package com.mohona.erp.feature.sales

import com.mohona.erp.feature.sales.data.CollectionRules
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CollectionRulesTest {
    @Test fun rules() {
        assertNull(CollectionRules.problem(BigDecimal(5000), "cash", null, listOf(CollectionRules.Alloc(BigDecimal(19000), BigDecimal(5000)))))
        assertEquals("reference", CollectionRules.problem(BigDecimal(2000), "bkash", null, emptyList()))
        assertEquals("allocation", CollectionRules.problem(BigDecimal(100), "cash", null, listOf(CollectionRules.Alloc(BigDecimal(50), BigDecimal(60)))))
        assertEquals("allocations above the amount", CollectionRules.problem(BigDecimal(100), "cash", null, listOf(CollectionRules.Alloc(BigDecimal(500), BigDecimal(150)))))
        assertNull(CollectionRules.problem(BigDecimal(3000), "bank", "TRX12345", emptyList()))
    }
}

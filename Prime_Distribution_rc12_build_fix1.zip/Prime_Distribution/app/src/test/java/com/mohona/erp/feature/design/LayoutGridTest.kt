package com.mohona.erp.feature.design

import com.mohona.erp.feature.design.data.Breakpoint
import com.mohona.erp.feature.design.data.DesignRepository
import com.mohona.erp.feature.design.data.GridWidget
import com.mohona.erp.feature.design.data.LayoutGrid
import com.mohona.erp.feature.design.data.Motion
import com.mohona.erp.feature.design.data.MotionPolicy
import com.mohona.erp.feature.design.data.ScreenLayout
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Same rules as design.fn_layout_report (t_s19_design2.sql S19-02..05). */
class LayoutGridTest {
    private val phone = Breakpoint("phone", 4, listOf(GridWidget("approvals", "approval", 0, 0, 4, 1), GridWidget("sales", "kpi", 0, 1, 2, 1, "kpi.sales_today")))

    @Test fun rulesMatchServer() {
        assertTrue(LayoutGrid.errors(phone).isEmpty())
        assertTrue(LayoutGrid.errors(phone.copy(widgets = phone.widgets + GridWidget("x", "kpi", 1, 1, 2, 1, "kpi.a_b"))).any { it.contains("overlap") })
        assertTrue(LayoutGrid.errors(phone.copy(widgets = listOf(GridWidget("ap", "approval", 0, 5, 4, 1)))).isNotEmpty())
        assertTrue(LayoutGrid.errors(phone.copy(widgets = listOf(GridWidget("k", "kpi", 0, 0, 2, 1)))).isNotEmpty())
        assertTrue(LayoutGrid.errors(phone, adsRequired = 1).any { it.contains("ad slot") })
    }

    @Test fun snapEditingRefusesBrokenMoves() {
        assertNull(LayoutGrid.edit(phone, "sales", dx = 3))                 // outside the grid
        assertNull(LayoutGrid.edit(phone, "approvals", dy = 4))             // approval pushed off-screen
        assertEquals(2, LayoutGrid.edit(phone, "sales", dx = 2)!!.widgets.first { it.id == "sales" }.x)
        assertNotNull(LayoutGrid.edit(phone, "sales", dw = 2))
    }

    @Test fun roundTripAndResponsiveChoice() {
        val l = ScreenLayout(mapOf("phone" to phone, "tablet" to phone.copy(name = "tablet", columns = 8)))
        val again = LayoutGrid.parse(LayoutGrid.encode(l))!!
        assertEquals(l, again)
        assertEquals("phone", LayoutGrid.pick(l, 360, 800).name)
        assertEquals("tablet", LayoutGrid.pick(l, 800, 1280).name)
        assertEquals("tablet", LayoutGrid.pick(l, 1280, 800).name)          // no landscape layout: tablet one
    }

    @Test fun reducedMotionAlwaysWins() {
        assertEquals(0, MotionPolicy.durationMs(Motion(300), 0f))
        assertEquals(0, MotionPolicy.durationMs(Motion(300, reduced = "always_reduce"), 1f))
        assertEquals(150, MotionPolicy.durationMs(Motion(300), 0.5f))
        assertEquals(600, MotionPolicy.durationMs(Motion(5000), 1f))
    }

    @Test fun activeDesignCarriesLayoutsAndMotion() {
        val a = DesignRepository.parseActive(JSONObject("""{"theme":null,"icons":[],"ads":true,
            "motion":{"duration_ms":120,"easing":"linear","reduced":"always_reduce"},
            "layouts":{"home":{"version":3,"layout":${LayoutGrid.encode(ScreenLayout(mapOf("phone" to phone)))}}}}"""))!!
        assertEquals(phone, a.layouts.getValue("home").phone); assertEquals("always_reduce", a.motion.reduced); assertTrue(a.ads)
    }
}

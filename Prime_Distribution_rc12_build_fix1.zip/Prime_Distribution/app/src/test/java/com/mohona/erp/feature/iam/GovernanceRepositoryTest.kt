package com.mohona.erp.feature.iam

import com.mohona.erp.feature.iam.data.CompanyPerson
import com.mohona.erp.feature.iam.data.GovernanceRepository
import com.mohona.erp.feature.iam.data.ScopeKind
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GovernanceRepositoryTest {
    @Test fun peopleParseWithTopRank() {
        val p = GovernanceRepository.parsePeople(JSONArray("""[{"membership_id":"m","person_id":"p","full_name_bn":"ক","employee_no":null,"status":"active",
            "assignments":[{"assignment_id":"a1","position_code":"MD","position_name_bn":"এমডি","rank":900,"status":"active","kind":"regular","valid_from":"t","valid_until":null,"home_wing_id":null,"home_department_id":null},
                           {"assignment_id":"a2","position_code":"AUDITOR","position_name_bn":"নি","rank":650,"status":"suspended","kind":"acting","valid_from":"t","valid_until":null,"home_wing_id":null,"home_department_id":null}]}]"""))!!
        assertEquals(900, p[0].topRank); assertNull(p[0].employeeNo); assertEquals("acting", p[0].assignments[1].kind)
    }
    @Test fun delegationsAndTransfersParse() {
        val d = GovernanceRepository.parseDelegations(JSONArray("""[{"id":"d","direction":"received","permission_codes":["iam.position.read"],"scope_kind":"COMPANY","scope_id":null,
            "valid_from":"a","valid_until":"b","reason":"r","live":true}]"""))!!
        assertFalse(d[0].given); assertEquals(ScopeKind.COMPANY, d[0].scopeKind); assertTrue(d[0].live)
        assertEquals("c1", GovernanceRepository.parseTransfers(JSONArray("""[{"id":"t","company_id":"c1","company_name_bn":"ক","reason":"r","expires_at":"x"}]"""))!![0].companyId)
        assertNull(GovernanceRepository.parseDelegations(JSONArray("""[{"id":"d"}]""")))
    }
    @Test fun manageGuardMirrorsServer() {
        val other = CompanyPerson("m", "p2", "খ", null, "active", emptyList())
        val me = CompanyPerson("m1", "p1", "ক", null, "active", emptyList())
        assertTrue(GovernanceRepository.canManage(900, false, "p1", other, 600, "ACCOUNTANT"))
        assertFalse(GovernanceRepository.canManage(900, false, "p1", other, 900, "MD"))
        assertFalse(GovernanceRepository.canManage(900, false, "p1", me, 100, "EMPLOYEE_SELF"))
        assertFalse(GovernanceRepository.canManage(1000, true, "p1", other, 900, "CHAIRMAN"))
        assertTrue(GovernanceRepository.canManage(1000, true, "p1", other, 900, "MD"))
    }
}

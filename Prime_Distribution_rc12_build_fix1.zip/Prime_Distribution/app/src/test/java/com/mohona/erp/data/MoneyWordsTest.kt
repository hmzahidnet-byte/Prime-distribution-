package com.mohona.erp.data

import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Test

/** Owner decision 14 Nov 2026: taka + paisa (2 decimals) and the amount in Bengali words. Mirrors SQL test S68-01/02. */
class MoneyWordsTest {
    @Test fun ownerExample() {
        assertEquals("৳ ১,১২,৯৫০.৬৬", Bn.money(BigDecimal("112950.66")))
        assertEquals("এক লক্ষ বারো হাজার নয় শত পঞ্চাশ টাকা ছেষট্টি পয়সা মাত্র", Bn.takaWords(BigDecimal("112950.66")))
    }
    @Test fun edges() {
        assertEquals("শূন্য টাকা মাত্র", Bn.takaWords(BigDecimal.ZERO))
        assertEquals("পঞ্চাশ পয়সা", Bn.takaWords(BigDecimal("0.5")).removePrefix("শূন্য টাকা ").removeSuffix(" মাত্র"))
        assertEquals("এক কোটি এক টাকা মাত্র", Bn.takaWords(BigDecimal("10000001")))
        assertEquals("এক শত পঞ্চাশ কোটি টাকা মাত্র", Bn.takaWords(BigDecimal("1500000000")))
        assertEquals("নিরানব্বই হাজার নয় শত নিরানব্বই টাকা নিরানব্বই পয়সা মাত্র", Bn.takaWords(BigDecimal("99999.994")))
        assertEquals("এক লক্ষ টাকা মাত্র", Bn.takaWords(BigDecimal("99999.995")))
        assertEquals("ঋণাত্মক পাঁচ টাকা মাত্র", Bn.takaWords(BigDecimal("-5")))
        assertEquals("৳ ০.০৫", Bn.money(BigDecimal("0.049")))
        assertEquals("-৳ ১,০০০.০০", Bn.money(BigDecimal("-1000")))
        assertEquals("—", Bn.money(null as String?))
        assertEquals("৳ ১২,৩৪,৫৬,৭৮৯.০০", Bn.money("123456789"))
    }
}

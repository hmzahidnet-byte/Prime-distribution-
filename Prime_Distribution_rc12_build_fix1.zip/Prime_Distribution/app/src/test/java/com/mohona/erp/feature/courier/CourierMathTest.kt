package com.mohona.erp.feature.courier

import com.mohona.erp.feature.courier.data.CourierMath
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Blueprint v180, data contract invariant 5 and scenarios 3 and 8. */
class CourierMathTest {
    @Test fun blueprintExample() {
        // 50,000 collected, 800 company-paid freight deducted, 30,000 remitted -> courier still owes 19,200
        assertEquals(0, BigDecimal(19200).compareTo(CourierMath.courierReceivable(BigDecimal(50000), BigDecimal(30000), BigDecimal(800))))
    }

    @Test fun shortfallMustBeFullyClassified() {
        val s = CourierMath.shortfall(BigDecimal(5000), BigDecimal(3500))
        assertEquals(0, BigDecimal(1500).compareTo(s))
        assertTrue(CourierMath.classified(s, BigDecimal(1500), BigDecimal.ZERO))          // all dealer due
        assertTrue(CourierMath.classified(s, BigDecimal(1000), BigDecimal(500)))          // split
        assertFalse(CourierMath.classified(s, BigDecimal(1000), BigDecimal.ZERO))         // 500 left unexplained
        assertEquals(0, BigDecimal.ZERO.compareTo(CourierMath.shortfall(BigDecimal(1000), BigDecimal(1000))))
    }

    @Test fun splitFreight() {
        assertTrue(CourierMath.splitOk(BigDecimal(800), BigDecimal(500), BigDecimal(300)))
        assertFalse(CourierMath.splitOk(BigDecimal(800), BigDecimal(500), BigDecimal(200)))
        assertFalse(CourierMath.splitOk(BigDecimal(800), BigDecimal(900), BigDecimal(-100)))
    }
}

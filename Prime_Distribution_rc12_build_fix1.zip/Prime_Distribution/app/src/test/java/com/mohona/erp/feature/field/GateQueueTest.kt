package com.mohona.erp.feature.field

import com.mohona.erp.feature.field.data.GateQueue
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GateQueueTest {
    @Test fun sameTokenQueuedOnce() {
        val q = GateQueue(maxItems = 2)
        assertTrue(q.add("MOS1|A|X|e|1|aa", 1_000)); assertFalse(q.add("MOS1|A|X|e|1|aa", 2_000))
        assertTrue(q.add("MOS1|A|X|e|2|bb", 3_000)); assertFalse(q.add("MOS1|A|X|e|3|cc", 4_000))   // full: never silently drops older scans
        assertEquals(2, q.batch().length()); assertEquals("1970-01-01T00:00:01Z", q.batch().getJSONObject(0).getString("scanned_at"))
        q.clear(); assertEquals(0, q.size)
    }
}

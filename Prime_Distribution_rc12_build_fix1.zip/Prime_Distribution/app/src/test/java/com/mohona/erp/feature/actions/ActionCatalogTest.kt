package com.mohona.erp.feature.actions

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActionCatalogTest {
    private val sample = """{"version":1,"actions":[
        {"d":"wh","r":"v1_order_pack","n":"অর্ডার প্যাক","w":true,"f":[{"p":"p_order_id","l":"অর্ডার-আইডি","t":"UUID","o":false},{"p":"p_cartons","l":"cartons","t":"INT","o":false},{"p":"p_note","l":"মন্তব্য","t":"TEXT","o":true}]},
        {"d":"dms","r":"v1_sales_analysis","n":"বিক্রয় বিশ্লেষণ","w":false,"f":[{"p":"p_from","l":"শুরুর তারিখ","t":"DATE","o":false},{"p":"p_lines","l":"x","t":"JSON","o":true},{"p":"p_ok","l":"x","t":"BOOL","o":true},{"p":"p_amt","l":"x","t":"NUMBER","o":true}]},
        {"d":"x","r":"drop table users","n":"bad","w":true,"f":[]}]}"""

    @Test fun sevenDepartmentsAndSafeParsing() {
        assertEquals(listOf("mfs", "wh", "dms", "crm", "hr", "courier", "dealer", "chairman"), ActionCatalog.departments.map { it.id })   // seven staff icons + the dealer's own app
        assertTrue(ActionCatalog.departments.single { it.chairmanOnly }.id == "chairman")
        val a = ActionCatalog.parse(sample)
        assertEquals(2, a.size)                                    // an entry whose name is not a v1_ function is dropped
        assertEquals(FieldType.UUID, a[0].fields[0].type)
        assertEquals(0, ActionCatalog.parse("not json").size)
    }

    @Test fun typedParameters() {
        val a = ActionCatalog.parse(sample)
        val p = ActionCatalog.buildParams(a[0], mapOf("p_order_id" to "0b0f4c0e-1111-2222-3333-444455556666", "p_cartons" to "১২")).getOrThrow()
        assertEquals(12, p.getInt("p_cartons")); assertTrue(p.isNull("p_note"))            // Bengali digits accepted; blank = null
        assertTrue(ActionCatalog.buildParams(a[0], mapOf("p_order_id" to "123")).isFailure)
        val q = ActionCatalog.buildParams(a[1], mapOf("p_from" to "২০২৬-১১-০১", "p_lines" to "[{\"qty\":2}]", "p_ok" to "true", "p_amt" to "12.50")).getOrThrow()
        assertEquals("2026-11-01", q.getString("p_from")); assertEquals(2, q.getJSONArray("p_lines").getJSONObject(0).getInt("qty"))
        assertTrue(q.getBoolean("p_ok")); assertEquals("12.50", q.get("p_amt").toString())
        assertTrue(ActionCatalog.buildParams(a[1], mapOf("p_from" to "01/11/2026")).isFailure)
        assertTrue(ActionCatalog.buildParams(a[1], mapOf("p_from" to "2026-11-01", "p_lines" to "5")).isFailure)
    }

    @Test fun rendering() {
        assertEquals(listOf("তথ্য নেই"), ActionCatalog.render(JSONObject.NULL))
        assertEquals(listOf("কোনো সারি নেই"), ActionCatalog.render(JSONArray()))
        val lines = ActionCatalog.render(JSONObject("""{"number":"SO-1","rows":[{"sku":"N","qty":2}],"note_bn":null}"""))
        assertTrue(lines.contains("number: SO-1")); assertTrue(lines.any { it.contains("sku: N") }); assertTrue(lines.contains("note_bn: —"))
    }
}

package com.mohona.erp.feature.maps

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** V162-12: only https packages with a proper SHA-256 are accepted from the catalogue; file names are stable per region + version. */
class OfflineMapStoreTest {
    @Test fun catalogueIsFilteredAndParsed() {
        val c = JSONObject("""{"quota_mb":300,"packages":[
            {"package_id":"a","region_code":"10","name_bn":"বরিশাল","version":2,"url":"https://m.example.org/10-v2.sqlite","sha256":"${"b".repeat(64)}","size_bytes":52000000,"min_zoom":6,"max_zoom":15,"attribution":"© OSM","current":true},
            {"package_id":"b","region_code":"10","name_bn":"বরিশাল","version":1,"url":"http://insecure","sha256":"${"a".repeat(64)}","size_bytes":1,"min_zoom":6,"max_zoom":15,"attribution":"© OSM","current":false},
            {"package_id":"c","region_code":"20","name_bn":"চট্টগ্রাম","version":1,"url":"https://m.example.org/20.sqlite","sha256":"bad","size_bytes":1,"min_zoom":6,"max_zoom":15,"attribution":"© OSM","current":true}]}""")
        val (quota, list) = OfflineMapStore.parse(c)
        assertEquals(300, quota); assertEquals(1, list.size)
        assertEquals("region_10_v2.sqlite", list[0].fileName); assertTrue(list[0].current)
    }
}

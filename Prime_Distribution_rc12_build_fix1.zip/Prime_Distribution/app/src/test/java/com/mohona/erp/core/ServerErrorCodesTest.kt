package com.mohona.erp.core

import com.mohona.erp.core.net.ErrorCatalog
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/** Every E_* code the backend migrations can raise must have a Bengali message in the app (no raw server text ever shown). */
class ServerErrorCodesTest {
    @Test fun everyServerCodeIsMappedInTheApp() {
        val dir = File("../backend/supabase/migrations")
        assertTrue("migrations not found from ${File(".").absolutePath}", dir.isDirectory)
        val codes = dir.listFiles()!!.filter { it.name.endsWith(".sql") }
            .flatMap { Regex("'(E_[A-Z0-9_]+)").findAll(it.readText()).map { m -> m.groupValues[1] }.toList() + Regex("\\b(E_[A-Z0-9_]+):").findAll(it.readText()).map { m -> m.groupValues[1] }.toList() }
            .toSet()
        assertTrue(codes.size >= 20)
        val missing = codes.filter { !ErrorCatalog.knows(it) }.sorted()
        assertTrue("unmapped server error codes: $missing", missing.isEmpty())
    }
}

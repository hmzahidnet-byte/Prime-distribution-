package com.mohona.erp.core

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.HttpRequest
import com.mohona.erp.core.net.HttpResponse
import com.mohona.erp.core.net.HttpTransport
import com.mohona.erp.core.net.MemoryTokenStore
import com.mohona.erp.core.net.SessionTokens
import com.mohona.erp.core.net.SupabaseClient
import com.mohona.erp.core.net.SupabaseConfig
import com.mohona.erp.feature.forms.data.AttachmentUploader
import com.mohona.erp.feature.forms.data.DraftAutoSync
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** OI-28 / OI-29: binary upload to the server-chosen path, never overwriting; SHA-256; automatic draft sync throttle. */
class StorageUploadTest {
    private class Fake(val handler: (HttpRequest) -> HttpResponse) : HttpTransport {
        val seen = ArrayList<HttpRequest>()
        override fun execute(request: HttpRequest): HttpResponse { seen.add(request); return handler(request) }
    }
    private fun client(t: HttpTransport) = SupabaseClient(SupabaseConfig("https://example.supabase.co", "anon-public"), t,
        MemoryTokenStore().apply { write(SessionTokens("A1", "R1", 10_000L)) }, Dispatchers.Unconfined, nowEpochSec = { 1_000L }, newId = { "id-1" })

    @Test fun uploadSendsBytesToTheServerPathWithoutUpsert() = runBlocking {
        val f = Fake { HttpResponse(200, """{"Key":"forms/x"}""") }
        val bytes = byteArrayOf(1, 2, 3)
        val r = client(f).uploadObject("forms", "c1/f1/a1.jpg", bytes, "image/jpeg")
        assertTrue(r is ApiResult.Ok)
        val req = f.seen.single()
        assertEquals("https://example.supabase.co/storage/v1/object/forms/c1/f1/a1.jpg", req.url)
        assertEquals("POST", req.method); assertArrayEquals(bytes, req.bodyBytes); assertNull(req.body)
        assertEquals("image/jpeg", req.headers["Content-Type"]); assertEquals("false", req.headers["x-upsert"]); assertEquals("Bearer A1", req.headers["Authorization"])
    }

    @Test fun uploadRefusesPathsTheServerWouldNeverGive() {
        val f = Fake { HttpResponse(200, "{}") }
        listOf("../etc/passwd.txt", "/abs/a.jpg", "a b/c.jpg", "c1/f1/a1").forEach { p ->
            assertTrue(p, runCatching { runBlocking { client(f).uploadObject("forms", p, byteArrayOf(1), "image/jpeg") } }.isFailure)
        }
        assertTrue(f.seen.isEmpty())
    }

    @Test fun uploadErrorIsReported() = runBlocking {
        val r = client(Fake { HttpResponse(403, """{"message":"new row violates row-level security policy"}""") }).uploadObject("forms", "c/f/a.png", byteArrayOf(9), "image/png")
        assertTrue(r is ApiResult.Err); assertEquals(403, (r as ApiResult.Err).error.httpCode)
    }

    @Test fun sha256IsLowercaseHex() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", AttachmentUploader.sha256Hex("abc".toByteArray()))
    }

    @Test fun autoSyncRunsAtMostOncePerMinute() {
        val t = 5_000_000_000L
        assertTrue(DraftAutoSync.shouldRun(t)); assertFalse(DraftAutoSync.shouldRun(t + 10_000)); assertTrue(DraftAutoSync.shouldRun(t + 61_000))
    }
}

package com.mohona.erp.feature.forms

import com.mohona.erp.feature.forms.data.FileDraftStorage
import com.mohona.erp.feature.forms.data.OfflineDraft
import com.mohona.erp.feature.forms.data.OfflineDraftStore
import java.nio.file.Files
import javax.crypto.KeyGenerator
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FileDraftStorageTest {
    @Test fun ciphertextOnDiskAndSafeIds() {
        val dir = Files.createTempDirectory("drafts").toFile()
        val storage = FileDraftStorage(dir)
        val key = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        val store = OfflineDraftStore(storage, { key })
        store.save(OfflineDraft("draft-0001", "c1", "p1", "f1", 2, JSONObject().put("nid", "1234567890123"), null, 0), 10)
        val onDisk = dir.listFiles()!!.single()
        assertEquals("draft-0001.draft", onDisk.name)
        assertFalse(onDisk.readText().contains("1234567890123"))
        assertEquals("1234567890123", store.list("c1", "p1", 14).single().values.getString("nid"))
        assertTrue(runCatching { storage.put("../escape", "x") }.isFailure)
        storage.remove("draft-0001"); assertNull(storage.get("draft-0001")); assertTrue(storage.ids().isEmpty())
    }
}

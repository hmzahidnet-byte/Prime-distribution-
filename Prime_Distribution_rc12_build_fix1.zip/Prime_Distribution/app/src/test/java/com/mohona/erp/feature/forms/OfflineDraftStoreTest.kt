package com.mohona.erp.feature.forms

import com.mohona.erp.feature.forms.data.MemoryDraftStorage
import com.mohona.erp.feature.forms.data.OfflineDraft
import com.mohona.erp.feature.forms.data.OfflineDraftStore
import javax.crypto.KeyGenerator
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OfflineDraftStoreTest {
    private val key = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
    private var clock = 1_000_000L
    private val storage = MemoryDraftStorage()
    private val store = OfflineDraftStore(storage, { key }, { clock })
    private fun draft(id: String, person: String = "p1", company: String = "c1") =
        OfflineDraft(id, company, person, "f1", 2, JSONObject().put("nid", "1234567890123"), null, 0)

    @Test fun draftsAreEncryptedAtRest() {
        assertTrue(store.save(draft("draft-0001"), 50))
        val blob = storage.get("draft-0001")!!
        assertTrue(blob.startsWith("v1:")); assertFalse(blob.contains("1234567890123"))
        assertEquals("1234567890123", store.get("draft-0001")!!.values.getString("nid"))
    }

    @Test fun boundToPersonAndCompany() {
        store.save(draft("draft-0001"), 50); store.save(draft("draft-0002", person = "p2"), 50); store.save(draft("draft-0003", company = "c2"), 50)
        assertEquals(listOf("draft-0001"), store.list("c1", "p1", 14).map { it.clientDraftId })
    }

    @Test fun expiryAndTamperingRemoveDrafts() {
        store.save(draft("draft-0001"), 50)
        clock += 15L * 86_400_000L
        assertTrue(store.list("c1", "p1", 14).isEmpty()); assertNull(storage.get("draft-0001"))
        storage.put("draft-0009", "v1:AAAAAAAAAAAAAAAAAAAAAAAAAAAA")
        assertTrue(store.list("c1", "p1", 14).isEmpty()); assertNull(storage.get("draft-0009"))
    }

    @Test fun limitAndSyncLifecycle() {
        assertTrue(store.save(draft("draft-0001"), 1))
        assertFalse(store.save(draft("draft-0002"), 1))
        assertTrue(store.save(draft("draft-0001"), 1))          // updating an existing draft is always allowed
        store.markSynced("draft-0001", "srv-1", conflict = false)
        assertEquals("srv-1", store.get("draft-0001")!!.serverSubmissionId)
        store.markSynced("draft-0001", "srv-1", conflict = true) // submitted online meanwhile: local copy dropped
        assertNull(store.get("draft-0001"))
        store.save(draft("draft-0003"), 5); store.clearAll(); assertTrue(storage.ids().isEmpty())
    }
}

package com.mohona.erp.core.shell

import com.mohona.erp.feature.iam.data.MyPermissions
import com.mohona.erp.feature.iam.data.PermissionScope
import com.mohona.erp.feature.iam.data.ScopeKind
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ShellTabsTest {
    private val company = listOf(PermissionScope(ScopeKind.COMPANY, null))
    private val accountant = MyPermissions("ACCOUNTANT", false, mapOf("forms.form.read" to company))

    @Test fun defaultTabsAndMoreAlwaysLast() {
        assertEquals(listOf("home", "reports", "more"), ShellTabs.resolve(null, accountant).map { it.key })      // no approval inbox right
        assertEquals(listOf("home", "tasks", "reports", "more"), ShellTabs.resolve(null, null).map { it.key })   // preview: no hints
    }

    @Test fun chairmanChoiceIsCleanedUp() {
        val t = ShellTabs.resolve(listOf("forms", "more", "admin", "HOME", "forms", "search", "scan", "reports", "tasks"), MyPermissions("CHAIRMAN", true, emptyMap()))
        assertEquals(listOf("home", "forms", "search", "scan", "more"), t.map { it.key })
        assertEquals(ShellTabs.MAX, t.size)
    }

    @Test fun moduleOffHidesItsTab() {
        assertFalse(ShellTabs.resolve(listOf("home", "forms"), accountant, setOf("core", "iam")).any { it.key == "forms" })
        assertTrue(ShellTabs.resolve(listOf("home", "forms"), accountant, setOf("forms")).any { it.key == "forms" })
    }

    @Test fun uiConfigParses() {
        val c = UiConfig.parse(JSONObject("""{"tabs":["home","forms","more"],"theme_primary":"#1456A0","modules":["forms","iam"],
            "flags":{"forms.offline_drafts":true},"mfa_positions":["CHAIRMAN","MD"],"offline":{"draft_ttl_days":7,"max_drafts":20}}"""))!!
        assertTrue(c.flag("forms.offline_drafts")); assertEquals(20, c.maxDrafts); assertEquals(7L, c.draftTtlDays)
        assertEquals(listOf("home", "forms", "more"), c.tabs)
        assertTrue(PermissionHints.can(null, "anything")); assertFalse(PermissionHints.can(accountant, "config.settings.manage"))
    }
}

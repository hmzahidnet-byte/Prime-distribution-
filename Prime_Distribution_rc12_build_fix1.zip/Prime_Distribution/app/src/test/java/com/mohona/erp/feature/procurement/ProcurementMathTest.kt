package com.mohona.erp.feature.procurement

import com.mohona.erp.feature.procurement.data.ProcurementMath
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Same cases as t_s26_procurement.sql (S26-08, S26-09). */
class ProcurementMathTest {
    @Test fun threeWayMatch() {
        assertTrue(ProcurementMath.matchLine(BigDecimal(550), BigDecimal(45), BigDecimal(550), BigDecimal(45), 100, 0).isEmpty())
        assertEquals("price", ProcurementMath.matchLine(BigDecimal(30), BigDecimal(50), BigDecimal(30), BigDecimal(45), 100, 0).single().kind)
        assertTrue(ProcurementMath.matchLine(BigDecimal(30), BigDecimal("45.40"), BigDecimal(30), BigDecimal(45), 100, 0).isEmpty())   // within 1%
        assertEquals("quantity", ProcurementMath.matchLine(BigDecimal(31), BigDecimal(45), BigDecimal(30), BigDecimal(45), 100, 0).single().kind)
    }

    @Test fun receiptSplitAndAging() {
        assertTrue(ProcurementMath.splitOk(BigDecimal(600), BigDecimal(550), BigDecimal(30), BigDecimal(20)))
        assertFalse(ProcurementMath.splitOk(BigDecimal(600), BigDecimal(550), BigDecimal(30), BigDecimal(10)))
        assertEquals("current", ProcurementMath.agingBucket(0)); assertEquals("d31_60", ProcurementMath.agingBucket(45)); assertEquals("d90_plus", ProcurementMath.agingBucket(91))
    }
}

package com.mohona.erp.feature.iam

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.HttpResponse
import com.mohona.erp.core.net.HttpTransport
import com.mohona.erp.core.net.MemoryTokenStore
import com.mohona.erp.core.net.SessionTokens
import com.mohona.erp.core.net.SupabaseClient
import com.mohona.erp.core.net.SupabaseConfig
import com.mohona.erp.feature.iam.data.PositionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PositionRepositoryTest {
    private val ctxJson = """{"person_id":"p1","company_id":"c1","company_code":"PA","company_name_bn":"ক","membership_id":"m1","assignment_id":"a1",
        "position_code":"CHAIRMAN","position_name_bn":"চেয়ারম্যান","is_supreme":true,"home_wing_id":null,"home_department_id":null,"authz_epoch":4}"""

    private fun opt(id: String, company: String, rank: Int, usable: Boolean) =
        """{"assignment_id":"$id","company_id":"c-$company","company_code":"$company","company_name_bn":"x","position_code":"P$rank","position_name_bn":"y","rank":$rank,"is_supreme":false,"kind":"regular","valid_from":null,"valid_until":null,"usable":$usable}"""

    @Test fun epochChangeDropsCaches() = runBlocking {
        var epoch = 4
        var dropped = 0
        val t = HttpTransport { _ -> HttpResponse(200, ctxJson.replace("\"authz_epoch\":4", "\"authz_epoch\":$epoch")) }
        val client = SupabaseClient(SupabaseConfig("https://x.supabase.co", "k"), t,
            MemoryTokenStore().apply { write(SessionTokens("A", "R", Long.MAX_VALUE / 2)) }, Dispatchers.Unconfined)
        val repo = PositionRepository(client) { dropped++ }
        repo.current(); repo.current(); assertEquals(0, dropped)
        epoch = 5; repo.current(); assertEquals(1, dropped)
    }

    @Test fun parsesContextWithNullHomeScope() {
        val c = PositionRepository.parseContext(JSONObject(ctxJson))!!
        assertEquals("CHAIRMAN", c.positionCode); assertTrue(c.isSupreme); assertNull(c.homeWingId); assertEquals(4, c.authzEpoch)
    }

    @Test fun pickerOrderAndAutoSelect() {
        val list = PositionRepository.parseOptions(JSONArray("[" + listOf(opt("a", "PB", 500, true), opt("b", "PA", 900, false), opt("c", "PA", 600, true)).joinToString(",") + "]"))!!
        assertEquals(listOf("c", "a", "b"), PositionRepository.pickerOrder(list).map { it.assignmentId })
        assertNull(PositionRepository.autoSelectable(list))
        assertEquals("c", PositionRepository.autoSelectable(list.filter { it.assignmentId != "a" })!!.assignmentId)
    }

    @Test fun selectSendsAssignmentAndAlwaysDropsCaches() = runBlocking {
        var dropped = 0
        val seen = ArrayList<String?>()
        val t = HttpTransport { req -> seen.add(req.body); HttpResponse(200, ctxJson) }
        val client = SupabaseClient(SupabaseConfig("https://x.supabase.co", "k"), t,
            MemoryTokenStore().apply { write(SessionTokens("A", "R", Long.MAX_VALUE / 2)) }, Dispatchers.Unconfined)
        val repo = PositionRepository(client) { dropped++ }
        val r = repo.select("a1")
        assertNotNull((r as ApiResult.Ok).value); assertEquals(1, dropped)
        assertEquals("a1", JSONObject(seen.single()!!).getString("p_assignment_id"))
        repo.clear(); assertEquals(2, dropped)
    }
}

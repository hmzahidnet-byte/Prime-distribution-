package com.mohona.erp.feature.hr

import com.mohona.erp.feature.hr.data.HierarchyRepository
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HierarchyRepositoryTest {
    @Test fun accessPreviewParsesGapsAndConflicts() {
        val p = HierarchyRepository.parsePreview(JSONObject("""{"assignment_id":"a","position_code":"MD","is_supreme":false,
            "permissions":[{"code":"forms.submission.export","module":"forms","name_bn":"রপ্তানি","is_sensitive":true,"via":"granted"},
                           {"code":"audit.read","module":"audit","name_bn":"অডিট","is_sensitive":false,"via":"delegated"}],
            "dependency_gaps":[{"permission":"config.rule.manage","requires":"config.rule.read"}],
            "sod_conflicts":[{"permission_a":"forms.submission.export","permission_b":"forms.submission.void","mode":"warn"}]}"""))!!
        assertEquals(2, p.byModule.size); assertEquals("config.rule.read", p.gaps.single().requires)
        assertFalse(p.hasBlockingConflict)
        assertNull(HierarchyRepository.parsePreview(JSONObject("""{"assignment_id":"a"}""")))
    }

    @Test fun orgTreeKeepsMaskedSalaryAsText() {
        val t = HierarchyRepository.parseTree(JSONArray("""[
            {"code":"CHAIRMAN","name_bn":"চেয়ারম্যান","rank":1000,"reports_to_code":null,"is_supreme":true,"holders":[]},
            {"code":"MD","name_bn":"এমডি","rank":900,"reports_to_code":"CHAIRMAN","is_supreme":false,"holders":[
              {"assignment_id":"x","name_bn":"ক","employee_id":"e","manager_employee_id":null,"employment_status":"active","grade":null,"salary":"••••••","onboarding_open":false}]},
            {"code":"FIN_MANAGER","name_bn":"অর্থ","rank":700,"reports_to_code":"MD","is_supreme":false,"holders":[
              {"assignment_id":"y","name_bn":"খ","employee_id":"f","manager_employee_id":"e","grade":"G5","salary":50000,"onboarding_open":true}]}]"""))!!
        assertEquals("••••••", t[1].holders[0].salaryText); assertNull(t[1].holders[0].grade)
        assertEquals("50000", t[2].holders[0].salaryText); assertTrue(t[2].holders[0].onboardingOpen)
        assertEquals(listOf("CHAIRMAN"), HierarchyRepository.children(t, null).map { it.code })
        assertEquals(listOf("FIN_MANAGER"), HierarchyRepository.children(t, "MD").map { it.code })
    }

    @Test fun changeResult() {
        val c = HierarchyRepository.parseChange(JSONObject("""{"change_id":"c","status":"pending_approval","request_id":"r","new_assignment_id":null}"""))
        assertEquals("r", c.requestId); assertNull(c.newAssignmentId)
    }

    @Test fun flattenIsDepthFirstAndNeverLosesAPosition() {
        val t = HierarchyRepository.parseTree(JSONArray("""[
            {"code":"CHAIRMAN","name_bn":"চ","rank":1000,"reports_to_code":null,"is_supreme":true,"holders":[]},
            {"code":"MD","name_bn":"এ","rank":900,"reports_to_code":"CHAIRMAN","is_supreme":false,"holders":[]},
            {"code":"ACCOUNTANT","name_bn":"হ","rank":600,"reports_to_code":"MD","is_supreme":false,"holders":[]},
            {"code":"X","name_bn":"x","rank":1,"reports_to_code":"Y","is_supreme":false,"holders":[]},
            {"code":"Y","name_bn":"y","rank":2,"reports_to_code":"X","is_supreme":false,"holders":[]}]"""))!!
        val f = HierarchyRepository.flatten(t)
        assertEquals(listOf("CHAIRMAN" to 0, "MD" to 1, "ACCOUNTANT" to 2), f.take(3).map { it.first.code to it.second })
        assertEquals(5, f.size)
    }
}

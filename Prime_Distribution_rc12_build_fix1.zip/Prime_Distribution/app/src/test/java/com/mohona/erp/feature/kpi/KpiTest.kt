package com.mohona.erp.feature.kpi

import com.mohona.erp.feature.kpi.data.AdRotation
import com.mohona.erp.feature.kpi.data.KpiCache
import com.mohona.erp.feature.kpi.data.KpiFormat
import com.mohona.erp.feature.kpi.data.KpiRepository
import java.math.BigDecimal
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KpiTest {
    private val values = KpiRepository.parseValues(JSONArray("""[
        {"code":"sales.amount","name_bn":"বিক্রয়","unit":"money","value":123456789.5,"previous":100000000,"refresh_seconds":300,"restricted":false,"cached":false,"style":{"chart":"bar","size":"l","color":"chart3"}},
        {"code":"mfg.factory_pnl","name_bn":"ফ্যাক্টরি লাভ-ক্ষতি","restricted":true,"value":999},
        {"code":"security.failed_logins","name_bn":"ব্যর্থ লগইন","unit":"count","value":12,"previous":10,"restricted":false},
        {"code":"x.y","error":"unknown"}]"""))!!

    @Test fun restrictedNeverCarriesANumber() {
        assertNull(values[1].value); assertTrue(values[1].restricted); assertEquals("গোপন", KpiFormat.value(values[1]))
        assertTrue(values[3].restricted)
    }

    @Test fun bengaliLakhCroreGrouping() {
        assertEquals("৳ ১২,৩৪,৫৬,৭৮৯.৫০", KpiFormat.value(values[0]))
        assertEquals("১,০০০", KpiFormat.grouped(BigDecimal(1000), 0))
        assertEquals("-১২,৩৪৫.০০", KpiFormat.grouped(BigDecimal("-12345")))
        assertEquals("bar", values[0].style.chart)
    }

    @Test fun deltaToneIsSemantic() {
        assertEquals(KpiFormat.Tone.GOOD, KpiFormat.delta(values[0])!!.second)
        assertEquals(KpiFormat.Tone.BAD, KpiFormat.delta(values[2])!!.second)        // more failed logins is bad
        assertNull(KpiFormat.delta(values[1]))
    }

    @Test fun bindingsAndAds() {
        assertEquals("sales.amount", KpiRepository.codeOf("kpi.sales.amount")); assertNull(KpiRepository.codeOf("list.my_tasks"))
        assertEquals(listOf(1, 2), AdRotation.visible(listOf(1, 2, 3), 2, 0))
        assertEquals(listOf(3, 1), AdRotation.visible(listOf(1, 2, 3), 2, 2))
        assertEquals(2, AdRotation.visible(listOf(1, 2, 3), 5, 0).size)
    }

    @Test fun clientCacheRespectsRefreshAndSkipsRestricted() {
        var now = 0L
        val c = KpiCache { now }
        c.put("a", values[0]); c.put("b", values[1])
        assertEquals("sales.amount", c.get("a")!!.code); assertNull(c.get("b"))
        now = 301_000L; assertNull(c.get("a"))
    }
}

package com.mohona.erp.feature.auth

import com.mohona.erp.core.net.AppError
import com.mohona.erp.core.net.ErrorKind
import com.mohona.erp.feature.auth.data.LoginRepository
import com.mohona.erp.feature.auth.data.LoginRules
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Same cases as backend/supabase/tests/t_s16_auth.sql (S16-01, S16-04): client pre-checks agree with the server. */
class LoginRulesTest {
    @Test fun phoneCanonicalForm() {
        assertEquals("+8801711111111", LoginRules.canonicalPhone("01711111111"))
        assertEquals("+8801711111111", LoginRules.canonicalPhone("+880 1711-111111"))
        assertEquals("+8801711111111", LoginRules.canonicalPhone("8801711111111"))
        assertEquals("+8801711111111", LoginRules.canonicalPhone("০১৭১১১১১১১১"))
        assertNull(LoginRules.canonicalPhone("abc"))
    }

    @Test fun pinPolicy() {
        assertEquals("sequence", LoginRules.pinProblem("123456"))
        assertEquals("repeated", LoginRules.pinProblem("111111"))
        assertEquals("sequence", LoginRules.pinProblem("987654"))
        assertEquals("digits", LoginRules.pinProblem("12a456"))
        assertEquals("length", LoginRules.pinProblem("4826"))
        assertEquals("sequence", LoginRules.pinProblem("890123"))
        assertEquals("common", LoginRules.pinProblem("121212"))
        assertNull(LoginRules.pinProblem("482913"))
    }

    @Test fun deviceIdMatchesServerPattern() {
        val id = LoginRules.newDeviceId()
        assertTrue(Regex("^[A-Za-z0-9_-]{16,128}$").matches(id))
        assertTrue(id != LoginRules.newDeviceId())
    }

    @Test fun pinSessionAndCompanies() {
        val t = LoginRepository.parsePinSession(JSONObject("""{"access_token":"a","refresh_token":"r","expires_at":100,"session_id":"s","token_type":"pin"}"""))!!
        assertEquals("pin", t.kind)
        assertNull(LoginRepository.parsePinSession(JSONObject("""{"error":"E_AUTH_FAILED"}""")))
        val cs = LoginRepository.parseCompanies(JSONArray("""[{"company_id":"c","code":"AUT","name_bn":"ক","membership_id":"m","positions":[
            {"assignment_id":"a1","position_code":"ACCOUNTANT","name_bn":"হিসাব","usable":true,"mfa_required":false},
            {"assignment_id":"a2","position_code":"MD","name_bn":"এমডি","usable":true,"mfa_required":true}]}]"""))!!
        assertNull(LoginRepository.autoPick(cs))                       // two usable positions: the person chooses
        val one = LoginRepository.parseCompanies(JSONArray("""[{"company_id":"c","code":"AUT","name_bn":"ক","membership_id":"m","positions":[
            {"assignment_id":"a1","position_code":"ACCOUNTANT","name_bn":"হিসাব","usable":true,"mfa_required":false}]}]"""))!!
        assertEquals("a1", LoginRepository.autoPick(one)!!.assignmentId)
    }

    @Test fun loginErrorsStayGeneric() {
        assertEquals("E_AUTH_LOCKED", LoginRepository.mapLoginError(AppError("E_AUTH_LOCKED", ErrorKind.FORBIDDEN, "x", 401)).code)
        assertEquals("E_AUTH_FAILED", LoginRepository.mapLoginError(AppError("C_SERVER", ErrorKind.SERVER, "x", 401)).code)
        assertEquals("C_NETWORK", LoginRepository.mapLoginError(AppError("C_NETWORK", ErrorKind.NETWORK, "x")).code)
    }
}

package com.mohona.erp.feature.actions

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** S60: search lists instead of typed ids, and a Bengali-only form catalog. */
class LookupKindsTest {
    private val catalog = JSONObject(File("src/main/assets/actions.json").readText(Charsets.UTF_8))
    private val kinds = File("src/main/assets/lookup_kinds.json").readText(Charsets.UTF_8)

    @Test fun parameterMapLoadsAndParsesRows() {
        LookupKinds.load(kinds)
        assertEquals("dealer", LookupKinds.kindFor("p_dealer_id")); assertEquals("warehouse", LookupKinds.kindFor("p_warehouse_id"))
        assertNull(LookupKinds.kindFor("p_note"))
        val rows = LookupKinds.parse(JSONArray("""[{"id":"a","label":"D1 · রহমান","sub":null},{"label":"no id"},{"id":"b","label":"x","sub":"y"}]"""))
        assertEquals(2, rows.size); assertEquals("", rows[0].sub); assertEquals("y", rows[1].sub)
        assertTrue(LookupKinds.parse("not an array").isEmpty())
        LookupKinds.load("broken"); assertNull(LookupKinds.kindFor("p_dealer_id"))
    }

    @Test fun everyLabelAndTitleIsBengali() {
        val a = catalog.getJSONArray("actions")
        val english = Regex("[A-Za-z]{3,}")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            assertTrue(o.getString("r"), !english.containsMatchIn(o.getString("n").replace(Regex("BOM|KPI|PIN|QR|GRN|SKU|FEFO|TLS|MB|PDF|COA|GL|HR|MD"), "")))
            val f = o.getJSONArray("f")
            for (k in 0 until f.length()) {
                val label = f.getJSONObject(k).getString("l").replace(Regex("\\[[^\\]]*\\]|\\([^)]*\\)"), "")      // JSON shape hints stay technical
                assertTrue(o.getString("r") + " " + label, !english.containsMatchIn(label.replace(Regex("BOM|KPI|PIN|QR|GRN|SKU|FEFO|TLS|MB|SHA|PO|PR|TIN|JSON"), "")))
            }
        }
    }

    @Test fun mostIdFieldsHaveASearchList() {
        LookupKinds.load(kinds)
        val a = catalog.getJSONArray("actions"); var ids = 0; var listed = 0
        for (i in 0 until a.length()) { val f = a.getJSONObject(i).getJSONArray("f")
            for (k in 0 until f.length()) { val x = f.getJSONObject(k); if (x.getString("t") == "UUID") { ids++; if (LookupKinds.kindFor(x.getString("p")) != null) listed++ } } }
        assertTrue("$listed of $ids", listed * 100 >= ids * 75)
    }
}

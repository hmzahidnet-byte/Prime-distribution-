package com.mohona.erp.feature.stock

import com.mohona.erp.feature.stock.data.LotRow
import com.mohona.erp.feature.stock.data.StockMath
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Same scenario as t_s25_raw_stock.sql (S25-04, S25-06, S25-10). */
class StockMathTest {
    @Test fun fefoTakesEarliestExpiryFirstAndSkipsExpired() {
        val lots = listOf(LotRow("L1", "L1", BigDecimal(130), "2026-12-09", false), LotRow("L2", "L2", BigDecimal(50), "2026-11-19", false),
                          LotRow("X", "X", BigDecimal(500), "2026-11-01", true))
        val p = StockMath.fefo(lots, BigDecimal(80))
        assertEquals(listOf("L2" to BigDecimal(50), "L1" to BigDecimal(30)), p.map { it.lotId to it.qty })
    }

    @Test fun onlyExpiredMeansExpiredError() {
        val e = runCatching { StockMath.fefo(listOf(LotRow("J1", "J1", BigDecimal(40), "2026-11-01", true)), BigDecimal(5)) }.exceptionOrNull() as StockMath.Short
        assertTrue(e.onlyExpired)
    }

    @Test fun movingAverage() {
        // 130 kg worth 7800 + 50 kg at 70 -> 180 kg worth 11300 -> 62.7778
        assertEquals(BigDecimal("62.7778"), StockMath.average(BigDecimal(130), BigDecimal(7800), BigDecimal(50), BigDecimal(70)))
    }
}

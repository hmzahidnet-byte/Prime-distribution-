package com.mohona.erp.feature.iam

import com.mohona.erp.feature.iam.data.IamRepository
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class IamRepositoryTest {
    @Test fun parsesPersonAndOnlyUsableCompaniesAreUsable() {
        val w = IamRepository.parseWhoAmI(JSONObject("""{"person":{"id":"p1","full_name_bn":"রহিম","authz_epoch":3},
          "memberships":[{"membership_id":"m1","company_id":"c1","company_code":"IA","company_name_bn":"ক","status":"active","company_status":"active","employee_no":"E-1"},
                         {"membership_id":"m2","company_id":"c2","company_code":"IB","company_name_bn":"খ","status":"suspended","company_status":"active"}]}"""))!!
        assertEquals("p1", w.person.id); assertEquals(3, w.person.authzEpoch); assertEquals(2, w.memberships.size)
        assertEquals(listOf("c1"), w.usableCompanies.map { it.companyId }); assertNull(w.memberships[1].employeeNo)
    }
    @Test fun malformedIsNull() { assertNull(IamRepository.parseWhoAmI(JSONObject("""{"memberships":[]}"""))) }
}

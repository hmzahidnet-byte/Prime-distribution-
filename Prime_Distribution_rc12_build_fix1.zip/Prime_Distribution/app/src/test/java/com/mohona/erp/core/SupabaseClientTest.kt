package com.mohona.erp.core

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorKind
import com.mohona.erp.core.net.HttpRequest
import com.mohona.erp.core.net.HttpResponse
import com.mohona.erp.core.net.HttpTransport
import com.mohona.erp.core.net.MemoryTokenStore
import com.mohona.erp.core.net.SessionTokens
import com.mohona.erp.core.net.SupabaseClient
import com.mohona.erp.core.net.SupabaseConfig
import com.mohona.erp.core.net.TransportTimeout
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SupabaseClientTest {
    private val cfg = SupabaseConfig("https://example.supabase.co", "anon-public")

    private class Fake(val handler: (HttpRequest) -> HttpResponse) : HttpTransport {
        val seen = ArrayList<HttpRequest>()
        override fun execute(request: HttpRequest): HttpResponse { seen.add(request); return handler(request) }
    }

    private fun client(t: HttpTransport, store: MemoryTokenStore = signedIn(), now: Long = 1_000L) =
        SupabaseClient(cfg, t, store, Dispatchers.Unconfined, nowEpochSec = { now }, newId = { "id-1" })

    private fun signedIn(exp: Long = 10_000L) = MemoryTokenStore().apply { write(SessionTokens("A1", "R1", exp)) }

    @Test fun rpcSendsApiProfileBearerAndRequestId() = runBlocking {
        val f = Fake { HttpResponse(200, """{"ok":true}""") }
        val r = client(f).rpcObject("v1_ping")
        assertTrue((r as ApiResult.Ok).value.getBoolean("ok"))
        val h = f.seen.single().headers
        assertEquals("https://example.supabase.co/rest/v1/rpc/v1_ping", f.seen.single().url)
        assertEquals("api", h["Content-Profile"]); assertEquals("api", h["Accept-Profile"])
        assertEquals("Bearer A1", h["Authorization"]); assertEquals("anon-public", h["apikey"]); assertEquals("id-1", h["X-Request-Id"])
        assertNull(h["Idempotency-Key"])
    }

    @Test fun writeRpcCarriesIdempotencyKeyAndReusesGivenKey() = runBlocking {
        val f = Fake { HttpResponse(200, "{}") }
        client(f).rpc("v1_save", JSONObject(), write = true, idempotencyKey = "same-key")
        assertEquals("same-key", f.seen.single().headers["Idempotency-Key"])
    }

    @Test fun serverEcodeBecomesTypedError() = runBlocking {
        val f = Fake { HttpResponse(400, """{"code":"P0001","message":"E_NO_DELETE: core.company rows are never deleted"}""") }
        val e = (client(f).rpc("v1_x") as ApiResult.Err).error
        assertEquals("E_NO_DELETE", e.code); assertEquals(ErrorKind.VALIDATION, e.kind)
    }

    @Test fun missingFunctionIsBackendNotReady() = runBlocking {
        val f = Fake { HttpResponse(404, """{"code":"PGRST202","message":"Could not find the function"}""") }
        assertEquals(ErrorKind.BACKEND_NOT_READY, (client(f).rpc("v1_missing") as ApiResult.Err).error.kind)
    }

    @Test fun unauthorizedRefreshesOnceThenRetries() = runBlocking {
        var n = 0
        val f = Fake { req ->
            when {
                req.url.contains("grant_type=refresh_token") -> HttpResponse(200, """{"access_token":"A2","refresh_token":"R2","expires_in":3600}""")
                req.headers["Authorization"] == "Bearer A1" -> { n++; HttpResponse(401, """{"message":"JWT expired"}""") }
                else -> HttpResponse(200, "[1,2]")
            }
        }
        val store = signedIn()
        val r = client(f, store).rpcArray("v1_list")
        assertEquals(2, (r as ApiResult.Ok).value.length()); assertEquals(1, n); assertEquals("A2", store.read()!!.accessToken)
    }

    @Test fun failedRefreshClearsSessionAndNotifies() = runBlocking {
        val f = Fake { req -> if (req.url.contains("refresh_token")) HttpResponse(400, """{"error_description":"invalid"}""") else HttpResponse(401, "{}") }
        val store = signedIn(); var lost = false
        val c = client(f, store); c.onSessionLost = { lost = true }
        val e = (c.rpc("v1_x") as ApiResult.Err).error
        assertEquals(ErrorKind.SESSION_EXPIRED, e.kind); assertTrue(lost); assertNull(store.read()); assertFalse(c.isSignedIn)
    }

    @Test fun nearExpiryTokenIsRefreshedBeforeTheCall() = runBlocking {
        val f = Fake { req -> if (req.url.contains("refresh_token")) HttpResponse(200, """{"access_token":"A2","refresh_token":"R2","expires_at":99999}""") else HttpResponse(200, "{}") }
        val store = signedIn(exp = 1_010L)
        client(f, store, now = 1_000L).rpc("v1_x")
        assertEquals("Bearer A2", f.seen.last().headers["Authorization"])
    }

    @Test fun networkAndTimeoutAreRetryableErrors() = runBlocking {
        val net = (client(Fake { throw IOException("down") }).rpc("v1_x") as ApiResult.Err).error
        assertEquals(ErrorKind.NETWORK, net.kind); assertTrue(net.retryable)
        val to = (client(Fake { throw TransportTimeout(IOException("slow")) }).rpc("v1_x") as ApiResult.Err).error
        assertEquals(ErrorKind.TIMEOUT, to.kind)
    }

    @Test fun notSignedInNeverTouchesNetwork() = runBlocking {
        val f = Fake { HttpResponse(200, "{}") }
        val r = client(f, MemoryTokenStore()).rpc("v1_x")
        assertEquals(ErrorKind.SESSION_EXPIRED, (r as ApiResult.Err).error.kind); assertTrue(f.seen.isEmpty())
    }

    @Test fun badLoginIsValidationNotServerError() = runBlocking {
        val f = Fake { HttpResponse(400, """{"error_description":"Invalid login credentials"}""") }
        val r = client(f, MemoryTokenStore()).signInWithPassword("x@y", "bad")
        assertEquals("C_INVALID_LOGIN", (r as ApiResult.Err).error.code)
    }

    @Test fun signOutClearsLocalEvenIfServerFails() = runBlocking {
        val store = signedIn()
        client(Fake { throw IOException("down") }, store).signOut()
        assertNull(store.read())
    }

    // ---------------------------------------------------------------- S16: PIN sessions through Edge Functions
    @Test fun pinSessionRefreshesThroughEdgeFunctionWithDevice() = runBlocking {
        val store = MemoryTokenStore().apply { write(SessionTokens("P1", "PR1", 1_010L, kind = "pin")) }
        val f = Fake { req ->
            if (req.url.endsWith("/functions/v1/auth-pin-refresh")) HttpResponse(200, """{"access_token":"P2","refresh_token":"PR2","expires_at":5000}""")
            else HttpResponse(200, "{}")
        }
        val c = client(f, store)
        c.deviceId = "device-aaaaaaaaaaaaaaaa"
        c.rpcObject("v1_ping")
        val refresh = f.seen.first()
        assertEquals("https://example.supabase.co/functions/v1/auth-pin-refresh", refresh.url)
        assertEquals("device-aaaaaaaaaaaaaaaa", JSONObject(refresh.body!!).getString("device_id"))
        assertEquals("P2", store.read()!!.accessToken); assertEquals("pin", store.read()!!.kind)
    }

    @Test fun pinSessionWithoutDeviceIsDropped() = runBlocking {
        val store = MemoryTokenStore().apply { write(SessionTokens("P1", "PR1", 1_010L, kind = "pin")) }
        val f = Fake { HttpResponse(200, "{}") }
        client(f, store).rpcObject("v1_ping")
        assertNull(store.read())
    }

    @Test fun edgeFunctionErrorCodeIsTyped() = runBlocking {
        val f = Fake { HttpResponse(401, """{"error":"E_AUTH_LOCKED"}""") }
        val e = (client(f).callFunction("auth-pin-login", JSONObject()) as ApiResult.Err).error
        assertEquals("E_AUTH_LOCKED", e.code)
    }

    // ---------------------------------------------------------------- S17 / OI-27: TOTP MFA on a GoTrue session
    @Test fun totpVerifyChallengesThenInstallsAal2Session() = runBlocking {
        val store = signedIn()
        val fid = "0f0e0d0c-0b0a-4908-8706-050403020100"
        val f = Fake { req ->
            when {
                req.url.endsWith("/auth/v1/factors/$fid/challenge") -> HttpResponse(200, """{"id":"ch-1"}""")
                req.url.endsWith("/auth/v1/factors/$fid/verify") -> HttpResponse(200, """{"access_token":"AAL2","refresh_token":"R2","expires_in":3600}""")
                req.url.endsWith("/auth/v1/user") -> HttpResponse(200, """{"factors":[{"id":"$fid","factor_type":"totp","status":"verified"},{"id":"x","factor_type":"totp","status":"unverified"}]}""")
                else -> HttpResponse(404, "{}")
            }
        }
        val c = client(f, store)
        assertEquals(listOf(fid), (c.mfaVerifiedTotp() as ApiResult.Ok).value)
        assertTrue(c.mfaVerify(fid, "123456") is ApiResult.Ok)
        assertEquals("AAL2", store.read()!!.accessToken)
        assertEquals("ch-1", JSONObject(f.seen.last().body!!).getString("challenge_id"))
    }

    @Test fun wrongTotpCodeIsTyped() = runBlocking {
        val fid = "0f0e0d0c-0b0a-4908-8706-050403020100"
        val f = Fake { req -> if (req.url.endsWith("/challenge")) HttpResponse(200, """{"id":"ch-1"}""") else HttpResponse(422, """{"msg":"Invalid TOTP code entered"}""") }
        val e = (client(f).mfaVerify(fid, "000000") as ApiResult.Err).error
        assertEquals("C_INVALID_MFA", e.code)
    }
}

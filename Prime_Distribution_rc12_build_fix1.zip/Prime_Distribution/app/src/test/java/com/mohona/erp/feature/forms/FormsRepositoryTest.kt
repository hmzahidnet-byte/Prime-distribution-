package com.mohona.erp.feature.forms

import com.mohona.erp.feature.forms.data.FormsRepository
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FormsRepositoryTest {
    @Test fun parsesServerShapes() {
        val l = FormsRepository.parseList(JSONArray("""[{"id":"f","code":"LEAVE","name_bn":"ছুটি","status":"active","active_version":2,"row_version":5}]"""))!!
        assertEquals(2, l[0].activeVersion)
        assertNull(FormsRepository.parseList(JSONArray("""[{"id":"f"}]""")))
        val s = FormsRepository.parseSave(JSONObject("""{"submission_id":"s","status":"submitted","row_version":3,"form_version":2,"conflict":true}"""))!!
        assertTrue(s.conflict)
        val sub = FormsRepository.parseSubmit(JSONObject("""{"submission_id":"s","status":"pending_approval","number":"LEAVE-2026-000001","request_id":null}"""))
        assertEquals("LEAVE-2026-000001", sub.number); assertNull(sub.requestId)
    }
    @Test fun rejectsUnsafeStoragePaths() {
        assertNull(FormsRepository.parseTicket(JSONObject("""{"attachment_id":"a","bucket":"forms","path":"../x","expires_in":300}""")))
        assertEquals("c/f/a.jpg", FormsRepository.parseTicket(JSONObject("""{"attachment_id":"a","bucket":"forms","path":"c/f/a.jpg","expires_in":300}"""))!!.path)
    }
}

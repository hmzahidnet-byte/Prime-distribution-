package com.mohona.erp.feature.forms

import com.mohona.erp.feature.forms.data.FormEngine
import com.mohona.erp.feature.forms.data.FormMask
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Same definition and cases as backend/supabase/tests/t_s14_forms.sql (S14-04..07): client and server must agree. */
class FormEngineTest {
    private val def = JSONObject("""{"amount_field":"days",
      "groups":[{"key":"medical","label_bn":"চিকিৎসা","visible_if":{"op":"=","field":"leave_type","value":"sick"}}],
      "fields":[
        {"key":"leave_type","type":"select","label_bn":"ধরন","required":true,"options":[{"value":"casual","label_bn":"ক"},{"value":"sick","label_bn":"খ"}]},
        {"key":"days","type":"integer","label_bn":"দিন","required":true,"min":1,"max":30},
        {"key":"start_date","type":"date","label_bn":"শুরু","required":true},
        {"key":"end_date","type":"date","label_bn":"শেষ","required":true},
        {"key":"medical_photo","type":"photo","label_bn":"সনদ","required":true,"group":"medical"},
        {"key":"nid","type":"text","label_bn":"NID","sensitive":true,"pattern":"^[0-9]{10,17}$","access":"masked"},
        {"key":"salary","type":"money","label_bn":"বেতন","min":0},
        {"key":"phone","type":"phone","label_bn":"ফোন"},
        {"key":"note","type":"textarea","label_bn":"মন্তব্য","max_length":500}],
      "checks":[{"kind":"compare","left":"end_date","op":">=","right":"start_date","message_bn":"শেষ তারিখ শুরুর আগে"},
                {"kind":"rule","condition":{"op":"<=","field":"days","value":20},"message_bn":"২০ দিনের বেশি নয়"}]}""")
    private fun gv() = JSONObject("""{"leave_type":"casual","days":3,"start_date":"2026-11-10","end_date":"2026-11-12","nid":"1234567890123","salary":25000.50,"phone":"01712345678","note":"x"}""")
    private fun has(c: com.mohona.erp.feature.forms.data.FormCheck, f: String, code: String) = c.errors.any { it.field == f && it.code == code }
    private fun field(k: String) = def.getJSONArray("fields").let { a -> (0 until a.length()).map { a.getJSONObject(it) }.first { it.getString("key") == k } }

    @Test fun validValuesPass() = assertTrue(FormEngine.check(def, gv(), partial = false).ok)

    @Test fun canonicalValuesOnly() {
        val c = FormEngine.check(def, JSONObject("""{"leave_type":"annual","days":"১২","start_date":"2026-02-30","end_date":"2026-03-01","phone":"০১৭১২৩৪৫৬৭৮","salary":10.555}"""), false)
        assertTrue(has(c, "leave_type", "option")); assertTrue(has(c, "days", "type")); assertTrue(has(c, "start_date", "type"))
        assertTrue(has(c, "phone", "pattern")); assertTrue(has(c, "salary", "type"))
    }

    @Test fun bengaliInputIsNormalised() {
        assertEquals(12L, FormEngine.normalize(field("days"), "১২"))
        assertEquals("01712345678", FormEngine.normalize(field("phone"), "+৮৮০ ১৭১২-৩৪৫৬৭৮"))
        assertEquals("2026-11-10", FormEngine.normalize(field("start_date"), "২০২৬-১১-১০"))
        assertNull(FormEngine.normalize(field("note"), "   "))
    }

    @Test fun visibilityIsDecidedLikeTheServer() {
        val sick = gv().put("leave_type", "sick")
        assertTrue(has(FormEngine.check(def, sick, false), "medical_photo", "required"))
        val hiddenSent = gv().put("medical_photo", "0f0e0d0c-0b0a-4908-8706-050403020100")
        val strip = FormEngine.check(def, hiddenSent, false)
        assertTrue(strip.ok); assertFalse(strip.values.has("medical_photo")); assertFalse("medical_photo" in strip.visible)
        assertTrue(has(FormEngine.check(def, hiddenSent, false, hiddenPolicy = "reject"), "medical_photo", "hidden"))
        assertTrue(FormEngine.check(def, JSONObject("""{"leave_type":"sick"}"""), partial = true).ok)
    }

    @Test fun validationBuilder() {
        assertTrue(has(FormEngine.check(def, gv().put("end_date", "2026-11-01"), false), "end_date", "check"))
        assertTrue(has(FormEngine.check(def, gv().put("days", 25), false), "_form", "check"))
        assertTrue(has(FormEngine.check(def, gv().put("days", 40), false), "days", "range"))
        assertTrue(has(FormEngine.check(def, gv().put("nid", "12AB"), false), "nid", "pattern"))
        assertTrue(has(FormEngine.check(def, gv().put("bogus", 1), false), "bogus", "unknown"))
    }

    @Test fun onlyWritableFieldsAreSent() {
        val sent = FormEngine.writable(def, gv())
        assertFalse(sent.has("nid")); assertTrue(sent.has("days"))
    }

    @Test fun serverValidationDetailIsParsed() {
        val e = FormEngine.parseErrors("""[{"field":"days","code":"range","message_bn":"মান অনুমোদিত সীমার বাইরে।"}]""")
        assertEquals("days", e.single().field); assertTrue(FormEngine.parseErrors("garbage").isEmpty())
    }

    @Test fun maskMatchesServer() {
        assertEquals("•••••••••0123", FormMask.render("1234567890123", "partial", 4))
        assertEquals("•••••", FormMask.render("55000", "partial", 4))
        assertEquals("••••••", FormMask.render(25000, "partial", 4))
        assertEquals("••••••", FormMask.render("1234567890123", "full", 4))
    }
}

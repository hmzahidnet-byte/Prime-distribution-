package com.mohona.erp.feature.config

import com.mohona.erp.feature.config.data.SettingsRepository
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsRepositoryTest {
    private val json = """[{"key":"iam.delegation.max_days","module":"iam","value_type":"int","name_bn":"মেয়াদ","description_bn":null,
        "default_value":30,"value":45,"is_default":false,"version":1,"min_value":1,"max_value":365,"allowed_values":null,"is_sensitive":true,"requires_aal2":false},
      {"key":"finance.rounding.mode","module":"finance","value_type":"text","name_bn":"রাউন্ডিং","default_value":"HALF_UP","value":"HALF_UP",
        "is_default":true,"version":0,"min_value":null,"max_value":null,"allowed_values":["HALF_UP","HALF_EVEN"],"is_sensitive":true,"requires_aal2":false},
      {"key":"iam.mfa.required_positions","module":"iam","value_type":"text_array","name_bn":"MFA","default_value":["CHAIRMAN","MD"],"value":["CHAIRMAN","MD"],
        "is_default":true,"version":0,"min_value":null,"max_value":null,"allowed_values":null,"is_sensitive":true,"requires_aal2":false}]"""

    @Test fun parsesTypedValues() {
        val s = SettingsRepository.parse(JSONArray(json))!!
        assertEquals(45, s[0].value); assertEquals(30, s[0].defaultValue); assertEquals(1, s[0].version)
        assertEquals(listOf("CHAIRMAN", "MD"), s[2].value); assertNull(s[0].descriptionBn)
    }
    @Test fun clientValidationMirrorsServer() {
        val s = SettingsRepository.parse(JSONArray(json))!!
        assertNull(s[0].validate(30)); assertNotNull(s[0].validate(999)); assertNotNull(s[0].validate(2.5)); assertNotNull(s[0].validate("x"))
        assertNull(s[1].validate("HALF_EVEN")); assertNotNull(s[1].validate("BANKERS"))
        assertNull(s[2].validate(listOf("CHAIRMAN"))); assertNotNull(s[2].validate(listOf(1)))
        assertTrue(SettingsRepository.toJson(listOf("A")) is JSONArray)
    }
}

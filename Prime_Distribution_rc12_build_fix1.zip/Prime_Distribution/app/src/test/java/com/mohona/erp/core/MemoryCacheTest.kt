package com.mohona.erp.core

import com.mohona.erp.core.cache.CacheScope
import com.mohona.erp.core.cache.MemoryCache
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test

class MemoryCacheTest {
    private var now = 0L
    private val a = CacheScope("P1", "C1", "POS1")
    private val otherPosition = CacheScope("P1", "C1", "POS2")
    private val otherCompany = CacheScope("P1", "C2", "POS1")

    @Test fun expiresAfterTtl() {
        val c = MemoryCache({ now }); c.put(a, "wing_list", "x", 100)
        assertEquals("x", c.get<String>(a, "wing_list")); now = 100; assertNull(c.get<String>(a, "wing_list"))
    }
    @Test fun sensitiveDataIsNeverCached() {
        val c = MemoryCache({ now })
        for (k in listOf("factory_pnl", "payroll_month", "payslip_1", "employee_salary")) assertFalse(k, c.put(a, k, "secret"))
        assertEquals(0, c.size())
    }
    @Test fun scopesNeverLeakAcrossPositionOrCompany() {
        val c = MemoryCache({ now }); c.put(a, "k", "v")
        assertNull(c.get<String>(otherPosition, "k")); assertNull(c.get<String>(otherCompany, "k"))
    }
    @Test fun invalidatePrefixAndClear() {
        val c = MemoryCache({ now }); c.put(a, "inv.stock", 1); c.put(a, "inv.lot", 2); c.put(a, "hr.x", 3)
        c.invalidate(a, "inv."); assertNull(c.get<Int>(a, "inv.stock")); assertEquals(3, c.get<Int>(a, "hr.x"))
        c.clearAll(); assertEquals(0, c.size())
    }
    @Test fun boundedSize() {
        val c = MemoryCache({ now }, maxEntries = 3); for (i in 1..5) c.put(a, "k$i", i)
        assertEquals(3, c.size()); assertNull(c.get<Int>(a, "k1"))
    }
}

package com.mohona.erp.ui

import com.mohona.erp.feature.design.data.DesignRepository
import com.mohona.erp.feature.iam.data.MyPermissions
import com.mohona.erp.feature.iam.data.PermissionScope
import com.mohona.erp.feature.iam.data.ScopeKind
import com.mohona.erp.ui.theme.IconRegistry
import com.mohona.erp.ui.theme.tokens.DesignRules
import com.mohona.erp.ui.theme.tokens.MohonaTokens
import com.mohona.erp.ui.theme.tokens.TokenCodec
import java.io.File
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Same limits as design.fn_tokens_report (t_s18_design.sql S18-03..05). */
class DesignStudioTest {
    @Test fun defaultsPublishCleanly() = assertTrue(DesignRules.publishErrors(MohonaTokens.DEFAULT).isEmpty())

    @Test fun contrastAndMoneyFitBlockPublishing() {
        val d = MohonaTokens.DEFAULT
        assertTrue(DesignRules.publishErrors(d.copy(colors = d.colors.copy(text = 0xFFBBBBBB))).any { it.startsWith("text/background") })
        assertTrue(DesignRules.publishErrors(d.copy(type = d.type.copy(headlineSp = 30f, scale = 1.3f))).contains("amounts would clip"))
        assertTrue(DesignRules.publishErrors(d.copy(type = d.type.copy(lineHeightFactor = 1.2f))).isNotEmpty())
        assertTrue(DesignRules.publishErrors(d.copy(cards = d.cards.copy(paddingDp = 4f))).isNotEmpty())
    }

    @Test fun cardsAndAccentsRoundTrip() {
        val r = TokenCodec.decode(JSONObject("""{"colors":{"roleAccent":{"MD":"#7E22CE","AUDITOR":"#FFE066"}},"cards":{"radiusDp":8,"borderDp":1}}"""))
        assertEquals(setOf("MD"), r.tokens.colors.roleAccent.keys)                // unreadable accent dropped
        assertEquals(8f, r.tokens.cards.radiusDp); assertEquals(1f, r.tokens.cards.borderDp)
        val again = TokenCodec.decode(TokenCodec.encode(r.tokens)).tokens
        assertEquals(r.tokens.cards, again.cards); assertEquals(r.tokens.colors.roleAccent, again.colors.roleAccent)
    }

    @Test fun actionIconsFollowPermissions() {
        val a = DesignRepository.parseActive(JSONObject("""{"theme":null,"icons":[
            {"target_key":"action.approve_request","icon":"Approval","permission":"approval.decide","version":1},
            {"target_key":"module.finance","icon":"AccountBalance","permission":null,"version":2}]}"""))!!
        val clerk = MyPermissions("ACCOUNTANT", false, mapOf("forms.form.read" to listOf(PermissionScope(ScopeKind.COMPANY, null))))
        assertNull(a.iconFor("action.approve_request", clerk))
        assertEquals("Approval", a.iconFor("action.approve_request", MyPermissions("CHAIRMAN", true, emptyMap())))
        assertEquals("AccountBalance", a.iconFor("module.finance", clerk)); assertEquals(2, a.icons[1].version)
    }

    @Test fun appKnowsEveryServerCatalogIcon() {
        val sql = File("../backend/supabase/migrations/20261108001700_design_studio.sql").readText()
        val seeded = Regex("""\('([A-Z][A-Za-z0-9]+)','[a-z_]+','""").findAll(sql).map { it.groupValues[1] }.toSet()
        assertTrue(seeded.size >= 40)
        assertEquals(emptySet<String>(), seeded - IconRegistry.NAMES.toSet())
    }
}

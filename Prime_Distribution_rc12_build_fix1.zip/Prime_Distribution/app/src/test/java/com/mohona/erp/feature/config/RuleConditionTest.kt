package com.mohona.erp.feature.config

import com.mohona.erp.feature.config.data.RuleCondition
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RuleConditionTest {
    private val c = JSONObject("""{"op":"and","args":[{"op":">=","field":"amount","value":100000},{"op":"in","field":"wing","value":["W1","W2"]},{"op":"not","arg":{"op":"is_null","field":"maker_position"}}]}""")

    @Test fun validatesLikeServer() {
        assertNull(RuleCondition.validate(c))
        assertNotNull(RuleCondition.validate(JSONObject("""{"op":"exec"}""")))
        assertNotNull(RuleCondition.validate(JSONObject("""{"op":">","field":"amount","value":"x"}""")))
        assertNotNull(RuleCondition.validate(JSONObject("""{"op":"=","field":"drop table","value":1}""")))
    }
    @Test fun evaluatesLikeServer() {
        assertTrue(RuleCondition.eval(c, JSONObject("""{"amount":150000,"wing":"W2","maker_position":"ACCOUNTANT"}""")))
        assertFalse(RuleCondition.eval(c, JSONObject("""{"amount":150000,"wing":"W3","maker_position":"ACCOUNTANT"}""")))
        assertFalse(RuleCondition.eval(c, JSONObject("""{"amount":150000,"wing":"W1"}""")))
        assertFalse(RuleCondition.eval(JSONObject("""{"op":">","field":"amount","value":5}"""), JSONObject("""{"amount":"9"}""")))
    }
}

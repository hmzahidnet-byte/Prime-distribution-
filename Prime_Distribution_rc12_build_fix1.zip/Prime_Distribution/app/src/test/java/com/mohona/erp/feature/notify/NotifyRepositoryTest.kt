package com.mohona.erp.feature.notify

import com.mohona.erp.feature.notify.data.NotifyRepository
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NotifyRepositoryTest {
    @Test fun parsesInboxAndBanner() {
        val n = NotifyRepository.parse(JSONArray("""[
            {"id":"1","category":"approval","priority":"high","title_bn":"অনুমোদন দরকার","body_bn":"নথি আপনার অনুমোদনের অপেক্ষায়।","link_kind":"approval_request","link_id":"r1","created_at":"2026-11-09T10:00:00Z","read":false},
            {"id":"2","title_bn":"লগইন লক হয়েছে","body_bn":"…","category":"security"}]"""))!!
        assertEquals("approval_request", n[0].linkKind); assertFalse(n[0].read)
        assertEquals("critical", n[1].priority); assertNull(n[1].linkKind)
    }

    @Test fun exportBundleChainCheck() {
        val ok = JSONObject("""{"events":[{"prev_hash":"00","row_hash":"aa"},{"prev_hash":"aa","row_hash":"bb"},{"prev_hash":"bb","row_hash":"cc"}]}""")
        val tampered = JSONObject("""{"events":[{"prev_hash":"00","row_hash":"aa"},{"prev_hash":"ff","row_hash":"bb"}]}""")
        assertTrue(NotifyRepository.chainIntact(ok)); assertFalse(NotifyRepository.chainIntact(tampered))
    }
}

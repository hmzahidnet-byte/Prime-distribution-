package com.mohona.erp.feature.structure

import com.mohona.erp.feature.structure.data.AreaCode
import com.mohona.erp.feature.structure.data.StructureRepository
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class StructureRepositoryTest {
    @Test fun areaCodes() {
        assertEquals("union", AreaCode.kind("01.02.003.001")); assertEquals("division", AreaCode.kind("08"))
        assertEquals("01.02.003", AreaCode.parent("01.02.003.001")); assertNull(AreaCode.parent("01"))
        assertEquals(listOf("01", "01.02", "01.02.003", "01.02.003.001"), AreaCode.chain("01.02.003.001"))
    }

    @Test fun treeWithDepartmentHierarchy() {
        val t = StructureRepository.parseTree(JSONObject("""{"wings":[{"id":"w","code":"W2","name_bn":"দুই","kind":"trading","status":"active","row_version":1,
            "departments":[{"id":"d2","code":"D2","name_bn":"ঢাকা","parent_id":"d1","status":"active","row_version":1},
                           {"id":"d1","code":"D1","name_bn":"বিক্রয়","parent_id":null,"status":"active","row_version":1}]}],
            "locations":[{"id":"l","code":"DEPOT1","name_bn":"ডিপো","kind":"depot","wing_id":"w","admin_area_code":"04.01.002","admin_area":"খুলনা › বাগেরহাট › কচুয়া উপজেলা","status":"active","row_version":1}],
            "warehouses":[{"id":"h","code":"WH1","name_bn":"গুদাম","kind":"raw_material","location_id":"l","status":"active","row_version":1}]}"""))!!
        assertEquals(listOf("d1" to 0, "d2" to 1), StructureRepository.departmentRows(t.wings[0]).map { it.first.id to it.second })
        assertEquals("04.01.002", t.locations[0].areaCode); assertEquals("l", t.warehouses[0].locationId)
    }
}

package com.mohona.erp.feature.stock

import com.mohona.erp.feature.stock.data.WarehouseRepository
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WarehouseRepositoryTest {
    @Test fun binQrShape() {
        val q = WarehouseRepository.parseBinQr("MOS1|B|INV|W1|B1|0123456789abcdef")!!
        assertEquals("W1", q.warehouseCode); assertEquals("B1", q.binCode)
        assertNull(WarehouseRepository.parseBinQr("MOS1|B|INV|W1|B1"))
        assertNull(WarehouseRepository.parseBinQr("MOS1|P|INV|W1|B1|0123456789abcdef"))
        assertNull(WarehouseRepository.parseBinQr("MOS1|B|INV|W1|B1|XYZ"))
    }

    @Test fun countListIsBlind() {
        val items = WarehouseRepository.parseCountList(JSONArray("""[{"lot_id":"l1","product_id":"p1","lot_no":"L1","qty":100}]"""))
        assertEquals("L1", items.single().lotNo)
        // CountItem has no quantity field at all: a leaked server quantity can never reach the counter's screen
        assertEquals(setOf("lotId", "productId", "lotNo"), items.single()::class.java.declaredFields.map { it.name }.filter { it in setOf("lotId", "productId", "lotNo", "qty") }.toSet())
    }
}

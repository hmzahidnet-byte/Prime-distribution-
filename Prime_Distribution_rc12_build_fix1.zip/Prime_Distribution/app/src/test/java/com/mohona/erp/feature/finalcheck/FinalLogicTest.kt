package com.mohona.erp.feature.finalcheck

import com.mohona.erp.feature.ops.data.LocationAge
import com.mohona.erp.feature.payroll.data.PayslipText
import com.mohona.erp.feature.print.data.PrintLines
import com.mohona.erp.feature.qr.data.MohonaQr
import com.mohona.erp.feature.report.data.ReportChart
import java.time.Instant
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FinalLogicTest {
    @Test fun qrShape() {
        assertEquals("ডিলার", MohonaQr.parse("MOS1|D|RPT|D1|0123456789abcdef")!!.typeNameBn)
        assertNotNull(MohonaQr.parse("MOS1|P|RPT|NOODLE|-"))
        assertNull(MohonaQr.parse("https://example.com/pay?to=me"))          // foreign codes are rejected before any call
        assertNull(MohonaQr.parse("MOS1|Z|RPT|x"))
        assertNull(MohonaQr.parse("MOS1|D|rpt|D1|sig"))
    }

    @Test fun payslipAndReceiptLines() {
        val p = JSONObject("""{"run":"PAY-1","period":"2026-11-01","employee":"করিম","days_employed":30,"absent_days":1,"leave_days":2,
            "earnings":[{"code":"BASE","amount":30000}],"deductions":[{"code":"PF","amount":1000}],"gross":30000,"deduction_total":1000,"net":29000,"paid":0}""")
        val lines = PayslipText.lines(p)
        assertTrue(lines.first().contains("2026-11")); assertTrue(lines.any { it.contains("29000") })
        val (title, r) = PrintLines.of("sales.receipt", JSONObject("""{"number":"RC-9","amount":500,"method":"cash","status":"recorded","unverified_banner":"যাচাই হয়নি"}"""))
        assertEquals("রসিদ RC-9", title); assertTrue(r.first().startsWith("⚠"))                // unverified receipts are flagged first
        val (_, inv) = PrintLines.of("sales.invoice", JSONObject("""{"number":"INV-1","dealer":"ক","date":"2026-11-09","due_date":"2026-12-09","lines":[],"total":100}"""))
        assertTrue(inv.none { it.contains("VAT", ignoreCase = true) || it.contains("ভ্যাট") })
    }

    @Test fun chartAndCsv() {
        val rows = JSONArray("""[{"employee":"ক","value":2},{"employee":"খ","value":4}]""")
        val bars = ReportChart.bars(rows, "employee")
        assertEquals(1f, bars[1].fraction, 0.0001f); assertEquals(0.5f, bars[0].fraction, 0.0001f)
        assertTrue(ReportChart.csv(JSONArray("""[{"a":"x\"y","b":null}]""")).contains("\"x\"\"y\","))
    }

    @Test fun staleLocationIsLabelled() {
        val now = Instant.parse("2026-11-09T10:00:00Z")
        assertEquals("৫ মিনিট আগে".replace("৫", "5"), LocationAge.label("2026-11-09T09:55:00Z", now, 15))
        assertTrue(LocationAge.label("2026-11-09T07:00:00Z", now, 15).startsWith("পুরোনো"))
        assertEquals("সময় অজানা", LocationAge.label("not-a-time", now, 15))
    }
}

package com.mohona.erp.feature.config

import com.mohona.erp.feature.config.data.ModuleAction
import com.mohona.erp.feature.config.data.ModuleStatus
import com.mohona.erp.feature.config.data.ModulesRepository
import com.mohona.erp.feature.config.data.Semver
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModulesRepositoryTest {
    private val mods = """[{"code":"master","name_bn":"মাস্টার","is_core":false,"built":true,"wing_scopable":true,"status":"suspended","version":"1.0.0",
        "wing_ids":null,"row_version":3,"depends_on":[{"module":"core","kind":"hard"}],
        "releases":[{"version":"1.0.0","compatible_from":"1.0.0","data_schema_version":1,"rollback_safe":true},
                    {"version":"1.1.0","compatible_from":"1.0.0","data_schema_version":1,"rollback_safe":true},
                    {"version":"2.0.0","compatible_from":"1.1.0","data_schema_version":2,"rollback_safe":false}]},
      {"code":"iam","name_bn":"পরিচয়","is_core":true,"built":true,"wing_scopable":false,"status":"enabled","version":"1.0.0","wing_ids":null,"row_version":1,"depends_on":[],"releases":[]}]"""

    @Test fun lifecycleActionsAndUpgradePath() {
        val m = ModulesRepository.parseModules(JSONArray(mods))!!
        assertEquals(ModuleStatus.SUSPENDED, m[0].status)
        assertEquals(listOf(ModuleAction.RESUME, ModuleAction.RETIRE), m[0].possibleActions(false))
        assertEquals(listOf("1.1.0"), m[0].upgradeTargets().map { it.version })
        assertTrue(m[1].possibleActions(true).isEmpty())
        assertTrue(Semver.parse("1.10.0") > Semver.parse("1.9.9"))
    }
    @Test fun flagsResolveWingOverrides() {
        val f = ModulesRepository.parseFlags(JSONArray("""[{"key":"inventory.fefo_picking","module":"inventory","name_bn":"FEFO","enabled":true,"default_enabled":true,
            "is_security_core":false,"version":0,"wing_overrides":[{"wing_id":"w1","enabled":false,"version":1}]},
            {"key":"iam.audit_trail","module":"iam","name_bn":"অডিট","enabled":true,"default_enabled":true,"is_security_core":true,"version":0,"wing_overrides":[]}]"""))!!
        assertFalse(f[0].enabledFor("w1")); assertTrue(f[0].enabledFor("w2")); assertTrue(f[1].enabledFor(null))
        val l = ModulesRepository.parseLauncher(JSONArray("""[{"code":"master","name_bn":"x","mode":"read_only","wing_ids":["w1"]}]"""))!!
        assertTrue(l[0].readOnly); assertEquals(listOf("w1"), l[0].wingIds)
    }
}

package com.mohona.erp.core.print

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EscPosTest {
    @Test fun startsWithInitAndEndsWithCut() {
        val b = EscPos(16).center(true).line("Mohona").center(false).pair("Total", "500").feedAndCut()
        assertEquals(0x1B.toByte(), b[0]); assertEquals(0x40.toByte(), b[1])
        assertEquals(listOf(0x1D.toByte(), 0x56.toByte(), 0x42.toByte(), 0x00.toByte()), b.takeLast(4))
        assertTrue(String(b, Charsets.UTF_8).contains("Total" + " ".repeat(8) + "500"))
    }

    @Test fun longLinesWrapInsteadOfBeingCut() {
        val text = String(EscPos(8).line("ABCDEFGHIJKL").feedAndCut(), Charsets.UTF_8)
        assertTrue(text.contains("ABCDEFGH\nIJKL\n"))
    }
}

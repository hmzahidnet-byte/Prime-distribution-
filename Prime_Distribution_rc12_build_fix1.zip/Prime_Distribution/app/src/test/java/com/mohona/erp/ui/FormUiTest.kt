package com.mohona.erp.ui

import com.mohona.erp.ui.forms.FormUi
import com.mohona.erp.ui.forms.Widget
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FormUiTest {
    private val def = JSONObject("""{"groups":[{"key":"med","label_bn":"চিকিৎসা","visible_if":{"op":"=","field":"type","value":"sick"}}],
      "fields":[{"key":"type","type":"select","label_bn":"ধরন","required":true,"options":[{"value":"casual","label_bn":"ক"},{"value":"sick","label_bn":"খ"}]},
                {"key":"photo","type":"photo","label_bn":"সনদ","group":"med","required":true},
                {"key":"days","type":"integer","label_bn":"দিন"},{"key":"amount","type":"money","label_bn":"টাকা"},
                {"key":"nid","type":"text","label_bn":"NID","access":"masked"}]}""")

    @Test fun visibilityAndAccess() {
        val casual = FormUi.visibleFields(def, JSONObject().put("type", "casual")).map { it.key }
        assertEquals(listOf("type", "days", "amount", "nid"), casual)
        val sick = FormUi.visibleFields(def, JSONObject().put("type", "sick"))
        assertTrue(sick.any { it.key == "photo" && it.widget == Widget.ATTACHMENT })
        assertFalse(sick.first { it.key == "nid" }.editable)
    }

    @Test fun inputNormalisationKeepsTyping() {
        val f = def.getJSONArray("fields").getJSONObject(2)
        assertEquals(12L, FormUi.withValue(JSONObject(), f, "১২").get("days"))
        val m = def.getJSONArray("fields").getJSONObject(3)
        val typing = FormUi.withValue(JSONObject(), m, "12.")
        assertEquals("12.", typing.get("amount"))                                   // still typing
        assertEquals("12", FormUi.display(FormUi.finalize(def, typing).get("amount")))
        assertFalse(FormUi.withValue(JSONObject().put("days", 3), f, "").has("days"))
    }
}

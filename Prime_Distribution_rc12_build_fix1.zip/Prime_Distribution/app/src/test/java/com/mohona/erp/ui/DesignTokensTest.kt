package com.mohona.erp.ui

import com.mohona.erp.core.arch.DiagnosticsLog
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.ui.theme.tokens.Contrast
import com.mohona.erp.ui.theme.tokens.Density
import com.mohona.erp.ui.theme.tokens.MohonaTokens
import com.mohona.erp.ui.theme.tokens.TokenCodec
import com.mohona.erp.ui.theme.tokens.TokenSource
import java.io.File
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DesignTokensTest {
    private val d = MohonaTokens.DEFAULT

    @Test fun defaultsMeetAccessibilityFloors() {
        assertTrue(Contrast.ratio(d.colors.text, d.colors.background) >= TokenCodec.MIN_TEXT)
        assertTrue(Contrast.ratio(d.colors.textMuted, d.colors.background) >= TokenCodec.MIN_MUTED)
        assertTrue(Contrast.ratio(d.colors.onPrimary, d.colors.primary) >= TokenCodec.MIN_ON_PRIMARY)
        assertEquals(0xFF1456A0, d.colors.primary)
    }
    @Test fun validChairmanThemeIsApplied() {
        val r = TokenCodec.decode(JSONObject("""{"revision":3,"colors":{"primary":"#1456A0","chart":["#111111","#222222","#333333"]},"type":{"scale":1.2},"spacing":{"density":"COMPACT"}}"""))
        assertTrue(r.problems.toString(), r.problems.isEmpty())
        assertEquals(0xFF1456A0, r.tokens.colors.primary); assertEquals(3, r.tokens.colors.chart.size)
        assertEquals(1.2f, r.tokens.type.scale, 0.0001f); assertEquals(Density.COMPACT, r.tokens.spacing.density)
        assertEquals(3, r.tokens.revision); assertEquals(TokenSource.PUBLISHED, r.tokens.source)
    }
    @Test fun badValuesFallBackPerFieldAndAreReported() {
        val r = TokenCodec.decode(JSONObject("""{"colors":{"primary":"orange","good":"#80FF0000"},"type":{"scale":3.0},"spacing":{"density":"HUGE"}}"""))
        assertEquals(d.colors.primary, r.tokens.colors.primary); assertEquals(d.colors.good, r.tokens.colors.good)
        assertEquals(d.type.scale, r.tokens.type.scale, 0.0001f); assertEquals(d.spacing.density, r.tokens.spacing.density)
        assertEquals(4, r.problems.size)
    }
    @Test fun unreadableContrastIsRefused() {
        val r = TokenCodec.decode(JSONObject("""{"colors":{"text":"#FAFAFA","primary":"#FFFF00"}}"""))
        assertEquals(d.colors.text, r.tokens.colors.text); assertEquals(d.colors.primary, r.tokens.colors.primary)
        assertTrue(r.problems.any { it.contains("text/background") }); assertTrue(r.problems.any { it.contains("onPrimary/primary") })
    }
    @Test fun shortChartPaletteRejected() {
        val r = TokenCodec.decode(JSONObject("""{"colors":{"chart":["#123456"]}}"""))
        assertEquals(d.colors.chart, r.tokens.colors.chart)
    }
    @Test fun encodeDecodeRoundTrip() {
        val t = d.copy(revision = 7)
        val r = TokenCodec.decode(TokenCodec.encode(t))
        assertTrue(r.problems.isEmpty()); assertEquals(t.copy(source = TokenSource.PUBLISHED), r.tokens)
    }
    @Test fun noScreenHardCodesAColour() {
        val bad = File("src/main/java/com/mohona/erp/ui/screens").listFiles()!!.filter { Regex("Color\\(0x").containsMatchIn(it.readText()) }.map { it.name }
        assertTrue("hard-coded colours in $bad", bad.isEmpty())
    }
    @Test fun diagnosticsLogIsBoundedAndHoldsNoSecrets() {
        DiagnosticsLog.clear()
        repeat(60) { DiagnosticsLog.record(ErrorCatalog.network().copy(requestId = "r$it")) }
        val items = DiagnosticsLog.recent()
        assertEquals(50, items.size); assertEquals("r59", items.first().requestId)
    }
}

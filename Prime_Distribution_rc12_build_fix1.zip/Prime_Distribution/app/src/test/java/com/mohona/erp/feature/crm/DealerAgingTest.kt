package com.mohona.erp.feature.crm

import com.mohona.erp.feature.crm.data.DealerAging
import java.math.BigDecimal
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Test

/** Same FIFO rule as api.v1_dealer_statement (t_s40_crm.sql S40-09). */
class DealerAgingTest {
    private val today = LocalDate.of(2026, 11, 9)

    @Test fun creditsSettleOldestFirst() {
        val e = listOf(DealerAging.Entry(today.minusDays(100), BigDecimal(10000), null), DealerAging.Entry(today.minusDays(40), BigDecimal(5000), null),
                       DealerAging.Entry(today.minusDays(5), BigDecimal(-12000), null), DealerAging.Entry(today, BigDecimal(2000), null))
        val b = DealerAging.buckets(e, 30, today)
        assertEquals(0, BigDecimal.ZERO.compareTo(b.getValue("d61_90")))      // the 100-day invoice is fully paid
        assertEquals(0, BigDecimal(3000).compareTo(b.getValue("d1_30")))       // 5000 − remaining 2000 credit, 10 days late
        assertEquals(0, BigDecimal(2000).compareTo(b.getValue("current")))     // today's invoice, due in 30 days
    }

    @Test fun statementScenario() {
        val e = listOf(DealerAging.Entry(today, BigDecimal(20000), today), DealerAging.Entry(today, BigDecimal(-500), null), DealerAging.Entry(today, BigDecimal(-3000), null))
        assertEquals(0, BigDecimal(16500).compareTo(DealerAging.buckets(e, 30, today).getValue("current")))
    }
}

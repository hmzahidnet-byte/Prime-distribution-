package com.mohona.erp.feature.config

import com.mohona.erp.feature.config.data.ApprovalRepository
import com.mohona.erp.feature.config.data.RequestState
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ApprovalRepositoryTest {
    @Test fun inboxAndRequestStates() {
        val l = ApprovalRepository.parseInbox(JSONArray("""[{"id":"r","document_type":"procurement.po","document_id":"d","amount":250000,"maker_name_bn":"ক","required_approvals":2,"approvals":1,"row_version":3}]"""))!!
        assertEquals(2, l[0].required); assertEquals(1, l[0].approvals); assertEquals(250000.0, l[0].amount, 0.0)
        assertEquals(RequestState.SUCCEEDED, ApprovalRepository.stateOf("succeeded")); assertEquals(RequestState.UNKNOWN, ApprovalRepository.stateOf("x"))
        assertNull(ApprovalRepository.parseInbox(JSONArray("""[{"id":"r"}]""")))
    }
}

package com.mohona.erp.feature.product

import com.mohona.erp.feature.product.data.PackMath
import com.mohona.erp.feature.product.data.PackSpec
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

/** Same numbers as t_s24_product.sql S24-08. */
class PackMathTest {
    private val spec = PackSpec(12, BigDecimal("25.5"), 20)

    @Test fun conversionsThroughTheSpec() {
        assertEquals(0, BigDecimal(24).compareTo(PackMath.convert(BigDecimal(2), "poly", "sachet", spec)))
        assertEquals(0, BigDecimal(240).compareTo(PackMath.convert(BigDecimal.ONE, "carton", "sachet", spec)))
        assertEquals(0, BigDecimal(306).compareTo(PackMath.convert(BigDecimal.ONE, "poly", "g", spec)))
        assertEquals(0, BigDecimal("2.5").compareTo(PackMath.convert(BigDecimal(2500), "g", "kg", null)))
    }

    @Test fun pcsIsNeverGuessed() {
        assertThrows(PackMath.Ambiguous::class.java) { PackMath.convert(BigDecimal(5), "pcs", "poly", spec) }
        assertThrows(PackMath.Ambiguous::class.java) { PackMath.convert(BigDecimal(5), "poly", "sachet", null) }
        assertThrows(PackMath.Ambiguous::class.java) { PackMath.convert(BigDecimal(1), "carton", "poly", PackSpec(12, BigDecimal(25), null)) }
    }

    @Test fun qrPayload() {
        val q = PackMath.parseQr("MOS1|P|PRD|NOODLE-50|V1")!!
        assertEquals("NOODLE-50", q.sku); assertEquals("V1", q.variantCode)
        assertNull(PackMath.parseQr("MOS1|P|PRD|NOODLE-50")); assertNull(PackMath.parseQr("MOS1|P|PRD|X|-")!!.variantCode)
    }
}

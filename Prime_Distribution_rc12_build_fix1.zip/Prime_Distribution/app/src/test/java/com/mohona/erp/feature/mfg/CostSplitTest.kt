package com.mohona.erp.feature.mfg

import com.mohona.erp.feature.mfg.data.CostSplit
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Test

/** Same numbers as t_s32_mfg.sql S32-10 / S32-11 (ADR-11). */
class CostSplitTest {
    @Test fun remainderOnTheLastPoly() {
        val s = CostSplit.split(BigDecimal("12350"), 1950, BigDecimal(2000), false)
        assertEquals(BigDecimal("6.3333"), s.unitCost); assertEquals(0, BigDecimal("6.3983").compareTo(s.lastCost))
        assertEquals(0, BigDecimal("12350").compareTo(s.unitCost.multiply(BigDecimal(1949)) + s.lastCost))
        assertEquals(0, BigDecimal.ZERO.compareTo(s.variance))
    }

    @Test fun approvedLowYieldVariance() {
        val s = CostSplit.split(BigDecimal("2750"), 400, BigDecimal(500), true)
        assertEquals(0, BigDecimal("2200").compareTo(s.capitalised)); assertEquals(0, BigDecimal("550").compareTo(s.variance))
        assertEquals(BigDecimal("80.00"), CostSplit.yieldPct(BigDecimal(400), BigDecimal(500)))
    }
}

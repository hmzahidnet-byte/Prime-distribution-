package com.mohona.erp.core

import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.ErrorKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ErrorCatalogTest {
    @Test fun knownCodeMapsToBengaliAndKeepsDetail() {
        val e = ErrorCatalog.fromServerMessage("E_IMMUTABLE: company id/code cannot change", 400, "rq")!!
        assertEquals("E_IMMUTABLE", e.code); assertEquals(ErrorKind.VALIDATION, e.kind)
        assertEquals("company id/code cannot change", e.detail); assertEquals("rq", e.requestId)
        assertTrue(e.messageBn.isNotBlank())
    }
    @Test fun unknownEcodeIsStillTypedNeverRawText() {
        val e = ErrorCatalog.fromServerMessage("E_SOMETHING_NEW", 400, null)!!
        assertEquals("E_SOMETHING_NEW", e.code); assertEquals(ErrorKind.SERVER, e.kind)
        assertTrue(e.messageBn.contains("E_SOMETHING_NEW"))
    }
    @Test fun nonCodeMessageIsNotParsed() {
        assertNull(ErrorCatalog.fromServerMessage("duplicate key value violates unique constraint", 409, null))
        assertNull(ErrorCatalog.fromServerMessage(null, 500, null))
    }
    @Test fun serverCodesUsedByMigrationsAreAllKnown() {
        for (c in listOf("E_IMMUTABLE", "E_NO_DELETE", "E_APPEND_ONLY", "E_DEPARTMENT_CYCLE", "E_DEPARTMENT_DEPTH", "E_COMPANY_CLOSED", "E_INTERNAL"))
            assertTrue(c, ErrorCatalog.knows(c))
    }
    @Test fun httpFallbacks() {
        assertEquals(ErrorKind.SESSION_EXPIRED, ErrorCatalog.fromHttp(401, null, null).kind)
        assertEquals(ErrorKind.FORBIDDEN, ErrorCatalog.fromHttp(403, null, null).kind)
        assertEquals(ErrorKind.CONFLICT, ErrorCatalog.fromHttp(409, null, null).kind)
        assertTrue(ErrorCatalog.fromHttp(503, null, null).retryable)
        assertTrue(ErrorCatalog.network().retryable); assertTrue(ErrorCatalog.timeout().retryable)
    }
}

package com.mohona.erp.feature.iam

import com.mohona.erp.feature.iam.data.MyPermissions
import com.mohona.erp.feature.iam.data.PermissionRepository
import com.mohona.erp.feature.iam.data.ScopeKind
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionRepositoryTest {
    @Test fun scopedHintsAreRespected() {
        val m = PermissionRepository.parseMine(JSONObject("""{"position_code":"WING_HEAD","is_supreme":false,"permissions":[
            {"code":"iam.assignment.manage","scopes":[{"kind":"WING","id":"w1"}]},{"code":"core.structure.read","scopes":[{"kind":"COMPANY","id":null}]}]}"""))!!
        assertTrue(m.hasForWing("iam.assignment.manage", "w1")); assertFalse(m.hasForWing("iam.assignment.manage", "w2"))
        assertFalse(m.hasCompanyWide("iam.assignment.manage")); assertTrue(m.hasCompanyWide("core.structure.read"))
        assertFalse(m.has("audit.read"))
    }
    @Test fun supremeHasEverythingAndNoneHasNothing() {
        val m = MyPermissions("CHAIRMAN", true, emptyMap())
        assertTrue(m.has("anything.at.all")); assertTrue(m.hasForWing("x.y", "w"))
        assertFalse(MyPermissions.NONE.has("iam.self.read"))
    }
    @Test fun catalogAndRulesParse() {
        val c = PermissionRepository.parseCatalog(JSONArray("""[{"code":"audit.read","module":"audit","name_bn":"অডিট","action_kind":"read","is_sensitive":true,
            "is_delegable":false,"requires_aal2":false,"allowed_scopes":["COMPANY"],"status":"active"}]"""))!!
        assertEquals(listOf(ScopeKind.COMPANY), c[0].allowedScopes); assertTrue(c[0].active)
        val r = PermissionRepository.parseRules(JSONArray("""[{"id":"r1","permission_code":"audit.read","effect":"deny","scope_kind":"COMPANY","scope_id":null,"origin":"chairman","reason":"x"}]"""))!!
        assertEquals("deny", r[0].effect); assertNull(r[0].scopeId)
        assertNull(PermissionRepository.parseRules(JSONArray("""[{"id":"r1"}]""")))
    }
}

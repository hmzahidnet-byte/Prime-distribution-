package com.mohona.erp.feature.finance

import com.mohona.erp.feature.finance.data.Money
import java.math.BigDecimal
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** ADR-09: NUMERIC, BDT 2 decimals half-up by default; journals always balance. */
class MoneyTest {
    @Test fun roundingModes() {
        assertEquals(BigDecimal("2.35"), Money.round(BigDecimal("2.345")))
        assertEquals(BigDecimal("2.34"), Money.round(BigDecimal("2.345"), 2, "HALF_EVEN"))
        assertEquals(BigDecimal("2.35"), Money.round(BigDecimal("2.341"), 2, "UP"))
        assertEquals(BigDecimal("2.34"), Money.round(BigDecimal("2.349"), 2, "DOWN"))
    }

    @Test fun balancedJournal() {
        assertTrue(Money.balanced(listOf(Money.Line("5500", BigDecimal("100.00"), BigDecimal.ZERO), Money.Line("1100", BigDecimal.ZERO, BigDecimal("100")))))
        assertFalse(Money.balanced(listOf(Money.Line("5500", BigDecimal("100.01"), BigDecimal.ZERO), Money.Line("1100", BigDecimal.ZERO, BigDecimal("100")))))
        assertFalse(Money.balanced(listOf(Money.Line("5500", BigDecimal.ONE, BigDecimal.ONE))))
        assertFalse(Money.balanced(emptyList()))
    }
}

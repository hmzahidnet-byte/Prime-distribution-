package com.mohona.erp.feature.recycle

import com.mohona.erp.feature.recycle.data.RecycleRepository
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RecycleRepositoryTest {
    @Test fun maskedEntriesCarryNoDetail() {
        val items = RecycleRepository.parseItems(JSONArray("""[
            {"id":"a","class_code":"forms.draft","label_bn":"নোট — খসড়া","status":"in_bin","deleted_at":"2026-11-08T10:00:00Z","purge_after":"2027-02-06","conflict":null,"on_hold":false,"masked":false},
            {"id":"b","class_code":"forms.draft","label_bn":"[গোপন]","status":"in_bin","deleted_at":"2026-11-08","purge_after":"2027-02-06","conflict":"parent_archived","on_hold":true,"masked":true}]"""))!!
        assertNull(items[0].conflict); assertTrue(items[1].masked); assertEquals("parent_archived", items[1].conflict); assertTrue(items[1].onHold)
    }

    @Test fun bulkReportsEveryDenial() {
        val b = RecycleRepository.parseBulk(JSONObject("""{"restored":[],"denied":[{"item_id":"x","reason":"forbidden"},{"item_id":"y","reason":"legal_hold"}],"status":"nothing_restored"}"""))
        assertFalse(b.allRestored); assertEquals(2, b.denied.size)
        assertTrue(RecycleRepository.parseBulk(JSONObject("""{"restored":["a","b"],"denied":[]}""")).allRestored)
        assertEquals("আইনি স্থগিতাদেশে আটকে আছে", RecycleRepository.reasonBn("legal_hold"))
    }
}

package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.structure.data.Area
import com.mohona.erp.feature.structure.data.StructureRepository
import com.mohona.erp.feature.structure.data.StructureTree
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.theme.TextMuted

/** Company structure (S23): wings with their department tree, locations (area path), warehouses; area lookup. */
@Composable
fun StructureScreen(onBack: () -> Unit) {
    var tree by remember { mutableStateOf<StructureTree?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        when (val r = AppContainer.structure?.tree()) { is ApiResult.Ok -> tree = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("কোম্পানি-কাঠামো", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            tree?.let { t ->
                SectionTitle("উইং ও বিভাগ")
                t.wings.forEach { w ->
                    AppCard {
                        Column(Modifier.padding(12.dp)) {
                            Text(w.nameBn + " (" + w.code + ")" + if (!w.active) " — নিষ্ক্রিয়" else "", style = MaterialTheme.typography.titleSmall)
                            StructureRepository.departmentRows(w).forEach { (d, depth) ->
                                Text("  ".repeat(depth + 1) + "• " + d.nameBn, style = MaterialTheme.typography.bodySmall, color = if (d.active) androidx.compose.ui.graphics.Color.Unspecified else TextMuted)
                            }
                        }
                    }
                }
                SectionTitle("অবস্থান")
                t.locations.forEach { l -> Text(l.nameBn + " · " + (l.areaPath ?: "এলাকা নির্ধারিত নয়"), style = MaterialTheme.typography.bodySmall) }
                SectionTitle("গুদাম")
                t.warehouses.forEach { h -> Text(h.nameBn + " (" + h.code + ") · " + h.kind, style = MaterialTheme.typography.bodySmall) }
            }
            SectionTitle("প্রশাসনিক এলাকা")
            AreaPicker { message = it.path ?: it.nameBn }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

/** Division -> district -> upazila -> union picker with search; returns the chosen area. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AreaPicker(onPick: (Area) -> Unit) {
    var parent by remember { mutableStateOf<Area?>(null) }
    var items by remember { mutableStateOf<List<Area>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    LaunchedEffect(parent, query) {
        val repo = AppContainer.structure ?: return@LaunchedEffect
        val r = if (query.length >= 2) repo.areaSearch(query) else repo.areaChildren(parent?.code)
        if (r is ApiResult.Ok) items = r.value
    }
    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("খুঁজুন (যেমন: কচুয়া)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    parent?.let { p -> FilterChip(selected = true, onClick = { parent = null; query = "" }, label = { Text("← " + p.nameBn) }) }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { a ->
            FilterChip(selected = false, onClick = { onPick(a); if (a.kind != "union") { parent = a; query = "" } }, label = { Text(a.nameBn) })
        }
    }
}

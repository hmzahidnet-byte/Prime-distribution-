package com.mohona.erp.core.shell

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import com.mohona.erp.feature.iam.data.MyPermissions
import org.json.JSONObject

/** What the app frame needs for the current position (api.v1_ui_config, S17). Hints only — the server re-authorises. */
data class UiConfig(
    val tabs: List<String>, val themePrimary: String?, val modules: Set<String>, val flags: Map<String, Boolean>,
    val mfaPositions: Set<String>, val draftTtlDays: Long, val maxDrafts: Int
) {
    fun flag(key: String): Boolean = flags[key] == true
    companion object {
        val DEFAULT = UiConfig(ShellTabs.DEFAULT, null, emptySet(), emptyMap(), setOf("CHAIRMAN", "MD"), 14, 50)

        fun parse(o: JSONObject): UiConfig? = try {
            val tabs = o.optJSONArray("tabs")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: ShellTabs.DEFAULT
            val mods = o.optJSONArray("modules")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: emptySet()
            val f = o.optJSONObject("flags")
            val flags = f?.keys()?.asSequence()?.associateWith { f.optBoolean(it, false) } ?: emptyMap()
            val mfa = o.optJSONArray("mfa_positions")?.let { a -> (0 until a.length()).map { a.getString(it) }.toSet() } ?: setOf("CHAIRMAN")
            val off = o.optJSONObject("offline")
            UiConfig(tabs, o.optString("theme_primary").takeIf { it.startsWith("#") }, mods, flags, mfa,
                off?.optLong("draft_ttl_days", 14) ?: 14, off?.optInt("max_drafts", 50) ?: 50)
        } catch (e: Exception) { null }
    }
}

class ShellRepository(private val client: SupabaseClient) {
    suspend fun load(): ApiResult<UiConfig> = when (val r = client.rpcObject("v1_ui_config")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> UiConfig.parse(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_ui_config"))
    }
}

/** One bottom tab. [permission] = hint: the tab is hidden when the position clearly lacks it. [module] = must be enabled. */
data class TabSpec(val key: String, val route: String, val labelBn: String, val permission: String? = null, val module: String? = null)

/**
 * Setting-driven bottom navigation (ui.nav.bottom_tabs). Rules: known keys only, no duplicates, "home" first, at most
 * five tabs, and "more" (profile: sign-out, settings, diagnostics) always present and last — nobody can configure
 * themselves out of signing out.
 */
object ShellTabs {
    val DEFAULT = listOf("home", "tasks", "reports", "more")
    const val MAX = 5

    val CATALOG: Map<String, TabSpec> = linkedMapOf(
        "home" to TabSpec("home", "home", "হোম"),
        "tasks" to TabSpec("tasks", "approvals", "কাজ", permission = "approval.inbox.read", module = "approval"),
        "reports" to TabSpec("reports", "reports", "রিপোর্ট"),
        "search" to TabSpec("search", "search", "অনুসন্ধান"),
        "scan" to TabSpec("scan", "scan", "স্ক্যান"),
        "forms" to TabSpec("forms", "forms", "ফর্ম", permission = "forms.form.read", module = "forms"),
        "dashboard" to TabSpec("dashboard", "dashboard", "ড্যাশবোর্ড", permission = "kpi.dashboard.read", module = "kpi"),
        "more" to TabSpec("more", "profile", "আরও")
    )

    /** [perms] null = Preview (no hints applied); [modules] empty = unknown (no module filter). */
    fun resolve(configured: List<String>?, perms: MyPermissions?, modules: Set<String> = emptySet()): List<TabSpec> {
        val keys = (configured?.takeIf { it.isNotEmpty() } ?: DEFAULT).map { it.trim().lowercase() }.distinct().filter { it in CATALOG }
        val ordered = listOf("home") + keys.filter { it != "home" && it != "more" }
        val allowed = ordered.mapNotNull { CATALOG[it] }.filter { t ->
            (perms == null || t.permission == null || perms.has(t.permission)) &&
                (modules.isEmpty() || t.module == null || t.module in modules)
        }
        return allowed.take(MAX - 1) + CATALOG.getValue("more")
    }
}

package com.mohona.erp.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs

/** Bangla digit and Taka formatting helpers. */
object Bn {
    private val digitMap = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun digits(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            if (c in '0'..'9') sb.append(digitMap[c - '0']) else sb.append(c)
        }
        return sb.toString()
    }

    /** South-Asian grouping: 12,34,567 */
    fun num(n: Long): String {
        val neg = n < 0
        val s = abs(n).toString()
        val grouped: String = if (s.length <= 3) {
            s
        } else {
            val last3 = s.takeLast(3)
            var rest = s.dropLast(3)
            val parts = ArrayList<String>()
            while (rest.length > 2) {
                parts.add(0, rest.takeLast(2))
                rest = rest.dropLast(2)
            }
            if (rest.isNotEmpty()) parts.add(0, rest)
            parts.joinToString(",") + "," + last3
        }
        return digits((if (neg) "-" else "") + grouped)
    }

    fun dec(d: Double, places: Int = 1): String =
        digits(String.format(Locale.US, "%." + places + "f", d))

    fun taka(n: Long): String = "৳ " + num(n)

    /**
     * Owner decision (14 Nov 2026): money is taka + paisa, always two decimals, South-Asian grouping, Bengali digits.
     * 112950.66 -> "৳ ১,১২,৯৫০.৬৬". Same rule as core.fn_taka_bn on the server.
     */
    fun money(v: BigDecimal?): String {
        if (v == null) return "—"
        val r = v.setScale(2, RoundingMode.HALF_UP)
        val whole = r.abs().toBigInteger()
        val paisa = r.abs().subtract(BigDecimal(whole)).movePointRight(2).toInt()
        val g = num(whole.toLong()).removePrefix("-")
        return (if (r.signum() < 0) "-" else "") + "৳ " + g + "." + digits(paisa.toString().padStart(2, '0'))
    }

    /** Server values arrive as JSON text; anything unparsable is shown as it came (never invented). */
    fun money(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return "—"
        return raw.trim().toBigDecimalOrNull()?.let { money(it) } ?: raw
    }

    private val W0_99 = arrayOf(
        "শূন্য", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়",
        "দশ", "এগারো", "বারো", "তেরো", "চৌদ্দ", "পনেরো", "ষোলো", "সতেরো", "আঠারো", "উনিশ",
        "বিশ", "একুশ", "বাইশ", "তেইশ", "চব্বিশ", "পঁচিশ", "ছাব্বিশ", "সাতাশ", "আঠাশ", "ঊনত্রিশ",
        "ত্রিশ", "একত্রিশ", "বত্রিশ", "তেত্রিশ", "চৌত্রিশ", "পঁয়ত্রিশ", "ছত্রিশ", "সাঁইত্রিশ", "আটত্রিশ", "ঊনচল্লিশ",
        "চল্লিশ", "একচল্লিশ", "বিয়াল্লিশ", "তেতাল্লিশ", "চুয়াল্লিশ", "পঁয়তাল্লিশ", "ছেচল্লিশ", "সাতচল্লিশ", "আটচল্লিশ", "ঊনপঞ্চাশ",
        "পঞ্চাশ", "একান্ন", "বায়ান্ন", "তিপ্পান্ন", "চুয়ান্ন", "পঞ্চান্ন", "ছাপ্পান্ন", "সাতান্ন", "আটান্ন", "ঊনষাট",
        "ষাট", "একষট্টি", "বাষট্টি", "তেষট্টি", "চৌষট্টি", "পঁয়ষট্টি", "ছেষট্টি", "সাতষট্টি", "আটষট্টি", "ঊনসত্তর",
        "সত্তর", "একাত্তর", "বাহাত্তর", "তিয়াত্তর", "চুয়াত্তর", "পঁচাত্তর", "ছিয়াত্তর", "সাতাত্তর", "আটাত্তর", "ঊনআশি",
        "আশি", "একাশি", "বিরাশি", "তিরাশি", "চুরাশি", "পঁচাশি", "ছিয়াশি", "সাতাশি", "আটাশি", "ঊননব্বই",
        "নব্বই", "একানব্বই", "বিরানব্বই", "তিরানব্বই", "চুরানব্বই", "পঁচানব্বই", "ছিয়ানব্বই", "সাতানব্বই", "আটানব্বই", "নিরানব্বই")

    /** Whole number in কোটি / লক্ষ / হাজার / শত (crore above 99 recurses). Same as core.fn_bn_words_int. */
    fun words(n: Long): String {
        require(n >= 0)
        if (n == 0L) return "শূন্য"
        val parts = ArrayList<String>()
        var r = n
        val crore = r / 10_000_000; r %= 10_000_000
        if (crore > 0) parts += words(crore) + " কোটি"
        val lakh = (r / 100_000).toInt(); r %= 100_000
        if (lakh > 0) parts += W0_99[lakh] + " লক্ষ"
        val th = (r / 1000).toInt(); r %= 1000
        if (th > 0) parts += W0_99[th] + " হাজার"
        val h = (r / 100).toInt(); val s = (r % 100).toInt()
        if (h > 0) parts += W0_99[h] + " শত"
        if (s > 0) parts += W0_99[s]
        return parts.joinToString(" ")
    }

    /** 112950.66 -> "এক লক্ষ বারো হাজার নয় শত পঞ্চাশ টাকা ছেষট্টি পয়সা মাত্র" (same as core.fn_taka_words_bn). */
    fun takaWords(v: BigDecimal): String {
        val r = v.setScale(2, RoundingMode.HALF_UP)
        val a = r.abs()
        val whole = a.toBigInteger().toLong()
        val paisa = a.subtract(BigDecimal(whole)).movePointRight(2).toInt()
        val core = words(whole) + " টাকা" + (if (paisa > 0) " " + W0_99[paisa] + " পয়সা" else "")
        return (if (r.signum() < 0) "ঋণাত্মক " else "") + core + " মাত্র"
    }
}

package com.mohona.erp.feature.kpi.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.math.RoundingMode
import org.json.JSONArray
import org.json.JSONObject

data class KpiStyle(val chart: String = "number", val size: String = "m", val shape: String = "card", val color: String = "primary")
data class KpiValue(val code: String, val nameBn: String, val unit: String?, val value: BigDecimal?, val previous: BigDecimal?, val restricted: Boolean,
                    val cached: Boolean, val refreshSeconds: Int, val hasProducts: Boolean, val style: KpiStyle, val formulaBn: String?)
data class KpiQuery(val period: String = "today", val from: String? = null, val to: String? = null, val wingId: String? = null) {
    fun key(code: String) = "$code|$period|$from|$to|$wingId"
}

/** KPI dashboard (S20). Restricted KPIs arrive as restricted=true without a number; the app never guesses one. */
class KpiRepository(private val client: SupabaseClient) {
    private fun q(o: JSONObject, k: KpiQuery) = o.put("p_period", k.period).put("p_from", k.from ?: JSONObject.NULL).put("p_to", k.to ?: JSONObject.NULL)
        .put("p_wing", k.wingId ?: JSONObject.NULL)

    suspend fun catalog(): ApiResult<JSONArray> = client.rpcArray("v1_kpi_catalog")
    suspend fun values(codes: List<String>, k: KpiQuery): ApiResult<List<KpiValue>> =
        when (val r = client.rpcArray("v1_kpi_values", q(JSONObject().put("p_codes", JSONArray(codes)), k))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseValues(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_kpi_values"))
        }
    /** Points for line / bar / sparkline charts (api.v1_kpi_series, <= 36 points). */
    suspend fun series(code: String, grain: String, from: String?, to: String?, wingId: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_kpi_series", JSONObject().put("p_code", code).put("p_grain", grain).put("p_from", from ?: JSONObject.NULL)
            .put("p_to", to ?: JSONObject.NULL).put("p_wing", wingId ?: JSONObject.NULL))
    /** Values by territory / dealer / product / warehouse / account for donut and bar charts (api.v1_kpi_split). */
    suspend fun split(code: String, by: String, from: String?, to: String?, limit: Int = 12): ApiResult<JSONObject> =
        client.rpcObject("v1_kpi_split", JSONObject().put("p_code", code).put("p_by", by).put("p_from", from ?: JSONObject.NULL)
            .put("p_to", to ?: JSONObject.NULL).put("p_limit", limit))
    suspend fun breakdown(code: String, k: KpiQuery): ApiResult<JSONArray> = client.rpcArray("v1_kpi_breakdown", q(JSONObject().put("p_code", code), k))
    suspend fun drilldown(code: String, k: KpiQuery, limit: Int = 50): ApiResult<JSONArray> =
        client.rpcArray("v1_kpi_drilldown", q(JSONObject().put("p_code", code), k).put("p_limit", limit))
    suspend fun export(codes: List<String>, k: KpiQuery, format: String): ApiResult<JSONObject> =
        client.rpcObject("v1_kpi_export", q(JSONObject().put("p_codes", JSONArray(codes)), k).put("p_format", format))
    suspend fun recordValue(code: String, dateIso: String, value: BigDecimal, wingId: String?, product: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_kpi_record_value", JSONObject().put("p_code", code).put("p_date", dateIso).put("p_value", value).put("p_wing", wingId ?: JSONObject.NULL)
            .put("p_product", product ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun setVisibility(code: String, position: String?, visible: Boolean, expectedVersion: Int, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_kpi_set_visibility", JSONObject().put("p_code", code).put("p_position_code", position ?: JSONObject.NULL).put("p_visible", visible)
            .put("p_expected_version", expectedVersion).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun setStyle(code: String, style: KpiStyle, expectedVersion: Int, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_kpi_set_style", JSONObject().put("p_code", code).put("p_style", JSONObject().put("chart", style.chart).put("size", style.size)
            .put("shape", style.shape).put("color", style.color)).put("p_expected_version", expectedVersion).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun closePeriod(monthIso: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_kpi_close_period", JSONObject().put("p_month", monthIso).put("p_reason", reason), write = true, idempotencyKey = key)

    companion object {
        private fun dec(o: JSONObject, k: String): BigDecimal? = if (!o.has(k) || o.isNull(k)) null else runCatching { BigDecimal(o.get(k).toString()) }.getOrNull()

        fun parseStyle(o: JSONObject?) = if (o == null) KpiStyle() else
            KpiStyle(o.optString("chart", "number"), o.optString("size", "m"), o.optString("shape", "card"), o.optString("color", "primary"))

        fun parseValues(a: JSONArray): List<KpiValue>? = try {
            (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                val restricted = o.optBoolean("restricted", false) || o.has("error")
                KpiValue(o.getString("code"), o.optString("name_bn", o.getString("code")), o.optString("unit").ifBlank { null },
                    if (restricted) null else dec(o, "value"), if (restricted) null else dec(o, "previous"), restricted, o.optBoolean("cached", false),
                    o.optInt("refresh_seconds", 300), o.optBoolean("has_products", false), parseStyle(o.optJSONObject("style")), o.optString("formula_bn").ifBlank { null })
            } }
        } catch (e: Exception) { null }

        /** Layout binding -> KPI code ("kpi.sales.amount" -> "sales.amount"); null for non-KPI bindings. */
        fun codeOf(binding: String?): String? = binding?.takeIf { it.startsWith("kpi.") }?.removePrefix("kpi.")?.takeIf { it.contains('.') }
    }
}

/** Bengali display of KPI numbers: lakh/crore grouping, Bengali digits, units; deltas carry a semantic tone. */
object KpiFormat {
    private fun bn(s: String) = buildString { for (c in s) append(if (c in '0'..'9') '০' + (c - '0') else c) }

    /** 123456789.5 -> "১২,৩৪,৫৬,৭৮৯.৫০" (South-Asian grouping). */
    fun grouped(v: BigDecimal, scale: Int = 2): String {
        val s = v.setScale(scale, RoundingMode.HALF_UP).abs().toPlainString()
        val (int, frac) = if ('.' in s) s.substringBefore('.') to s.substringAfter('.') else s to ""
        val head = if (int.length <= 3) int else {
            val last3 = int.takeLast(3); var rest = int.dropLast(3); val parts = ArrayList<String>()
            while (rest.length > 2) { parts.add(0, rest.takeLast(2)); rest = rest.dropLast(2) }
            if (rest.isNotEmpty()) parts.add(0, rest)
            parts.joinToString(",") + "," + last3
        }
        return bn((if (v.signum() < 0) "-" else "") + head + if (frac.isNotEmpty()) ".$frac" else "")
    }

    fun value(v: KpiValue): String = when {
        v.restricted -> "গোপন"
        v.value == null -> "—"
        v.unit == "money" -> "৳ " + grouped(v.value)
        v.unit == "percent" -> grouped(v.value, 1) + "%"
        else -> grouped(v.value, 0)
    }

    enum class Tone { GOOD, BAD, NEUTRAL }

    /** KPIs where a rise is bad news (shown in the alert colour). */
    val UP_IS_BAD = setOf("security.failed_logins", "dms.returns", "dms.return_rate", "dms.overdue", "dms.undelivered", "dms.collection_pending",
        "mfg.waste", "mfg.waste_rate", "mfg.unit_cost", "fin.expenses", "fin.cogs", "fin.payable", "stock.low_items", "stock.expiring",
        "courier.freight_company", "approvals.pending")

    /** Default split dimension for a donut chart of this KPI (null = the KPI cannot be split). */
    fun splitBy(code: String): String? = when (code) {
        "dms.sales", "dms.collected", "dms.receivable" -> "territory"
        "stock.total_value", "stock.fg_value", "stock.raw_value" -> "warehouse"
        "mfg.fg_output", "mfg.waste" -> "product"
        "fin.expenses", "fin.revenue" -> "account"
        else -> null
    }

    /** Change vs the previous period; for most KPIs up is good (failed logins: up is bad). Bad always uses the alert colour. */
    fun delta(v: KpiValue): Pair<String, Tone>? {
        val cur = v.value ?: return null; val prev = v.previous ?: return null
        if (prev.signum() == 0) return null
        val pct = cur.subtract(prev).multiply(BigDecimal(100)).divide(prev.abs(), 1, RoundingMode.HALF_UP)
        val upIsBad = v.code in UP_IS_BAD
        val tone = when { pct.signum() == 0 -> Tone.NEUTRAL; (pct.signum() > 0) != upIsBad -> Tone.GOOD; else -> Tone.BAD }
        return (if (pct.signum() > 0) "▲ " else if (pct.signum() < 0) "▼ " else "") + grouped(pct.abs(), 1) + "%" to tone
    }
}

/** Ads (F058): at most [visibleMax] (≤ 2) of the active slots at a time, rotating. */
object AdRotation {
    fun visible(slots: List<Int>, visibleMax: Int, tick: Int): List<Int> {
        val s = slots.distinct().sorted().take(3)
        val n = visibleMax.coerceIn(1, 2)
        if (s.size <= n) return s
        return (0 until n).map { s[(tick + it) % s.size] }
    }
}

/** Client cache with the KPI's own refresh window; dropped with every context/permission change (AppContainer). */
class KpiCache(private val now: () -> Long = System::currentTimeMillis) {
    private val m = HashMap<String, Pair<Long, KpiValue>>()
    @Synchronized fun get(key: String): KpiValue? = m[key]?.takeIf { (at, v) -> now() - at < v.refreshSeconds * 1000L }?.second
    @Synchronized fun put(key: String, v: KpiValue) { if (!v.restricted) m[key] = now() to v }
    @Synchronized fun clear() = m.clear()
}

package com.mohona.erp.feature.forms.data

import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import org.json.JSONObject

/** Where encrypted draft blobs live (app-private files in production, a map in tests). Only ciphertext ever reaches it. */
interface DraftStorage {
    fun put(id: String, blob: String)
    fun get(id: String): String?
    fun remove(id: String)
    fun ids(): Set<String>
}

class MemoryDraftStorage : DraftStorage {
    private val m = LinkedHashMap<String, String>()
    @Synchronized override fun put(id: String, blob: String) { m[id] = blob }
    @Synchronized override fun get(id: String): String? = m[id]
    @Synchronized override fun remove(id: String) { m.remove(id) }
    @Synchronized override fun ids(): Set<String> = m.keys.toSet()
}

data class OfflineDraft(
    val clientDraftId: String, val companyId: String, val personId: String, val formId: String, val formVersion: Int,
    val values: JSONObject, val wingId: String?, val savedAtMs: Long, val serverSubmissionId: String? = null
)

/**
 * Offline drafts (MOS-F153-048): AES-256-GCM encrypted on the device (key from the Android Keystore, [KeystoreDraftKey]),
 * bound to company + person (company switch / sign-out never shows another person's draft), expired after the Chairman's
 * TTL (forms.offline.draft_ttl_days), capped (forms.offline.max_drafts). This store can only SYNC a draft to the server
 * (api.v1_forms_draft_sync) — there is deliberately no submit or approve here: submission is an online action.
 */
class OfflineDraftStore(
    private val storage: DraftStorage,
    private val key: () -> SecretKey,
    private val now: () -> Long = System::currentTimeMillis
) {
    fun newDraftId(): String = "d" + java.util.UUID.randomUUID().toString().replace("-", "").take(30)

    fun save(d: OfflineDraft, maxDrafts: Int): Boolean {
        require(Regex("^[A-Za-z0-9_-]{8,64}$").matches(d.clientDraftId)) { "bad draft id" }
        val mine = list(d.companyId, d.personId, Long.MAX_VALUE)
        if (mine.none { it.clientDraftId == d.clientDraftId } && mine.size >= maxDrafts) return false
        storage.put(d.clientDraftId, encrypt(toJson(d.copy(savedAtMs = now())).toString()))
        return true
    }

    /** Drafts of this person in this company, newest first; expired or unreadable (tampered / other key) drafts are removed. */
    fun list(companyId: String, personId: String, ttlDays: Long): List<OfflineDraft> {
        val out = ArrayList<OfflineDraft>()
        val ttlMs = if (ttlDays == Long.MAX_VALUE) Long.MAX_VALUE else ttlDays * 86_400_000L
        for (id in storage.ids()) {
            val d = storage.get(id)?.let { b -> runCatching { fromJson(JSONObject(decrypt(b))) }.getOrNull() }
            if (d == null) { storage.remove(id); continue }
            if (ttlMs != Long.MAX_VALUE && now() - d.savedAtMs > ttlMs) { storage.remove(id); continue }
            if (d.companyId == companyId && d.personId == personId) out += d
        }
        return out.sortedByDescending { it.savedAtMs }
    }

    fun get(id: String): OfflineDraft? = storage.get(id)?.let { b -> runCatching { fromJson(JSONObject(decrypt(b))) }.getOrNull() }

    fun remove(id: String) = storage.remove(id)

    /** After a successful sync: remember the server id. After the draft was submitted online (sync returns conflict): drop it. */
    fun markSynced(id: String, serverSubmissionId: String, conflict: Boolean) {
        if (conflict) { storage.remove(id); return }
        get(id)?.let { storage.put(id, encrypt(toJson(it.copy(serverSubmissionId = serverSubmissionId)).toString())) }
    }

    /** Sign-out / company switch: nothing readable may remain for the next user of the device. */
    fun clearAll() = storage.ids().forEach { storage.remove(it) }

    private fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())              // the provider picks a fresh random IV (Keystore refuses caller IVs)
        val iv = c.iv
        check(iv.size == 12) { "unexpected GCM IV size" }
        return "v1:" + Base64.getEncoder().encodeToString(iv + c.doFinal(plain.toByteArray(Charsets.UTF_8)))
    }

    private fun decrypt(blob: String): String {
        require(blob.startsWith("v1:"))
        val raw = Base64.getDecoder().decode(blob.substring(3))
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        return String(c.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8)
    }

    private fun toJson(d: OfflineDraft) = JSONObject().put("id", d.clientDraftId).put("company", d.companyId).put("person", d.personId)
        .put("form", d.formId).put("version", d.formVersion).put("values", d.values).put("wing", d.wingId ?: JSONObject.NULL)
        .put("saved", d.savedAtMs).put("server", d.serverSubmissionId ?: JSONObject.NULL)

    private fun fromJson(o: JSONObject) = OfflineDraft(o.getString("id"), o.getString("company"), o.getString("person"), o.getString("form"),
        o.getInt("version"), o.getJSONObject("values"), if (o.isNull("wing")) null else o.getString("wing"), o.getLong("saved"),
        if (o.isNull("server")) null else o.getString("server"))
}

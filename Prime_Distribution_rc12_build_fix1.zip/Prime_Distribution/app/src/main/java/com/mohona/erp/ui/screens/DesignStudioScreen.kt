package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.feature.design.data.ThemeTemplate
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.IconRegistry
import com.mohona.erp.ui.theme.TextMuted
import com.mohona.erp.ui.theme.toColor
import com.mohona.erp.ui.theme.tokens.Contrast
import com.mohona.erp.ui.theme.tokens.DesignRules
import com.mohona.erp.ui.theme.tokens.MohonaTokens
import com.mohona.erp.ui.theme.tokens.TokenCodec
import java.util.UUID
import kotlinx.coroutines.launch

/**
 * Design Studio 1 (S18): start from a template, edit palette / typography / cards with live contrast and a money-fit
 * preview, save an immutable draft, publish (server re-validates; may need approval), bind catalog icons to targets.
 * Shown with design.studio.edit; publish with design.studio.publish (server decides).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DesignStudioScreen(icons: List<com.mohona.erp.feature.design.data.IconBinding>, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    var templates by remember { mutableStateOf<List<ThemeTemplate>>(emptyList()) }
    var tokens by remember { mutableStateOf(MohonaTokens.DEFAULT) }
    var code by remember { mutableStateOf("HOUSE") }
    var name by remember { mutableStateOf("কোম্পানির থিম") }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var saved by remember { mutableStateOf<Pair<String, Int>?>(null) }
    var iconTarget by remember { mutableStateOf("module.finance") }
    var iconPerm by remember { mutableStateOf("") }
    var iconName by remember { mutableStateOf("AccountBalance") }
    LaunchedEffect(Unit) {
        when (val r = AppContainer.design?.templates()) { is ApiResult.Ok -> templates = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    val problems = DesignRules.publishErrors(tokens)
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("ডিজাইন-স্টুডিও", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("থিম-ক্যাটালগ")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                templates.forEach { t -> FilterChip(selected = false, onClick = { tokens = TokenCodec.decode(t.tokens).tokens; message = t.nameBn + " থেকে শুরু" }, label = { Text(t.nameBn) }) }
            }
            SectionTitle("প্যালেট")
            fun setColor(key: String, hex: String) {
                val v = TokenCodec.parseHex(hex) ?: return
                val c = tokens.colors
                tokens = tokens.copy(colors = when (key) {
                    "primary" -> c.copy(primary = v); "onPrimary" -> c.copy(onPrimary = v); "background" -> c.copy(background = v)
                    "surfaceAlt" -> c.copy(surfaceAlt = v); "text" -> c.copy(text = v); "textMuted" -> c.copy(textMuted = v)
                    "good" -> c.copy(good = v); "warn" -> c.copy(warn = v); "bad" -> c.copy(bad = v); else -> c.copy(info = v)
                })
            }
            val c = tokens.colors
            listOf("primary" to c.primary, "onPrimary" to c.onPrimary, "background" to c.background, "surfaceAlt" to c.surfaceAlt,
                "text" to c.text, "textMuted" to c.textMuted, "good" to c.good, "warn" to c.warn, "bad" to c.bad, "info" to c.info).forEach { (k, v) ->
                ColorRow(k, v, against = if (k == "onPrimary") c.primary else c.background) { setColor(k, it) }
            }
            SectionTitle("টাইপোগ্রাফি")
            Labeled("স্কেল ${"%.2f".format(tokens.type.scale)}") { Slider(value = tokens.type.scale, valueRange = 0.85f..1.40f, onValueChange = { tokens = tokens.copy(type = tokens.type.copy(scale = it)) }) }
            Labeled("শিরোনাম ${tokens.type.headlineSp.toInt()} sp") { Slider(value = tokens.type.headlineSp, valueRange = 18f..36f, onValueChange = { tokens = tokens.copy(type = tokens.type.copy(headlineSp = it)) }) }
            Labeled("লেখা ${tokens.type.bodySp.toInt()} sp") { Slider(value = tokens.type.bodySp, valueRange = 12f..22f, onValueChange = { tokens = tokens.copy(type = tokens.type.copy(bodySp = it)) }) }
            Labeled("লাইন-উচ্চতা ${"%.2f".format(tokens.type.lineHeightFactor)}") { Slider(value = tokens.type.lineHeightFactor, valueRange = 1.2f..2.0f, onValueChange = { tokens = tokens.copy(type = tokens.type.copy(lineHeightFactor = it)) }) }
            SectionTitle("কার্ড")
            Labeled("কোণ ${tokens.cards.radiusDp.toInt()} dp") { Slider(value = tokens.cards.radiusDp, valueRange = 0f..28f, onValueChange = { tokens = tokens.copy(cards = tokens.cards.copy(radiusDp = it)) }) }
            Labeled("ভেতরের ফাঁকা ${tokens.cards.paddingDp.toInt()} dp") { Slider(value = tokens.cards.paddingDp, valueRange = 4f..24f, onValueChange = { tokens = tokens.copy(cards = tokens.cards.copy(paddingDp = it)) }) }
            Labeled("সীমারেখা ${"%.1f".format(tokens.cards.borderDp)} dp") { Slider(value = tokens.cards.borderDp, valueRange = 0f..2f, onValueChange = { tokens = tokens.copy(cards = tokens.cards.copy(borderDp = it)) }) }
            SectionTitle("প্রিভিউ")
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(tokens.cards.radiusDp.dp)).background(tokens.colors.background.toColor()).padding(tokens.cards.paddingDp.dp)) {
                Column {
                    Text("আজকের বিক্রয়", color = tokens.colors.textMuted.toColor(), fontSize = (tokens.type.labelSp * tokens.type.scale).sp)
                    Text(DesignRules.MONEY_SAMPLE, color = tokens.colors.text.toColor(), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Clip,
                        fontSize = (tokens.type.headlineSp * tokens.type.scale).sp, lineHeight = (tokens.type.headlineSp * tokens.type.scale * tokens.type.lineHeightFactor).sp)
                    Box(Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).background(tokens.colors.primary.toColor()).padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Text("অনুমোদন", color = tokens.colors.onPrimary.toColor())
                    }
                }
            }
            problems.forEach { Text("প্রকাশে বাধা: $it", color = BadRed, style = MaterialTheme.typography.labelSmall) }
            OutlinedTextField(value = code, onValueChange = { code = it.uppercase().take(31) }, label = { Text("থিম-কোড") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    if (reason.isBlank()) { message = "কারণ লিখুন।"; return@OutlinedButton }
                    scope.launch {
                        when (val r = AppContainer.design?.save(code, name, TokenCodec.encode(tokens), null, reason, UUID.randomUUID().toString())) {
                            is ApiResult.Ok -> { saved = r.value.optString("theme_id") to r.value.optInt("version")
                                val ok = r.value.optJSONObject("report")?.optBoolean("ok") == true
                                message = "খসড়া সংস্করণ ${r.value.optInt("version")} সংরক্ষিত" + if (ok) "" else " (প্রকাশের আগে ত্রুটি ঠিক করুন)" }
                            is ApiResult.Err -> message = r.error.messageBn
                            null -> message = "সংযুক্ত মোড নয়।"
                        }
                    }
                }) { Text("খসড়া সংরক্ষণ") }
                if (PermissionHints.can(perms, "design.studio.publish")) Button(enabled = saved != null && problems.isEmpty(), onClick = {
                    val (themeId, version) = saved ?: return@Button
                    scope.launch {
                        val rv = (AppContainer.design?.themes() as? ApiResult.Ok)?.value?.let { a ->
                            (0 until a.length()).map { a.getJSONObject(it) }.firstOrNull { it.optString("id") == themeId }?.optInt("row_version") } ?: 1
                        when (val r = AppContainer.design?.publish(themeId, version, rv, reason.ifBlank { "publish" }, UUID.randomUUID().toString())) {
                            is ApiResult.Ok -> message = if (r.value.optString("status") == "published") "প্রকাশিত — পরের লগইনে সবার অ্যাপে।" else "অনুমোদনের অপেক্ষায়।"
                            is ApiResult.Err -> message = r.error.messageBn
                            null -> Unit
                        }
                    }
                }) { Text("প্রকাশ") }
            }
            SectionTitle("আইকন")
            OutlinedTextField(value = iconTarget, onValueChange = { iconTarget = it.lowercase().take(90) }, label = { Text("লক্ষ্য (module./action./tab./kpi./status.)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = iconPerm, onValueChange = { iconPerm = it.trim() }, label = { Text("অনুমতি-কোড (action.* হলে বাধ্যতামূলক)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconRegistry.NAMES.forEach { n ->
                    FilterChip(selected = iconName == n, onClick = { iconName = n }, label = { Icon(IconRegistry.vector(n), contentDescription = n, modifier = Modifier.size(18.dp)) })
                }
            }
            OutlinedButton(onClick = {
                if (reason.isBlank()) { message = "কারণ লিখুন।"; return@OutlinedButton }
                scope.launch {
                    val current = icons.firstOrNull { it.targetKey == iconTarget }?.version ?: 0
                    when (val r = AppContainer.design?.setIcon(iconTarget, iconName, iconPerm.ifBlank { null }, current, reason, UUID.randomUUID().toString())) {
                        is ApiResult.Ok -> message = "আইকন সংরক্ষিত।"
                        is ApiResult.Err -> message = r.error.messageBn
                        null -> Unit
                    }
                }
            }) { Text("আইকন বাঁধুন") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

@Composable
private fun ColorRow(key: String, value: Long, against: Long, onHex: (String) -> Unit) {
    var text by remember(value) { mutableStateOf(TokenCodec.toHex(value)) }
    val ratio = Contrast.ratio(value, against)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(28.dp).clip(RoundedCornerShape(6.dp)).background(value.toColor()))
        OutlinedTextField(value = text, onValueChange = { text = it.take(7); if (TokenCodec.parseHex(text) != null) onHex(text) }, label = { Text(key) },
            singleLine = true, modifier = Modifier.weight(1f))
        Text("%.1f:1".format(ratio), style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun Labeled(label: String, content: @Composable () -> Unit) {
    Column { Text(label, style = MaterialTheme.typography.labelMedium); content() }
}

package com.mohona.erp.feature.actions

import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Every server function of Prime Distribution as a form (generated file: assets/actions.json, built from the SQL
 * signatures, so parameter names always match the server). Seven departments = the seven main icons.
 * The server stays the only authority: a form the position has no right for simply returns the server's refusal.
 */
enum class FieldType { TEXT, NUMBER, INT, DATE, BOOL, UUID, JSON, TEXT_ARRAY }

data class ActionField(val param: String, val labelBn: String, val type: FieldType, val optional: Boolean)
data class ActionDef(val department: String, val rpc: String, val titleBn: String, val write: Boolean, val fields: List<ActionField>)
data class DeptLink(val titleBn: String, val route: String, val permission: String? = null)
data class Department(val id: String, val titleBn: String, val icon: String, val gatePermission: String?, val chairmanOnly: Boolean, val links: List<DeptLink>)

object ActionCatalog {
    val departments: List<Department> = listOf(
        Department("mfs", "ম্যানুফ্যাকচারিং", "🏭", "mfg.bom.read", false, listOf(
            DeptLink("উৎপাদন ও ব্যাচ", "mfg", "mfg.bom.read"), DeptLink("ক্রয় ও সরবরাহকারী-দেনা", "procurement", "procurement.read"),
            DeptLink("কাঁচামাল-মজুদ", "stock", "inventory.stock.read"), DeptLink("পণ্য ও প্যাকিং", "products", "master.sku.read"))),
        Department("wh", "ওয়্যারহাউস", "📦", "inventory.stock.read", false, listOf(
            DeptLink("গুদাম (রিপোর্ট, QR, গণনা)", "warehouse", "inventory.stock.read"), DeptLink("মজুদ ও লট", "stock", "inventory.stock.read"),
            DeptLink("QR স্ক্যান (পণ্য / কার্টন / বিন)", "qrscan"))),
        Department("dms", "ডিলার (DMS)", "🤝", "crm.dealer.read", false, listOf(
            DeptLink("ডিলার, বকেয়া ও স্টেটমেন্ট", "dealers", "crm.dealer.read"), DeptLink("বিক্রয় ও কালেকশন", "sales"),
            DeptLink("ইনভয়েস / রসিদ প্রিন্ট ও শেয়ার", "print"))),
        Department("crm", "গ্রাহক (CRM)", "👥", "crm.dealer.read", false, listOf(
            DeptLink("পার্টি ও ডিলার", "dealers", "crm.dealer.read"), DeptLink("ম্যাপ ও অবস্থান", "map"), DeptLink("আজকের ভিজিট", "myday", "hr.attendance.scan"))),
        Department("hr", "অফিস ও HR", "🏢", null, false, listOf(
            DeptLink("আমার দিন (হাজিরা-QR)", "myday", "hr.attendance.scan"), DeptLink("পে-স্লিপ", "ops"), DeptLink("সংগঠন-কাঠামো", "org", "iam.hierarchy.read"),
            DeptLink("ফর্ম", "forms", "forms.form.read"), DeptLink("রিপোর্ট", "custom_reports", "report.run"), DeptLink("নোটিফিকেশন", "inbox"))),
        Department("courier", "কুরিয়ার", "🚚", "courier.read", false, listOf(DeptLink("চালান, কন্ডিশন ও আদায়", "courier", "courier.read"))),
        // V162 dealer self-service: visible only to a DEALER_PORTAL position (staff never hold dealer.portal.read)
        Department("dealer", "আমার ডিলার-অ্যাপ", "🏪", "dealer.portal.read", false, emptyList()),
        Department("chairman", "চেয়ারম্যান", "👑", "iam.permission.manage", true, listOf(
            DeptLink("অর্থ-অনুমোদন ও হিসাব-শৃঙ্খল", "chairman_panel"), DeptLink("গ্রাফ, অঞ্চলভিত্তিক গ্রাফ ও ৫০ ইনভয়েস-নকশা", "chairman_studio", "kpi.dashboard.read"), DeptLink("হিসাব", "finance", "finance.ledger.read"), DeptLink("সেটিং", "settings", "config.settings.read"),
            DeptLink("ডিজাইন-স্টুডিও", "design", "design.studio.edit"), DeptLink("লেআউট-স্টুডিও", "layout", "design.studio.edit"),
            DeptLink("কোম্পানি-কাঠামো", "structure", "core.structure.read"), DeptLink("শাসন, ব্যাকআপ ও রিলিজ-প্রমাণ", "ops"), DeptLink("রিসাইকেল-বিন", "recycle")))
    )

    /** Parses assets/actions.json. Unknown field types become TEXT; a broken entry is skipped, never crashes the app. */
    fun parse(json: String): List<ActionDef> {
        val out = ArrayList<ActionDef>()
        val arr = runCatching { JSONObject(json).getJSONArray("actions") }.getOrNull() ?: return out
        for (i in 0 until arr.length()) {
            val a = arr.optJSONObject(i) ?: continue
            val rpc = a.optString("r")
            if (!Regex("^v1_[a-z0-9_]+$").matches(rpc)) continue
            val fs = a.optJSONArray("f") ?: JSONArray()
            val fields = (0 until fs.length()).mapNotNull { k ->
                val f = fs.optJSONObject(k) ?: return@mapNotNull null
                val t = runCatching { FieldType.valueOf(f.optString("t")) }.getOrDefault(FieldType.TEXT)
                ActionField(f.optString("p"), f.optString("l"), t, f.optBoolean("o"))
            }
            out += ActionDef(a.optString("d"), rpc, a.optString("n"), a.optBoolean("w"), fields)
        }
        return out
    }

    /** Typed parameters for PostgREST. Blank = SQL null (the server decides whether that is allowed). */
    fun buildParams(def: ActionDef, values: Map<String, String>): Result<JSONObject> = runCatching {
        val p = JSONObject()
        for (f in def.fields) {
            val raw = values[f.param]?.trim().orEmpty()
            if (raw.isEmpty() && f.param == "p_idem_key") { p.put(f.param, "APP-" + java.util.UUID.randomUUID().toString().replace("-", "")); continue }  // one key per press
            if (raw.isEmpty()) { p.put(f.param, JSONObject.NULL); continue }
            when (f.type) {
                FieldType.TEXT -> p.put(f.param, raw)
                FieldType.NUMBER -> p.put(f.param, BigDecimal(toAsciiDigits(raw)))
                FieldType.INT -> p.put(f.param, toAsciiDigits(raw).toInt())
                FieldType.DATE -> { val d = toAsciiDigits(raw); require(Regex("^\\d{4}-\\d{2}-\\d{2}$").matches(d)) { "${f.labelBn}: তারিখ বছর-মাস-দিন (যেমন ২০২৬-১১-১৪)" }; p.put(f.param, d) }
                FieldType.BOOL -> p.put(f.param, raw == "true")
                FieldType.UUID -> { require(Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$").matches(raw)) { "${f.labelBn}: আইডি ঠিক নয়" }; p.put(f.param, raw) }
                FieldType.JSON -> { val v = JSONTokener(raw).nextValue(); require(v is JSONObject || v is JSONArray) { "${f.labelBn}: JSON তালিকা বা অবজেক্ট" }; p.put(f.param, v) }
                FieldType.TEXT_ARRAY -> p.put(f.param, JSONArray(raw.split(',').map { it.trim() }.filter { it.isNotEmpty() }))
            }
        }
        p
    }

    /** Bengali digits typed on a Bengali keyboard are accepted in number / date fields. */
    fun toAsciiDigits(s: String): String = buildString { s.forEach { c -> append(if (c in '০'..'৯') ('0' + (c - '০')) else c) } }

    /** Flattens a server answer into readable lines (objects: key: value; arrays: one line per row; null: "তথ্য নেই"). */
    fun render(value: Any?, limit: Int = 200): List<String> {
        val out = ArrayList<String>()
        fun line(o: JSONObject): String = o.keys().asSequence().filter { !o.isNull(it) }.joinToString(" · ") { k ->
            val v = o.opt(k); k + ": " + if (v is JSONObject || v is JSONArray) "…" else v.toString() }
        when (value) {
            null, JSONObject.NULL -> out += "তথ্য নেই"
            is JSONArray -> { if (value.length() == 0) out += "কোনো সারি নেই"; for (i in 0 until minOf(value.length(), limit)) { val r = value.opt(i); out += if (r is JSONObject) line(r) else r.toString() } }
            is JSONObject -> value.keys().forEach { k ->
                val v = value.opt(k)
                when (v) {
                    is JSONArray -> { out += "$k (${v.length()})"; for (i in 0 until minOf(v.length(), limit)) { val r = v.opt(i); out += "  • " + if (r is JSONObject) line(r) else r.toString() } }
                    is JSONObject -> out += "$k: " + line(v)
                    else -> out += "$k: " + if (value.isNull(k)) "—" else v.toString()
                }
            }
            else -> out += value.toString()
        }
        return out
    }
}

/** Which department the hub opened (navigation without route arguments). */
object DeptNav { @Volatile var current: String = "mfs" }

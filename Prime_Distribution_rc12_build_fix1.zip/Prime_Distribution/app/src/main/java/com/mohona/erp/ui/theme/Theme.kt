package com.mohona.erp.ui.theme

import android.app.Activity
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.mohona.erp.ui.theme.tokens.MohonaTokens

// Light theme only (owner decision). Everything below derives from ThemeRuntime.tokens (Chairman-customisable).

internal fun colorSchemeFor(t: MohonaTokens) = lightColorScheme(
    primary = t.colors.primary.toColor(),
    onPrimary = t.colors.onPrimary.toColor(),
    primaryContainer = t.colors.primarySoft.toColor(),
    onPrimaryContainer = t.colors.primaryDark.toColor(),
    secondary = t.colors.primaryDark.toColor(),
    onSecondary = t.colors.onPrimary.toColor(),
    secondaryContainer = t.colors.primarySoft.toColor(),
    onSecondaryContainer = t.colors.primaryDark.toColor(),
    tertiary = t.colors.info.toColor(),
    background = t.colors.background.toColor(),
    onBackground = t.colors.text.toColor(),
    surface = t.colors.background.toColor(),
    onSurface = t.colors.text.toColor(),
    surfaceVariant = t.colors.surfaceAlt.toColor(),
    onSurfaceVariant = t.colors.textMuted.toColor(),
    outline = t.colors.divider.toColor(),
    error = t.colors.bad.toColor(),
    onError = Color.White
)

internal fun typographyFor(t: MohonaTokens): Typography {
    val k = t.type.scale
    val lh = t.type.lineHeightFactor
    fun style(size: Float, weight: FontWeight) = TextStyle(fontSize = (size * k).sp, lineHeight = (size * k * lh).sp, fontWeight = weight)
    return Typography(
        displaySmall = style(t.type.headlineSp + 6f, FontWeight.Bold),
        headlineMedium = style(t.type.headlineSp + 2f, FontWeight.Bold),
        headlineSmall = style(t.type.headlineSp, FontWeight.SemiBold),
        titleLarge = style(t.type.titleSp + 2f, FontWeight.SemiBold),
        titleMedium = style(t.type.titleSp, FontWeight.SemiBold),
        titleSmall = style(t.type.bodySp, FontWeight.Medium),
        bodyLarge = style(t.type.bodySp + 1f, FontWeight.Normal),
        bodyMedium = style(t.type.bodySp, FontWeight.Normal),
        bodySmall = style(t.type.labelSp, FontWeight.Normal),
        labelLarge = style(t.type.bodySp - 1f, FontWeight.Medium),
        labelMedium = style(t.type.labelSp, FontWeight.Medium),
        labelSmall = style(t.type.labelSp - 1f, FontWeight.Medium)
    )
}

internal fun shapesFor(t: MohonaTokens) = Shapes(
    extraSmall = RoundedCornerShape((t.shapes.cornerSmallDp / 2f).dp),
    small = RoundedCornerShape(t.shapes.cornerSmallDp.dp),
    medium = RoundedCornerShape(t.shapes.cornerMediumDp.dp),
    large = RoundedCornerShape(t.shapes.cornerLargeDp.dp),
    extraLarge = RoundedCornerShape((t.shapes.cornerLargeDp * 1.5f).dp)
)

@Composable
fun MohonaTheme(content: @Composable () -> Unit) {
    val tokens = ThemeRuntime.tokens
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = tokens.colors.background.toColor().toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = true
            }
        }
    }
    val scheme = remember(tokens) { colorSchemeFor(tokens) }
    val typography = remember(tokens) { typographyFor(tokens) }
    val shapes = remember(tokens) { shapesFor(tokens) }
    MaterialTheme(colorScheme = scheme, typography = typography, shapes = shapes, content = content)
}

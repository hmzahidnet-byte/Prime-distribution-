package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.hr.data.AccessPreview
import com.mohona.erp.feature.hr.data.HierarchyRepository
import com.mohona.erp.feature.hr.data.OrgPosition
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ErrorState
import com.mohona.erp.ui.components.LoadingState
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted

/** Organisation tree (OI-23): positions by reporting line, holders, grade and pay as the server allows (masked otherwise). */
@Composable
fun OrgTreeScreen(onBack: () -> Unit, onPreview: (assignmentId: String) -> Unit) {
    var tree by remember { mutableStateOf<List<OrgPosition>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        when (val r = AppContainer.hierarchy?.orgTree()) { is ApiResult.Ok -> tree = r.value; is ApiResult.Err -> error = r.error.messageBn; null -> error = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("সংগঠন-কাঠামো", onBack)
        val t = tree
        when {
            error != null -> ErrorState(error!!)
            t == null -> LoadingState()
            else -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HierarchyRepository.flatten(t).forEach { (p, depth) ->
                    AppCard {
                        Column(Modifier.padding(start = (12 + depth * 14).dp, top = 10.dp, bottom = 10.dp, end = 12.dp)) {
                            Text(p.nameBn + " (" + p.code + ")", style = MaterialTheme.typography.bodyMedium)
                            if (p.holders.isEmpty()) Text("শূন্য পদ", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            p.holders.forEach { h ->
                                AppCard(onClick = { onPreview(h.assignmentId) }) {
                                    Text(h.nameBn + listOfNotNull(h.grade?.let { "গ্রেড $it" }, h.salaryText?.let { "বেতন $it" },
                                        h.employmentStatus?.takeIf { it != "active" }, if (h.onboardingOpen) "নিয়োগ-চেকলিস্ট খোলা" else null)
                                        .joinToString(" · ", prefix = " · ").takeIf { it.length > 3 }.orEmpty(),
                                        style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(8.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Effective privileges of one assignment (F023): by module, with dependency gaps and SoD conflicts. No business records. */
@Composable
fun AccessPreviewScreen(assignmentId: String, onBack: () -> Unit) {
    var preview by remember { mutableStateOf<AccessPreview?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(assignmentId) {
        when (val r = AppContainer.hierarchy?.accessPreview(assignmentId)) { is ApiResult.Ok -> preview = r.value; is ApiResult.Err -> error = r.error.messageBn; null -> error = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("অ্যাক্সেস-প্রিভিউ", onBack)
        val p = preview
        when {
            error != null -> ErrorState(error!!)
            p == null -> LoadingState()
            else -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(p.positionCode + if (p.supreme) " — সর্বোচ্চ কর্তৃত্ব" else "", style = MaterialTheme.typography.titleSmall)
                p.conflicts.forEach { Text("দায়িত্ব-বিভাজন (" + it.mode + "): " + it.a + " ↔ " + it.b, color = BadRed, style = MaterialTheme.typography.labelSmall) }
                p.gaps.forEach { Text("নির্ভরতা-ফাঁক: " + it.permission + " → " + it.requires, color = BadRed, style = MaterialTheme.typography.labelSmall) }
                p.byModule.toSortedMap().forEach { (module, perms) ->
                    SectionTitle(module)
                    perms.forEach { Text(it.nameBn + " · " + it.code + (if (it.via == "delegated") " (অর্পিত)" else ""), style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }
}

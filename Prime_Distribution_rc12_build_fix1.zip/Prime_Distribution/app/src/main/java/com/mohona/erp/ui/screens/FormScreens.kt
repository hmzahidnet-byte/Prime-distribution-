package com.mohona.erp.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorKind
import com.mohona.erp.feature.forms.data.AttachmentUploader
import com.mohona.erp.feature.forms.data.FormEngine
import com.mohona.erp.feature.forms.data.FormSummary
import com.mohona.erp.feature.forms.data.OfflineDraft
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.ErrorState
import com.mohona.erp.ui.components.LoadingState
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.forms.DynamicForm
import com.mohona.erp.ui.forms.FormUi
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Published forms of the company (S17). */
@Composable
fun FormsListScreen(onBack: () -> Unit, onOpen: (FormSummary) -> Unit) {
    var forms by remember { mutableStateOf<List<FormSummary>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        val repo = AppContainer.forms ?: run { error = "সংযুক্ত মোড নয়।"; return@LaunchedEffect }
        when (val r = repo.list()) { is ApiResult.Ok -> forms = r.value; is ApiResult.Err -> error = r.error.messageBn }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("ফর্ম", onBack)
        val list = forms
        when {
            error != null -> ErrorState(error!!, onRetry = { error = null; reload++ })
            list == null -> LoadingState()
            list.isEmpty() -> EmptyState("কোনো প্রকাশিত ফর্ম নেই।")
            else -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                list.filter { it.status == "active" }.forEach { f ->
                    AppCard(onClick = { onOpen(f) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text(f.nameBn, style = MaterialTheme.typography.titleSmall)
                            Text(f.code + " · সংস্করণ " + (f.activeVersion ?: 0), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}

/**
 * Fill one form: draft save (online; offline encrypted when the network is down and the company allows offline drafts),
 * then submit (online only — never offline). Field errors come from the local engine and, authoritatively, the server.
 */
@Composable
fun FormFillScreen(formId: String, companyId: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var def by remember { mutableStateOf<JSONObject?>(null) }
    var meta by remember { mutableStateOf<JSONObject?>(null) }
    var values by remember { mutableStateOf(JSONObject()) }
    var errors by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var submissionId by remember { mutableStateOf<String?>(null) }
    var rowVersion by remember { mutableStateOf<Int?>(null) }
    var saveKey by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var submitKey by remember { mutableStateOf(UUID.randomUUID().toString()) }
    val context = LocalContext.current
    var attachField by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val key = attachField
        if (uri != null && key != null) {
            busy = true; message = "সংযুক্তি আপলোড হচ্ছে…"
            scope.launch {
                val out = AttachmentUploader.upload(context, uri, formId, key)
                if (out.attachmentId != null) { values = JSONObject(values.toString()).put(key, out.attachmentId); errors = emptyMap() }
                message = out.messageBn; busy = false; attachField = null
            }
        }
    }
    LaunchedEffect(formId) {
        when (val r = AppContainer.forms?.definition(formId)) {
            is ApiResult.Ok -> { meta = r.value; def = r.value.optJSONObject("definition") }
            is ApiResult.Err -> message = r.error.messageBn
            null -> message = "সংযুক্ত মোড নয়।"
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(meta?.optString("name_bn") ?: "ফর্ম", onBack)
        val d = def
        if (d == null) { if (message != null) ErrorState(message!!) else LoadingState(); return@Column }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            DynamicForm(d, values, errors, enabled = !busy, onChange = { values = it; errors = emptyMap() },
                onAttach = { key -> attachField = key; picker.launch("*/*") })
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted, modifier = Modifier.padding(top = 10.dp)) }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(enabled = !busy, modifier = Modifier.weight(1f), onClick = {
                    val repo = AppContainer.forms ?: return@OutlinedButton
                    busy = true
                    scope.launch {
                        val toSend = FormUi.finalize(d, values)
                        when (val r = repo.save(formId, submissionId, d, toSend, null, rowVersion, null, saveKey)) {
                            is ApiResult.Ok -> { submissionId = r.value.submissionId; rowVersion = r.value.rowVersion; saveKey = UUID.randomUUID().toString(); message = "খসড়া সংরক্ষিত।" }
                            is ApiResult.Err -> if ((r.error.kind == ErrorKind.NETWORK || r.error.kind == ErrorKind.TIMEOUT) && meta?.optBoolean("offline_drafts") == true) {
                                val store = AppContainer.draftStore; val person = AppContainer.currentPersonId
                                if (store != null && person != null) {
                                    val ok = store.save(OfflineDraft(store.newDraftId(), companyId, person, formId, meta!!.optInt("version"), toSend, null, 0),
                                        AppContainer.uiMaxDrafts)
                                    message = if (ok) "নেটওয়ার্ক নেই: খসড়া এই ফোনে এনক্রিপ্ট করে রাখা হলো; পরে সিঙ্ক করুন।" else "খোলা খসড়ার সীমা পূর্ণ।"
                                } else message = r.error.messageBn
                            } else {
                                errors = FormUi.errorsByField(FormEngine.parseErrors(r.error.detail)); message = r.error.messageBn
                            }
                        }
                        busy = false
                    }
                }) { Text("খসড়া") }
                Button(enabled = !busy, modifier = Modifier.weight(1f), onClick = {
                    val repo = AppContainer.forms ?: return@Button
                    val local = FormEngine.check(d, FormUi.finalize(d, values), partial = false)
                    if (!local.ok) { errors = FormUi.errorsByField(local.errors); return@Button }
                    busy = true
                    scope.launch {
                        val saved = repo.save(formId, submissionId, d, FormUi.finalize(d, values), null, rowVersion, null, saveKey)
                        if (saved is ApiResult.Err) {
                            errors = FormUi.errorsByField(FormEngine.parseErrors(saved.error.detail)); message = saved.error.messageBn; busy = false; return@launch
                        }
                        val s = (saved as ApiResult.Ok).value
                        submissionId = s.submissionId; rowVersion = s.rowVersion; saveKey = UUID.randomUUID().toString()
                        when (val r = repo.submit(s.submissionId, s.rowVersion, submitKey)) {
                            is ApiResult.Ok -> { submitKey = UUID.randomUUID().toString()
                                message = "জমা হয়েছে" + (r.value.number?.let { " — নম্বর $it" } ?: "") + if (r.value.status == "pending_approval") " (অনুমোদনের অপেক্ষায়)" else "" }
                            is ApiResult.Err -> { errors = FormUi.errorsByField(FormEngine.parseErrors(r.error.detail)); message = r.error.messageBn }
                        }
                        busy = false
                    }
                }) { Text("জমা দিন") }
            }
        }
    }
}

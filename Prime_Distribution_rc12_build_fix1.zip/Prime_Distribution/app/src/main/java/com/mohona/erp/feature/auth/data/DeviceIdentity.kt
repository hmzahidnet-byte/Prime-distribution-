package com.mohona.erp.feature.auth.data

import android.content.Context

/** Stable per-install device id (not a secret: the server stores only its hash and binds PIN sessions to it). */
object DeviceIdentity {
    fun get(context: Context): String {
        val prefs = context.getSharedPreferences("mohona_device", Context.MODE_PRIVATE)
        prefs.getString("id", null)?.let { if (Regex("^[A-Za-z0-9_-]{16,128}$").matches(it)) return it }
        val id = LoginRules.newDeviceId()
        prefs.edit().putString("id", id).apply()
        return id
    }
}

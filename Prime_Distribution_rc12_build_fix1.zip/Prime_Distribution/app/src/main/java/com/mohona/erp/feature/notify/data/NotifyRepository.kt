package com.mohona.erp.feature.notify.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class Notice(val id: String, val category: String, val priority: String, val titleBn: String, val bodyBn: String, val linkKind: String?,
                  val linkId: String?, val createdAt: String, val read: Boolean)

/** Notifications (S22): personal inbox, banner, read state, preferences; audit search/export and policy review (governance). */
class NotifyRepository(private val client: SupabaseClient) {
    suspend fun inbox(unreadOnly: Boolean = false): ApiResult<List<Notice>> = when (val r = client.rpcArray("v1_notify_inbox", JSONObject().put("p_unread_only", unreadOnly).put("p_limit", 100))) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parse(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_notify_inbox"))
    }
    suspend fun banner(): ApiResult<List<Notice>> = when (val r = client.rpcArray("v1_notify_banner")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parse(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_notify_banner"))
    }
    suspend fun mark(ids: List<String>, action: String): ApiResult<Any> =
        client.rpc("v1_notify_mark", JSONObject().put("p_ids", JSONArray(ids)).put("p_action", action), write = true)
    suspend fun preferences(): ApiResult<JSONArray> = client.rpcArray("v1_notify_preferences")
    suspend fun setPreference(category: String, channel: String, enabled: Boolean): ApiResult<JSONObject> =
        client.rpcObject("v1_notify_set_preference", JSONObject().put("p_category", category).put("p_channel", channel).put("p_enabled", enabled), write = true)
    suspend fun broadcast(titleBn: String, bodyBn: String, wingId: String?, priority: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_notify_broadcast", JSONObject().put("p_title_bn", titleBn).put("p_body_bn", bodyBn).put("p_wing_id", wingId ?: JSONObject.NULL)
            .put("p_priority", priority).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun auditEvents(fromIso: String?, toIso: String?, table: String? = null): ApiResult<JSONArray> =
        client.rpcArray("v1_audit_events", JSONObject().put("p_from", fromIso ?: JSONObject.NULL).put("p_to", toIso ?: JSONObject.NULL)
            .put("p_entity_table", table ?: JSONObject.NULL).put("p_actor", JSONObject.NULL).put("p_limit", 200))
    suspend fun auditExport(fromSeq: Long, toSeq: Long, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_audit_export", JSONObject().put("p_from_seq", fromSeq).put("p_to_seq", toSeq).put("p_reason", reason))
    suspend fun proposals(status: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_policy_proposals", JSONObject().put("p_status", status ?: JSONObject.NULL))
    suspend fun reviewPolicy(id: String, approve: Boolean, note: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_policy_review", JSONObject().put("p_proposal_id", id).put("p_decision", if (approve) "approve" else "reject").put("p_note", note),
            write = true, idempotencyKey = key)

    companion object {
        fun parse(a: JSONArray): List<Notice>? = try {
            (0 until a.length()).map { a.getJSONObject(it).let { o ->
                Notice(o.getString("id"), o.optString("category"), o.optString("priority", "critical"), o.optString("title_bn"), o.optString("body_bn"),
                    if (o.isNull("link_kind")) null else o.optString("link_kind").ifBlank { null }, if (o.isNull("link_id")) null else o.optString("link_id").ifBlank { null },
                    o.optString("created_at"), o.optBoolean("read", false)) } }
        } catch (e: Exception) { null }

        /** Verifies an exported bundle on the device: every prev_hash equals the previous row_hash (tamper evidence). */
        fun chainIntact(bundle: JSONObject): Boolean {
            val ev = bundle.optJSONArray("events") ?: return false
            for (i in 1 until ev.length()) if (ev.getJSONObject(i).optString("prev_hash") != ev.getJSONObject(i - 1).optString("row_hash")) return false
            return true
        }
    }
}

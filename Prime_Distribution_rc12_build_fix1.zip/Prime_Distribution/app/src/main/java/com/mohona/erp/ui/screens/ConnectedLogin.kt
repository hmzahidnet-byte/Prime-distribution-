package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.ConnectedStep
import com.mohona.erp.data.SessionState
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextMuted

/** Connected-mode actions (S16). The PIN is held only in this screen's state and cleared after each use. */
class ConnectedActions(
    val pinLogin: (phone: String, pin: String) -> Unit,
    val startOtp: (phone: String) -> Unit,
    val verifyOtp: (code: String) -> Unit,
    val setPin: (pin: String, confirm: String) -> Unit,
    val choosePosition: (assignmentId: String) -> Unit,
    val goTo: (ConnectedStep) -> Unit,
    val verifyMfa: (code: String) -> Unit = {}
)

@Composable
fun ConnectedLoginPanel(session: SessionState, actions: ConnectedActions) {
    var phone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)

    Column(Modifier.fillMaxWidth()) {
        when (session.step) {
            ConnectedStep.PIN_LOGIN -> {
                PhoneField(phone) { phone = it }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8) }, label = { Text("PIN") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = numeric, modifier = Modifier.fillMaxWidth())
                PrimaryButton("লগইন", session.loading) { actions.pinLogin(phone, pin); pin = "" }
                TextButton(onClick = { actions.goTo(ConnectedStep.OTP_PHONE) }) { Text("প্রথমবার লগইন / PIN ভুলে গেছেন") }
            }
            ConnectedStep.OTP_PHONE -> {
                Hint("আমন্ত্রিত মোবাইল নম্বরে একটি কোড পাঠানো হবে।")
                PhoneField(phone) { phone = it }
                PrimaryButton("কোড পাঠান", session.loading) { actions.startOtp(phone) }
                TextButton(onClick = { actions.goTo(ConnectedStep.PIN_LOGIN) }) { Text("PIN দিয়ে লগইনে ফিরুন") }
            }
            ConnectedStep.OTP_CODE -> {
                Hint("SMS-এ পাওয়া কোড লিখুন।")
                OutlinedTextField(value = code, onValueChange = { code = it.filter(Char::isDigit).take(8) }, label = { Text("কোড") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                PrimaryButton("যাচাই করুন", session.loading) { actions.verifyOtp(code); code = "" }
                TextButton(onClick = { actions.goTo(ConnectedStep.OTP_PHONE) }) { Text("আবার কোড পাঠান") }
            }
            ConnectedStep.PIN_SETUP -> {
                Hint("৬ অঙ্কের নতুন PIN — একই অঙ্ক বা ক্রমিক অঙ্ক নয়।")
                OutlinedTextField(value = pin, onValueChange = { pin = it.filter(Char::isDigit).take(8) }, label = { Text("নতুন PIN") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = numeric, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(value = pin2, onValueChange = { pin2 = it.filter(Char::isDigit).take(8) }, label = { Text("আবার PIN") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = numeric, modifier = Modifier.fillMaxWidth())
                PrimaryButton("PIN সংরক্ষণ", session.loading) { actions.setPin(pin, pin2); pin = ""; pin2 = "" }
            }
            ConnectedStep.MFA -> {
                session.mfaEnrollment?.let { e ->
                    Hint("Authenticator অ্যাপে (Google/Microsoft Authenticator) নতুন অ্যাকাউন্ট যোগ করুন — এই কী একবারই দেখানো হচ্ছে:")
                    Text(e.secret.chunked(4).joinToString(" "), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(e.uri, style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
                }
                OutlinedTextField(value = code, onValueChange = { code = it.filter(Char::isDigit).take(6) }, label = { Text("Authenticator কোড") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                PrimaryButton("যাচাই করে প্রবেশ", session.loading) { actions.verifyMfa(code); code = "" }
                TextButton(onClick = { actions.goTo(ConnectedStep.POSITION) }) { Text("অন্য পদ বেছে নিন") }
            }
            ConnectedStep.POSITION -> {
                Text("কোম্পানি ও পদ বেছে নিন", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                session.companies.forEach { c ->
                    Text(c.nameBn, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
                    c.positions.forEach { p ->
                        val enabled = p.usable && !session.loading
                        Text(
                            text = p.nameBn.ifBlank { p.positionCode } + when {
                                !p.usable -> " — এখন ব্যবহারযোগ্য নয়"
                                p.mfaRequired -> " — দুই-ধাপ যাচাই (Authenticator) লাগবে"
                                else -> ""
                            },
                            color = if (enabled) Color.Unspecified else TextMuted,
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).background(BackgroundGray)
                                .clickable(enabled = enabled) { actions.choosePosition(p.assignmentId) }.padding(12.dp)
                        )
                    }
                }
            }
        }
        session.info?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted, modifier = Modifier.padding(top = 8.dp)) }
        session.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = BadRed, modifier = Modifier.padding(top = 8.dp)) }
    }
}

@Composable
private fun PhoneField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = { onChange(it.take(20)) }, label = { Text("মোবাইল নম্বর") }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
}

@Composable
private fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = TextMuted, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun PrimaryButton(label: String, loading: Boolean, onClick: () -> Unit) {
    Spacer(Modifier.height(16.dp))
    Button(onClick = onClick, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)) {
        if (loading) CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
        else Text(label, style = MaterialTheme.typography.titleSmall)
    }
}

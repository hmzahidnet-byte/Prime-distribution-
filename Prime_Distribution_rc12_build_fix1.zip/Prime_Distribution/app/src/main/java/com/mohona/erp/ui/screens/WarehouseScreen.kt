package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import androidx.compose.foundation.layout.Arrangement
import com.mohona.erp.feature.actions.LookupField
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.stock.data.CountItem
import com.mohona.erp.feature.stock.data.WarehouseRepository
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray

/** Warehouse (S29–S31): stock report, bin QR lookup, blind cycle count (no system quantities shown to the counter). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WarehouseScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("report") }
    var rows by remember { mutableStateOf(JSONArray()) }
    var qr by remember { mutableStateOf("") }
    var warehouseId by remember { mutableStateOf("") }
    var count by remember { mutableStateOf<Pair<String, List<CountItem>>?>(null) }
    var counted by remember { mutableStateOf(mapOf<String, String>()) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("গুদাম", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("report" to "মজুদ-রিপোর্ট", "qr" to "বিন-QR", "count" to "গণনা").forEach { (k, l) -> FilterChip(selected = tab == k, onClick = { tab = k }, label = { Text(l) }) }
            }
            when (tab) {
                "report" -> {
                    OutlinedButton(onClick = { scope.launch { when (val r = AppContainer.warehouse?.report()) { is ApiResult.Ok -> rows = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) {
                        Text("রিপোর্ট আনুন")
                    }
                    (0 until rows.length()).map { rows.getJSONObject(it) }.forEach { o ->
                        Text("${o.optString("warehouse")} · ${o.optString("sku")} · লট ${o.optString("lot_no")} · ${o.optString("qty")} · ${o.optInt("age_days")} দিন" +
                            (if (o.isNull("value")) "" else " · " + Bn.money(o.optString("value"))), style = MaterialTheme.typography.labelSmall)
                    }
                }
                "qr" -> {
                    OutlinedTextField(value = qr, onValueChange = { qr = it.trim() }, label = { Text("বিন-লেবেলের লেখা (স্ক্যান)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(enabled = WarehouseRepository.parseBinQr(qr) != null, onClick = {
                        scope.launch {
                            when (val r = AppContainer.warehouse?.lookup(qr)) {
                                is ApiResult.Ok -> { val c = r.value.optJSONArray("contents") ?: JSONArray()
                                    message = r.value.optString("warehouse") + " / " + r.value.optString("bin") + ": " +
                                        (0 until c.length()).joinToString("; ") { c.getJSONObject(it).let { x -> x.optString("sku") + " " + x.optString("lot_no") + " = " + x.optString("qty") } } }
                                is ApiResult.Err -> message = r.error.messageBn
                                null -> Unit
                            }
                        }
                    }) { Text("দেখুন") }
                }
                else -> {
                    if (count == null) {
                        LookupField("গুদাম", "warehouse", false, warehouseId) { warehouseId = it.trim() }
                        OutlinedButton(enabled = warehouseId.length == 36, onClick = {
                            scope.launch { when (val r = AppContainer.warehouse?.startCount(warehouseId, "চক্র-গণনা", UUID.randomUUID().toString())) {
                                is ApiResult.Ok -> count = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } }
                        }) { Text("গণনা শুরু") }
                    } else count?.let { (id, items) ->
                        Text("প্রতিটি লট গুনে লিখুন (সিস্টেমের পরিমাণ দেখানো হয় না)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        items.forEach { it ->
                            OutlinedTextField(value = counted[it.lotId].orEmpty(), onValueChange = { v -> counted = counted + (it.lotId to v) }, label = { Text("লট " + it.lotNo) },
                                singleLine = true, modifier = Modifier.fillMaxWidth())
                        }
                        OutlinedButton(enabled = items.all { counted[it.lotId]?.toBigDecimalOrNull() != null }, onClick = {
                            scope.launch {
                                val repo = AppContainer.warehouse ?: return@launch
                                val rec = repo.recordCount(id, counted.mapValues { it.value.toBigDecimal() }, UUID.randomUUID().toString())
                                if (rec is ApiResult.Err) { message = rec.error.messageBn; return@launch }
                                when (val s = repo.submitCount(id, UUID.randomUUID().toString())) {
                                    is ApiResult.Ok -> { message = "জমা হয়েছে — পার্থক্য ${s.value.optInt("variances")}টি, অনুমোদনের অপেক্ষায়।"; count = null; counted = emptyMap() }
                                    is ApiResult.Err -> message = s.error.messageBn
                                }
                            }
                        }) { Text("গণনা জমা দিন") }
                    }
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

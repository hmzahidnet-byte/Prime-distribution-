package com.mohona.erp.feature.maps

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.modules.OfflineTileProvider
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon
import org.osmdroid.views.overlay.Polyline

data class MapPoint(val lat: Double, val lon: Double, val title: String)

/**
 * In-app map (osmdroid, no API key). Uses the downloaded region packages when present (works without network), otherwise online
 * OpenStreetMap tiles. Shows markers (dealers / consented field staff), one trail line and market boundaries. Attribution is always shown.
 */
@Composable
fun InAppMap(modifier: Modifier, markers: List<MapPoint>, trail: List<MapPoint>, boundaries: List<List<MapPoint>>, attribution: String,
             onTap: ((MapPoint) -> Unit)? = null) {
    AndroidView(modifier = modifier, factory = { context -> buildMap(context) }, update = { map ->
        map.overlays.clear()
        // tap = drop a pin / add a boundary corner (V166-03 pin drop, V166-16 market editor); nothing is saved without a confirm button
        if (onTap != null) map.overlays.add(org.osmdroid.views.overlay.MapEventsOverlay(object : org.osmdroid.events.MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean { onTap(MapPoint(p.latitude, p.longitude, "")); return true }
            override fun longPressHelper(p: GeoPoint): Boolean = false
        }))
        val outline = com.mohona.erp.ui.theme.DesignProps.color("map.marker.market", "color", androidx.compose.ui.graphics.Color(0xFF1456A0))
        boundaries.filter { it.size >= 2 }.forEach { ring ->
            if (ring.size >= 3) map.overlays.add(Polygon(map).apply {
                points = ring.map { GeoPoint(it.lat, it.lon) } + GeoPoint(ring[0].lat, ring[0].lon); title = ring[0].title
                outlinePaint.color = outline.toArgb(); outlinePaint.strokeWidth = com.mohona.erp.ui.theme.DesignProps.dp("map.marker.market", "stroke_dp", 3.dp).value * 2
            }) else map.overlays.add(Polyline(map).apply { setPoints(ring.map { GeoPoint(it.lat, it.lon) }) })
        }
        if (trail.size >= 2) map.overlays.add(Polyline(map).apply { setPoints(trail.map { GeoPoint(it.lat, it.lon) }) })
        markers.forEach { m -> map.overlays.add(Marker(map).apply { position = GeoPoint(m.lat, m.lon); title = m.title; setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM) }) }
        val first = markers.firstOrNull() ?: trail.firstOrNull() ?: boundaries.firstOrNull()?.firstOrNull()
        if (first != null) map.controller.setCenter(GeoPoint(first.lat, first.lon))
        map.contentDescription = "ম্যাপ · $attribution"
        map.invalidate()
    })
}

private fun buildMap(context: Context): MapView {
    Configuration.getInstance().userAgentValue = "PrimeDistribution/" + context.packageName
    val map = MapView(context)
    val offline = OfflineMapStore.installed(context)
    if (offline.isNotEmpty()) {
        runCatching {
            val provider = OfflineTileProvider(SimpleRegisterReceiver(context), offline.toTypedArray())
            map.setTileProvider(provider)
            val archives = provider.archives
            val source = archives.flatMap { it.tileSources }.firstOrNull()
            map.setTileSource(if (source != null) org.osmdroid.tileprovider.tilesource.FileBasedTileSource.getSource(source) else TileSourceFactory.MAPNIK)
            map.setUseDataConnection(false)
        }.onFailure { map.setTileSource(TileSourceFactory.MAPNIK) }
    } else {
        map.setTileSource(TileSourceFactory.MAPNIK)
    }
    map.setMultiTouchControls(true)
    map.controller.setZoom(12.0)
    map.controller.setCenter(GeoPoint(23.8103, 90.4125))      // Dhaka until data arrives
    return map
}

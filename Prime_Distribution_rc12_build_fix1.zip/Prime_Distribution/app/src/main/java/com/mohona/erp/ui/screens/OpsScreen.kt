package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import com.mohona.erp.feature.actions.LookupField
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.payroll.data.PayslipText
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Governance & operations (S53–S55) + own payslip (S47): read-only status for Chairman / auditor; payslip for everyone. */
@Composable
fun OpsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var gov by remember { mutableStateOf<JSONObject?>(null) }
    var ops by remember { mutableStateOf<JSONObject?>(null) }
    var reg by remember { mutableStateOf<JSONObject?>(null) }
    var runId by remember { mutableStateOf("") }
    var slip by remember { mutableStateOf<List<String>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        (AppContainer.ops?.governance() as? ApiResult.Ok)?.let { gov = it.value }
        (AppContainer.ops?.opsStatus() as? ApiResult.Ok)?.let { ops = it.value }
        (AppContainer.ops?.registry("failed") as? ApiResult.Ok)?.let { reg = it.value }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("পে-স্লিপ ও পরিচালনা", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("আমার পে-স্লিপ", style = MaterialTheme.typography.titleSmall)
            LookupField("পে-রান", "payroll_run", false, runId) { runId = it.trim() }
            OutlinedButton(enabled = runId.length == 36, onClick = { scope.launch {
                when (val r = AppContainer.payroll?.payslip(runId)) {
                    is ApiResult.Ok -> { slip = PayslipText.lines(r.value); message = null }
                    is ApiResult.Err -> { slip = emptyList(); message = r.error.messageBn }
                    null -> message = "সংযুক্ত মোড নয়।"
                } } }) { Text("দেখুন") }
            slip.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            gov?.let { g ->
                Text("শাসন-পরীক্ষা", style = MaterialTheme.typography.titleSmall)
                Text("চেয়ারম্যান-আসন ${g.optInt("chairman_seats")} · সক্রিয় দায়িত্ব-অর্পণ ${g.optInt("delegations_active")} · অপেক্ষমাণ অনুমোদন ${g.optInt("approvals_pending")} · আটকে থাকা হিসাব-পোস্টিং ${g.optInt("gl_events_waiting")}",
                    style = MaterialTheme.typography.labelSmall)
            }
            ops?.let { o ->
                Text("ব্যাকআপ", style = MaterialTheme.typography.titleSmall)
                Text("সর্বশেষ ব্যাকআপ: ${o.optJSONObject("last_backup")?.optString("finished_at") ?: "রেকর্ড নেই"} · এখনকার RPO ${o.optString("rpo_minutes_now", "—")} মিনিট",
                    style = MaterialTheme.typography.labelSmall)
                Text("সর্বশেষ রিকভারি-ড্রিল: ${o.optJSONObject("last_drill")?.let { "RPO ${it.optString("rpo")} · RTO ${it.optString("rto")} মিনিট" } ?: "এখনো হয়নি"}", style = MaterialTheme.typography.labelSmall)
            }
            reg?.let { r ->
                Text("রিলিজ-প্রমাণ", style = MaterialTheme.typography.titleSmall)
                Text("ফিচার ${r.optInt("features")} · প্রমাণিত ${r.optInt("passed")} · ব্যর্থ ${r.optInt("failed")}", style = MaterialTheme.typography.labelSmall)
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

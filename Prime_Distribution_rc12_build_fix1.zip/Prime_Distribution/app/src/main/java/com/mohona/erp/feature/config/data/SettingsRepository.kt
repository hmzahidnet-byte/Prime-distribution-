package com.mohona.erp.feature.config.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

/** One Chairman setting (config.setting_definition + the company's effective value). */
data class Setting(
    val key: String, val module: String, val valueType: String, val nameBn: String, val descriptionBn: String?,
    val defaultValue: Any?, val value: Any?, val isDefault: Boolean, val version: Int,
    val min: Double?, val max: Double?, val allowed: List<Any?>?, val isSensitive: Boolean, val requiresAal2: Boolean
) {
    /** Client-side pre-check mirroring config.fn_validate (the server validates again). */
    fun validate(candidate: Any?): String? {
        if (candidate == null || candidate == JSONObject.NULL) return "মান দিন"
        when (valueType) {
            "int", "numeric" -> {
                val n = (candidate as? Number)?.toDouble() ?: return "সংখ্যা দিন"
                if (valueType == "int" && n != Math.floor(n)) return "পূর্ণসংখ্যা দিন"
                if (min != null && n < min) return "সর্বনিম্ন ${min.toLong()}"
                if (max != null && n > max) return "সর্বোচ্চ ${max.toLong()}"
            }
            "bool" -> if (candidate !is Boolean) return "হ্যাঁ/না বেছে নিন"
            "text" -> if (candidate !is String) return "লেখা দিন"
            "text_array" -> if (candidate !is List<*> || candidate.any { it !is String }) return "তালিকা দিন"
        }
        val a = allowed ?: return null
        val items = if (valueType == "text_array") (candidate as List<*>) else listOf(candidate)
        return if (items.all { it in a }) null else "অনুমোদিত মান নয়"
    }
}

class SettingsRepository(private val client: SupabaseClient) {

    suspend fun list(module: String? = null): ApiResult<List<Setting>> =
        when (val r = client.rpcArray("v1_config_settings", JSONObject().put("p_module", module ?: JSONObject.NULL))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parse(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_config_settings"))
        }

    suspend fun set(key: String, value: Any, expectedVersion: Int, reason: String, idempotencyKey: String): ApiResult<Int> =
        when (val r = client.rpc("v1_config_set", JSONObject().put("p_key", key).put("p_value", toJson(value))
            .put("p_expected_version", expectedVersion).put("p_reason", reason), write = true, idempotencyKey = idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok((r.value as? Number)?.toInt() ?: 0)
        }

    suspend fun reset(key: String, expectedVersion: Int, reason: String, idempotencyKey: String): ApiResult<Int> =
        when (val r = client.rpc("v1_config_reset", JSONObject().put("p_key", key).put("p_expected_version", expectedVersion)
            .put("p_reason", reason), write = true, idempotencyKey = idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok((r.value as? Number)?.toInt() ?: 0)
        }

    companion object {
        fun toJson(v: Any): Any = if (v is List<*>) JSONArray(v) else v

        private fun plain(v: Any?): Any? = when (v) {
            null, JSONObject.NULL -> null
            is JSONArray -> (0 until v.length()).map { plain(v.get(it)) }
            else -> v
        }

        fun parse(a: JSONArray): List<Setting>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Setting(o.getString("key"), o.getString("module"), o.getString("value_type"), o.getString("name_bn"),
                    if (o.isNull("description_bn")) null else o.optString("description_bn"),
                    plain(o.opt("default_value")), plain(o.opt("value")), o.optBoolean("is_default", true), o.optInt("version", 0),
                    if (o.isNull("min_value")) null else o.optDouble("min_value"), if (o.isNull("max_value")) null else o.optDouble("max_value"),
                    (plain(o.opt("allowed_values")) as? List<*>)?.toList(), o.optBoolean("is_sensitive"), o.optBoolean("requires_aal2"))
            }
        } catch (e: Exception) { null }
    }
}

package com.mohona.erp.ui.screens

import android.content.Context
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.feature.design.data.ActiveDesign
import com.mohona.erp.feature.design.data.LayoutGrid
import com.mohona.erp.feature.kpi.data.AdRotation
import com.mohona.erp.feature.kpi.data.KpiFormat
import com.mohona.erp.feature.kpi.data.KpiQuery
import com.mohona.erp.feature.kpi.data.KpiRepository
import com.mohona.erp.ui.components.KpiChart
import com.mohona.erp.feature.kpi.data.KpiValue
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.GoodGreen
import com.mohona.erp.ui.theme.TextMuted
import java.io.FileOutputStream
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray

private val PERIODS = listOf("today" to "আজ", "yesterday" to "গতকাল", "this_week" to "এই সপ্তাহ", "this_month" to "এই মাস", "last_month" to "গত মাস", "this_year" to "এই বছর")

/**
 * KPI dashboard (S20): the published layout of the screen (or every visible KPI), Bengali figures with a coloured change
 * vs. the previous period, restricted KPIs shown as "গোপন" (never a number), tap = authorised drilldown, ads below the
 * approval panel (two at a time), print / save as PDF through the system dialog (server-redacted data).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(design: ActiveDesign?, screenKey: String, onBack: () -> Unit, onApprovals: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val perms = LocalPermissions.current
    var query by remember { mutableStateOf(KpiQuery()) }
    var values by remember { mutableStateOf<List<KpiValue>>(emptyList()) }
    var drill by remember { mutableStateOf<Pair<String, JSONArray>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val layout = design?.layouts?.get(screenKey)
    LaunchedEffect(query, layout) {
        val repo = AppContainer.kpi ?: run { message = "সংযুক্ত মোড নয়।"; return@LaunchedEffect }
        val codes = layout?.phone?.widgets?.mapNotNull { KpiRepository.codeOf(it.binding) }?.distinct()?.takeIf { it.isNotEmpty() }
            ?: (repo.catalog() as? ApiResult.Ok)?.value?.let { a -> (0 until a.length()).map { a.getJSONObject(it).getString("code") } }?.take(30) ?: emptyList()
        if (codes.isEmpty()) { values = emptyList(); return@LaunchedEffect }
        val cache = AppContainer.kpiCache
        val missing = codes.filter { cache.get(query.key(it)) == null }
        val fetched = HashMap<String, KpiValue>()
        if (missing.isNotEmpty()) {
            when (val r = repo.values(missing, query)) {
                is ApiResult.Ok -> r.value.forEach { cache.put(query.key(it.code), it); fetched[it.code] = it }
                is ApiResult.Err -> message = r.error.messageBn
            }
        }
        values = codes.mapNotNull { c -> cache.get(query.key(c)) ?: fetched[c] }
    }
    LaunchedEffect(Unit) { while (true) { delay(8000); tick++ } }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("ড্যাশবোর্ড", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PERIODS.forEach { (k, label) -> FilterChip(selected = query.period == k, onClick = { query = query.copy(period = k) }, label = { Text(label) }) }
            }
            val widgets = layout?.phone?.widgets?.sortedWith(compareBy({ it.y }, { it.x }))
            if (widgets == null) values.forEach { v ->
                KpiCard(v) { code -> scope.launch { (AppContainer.kpi?.drilldown(code, query) as? ApiResult.Ok)?.let { d -> drill = code to d.value } } }
                if (!v.restricted && v.style.chart != "number") KpiChart(v, if (query.period == "this_year") "month" else "day", null, null, query.wingId)
            }
            else widgets.forEach { w ->
                when (w.type) {
                    "kpi", "chart" -> values.firstOrNull { it.code == KpiRepository.codeOf(w.binding) }?.let { v ->
                        KpiCard(v) { code -> scope.launch { (AppContainer.kpi?.drilldown(code, query) as? ApiResult.Ok)?.let { d -> drill = code to d.value } } }
                        // a chart widget, or a KPI the Chairman styled as a graph, draws the server series / split under the figure
                        if (!v.restricted && (w.type == "chart" || v.style.chart != "number")) {
                            val styled = if (w.type == "chart" && v.style.chart == "number") v.copy(style = v.style.copy(chart = "line")) else v
                            KpiChart(styled, if (query.period == "this_year") "month" else "day", null, null, query.wingId)
                        }
                    } ?: Text("${w.binding ?: w.id}: এই KPI এখনো নেই", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    "approval" -> if (PermissionHints.can(perms, "approval.inbox.read")) AppCard(onClick = onApprovals) {
                        Text("অনুমোদনের অপেক্ষায় — খুলুন", Modifier.padding(14.dp), fontWeight = FontWeight.SemiBold)
                    }
                    "ad_slot" -> if (design != null && design.ads) {
                        val media = design.adMedia
                        AdRotation.visible(media.map { it.first }, design.adsVisibleMax, tick).forEach { slot ->
                            media.firstOrNull { it.first == slot }?.let { Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(com.mohona.erp.ui.theme.BackgroundGray).padding(12.dp)) {
                                Text("বিজ্ঞাপন: " + it.second, style = MaterialTheme.typography.labelSmall) } }
                        }
                    }
                    else -> Unit
                }
            }
            drill?.let { (code, rows) ->
                Text("বিস্তারিত: $code (${rows.length()})", style = MaterialTheme.typography.titleSmall)
                (0 until rows.length()).map { rows.getJSONObject(it) }.forEach { r -> Text(r.toString().take(160), style = MaterialTheme.typography.labelSmall) }
            }
            if (PermissionHints.can(perms, "kpi.export")) OutlinedButton(onClick = {
                scope.launch {
                    when (val r = AppContainer.kpi?.export(values.map { it.code }.ifEmpty { listOf("approvals.pending") }, query, "pdf")) {
                        is ApiResult.Ok -> KpiPrint.print(context, "KPI " + query.period, r.value.optJSONArray("rows") ?: JSONArray())
                        is ApiResult.Err -> message = r.error.messageBn
                        null -> Unit
                    }
                }
            }) { Text("প্রিন্ট / PDF") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

@Composable
private fun KpiCard(v: KpiValue, onDrill: (String) -> Unit) {
    AppCard(onClick = if (v.restricted) null else ({ onDrill(v.code) })) {
        Column(Modifier.padding(14.dp)) {
            Text(v.nameBn, style = MaterialTheme.typography.labelMedium, color = TextMuted)
            val base = if (v.style.size == "l") MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge
            Text(KpiFormat.value(v), style = base.copy(fontSize = base.fontSize * com.mohona.erp.ui.theme.DesignProps.scale("kpi.card")), fontWeight = FontWeight.Bold,
                 color = com.mohona.erp.ui.theme.DesignProps.color("kpi.card", "color", MaterialTheme.colorScheme.onSurface))
            KpiFormat.delta(v)?.let { (text, tone) ->
                Text(text, style = MaterialTheme.typography.labelSmall, color = when (tone) { KpiFormat.Tone.GOOD -> GoodGreen; KpiFormat.Tone.BAD -> BadRed; else -> TextMuted })
            }
        }
    }
}

/** System print dialog (also "Save as PDF"). Prints exactly the server's export rows — restricted figures arrive redacted. */
object KpiPrint {
    fun print(context: Context, title: String, rows: JSONArray) {
        val pm = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        pm.print(title, object : PrintDocumentAdapter() {
            private var attrs: PrintAttributes? = null
            override fun onLayout(old: PrintAttributes?, new: PrintAttributes, cancel: CancellationSignal?, cb: LayoutResultCallback, extras: Bundle?) {
                attrs = new
                if (cancel?.isCanceled == true) { cb.onLayoutCancelled(); return }
                cb.onLayoutFinished(PrintDocumentInfo.Builder("kpi.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(), true)
            }
            override fun onWrite(pages: Array<out PageRange>?, dest: ParcelFileDescriptor, cancel: CancellationSignal?, cb: WriteResultCallback) {
                val doc = PrintedPdfDocument(context, attrs ?: PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build())
                val page = doc.startPage(0)
                val paint = android.graphics.Paint().apply { textSize = 12f }
                var y = 40f
                page.canvas.drawText(title, 40f, y, paint.apply { isFakeBoldText = true }); paint.isFakeBoldText = false
                for (i in 0 until rows.length()) {
                    val r = rows.getJSONObject(i); y += 22f
                    page.canvas.drawText(r.optString("name_bn", r.optString("code")) + ": " + r.opt("value")?.toString().orEmpty(), 40f, y, paint)
                }
                doc.finishPage(page)
                try { FileOutputStream(dest.fileDescriptor).use { doc.writeTo(it) }; cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES)) }
                catch (e: Exception) { cb.onWriteFailed(e.message) } finally { doc.close() }
            }
        }, null)
    }
}

package com.mohona.erp.core.cache

/** Whose view of the data a cached value belongs to. Switching person, company or active position never reuses entries. */
data class CacheScope(val personId: String, val companyId: String, val positionId: String) {
    internal fun prefix(): String = "$personId|$companyId|$positionId|"
}

/**
 * Cache policy (docs/ANDROID_ARCHITECTURE_BN.md §৫):
 * - Memory only; nothing business-related is written to disk on the device.
 * - Sensitive data (P&L, payroll, salary, payslip, personal HR data) is NEVER cached.
 * - Everything is dropped on sign-out, session loss, company/position switch or a server "permissions changed" signal.
 */
object CachePolicy {
    private val sensitiveMarkers = listOf("pnl", "profit", "payroll", "salary", "payslip", "personal", "bank_account")
    const val DEFAULT_TTL_MS: Long = 60_000L
    const val REFERENCE_TTL_MS: Long = 10 * 60_000L

    fun isSensitive(key: String): Boolean = sensitiveMarkers.any { key.lowercase().contains(it) }
}

class MemoryCache(
    private val nowMs: () -> Long = { System.currentTimeMillis() },
    private val maxEntries: Int = 256
) {
    private class Entry(val value: Any, val expiresAt: Long)

    private val map = object : LinkedHashMap<String, Entry>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Entry>?): Boolean = size > maxEntries
    }

    @Synchronized
    fun getRaw(scope: CacheScope, key: String): Any? {
        val k = scope.prefix() + key
        val e = map[k] ?: return null
        if (nowMs() >= e.expiresAt) { map.remove(k); return null }
        return e.value
    }

    inline fun <reified T> get(scope: CacheScope, key: String): T? = getRaw(scope, key) as? T

    /** Returns false (and stores nothing) for sensitive keys or a non-positive TTL. */
    @Synchronized
    fun put(scope: CacheScope, key: String, value: Any, ttlMs: Long = CachePolicy.DEFAULT_TTL_MS): Boolean {
        if (ttlMs <= 0 || CachePolicy.isSensitive(key)) return false
        map[scope.prefix() + key] = Entry(value, nowMs() + ttlMs)
        return true
    }

    @Synchronized
    fun invalidate(scope: CacheScope, keyPrefix: String = "") {
        val p = scope.prefix() + keyPrefix
        map.keys.removeAll { it.startsWith(p) }
    }

    @Synchronized
    fun clearAll() = map.clear()

    @Synchronized
    fun size(): Int = map.size
}

package com.mohona.erp.feature.crm.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import org.json.JSONArray
import org.json.JSONObject

/** Dealer CRM (S40): dealers, retailers, ledger, credit, visits, contacts, statements, signed dealer QR. */
class CrmRepository(private val client: SupabaseClient) {
    suspend fun dealers(text: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_dealers", JSONObject().put("p_text", text ?: JSONObject.NULL))
    suspend fun dealer(id: String): ApiResult<JSONObject> = client.rpcObject("v1_dealer_get", JSONObject().put("p_dealer_id", id))
    suspend fun creditCheck(id: String, amount: BigDecimal): ApiResult<JSONObject> =
        client.rpcObject("v1_credit_check", JSONObject().put("p_dealer_id", id).put("p_amount", amount))
    suspend fun statement(id: String, from: String?, to: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_dealer_statement", JSONObject().put("p_dealer_id", id).put("p_from", from ?: JSONObject.NULL).put("p_to", to ?: JSONObject.NULL))
    suspend fun contactLink(contactId: String, channel: String, note: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_dealer_contact_link", JSONObject().put("p_contact_id", contactId).put("p_channel", channel).put("p_note", note ?: JSONObject.NULL), write = true)
    suspend fun planVisit(dealerId: String?, retailerId: String?, dateIso: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_visit_plan", JSONObject().put("p_dealer_id", dealerId ?: JSONObject.NULL).put("p_retailer_id", retailerId ?: JSONObject.NULL)
            .put("p_planned_date", dateIso ?: JSONObject.NULL), write = true)
    suspend fun recordVisit(visitId: String, outcome: String, notes: String?, lat: Double?, lon: Double?): ApiResult<JSONObject> =
        client.rpcObject("v1_visit_record", JSONObject().put("p_visit_id", visitId).put("p_outcome", outcome).put("p_notes", notes ?: JSONObject.NULL)
            .put("p_latitude", lat ?: JSONObject.NULL).put("p_longitude", lon ?: JSONObject.NULL), write = true)
    suspend fun locationConsent(grant: Boolean, note: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_location_consent", JSONObject().put("p_grant", grant).put("p_note", note ?: JSONObject.NULL), write = true)
    suspend fun creditException(dealerId: String, amount: BigDecimal, validUntil: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_credit_exception_request", JSONObject().put("p_dealer_id", dealerId).put("p_amount", amount).put("p_valid_until", validUntil)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun qrLookup(payload: String): ApiResult<JSONObject> = client.rpcObject("v1_dealer_qr_lookup", JSONObject().put("p_payload", payload))
}

/** Client mirror of the statement aging (FIFO: credits settle the oldest debits first). */
object DealerAging {
    data class Entry(val date: LocalDate, val amount: BigDecimal, val due: LocalDate?)

    fun buckets(entries: List<Entry>, creditDays: Int, asOf: LocalDate): Map<String, BigDecimal> {
        val out = linkedMapOf("current" to BigDecimal.ZERO, "d1_30" to BigDecimal.ZERO, "d31_60" to BigDecimal.ZERO, "d61_90" to BigDecimal.ZERO, "d90_plus" to BigDecimal.ZERO)
        var credit = entries.filter { it.amount.signum() < 0 && !it.date.isAfter(asOf) }.fold(BigDecimal.ZERO) { a, e -> a - e.amount }
        for (d in entries.filter { it.amount.signum() > 0 && !it.date.isAfter(asOf) }.sortedBy { it.date }) {
            val left = (d.amount - credit).max(BigDecimal.ZERO); credit = (credit - d.amount).max(BigDecimal.ZERO)
            if (left.signum() == 0) continue
            val due = d.due ?: d.date.plusDays(creditDays.toLong())
            val late = ChronoUnit.DAYS.between(due, asOf)
            val k = when { late <= 0 -> "current"; late <= 30 -> "d1_30"; late <= 60 -> "d31_60"; late <= 90 -> "d61_90"; else -> "d90_plus" }
            out[k] = out.getValue(k) + left
        }
        return out
    }
}

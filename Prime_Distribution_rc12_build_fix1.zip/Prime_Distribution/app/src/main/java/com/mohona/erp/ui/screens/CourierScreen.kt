package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import java.time.Instant
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Courier centre (v180): shipments with condition / collected / shortfall, shipment detail, reporting a courier
 * collection (money the COURIER holds — the company's cash does not move), and — for the Chairman — the money
 * requests waiting for the final decision and the company chain figures.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CourierScreen(chairmanView: Boolean, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(if (chairmanView) "money" else "shipments") }
    var rows by remember { mutableStateOf(JSONArray()) }
    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var chain by remember { mutableStateOf<JSONObject?>(null) }
    var amount by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab, reload) {
        val repo = AppContainer.courier ?: run { message = "সংযুক্ত মোড নয়।"; return@LaunchedEffect }
        rows = JSONArray(); chain = null
        when (tab) {
            "shipments" -> when (val r = repo.shipments()) { is ApiResult.Ok -> rows = r.value; is ApiResult.Err -> message = r.error.messageBn }
            "money" -> when (val r = repo.moneyRequests()) { is ApiResult.Ok -> rows = r.value; is ApiResult.Err -> message = r.error.messageBn }
            else -> when (val r = repo.chairmanChain(null, null)) { is ApiResult.Ok -> chain = r.value; is ApiResult.Err -> message = r.error.messageBn }
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (chairmanView) "চেয়ারম্যান প্যানেল" else "কুরিয়ার", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val tabs = if (chairmanView) listOf("money" to "অর্থ-অনুমোদন", "chain" to "কোম্পানির হিসাব-শৃঙ্খল", "shipments" to "চালান") else listOf("shipments" to "চালান")
                tabs.forEach { (k, l) -> FilterChip(selected = tab == k, onClick = { tab = k; detail = null }, label = { Text(l) }) }
            }
            when (tab) {
                "shipments" -> (0 until rows.length()).map { rows.getJSONObject(it) }.forEach { s ->
                    AppCard(onClick = { scope.launch { (AppContainer.courier?.shipment(s.getString("id")) as? ApiResult.Ok)?.let { detail = it.value } } }) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${s.optString("number")} · ${s.optString("dealer")} · ${s.optString("courier")}", style = MaterialTheme.typography.bodyMedium)
                            Text("${s.optString("destination")} · কন্ডিশন ${Bn.money(s.optString("condition"))} · কুরিয়ারের হাতে আদায় ${Bn.money(s.optString("collected"))} · ${s.optString("status")}",
                                style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            if ((s.optString("shortfall").toBigDecimalOrNull()?.signum() ?: 0) > 0) {
                                Text("অমীমাংসিত ঘাটতি ${Bn.money(s.optString("shortfall"))}", style = MaterialTheme.typography.labelSmall, color = BadRed)
                            }
                        }
                    }
                }
                "money" -> {
                    if (rows.length() == 0) Text("অনুমোদনের অপেক্ষায় কিছু নেই।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    (0 until rows.length()).map { rows.getJSONObject(it) }.forEach { q ->
                        AppCard {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${q.optString("number")} · ${q.optString("kind")} · ${Bn.money(q.optString("amount"))}", style = MaterialTheme.typography.bodyMedium)
                                Text(q.optString("reason") + if (q.optBoolean("missing_evidence")) " · প্রমাণ অনুপস্থিত" else "", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(true to "অনুমোদন", false to "প্রত্যাখ্যান").forEach { (ok, label) ->
                                        OutlinedButton(onClick = { scope.launch {
                                            when (val r = AppContainer.courier?.decideMoneyRequest(q.getString("id"), ok)) {
                                                is ApiResult.Ok -> { message = "সিদ্ধান্ত নেওয়া হয়েছে।"; reload++ }
                                                is ApiResult.Err -> message = r.error.messageBn
                                                null -> Unit
                                            } } }) { Text(label) }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> chain?.let { c ->
                    listOf("purchases" to "ক্রয়", "production_cost" to "উৎপাদন-খরচ", "sales" to "বিক্রয়", "returns" to "ফেরত", "cost_of_sales" to "বিক্রীত পণ্যের খরচ",
                        "courier_freight" to "কুরিয়ার-ভাড়া", "concessions" to "ছাড়/মওকুফ", "expenses" to "খরচ", "payroll" to "বেতন", "result" to "ফলাফল").forEach { (k, l) ->
                        Text(l + ": " + if (c.isNull(k)) "তথ্য নেই" else "" + Bn.money(c.optString(k)), style = MaterialTheme.typography.bodySmall)
                    }
                    Text(c.optString("note_bn"), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
            detail?.let { d ->
                Text("${d.optString("number")} — ${d.optString("status")}", style = MaterialTheme.typography.titleSmall)
                Text("কুরিয়ারের হাতে আদায় কোম্পানির নগদ নয়; জমা যাচাই ও চেয়ারম্যানের অনুমোদনের পর খাতায় আসে।", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("কুরিয়ার আদায় করেছে (৳)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton(enabled = (amount.toBigDecimalOrNull()?.signum() ?: 0) > 0, onClick = { scope.launch {
                    when (val r = AppContainer.courier?.reportCollection(d.getString("id"), amount.toBigDecimal(), Instant.now().toString(), UUID.randomUUID().toString())) {
                        is ApiResult.Ok -> { message = "আদায় রিপোর্ট হয়েছে — যাচাইয়ের অপেক্ষায়।"; amount = ""; reload++ }
                        is ApiResult.Err -> message = r.error.messageBn
                        null -> Unit
                    } } }) { Text("আদায় রিপোর্ট করুন") }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

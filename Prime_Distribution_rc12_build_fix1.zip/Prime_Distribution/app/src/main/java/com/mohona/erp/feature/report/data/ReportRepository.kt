package com.mohona.erp.feature.report.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

/** Custom reports (S52): whitelisted datasets and approved templates only — the app never sends SQL. */
class ReportRepository(private val client: SupabaseClient) {
    suspend fun datasets(): ApiResult<JSONArray> = client.rpcArray("v1_report_datasets")
    suspend fun templates(): ApiResult<JSONArray> = client.rpcArray("v1_report_templates")
    suspend fun saveTemplate(code: String, nameBn: String, dataset: String, spec: JSONObject): ApiResult<JSONObject> =
        client.rpcObject("v1_report_template_save", JSONObject().put("p_code", code).put("p_name_bn", nameBn).put("p_dataset", dataset).put("p_spec", spec), write = true)
    suspend fun templateAction(id: String, action: String): ApiResult<JSONObject> =
        client.rpcObject("v1_report_template_action", JSONObject().put("p_template_id", id).put("p_action", action), write = true)
    suspend fun run(templateId: String, fromIso: String?, toIso: String?, format: String): ApiResult<JSONObject> =
        client.rpcObject("v1_report_run", JSONObject().put("p_template_id", templateId)
            .put("p_filters", JSONObject().apply { if (fromIso != null) put("from", fromIso); if (toIso != null) put("to", toIso) }).put("p_format", format))
    suspend fun share(outputId: String, recipientId: String, days: Int): ApiResult<JSONObject> =
        client.rpcObject("v1_report_share", JSONObject().put("p_output_id", outputId).put("p_recipient", recipientId).put("p_days", days), write = true)
}

/** Bar lengths for the simple chart (F298): each row shows its value as text too, so the chart never is the only carrier. */
object ReportChart {
    data class Bar(val label: String, val value: BigDecimal, val fraction: Float)

    fun bars(rows: JSONArray, labelKey: String): List<Bar> {
        val items = (0 until rows.length()).map { rows.getJSONObject(it) }.map { it.optString(labelKey) to (it.optString("value").toBigDecimalOrNull() ?: BigDecimal.ZERO) }
        val max = items.maxOfOrNull { it.second.abs() } ?: BigDecimal.ZERO
        return items.map { (l, v) -> Bar(l, v, if (max.signum() == 0) 0f else v.abs().toFloat() / max.toFloat()) }
    }

    /** CSV export of an output; values are quoted, masked columns arrive as null and stay empty. */
    fun csv(rows: JSONArray): String {
        if (rows.length() == 0) return ""
        val keys = rows.getJSONObject(0).keys().asSequence().toList()
        val sb = StringBuilder(keys.joinToString(",") { q(it) }).append('\n')
        for (i in 0 until rows.length()) { val o = rows.getJSONObject(i); sb.append(keys.joinToString(",") { k -> if (o.isNull(k)) "" else q(o.optString(k)) }).append('\n') }
        return sb.toString()
    }
    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
}

package com.mohona.erp.feature.maps

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** One region package from api.v1_map_packages (the server catalogue). */
data class MapPackage(val id: String, val region: String, val nameBn: String, val version: Int, val url: String, val sha256: String,
                      val sizeBytes: Long, val minZoom: Int, val maxZoom: Int, val attribution: String, val current: Boolean) {
    val fileName: String get() = "region_${region.replace('.', '_')}_v$version.sqlite"
}

/**
 * V162-12 offline Bangladesh maps: download a region package over HTTPS, verify its SHA-256 before use, keep the company's disk quota
 * (oldest packages are removed first), list / remove installed packages. Map tiles are public data (no personal data inside);
 * GPS works without network, the server is only needed for the catalogue.
 */
object OfflineMapStore {
    fun dir(context: Context): File = File(context.filesDir, "maps").apply { mkdirs() }

    fun parse(catalogue: JSONObject): Pair<Int, List<MapPackage>> {
        val quota = catalogue.optInt("quota_mb", 512)
        val arr = catalogue.optJSONArray("packages") ?: return quota to emptyList()
        val list = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val url = o.optString("url")
            if (!url.startsWith("https://") || !Regex("^[0-9a-f]{64}$").matches(o.optString("sha256"))) return@mapNotNull null
            MapPackage(o.optString("package_id"), o.optString("region_code"), o.optString("name_bn"), o.optInt("version"), url, o.optString("sha256"),
                o.optLong("size_bytes"), o.optInt("min_zoom"), o.optInt("max_zoom"), o.optString("attribution"), o.optBoolean("current"))
        }
        return quota to list
    }

    fun installed(context: Context): List<File> = dir(context).listFiles { f -> f.name.endsWith(".sqlite") }?.sortedBy { it.lastModified() } ?: emptyList()

    fun usedBytes(context: Context): Long = installed(context).sumOf { it.length() }

    fun sha256(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val buf = ByteArray(64 * 1024); while (true) { val n = input.read(buf); if (n < 0) break; md.update(buf, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Frees space for [needed] bytes inside [quotaBytes], removing the oldest packages; false when it cannot fit at all. */
    fun makeRoom(context: Context, needed: Long, quotaBytes: Long): Boolean {
        if (needed > quotaBytes) return false
        val files = installed(context).toMutableList()
        var used = files.sumOf { it.length() }
        while (used + needed > quotaBytes && files.isNotEmpty()) { val f = files.removeAt(0); used -= f.length(); f.delete() }
        return used + needed <= quotaBytes
    }

    /** Downloads into a temp file, checks size and SHA-256, then moves it in place. Returns a Bengali message. */
    suspend fun install(context: Context, p: MapPackage, quotaMb: Int): String = withContext(Dispatchers.IO) {
        val target = File(dir(context), p.fileName)
        if (target.exists() && sha256(target) == p.sha256) return@withContext "আগেই নামানো আছে।"
        if (!makeRoom(context, p.sizeBytes, quotaMb.toLong() * 1024 * 1024)) return@withContext "জায়গা নেই: সীমা $quotaMb MB।"
        val tmp = File(dir(context), p.fileName + ".part")
        runCatching {
            val conn = URL(p.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000; conn.readTimeout = 60_000; conn.instanceFollowRedirects = false
            try {
                if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
                conn.inputStream.use { input -> tmp.outputStream().use { out -> input.copyTo(out, 64 * 1024) } }
            } finally { conn.disconnect() }
        }.onFailure { tmp.delete(); return@withContext "নামানো যায়নি — নেটওয়ার্ক দেখে আবার চেষ্টা করুন।" }
        if (tmp.length() != p.sizeBytes || sha256(tmp) != p.sha256) { tmp.delete(); return@withContext "ফাইল যাচাইয়ে মেলেনি (SHA-256) — বাতিল করা হলো।" }
        installed(context).filter { it.name.startsWith("region_${p.region.replace('.', '_')}_v") }.forEach { it.delete() }   // one version per region
        if (!tmp.renameTo(target)) { tmp.delete(); return@withContext "ফাইল রাখা যায়নি।" }
        "নামানো ও যাচাই সম্পন্ন: ${p.nameBn} (সংস্করণ ${p.version})।"
    }
}

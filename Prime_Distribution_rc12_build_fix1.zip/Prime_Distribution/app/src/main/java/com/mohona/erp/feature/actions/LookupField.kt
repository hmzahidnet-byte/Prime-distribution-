package com.mohona.erp.feature.actions

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** One row of a search list: the id sent to the server, what a person reads, and a second line. */
data class LookupItem(val id: String, val label: String, val sub: String)

/**
 * Parameter name -> list kind (assets/lookup_kinds.json, generated together with api.v1_lookup by tools/gen_lookup.py,
 * so the app never asks for a list the server does not have).
 */
object LookupKinds {
    @Volatile private var map: Map<String, String> = emptyMap()

    fun load(json: String) {
        map = runCatching {
            val o = JSONObject(json).getJSONObject("params")
            o.keys().asSequence().associateWith { o.getString(it) }
        }.getOrDefault(emptyMap())
    }

    fun kindFor(param: String): String? = map[param]

    fun parse(value: Any?): List<LookupItem> {
        val arr = value as? JSONArray ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            if (id.isBlank()) null else LookupItem(id, o.optString("label", id), if (o.isNull("sub")) "" else o.optString("sub"))
        }
    }
}

/**
 * A search box instead of a raw id: type a few letters (name, code, number), pick a row. The chosen row's id is the value.
 * When the list is refused (no right for this list, offline) the field falls back to typing the id, so no form is blocked.
 */
@Composable
fun LookupField(label: String, kind: String, optional: Boolean, value: String, onValue: (String) -> Unit) {
    var query by remember(kind) { mutableStateOf("") }
    var chosen by remember(kind) { mutableStateOf<LookupItem?>(null) }
    var rows by remember(kind) { mutableStateOf<List<LookupItem>>(emptyList()) }
    var open by remember(kind) { mutableStateOf(false) }
    var manual by remember(kind) { mutableStateOf(false) }
    var note by remember(kind) { mutableStateOf<String?>(null) }

    LaunchedEffect(kind, query, open, manual) {
        if (!open || manual) return@LaunchedEffect
        delay(300)                                                       // wait until typing pauses
        val client = AppContainer.client
        if (client == null) { note = "সংযুক্ত মোড নয় — আইডি হাতে লিখুন।"; manual = true; return@LaunchedEffect }
        val p = JSONObject().put("p_kind", kind).put("p_query", query.trim().ifEmpty { JSONObject.NULL }).put("p_limit", 20)
        when (val r = client.rpc("v1_lookup", p)) {
            is ApiResult.Ok -> { rows = LookupKinds.parse(r.value); note = if (rows.isEmpty()) "কিছু পাওয়া যায়নি" else null }
            is ApiResult.Err -> { rows = emptyList(); note = r.error.messageBn + " — আইডি হাতে লিখুন।"; manual = true }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (manual) {
            OutlinedTextField(value = value, onValueChange = onValue, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("$label (আইডি)" + if (optional) " · ঐচ্ছিক" else "") })
            TextButton(onClick = { manual = false; note = null; open = true }) { Text("তালিকা থেকে বাছুন") }
        } else {
            val c = chosen
            OutlinedTextField(
                value = if (c != null && c.id == value && !open) c.label else query,
                onValueChange = { query = it; open = true },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("$label — খুঁজুন" + if (optional) " · ঐচ্ছিক" else "") },
                supportingText = { if (c != null && c.id == value) Text(c.sub.ifBlank { "বাছাই করা হয়েছে" }, color = TextMuted) }
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!open) TextButton(onClick = { open = true }) { Text("তালিকা দেখুন") }
                if (value.isNotBlank()) TextButton(onClick = { onValue(""); chosen = null; query = "" }) { Text("মুছুন") }
                TextButton(onClick = { manual = true; open = false }) { Text("আইডি হাতে") }
            }
            if (open) {
                rows.take(12).forEach { r ->
                    Column(Modifier.fillMaxWidth().clickable { chosen = r; onValue(r.id); open = false; query = "" }.padding(vertical = 6.dp, horizontal = 4.dp)) {
                        Text(r.label, style = MaterialTheme.typography.bodyMedium)
                        if (r.sub.isNotBlank()) Text(r.sub, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
        }
        note?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = if (manual) BadRed else TextMuted) }
    }
}

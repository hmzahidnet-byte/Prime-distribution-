package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.stock.data.Balance
import com.mohona.erp.feature.stock.data.LotRow
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.launch

/** Stock (S25): balances per warehouse (available after reservations, cost only for cost readers), lots with expiry. */
@Composable
fun StockScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var rows by remember { mutableStateOf<List<Balance>>(emptyList()) }
    var lots by remember { mutableStateOf<Pair<String, List<LotRow>>?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        when (val r = AppContainer.stock?.balances()) { is ApiResult.Ok -> rows = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("মজুদ", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            rows.forEach { b ->
                AppCard(onClick = { scope.launch { (AppContainer.stock?.lots(b.productId, b.warehouseId) as? ApiResult.Ok)?.let { lots = b.sku to it.value } } }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(b.nameBn + " · " + b.sku, style = MaterialTheme.typography.bodyMedium)
                        Text("মজুদ ${b.qty.stripTrailingZeros().toPlainString()} ${b.unit} · ব্যবহারযোগ্য ${b.available.stripTrailingZeros().toPlainString()}" +
                            (b.avgCost?.let { " · গড় ৳" + Bn.digits(it.stripTrailingZeros().toPlainString()) } ?: ""), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        if (b.belowMin) Text("ন্যূনতম মজুদের নিচে", style = MaterialTheme.typography.labelSmall, color = BadRed)
                    }
                }
            }
            lots?.let { (sku, list) ->
                Text("লট — $sku", style = MaterialTheme.typography.titleSmall)
                list.forEach { l -> Text(l.lotNo + " · " + l.qty.stripTrailingZeros().toPlainString() + " · মেয়াদ " + (l.expiry ?: "—") + if (l.expired) " (মেয়াদোত্তীর্ণ)" else "",
                    style = MaterialTheme.typography.labelSmall, color = if (l.expired) BadRed else TextMuted) }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

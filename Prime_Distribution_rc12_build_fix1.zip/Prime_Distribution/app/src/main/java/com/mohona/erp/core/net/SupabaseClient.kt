package com.mohona.erp.core.net

import java.util.UUID
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Tokens of ONE signed-in person. Kept in memory by default (see [TokenStore]); never logged.
 * [kind] "gotrue" = Supabase Auth session (OTP); "pin" = PIN session minted by the Edge Function (S16), refreshed there.
 */
data class SessionTokens(val accessToken: String, val refreshToken: String?, val expiresAtEpochSec: Long, val kind: String = "gotrue")

/** TOTP enrolment started on the server (S17 / OI-27). The secret is shown once to the person and never stored by the app. */
data class TotpEnrollment(val factorId: String, val secret: String, val uri: String)

interface TokenStore {
    fun read(): SessionTokens?
    fun write(tokens: SessionTokens)
    fun clear()
}

class MemoryTokenStore : TokenStore {
    @Volatile private var tokens: SessionTokens? = null
    override fun read(): SessionTokens? = tokens
    override fun write(tokens: SessionTokens) { this.tokens = tokens }
    override fun clear() { tokens = null }
}

/** Supplied by the app; used only to build requests. The anon/publishable key is public by design. */
data class SupabaseConfig(val baseUrl: String, val anonKey: String) {
    init {
        require(baseUrl.startsWith("https://")) { "SUPABASE_URL must be https" }
        require(anonKey.isNotBlank()) { "anon key missing" }
    }
}

/**
 * The ONLY door to the backend. All business calls are RPCs into schema `api` (POST /rest/v1/rpc/<name>);
 * the app never reads or writes tables directly (the database grants nothing on tables to API roles).
 * - Every request carries an X-Request-Id; write RPCs also carry an Idempotency-Key that the server stores (S37+).
 * - A 401 triggers ONE token refresh (serialised by a mutex) and ONE retry; a failed refresh clears the session.
 */
private val RPC_NAME = Regex("^[a-z][a-z0-9_]*$")

class SupabaseClient(
    private val config: SupabaseConfig,
    private val transport: HttpTransport,
    private val tokens: TokenStore,
    private val io: CoroutineDispatcher = Dispatchers.IO,
    private val nowEpochSec: () -> Long = { System.currentTimeMillis() / 1000 },
    private val newId: () -> String = { UUID.randomUUID().toString() }
) {
    private val refreshMutex = Mutex()

    /** Listener for "the session is gone" (refresh failed / revoked): the UI routes to login. */
    @Volatile var onSessionLost: (() -> Unit)? = null

    val isSignedIn: Boolean get() = tokens.read() != null

    /** Stable per-install device id (S16); required to refresh a PIN session (the server binds sessions to devices). */
    @Volatile var deviceId: String? = null

    /** Installs tokens obtained outside GoTrue (PIN login through the Edge Function). */
    fun adoptSession(t: SessionTokens) = tokens.write(t)

    /** Local sign-out: forgets the tokens without the "session lost" callback (the server side is ended separately). */
    fun forgetSession() = tokens.clear()

    val hasSession: Boolean get() = tokens.read() != null

    /** POST /functions/v1/<name>. [authenticated] adds the current bearer; the anon key is always sent. */
    suspend fun callFunction(name: String, body: JSONObject, authenticated: Boolean = false): ApiResult<JSONObject> = withContext(io) {
        require(Regex("^[a-z][a-z0-9-]{1,40}$").matches(name)) { "bad function name" }
        val bearer = if (authenticated) tokens.read()?.accessToken else null
        when (val r = send("POST", "/functions/v1/$name", body.toString(), bearer = bearer, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try { ApiResult.Ok(JSONObject(r.value)) } catch (e: Exception) { ApiResult.Err(ErrorCatalog.badResponse(name)) }
        }
    }

    /** "gotrue" (OTP / MFA session), "pin" (Edge Function session) or null when signed out. */
    val sessionKind: String? get() = tokens.read()?.kind

    // ---------------------------------------------------------------- MFA (OI-27): TOTP on a GoTrue session -> aal2
    /** Verified TOTP factor ids of the signed-in GoTrue user. */
    suspend fun mfaVerifiedTotp(): ApiResult<List<String>> = withContext(io) {
        val t = tokens.read() ?: return@withContext ApiResult.Err(ErrorCatalog.sessionExpired())
        when (val r = send("GET", "/auth/v1/user", null, bearer = t.accessToken, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try {
                val a = JSONObject(r.value).optJSONArray("factors") ?: org.json.JSONArray()
                ApiResult.Ok((0 until a.length()).map { a.getJSONObject(it) }
                    .filter { it.optString("factor_type") == "totp" && it.optString("status") == "verified" }.map { it.getString("id") })
            } catch (e: Exception) { ApiResult.Err(ErrorCatalog.badResponse("user")) }
        }
    }

    /** Starts TOTP enrolment; the person adds [TotpEnrollment.uri] / secret to an authenticator app, then verifies a code. */
    suspend fun mfaEnrollTotp(friendlyName: String): ApiResult<TotpEnrollment> = withContext(io) {
        val t = tokens.read() ?: return@withContext ApiResult.Err(ErrorCatalog.sessionExpired())
        val body = JSONObject().put("factor_type", "totp").put("friendly_name", friendlyName.take(40)).toString()
        when (val r = send("POST", "/auth/v1/factors", body, bearer = t.accessToken, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> try {
                val o = JSONObject(r.value); val totp = o.getJSONObject("totp")
                ApiResult.Ok(TotpEnrollment(o.getString("id"), totp.getString("secret"), totp.getString("uri")))
            } catch (e: Exception) { ApiResult.Err(ErrorCatalog.badResponse("factors")) }
        }
    }

    /** Challenge + verify one TOTP code; on success the aal2 session replaces the current one. */
    suspend fun mfaVerify(factorId: String, code: String): ApiResult<SessionTokens> = withContext(io) {
        require(Regex("^[0-9a-fA-F-]{36}$").matches(factorId)) { "bad factor id" }
        val t = tokens.read() ?: return@withContext ApiResult.Err(ErrorCatalog.sessionExpired())
        val ch = when (val r = send("POST", "/auth/v1/factors/$factorId/challenge", "{}", bearer = t.accessToken, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> return@withContext r
            is ApiResult.Ok -> runCatching { JSONObject(r.value).getString("id") }.getOrNull() ?: return@withContext ApiResult.Err(ErrorCatalog.badResponse("challenge"))
        }
        val body = JSONObject().put("challenge_id", ch).put("code", code).toString()
        when (val r = send("POST", "/auth/v1/factors/$factorId/verify", body, bearer = t.accessToken, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> if (r.error.httpCode in setOf(400, 401, 403, 422))
                ApiResult.Err(AppError("C_INVALID_MFA", ErrorKind.VALIDATION, "যাচাই-কোড সঠিক নয় বা মেয়াদ শেষ।", r.error.httpCode, r.error.detail, r.error.requestId)) else r
            is ApiResult.Ok -> parseTokens(r.value)?.let { tokens.write(it); ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("verify"))
        }
    }

    /** Supabase phone OTP: sends a code to an already-allowed number (sign-up stays disabled). [phone] = +8801XXXXXXXXX. */
    suspend fun requestOtp(phone: String): ApiResult<Unit> = withContext(io) {
        val body = JSONObject().put("phone", phone.removePrefix("+")).put("create_user", false).toString()
        when (val r = send("POST", "/auth/v1/otp", body, bearer = null, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(Unit)
        }
    }

    /** Verifies the SMS code; on success the OTP session (aal1, fresh amr) becomes the current session. */
    suspend fun verifyOtp(phone: String, code: String): ApiResult<SessionTokens> = withContext(io) {
        val body = JSONObject().put("type", "sms").put("phone", phone.removePrefix("+")).put("token", code).toString()
        when (val r = send("POST", "/auth/v1/verify", body, bearer = null, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> if (r.error.httpCode in setOf(400, 401, 403, 422))
                ApiResult.Err(AppError("C_INVALID_OTP", ErrorKind.VALIDATION, "কোডটি সঠিক নয় বা মেয়াদ শেষ।", r.error.httpCode, r.error.detail, r.error.requestId)) else r
            is ApiResult.Ok -> parseTokens(r.value)?.let { tokens.write(it); ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("verify"))
        }
    }

    // ------------------------------------------------------------------ auth (Supabase GoTrue)

    suspend fun signInWithPassword(loginId: String, password: String): ApiResult<SessionTokens> = withContext(io) {
        val body = JSONObject().put("email", loginId.trim()).put("password", password).toString()
        when (val r = send("POST", "/auth/v1/token?grant_type=password", body, bearer = null, schema = null, idempotencyKey = null)) {
            is ApiResult.Err -> {
                val e = r.error
                if (e.httpCode == 400 || e.httpCode == 401 || e.httpCode == 422)
                    ApiResult.Err(AppError("C_INVALID_LOGIN", ErrorKind.VALIDATION, "লগইন আইডি বা পাসওয়ার্ড সঠিক নয়।", e.httpCode, e.detail, e.requestId))
                else r
            }
            is ApiResult.Ok -> parseTokens(r.value)?.let { tokens.write(it); ApiResult.Ok(it) }
                ?: ApiResult.Err(ErrorCatalog.badResponse("token response"))
        }
    }

    /** Ends THIS device's session on the server; local state is cleared regardless of the server answer. */
    suspend fun signOut() = withContext(io) {
        val t = tokens.read()
        tokens.clear()
        if (t != null) send("POST", "/auth/v1/logout?scope=local", "{}", bearer = t.accessToken, schema = null, idempotencyKey = null)
        Unit
    }

    private suspend fun refresh(stale: SessionTokens): Boolean = refreshMutex.withLock {
        val current = tokens.read() ?: return@withLock false
        if (current.accessToken != stale.accessToken) return@withLock true        // another caller already refreshed
        val rt = current.refreshToken ?: return@withLock false.also { lose() }
        val pin = current.kind == "pin"
        if (pin && deviceId == null) return@withLock false.also { lose() }
        val body = if (pin) JSONObject().put("refresh_token", rt).put("device_id", deviceId).toString() else JSONObject().put("refresh_token", rt).toString()
        val path = if (pin) "/functions/v1/auth-pin-refresh" else "/auth/v1/token?grant_type=refresh_token"
        when (val r = send("POST", path, body, bearer = null, schema = null, idempotencyKey = null)) {
            is ApiResult.Ok -> {
                val t = parseTokens(r.value)?.let { if (pin) it.copy(kind = "pin") else it }
                if (t == null) { lose(); false } else { tokens.write(t); true }
            }
            is ApiResult.Err -> { if (!r.error.retryable) lose(); false }
        }
    }

    private fun lose() {
        tokens.clear()
        onSessionLost?.invoke()
    }

    private fun parseTokens(body: String): SessionTokens? = try {
        val o = JSONObject(body)
        val access = o.getString("access_token")
        val refresh = o.optString("refresh_token", "").ifBlank { null }
        val expiresAt = if (o.has("expires_at")) o.getLong("expires_at") else nowEpochSec() + o.optLong("expires_in", 3600)
        SessionTokens(access, refresh, expiresAt)
    } catch (e: Exception) { null }

    // ------------------------------------------------------------------ RPC

    /**
     * Calls api.<name>(params). [write] = true marks a state-changing call and attaches an Idempotency-Key
     * (pass the SAME key when the user retries the SAME action, e.g. after a timeout).
     * Returns the parsed JSON value (JSONObject, JSONArray, String, Number, Boolean or JSONObject.NULL).
     */
    suspend fun rpc(name: String, params: JSONObject = JSONObject(), write: Boolean = false, idempotencyKey: String? = null): ApiResult<Any> =
        withContext(io) { callRpc(name, params, write, idempotencyKey) }

    private suspend fun callRpc(name: String, params: JSONObject, write: Boolean, idempotencyKey: String?): ApiResult<Any> {
        require(RPC_NAME.matches(name)) { "bad rpc name" }
        val t0 = tokens.read() ?: return ApiResult.Err(ErrorCatalog.sessionExpired())
        if (t0.expiresAtEpochSec - nowEpochSec() < 30) refresh(t0)
        val key = if (write) (idempotencyKey ?: newId()) else null
        for (attempt in 0..1) {
            val t = tokens.read() ?: return ApiResult.Err(ErrorCatalog.sessionExpired())
            when (val r = send("POST", "/rest/v1/rpc/$name", params.toString(), bearer = t.accessToken, schema = "api", idempotencyKey = key, rpcName = name)) {
                is ApiResult.Ok -> return parseJson(r.value)
                is ApiResult.Err -> {
                    if (r.error.httpCode == 401 && attempt == 0 && refresh(t)) continue
                    if (r.error.kind == ErrorKind.SESSION_EXPIRED) lose()
                    return r
                }
            }
        }
        return ApiResult.Err(ErrorCatalog.sessionExpired())
    }

    // ------------------------------------------------------------------ Storage (attachments)

    /**
     * Uploads [bytes] to Storage at the path the SERVER chose (api.v1_forms_attachment_begin / v1_product_media_begin). Never overwrites
     * (x-upsert false); the Storage policy lets only the person holding the upload grant write that exact object.
     */
    suspend fun uploadObject(bucket: String, objectPath: String, bytes: ByteArray, mimeType: String): ApiResult<Unit> = withContext(io) {
        require(Regex("^[a-z0-9_-]{2,40}$").matches(bucket)) { "bad bucket" }
        require(Regex("^[A-Za-z0-9_-]+(/[A-Za-z0-9_-]+)*\\.[a-z0-9]{2,5}$").matches(objectPath)) { "bad object path" }
        require(Regex("^[a-z]+/[a-z0-9.+-]+$").matches(mimeType)) { "bad mime type" }
        val t0 = tokens.read() ?: return@withContext ApiResult.Err(ErrorCatalog.sessionExpired())
        if (t0.expiresAtEpochSec - nowEpochSec() < 30) refresh(t0)
        for (attempt in 0..1) {
            val t = tokens.read() ?: return@withContext ApiResult.Err(ErrorCatalog.sessionExpired())
            val r = sendRaw("POST", "/storage/v1/object/$bucket/$objectPath", null, bearer = t.accessToken, schema = null, idempotencyKey = null, rpcName = null,
                            bytes = bytes, contentType = mimeType, extra = mapOf("x-upsert" to "false", "Cache-Control" to "no-store"))
            when (r) {
                is ApiResult.Ok -> return@withContext ApiResult.Ok(Unit)
                is ApiResult.Err -> {
                    if (r.error.httpCode == 401 && attempt == 0 && refresh(t)) continue
                    onError?.invoke(r.error)
                    return@withContext r
                }
            }
        }
        ApiResult.Err(ErrorCatalog.sessionExpired())
    }

    suspend fun rpcObject(name: String, params: JSONObject = JSONObject(), write: Boolean = false, idempotencyKey: String? = null): ApiResult<JSONObject> =
        when (val r = rpc(name, params, write, idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> (r.value as? JSONObject)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("expected object from $name"))
        }

    suspend fun rpcArray(name: String, params: JSONObject = JSONObject()): ApiResult<JSONArray> =
        when (val r = rpc(name, params)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> (r.value as? JSONArray)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("expected array from $name"))
        }

    private fun parseJson(body: String): ApiResult<Any> = try {
        if (body.isBlank()) ApiResult.Ok(JSONObject.NULL) else ApiResult.Ok(JSONTokener(body).nextValue())
    } catch (e: Exception) {
        ApiResult.Err(ErrorCatalog.badResponse(e.message))
    }

    // ------------------------------------------------------------------ transport + error mapping

    /** Observer for every failed request (Diagnostics screen). Receives codes/request ids only. */
    @Volatile var onError: ((AppError) -> Unit)? = null

    private fun send(method: String, path: String, body: String?, bearer: String?, schema: String?, idempotencyKey: String?, rpcName: String? = null): ApiResult<String> {
        val r = sendRaw(method, path, body, bearer, schema, idempotencyKey, rpcName)
        if (r is ApiResult.Err) onError?.invoke(r.error)
        return r
    }

    private fun sendRaw(method: String, path: String, body: String?, bearer: String?, schema: String?, idempotencyKey: String?, rpcName: String?,
                        bytes: ByteArray? = null, contentType: String = "application/json", extra: Map<String, String> = emptyMap()): ApiResult<String> {
        val requestId = newId()
        val headers = LinkedHashMap<String, String>()
        headers["apikey"] = config.anonKey
        headers["Content-Type"] = contentType
        headers["Accept"] = "application/json"
        headers["X-Request-Id"] = requestId
        headers["X-Client-Info"] = "mohona-android"
        if (bearer != null) headers["Authorization"] = "Bearer $bearer"
        if (schema != null) { headers["Content-Profile"] = schema; headers["Accept-Profile"] = schema }
        if (idempotencyKey != null) headers["Idempotency-Key"] = idempotencyKey
        headers.putAll(extra)
        val resp = try {
            transport.execute(HttpRequest(method, config.baseUrl.trimEnd('/') + path, headers, body, bytes))
        } catch (e: TransportTimeout) {
            return ApiResult.Err(ErrorCatalog.timeout().copy(requestId = requestId))
        } catch (e: Exception) {
            return ApiResult.Err(ErrorCatalog.network(e.javaClass.simpleName).copy(requestId = requestId))
        }
        if (resp.code in 200..299) return ApiResult.Ok(resp.body)
        return ApiResult.Err(mapError(resp, requestId, rpcName))
    }

    internal fun mapError(resp: HttpResponse, requestId: String, rpcName: String?): AppError {
        var message: String? = null
        var pgCode: String? = null
        try {
            val o = JSONObject(resp.body)
            message = o.optString("message", "").ifBlank { o.optString("msg", "").ifBlank { o.optString("error_description", "") } }
                .ifBlank { o.optString("error", "").takeIf { it.startsWith("E_") } ?: "" }.ifBlank { null }   // Edge Functions: {"error":"E_*"}
            pgCode = o.optString("code", "").ifBlank { null }
        } catch (e: Exception) { /* non-JSON body */ }
        ErrorCatalog.fromServerMessage(message, resp.code, requestId)?.let { return it }
        if (rpcName != null && (pgCode == "PGRST202" || (resp.code == 404 && pgCode == null))) return ErrorCatalog.backendNotReady(rpcName).copy(httpCode = resp.code, requestId = requestId)
        if (pgCode == "42501") return AppError("C_FORBIDDEN", ErrorKind.FORBIDDEN, "এই কাজের অনুমতি আপনার নেই।", resp.code, message, requestId)
        return ErrorCatalog.fromHttp(resp.code, message, requestId)
    }
}

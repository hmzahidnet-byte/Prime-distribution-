package com.mohona.erp.ui.screens

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.BuildConfig
import com.mohona.erp.core.arch.DiagnosticsLog
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.data.AppConfig
import com.mohona.erp.data.Bn
import com.mohona.erp.ui.components.KeyValueRow
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionCard
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.TextMuted
import com.mohona.erp.ui.theme.ThemeRuntime
import com.mohona.erp.ui.theme.tokens.TokenSource
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Build identity + runtime diagnostics. Shows NO secret (no key, no token): server host only. */
@Composable
fun DiagnosticsScreen(isPreview: Boolean, onBack: () -> Unit) {
    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("Asia/Dhaka") }
    val sha = BuildConfig.GIT_SHA
    val tokens = ThemeRuntime.tokens
    Column(modifier = Modifier.fillMaxSize().background(BackgroundGray).verticalScroll(rememberScrollState())) {
        ScreenHeader("বিল্ড ও ডায়াগনস্টিক", onBack)
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionCard("বিল্ড-পরিচয়") {
                KeyValueRow("সংস্করণ", BuildConfig.VERSION_NAME + " (" + Bn.digits(BuildConfig.VERSION_CODE.toString()) + ")")
                KeyValueRow("Git SHA", if (sha == "UNKNOWN") "অজানা (CI ছাড়া তৈরি)" else sha.take(12))
                KeyValueRow("বিল্ড-সময় (UTC)", BuildConfig.BUILD_TIME_UTC)
                KeyValueRow("ধরন", if (BuildConfig.DEBUG) "Debug" else "Release")
            }
            SectionCard("সংযোগ") {
                KeyValueRow("মোড", if (isPreview) "প্রিভিউ (নমুনা)" else "সংযুক্ত")
                val host = AppConfig.supabaseUrl.removePrefix("https://").substringBefore('/')
                KeyValueRow("সার্ভার", if (host.isBlank()) "কনফিগার করা নেই" else host)
                KeyValueRow("কনফিগ-সমস্যা", AppConfig.configProblem ?: "নেই")
                KeyValueRow("সাইন-ইন", if (AppContainer.client?.isSignedIn == true) "হ্যাঁ" else "না")
                KeyValueRow("ক্যাশ-এন্ট্রি", Bn.digits(AppContainer.cache.size().toString()))
            }
            SectionCard("থিম") {
                KeyValueRow("উৎস", if (tokens.source == TokenSource.DEFAULT) "ডিফল্ট" else "চেয়ারম্যান-প্রকাশিত")
                KeyValueRow("রিভিশন", Bn.digits(tokens.revision.toString()))
            }
            SectionCard("ডিভাইস") {
                KeyValueRow("Android", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")")
                KeyValueRow("মডেল", Build.MANUFACTURER + " " + Build.MODEL)
            }
            SectionCard("সাম্প্রতিক ত্রুটি", trailing = Bn.digits(DiagnosticsLog.recent().size.toString()) + "টি") {
                val items = DiagnosticsLog.recent()
                if (items.isEmpty()) Text("কোনো ত্রুটি নেই", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                items.take(20).forEach {
                    KeyValueRow(fmt.format(Date(it.atMillis)), it.code + (it.httpCode?.let { c -> " · " + c } ?: "") + (it.requestId?.let { r -> " · " + r.take(8) } ?: ""))
                }
            }
        }
    }
}

package com.mohona.erp.feature.forms.data

import java.io.File

/**
 * [DraftStorage] on app-private files (OI-18): one file per draft holding ONLY ciphertext from [OfflineDraftStore].
 * Writes are atomic (temp file + rename) so a crash never leaves half a draft. Ids are validated (no path tricks).
 */
class FileDraftStorage(private val dir: File) : DraftStorage {
    private val idPattern = Regex("^[A-Za-z0-9_-]{8,64}$")
    init { dir.mkdirs() }

    private fun file(id: String): File {
        require(idPattern.matches(id)) { "bad draft id" }
        return File(dir, "$id.draft")
    }

    @Synchronized override fun put(id: String, blob: String) {
        val target = file(id)
        val tmp = File(dir, "$id.tmp")
        tmp.writeText(blob, Charsets.UTF_8)
        if (!tmp.renameTo(target)) { target.delete(); check(tmp.renameTo(target)) { "draft write failed" } }
    }

    @Synchronized override fun get(id: String): String? = file(id).takeIf { it.isFile }?.readText(Charsets.UTF_8)

    @Synchronized override fun remove(id: String) { if (idPattern.matches(id)) file(id).delete() }

    @Synchronized override fun ids(): Set<String> =
        (dir.listFiles() ?: emptyArray()).filter { it.isFile && it.name.endsWith(".draft") }.map { it.name.removeSuffix(".draft") }
            .filter { idPattern.matches(it) }.toSet()
}

data class SyncReport(val synced: Int, val conflicts: Int, val failed: Int, val firstError: String?)

/**
 * Pushes this person's local drafts to the server (api.v1_forms_draft_sync). Never submits: a draft that was already
 * submitted online comes back as "conflict" and the local copy is dropped. Network failures keep the draft for later.
 */
class DraftSyncer(private val store: OfflineDraftStore, private val forms: FormsRepository) {
    suspend fun syncAll(companyId: String, personId: String, ttlDays: Long, newKey: () -> String): SyncReport {
        var ok = 0; var conflicts = 0; var failed = 0; var firstError: String? = null
        val definitions = HashMap<Pair<String, Int>, org.json.JSONObject>()
        for (d in store.list(companyId, personId, ttlDays)) {
            val cacheKey = d.formId to d.formVersion
            var def = definitions[cacheKey]
            if (def == null) {
                when (val r = forms.definition(d.formId, d.formVersion)) {
                    is com.mohona.erp.core.net.ApiResult.Ok -> { def = r.value.optJSONObject("definition") ?: org.json.JSONObject(); definitions[cacheKey] = def }
                    is com.mohona.erp.core.net.ApiResult.Err -> { failed++; firstError = firstError ?: r.error.messageBn; continue }
                }
            }
            when (val r = forms.syncDraft(d, def ?: continue, newKey())) {
                is com.mohona.erp.core.net.ApiResult.Ok -> {
                    store.markSynced(d.clientDraftId, r.value.submissionId, r.value.conflict)
                    if (r.value.conflict) conflicts++ else ok++
                }
                is com.mohona.erp.core.net.ApiResult.Err -> { failed++; firstError = firstError ?: r.error.messageBn }
            }
        }
        return SyncReport(ok, conflicts, failed, firstError)
    }
}

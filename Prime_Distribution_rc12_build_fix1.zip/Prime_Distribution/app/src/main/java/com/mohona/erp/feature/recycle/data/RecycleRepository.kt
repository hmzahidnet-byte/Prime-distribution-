package com.mohona.erp.feature.recycle.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class BinItem(val id: String, val classCode: String, val labelBn: String, val status: String, val deletedAt: String, val purgeAfter: String,
                   val conflict: String?, val onHold: Boolean, val masked: Boolean)
data class RestoreOutcome(val status: String, val reason: String?)   // restored | conflict | denied
data class BulkOutcome(val restored: List<String>, val denied: List<Pair<String, String>>) { val allRestored get() = denied.isEmpty() && restored.isNotEmpty() }

/** Recycle bin (S21). Restores re-check today's rights on the server; masked entries carry no label or record id. */
class RecycleRepository(private val client: SupabaseClient) {
    suspend fun delete(classCode: String, recordId: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_recycle_delete", JSONObject().put("p_class", classCode).put("p_record_id", recordId).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun list(classCode: String? = null, status: String? = "in_bin"): ApiResult<List<BinItem>> =
        when (val r = client.rpcArray("v1_recycle_list", JSONObject().put("p_class", classCode ?: JSONObject.NULL).put("p_status", status ?: JSONObject.NULL).put("p_limit", 200))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseItems(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_recycle_list"))
        }
    suspend fun restore(itemId: String, reason: String, key: String): ApiResult<RestoreOutcome> =
        when (val r = client.rpcObject("v1_recycle_restore", JSONObject().put("p_item_id", itemId).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(RestoreOutcome(r.value.optString("status"), r.value.optString("conflict").ifBlank { r.value.optString("reason").ifBlank { null } }))
        }
    suspend fun restoreBulk(itemIds: List<String>, reason: String, key: String): ApiResult<BulkOutcome> =
        when (val r = client.rpcObject("v1_recycle_restore_bulk", JSONObject().put("p_item_ids", JSONArray(itemIds)).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(parseBulk(r.value))
        }
    suspend fun requestPurge(itemId: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_recycle_request_purge", JSONObject().put("p_item_id", itemId).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun approvePurge(requestId: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_recycle_approve_purge", JSONObject().put("p_request_id", requestId).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun events(itemId: String? = null): ApiResult<JSONArray> =
        client.rpcArray("v1_recycle_events", JSONObject().put("p_item_id", itemId ?: JSONObject.NULL).put("p_limit", 200))

    companion object {
        fun parseItems(a: JSONArray): List<BinItem>? = try {
            (0 until a.length()).map { a.getJSONObject(it).let { o ->
                BinItem(o.getString("id"), o.getString("class_code"), o.optString("label_bn"), o.getString("status"), o.optString("deleted_at"), o.optString("purge_after"),
                    if (o.isNull("conflict")) null else o.optString("conflict"), o.optBoolean("on_hold"), o.optBoolean("masked")) } }
        } catch (e: Exception) { null }

        fun parseBulk(o: JSONObject): BulkOutcome {
            val r = o.optJSONArray("restored") ?: JSONArray(); val d = o.optJSONArray("denied") ?: JSONArray()
            return BulkOutcome((0 until r.length()).map { r.getString(it) }, (0 until d.length()).map { d.getJSONObject(it).let { x -> x.getString("item_id") to x.getString("reason") } })
        }

        fun reasonBn(reason: String?): String = when (reason) {
            null -> ""
            "forbidden" -> "আপনার এখন এই রেকর্ড ফেরানোর অনুমতি নেই"
            "legal_hold" -> "আইনি স্থগিতাদেশে আটকে আছে"
            "purge_pending" -> "স্থায়ী মুছে ফেলার অনুরোধ চলছে"
            "parent_archived" -> "মূল ফর্ম আর্কাইভ করা — আগে ফর্মটি চালু করুন"
            "blob_missing" -> "সংযুক্তির ফাইল পাওয়া যায়নি"
            "changed" -> "রেকর্ডটি ইতিমধ্যে বদলে গেছে"
            "not_in_bin" -> "এটি আর বিনে নেই"
            else -> reason
        }
    }
}

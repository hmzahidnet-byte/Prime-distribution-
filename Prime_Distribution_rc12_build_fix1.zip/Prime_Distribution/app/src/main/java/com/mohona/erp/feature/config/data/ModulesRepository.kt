package com.mohona.erp.feature.config.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

enum class ModuleStatus { DISABLED, ENABLED, SUSPENDED, RETIRED, UNKNOWN }
enum class ModuleAction(val wire: String) { ENABLE("enable"), SUSPEND("suspend"), RESUME("resume"), RETIRE("retire"), REACTIVATE("reactivate") }

data class ModuleRelease(val version: String, val compatibleFrom: String, val dataSchemaVersion: Int, val rollbackSafe: Boolean)

data class CompanyModule(
    val code: String, val nameBn: String, val isCore: Boolean, val built: Boolean, val wingScopable: Boolean,
    val status: ModuleStatus, val version: String?, val wingIds: List<String>?, val rowVersion: Int,
    val dependsOn: List<Pair<String, String>>, val releases: List<ModuleRelease>
) {
    /** Actions the lifecycle allows from the current state (the server re-validates and checks dependencies). */
    fun possibleActions(iAmSupreme: Boolean): List<ModuleAction> = if (isCore) emptyList() else when (status) {
        ModuleStatus.DISABLED -> if (built) listOf(ModuleAction.ENABLE) else emptyList()
        ModuleStatus.ENABLED -> listOf(ModuleAction.SUSPEND)
        ModuleStatus.SUSPENDED -> listOf(ModuleAction.RESUME, ModuleAction.RETIRE)
        ModuleStatus.RETIRED -> if (iAmSupreme) listOf(ModuleAction.REACTIVATE) else emptyList()
        ModuleStatus.UNKNOWN -> emptyList()
    }
    fun upgradeTargets(): List<ModuleRelease> {
        val cur = version?.let { Semver.parse(it) } ?: return emptyList()
        return releases.filter { Semver.parse(it.version) > cur && Semver.parse(it.compatibleFrom) <= cur }
    }
}

data class LauncherModule(val code: String, val nameBn: String, val readOnly: Boolean, val wingIds: List<String>?)

data class FeatureFlag(val key: String, val module: String, val nameBn: String, val enabled: Boolean, val defaultEnabled: Boolean,
                       val isSecurityCore: Boolean, val version: Int, val wingOverrides: Map<String, Pair<Boolean, Int>>) {
    fun enabledFor(wingId: String?): Boolean = if (isSecurityCore) true else (wingId?.let { wingOverrides[it]?.first } ?: enabled)
}

data class Semver(val major: Int, val minor: Int, val patch: Int) : Comparable<Semver> {
    override fun compareTo(other: Semver): Int = compareValuesBy(this, other, { it.major }, { it.minor }, { it.patch })
    companion object {
        fun parse(s: String): Semver { val p = s.split('.').map { it.toInt() }; return Semver(p[0], p[1], p[2]) }
    }
}

class ModulesRepository(private val client: SupabaseClient) {
    suspend fun modules(): ApiResult<List<CompanyModule>> = arr("v1_config_modules", JSONObject(), ::parseModules)
    suspend fun launcher(): ApiResult<List<LauncherModule>> = arr("v1_config_my_modules", JSONObject(), ::parseLauncher)
    suspend fun flags(module: String? = null): ApiResult<List<FeatureFlag>> =
        arr("v1_config_flags", JSONObject().put("p_module", module ?: JSONObject.NULL), ::parseFlags)

    suspend fun action(code: String, action: ModuleAction, expectedRowVersion: Int, reason: String, cascade: Boolean?, key: String): ApiResult<Int> =
        int("v1_config_module_action", JSONObject().put("p_module", code).put("p_action", action.wire).put("p_expected_row_version", expectedRowVersion)
            .put("p_reason", reason).put("p_cascade", cascade ?: JSONObject.NULL), key)

    suspend fun setWings(code: String, wingIds: List<String>?, expectedRowVersion: Int, reason: String, key: String): ApiResult<Int> =
        int("v1_config_module_set_wings", JSONObject().put("p_module", code).put("p_wing_ids", wingIds?.let { JSONArray(it) } ?: JSONObject.NULL)
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), key)

    suspend fun upgrade(code: String, toVersion: String, expectedRowVersion: Int, reason: String, key: String): ApiResult<Int> =
        int("v1_config_module_upgrade", JSONObject().put("p_module", code).put("p_to_version", toVersion).put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), key)

    suspend fun rollback(code: String, toVersion: String, expectedRowVersion: Int, reason: String, key: String): ApiResult<Int> =
        int("v1_config_module_rollback", JSONObject().put("p_module", code).put("p_to_version", toVersion).put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), key)

    suspend fun setFlag(flagKey: String, wingId: String?, enabled: Boolean, expectedVersion: Int, reason: String, key: String): ApiResult<Int> =
        int("v1_config_set_flag", JSONObject().put("p_key", flagKey).put("p_wing_id", wingId ?: JSONObject.NULL).put("p_enabled", enabled)
            .put("p_expected_version", expectedVersion).put("p_reason", reason), key)

    private suspend fun int(name: String, p: JSONObject, key: String): ApiResult<Int> = when (val r = client.rpc(name, p, write = true, idempotencyKey = key)) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> ApiResult.Ok((r.value as? Number)?.toInt() ?: 0)
    }

    private suspend fun <T> arr(name: String, p: JSONObject, parse: (JSONArray) -> T?): ApiResult<T> = when (val r = client.rpcArray(name, p)) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parse(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse(name))
    }

    companion object {
        private fun strList(a: JSONArray?): List<String>? = a?.let { x -> (0 until x.length()).map { x.getString(it) } }
        private fun status(s: String?): ModuleStatus = ModuleStatus.values().firstOrNull { it.name.equals(s, true) } ?: ModuleStatus.UNKNOWN

        fun parseModules(a: JSONArray): List<CompanyModule>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val deps = o.optJSONArray("depends_on") ?: JSONArray(); val rel = o.optJSONArray("releases") ?: JSONArray()
                CompanyModule(o.getString("code"), o.getString("name_bn"), o.optBoolean("is_core"), o.optBoolean("built"), o.optBoolean("wing_scopable"),
                    status(if (o.isNull("status")) null else o.getString("status")), if (o.isNull("version")) null else o.getString("version"),
                    if (o.isNull("wing_ids")) null else strList(o.optJSONArray("wing_ids")), o.optInt("row_version", 0),
                    (0 until deps.length()).map { deps.getJSONObject(it).let { d -> d.getString("module") to d.getString("kind") } },
                    (0 until rel.length()).map { rel.getJSONObject(it).let { r -> ModuleRelease(r.getString("version"), r.getString("compatible_from"), r.getInt("data_schema_version"), r.optBoolean("rollback_safe", true)) } })
            }
        } catch (e: Exception) { null }

        fun parseLauncher(a: JSONArray): List<LauncherModule>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                LauncherModule(o.getString("code"), o.getString("name_bn"), o.optString("mode") == "read_only", if (o.isNull("wing_ids")) null else strList(o.optJSONArray("wing_ids")))
            }
        } catch (e: Exception) { null }

        fun parseFlags(a: JSONArray): List<FeatureFlag>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i); val w = o.optJSONArray("wing_overrides") ?: JSONArray()
                FeatureFlag(o.getString("key"), o.getString("module"), o.getString("name_bn"), o.getBoolean("enabled"), o.optBoolean("default_enabled"),
                    o.optBoolean("is_security_core"), o.optInt("version"),
                    (0 until w.length()).associate { k -> w.getJSONObject(k).let { x -> x.getString("wing_id") to (x.getBoolean("enabled") to x.optInt("version")) } })
            }
        } catch (e: Exception) { null }
    }
}

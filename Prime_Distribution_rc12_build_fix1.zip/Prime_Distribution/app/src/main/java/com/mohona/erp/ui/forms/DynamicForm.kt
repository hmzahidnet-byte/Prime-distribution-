package com.mohona.erp.ui.forms

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import org.json.JSONArray
import org.json.JSONObject

/**
 * Metadata renderer (S17): draws any Dynamic Form definition (S14) — the server's client definition already carries each
 * field's access. Visibility follows the server algorithm ([FormUi.visibleFields]); masked / read-only fields are shown,
 * never edited; values are normalised (Bengali digits -> canonical) on every change. The server re-validates on save.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DynamicForm(
    definition: JSONObject,
    values: JSONObject,
    errors: Map<String, String>,
    enabled: Boolean,
    onChange: (JSONObject) -> Unit,
    onAttach: (fieldKey: String) -> Unit = {}
) {
    val fields = FormUi.visibleFields(definition, values)
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        fields.forEach { f ->
            val current = values.opt(f.key)
            val label = f.labelBn + if (f.required) " *" else ""
            val canEdit = enabled && f.editable
            if (f.masked && !f.editable) {
                ReadOnly(label, if (current == null) "—" else FormUi.display(current) + " (গোপন)")
            } else when (f.widget) {
                Widget.SWITCH -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, Modifier.weight(1f))
                    Switch(checked = current == true, enabled = canEdit, onCheckedChange = { onChange(FormUi.withValue(values, f.raw, it)) })
                }
                Widget.SINGLE_CHOICE, Widget.MULTI_CHOICE -> Column {
                    Text(label, style = MaterialTheme.typography.bodyMedium)
                    val selected: Set<String> = when (current) {
                        is JSONArray -> (0 until current.length()).map { current.getString(it) }.toSet()
                        is String -> setOf(current)
                        else -> emptySet()
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        f.options.forEach { (value, text) ->
                            FilterChip(selected = value in selected, enabled = canEdit, label = { Text(text) }, onClick = {
                                val next: Any? = if (f.widget == Widget.SINGLE_CHOICE) (if (value in selected) null else value)
                                    else JSONArray((if (value in selected) selected - value else selected + value).toList())
                                onChange(FormUi.withValue(values, f.raw, next))
                            })
                        }
                    }
                }
                Widget.ATTACHMENT -> Column {
                    Text(label, style = MaterialTheme.typography.bodyMedium)
                    OutlinedButton(onClick = { onAttach(f.key) }, enabled = canEdit) {
                        Text(if (current == null) "সংযুক্তি যোগ করুন" else "সংযুক্তি বদলান")
                    }
                }
                Widget.UNSUPPORTED -> ReadOnly(label, "এই ঘরের ধরন অ্যাপে এখনো নেই")
                else -> OutlinedTextField(
                    value = FormUi.display(current),
                    onValueChange = { onChange(FormUi.withValue(values, f.raw, it)) },
                    enabled = canEdit,
                    label = { Text(label) },
                    placeholder = { Text(f.raw.optString("placeholder_bn", if (f.widget == Widget.DATE) "YYYY-MM-DD" else "")) },
                    singleLine = f.widget != Widget.MULTILINE,
                    minLines = if (f.widget == Widget.MULTILINE) 3 else 1,
                    keyboardOptions = KeyboardOptions(keyboardType = when (f.widget) {
                        Widget.NUMBER -> KeyboardType.Number; Widget.DECIMAL -> KeyboardType.Decimal; Widget.PHONE -> KeyboardType.Phone
                        Widget.EMAIL -> KeyboardType.Email; else -> KeyboardType.Text
                    }),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            f.helpBn?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = TextMuted) }
            errors[f.key]?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = BadRed) }
        }
        errors["_form"]?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = BadRed) }
    }
}

@Composable
private fun ReadOnly(label: String, text: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = TextMuted)
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

package com.mohona.erp.core.print

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.mohona.erp.data.Bn
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

/**
 * The 50 invoice designs (Prime 07, gate 8): 10 layout families × 5 variants, chosen by the spec the invoice was ISSUED with.
 * One drawing routine serves the PDF, the share image and the Chairman's gallery preview, so what the Chairman picks is what prints.
 * Figures come only from the authorised payload (api.v1_print_authorize): company, lines, total, paid, open, amount in words, signed QR.
 * No VAT / tax line exists in any design (OWN-06).
 */
object InvoiceRender {
    data class Paper(val w: Int, val h: Int, val margin: Float, val scale: Float)

    fun paper(spec: JSONObject): Paper = when (spec.optString("paper", "a4")) {
        "a5" -> Paper(420, 595, 26f, 0.82f)
        "pos80" -> Paper(226, 860, 8f, 0.66f)
        else -> Paper(595, 842, 36f, 1f)
    }

    fun qrBitmap(text: String, size: Int): Bitmap? = runCatching {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.MARGIN to 1))
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (m[x, y]) Color.BLACK else Color.WHITE)
        bmp
    }.getOrNull()

    private fun money(o: JSONObject, k: String): String = Bn.money(if (o.isNull(k)) null else o.optString(k))
    private fun dec(o: JSONObject, k: String): BigDecimal? = if (!o.has(k) || o.isNull(k)) null else o.optString(k).toBigDecimalOrNull()

    /** Draws one invoice page on [c] (size from [paper]). [data] is the print payload; [watermark] is the server's who/when line. */
    fun draw(c: Canvas, spec: JSONObject, data: JSONObject, watermark: String) {
        val p = paper(spec)
        val fam = spec.optString("family", "classic")
        val sc = p.scale * spec.optDouble("font_scale", 1.0).toFloat()
        val accent = runCatching { Color.parseColor(spec.optString("accent", "#1456A0")) }.getOrDefault(Color.BLACK)
        val soft = Color.argb(28, Color.red(accent), Color.green(accent), Color.blue(accent))
        val w = p.w.toFloat(); val h = p.h.toFloat(); var m = p.margin
        val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f * sc; color = Color.BLACK }
        val bold = Paint(txt).apply { isFakeBoldText = true }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8f * sc; color = Color.DKGRAY }
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 17f * sc; isFakeBoldText = true; color = accent }
        val onAccent = Paint(head).apply { color = Color.WHITE }
        val fill = Paint().apply { color = accent }
        val softFill = Paint().apply { color = soft }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.8f; color = accent }
        c.drawColor(Color.WHITE)

        val company = data.optJSONObject("company") ?: JSONObject()
        val cname = company.optString("name_bn", "")
        val caddr = listOfNotNull(company.optString("address_bn").takeIf { it.isNotBlank() && it != "null" },
                                  company.optString("phone").takeIf { it.isNotBlank() && it != "null" }?.let { "ফোন " + Bn.digits(it) }).joinToString(" · ")
        val title = "ইনভয়েস " + Bn.digits(data.optString("number"))
        val sample = data.optBoolean("sample", false)

        // ---------------------------------------------------------------- frame by family
        if (fam == "sidebar") { c.drawRect(0f, 0f, 10f * sc + 4f, h, fill); m += 8f * sc }
        if (fam == "boxed") c.drawRect(RectF(m - 6f, m - 6f, w - m + 6f, h - m + 6f), stroke)
        val right = w - m
        var y = m

        // ---------------------------------------------------------------- header
        val qrPos = spec.optString("qr", "top_right")
        val qrSize = (if (fam == "receipt") 70f else 64f) * p.scale
        val qrText = data.optString("qr").takeIf { it.isNotBlank() && it != "null" }
        val headerRight = if (qrPos == "top_right" && qrText != null && fam != "receipt") right - qrSize - 6f else right
        when (fam) {
            "banner" -> {
                c.drawRect(0f, 0f, w, m + 46f * sc, fill)
                c.drawText(cname, m, m + 14f * sc, onAccent.apply { textSize = 15f * sc })
                c.drawText(title, m, m + 36f * sc, Paint(onAccent).apply { textSize = 12f * sc })
                y = m + 62f * sc
            }
            "centered", "letterhead" -> {
                val cp = if (fam == "letterhead") Paint(head).apply { textSize = 20f * sc } else head
                c.drawText(cname, (w - cp.measureText(cname)) / 2f, y + 16f * sc, cp); y += 22f * sc
                if (caddr.isNotBlank()) { c.drawText(caddr, (w - small.measureText(caddr)) / 2f, y + 6f * sc, small); y += 12f * sc }
                if (fam == "letterhead") { c.drawRect(m, y + 4f, right, y + 5.5f, fill); c.drawRect(m, y + 8f, right, y + 8.6f, fill); y += 14f }
                c.drawText(title, (w - bold.measureText(title)) / 2f, y + 14f * sc, bold); y += 24f * sc
            }
            "corporate" -> {
                c.drawText(cname, m, y + 16f * sc, head)
                if (caddr.isNotBlank()) c.drawText(caddr, m, y + 30f * sc, small)
                val bx = RectF(headerRight - 150f * sc, y, headerRight, y + 40f * sc)
                c.drawRect(bx, softFill); c.drawRect(bx, stroke)
                c.drawText(title, bx.left + 6f, bx.top + 15f * sc, bold)
                c.drawText("তারিখ " + Bn.digits(data.optString("date")), bx.left + 6f, bx.top + 31f * sc, small)
                y += 52f * sc
            }
            "receipt" -> {
                c.drawText(cname, (w - bold.measureText(cname)) / 2f, y + 12f * sc, bold); y += 16f * sc
                if (caddr.isNotBlank()) { c.drawText(caddr, (w - small.measureText(caddr)) / 2f, y + 6f * sc, small); y += 12f * sc }
                c.drawText(title, (w - txt.measureText(title)) / 2f, y + 10f * sc, txt); y += 18f * sc
            }
            "minimal" -> {
                c.drawText(cname, m, y + 14f * sc, bold); c.drawText(title, headerRight - txt.measureText(title), y + 14f * sc, txt)
                if (caddr.isNotBlank()) c.drawText(caddr, m, y + 27f * sc, small)
                y += 40f * sc
            }
            else -> { // classic, sidebar, boxed, striped
                if (spec.optString("logo") == "left") { c.drawRect(m, y, m + 22f * sc, y + 22f * sc, fill); c.drawText(cname, m + 28f * sc, y + 16f * sc, head) }
                else c.drawText(cname, m, y + 16f * sc, head)
                c.drawText(title, headerRight - bold.measureText(title), y + 16f * sc, bold)
                if (caddr.isNotBlank()) c.drawText(caddr, m, y + 30f * sc, small)
                y += 36f * sc
                if (fam == "classic") { c.drawRect(m, y, right, y + 2f, fill); y += 8f }
            }
        }
        if (qrText != null && qrPos == "top_right" && fam != "receipt") qrBitmap(qrText, qrSize.toInt())?.let { c.drawBitmap(it, right - qrSize, m, null) }

        // ---------------------------------------------------------------- parties and dates
        c.drawText("ডিলার: " + data.optString("dealer") + (data.optString("dealer_code").takeIf { it.isNotBlank() && it != "null" }?.let { " (" + it + ")" } ?: ""), m, y + 10f * sc, txt)
        y += 14f * sc
        if (fam != "corporate") { c.drawText("তারিখ " + Bn.digits(data.optString("date")) + " · পরিশোধের শেষ দিন " + Bn.digits(data.optString("due_date")), m, y + 10f * sc, txt); y += 14f * sc }
        else { c.drawText("পরিশোধের শেষ দিন " + Bn.digits(data.optString("due_date")), m, y + 10f * sc, txt); y += 14f * sc }
        y += 8f * sc

        // ---------------------------------------------------------------- lines table
        val table = spec.optString("table", "lines")
        val narrow = fam == "receipt"
        val colQty = if (narrow) m + (right - m) * 0.50f else m + (right - m) * 0.52f
        val colPrice = if (narrow) m + (right - m) * 0.66f else m + (right - m) * 0.68f
        val rowH = 15f * sc
        if (table == "grid" || fam == "banner" || fam == "corporate") c.drawRect(m, y - 2f, right, y + rowH - 2f, softFill)
        c.drawText("পণ্য", m + 2f, y + 9f * sc, bold)
        c.drawText("পরিমাণ", colQty, y + 9f * sc, bold)
        if (!narrow) c.drawText("দর", colPrice, y + 9f * sc, bold)
        c.drawText("টাকা", right - bold.measureText("টাকা") - 2f, y + 9f * sc, bold)
        y += rowH
        if (table != "plain") c.drawRect(m, y - 3f, right, y - 2f, fill)
        val lines = data.optJSONArray("lines") ?: JSONArray()
        val bottomReserve = (if (narrow) 150f else 130f) * sc
        var shown = 0
        for (i in 0 until lines.length()) {
            if (y > h - m - bottomReserve) break
            val l = lines.optJSONObject(i) ?: continue
            if (table == "stripes" && i % 2 == 0) c.drawRect(m, y - 2f, right, y + rowH - 2f, softFill)
            val name = (l.optString("name_bn").takeIf { it.isNotBlank() && it != "null" } ?: l.optString("sku")).let { if (narrow) it.take(16) else it.take(34) }
            c.drawText(Bn.digits((i + 1).toString()) + ". " + name, m + 2f, y + 9f * sc, txt)
            c.drawText(Bn.digits(l.optString("qty")), colQty, y + 9f * sc, txt)
            if (!narrow) c.drawText(Bn.money(l.optString("price")).removePrefix("৳ "), colPrice, y + 9f * sc, txt)
            val amt = Bn.money(l.optString("amount")).removePrefix("৳ ")
            c.drawText(amt, right - txt.measureText(amt) - 2f, y + 9f * sc, txt)
            if (table == "grid" || table == "lines") c.drawRect(m, y + rowH - 3f, right, y + rowH - 2.6f, Paint().apply { color = Color.LTGRAY })
            y += rowH; shown++
        }
        if (shown < lines.length()) { c.drawText("… আরও " + Bn.digits((lines.length() - shown).toString()) + "টি লাইন (পূর্ণ তালিকা ডিজিটাল কপিতে)", m, y + 9f * sc, small); y += rowH }
        y += 4f
        c.drawRect(m, y, right, y + 1.2f, fill); y += 14f * sc

        // ---------------------------------------------------------------- totals + words
        fun row(label: String, value: String, paint: Paint) {
            c.drawText(label, if (narrow) m else right - 210f * sc, y, paint)
            c.drawText(value, right - paint.measureText(value) - 2f, y, paint); y += 14f * sc
        }
        if (fam == "centered" || fam == "boxed") c.drawRect(RectF(right - 216f * sc, y - 12f * sc, right, y + 34f * sc), softFill)
        row("মোট", money(data, "total"), bold)
        if (dec(data, "paid")?.signum() == 1) row("পরিশোধিত", money(data, "paid"), txt)
        row("বকেয়া", money(data, "open"), txt)
        y += 4f
        if (spec.optBoolean("words", true)) {
            val words = data.optString("total_words").takeIf { it.isNotBlank() && it != "null" } ?: dec(data, "total")?.let { Bn.takaWords(it) } ?: ""
            wrap(c, "কথায়: $words", m, y, right - m, small, 11f * sc).also { y = it + 4f }
        }

        // ---------------------------------------------------------------- footer
        val footer = spec.optString("footer", "signature")
        val note = company.optString("note_bn").takeIf { it.isNotBlank() && it != "null" }
        if (footer == "terms" || footer == "both") { y = wrap(c, note ?: "এই ইনভয়েস বা এর QR পরিশোধের প্রমাণ নয়; পরিশোধের প্রমাণ যাচাইকৃত রসিদ।", m, y + 6f, right - m, small, 11f * sc) }
        if (footer == "thanks") { val t = note ?: "আমাদের সাথে ব্যবসার জন্য ধন্যবাদ।"; c.drawText(t, (w - small.measureText(t)) / 2f, y + 10f, small); y += 14f }
        val qrBottom = qrText != null && (qrPos == "bottom_left" || qrPos == "bottom_right" || fam == "receipt")
        if (qrBottom) {
            val qx = if (fam == "receipt") (w - qrSize) / 2f else if (qrPos == "bottom_left") m else right - qrSize
            val qy = if (fam == "receipt") y + 6f else h - m - qrSize - 14f
            qrBitmap(qrText!!, qrSize.toInt())?.let { c.drawBitmap(it, qx, qy, null) }
            if (fam == "receipt") y += qrSize + 10f
        }
        if (footer == "signature" || footer == "both") {
            val sx = if (qrBottom && qrPos == "bottom_right" && fam != "receipt") m else right - 120f * sc
            val sy = if (fam == "receipt") y + 24f else h - m - 22f
            c.drawRect(sx, sy, sx + 120f * sc, sy + 0.8f, txt); c.drawText("অনুমোদিত স্বাক্ষর", sx + 16f * sc, sy + 11f * sc, small)
            if (fam == "receipt") y += 40f
        }
        if (sample) c.drawText("নমুনা — আসল ইনভয়েস নয়", m, h - m / 2f - 9f, Paint(small).apply { color = Color.RED })
        if (watermark.isNotBlank()) c.drawText(watermark, m, h - m / 2f, Paint(small).apply { color = Color.GRAY })
    }

    /** Simple word wrap for Bengali text (breaks at spaces). Returns the next y. */
    private fun wrap(c: Canvas, text: String, x: Float, y0: Float, width: Float, paint: Paint, lineH: Float): Float {
        var y = y0; var line = ""
        for (word in text.split(' ')) {
            val t = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(t) > width && line.isNotEmpty()) { c.drawText(line, x, y, paint); y += lineH; line = word } else line = t
        }
        if (line.isNotEmpty()) { c.drawText(line, x, y, paint); y += lineH }
        return y
    }

    /** Gallery thumbnail / share image of one design. */
    fun bitmap(spec: JSONObject, data: JSONObject, watermark: String, widthPx: Int): Bitmap {
        val p = paper(spec)
        val k = widthPx / p.w.toFloat()
        val bmp = Bitmap.createBitmap(widthPx, (p.h * k).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(k, k)
        draw(c, spec, data, watermark)
        return bmp
    }
}

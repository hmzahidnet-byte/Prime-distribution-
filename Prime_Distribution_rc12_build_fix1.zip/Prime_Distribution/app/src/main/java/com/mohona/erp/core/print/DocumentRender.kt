package com.mohona.erp.core.print

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File

/**
 * PDF / image rendering and sharing (S49). Every document is rendered from the lines the server authorised
 * (api.v1_print_authorize), with the server's watermark (who + when) on each page. Files live in the app cache only.
 */
object DocumentRender {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 40f

    private fun sharedDir(context: Context): File = File(context.cacheDir, "shared").apply { mkdirs() }

    fun pdf(context: Context, title: String, lines: List<String>, watermark: String, fileName: String): File {
        val doc = PdfDocument()
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f; isFakeBoldText = true; color = Color.BLACK }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.BLACK }
        val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; color = Color.GRAY }
        val perPage = ((PAGE_H - 2 * MARGIN - 50f) / 16f).toInt()
        val pages = if (lines.isEmpty()) listOf(emptyList()) else lines.chunked(perPage)
        pages.forEachIndexed { i, chunk ->
            val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, i + 1).create())
            val c = page.canvas
            c.drawText(title, MARGIN, MARGIN + 10f, titlePaint)
            var y = MARGIN + 40f
            chunk.forEach { c.drawText(it, MARGIN, y, textPaint); y += 16f }
            if (watermark.isNotBlank()) c.drawText(watermark + " · পৃষ্ঠা ${i + 1}/${pages.size}", MARGIN, PAGE_H - MARGIN / 2, markPaint)
            doc.finishPage(page)
        }
        val file = File(sharedDir(context), fileName)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** A card image (PNG or JPG) drawn from the same authorised lines; masked values arrive already masked. */
    fun image(context: Context, title: String, lines: List<String>, watermark: String, fileName: String, jpg: Boolean = false): File {
        val w = 1080
        val h = (160 + lines.size * 54 + 80).coerceAtLeast(400)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 54f; isFakeBoldText = true; color = Color.BLACK }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 40f; color = Color.DKGRAY }
        val markPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 28f; color = Color.GRAY }
        c.drawText(title, 48f, 96f, titlePaint)
        var y = 180f
        lines.forEach { c.drawText(it, 48f, y, textPaint); y += 54f }
        if (watermark.isNotBlank()) c.drawText(watermark, 48f, h - 36f, markPaint)
        val file = File(sharedDir(context), fileName)
        file.outputStream().use { bmp.compress(if (jpg) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG, 92, it) }
        bmp.recycle()
        return file
    }

    /**
     * Invoice PDF in the design the invoice was ISSUED with (one of 50; see InvoiceRender). Same drawing as the gallery preview.
     */
    fun invoicePdf(context: Context, spec: org.json.JSONObject, invoice: org.json.JSONObject, watermark: String, fileName: String): File {
        val paper = InvoiceRender.paper(spec)
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(paper.w, paper.h, 1).create())
        InvoiceRender.draw(page.canvas, spec, invoice, watermark)
        doc.finishPage(page)
        val file = File(sharedDir(context), fileName)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Invoice as a share image (PNG) in its issued design. */
    fun invoiceImage(context: Context, spec: org.json.JSONObject, invoice: org.json.JSONObject, watermark: String, fileName: String): File {
        val bmp = InvoiceRender.bitmap(spec, invoice, watermark, 1240)
        val file = File(sharedDir(context), fileName)
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 92, it) }
        bmp.recycle()
        return file
    }

    fun share(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "শেয়ার").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

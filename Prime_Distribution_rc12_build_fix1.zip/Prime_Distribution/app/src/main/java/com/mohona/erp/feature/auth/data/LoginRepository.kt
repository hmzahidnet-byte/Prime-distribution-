package com.mohona.erp.feature.auth.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.AppError
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.ErrorKind
import com.mohona.erp.core.net.SessionTokens
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class CompanyPosition(val assignmentId: String, val positionCode: String, val nameBn: String, val usable: Boolean, val mfaRequired: Boolean)
data class CompanyChoice(val companyId: String, val code: String, val nameBn: String, val membershipId: String, val positions: List<CompanyPosition>)
data class DeviceInfo(val id: String, val name: String, val platform: String, val status: String, val thisDevice: Boolean)

/**
 * Login & identity (S16, replaces the legacy data/AuthRepository — OI-05).
 *  First time / forgot PIN: [otpStart] -> [requestOtp] -> [verifyOtp] -> [claimInvitation] (first time) -> [setPin] -> [registerDevice]
 *  Every day: [pinLogin] (Edge Function; the PIN is checked only in the database) -> [companies] -> position select.
 * The PIN never leaves this call path and is never stored or logged on the device.
 */
class LoginRepository(private val client: SupabaseClient, private val deviceId: () -> String) {

    suspend fun otpStart(phone: String): ApiResult<Boolean> =
        when (val r = client.callFunction("auth-otp-start", JSONObject().put("phone", phone))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.optBoolean("allowed", false))
        }

    suspend fun requestOtp(phone: String): ApiResult<Unit> = client.requestOtp(phone)
    suspend fun verifyOtp(phone: String, code: String): ApiResult<SessionTokens> = client.verifyOtp(phone, code)

    /** Returns true when a PIN still has to be set. */
    suspend fun claimInvitation(): ApiResult<Boolean> = when (val r = client.rpcObject("v1_auth_claim_invitation", write = true)) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> ApiResult.Ok(r.value.optBoolean("needs_pin", false))
    }

    suspend fun setPin(pin: String): ApiResult<String> {
        LoginRules.pinProblem(pin)?.let { return ApiResult.Err(AppError("E_PIN_WEAK", ErrorKind.VALIDATION, LoginRules.pinProblemBn(it)!!)) }
        return when (val r = client.rpcObject("v1_auth_set_pin", JSONObject().put("p_pin", pin), write = true)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.optString("status"))
        }
    }

    suspend fun registerDevice(name: String): ApiResult<String> =
        when (val r = client.rpcObject("v1_auth_register_device", JSONObject().put("p_device_id", deviceId()).put("p_name", name).put("p_platform", "android"), write = true)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.optString("device_id"))
        }

    /** Daily login. On success the PIN session becomes the client's session (refreshed through `auth-pin-refresh`). */
    suspend fun pinLogin(phone: String, pin: String, deviceName: String): ApiResult<Unit> {
        val canonical = LoginRules.canonicalPhone(phone) ?: return ApiResult.Err(AppError("E_AUTH_FAILED", ErrorKind.VALIDATION, "মোবাইল নম্বর সঠিক নয়।"))
        client.deviceId = deviceId()
        return when (val r = client.callFunction("auth-pin-login", JSONObject().put("phone", canonical).put("pin", pin)
            .put("device_id", deviceId()).put("device_name", deviceName).put("platform", "android"))) {
            is ApiResult.Err -> ApiResult.Err(mapLoginError(r.error))
            is ApiResult.Ok -> parsePinSession(r.value)?.let { client.adoptSession(it); ApiResult.Ok(Unit) }
                ?: ApiResult.Err(ErrorCatalog.badResponse("auth-pin-login"))
        }
    }

    suspend fun changePin(oldPin: String, newPin: String): ApiResult<Boolean> {
        LoginRules.pinProblem(newPin)?.let { return ApiResult.Err(AppError("E_PIN_WEAK", ErrorKind.VALIDATION, LoginRules.pinProblemBn(it)!!)) }
        return when (val r = client.rpcObject("v1_auth_change_pin", JSONObject().put("p_old_pin", oldPin).put("p_new_pin", newPin), write = true)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.optString("status") == "changed")
        }
    }

    suspend fun companies(): ApiResult<List<CompanyChoice>> = when (val r = client.rpcArray("v1_auth_my_companies")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseCompanies(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_auth_my_companies"))
    }

    suspend fun devices(): ApiResult<List<DeviceInfo>> = when (val r = client.rpcArray("v1_auth_my_devices")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseDevices(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_auth_my_devices"))
    }

    suspend fun revokeDevice(id: String, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_auth_revoke_device", JSONObject().put("p_device_id", id).put("p_person_id", JSONObject.NULL).put("p_reason", reason), write = true)

    /** Ends the session on the server (PIN + native when everywhere), then locally — local always happens. */
    suspend fun signOut(everywhere: Boolean = false): ApiResult<Unit> {
        val r = if (client.hasSession) client.callFunction("auth-sign-out", JSONObject().put("everywhere", everywhere), authenticated = true) else null
        client.forgetSession()
        return if (r is ApiResult.Err) r else ApiResult.Ok(Unit)
    }

    companion object {
        fun parsePinSession(o: JSONObject): SessionTokens? = try {
            SessionTokens(o.getString("access_token"), o.getString("refresh_token"), o.getLong("expires_at"), kind = "pin")
        } catch (e: Exception) { null }

        /** The Edge Function answers every failure with the same shape; only the code says locked vs failed. */
        fun mapLoginError(e: AppError): AppError {
            val code = e.code
            return when (code) {
                "E_AUTH_LOCKED" -> AppError(code, ErrorKind.FORBIDDEN, "অনেকবার ভুল হয়েছে; কিছুক্ষণ পরে চেষ্টা করুন বা ব্যবস্থাপককে জানান।", e.httpCode, null, e.requestId)
                "E_DEVICE_REVOKED" -> AppError(code, ErrorKind.FORBIDDEN, "এই ডিভাইস বাতিল করা হয়েছে; OTP দিয়ে আবার নিবন্ধন করুন।", e.httpCode, null, e.requestId)
                "E_DEVICE_LIMIT" -> AppError(code, ErrorKind.FORBIDDEN, "সর্বোচ্চ ডিভাইস নিবন্ধিত; পুরোনো একটি সরান।", e.httpCode, null, e.requestId)
                else -> if (e.kind == ErrorKind.NETWORK || e.kind == ErrorKind.TIMEOUT) e
                        else AppError("E_AUTH_FAILED", ErrorKind.VALIDATION, "মোবাইল নম্বর বা PIN সঠিক নয়।", e.httpCode, null, e.requestId)
            }
        }

        fun parseCompanies(a: JSONArray): List<CompanyChoice>? = try {
            (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                val p = o.optJSONArray("positions") ?: JSONArray()
                CompanyChoice(o.getString("company_id"), o.getString("code"), o.getString("name_bn"), o.getString("membership_id"),
                    (0 until p.length()).map { k -> p.getJSONObject(k).let { x ->
                        CompanyPosition(x.getString("assignment_id"), x.getString("position_code"), x.optString("name_bn"), x.optBoolean("usable"), x.optBoolean("mfa_required")) } })
            } }
        } catch (e: Exception) { null }

        fun parseDevices(a: JSONArray): List<DeviceInfo>? = try {
            (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                DeviceInfo(o.getString("id"), o.optString("name"), o.optString("platform"), o.getString("status"), o.optBoolean("this_device")) } }
        } catch (e: Exception) { null }

        /** The one position to enter automatically, when there is exactly one usable choice that needs no MFA. */
        fun autoPick(cs: List<CompanyChoice>): CompanyPosition? =
            cs.flatMap { it.positions }.filter { it.usable && !it.mfaRequired }.singleOrNull()
                ?.takeIf { cs.flatMap { c -> c.positions }.count { it.usable } == 1 }
    }
}

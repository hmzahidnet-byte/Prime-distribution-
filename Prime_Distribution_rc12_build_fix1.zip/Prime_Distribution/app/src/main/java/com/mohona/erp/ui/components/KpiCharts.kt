package com.mohona.erp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.data.Bn
import com.mohona.erp.feature.kpi.data.KpiFormat
import com.mohona.erp.feature.kpi.data.KpiValue
import com.mohona.erp.ui.theme.TextMuted
import com.mohona.erp.ui.theme.chartColor
import org.json.JSONObject

/**
 * A KPI drawn in the style the Chairman chose for it (report.kpi_style: number / line / bar / donut / sparkline, colour chart1..8).
 * Data is always the server's: series from api.v1_kpi_series, splits from api.v1_kpi_split. A missing value is "—", never zero.
 */
object KpiChartData {
    data class Point(val label: String, val value: Double?)

    fun points(o: JSONObject?): List<Point> {
        val a = o?.optJSONArray("points") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.map {
            Point(Bn.digits(it.optString("label")), if (it.isNull("value")) null else it.optString("value").toDoubleOrNull())
        }
    }

    fun parts(o: JSONObject?): List<Pair<String, Double>> {
        val a = o?.optJSONArray("rows") ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.mapNotNull { r ->
            r.optString("value").toDoubleOrNull()?.let { r.optString("label") to it }
        }
    }

    fun colorIndex(style: String): Int = style.removePrefix("chart").toIntOrNull()?.coerceIn(1, 8) ?: 1

    /** The axis unit in Bengali; money in lakh when large so labels stay readable. */
    fun unitBn(unit: String?, max: Double): Pair<String, Double> = when (unit) {
        "money" -> if (max >= 100_000) "লাখ টাকা" to 100_000.0 else "টাকা" to 1.0
        "percent" -> "%" to 1.0
        "qty" -> "পলি" to 1.0
        else -> "" to 1.0
    }
}

@Composable
fun KpiChart(v: KpiValue, grain: String, from: String?, to: String?, wingId: String?) {
    var series by remember(v.code, grain, from, to) { mutableStateOf<JSONObject?>(null) }
    var split by remember(v.code, from, to) { mutableStateOf<JSONObject?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val chart = v.style.chart
    val color = chartColor(KpiChartData.colorIndex(v.style.color))
    LaunchedEffect(v.code, chart, grain, from, to) {
        val repo = AppContainer.kpi ?: return@LaunchedEffect
        if (v.restricted || chart == "number") return@LaunchedEffect
        if (chart == "donut") {
            val by = KpiFormat.splitBy(v.code)
            if (by == null) { error = "এই KPI ভাগ করে দেখানো যায় না"; return@LaunchedEffect }
            when (val r = repo.split(v.code, by, from, to)) { is ApiResult.Ok -> split = r.value; is ApiResult.Err -> error = r.error.messageBn }
        } else {
            when (val r = repo.series(v.code, grain, from, to, wingId)) { is ApiResult.Ok -> series = r.value; is ApiResult.Err -> error = r.error.messageBn }
        }
    }
    Column(Modifier.fillMaxWidth()) {
        error?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = TextMuted) }
        when (chart) {
            "line", "bar" -> {
                val pts = KpiChartData.points(series)
                if (pts.isNotEmpty()) {
                    val (u, div) = KpiChartData.unitBn(v.unit, pts.maxOf { it.value ?: 0.0 })
                    val labels = pts.map { it.label }; val vals = pts.map { (it.value ?: 0.0) / div }
                    if (chart == "line") LineChart(labels, vals, u, lineColor = color)
                    else BarChart(labels, listOf(BarSeries(v.nameBn, vals, color)), u)
                    if (pts.any { it.value == null }) Text("— চিহ্নিত সময়ে তথ্য নেই (শূন্য ধরা হয়নি)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
            "sparkline" -> {
                val vals = KpiChartData.points(series).mapNotNull { it.value }
                if (vals.size >= 2) Sparkline(vals, color)
            }
            "donut" -> {
                val parts = KpiChartData.parts(split)
                if (parts.isNotEmpty()) DonutChart(parts.mapIndexed { i, (l, x) -> DonutPart(l, x, chartColor(i % 8 + 1)) },
                    KpiFormat.value(v), v.nameBn, if (v.unit == "money") " টাকা" else "")
                else if (split != null) Text("ভাগ করার মতো তথ্য নেই", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
        }
    }
}

@Composable
fun Sparkline(values: List<Double>, color: Color) {
    val min = values.min(); val max = values.max(); val span = (max - min).takeIf { it > 0 } ?: 1.0
    Canvas(Modifier.fillMaxWidth().height(36.dp)) {
        val stepX = size.width / (values.size - 1)
        for (i in 1 until values.size) {
            val y0 = size.height - ((values[i - 1] - min) / span * size.height).toFloat()
            val y1 = size.height - ((values[i] - min) / span * size.height).toFloat()
            drawLine(color, Offset((i - 1) * stepX, y0), Offset(i * stepX, y1), strokeWidth = 4f)
        }
        val last = size.height - ((values.last() - min) / span * size.height).toFloat()
        drawCircle(color, 6f, Offset(size.width, last))
    }
}

/**
 * Payment status mark (V165-12): the Chairman styles colour / icon / size / label / motion (S71), but the TICK appears only when the
 * server reports the payment verified AND posted — a theme can never turn a pending payment green.
 */
@Composable
fun PaymentStatusMark(verified: Boolean, posted: Boolean) {
    val ok = verified && posted
    val comp = if (ok) "payment.status.tick" else "payment.status.pending"
    val color = com.mohona.erp.ui.theme.DesignProps.color(comp, "color", if (ok) com.mohona.erp.ui.theme.GoodGreen else TextMuted)
    val label = com.mohona.erp.ui.theme.DesignProps.text(comp, "label_bn", if (ok) "যাচাই ও পোস্ট হয়েছে" else "যাচাই বাকি")
    val size = com.mohona.erp.ui.theme.DesignProps.dp(comp, "size_dp", 18.dp)
    androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        androidx.compose.material3.Icon(com.mohona.erp.ui.theme.IconRegistry.vector(com.mohona.erp.ui.theme.DesignProps.icon(comp, if (ok) "Verified" else "Schedule")),
            contentDescription = label, tint = color, modifier = Modifier.height(size).width(size))
        Text(" $label", style = MaterialTheme.typography.labelMedium, color = color)
    }
}

package com.mohona.erp.feature.forms.data

import android.content.Context
import android.net.Uri
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import java.security.MessageDigest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * OI-28: one attachment, end to end — pick (system picker) -> read -> SHA-256 -> api.v1_forms_attachment_begin (the SERVER chooses the
 * object path and checks type/size) -> Storage upload (never overwrite) -> api.v1_forms_attachment_confirm (the server checks the object
 * exists). The field then stores the attachment id. Retrying uses the same idempotency keys, so a timeout never creates a second record.
 */
object AttachmentUploader {
    /** Hard local cap so a huge file never fills the phone's memory; the company limit (forms.attachment.max_mb) is checked by the server. */
    const val LOCAL_MAX_BYTES: Long = 25L * 1024 * 1024

    data class Outcome(val attachmentId: String?, val messageBn: String)

    fun sha256Hex(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    suspend fun upload(context: Context, uri: Uri, formId: String, fieldKey: String): Outcome {
        val repo = AppContainer.forms ?: return Outcome(null, "সংযুক্ত মোড নয়।")
        val client = AppContainer.client ?: return Outcome(null, "সংযুক্ত মোড নয়।")
        val read = withContext(Dispatchers.IO) {
            runCatching {
                val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
                val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                    val buf = java.io.ByteArrayOutputStream()
                    val chunk = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = input.read(chunk)
                        if (n < 0) break
                        total += n
                        if (total > LOCAL_MAX_BYTES) throw IllegalStateException("too big")
                        buf.write(chunk, 0, n)
                    }
                    buf.toByteArray()
                } ?: throw IllegalStateException("unreadable")
                mime to bytes
            }
        }
        val (mime, bytes) = read.getOrElse { e ->
            return Outcome(null, if (e.message == "too big") "ফাইল খুব বড় (২৫ MB-এর বেশি)।" else "ফাইলটি পড়া যায়নি।")
        }
        if (bytes.isEmpty()) return Outcome(null, "ফাইলটি খালি।")
        val sha = sha256Hex(bytes)
        val ticket = when (val r = repo.attachmentBegin(formId, fieldKey, mime, bytes.size.toLong(), sha, "att-begin-$formId-$fieldKey-$sha".take(120))) {
            is ApiResult.Ok -> r.value
            is ApiResult.Err -> return Outcome(null, r.error.messageBn)
        }
        when (val up = client.uploadObject(ticket.bucket, ticket.path, bytes, mime)) {
            is ApiResult.Err -> if (up.error.httpCode != 409) return Outcome(null, "আপলোড হয়নি: " + up.error.messageBn)   // 409 = already uploaded on a retry
            is ApiResult.Ok -> Unit
        }
        return when (val c = repo.attachmentConfirm(ticket.attachmentId, "att-confirm-" + ticket.attachmentId)) {
            is ApiResult.Ok -> Outcome(ticket.attachmentId, "সংযুক্তি যোগ হয়েছে (" + (bytes.size / 1024).coerceAtLeast(1) + " KB)।")
            is ApiResult.Err -> Outcome(null, c.error.messageBn)
        }
    }
}

package com.mohona.erp.feature.forms.data

import com.mohona.erp.feature.config.data.RuleCondition
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.OffsetDateTime
import org.json.JSONArray
import org.json.JSONObject

data class FieldError(val field: String, val code: String, val messageBn: String)
data class FormCheck(val ok: Boolean, val errors: List<FieldError>, val visible: List<String>, val values: JSONObject)

/**
 * Dynamic Forms (S14) client engine. Mirrors config.fn_form_check / fn_form_value_error so the form screen can show errors
 * and visibility instantly — the SERVER re-checks everything on save and submit and remains the authority.
 * [normalize] turns Bengali input into the canonical, locale-independent values the server accepts (ASCII digits, ISO dates).
 */
object FormEngine {
    val TYPES = setOf("text", "textarea", "integer", "decimal", "money", "date", "datetime", "bool", "select", "multiselect",
        "phone", "email", "qr", "photo", "file")
    private val UUID = Regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
    private val DATE = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
    private val DATETIME = Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2}(\\.[0-9]{1,6})?)?(Z|[+-][0-9]{2}:[0-9]{2})$")
    private val PHONE = Regex("^01[3-9][0-9]{8}$")
    private val EMAIL = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    private val QR = Regex("^[!-~]{1,512}$")

    fun messageBn(code: String): String = when (code) {
        "required" -> "এই ঘর পূরণ করুন।"
        "type" -> "মানের ধরন সঠিক নয়।"
        "range" -> "মান অনুমোদিত সীমার বাইরে।"
        "length" -> "লেখার দৈর্ঘ্য অনুমোদিত সীমার বাইরে।"
        "pattern" -> "ফরম্যাট সঠিক নয়।"
        "option" -> "তালিকার বাইরের মান দেওয়া হয়েছে।"
        "attachment" -> "সংযুক্তি পাওয়া যায়নি বা আপলোড সম্পূর্ণ হয়নি।"
        "hidden" -> "লুকানো ঘরে মান দেওয়া যাবে না।"
        "unknown" -> "ফর্মে এই ঘর নেই।"
        "forbidden" -> "এই ঘর বদলানোর অনুমতি নেই।"
        else -> "মান গ্রহণযোগ্য নয়।"
    }

    /** Bengali digits (০-৯) -> ASCII. */
    fun asciiDigits(s: String): String = buildString(s.length) { for (c in s) append(if (c in '০'..'৯') '0' + (c - '০') else c) }

    /** User input -> canonical value for the field type. Returns the input unchanged when it cannot be converted (the check reports it). */
    fun normalize(field: JSONObject, raw: Any?): Any? {
        if (raw == null || raw == JSONObject.NULL) return null
        val type = field.optString("type")
        if (raw is String) {
            val t = raw.trim()
            if (t.isEmpty()) return null
            return when (type) {
                "integer" -> asciiDigits(t).replace(",", "").toLongOrNull() ?: raw
                "decimal", "money" -> asciiDigits(t).replace(",", "").toBigDecimalOrNull() ?: raw
                "phone" -> asciiDigits(t).replace(Regex("[\\s-]"), "").let { if (it.startsWith("+880")) it.substring(3) else if (it.startsWith("880")) it.substring(2) else it }
                "date", "datetime", "qr" -> asciiDigits(t)
                "email" -> t.lowercase()
                else -> t
            }
        }
        return raw
    }

    private fun num(v: Any?): BigDecimal? = when (v) {
        is BigDecimal -> v
        is Int, is Long -> BigDecimal.valueOf((v as Number).toLong())
        is Number -> BigDecimal(v.toString())
        else -> null
    }

    private fun options(field: JSONObject): Set<String> {
        val a = field.optJSONArray("options") ?: return emptySet()
        return (0 until a.length()).map { a.getJSONObject(it).optString("value") }.toSet()
    }

    fun isIsoDate(s: String): Boolean = DATE.matches(s) && runCatching { LocalDate.parse(s).toString() == s }.getOrDefault(false)
    fun isIsoDateTime(s: String): Boolean = DATETIME.matches(s) && isIsoDate(s.take(10)) && runCatching { OffsetDateTime.parse(s); true }.getOrDefault(false)

    /** One value against one field; null = valid. Attachments are checked only for shape (existence is server-side). */
    fun valueError(field: JSONObject, v: Any?, moneyScale: Int = 2): String? {
        val type = field.optString("type")
        when (type) {
            "text", "textarea" -> {
                val s = v as? String ?: return "type"
                val max = if (field.has("max_length")) field.getInt("max_length") else if (type == "text") 2000 else 10000
                val min = field.optInt("min_length", 0)
                if (s.codePointCount(0, s.length) !in min..max) return "length"
                if (field.has("pattern") && !Regex(field.getString("pattern")).containsMatchIn(s)) return "pattern"
            }
            "integer", "decimal", "money" -> {
                val n = num(v) ?: return "type"
                val scale = when (type) { "integer" -> 0; "money" -> moneyScale; else -> field.optInt("decimals", 4) }
                if (n.compareTo(n.setScale(scale, RoundingMode.HALF_UP)) != 0) return "type"
                if ((field.has("min") && n < num(field.get("min"))!!) || (field.has("max") && n > num(field.get("max"))!!)) return "range"
            }
            "date" -> {
                val s = v as? String ?: return "type"
                if (!isIsoDate(s)) return "type"
                if ((field.has("min") && s < field.getString("min")) || (field.has("max") && s > field.getString("max"))) return "range"
            }
            "datetime" -> if (v !is String || !isIsoDateTime(v)) return "type"
            "bool" -> if (v !is Boolean) return "type"
            "select" -> { val s = v as? String ?: return "type"; if (s !in options(field)) return "option" }
            "multiselect" -> {
                val a = v as? JSONArray ?: return "type"
                val items = (0 until a.length()).map { a.get(it) as? String ?: return "type" }
                if (items.any { it !in options(field) } || items.toSet().size != items.size) return "option"
                if ((field.has("min") && items.size < field.getInt("min")) || (field.has("max") && items.size > field.getInt("max"))) return "range"
            }
            "phone" -> if (v !is String || !PHONE.matches(v)) return "pattern"
            "email" -> if (v !is String || v.length > 254 || !EMAIL.matches(v)) return "pattern"
            "qr" -> if (v !is String || !QR.matches(v)) return "pattern"
            "photo", "file" -> if (v !is String || !UUID.matches(v)) return "type"
            else -> return "type"
        }
        return null
    }

    private fun isEmpty(v: Any?): Boolean = v == null || v == JSONObject.NULL || (v is String && v.isBlank()) || (v is JSONArray && v.length() == 0)

    /** Same algorithm as the server: fields in order, conditions see earlier visible values only, hidden values dropped/refused. */
    fun check(def: JSONObject, values: JSONObject, partial: Boolean, moneyScale: Int = 2, hiddenPolicy: String = "strip"): FormCheck {
        val fields = def.optJSONArray("fields") ?: JSONArray()
        val byKey = (0 until fields.length()).associate { fields.getJSONObject(it).optString("key") to fields.getJSONObject(it) }
        val errs = ArrayList<FieldError>()
        fun err(f: String, c: String, m: String = messageBn(c)) { errs += FieldError(f, c, m) }
        values.keys().forEach { if (it !in byKey) err(it, "unknown") }
        val groups = HashMap<String, JSONObject?>()
        def.optJSONArray("groups")?.let { g -> for (i in 0 until g.length()) g.getJSONObject(i).let { groups[it.optString("key")] = it.optJSONObject("visible_if") } }
        val facts = JSONObject(); val clean = JSONObject(); val visible = ArrayList<String>()
        for (i in 0 until fields.length()) {
            val f = fields.getJSONObject(i); val k = f.optString("key")
            val v = values.opt(k).takeUnless { isEmpty(it) }
            val fieldVis = f.optJSONObject("visible_if")?.let { RuleCondition.eval(it, facts) } ?: true
            val groupVis = f.optString("group", "").takeIf { it.isNotEmpty() }?.let { g -> groups[g]?.let { RuleCondition.eval(it, facts) } ?: true } ?: true
            if (!(fieldVis && groupVis)) { if (v != null && hiddenPolicy == "reject") err(k, "hidden"); continue }
            visible += k
            val required = f.optBoolean("required", false) || (f.optJSONObject("required_if")?.let { RuleCondition.eval(it, facts) } ?: false)
            if (v == null) { if (required && !partial) err(k, "required"); continue }
            val e = valueError(f, v, moneyScale)
            if (e != null) { err(k, e); continue }
            clean.put(k, v); facts.put(k, v)
        }
        if (!partial && errs.isEmpty()) {
            val checks = def.optJSONArray("checks") ?: JSONArray()
            for (i in 0 until checks.length()) {
                val c = checks.getJSONObject(i)
                if (c.optString("kind") == "compare") {
                    val a = clean.opt(c.optString("left")); val b = clean.opt(c.optString("right"))
                    if (a == null || b == null) continue
                    val cmp = num(a)?.let { x -> num(b)?.let { x.compareTo(it) } } ?: a.toString().compareTo(b.toString())
                    val ok = when (c.optString("op")) { "=" -> cmp == 0; "!=" -> cmp != 0; ">" -> cmp > 0; ">=" -> cmp >= 0; "<" -> cmp < 0; else -> cmp <= 0 }
                    if (!ok) err(c.optString("left"), "check", c.optString("message_bn"))
                } else if (!RuleCondition.eval(c.getJSONObject("condition"), clean)) {
                    err("_form", "check", c.optString("message_bn"))
                }
            }
        }
        return FormCheck(errs.isEmpty(), errs, visible, clean)
    }

    /** Values to send: only fields this position may write ('write' / 'entry'); masked placeholders are never resent. */
    fun writable(def: JSONObject, values: JSONObject): JSONObject {
        val fields = def.optJSONArray("fields") ?: return JSONObject()
        val out = JSONObject()
        for (i in 0 until fields.length()) {
            val f = fields.getJSONObject(i)
            if (f.optString("access", "write") in setOf("write", "entry") && values.has(f.optString("key"))) out.put(f.optString("key"), values.get(f.optString("key")))
        }
        return out
    }

    /** Parses the server's E_FORM_VALIDATION detail (JSON list of {field, code, message_bn}). */
    fun parseErrors(detail: String?): List<FieldError> = runCatching {
        val a = JSONArray(detail ?: return emptyList())
        (0 until a.length()).map { a.getJSONObject(it).let { o -> FieldError(o.optString("field"), o.optString("code"), o.optString("message_bn", messageBn(o.optString("code")))) } }
    }.getOrDefault(emptyList())
}

/** Mirror of config.fn_mask_render, for previews of the Chairman's masking settings. */
object FormMask {
    fun render(value: Any?, style: String, keep: Int): Any? {
        if (value == null || value == JSONObject.NULL) return value
        if (style != "partial" || value !is String) return "••••••"
        val n = value.codePointCount(0, value.length)
        if (keep <= 0 || n <= keep * 2) return "•".repeat(maxOf(n, 4))
        return "•".repeat(n - keep) + value.substring(value.offsetByCodePoints(0, n - keep))
    }
}

package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.feature.config.data.Setting
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ErrorState
import com.mohona.erp.ui.components.LoadingState
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.forms.FormUi
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch

/**
 * Chairman settings (S17): every registered setting, grouped by module, edited by type (switch / number / choice /
 * multi-choice / text). Each change needs a reason, is version-checked and audited on the server; editing is offered only
 * with the config.settings.manage hint (the server decides).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val canEdit = PermissionHints.can(LocalPermissions.current, "config.settings.manage")
    var settings by remember { mutableStateOf<List<Setting>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var module by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<Setting?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        when (val r = AppContainer.settings?.list()) { is ApiResult.Ok -> settings = r.value; is ApiResult.Err -> error = r.error.messageBn; null -> error = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("সেটিং", onBack)
        val all = settings
        when {
            error != null -> ErrorState(error!!, onRetry = { error = null; reload++ })
            all == null -> LoadingState()
            else -> Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = module == null, onClick = { module = null }, label = { Text("সব") })
                    all.map { it.module }.distinct().sorted().forEach { m -> FilterChip(selected = module == m, onClick = { module = m }, label = { Text(m) }) }
                }
                all.filter { module == null || it.module == module }.forEach { s ->
                    AppCard(onClick = if (canEdit && s.valueType != "json") ({ editing = s }) else null) {
                        Column(Modifier.padding(12.dp)) {
                            Text(s.nameBn, style = MaterialTheme.typography.bodyMedium)
                            Text(s.key + " = " + FormUi.display(s.value ?: s.defaultValue) + if (s.isDefault) " (ডিফল্ট)" else " · v" + s.version,
                                style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            if (s.requiresAal2) Text("দুই-ধাপ যাচাই লাগবে", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
    editing?.let { s ->
        SettingEditor(s, onDismiss = { editing = null }) { value, reason, done ->
            scope.launch {
                when (val r = AppContainer.settings?.set(s.key, value, s.version, reason, UUID.randomUUID().toString())) {
                    is ApiResult.Ok -> { editing = null; reload++; done(null) }
                    is ApiResult.Err -> done(r.error.messageBn)
                    null -> done("সংযুক্ত মোড নয়।")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SettingEditor(s: Setting, onDismiss: () -> Unit, onSave: (Any, String, (String?) -> Unit) -> Unit) {
    val current = s.value ?: s.defaultValue
    var text by remember { mutableStateOf(if (current is List<*>) "" else FormUi.display(current)) }
    var flag by remember { mutableStateOf(current == true) }
    var picked by remember { mutableStateOf((current as? List<*>)?.map { it.toString() }?.toSet() ?: emptySet()) }
    var reason by remember { mutableStateOf("") }
    var problem by remember { mutableStateOf<String?>(null) }
    val allowed = s.allowed?.map { it.toString() }
    fun candidate(): Any? = when (s.valueType) {
        "bool" -> flag
        "int" -> text.trim().toLongOrNull()
        "numeric" -> text.trim().toDoubleOrNull()
        "text_array" -> picked.toList()
        else -> text
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(s.nameBn) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            s.descriptionBn?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = TextMuted) }
            when {
                s.valueType == "bool" -> Row(verticalAlignment = Alignment.CenterVertically) { Text("চালু", Modifier.weight(1f)); Switch(checked = flag, onCheckedChange = { flag = it }) }
                s.valueType == "text_array" && allowed != null -> FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    allowed.forEach { a -> FilterChip(selected = a in picked, onClick = { picked = if (a in picked) picked - a else picked + a }, label = { Text(a) }) }
                }
                s.valueType == "text" && allowed != null -> FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    allowed.forEach { a -> FilterChip(selected = text == a, onClick = { text = a }, label = { Text(a) }) }
                }
                else -> OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("মান") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ (বাধ্যতামূলক)") }, modifier = Modifier.fillMaxWidth())
            problem?.let { Text(it, color = BadRed, style = MaterialTheme.typography.labelSmall) }
        }
    }, confirmButton = {
        TextButton(onClick = {
            val c = candidate()
            val local = s.validate(c)
            problem = when {
                reason.isBlank() -> "কারণ লিখুন।"
                local != null -> local
                else -> null
            }
            if (problem == null && c != null) onSave(c, reason.trim()) { problem = it }
        }) { Text("সংরক্ষণ") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } })
}

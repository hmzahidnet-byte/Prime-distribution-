package com.mohona.erp.ui.forms

import com.mohona.erp.feature.forms.data.FieldError
import com.mohona.erp.feature.forms.data.FormEngine
import org.json.JSONArray
import org.json.JSONObject

/** Widget chosen for a field type (the metadata renderer's single mapping table). */
enum class Widget { TEXT, MULTILINE, NUMBER, DECIMAL, DATE, DATETIME, SWITCH, SINGLE_CHOICE, MULTI_CHOICE, PHONE, EMAIL, QR, ATTACHMENT, UNSUPPORTED }

data class FieldView(val key: String, val labelBn: String, val helpBn: String?, val widget: Widget, val required: Boolean, val editable: Boolean,
                     val masked: Boolean, val options: List<Pair<String, String>>, val group: String?, val raw: JSONObject)

/** Pure part of the metadata renderer (S17): which fields to show, how, and with which errors. JVM-testable. */
object FormUi {
    fun widgetFor(type: String): Widget = when (type) {
        "text" -> Widget.TEXT; "textarea" -> Widget.MULTILINE; "integer" -> Widget.NUMBER; "decimal", "money" -> Widget.DECIMAL
        "date" -> Widget.DATE; "datetime" -> Widget.DATETIME; "bool" -> Widget.SWITCH; "select" -> Widget.SINGLE_CHOICE
        "multiselect" -> Widget.MULTI_CHOICE; "phone" -> Widget.PHONE; "email" -> Widget.EMAIL; "qr" -> Widget.QR
        "photo", "file" -> Widget.ATTACHMENT; else -> Widget.UNSUPPORTED
    }

    private fun options(f: JSONObject): List<Pair<String, String>> {
        val a = f.optJSONArray("options") ?: return emptyList()
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> o.optString("value") to o.optString("label_bn", o.optString("value")) } }
    }

    /** Visible fields in order (server algorithm via [FormEngine.check]); 'none' fields never reach the client. */
    fun visibleFields(def: JSONObject, values: JSONObject, hiddenPolicy: String = "strip", moneyScale: Int = 2): List<FieldView> {
        val visible = FormEngine.check(def, values, partial = true, moneyScale = moneyScale, hiddenPolicy = hiddenPolicy).visible.toSet()
        val fields = def.optJSONArray("fields") ?: JSONArray()
        return (0 until fields.length()).map { fields.getJSONObject(it) }.filter { it.optString("key") in visible }.map { f ->
            val access = f.optString("access", "write")
            FieldView(f.optString("key"), f.optString("label_bn", f.optString("key")), f.optString("help_bn").ifBlank { null }, widgetFor(f.optString("type")),
                f.optBoolean("required", false), access == "write" || access == "entry", access == "masked" || access == "entry", options(f),
                f.optString("group").ifBlank { null }, f)
        }
    }

    /** User input (possibly Bengali digits) -> canonical value for the field, then into a NEW values object. */
    fun withValue(values: JSONObject, field: JSONObject, input: Any?): JSONObject {
        val out = JSONObject(values.toString())
        val v = FormEngine.normalize(field, input)
        // while typing "12." or "1.50" keep the user's text; [finalize] converts it before sending
        val keepTyping = input is String && v is Number && display(v) != FormEngine.asciiDigits(input.trim()).replace(",", "")
        if (v == null) out.remove(field.optString("key")) else out.put(field.optString("key"), if (keepTyping) input else v)
        return out
    }

    /** Canonical values for sending: every still-typed text of a numeric field becomes a number (or stays for the server to refuse). */
    fun finalize(def: JSONObject, values: JSONObject): JSONObject {
        val out = JSONObject(values.toString())
        val fields = def.optJSONArray("fields") ?: return out
        for (i in 0 until fields.length()) {
            val f = fields.getJSONObject(i); val k = f.optString("key")
            if (out.has(k) && out.get(k) is String) FormEngine.normalize(f, out.get(k))?.let { out.put(k, it) }
        }
        return out
    }

    /** Errors per field for display: local check first; server errors (E_FORM_VALIDATION detail) replace them after a save. */
    fun errorsByField(errors: List<FieldError>): Map<String, String> = errors.groupBy { it.field }.mapValues { (_, e) -> e.first().messageBn }

    /** Text shown in an editor for a stored value (numbers without trailing zeros, lists joined). */
    fun display(v: Any?): String = when (v) {
        null, JSONObject.NULL -> ""
        is java.math.BigDecimal -> v.stripTrailingZeros().toPlainString()
        is Double -> java.math.BigDecimal(v.toString()).stripTrailingZeros().toPlainString()
        is JSONArray -> (0 until v.length()).joinToString(", ") { v.get(it).toString() }
        else -> v.toString()
    }
}

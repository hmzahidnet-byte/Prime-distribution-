package com.mohona.erp.feature.config.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class ApprovalItem(val id: String, val documentType: String, val documentId: String, val amount: Double, val makerNameBn: String?,
                        val required: Int, val approvals: Int, val rowVersion: Int)
data class DecisionResult(val status: String, val approvals: Int, val required: Int)
enum class RequestState { SUCCEEDED, IN_PROGRESS, UNKNOWN }

/** Approval inbox / decisions (ADR-02), timeout recovery (request status by idempotency key), break-glass (ADR-03). */
class ApprovalRepository(private val client: SupabaseClient) {

    suspend fun inbox(): ApiResult<List<ApprovalItem>> = when (val r = client.rpcArray("v1_approval_inbox")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseInbox(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_approval_inbox"))
    }

    suspend fun decide(requestId: String, approve: Boolean, expectedRowVersion: Int, reason: String, key: String): ApiResult<DecisionResult> =
        when (val r = client.rpcObject("v1_approval_decide", JSONObject().put("p_request_id", requestId).put("p_decision", if (approve) "approve" else "reject")
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(DecisionResult(r.value.optString("status"), r.value.optInt("approvals"), r.value.optInt("required")))
        }

    /** After a timeout: did the write with this Idempotency-Key reach the server? Only UNKNOWN is safe to resend as new. */
    suspend fun requestStatus(idempotencyKey: String): ApiResult<RequestState> =
        when (val r = client.rpcObject("v1_core_request_status", JSONObject().put("p_key", idempotencyKey))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(stateOf(r.value.optString("status")))
        }

    suspend fun breakglassRequest(permissions: List<String>, reason: String, key: String): ApiResult<String> =
        when (val r = client.rpc("v1_breakglass_request", JSONObject().put("p_permissions", JSONArray(permissions)).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.toString())
        }

    suspend fun breakglassApprove(grantId: String, key: String): ApiResult<String> =
        when (val r = client.rpcObject("v1_breakglass_approve", JSONObject().put("p_grant_id", grantId), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.optString("status"))
        }

    companion object {
        fun stateOf(s: String): RequestState = when (s) { "succeeded" -> RequestState.SUCCEEDED; "in_progress" -> RequestState.IN_PROGRESS; else -> RequestState.UNKNOWN }

        fun parseInbox(a: JSONArray): List<ApprovalItem>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                ApprovalItem(o.getString("id"), o.getString("document_type"), o.getString("document_id"), o.optDouble("amount", 0.0),
                    if (o.isNull("maker_name_bn")) null else o.optString("maker_name_bn"), o.optInt("required_approvals", 1), o.optInt("approvals"), o.optInt("row_version"))
            }
        } catch (e: Exception) { null }
    }
}

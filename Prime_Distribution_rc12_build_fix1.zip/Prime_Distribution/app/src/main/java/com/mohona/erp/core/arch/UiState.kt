package com.mohona.erp.core.arch

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.AppError
import com.mohona.erp.core.net.ErrorKind

/** The four states every screen renders (MVVM: ViewModel exposes UiState, Composable only draws it). */
sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data object Empty : UiState<Nothing>
    data class Content<T>(val data: T) : UiState<T>
    data class Failed(val error: AppError) : UiState<Nothing> {
        val isForbidden: Boolean get() = error.kind == ErrorKind.FORBIDDEN
        val needsLogin: Boolean get() = error.kind == ErrorKind.SESSION_EXPIRED
    }
}

fun <T> ApiResult<T>.toUiState(isEmpty: (T) -> Boolean = { false }): UiState<T> = when (this) {
    is ApiResult.Ok -> if (isEmpty(value)) UiState.Empty else UiState.Content(value)
    is ApiResult.Err -> UiState.Failed(error)
}

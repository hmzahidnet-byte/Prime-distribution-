package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray

/** My day (S44–S46): rotating attendance QR, today's route visits (check-in / outcome / missed). */
@Composable
fun MyDayScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var qr by remember { mutableStateOf<String?>(null) }
    var visits by remember { mutableStateOf(JSONArray()) }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            (AppContainer.field?.attendanceQr() as? ApiResult.Ok)?.let { qr = it.value.optString("payload") }
            delay(20_000)                                     // tokens live 30 s; refresh before expiry
        }
    }
    LaunchedEffect(reload) { (AppContainer.field?.myVisits() as? ApiResult.Ok)?.let { visits = it.value } }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("আমার দিন", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("হাজিরা-QR (গেটে দেখান, প্রতি ৩০ সেকেন্ডে বদলায়)", style = MaterialTheme.typography.titleSmall)
            Text(qr ?: "—", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text("আজকের ভিজিট", style = MaterialTheme.typography.titleSmall)
            (0 until visits.length()).map { visits.getJSONObject(it) }.forEach { v ->
                AppCard {
                    Column(Modifier.padding(12.dp)) {
                        Text("${v.optInt("seq")}. ${v.optString("name_bn")} · ${v.optString("status")}", style = MaterialTheme.typography.bodyMedium)
                        if (v.optString("status") == "planned") Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (!v.optBoolean("checked_in")) OutlinedButton(onClick = { scope.launch {
                                when (val r = AppContainer.field?.checkIn(v.getString("id"), null, null)) { is ApiResult.Ok -> reload++; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text("চেক-ইন") }
                            else OutlinedButton(onClick = { scope.launch {
                                when (val r = AppContainer.field?.outcome(v.getString("id"), "order", null, null)) { is ApiResult.Ok -> reload++; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text("অর্ডার নেওয়া হয়েছে") }
                            OutlinedButton(onClick = { scope.launch {
                                when (val r = AppContainer.field?.missed(v.getString("id"), "other", "যাওয়া হয়নি")) { is ApiResult.Ok -> reload++; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text("হয়নি") }
                        }
                    }
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

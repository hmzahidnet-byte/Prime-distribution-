package com.mohona.erp.core.net

import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

/** [bodyBytes] (binary upload, e.g. a photo to Storage) wins over [body] when both are set. */
data class HttpRequest(val method: String, val url: String, val headers: Map<String, String>, val body: String?, val bodyBytes: ByteArray? = null)
data class HttpResponse(val code: Int, val body: String, val headers: Map<String, String> = emptyMap())

class TransportTimeout(cause: Throwable) : Exception(cause)

/** Blocking HTTP seam. Production uses [UrlConnectionTransport]; JVM tests inject a fake. Always called off the main thread. */
fun interface HttpTransport {
    fun execute(request: HttpRequest): HttpResponse
}

/** Platform HttpURLConnection: no extra dependency, HTTPS only (cleartext is disabled in the manifest too). */
class UrlConnectionTransport(
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 30_000
) : HttpTransport {
    override fun execute(request: HttpRequest): HttpResponse {
        require(request.url.startsWith("https://")) { "only https is allowed" }
        val conn = URL(request.url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = request.method
            conn.connectTimeout = connectTimeoutMs
            conn.readTimeout = readTimeoutMs
            conn.instanceFollowRedirects = false
            request.headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val bytes = request.bodyBytes
            val body = request.body
            if (bytes != null) {
                conn.doOutput = true
                conn.setFixedLengthStreamingMode(bytes.size)
                conn.outputStream.use { it.write(bytes) }
            } else if (body != null) {
                conn.doOutput = true
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val headers = HashMap<String, String>()
            for ((k, v) in conn.headerFields) {
                if (k != null && v != null && v.isNotEmpty()) headers[k.lowercase()] = v[0]
            }
            return HttpResponse(code, text, headers)
        } catch (e: SocketTimeoutException) {
            throw TransportTimeout(e)
        } finally {
            conn.disconnect()
        }
    }
}

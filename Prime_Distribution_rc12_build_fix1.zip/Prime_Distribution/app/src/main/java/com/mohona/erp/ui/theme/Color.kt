package com.mohona.erp.ui.theme

import androidx.compose.ui.graphics.Color

// Colour names used by all existing screens. They are now LIVE getters over the Chairman-customisable tokens
// (ThemeRuntime), not constants: no screen has a hard-coded brand colour any more.
val OrangePrimary: Color get() = ThemeRuntime.tokens.colors.primary.toColor()
val OrangeDark: Color get() = ThemeRuntime.tokens.colors.primaryDark.toColor()
val OrangeSoft: Color get() = ThemeRuntime.tokens.colors.primarySoft.toColor()
val OnPrimary: Color get() = ThemeRuntime.tokens.colors.onPrimary.toColor()
val BackgroundWhite: Color get() = ThemeRuntime.tokens.colors.background.toColor()
val BackgroundGray: Color get() = ThemeRuntime.tokens.colors.surfaceAlt.toColor()
val TextDark: Color get() = ThemeRuntime.tokens.colors.text.toColor()
val TextMuted: Color get() = ThemeRuntime.tokens.colors.textMuted.toColor()
val DividerGray: Color get() = ThemeRuntime.tokens.colors.divider.toColor()
val GoodGreen: Color get() = ThemeRuntime.tokens.colors.good.toColor()
val WarnAmber: Color get() = ThemeRuntime.tokens.colors.warn.toColor()
val BadRed: Color get() = ThemeRuntime.tokens.colors.bad.toColor()
val InfoBlue: Color get() = ThemeRuntime.tokens.colors.info.toColor()
val ChartBlue: Color get() = chartColor(1)
val ChartTeal: Color get() = chartColor(2)

/** i-th chart series colour (wraps around the Chairman's palette). */
fun chartColor(i: Int): Color {
    val p = ThemeRuntime.tokens.colors.chart
    return p[((i % p.size) + p.size) % p.size].toColor()
}

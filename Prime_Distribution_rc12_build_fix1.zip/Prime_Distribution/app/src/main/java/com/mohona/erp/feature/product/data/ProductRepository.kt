package com.mohona.erp.feature.product.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.math.RoundingMode
import org.json.JSONArray
import org.json.JSONObject

data class ProductRow(val id: String, val sku: String, val nameBn: String, val kind: String, val baseUnit: String, val status: String, val pendingVersion: Int?, val rowVersion: Int)
data class PackSpec(val sachetsPerPoly: Int, val gramsPerSachet: BigDecimal, val polysPerCarton: Int?)
data class ProductQr(val companyCode: String, val sku: String, val variantCode: String?)

/** Product master (S24): catalog, maker-checker versions, variants, POLY specs, prices, media, QR. */
class ProductRepository(private val client: SupabaseClient) {
    suspend fun list(text: String? = null, status: String? = null): ApiResult<List<ProductRow>> =
        when (val r = client.rpcArray("v1_product_list", JSONObject().put("p_text", text ?: JSONObject.NULL).put("p_status", status ?: JSONObject.NULL).put("p_limit", 200))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseList(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_product_list"))
        }
    suspend fun get(id: String): ApiResult<JSONObject> = client.rpcObject("v1_product_get", JSONObject().put("p_product_id", id))
    suspend fun history(id: String): ApiResult<JSONArray> = client.rpcArray("v1_product_history", JSONObject().put("p_product_id", id))
    suspend fun propose(id: String?, sku: String?, nameBn: String, nameEn: String?, kind: String?, categoryId: String?, baseUnit: String?, attributes: JSONObject?,
                        reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_product_propose", JSONObject().put("p_product_id", id ?: JSONObject.NULL).put("p_sku", sku ?: JSONObject.NULL).put("p_name_bn", nameBn)
            .put("p_name_en", nameEn ?: JSONObject.NULL).put("p_kind", kind ?: JSONObject.NULL).put("p_category_id", categoryId ?: JSONObject.NULL)
            .put("p_base_unit", baseUnit ?: JSONObject.NULL).put("p_attributes", attributes ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun decide(id: String, version: Int, approve: Boolean, note: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_product_decide", JSONObject().put("p_product_id", id).put("p_version", version).put("p_decision", if (approve) "approve" else "reject")
            .put("p_note", note), write = true, idempotencyKey = key)
    suspend fun action(id: String, action: String, rowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_product_action", JSONObject().put("p_product_id", id).put("p_action", action).put("p_expected_row_version", rowVersion).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun proposeSpec(id: String, variantId: String?, sachetsPerPoly: Int, gramsPerSachet: BigDecimal, polysPerCarton: Int?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_pack_spec_propose", JSONObject().put("p_product_id", id).put("p_variant_id", variantId ?: JSONObject.NULL).put("p_sachets_per_poly", sachetsPerPoly)
            .put("p_grams_per_sachet", gramsPerSachet).put("p_polys_per_carton", polysPerCarton ?: JSONObject.NULL).put("p_effective_from", JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun decideSpec(specId: String, approve: Boolean, note: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_pack_spec_decide", JSONObject().put("p_spec_id", specId).put("p_decision", if (approve) "approve" else "reject").put("p_note", note),
            write = true, idempotencyKey = key)
    suspend fun priceAt(listId: String, productId: String, variantId: String?, unit: String, dateIso: String? = null): ApiResult<Any> =
        client.rpc("v1_price_at", JSONObject().put("p_price_list_id", listId).put("p_product_id", productId).put("p_variant_id", variantId ?: JSONObject.NULL)
            .put("p_unit", unit).put("p_date", dateIso ?: JSONObject.NULL))
    suspend fun resolveQr(payload: String): ApiResult<JSONObject> = client.rpcObject("v1_product_resolve_qr", JSONObject().put("p_payload", payload))

    companion object {
        fun parseList(a: JSONArray): List<ProductRow>? = try {
            (0 until a.length()).map { a.getJSONObject(it).let { o -> ProductRow(o.getString("id"), o.getString("sku"), o.getString("name_bn"), o.getString("kind"),
                o.getString("base_unit"), o.getString("status"), if (o.isNull("pending_version")) null else o.optInt("pending_version"), o.optInt("row_version")) } }
        } catch (e: Exception) { null }
    }
}

/** Client mirror of inventory.fn_convert (preview only; the server converts for real). pcs is never converted to packs. */
object PackMath {
    private val mass = mapOf("g" to BigDecimal.ONE, "kg" to BigDecimal(1000), "ton" to BigDecimal(1_000_000))
    class Ambiguous(msg: String) : IllegalArgumentException(msg)

    fun convert(qty: BigDecimal, from: String, to: String, spec: PackSpec?): BigDecimal {
        if (from == to) return qty
        if (from in mass && to in mass) return qty.multiply(mass.getValue(from)).divide(mass.getValue(to), 6, RoundingMode.HALF_UP).stripTrailingZeros()
        val packs = setOf("sachet", "poly", "carton")
        if ((from !in packs && from !in mass) || (to !in packs && to !in mass)) throw Ambiguous("$from -> $to")
        val s = spec ?: throw Ambiguous("needs POLY spec")
        val perPoly = BigDecimal(s.sachetsPerPoly); val perCarton = s.polysPerCarton?.let { BigDecimal(it) }
        if ((from == "carton" || to == "carton") && perCarton == null) throw Ambiguous("polys per carton")
        val sachets = when (from) {
            "sachet" -> qty; "poly" -> qty.multiply(perPoly); "carton" -> qty.multiply(perCarton!!).multiply(perPoly)
            else -> qty.multiply(mass.getValue(from)).divide(s.gramsPerSachet, 6, RoundingMode.HALF_UP)
        }
        return when (to) {
            "sachet" -> sachets; "poly" -> sachets.divide(perPoly, 6, RoundingMode.HALF_UP); "carton" -> sachets.divide(perPoly.multiply(perCarton!!), 6, RoundingMode.HALF_UP)
            else -> sachets.multiply(s.gramsPerSachet).divide(mass.getValue(to), 6, RoundingMode.HALF_UP)
        }.stripTrailingZeros()
    }

    /** "MOS1|P|<company>|<SKU>|<variant or ->" */
    fun parseQr(payload: String): ProductQr? {
        val p = payload.split('|')
        if (p.size != 5 || p[1] != "P" || p[3].isBlank()) return null
        return ProductQr(p[2], p[3], p[4].takeIf { it != "-" })
    }
}

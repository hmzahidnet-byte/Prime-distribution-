package com.mohona.erp.feature.finance.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.math.RoundingMode
import org.json.JSONArray
import org.json.JSONObject

/** Finance ledger (S36–S39): CoA, journals, periods, cash/bank, statements, factory P&L, product profitability, GL events. */
class FinanceRepository(private val client: SupabaseClient) {
    suspend fun accounts(): ApiResult<JSONArray> = client.rpcArray("v1_accounts")
    suspend fun trialBalance(asOf: String? = null): ApiResult<JSONObject> = client.rpcObject("v1_trial_balance", JSONObject().put("p_as_of", asOf ?: JSONObject.NULL))
    suspend fun statements(from: String? = null, to: String? = null): ApiResult<JSONObject> =
        client.rpcObject("v1_statements", JSONObject().put("p_from", from ?: JSONObject.NULL).put("p_to", to ?: JSONObject.NULL))
    suspend fun ledger(accountCode: String, from: String?, to: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_ledger", JSONObject().put("p_account_code", accountCode).put("p_from", from ?: JSONObject.NULL).put("p_to", to ?: JSONObject.NULL))
    suspend fun saveJournal(id: String?, dateIso: String, memo: String, lines: JSONArray, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_journal_save", JSONObject().put("p_id", id ?: JSONObject.NULL).put("p_date", dateIso).put("p_memo", memo).put("p_lines", lines),
            write = true, idempotencyKey = key)
    suspend fun submitJournal(id: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_journal_submit", JSONObject().put("p_journal_id", id), write = true, idempotencyKey = key)
    suspend fun reverseJournal(id: String, dateIso: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_journal_reverse", JSONObject().put("p_journal_id", id).put("p_date", dateIso ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun glEvents(status: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_gl_events", JSONObject().put("p_status", status ?: JSONObject.NULL))
    suspend fun retryEvents(key: String): ApiResult<JSONObject> = client.rpcObject("v1_gl_events_retry", JSONObject(), write = true, idempotencyKey = key)
    suspend fun cashVoucher(cashAccountId: String, kind: String, amount: BigDecimal, counterAccount: String, memo: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_cash_voucher", JSONObject().put("p_cash_account_id", cashAccountId).put("p_kind", kind).put("p_amount", amount)
            .put("p_counter_account_code", counterAccount).put("p_memo", memo), write = true, idempotencyKey = key)
    suspend fun cashCount(cashAccountId: String, counted: BigDecimal, note: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_cash_count", JSONObject().put("p_cash_account_id", cashAccountId).put("p_counted", counted).put("p_note", note ?: JSONObject.NULL),
            write = true, idempotencyKey = key)
    suspend fun bankUnreconciled(bankAccountId: String): ApiResult<JSONObject> = client.rpcObject("v1_bank_unreconciled", JSONObject().put("p_bank_account_id", bankAccountId))
    suspend fun factoryPnl(from: String?, to: String?, wingId: String? = null): ApiResult<JSONObject> =
        client.rpcObject("v1_factory_pnl", JSONObject().put("p_from", from ?: JSONObject.NULL).put("p_to", to ?: JSONObject.NULL).put("p_wing_id", wingId ?: JSONObject.NULL))
    suspend fun productProfitability(from: String?, to: String?): ApiResult<JSONArray> =
        client.rpcArray("v1_product_profitability", JSONObject().put("p_from", from ?: JSONObject.NULL).put("p_to", to ?: JSONObject.NULL))
}

/** ADR-09 mirror for previews: BDT at the company scale with the company rounding mode; journals must balance. */
object Money {
    fun round(v: BigDecimal, scale: Int = 2, mode: String = "HALF_UP"): BigDecimal = v.setScale(scale, when (mode) {
        "HALF_EVEN" -> RoundingMode.HALF_EVEN; "UP" -> RoundingMode.UP; "DOWN" -> RoundingMode.DOWN; else -> RoundingMode.HALF_UP })

    data class Line(val account: String, val debit: BigDecimal, val credit: BigDecimal)

    /** Same rule as finance.fn_post_journal: non-zero and debit = credit after rounding; no line with both sides. */
    fun balanced(lines: List<Line>, scale: Int = 2): Boolean {
        if (lines.any { it.debit.signum() < 0 || it.credit.signum() < 0 || (it.debit.signum() > 0 && it.credit.signum() > 0) }) return false
        val dr = lines.fold(BigDecimal.ZERO) { a, l -> a + round(l.debit, scale) }
        val cr = lines.fold(BigDecimal.ZERO) { a, l -> a + round(l.credit, scale) }
        return dr.signum() > 0 && dr.compareTo(cr) == 0
    }
}

package com.mohona.erp.core.shell

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import com.mohona.erp.feature.iam.data.MyPermissions

/**
 * Permission HINTS for the UI (S17): what to show or enable for the current position. They never grant anything —
 * every RPC is re-authorised by the server (iam.fn_require). Preview mode provides null (= show everything as demo).
 */
val LocalPermissions = compositionLocalOf<MyPermissions?> { null }

object PermissionHints {
    fun can(perms: MyPermissions?, code: String): Boolean = perms == null || perms.has(code)
    fun canAll(perms: MyPermissions?, vararg codes: String): Boolean = codes.all { can(perms, it) }
    fun canAny(perms: MyPermissions?, vararg codes: String): Boolean = codes.isEmpty() || codes.any { can(perms, it) }
}

/** Shows [content] only when the current position (probably) holds [code]; otherwise [otherwise]. */
@Composable
fun IfCan(code: String, otherwise: @Composable () -> Unit = {}, content: @Composable () -> Unit) {
    if (PermissionHints.can(LocalPermissions.current, code)) content() else otherwise()
}

/**
 * Effective animation duration in ms for the current company and phone (S19, MOS-F153-008): 0 when the phone's
 * "remove animations" is on or the Chairman chose always_reduce. Components animate with this, never a constant.
 */
val LocalMotionMs = compositionLocalOf { 200 }

package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.AppMode
import com.mohona.erp.data.Bn
import com.mohona.erp.data.ModuleKeys
import com.mohona.erp.data.RoleAccess
import com.mohona.erp.data.Roles
import com.mohona.erp.data.SessionState
import com.mohona.erp.data.UserProfile
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.KeyValueRow
import com.mohona.erp.ui.components.MohonaLogo
import com.mohona.erp.ui.components.PreviewBadge
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.TextMuted

@Composable
fun ProfileScreen(session: SessionState, profile: UserProfile, onDiagnostics: () -> Unit = {}, shell: ProfileShellActions? = null, onLogout: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundGray)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MohonaLogo(size = 34.dp)
            Spacer(Modifier.size(12.dp))
            Text("প্রোফাইল", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(84.dp).clip(CircleShape).background(OrangeSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = OrangeDark, modifier = Modifier.size(46.dp))
                }
                Spacer(Modifier.height(8.dp))
                Text(profile.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(Roles.namesOf(profile.roleCodes), style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                Spacer(Modifier.height(6.dp))
                PreviewBadge(if (session.mode == AppMode.PREVIEW) "প্রিভিউ মোড" else "সংযুক্ত মোড (Staging)")
            }

            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ব্যবহারকারীর তথ্য", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    KeyValueRow("নাম / লগইন", profile.name)
                    KeyValueRow("ভূমিকা", Roles.namesOf(profile.roleCodes))
                    KeyValueRow("ভূমিকার কোড", if (profile.roleCodes.isEmpty()) "—" else profile.roleCodes.joinToString(", "))
                    KeyValueRow("প্রবেশের ধরন", if (profile.isPreview) "প্রিভিউ (নমুনা)" else "সংযুক্ত (Staging)")
                    if (!profile.isPreview) {
                        KeyValueRow("সার্ভার-অনুমতি", Bn.digits(profile.permissions.size.toString()) + "টি")
                        val scopes = profile.permissions.map { it.scope }.distinct().joinToString(", ")
                        KeyValueRow("পরিধি (Scope) কোড", if (scopes.isEmpty()) "—" else scopes)
                    }
                }
            }

            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("কোম্পানির তথ্য", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    KeyValueRow("কোম্পানি", profile.companyName)
                    KeyValueRow("কোড", profile.companyCode)
                    KeyValueRow("লোগো", "প্লেসহোল্ডার (আসল লোগো পরে)")
                    if (profile.isPreview) KeyValueRow("তথ্যের উৎস", "নমুনা")
                }
            }

            AppCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("নিরাপত্তা-নোট", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "• প্রিভিউ ভূমিকা শুধু ডেমো-পর্দা বদলায়; কোনো ব্যাকএন্ড-অধিকার দেয় না।\n" +
                            "• প্রকৃত অনুমতি সার্ভারের RLS/RPC নিয়ন্ত্রণ করে; অ্যাপ শুধু দেখানোর ইঙ্গিত দেয়।\n" +
                            "• এক মানুষ = এক লগইন; একাধিক কোম্পানিতে সদস্যপদ থাকলেও একবারে একটি সক্রিয় পদ।\n" +
                            "• কোম্পানির মধ্যে লেনদেন বন্ধ। কোম্পানি-চেয়ারম্যান সর্বোচ্চ; ফ্যাক্টরি লাভ-ক্ষতি ডিফল্টে চেয়ারম্যান ও এমডি।\n" +
                            "• VAT/Tax ও CCTV এই অ্যাপে নেই।",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            }

            if (shell != null && !profile.isPreview) {
                ProfileShellButtons(shell)
            }
            OutlinedButton(onClick = onDiagnostics, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Text("বিল্ড ও ডায়াগনস্টিক")
            }
            OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth().height(50.dp)) {
                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("লগআউট")
            }
            Text(
                "সংস্করণ " + Bn.digits(com.mohona.erp.BuildConfig.VERSION_NAME) + " • " + com.mohona.erp.BuildConfig.GIT_SHA.take(7),
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}


/** Connected-mode shell links (S17). Each is shown only with its permission hint; the server still decides. */
class ProfileShellActions(
    val onSettings: () -> Unit,
    val onOrg: () -> Unit,
    val onForms: () -> Unit,
    val onSyncDrafts: () -> Unit,
    val onLogoutEverywhere: () -> Unit,
    val draftInfo: String? = null,
    val onDesign: () -> Unit = {},
    val onLayout: () -> Unit = {},
    val onRecycle: () -> Unit = {},
    val onInbox: () -> Unit = {},
    val onStructure: () -> Unit = {},
    val onProducts: () -> Unit = {},
    val onStock: () -> Unit = {},
    val onProcurement: () -> Unit = {},
    val onWarehouse: () -> Unit = {},
    val onMfg: () -> Unit = {},
    val onFinance: () -> Unit = {},
    val onDealers: () -> Unit = {},
    val onSales: () -> Unit = {},
    val onMyDay: () -> Unit = {},
    val onScan: () -> Unit = {},
    val onPrint: () -> Unit = {},
    val onReports: () -> Unit = {},
    val onMap: () -> Unit = {},
    val onOps: () -> Unit = {},
    val onCourier: () -> Unit = {},
    val onChairmanPanel: () -> Unit = {}
)

/**
 * Prime Distribution Architect 1: seven main icons only — MFS, Warehouse, DMS, CRM, Office/HR, Courier, Chairman.
 * An icon the position has no right for is not shown; the Chairman icon is shown only to the Chairman. Each icon opens
 * its department's actions. Navigation only: every screen and server rule behind it is unchanged.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun ProfileShellButtons(a: ProfileShellActions) {
    val perms = com.mohona.erp.core.shell.LocalPermissions.current
    val can = { code: String -> com.mohona.erp.core.shell.PermissionHints.can(perms, code) }
    val entries: List<Triple<String, String, List<Pair<String, () -> Unit>>>> = listOf(
        Triple("mfs", "🏭 ম্যানুফ্যাকচারিং", listOfNotNull(
            if (can("mfg.bom.read")) "উৎপাদন ও ব্যাচ" to a.onMfg else null,
            if (can("procurement.read")) "ক্রয় ও সরবরাহকারী-দেনা" to a.onProcurement else null,
            if (can("inventory.stock.read")) "কাঁচামাল-মজুদ" to a.onStock else null,
            if (can("master.sku.read")) "পণ্য ও প্যাকিং" to a.onProducts else null)),
        Triple("wh", "📦 ওয়্যারহাউস", listOfNotNull(
            if (can("inventory.stock.read")) "গুদাম (রিপোর্ট, QR, গণনা)" to a.onWarehouse else null,
            if (can("inventory.stock.read")) "মজুদ ও লট" to a.onStock else null,
            "QR স্ক্যান (পণ্য / কার্টন / বিন)" to a.onScan)),
        Triple("dms", "🤝 ডিলার (DMS)", listOfNotNull(
            if (can("crm.dealer.read")) "ডিলার, বকেয়া ও স্টেটমেন্ট" to a.onDealers else null,
            if (can("sales.collection.record") || can("sales.weekly_summary.read")) "বিক্রয় ও কালেকশন" to a.onSales else null,
            "ইনভয়েস / রসিদ প্রিন্ট ও শেয়ার" to a.onPrint)),
        Triple("crm", "👥 গ্রাহক (CRM)", listOfNotNull(
            if (can("crm.dealer.read")) "পার্টি ও ডিলার" to a.onDealers else null,
            if (can("location.live.share") || can("location.live.read") || can("location.dealer_map.read")) "ম্যাপ ও অবস্থান" to a.onMap else null,
            if (can("hr.attendance.scan")) "আজকের ভিজিট" to a.onMyDay else null)),
        Triple("hr", "🏢 অফিস ও HR", listOfNotNull(
            if (can("hr.attendance.scan")) "আমার দিন (হাজিরা-QR)" to a.onMyDay else null,
            "পে-স্লিপ" to a.onOps,
            if (can("iam.hierarchy.read")) "সংগঠন-কাঠামো" to a.onOrg else null,
            if (can("forms.form.read")) "ফর্ম" to a.onForms else null,
            if (can("report.run")) "রিপোর্ট" to a.onReports else null,
            "নোটিফিকেশন" to a.onInbox)),
        Triple("courier", "🚚 কুরিয়ার", listOfNotNull(
            if (can("courier.read")) "চালান, কন্ডিশন ও আদায়" to a.onCourier else null)),
        Triple("chairman", "👑 চেয়ারম্যান", if (!can("iam.permission.manage")) emptyList() else listOfNotNull(
            "অর্থ-অনুমোদন ও কোম্পানির হিসাব-শৃঙ্খল" to a.onChairmanPanel,
            if (can("finance.ledger.read")) "হিসাব" to a.onFinance else null,
            if (can("config.settings.read")) "সেটিং" to a.onSettings else null,
            if (can("design.studio.edit")) "ডিজাইন-স্টুডিও" to a.onDesign else null,
            if (can("design.studio.edit")) "লেআউট-স্টুডিও" to a.onLayout else null,
            if (can("core.structure.read")) "কোম্পানি-কাঠামো" to a.onStructure else null,
            "শাসন, ব্যাকআপ ও রিলিজ-প্রমাণ" to a.onOps,
            "রিসাইকেল-বিন" to a.onRecycle))
    ).filter { it.third.isNotEmpty() }
    val open = androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<String?>(null) }
    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
        androidx.compose.foundation.layout.FlowRow(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
            entries.forEach { e ->
                androidx.compose.material3.FilterChip(selected = open.value == e.first, onClick = { open.value = if (open.value == e.first) null else e.first },
                    label = { Text(e.second, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(vertical = 10.dp)) })
            }
        }
        entries.firstOrNull { it.first == open.value }?.third?.forEach { (label, action) ->
            OutlinedButton(onClick = action, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(label) }
        }
        OutlinedButton(onClick = a.onSyncDrafts, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("অফলাইন খসড়া সিঙ্ক") }
        a.draftInfo?.let { Text(it, style = MaterialTheme.typography.labelSmall) }
        OutlinedButton(onClick = a.onLogoutEverywhere, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("সব ডিভাইস থেকে বের হন") }
    }
}

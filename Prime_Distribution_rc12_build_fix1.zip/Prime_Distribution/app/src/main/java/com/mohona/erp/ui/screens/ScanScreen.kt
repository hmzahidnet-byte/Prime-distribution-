package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.qr.data.MohonaQr
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Universal QR (S49): scan with the phone's code scanner (one still frame is read; nothing is recorded or stored — F242)
 * or paste the label text; the server resolves it inside the user's own company and rights.
 */
@Composable
fun ScanScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<JSONObject?>(null) }
    var message by remember { mutableStateOf<String?>(null) }

    fun resolve(raw: String) {
        val label = MohonaQr.parse(raw)
        if (label == null) { message = "এটি Prime Distribution-এর বৈধ QR নয়।"; result = null; return }
        scope.launch {
            when (val r = AppContainer.qr?.resolve(raw.trim())) {
                is ApiResult.Ok -> { result = r.value; message = label.typeNameBn + "-QR" }
                is ApiResult.Err -> { result = null; message = r.error.messageBn }
                null -> message = "সংযুক্ত মোড নয়।"
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("QR স্ক্যান", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                runCatching {
                    GmsBarcodeScanning.getClient(context).startScan()
                        .addOnSuccessListener { code -> val v = code.rawValue.orEmpty(); text = v; resolve(v) }
                        .addOnFailureListener { message = "স্ক্যান করা যায়নি — নিচে লেখাটি পেস্ট করুন।" }
                }.onFailure { message = "এই ফোনে স্ক্যানার চালু হয়নি — নিচে লেখাটি পেস্ট করুন।" }
            }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("ক্যামেরায় স্ক্যান করুন") }
            OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("অথবা QR-এর লেখা") }, modifier = Modifier.fillMaxWidth())
            OutlinedButton(enabled = text.isNotBlank(), onClick = { resolve(text) }, modifier = Modifier.fillMaxWidth().height(48.dp)) { Text("দেখুন") }
            message?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = if (result == null) BadRed else TextMuted) }
            result?.let { r ->
                val body = r.optJSONObject("result") ?: r
                body.keys().forEach { k ->
                    if (!body.isNull(k) && k != "type") Text("$k: ${body.opt(k)}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

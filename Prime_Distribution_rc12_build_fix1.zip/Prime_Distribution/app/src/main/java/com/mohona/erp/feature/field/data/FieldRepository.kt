package com.mohona.erp.feature.field.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

/** Field routes + attendance for the signed-in person (S44–S46). */
class FieldRepository(private val client: SupabaseClient) {
    suspend fun myVisits(dateIso: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_my_visits", JSONObject().put("p_date", dateIso ?: JSONObject.NULL))
    suspend fun checkIn(visitId: String, lat: Double?, lon: Double?): ApiResult<JSONObject> =
        client.rpcObject("v1_visit_check_in", JSONObject().put("p_visit_id", visitId).put("p_latitude", lat ?: JSONObject.NULL).put("p_longitude", lon ?: JSONObject.NULL), write = true)
    suspend fun outcome(visitId: String, outcome: String, noSaleReason: String?, notes: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_visit_outcome", JSONObject().put("p_visit_id", visitId).put("p_outcome", outcome).put("p_no_sale_reason", noSaleReason ?: JSONObject.NULL)
            .put("p_notes", notes ?: JSONObject.NULL), write = true)
    suspend fun missed(visitId: String, reason: String, note: String): ApiResult<JSONObject> =
        client.rpcObject("v1_visit_missed", JSONObject().put("p_visit_id", visitId).put("p_reason_code", reason).put("p_note", note).put("p_evidence_path", JSONObject.NULL), write = true)
    suspend fun attendanceQr(): ApiResult<JSONObject> = client.rpcObject("v1_attendance_qr")
    suspend fun leave(code: String, fromIso: String, toIso: String, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_leave_request", JSONObject().put("p_code", code).put("p_from", fromIso).put("p_to", toIso).put("p_reason", reason), write = true)
    suspend fun correction(atIso: String, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_attendance_correction", JSONObject().put("p_event_at", atIso).put("p_reason", reason), write = true)
    suspend fun myReport(fromIso: String, toIso: String): ApiResult<JSONObject> =
        client.rpcObject("v1_attendance_report", JSONObject().put("p_from", fromIso).put("p_to", toIso).put("p_employee_id", JSONObject.NULL))
    suspend fun gateSync(deviceCode: String, deviceKey: String, scans: JSONArray): ApiResult<JSONObject> =
        client.rpcObject("v1_gate_sync", JSONObject().put("p_device_code", deviceCode).put("p_device_key", deviceKey).put("p_scans", scans), write = true)
}

/** Gate device offline queue (F170): keeps scans with their time until sync; the server deduplicates by token hash. */
class GateQueue(private val maxItems: Int = 5000) {
    private val items = LinkedHashMap<String, Long>()          // payload -> scanned at (epoch ms); same token kept once
    @Synchronized fun add(payload: String, atMillis: Long): Boolean {
        if (items.containsKey(payload) || items.size >= maxItems) return false
        items[payload] = atMillis; return true
    }
    @Synchronized fun batch(): JSONArray = JSONArray(items.map { (p, t) -> JSONObject().put("payload", p).put("scanned_at", java.time.Instant.ofEpochMilli(t).toString()) })
    @Synchronized fun clear() = items.clear()
    val size: Int @Synchronized get() = items.size
}

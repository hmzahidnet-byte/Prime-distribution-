package com.mohona.erp.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.mohona.erp.ui.theme.tokens.MohonaTokens

/**
 * The single active token set (one company / one session at a time). Backed by Compose snapshot state, so every
 * composable AND every Canvas draw that reads a colour updates when the Chairman publishes a new theme.
 */
object ThemeRuntime {
    var tokens: MohonaTokens by mutableStateOf(MohonaTokens.DEFAULT)
        private set

    fun apply(newTokens: MohonaTokens) { tokens = newTokens }
    fun reset() { tokens = MohonaTokens.DEFAULT }
}

fun Long.toColor(): Color = Color(this.toInt())

package com.mohona.erp.feature.config.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

/**
 * Rule Studio client (S13). [RuleCondition] mirrors the server's safe JSON condition language so the Chairman's editor can
 * preview instantly; the server (config.fn_rule_validate / fn_rule_eval) remains the authority.
 */
object RuleCondition {
    private val FIELD = Regex("^[a-z][a-z0-9_]{0,40}$")
    private val OPS = setOf("and", "or", "not", "always", "=", "!=", ">", ">=", "<", "<=", "in", "contains", "is_null")

    fun validate(node: JSONObject, depth: Int = 0): String? {
        if (depth > 10) return "শর্ত ১০ স্তরের বেশি গভীর"
        val op = node.optString("op", "")
        if (op !in OPS) return "অজানা শর্ত: $op"
        return when (op) {
            "and", "or" -> {
                val a = node.optJSONArray("args") ?: return "$op-এর অংশ লাগবে"
                if (a.length() == 0) return "$op-এর অংশ লাগবে"
                (0 until a.length()).asSequence().mapNotNull { validate(a.getJSONObject(it), depth + 1) }.firstOrNull()
            }
            "not" -> node.optJSONObject("arg")?.let { validate(it, depth + 1) } ?: "not-এর অংশ লাগবে"
            "always" -> null
            else -> when {
                !FIELD.matches(node.optString("field", "")) -> "ঘরের নাম সঠিক নয়"
                op in setOf(">", ">=", "<", "<=") && node.opt("value") !is Number -> "সংখ্যা দিন"
                op == "in" && node.opt("value") !is JSONArray -> "তালিকা দিন"
                else -> null
            }
        }
    }

    fun eval(node: JSONObject, facts: JSONObject): Boolean {
        val op = node.optString("op")
        val v = if (node.has("field") && facts.has(node.getString("field"))) facts.get(node.getString("field")) else null
        val target = node.opt("value")
        return when (op) {
            "always" -> true
            "and" -> node.getJSONArray("args").let { a -> (0 until a.length()).all { eval(a.getJSONObject(it), facts) } }
            "or" -> node.getJSONArray("args").let { a -> (0 until a.length()).any { eval(a.getJSONObject(it), facts) } }
            "not" -> !eval(node.getJSONObject("arg"), facts)
            "is_null" -> v == null || v == JSONObject.NULL
            "=" -> v != null && same(v, target)
            "!=" -> v == null || !same(v, target)
            "in" -> v != null && (target as JSONArray).let { a -> (0 until a.length()).any { same(v, a.get(it)) } }
            "contains" -> v is JSONArray && (0 until v.length()).any { same(v.get(it), target) }
            else -> {
                val x = (v as? Number)?.toDouble() ?: return false
                val y = (target as Number).toDouble()
                when (op) { ">" -> x > y; ">=" -> x >= y; "<" -> x < y; "<=" -> x <= y; else -> false }
            }
        }
    }

    private fun same(a: Any?, b: Any?): Boolean =
        if (a is Number && b is Number) a.toDouble() == b.toDouble() else a == b
}

class RulesRepository(private val client: SupabaseClient) {
    suspend fun list(event: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_rules_list", JSONObject().put("p_event", event ?: JSONObject.NULL))

    suspend fun saveDraft(code: String, nameBn: String, event: String, wingId: String?, priority: Int, condition: JSONObject, actions: JSONObject,
                          reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_rules_save_draft", JSONObject().put("p_code", code).put("p_name_bn", nameBn).put("p_event", event)
            .put("p_wing_id", wingId ?: JSONObject.NULL).put("p_priority", priority).put("p_condition", condition).put("p_actions", actions)
            .put("p_reason", reason), write = true, idempotencyKey = key)

    suspend fun simulate(event: String, wingId: String?, facts: JSONObject, ruleId: String? = null, version: Int? = null): ApiResult<JSONObject> =
        client.rpcObject("v1_rules_simulate", JSONObject().put("p_event", event).put("p_wing_id", wingId ?: JSONObject.NULL).put("p_facts", facts)
            .put("p_rule_id", ruleId ?: JSONObject.NULL).put("p_version", version ?: JSONObject.NULL))

    suspend fun action(ruleId: String, action: String, version: Int?, expectedRowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_rules_action", JSONObject().put("p_rule_id", ruleId).put("p_action", action).put("p_version", version ?: JSONObject.NULL)
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)

    suspend fun conflicts(event: String, samples: JSONArray): ApiResult<JSONArray> =
        client.rpcArray("v1_rules_conflicts", JSONObject().put("p_event", event).put("p_samples", samples))

    suspend fun impact(ruleId: String, version: Int): ApiResult<JSONObject> =
        client.rpcObject("v1_rules_impact", JSONObject().put("p_rule_id", ruleId).put("p_version", version).put("p_limit", 500))
}

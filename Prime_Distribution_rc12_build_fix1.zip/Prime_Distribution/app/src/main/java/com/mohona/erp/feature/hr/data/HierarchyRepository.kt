package com.mohona.erp.feature.hr.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class PreviewPermission(val code: String, val module: String, val nameBn: String, val sensitive: Boolean, val via: String)
data class DependencyGap(val permission: String, val requires: String)
data class SodConflict(val a: String, val b: String, val mode: String)
data class AccessPreview(val assignmentId: String, val positionCode: String, val supreme: Boolean, val permissions: List<PreviewPermission>,
                         val gaps: List<DependencyGap>, val conflicts: List<SodConflict>) {
    val byModule: Map<String, List<PreviewPermission>> get() = permissions.groupBy { it.module }
    val hasBlockingConflict: Boolean get() = conflicts.any { it.mode == "block" }
}
data class Holder(val assignmentId: String, val nameBn: String, val employeeId: String?, val managerEmployeeId: String?,
                  val employmentStatus: String?, val grade: String?, val salaryText: String?, val onboardingOpen: Boolean)
data class OrgPosition(val code: String, val nameBn: String, val rank: Int, val reportsTo: String?, val supreme: Boolean, val holders: List<Holder>)
data class ChangeResult(val changeId: String, val status: String, val newAssignmentId: String?, val requestId: String?)

/** S15: access preview, SoD, dependencies, permission audit, org tree, employment changes, onboarding, substitution. */
class HierarchyRepository(private val client: SupabaseClient) {
    suspend fun accessPreview(assignmentId: String, wingId: String? = null): ApiResult<AccessPreview> =
        when (val r = client.rpcObject("v1_iam_access_preview", JSONObject().put("p_assignment_id", assignmentId).put("p_wing_id", wingId ?: JSONObject.NULL))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parsePreview(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_access_preview"))
        }

    suspend fun sodRules(): ApiResult<JSONArray> = client.rpcArray("v1_iam_sod_rules")
    suspend fun sodReport(): ApiResult<JSONArray> = client.rpcArray("v1_iam_sod_report")
    suspend fun setSod(a: String, b: String, mode: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_iam_sod_set", JSONObject().put("p_permission_a", a).put("p_permission_b", b).put("p_mode", mode).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun dependencies(): ApiResult<JSONArray> = client.rpcArray("v1_iam_permission_dependencies")
    suspend fun permissionAudit(sinceIso: String? = null, limit: Int = 200): ApiResult<JSONArray> =
        client.rpcArray("v1_iam_permission_audit", JSONObject().put("p_since", sinceIso ?: JSONObject.NULL).put("p_limit", limit))

    suspend fun orgTree(): ApiResult<List<OrgPosition>> = when (val r = client.rpcArray("v1_hr_org_tree")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseTree(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_hr_org_tree"))
    }
    suspend fun history(membershipId: String): ApiResult<JSONObject> = client.rpcObject("v1_hr_employment_history", JSONObject().put("p_membership_id", membershipId))
    suspend fun setManager(employeeId: String, managerEmployeeId: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_hr_set_manager", JSONObject().put("p_employee_id", employeeId).put("p_manager_employee_id", managerEmployeeId ?: JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = key)

    /** kind: promotion | transfer | suspension | reinstatement | termination. effectiveOn = ISO date or null (today). */
    suspend fun change(kind: String, assignmentId: String, toPosition: String?, toWing: String?, toDepartment: String?, toLocation: String?,
                       grade: String?, salary: String?, effectiveOn: String?, reason: String, key: String): ApiResult<ChangeResult> =
        when (val r = client.rpcObject("v1_hr_employment_change", JSONObject().put("p_kind", kind).put("p_assignment_id", assignmentId)
            .put("p_to_position_code", toPosition ?: JSONObject.NULL).put("p_to_wing_id", toWing ?: JSONObject.NULL)
            .put("p_to_department_id", toDepartment ?: JSONObject.NULL).put("p_to_location_id", toLocation ?: JSONObject.NULL)
            .put("p_grade", grade ?: JSONObject.NULL).put("p_salary", salary?.let { java.math.BigDecimal(it) } ?: JSONObject.NULL)
            .put("p_effective_on", effectiveOn ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(parseChange(r.value))
        }
    suspend fun cancelChange(changeId: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_hr_change_cancel", JSONObject().put("p_change_id", changeId).put("p_reason", reason), write = true, idempotencyKey = key)

    suspend fun hire(nameBn: String, phone: String?, email: String?, employeeNo: String?, position: String, wing: String?, department: String?,
                     location: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_hr_hire", JSONObject().put("p_full_name_bn", nameBn).put("p_phone", phone ?: JSONObject.NULL).put("p_email", email ?: JSONObject.NULL)
            .put("p_employee_no", employeeNo ?: JSONObject.NULL).put("p_position_code", position).put("p_home_wing", wing ?: JSONObject.NULL)
            .put("p_home_department", department ?: JSONObject.NULL).put("p_home_location", location ?: JSONObject.NULL).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun onboardings(status: String? = "open"): ApiResult<JSONArray> = client.rpcArray("v1_hr_onboardings", JSONObject().put("p_status", status ?: JSONObject.NULL))
    suspend fun onboardingTask(id: String, taskKey: String, done: Boolean, expectedRowVersion: Int, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_hr_onboarding_task", JSONObject().put("p_onboarding_id", id).put("p_task_key", taskKey).put("p_done", done)
            .put("p_expected_row_version", expectedRowVersion), write = true, idempotencyKey = key)
    suspend fun onboardingDecide(id: String, approve: Boolean, expectedRowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_hr_onboarding_decide", JSONObject().put("p_onboarding_id", id).put("p_action", if (approve) "approve" else "cancel")
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun setOnboardingTemplate(position: String?, tasks: JSONArray, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_hr_onboarding_template_set", JSONObject().put("p_position_code", position ?: JSONObject.NULL).put("p_tasks", tasks).put("p_reason", reason),
            write = true, idempotencyKey = key)

    suspend fun substitute(absent: String, substitute: String, permissions: List<String>, scopeKind: String, scopeId: String?, fromIso: String?,
                           untilIso: String, dutyBn: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_hr_substitute", JSONObject().put("p_absent_assignment", absent).put("p_substitute_assignment", substitute)
            .put("p_permissions", JSONArray(permissions)).put("p_scope_kind", scopeKind).put("p_scope_id", scopeId ?: JSONObject.NULL)
            .put("p_valid_from", fromIso ?: JSONObject.NULL).put("p_valid_until", untilIso).put("p_duty_bn", dutyBn).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun substitutions(): ApiResult<JSONArray> = client.rpcArray("v1_hr_substitutions")
    suspend fun endSubstitution(id: String, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_hr_end_substitution", JSONObject().put("p_substitution_id", id).put("p_reason", reason), write = true, idempotencyKey = key)

    companion object {
        fun parsePreview(o: JSONObject): AccessPreview? = try {
            val p = o.getJSONArray("permissions"); val g = o.getJSONArray("dependency_gaps"); val c = o.getJSONArray("sod_conflicts")
            AccessPreview(o.getString("assignment_id"), o.getString("position_code"), o.optBoolean("is_supreme"),
                (0 until p.length()).map { p.getJSONObject(it).let { x -> PreviewPermission(x.getString("code"), x.getString("module"), x.getString("name_bn"),
                    x.optBoolean("is_sensitive"), x.optString("via")) } },
                (0 until g.length()).map { g.getJSONObject(it).let { x -> DependencyGap(x.getString("permission"), x.getString("requires")) } },
                (0 until c.length()).map { c.getJSONObject(it).let { x -> SodConflict(x.getString("permission_a"), x.getString("permission_b"), x.getString("mode")) } })
        } catch (e: Exception) { null }

        fun parseTree(a: JSONArray): List<OrgPosition>? = try {
            (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                val h = o.optJSONArray("holders") ?: JSONArray()
                OrgPosition(o.getString("code"), o.getString("name_bn"), o.getInt("rank"), o.optStringOrNull("reports_to_code"), o.optBoolean("is_supreme"),
                    (0 until h.length()).map { k -> h.getJSONObject(k).let { x ->
                        Holder(x.getString("assignment_id"), x.optString("name_bn"), x.optStringOrNull("employee_id"), x.optStringOrNull("manager_employee_id"),
                            x.optStringOrNull("employment_status"), x.optStringOrNull("grade"), x.optStringOrNull("salary"), x.optBoolean("onboarding_open")) } })
            } }
        } catch (e: Exception) { null }

        fun parseChange(o: JSONObject) = ChangeResult(o.optString("change_id"), o.optString("status"), o.optStringOrNull("new_assignment_id"), o.optStringOrNull("request_id"))

        /** Children of a tree (positions whose reports_to_code = code); roots have no reporting code. */
        fun children(tree: List<OrgPosition>, code: String?): List<OrgPosition> = tree.filter { it.reportsTo == code }.sortedByDescending { it.rank }

        /** Depth-first tree as (position, depth) rows; positions whose reporting code is unknown are shown at the root. */
        fun flatten(tree: List<OrgPosition>): List<Pair<OrgPosition, Int>> {
            val known = tree.map { it.code }.toSet()
            val out = ArrayList<Pair<OrgPosition, Int>>(); val seen = HashSet<String>()
            fun walk(p: OrgPosition, depth: Int) {
                if (!seen.add(p.code)) return
                out += p to depth
                if (depth < 32) children(tree, p.code).forEach { walk(it, depth + 1) }
            }
            tree.filter { it.reportsTo == null || it.reportsTo !in known }.sortedByDescending { it.rank }.forEach { walk(it, 0) }
            tree.filter { it.code !in seen }.forEach { walk(it, 0) }          // cycles never hide a position
            return out
        }

        private fun JSONObject.optStringOrNull(k: String): String? = if (!has(k) || isNull(k)) null else get(k).toString()
    }
}

package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.feature.product.data.ProductRow
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Product catalog (S24): search, details (variants, POLY specs, pending change with diff), approve / reject for approvers. */
@Composable
fun ProductsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    var query by remember { mutableStateOf("") }
    var rows by remember { mutableStateOf<List<ProductRow>>(emptyList()) }
    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var note by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(query, reload) {
        when (val r = AppContainer.products?.list(query.ifBlank { null })) { is ApiResult.Ok -> rows = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("পণ্য", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("SKU বা নাম") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            rows.forEach { p ->
                AppCard(onClick = { scope.launch { (AppContainer.products?.get(p.id) as? ApiResult.Ok)?.let { detail = it.value } } }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(p.nameBn + " · " + p.sku, style = MaterialTheme.typography.bodyMedium)
                        Text(p.kind + " · " + p.baseUnit + " · " + p.status + (p.pendingVersion?.let { " · অনুমোদনের অপেক্ষায় v$it" } ?: ""),
                            style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
            detail?.let { d ->
                SectionTitle(d.optString("name_bn") + " (" + d.optString("sku") + ")")
                Text("QR: " + d.optString("qr"), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                val specs = d.optJSONArray("pack_specs")
                if (specs != null) for (i in 0 until specs.length()) specs.getJSONObject(i).let { s ->
                    Text("POLY v${s.optInt("version")}: ${s.optInt("sachets_per_poly")} স্যাশে/পলি · ${s.optString("grams_per_sachet")} গ্রাম/স্যাশে · ${s.optString("status")}",
                        style = MaterialTheme.typography.labelSmall)
                }
                d.optJSONObject("pending")?.let { pend ->
                    Text("অপেক্ষমাণ পরিবর্তন: " + pend.optJSONObject("diff")?.keys()?.asSequence()?.joinToString(), style = MaterialTheme.typography.bodySmall)
                    if (PermissionHints.can(perms, "master.sku.approve")) {
                        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("মন্তব্য") }, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(true to "অনুমোদন", false to "প্রত্যাখ্যান").forEach { (ok, label) ->
                                OutlinedButton(enabled = note.isNotBlank(), onClick = {
                                    scope.launch {
                                        when (val r = AppContainer.products?.decide(d.optString("id"), pend.optInt("version"), ok, note, UUID.randomUUID().toString())) {
                                            is ApiResult.Ok -> { message = "সিদ্ধান্ত হয়েছে।"; detail = null; reload++ }
                                            is ApiResult.Err -> message = r.error.messageBn
                                            null -> Unit
                                        }
                                    }
                                }) { Text(label) }
                            }
                        }
                    }
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

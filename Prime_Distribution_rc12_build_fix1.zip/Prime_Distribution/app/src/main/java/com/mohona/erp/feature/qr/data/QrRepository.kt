package com.mohona.erp.feature.qr.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONObject

/** Universal QR (S49): one resolver on the server; the app only recognises the label shape before asking. */
class QrRepository(private val client: SupabaseClient) {
    suspend fun resolve(payload: String): ApiResult<JSONObject> = client.rpcObject("v1_qr_resolve", JSONObject().put("p_payload", payload))
    suspend fun label(kind: String, id: String): ApiResult<JSONObject> = client.rpcObject("v1_qr_label", JSONObject().put("p_kind", kind).put("p_id", id))
}

object MohonaQr {
    data class Label(val type: String, val companyCode: String, val typeNameBn: String)

    private val names = mapOf("P" to "পণ্য", "B" to "বিন", "D" to "ডিলার", "T" to "রিটেইলার", "E" to "কর্মী", "L" to "লট", "I" to "ইনভয়েস", "R" to "রসিদ",
        "X" to "নথি", "A" to "হাজিরা")

    /** Shape check only (the signature is verified on the server). Malformed or foreign codes are rejected here (F246). */
    fun parse(raw: String): Label? {
        val t = raw.trim()
        if (t.length !in 10..300 || t.any { it.isISOControl() }) return null
        val p = t.split('|')
        if (p.size < 4 || p[0] != "MOS1" || p[1] !in names.keys || !Regex("^[A-Z0-9]{2,10}$").matches(p[2])) return null
        return Label(p[1], p[2], names.getValue(p[1]))
    }
}

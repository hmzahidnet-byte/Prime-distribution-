package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.feature.recycle.data.BinItem
import com.mohona.erp.feature.recycle.data.RecycleRepository
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch

/** Recycle bin (S21): restore one or many (all-or-nothing), see why something cannot return, request a purge. */
@Composable
fun RecycleBinScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    var items by remember { mutableStateOf<List<BinItem>>(emptyList()) }
    var picked by remember { mutableStateOf(setOf<String>()) }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        when (val r = AppContainer.recycle?.list()) { is ApiResult.Ok -> items = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("রিসাইকেল-বিন", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ (বাধ্যতামূলক)") }, modifier = Modifier.fillMaxWidth())
            if (items.isEmpty()) EmptyState("বিন খালি।")
            items.forEach { it ->
                AppCard {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = it.id in picked, enabled = !it.masked, onCheckedChange = { c -> picked = if (c) picked + it.id else picked - it.id })
                        Column(Modifier.weight(1f)) {
                            Text(it.labelBn, style = MaterialTheme.typography.bodyMedium)
                            Text("মুছেছেন ${it.deletedAt.take(10)} · স্থায়ীভাবে মুছবে ${it.purgeAfter.take(10)}" + if (it.onHold) " · আইনি স্থগিতাদেশ" else "",
                                style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            it.conflict?.let { c -> Text(RecycleRepository.reasonBn(c), style = MaterialTheme.typography.labelSmall, color = BadRed) }
                        }
                        if (!it.masked) OutlinedButton(enabled = reason.isNotBlank(), onClick = {
                            scope.launch {
                                when (val r = AppContainer.recycle?.restore(it.id, reason, UUID.randomUUID().toString())) {
                                    is ApiResult.Ok -> { message = if (r.value.status == "restored") "ফেরত আনা হয়েছে।" else RecycleRepository.reasonBn(r.value.reason); reload++ }
                                    is ApiResult.Err -> message = r.error.messageBn
                                    null -> Unit
                                }
                            }
                        }) { Text("ফেরত") }
                    }
                }
            }
            if (picked.size > 1) OutlinedButton(enabled = reason.isNotBlank(), onClick = {
                scope.launch {
                    when (val r = AppContainer.recycle?.restoreBulk(picked.toList(), reason, UUID.randomUUID().toString())) {
                        is ApiResult.Ok -> { message = if (r.value.allRestored) "সব ফেরত আনা হয়েছে।"
                            else "কিছুই ফেরত আনা হয়নি — " + r.value.denied.joinToString("; ") { (id, why) -> (items.firstOrNull { x -> x.id == id }?.labelBn ?: id) + ": " + RecycleRepository.reasonBn(why) }
                            picked = emptySet(); reload++ }
                        is ApiResult.Err -> message = r.error.messageBn
                        null -> Unit
                    }
                }
            }) { Text("নির্বাচিত ${picked.size}টি একসাথে ফেরত") }
            if (PermissionHints.can(perms, "recycle.purge.request") && picked.size == 1) OutlinedButton(enabled = reason.isNotBlank(), onClick = {
                scope.launch {
                    when (val r = AppContainer.recycle?.requestPurge(picked.first(), reason, UUID.randomUUID().toString())) {
                        is ApiResult.Ok -> message = "স্থায়ী মুছে ফেলার অনুরোধ হয়েছে — দুইজন অনুমোদনের পর ও অপেক্ষার শেষে কার্যকর।"
                        is ApiResult.Err -> message = r.error.messageBn
                        null -> Unit
                    }
                }
            }) { Text("স্থায়ীভাবে মুছে ফেলার অনুরোধ") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

package com.mohona.erp.feature.sales.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

/** Sales + collections (S41–S43). Credit, stock and verification are decided on the server. */
class SalesRepository(private val client: SupabaseClient) {
    suspend fun quotation(dealerId: String, lines: JSONArray): ApiResult<JSONObject> =
        client.rpcObject("v1_quotation_create", JSONObject().put("p_dealer_id", dealerId).put("p_lines", lines), write = true)
    suspend fun order(dealerId: String, warehouseId: String, priceListId: String, lines: JSONArray, quotationId: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_order_create", JSONObject().put("p_dealer_id", dealerId).put("p_warehouse_id", warehouseId).put("p_price_list_id", priceListId)
            .put("p_lines", lines).put("p_quotation_id", quotationId ?: JSONObject.NULL), write = true, idempotencyKey = key)
    suspend fun dispatch(orderId: String, vehicle: String?, driver: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_dispatch_post", JSONObject().put("p_order_id", orderId).put("p_vehicle", vehicle ?: JSONObject.NULL).put("p_driver", driver ?: JSONObject.NULL),
            write = true, idempotencyKey = key)
    suspend fun deliver(dispatchId: String, recipient: String, signatureSha256: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_delivery_confirm", JSONObject().put("p_dispatch_id", dispatchId).put("p_recipient_name", recipient).put("p_signature_sha256", signatureSha256 ?: JSONObject.NULL),
            write = true, idempotencyKey = key)
    suspend fun invoice(orderId: String, key: String): ApiResult<JSONObject> = client.rpcObject("v1_invoice_post", JSONObject().put("p_order_id", orderId), write = true, idempotencyKey = key)
    suspend fun recordCollection(dealerId: String, method: String, amount: BigDecimal, reference: String?, allocations: JSONArray, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_collection_record", JSONObject().put("p_dealer_id", dealerId).put("p_method", method).put("p_amount", amount).put("p_reference", reference ?: JSONObject.NULL)
            .put("p_evidence_path", JSONObject.NULL).put("p_allocations", allocations), write = true, idempotencyKey = key)
    suspend fun verifyCollection(id: String, cashAccountId: String?, bankLineId: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_collection_verify", JSONObject().put("p_collection_id", id).put("p_cash_account_id", cashAccountId ?: JSONObject.NULL)
            .put("p_bank_line_id", bankLineId ?: JSONObject.NULL), write = true, idempotencyKey = key)
    suspend fun receiptLookup(payload: String): ApiResult<JSONObject> = client.rpcObject("v1_receipt_qr_lookup", JSONObject().put("p_payload", payload))
    suspend fun reconcile(dealerId: String): ApiResult<JSONObject> = client.rpcObject("v1_dealer_reconcile", JSONObject().put("p_dealer_id", dealerId))
    suspend fun weekly(from: String?, to: String?): ApiResult<JSONArray> =
        client.rpcArray("v1_sales_weekly", JSONObject().put("p_from", from ?: JSONObject.NULL).put("p_to", to ?: JSONObject.NULL))
}

/** Client check before sending a collection (server re-checks): allocations positive, within open amounts and the paid sum. */
object CollectionRules {
    data class Alloc(val invoiceOpen: BigDecimal, val amount: BigDecimal)
    fun problem(amount: BigDecimal, method: String, reference: String?, allocs: List<Alloc>): String? = when {
        amount.signum() <= 0 -> "amount"
        method !in setOf("cash", "bank", "bkash", "nagad") -> "method"
        method != "cash" && (reference == null || !Regex("^[A-Za-z0-9/_-]{4,40}$").matches(reference)) -> "reference"
        allocs.any { it.amount.signum() <= 0 || it.amount > it.invoiceOpen } -> "allocation"
        allocs.fold(BigDecimal.ZERO) { a, x -> a + x.amount } > amount -> "allocations above the amount"
        else -> null
    }
}

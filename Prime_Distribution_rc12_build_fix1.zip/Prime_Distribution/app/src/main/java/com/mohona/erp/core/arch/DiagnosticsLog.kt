package com.mohona.erp.core.arch

import com.mohona.erp.core.net.AppError

/**
 * Small in-memory ring buffer of recent errors for the Diagnostics screen (support can quote the request id).
 * Holds codes and request ids only: never tokens, passwords or business data.
 */
object DiagnosticsLog {
    data class Item(val atMillis: Long, val code: String, val kind: String, val requestId: String?, val httpCode: Int?)

    private const val MAX = 50
    private val items = ArrayDeque<Item>()

    @Synchronized fun record(e: AppError, nowMillis: Long = System.currentTimeMillis()) {
        items.addFirst(Item(nowMillis, e.code, e.kind.name, e.requestId, e.httpCode))
        while (items.size > MAX) items.removeLast()
    }

    @Synchronized fun recent(): List<Item> = items.toList()
    @Synchronized fun clear() = items.clear()
}

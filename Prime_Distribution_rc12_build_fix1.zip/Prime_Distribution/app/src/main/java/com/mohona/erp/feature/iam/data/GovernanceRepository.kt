package com.mohona.erp.feature.iam.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class PersonAssignment(val assignmentId: String, val positionCode: String, val positionNameBn: String, val rank: Int, val status: String,
                            val kind: String, val validFrom: String?, val validUntil: String?, val homeWingId: String?, val homeDepartmentId: String?)

data class CompanyPerson(val membershipId: String, val personId: String, val fullNameBn: String, val employeeNo: String?, val status: String,
                         val assignments: List<PersonAssignment>) {
    val topRank: Int get() = assignments.filter { it.status == "active" }.maxOfOrNull { it.rank } ?: 0
}

data class Delegation(val id: String, val given: Boolean, val permissionCodes: List<String>, val scopeKind: ScopeKind, val scopeId: String?,
                      val validFrom: String, val validUntil: String, val reason: String, val live: Boolean)

data class PendingTransfer(val id: String, val companyId: String, val companyNameBn: String, val reason: String, val expiresAt: String)

enum class AssignmentAction(val wire: String) { END("end"), SUSPEND("suspend"), REACTIVATE("reactivate") }

/** People & power inside the active company (S09). Every call is re-authorized by the server (rank, scope, self rules). */
class GovernanceRepository(private val client: SupabaseClient) {

    suspend fun companyPeople(): ApiResult<List<CompanyPerson>> = arr("v1_iam_company_people", JSONObject()) { parsePeople(it) }

    suspend fun addMember(fullNameBn: String, phone: String?, email: String?, employeeNo: String?, reason: String, key: String): ApiResult<Pair<String, String>> =
        when (val r = client.rpcObject("v1_iam_add_member", JSONObject().put("p_full_name_bn", fullNameBn).put("p_phone", phone ?: JSONObject.NULL)
            .put("p_email", email ?: JSONObject.NULL).put("p_employee_no", employeeNo ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.optString("person_id") to r.value.optString("membership_id"))
        }

    suspend fun endMember(membershipId: String, reason: String, key: String): ApiResult<Unit> =
        unit("v1_iam_end_member", JSONObject().put("p_membership_id", membershipId).put("p_reason", reason), key)

    suspend fun assignPosition(membershipId: String, positionCode: String, validFromIso: String?, validUntilIso: String?, acting: Boolean,
                               homeWingId: String?, homeDepartmentId: String?, homeLocationId: String?, reason: String, key: String): ApiResult<String> =
        when (val r = client.rpc("v1_iam_assign_position", JSONObject().put("p_membership_id", membershipId).put("p_position_code", positionCode)
            .put("p_valid_from", validFromIso ?: JSONObject.NULL).put("p_valid_until", validUntilIso ?: JSONObject.NULL)
            .put("p_kind", if (acting) "acting" else "regular").put("p_home_wing", homeWingId ?: JSONObject.NULL)
            .put("p_home_department", homeDepartmentId ?: JSONObject.NULL).put("p_home_location", homeLocationId ?: JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.toString())
        }

    suspend fun changeAssignment(assignmentId: String, action: AssignmentAction, reason: String, key: String): ApiResult<Unit> =
        unit("v1_iam_change_assignment", JSONObject().put("p_assignment_id", assignmentId).put("p_action", action.wire).put("p_reason", reason), key)

    suspend fun revokeSessions(personId: String, reason: String, key: String): ApiResult<Unit> =
        unit("v1_iam_revoke_sessions", JSONObject().put("p_person_id", personId).put("p_reason", reason), key)

    suspend fun delegate(delegateAssignmentId: String, permissions: List<String>, scope: ScopeKind, scopeId: String?, validFromIso: String?,
                         validUntilIso: String, reason: String, key: String): ApiResult<String> =
        when (val r = client.rpc("v1_iam_delegate", JSONObject().put("p_delegate_assignment", delegateAssignmentId)
            .put("p_permissions", JSONArray(permissions)).put("p_scope_kind", scope.name).put("p_scope_id", scopeId ?: JSONObject.NULL)
            .put("p_valid_from", validFromIso ?: JSONObject.NULL).put("p_valid_until", validUntilIso).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.toString())
        }

    suspend fun revokeDelegation(delegationId: String, reason: String, key: String): ApiResult<Unit> =
        unit("v1_iam_revoke_delegation", JSONObject().put("p_delegation_id", delegationId).put("p_reason", reason), key)

    suspend fun myDelegations(): ApiResult<List<Delegation>> = arr("v1_iam_my_delegations", JSONObject()) { parseDelegations(it) }

    suspend fun proposeChairmanTransfer(toMembershipId: String, reason: String, key: String): ApiResult<String> =
        when (val r = client.rpc("v1_gov_propose_chairman_transfer", JSONObject().put("p_to_membership", toMembershipId).put("p_reason", reason), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.toString())
        }

    suspend fun acceptChairmanTransfer(transferId: String, key: String): ApiResult<Unit> =
        unit("v1_gov_accept_chairman_transfer", JSONObject().put("p_transfer_id", transferId), key)

    suspend fun cancelChairmanTransfer(transferId: String, key: String): ApiResult<Unit> =
        unit("v1_gov_cancel_chairman_transfer", JSONObject().put("p_transfer_id", transferId), key)

    suspend fun myPendingTransfers(): ApiResult<List<PendingTransfer>> = arr("v1_gov_my_pending_transfers", JSONObject()) { parseTransfers(it) }

    private suspend fun unit(name: String, params: JSONObject, key: String): ApiResult<Unit> =
        when (val r = client.rpc(name, params, write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(Unit)
        }

    private suspend fun <T> arr(name: String, params: JSONObject, parse: (JSONArray) -> T?): ApiResult<T> =
        when (val r = client.rpcArray(name, params)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parse(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse(name))
        }

    companion object {
        private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k, "").ifBlank { null }

        fun parsePeople(a: JSONArray): List<CompanyPerson>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i); val asg = o.optJSONArray("assignments") ?: JSONArray()
                CompanyPerson(o.getString("membership_id"), o.getString("person_id"), o.getString("full_name_bn"), o.str("employee_no"), o.getString("status"),
                    (0 until asg.length()).map { k ->
                        val x = asg.getJSONObject(k)
                        PersonAssignment(x.getString("assignment_id"), x.getString("position_code"), x.getString("position_name_bn"), x.optInt("rank"),
                            x.getString("status"), x.optString("kind", "regular"), x.str("valid_from"), x.str("valid_until"), x.str("home_wing_id"), x.str("home_department_id"))
                    })
            }
        } catch (e: Exception) { null }

        fun parseDelegations(a: JSONArray): List<Delegation>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i); val pc = o.getJSONArray("permission_codes")
                Delegation(o.getString("id"), o.getString("direction") == "given", (0 until pc.length()).map { pc.getString(it) },
                    ScopeKind.valueOf(o.getString("scope_kind")), o.str("scope_id"), o.getString("valid_from"), o.getString("valid_until"),
                    o.optString("reason"), o.optBoolean("live"))
            }
        } catch (e: Exception) { null }

        fun parseTransfers(a: JSONArray): List<PendingTransfer>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                PendingTransfer(o.getString("id"), o.getString("company_id"), o.getString("company_name_bn"), o.optString("reason"), o.getString("expires_at"))
            }
        } catch (e: Exception) { null }

        /** UI guard mirroring the server rule: a non-Chairman may act only strictly below their own rank and never on themselves. */
        fun canManage(myRank: Int, iAmSupreme: Boolean, myPersonId: String, target: CompanyPerson, targetPositionRank: Int, targetPositionCode: String): Boolean =
            targetPositionCode != "CHAIRMAN" && (iAmSupreme || (target.personId != myPersonId && targetPositionRank < myRank))
    }
}

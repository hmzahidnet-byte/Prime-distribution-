package com.mohona.erp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.print.InvoiceRender
import com.mohona.erp.feature.kpi.data.KpiFormat
import com.mohona.erp.feature.kpi.data.KpiRepository
import com.mohona.erp.feature.kpi.data.KpiStyle
import com.mohona.erp.feature.kpi.data.KpiValue
import com.mohona.erp.ui.components.DonutChart
import com.mohona.erp.ui.components.DonutPart
import com.mohona.erp.ui.components.KpiChart
import com.mohona.erp.ui.components.KpiChartData
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextMuted
import com.mohona.erp.ui.theme.chartColor
import java.time.LocalDate
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * Chairman studio (Prime 07): (1) graph studio — every KPI's chart type, size, shape and colour, previewed with live data and saved as a
 * versioned, audited style; (2) area-wise graphs — sales / collection / dues by territory or dealer, stock by warehouse, output and waste
 * by product, expenses by account; (3) the 50 invoice designs drawn with sample figures, chosen with an effective date (issued invoices
 * keep the design they were issued with). Everything is enforced by the server; this screen only shows and sends.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChairmanStudioScreen(onBack: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("চেয়ারম্যান স্টুডিও", onBack)
        FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("গ্রাফ-নকশা", "অঞ্চলভিত্তিক গ্রাফ", "ইনভয়েস-নকশা (৫০)", "উপাদান-নকশা").forEachIndexed { i, t -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) }) }
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (tab) { 0 -> GraphStudio(); 1 -> AreaGraphs(); 2 -> InvoiceGallery(); else -> PropertyStudio() }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GraphStudio() {
    val scope = rememberCoroutineScope()
    var catalog by remember { mutableStateOf(JSONArray()) }
    var selected by remember { mutableStateOf<JSONObject?>(null) }
    var style by remember { mutableStateOf(KpiStyle()) }
    var preview by remember { mutableStateOf<KpiValue?>(null) }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { (AppContainer.kpi?.catalog() as? ApiResult.Ok)?.let { catalog = it.value } ?: run { message = "সংযুক্ত মোড নয়।" } }
    Text("কোন KPI কেমন দেখাবে — সংখ্যা, রেখা, স্তম্ভ, ডোনাট বা ছোট রেখা; আকার ও রং। প্রতিটি পরিবর্তন সংস্করণসহ অডিটে থাকে।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (0 until catalog.length()).map { catalog.getJSONObject(it) }.forEach { k ->
            FilterChip(selected = selected?.optString("code") == k.optString("code"), onClick = {
                selected = k; style = KpiRepository.parseStyle(k.optJSONObject("style")); message = null
                scope.launch {
                    (AppContainer.kpi?.values(listOf(k.optString("code")), com.mohona.erp.feature.kpi.data.KpiQuery("this_month")) as? ApiResult.Ok)?.value?.firstOrNull()?.let { preview = it }
                }
            }, label = { Text(k.optString("name_bn")) })
        }
    }
    val k = selected ?: return
    Text(k.optString("name_bn") + " — " + k.optString("formula_bn"), style = MaterialTheme.typography.titleSmall)
    Text("চার্ট", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("number" to "সংখ্যা", "line" to "রেখা", "bar" to "স্তম্ভ", "donut" to "ডোনাট", "sparkline" to "ছোট রেখা").forEach { (c, l) ->
            FilterChip(selected = style.chart == c, onClick = { style = style.copy(chart = c) }, label = { Text(l) })
        }
    }
    Text("আকার ও আকৃতি", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("s" to "ছোট", "m" to "মাঝারি", "l" to "বড়").forEach { (c, l) -> FilterChip(selected = style.size == c, onClick = { style = style.copy(size = c) }, label = { Text(l) }) }
        listOf("card" to "কার্ড", "pill" to "পিল").forEach { (c, l) -> FilterChip(selected = style.shape == c, onClick = { style = style.copy(shape = c) }, label = { Text(l) }) }
    }
    Text("রং (সতর্কতার লাল/হলুদ শুধু খারাপ খবরের জন্য সংরক্ষিত)", style = MaterialTheme.typography.labelMedium)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (listOf("primary", "info", "good") + (1..8).map { "chart$it" }).forEach { c ->
            FilterChip(selected = style.color == c, onClick = { style = style.copy(color = c) }, label = {
                Text(when (c) { "primary" -> "মূল"; "info" -> "তথ্য"; "good" -> "ভালো"; else -> "● রং " + com.mohona.erp.data.Bn.digits(c.removePrefix("chart")) },
                    color = if (c.startsWith("chart")) chartColor(KpiChartData.colorIndex(c)) else MaterialTheme.colorScheme.onSurface)
            })
        }
    }
    preview?.let { v ->
        Text("পূর্বরূপ (এই মাস): " + KpiFormat.value(v), style = MaterialTheme.typography.titleMedium, color = OrangePrimary)
        if (!v.restricted && style.chart != "number") KpiChart(v.copy(style = style), "day", null, null, null)
    }
    OutlinedTextField(reason, { reason = it.take(200) }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
    OutlinedButton(onClick = {
        scope.launch {
            val r = AppContainer.kpi?.setStyle(k.optString("code"), style, k.optInt("style_version", 0), reason.trim(), "style-" + k.optString("code") + "-" + System.currentTimeMillis())
            message = when (r) { is ApiResult.Ok -> "সংরক্ষিত — সব ড্যাশবোর্ডে এই নকশা দেখাবে।"; is ApiResult.Err -> r.error.messageBn; null -> "সংযুক্ত মোড নয়।" }
            (AppContainer.kpi?.catalog() as? ApiResult.Ok)?.let { catalog = it.value; selected = (0 until it.value.length()).map { i -> it.value.getJSONObject(i) }.firstOrNull { x -> x.optString("code") == k.optString("code") } }
        }
    }) { Text("সংরক্ষণ") }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AreaGraphs() {
    val views = listOf(
        Triple("dms.sales", "territory", "এলাকাভিত্তিক বিক্রয়"), Triple("dms.sales", "dealer", "ডিলারভিত্তিক বিক্রয়"), Triple("dms.sales", "product", "পণ্যভিত্তিক বিক্রয়"),
        Triple("dms.collected", "territory", "এলাকাভিত্তিক আদায়"), Triple("dms.receivable", "territory", "এলাকাভিত্তিক বকেয়া"),
        Triple("stock.total_value", "warehouse", "গুদামভিত্তিক মজুদ"), Triple("mfg.fg_output", "product", "পণ্যভিত্তিক উৎপাদন"),
        Triple("mfg.waste", "product", "পণ্যভিত্তিক অপচয়"), Triple("fin.expenses", "account", "খাতভিত্তিক ব্যয়"))
    var pick by remember { mutableStateOf(0) }
    var month by remember { mutableStateOf(true) }
    var data by remember { mutableStateOf<JSONObject?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    val (code, by, title) = views[pick]
    LaunchedEffect(pick, month) {
        val today = LocalDate.now()
        val from = if (month) today.withDayOfMonth(1) else today.withDayOfYear(1)
        data = null; message = null
        when (val r = AppContainer.kpi?.split(code, by, from.toString(), today.toString(), 12)) {
            is ApiResult.Ok -> data = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।"
        }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        views.forEachIndexed { i, v -> FilterChip(selected = pick == i, onClick = { pick = i }, label = { Text(v.third) }) }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected = month, onClick = { month = true }, label = { Text("এই মাস") })
        FilterChip(selected = !month, onClick = { month = false }, label = { Text("এই বছর") })
    }
    Text(title, style = MaterialTheme.typography.titleSmall)
    val parts = KpiChartData.parts(data)
    if (parts.isNotEmpty()) {
        val total = parts.sumOf { it.second }
        val unit = data?.optString("unit")
        DonutChart(parts.mapIndexed { i, (l, v) -> DonutPart(l, v, chartColor(i % 8 + 1)) },
            if (unit == "money") com.mohona.erp.data.Bn.money(java.math.BigDecimal.valueOf(total)) else com.mohona.erp.data.Bn.dec(total, 0), "মোট", if (unit == "money") " টাকা" else "")
        parts.forEach { (l, v) -> Text(l + " — " + (if (unit == "money") com.mohona.erp.data.Bn.money(java.math.BigDecimal.valueOf(v)) else com.mohona.erp.data.Bn.dec(v, 0)), style = MaterialTheme.typography.bodySmall) }
    } else if (data != null) Text("এই সময়ে তথ্য নেই।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InvoiceGallery() {
    val scope = rememberCoroutineScope()
    var preview by remember { mutableStateOf<JSONObject?>(null) }
    var current by remember { mutableStateOf<String?>(null) }
    var chosen by remember { mutableStateOf<String?>(null) }
    var effective by remember { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
    var family by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        when (val r = AppContainer.client?.rpcObject("v1_invoice_design_preview")) {
            is ApiResult.Ok -> preview = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।"
        }
        (AppContainer.client?.rpcObject("v1_invoice_designs") as? ApiResult.Ok)?.let { current = it.value.optString("current").takeIf { c -> c.isNotBlank() && c != "null" } }
    }
    val p = preview ?: run { message?.let { Text(it, color = TextMuted) }; return }
    val sample = p.optJSONObject("sample")?.put("company", p.optJSONObject("company")) ?: JSONObject()
    val designs = p.optJSONArray("designs") ?: JSONArray()
    val all = (0 until designs.length()).map { designs.getJSONObject(it) }
    Text("বর্তমান নকশা: " + (current ?: "D01") + " · নতুন নকশা শুধু কার্যকর তারিখ থেকে নতুন ইনভয়েসে; পুরোনো ইনভয়েস নিজের নকশায় থাকে।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
    val families = listOf("" to "সব", "classic" to "ক্লাসিক", "banner" to "ব্যানার", "centered" to "মাঝখানে", "letterhead" to "লেটারহেড", "sidebar" to "ফিতা",
        "minimal" to "সাদামাটা", "boxed" to "বাক্স", "striped" to "ডোরাকাটা", "corporate" to "কর্পোরেট", "receipt" to "রসিদ")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { families.forEach { (f, l) -> FilterChip(selected = family == f, onClick = { family = f }, label = { Text(l) }) } }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        all.filter { family.isEmpty() || it.optJSONObject("spec")?.optString("family") == family }.forEach { d ->
            val spec = d.optJSONObject("spec") ?: JSONObject()
            val bmp = remember(d.optString("code")) { InvoiceRender.bitmap(spec, sample, "", 300).asImageBitmap() }
            Column(Modifier.width(150.dp)) {
                Image(bmp, contentDescription = d.optString("name_bn"),
                    modifier = Modifier.fillMaxWidth().border(if (chosen == d.optString("code")) 3.dp else 1.dp, if (chosen == d.optString("code")) OrangePrimary else TextMuted))
                FilterChip(selected = chosen == d.optString("code"), onClick = { chosen = d.optString("code") },
                    label = { Text(d.optString("code") + " · " + d.optString("name_bn"), style = MaterialTheme.typography.labelSmall) })
            }
        }
    }
    chosen?.let { c ->
        OutlinedTextField(effective, { effective = it.take(10) }, label = { Text("কার্যকর তারিখ (YYYY-MM-DD, আজ বা পরে)") }, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = {
            scope.launch {
                val r = AppContainer.client?.rpcObject("v1_invoice_design_set", JSONObject().put("p_design_code", c).put("p_effective_from", effective.trim()), write = true)
                message = when (r) { is ApiResult.Ok -> "নির্ধারিত: $c, ${effective} থেকে নতুন ইনভয়েসে।"; is ApiResult.Err -> r.error.messageBn; null -> "সংযুক্ত মোড নয়।" }
            }
        }) { Text("এই নকশা নির্ধারণ (শুধু চেয়ারম্যান)") }
    }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
}

/**
 * Micro-design (S71): every catalogued component property (payment tick, chips, cards, rows, carousel, markers, badges …) per company,
 * wing or position. Values are checked on the server (contrast, ranges, known icons); drafts go live together as one revision; any
 * revision can be restored. Meaning never changes: a tick still needs a verified + posted payment.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PropertyStudio() {
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf<JSONObject?>(null) }
    var component by remember { mutableStateOf<String?>(null) }
    var property by remember { mutableStateOf<String?>(null) }
    var scopeKind by remember { mutableStateOf("company") }
    var scopeRef by remember { mutableStateOf("") }
    var value by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    suspend fun reload() { (AppContainer.client?.rpcObject("v1_design_property_catalog") as? ApiResult.Ok)?.let { data = it.value } }
    LaunchedEffect(Unit) { reload() }
    val cat = data?.optJSONArray("catalog") ?: JSONArray()
    val rows = (0 until cat.length()).map { cat.getJSONObject(it) }
    Text("প্রকাশিত সংস্করণ: " + com.mohona.erp.data.Bn.digits(data?.optString("revision")?.takeIf { it != "null" } ?: "০"), style = MaterialTheme.typography.bodySmall, color = TextMuted)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.map { it.optString("component") to it.optString("name_bn") }.distinct().forEach { (k, n) ->
            FilterChip(selected = component == k, onClick = { component = k; property = null; value = "" }, label = { Text(n) })
        }
    }
    val c = component ?: return
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.filter { it.optString("component") == c }.forEach { r ->
            val p = r.optString("property")
            FilterChip(selected = property == p, onClick = { property = p }, label = { Text(PROP_BN[p] ?: p) })
        }
    }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("company" to "পুরো কোম্পানি", "wing" to "উইং", "position" to "পদ").forEach { (k, l) -> FilterChip(selected = scopeKind == k, onClick = { scopeKind = k }, label = { Text(l) }) }
    }
    if (scopeKind != "company") OutlinedTextField(scopeRef, { scopeRef = it.trim() }, label = { Text(if (scopeKind == "wing") "উইং-আইডি" else "পদ-কোড (যেমন MD)") }, modifier = Modifier.fillMaxWidth())
    val p = property ?: return
    OutlinedTextField(value, { value = it.take(60) }, label = { Text(PROP_HINT[p] ?: "মান") }, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(reason, { reason = it.take(200) }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
    if (c.startsWith("payment.status")) com.mohona.erp.ui.components.PaymentStatusMark(verified = c.endsWith("tick"), posted = c.endsWith("tick"))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { scope.launch {
            val v: Any = when (p) { "size_dp", "stroke_dp", "radius_dp", "text_scale", "interval_s" -> value.toDoubleOrNull() ?: value
                                    "visible" -> value == "true" || value == "হ্যাঁ"; else -> value }
            val r = AppContainer.client?.rpcObject("v1_design_property_set", JSONObject().put("p_scope_kind", scopeKind)
                .put("p_scope_ref", if (scopeKind == "company") JSONObject.NULL else scopeRef).put("p_component", c).put("p_property", p)
                .put("p_value", if (value.isBlank()) JSONObject.NULL else v).put("p_reason", reason.trim()), write = true)
            message = when (r) { is ApiResult.Ok -> "খসড়া রাখা হয়েছে — প্রকাশ করলে সবার অ্যাপে দেখাবে।"; is ApiResult.Err -> r.error.messageBn; null -> "সংযুক্ত মোড নয়।" }
            reload()
        } }) { Text("খসড়া রাখুন") }
        OutlinedButton(onClick = { scope.launch {
            val r = AppContainer.client?.rpcObject("v1_design_property_publish", JSONObject().put("p_reason", reason.trim().ifBlank { "নকশা প্রকাশ" }), write = true)
            message = when (r) { is ApiResult.Ok -> "প্রকাশিত: সংস্করণ " + com.mohona.erp.data.Bn.digits(r.value.optString("revision")) + " (আবার লগইন/পদ বাছাইয়ে প্রযোজ্য)"; is ApiResult.Err -> r.error.messageBn; null -> "সংযুক্ত মোড নয়।" }
            reload()
        } }) { Text("সব খসড়া প্রকাশ (শুধু চেয়ারম্যান)") }
    }
    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
}

private val PROP_BN = mapOf("color" to "রং", "background" to "পটভূমি", "icon" to "আইকন", "size_dp" to "আকার", "stroke_dp" to "রেখার পুরুত্ব", "radius_dp" to "কোণের বাঁক",
    "text_scale" to "লেখার মাপ", "animation" to "নড়াচড়া", "visible" to "দেখা যাবে", "density" to "ঘনত্ব", "style_variant" to "ধরন", "layout_variant" to "বিন্যাস",
    "label_bn" to "লেখা", "interval_s" to "বিরতি (সেকেন্ড)")
private val PROP_HINT = mapOf("color" to "#RRGGBB (সাদার ওপর পড়া যায় এমন)", "background" to "#RRGGBB (হালকা)", "icon" to "আইকনের নাম (যেমন Verified)",
    "size_dp" to "১২–৯৬", "stroke_dp" to "০–৮", "radius_dp" to "০–৩২", "text_scale" to "০.৮৫–১.৩০", "animation" to "none / subtle / standard",
    "visible" to "true / false", "density" to "compact / regular / comfortable", "style_variant" to "filled / outlined / tonal / text",
    "layout_variant" to "compact / regular / expanded", "label_bn" to "১–৪০ অক্ষরের বাংলা লেখা", "interval_s" to "৩–৩০")

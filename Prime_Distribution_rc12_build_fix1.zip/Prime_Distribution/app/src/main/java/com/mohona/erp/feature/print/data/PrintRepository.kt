package com.mohona.erp.feature.print.data

import com.mohona.erp.data.Bn
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

/** Print / share authorisation (S49): the server checks rights + registered device, logs it, returns data + watermark. */
class PrintRepository(private val client: SupabaseClient) {
    suspend fun authorize(docType: String, docRef: String, format: String, deviceId: String? = null): ApiResult<JSONObject> =
        client.rpcObject("v1_print_authorize", JSONObject().put("p_doc_type", docType).put("p_doc_ref", docRef).put("p_format", format)
            .put("p_device_id", deviceId ?: JSONObject.NULL), write = true)
    /** The design an invoice was issued with (never the company's current one). */
    suspend fun invoiceDesign(number: String): ApiResult<JSONObject> = client.rpcObject("v1_invoice_print_design", JSONObject().put("p_number", number))
}

/** Plain lines for each printable document type (same lines for PDF, image and POS). No VAT lines anywhere (OWN-06). */
object PrintLines {
    fun of(docType: String, data: Any?): Pair<String, List<String>> = when (docType) {
        "sales.invoice" -> invoice(data as JSONObject)
        "sales.receipt" -> receipt(data as JSONObject)
        "inventory.stock" -> "মজুদ-রিপোর্ট" to rows(data as? JSONArray ?: JSONArray()) { "${it.optString("warehouse")} · ${it.optString("sku")} · লট ${it.optString("lot_no")} · ${it.optString("qty")}" }
        "finance.ledger" -> "রেওয়ামিল" to rows((data as JSONObject).optJSONArray("rows") ?: JSONArray()) {
            "${it.optString("code")} ${it.optString("name_bn")} · ডে ${it.optString("debit")} · ক্রে ${it.optString("credit")}" }
        "hr.payslip" -> "বেতন-বিবরণী" to com.mohona.erp.feature.payroll.data.PayslipText.lines(data as JSONObject)
        else -> docType to emptyList()
    }

    private fun rows(a: JSONArray, f: (JSONObject) -> String): List<String> = (0 until a.length()).map { f(a.getJSONObject(it)) }

    private fun invoice(i: JSONObject): Pair<String, List<String>> {
        val out = ArrayList<String>()
        i.optJSONObject("company")?.let { co -> out += co.optString("name_bn"); co.optString("address_bn").takeIf { it.isNotBlank() && it != "null" }?.let { out += it } }
        out += "ডিলার: ${i.optString("dealer")}"
        out += "তারিখ ${Bn.digits(i.optString("date"))} · পরিশোধের শেষ দিন ${Bn.digits(i.optString("due_date"))}"
        val lines = i.optJSONArray("lines") ?: JSONArray()
        for (k in 0 until lines.length()) lines.getJSONObject(k).let {
            out += "${Bn.digits(it.optString("line"))}. ${it.optString("name_bn").takeIf { n -> n.isNotBlank() && n != "null" } ?: it.optString("sku")} " +
                   "${Bn.digits(it.optString("qty"))} × ${Bn.money(it.optString("price"))} = ${Bn.money(it.optString("amount"))}"
        }
        out += "মোট ${Bn.money(i.optString("total"))}"
        if (!i.isNull("open")) out += "বকেয়া ${Bn.money(i.optString("open"))}"
        i.optString("total_words").takeIf { it.isNotBlank() && it != "null" }?.let { out += "কথায়: $it" }
        out += "এই ইনভয়েস বা এর QR পরিশোধের প্রমাণ নয়।"
        return "ইনভয়েস ${Bn.digits(i.optString("number"))}" to out
    }

    private fun receipt(c: JSONObject): Pair<String, List<String>> {
        val out = ArrayList<String>()
        c.optJSONObject("company")?.let { out += it.optString("name_bn") }
        if (!c.isNull("unverified_banner")) out += "⚠ " + c.optString("unverified_banner")
        if (!c.isNull("dealer")) out += "ডিলার: ${c.optString("dealer")}"
        out += "টাকা ${Bn.money(c.optString("amount"))} · মাধ্যম ${c.optString("method")}"
        c.optString("amount_words").takeIf { it.isNotBlank() && it != "null" }?.let { out += "কথায়: $it" }
        out += "অবস্থা: ${c.optString("status")}"
        return "রসিদ ${Bn.digits(c.optString("number"))}" to out
    }
}

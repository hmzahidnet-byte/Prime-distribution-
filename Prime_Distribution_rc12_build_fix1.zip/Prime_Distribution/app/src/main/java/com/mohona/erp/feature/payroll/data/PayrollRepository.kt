package com.mohona.erp.feature.payroll.data

import com.mohona.erp.data.Bn
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

/** Payroll (S47–S48). Amounts always come from the server; the app only shows them. */
class PayrollRepository(private val client: SupabaseClient) {
    suspend fun calculate(periodIso: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_payroll_calculate", JSONObject().put("p_period", periodIso), write = true, idempotencyKey = key)
    suspend fun action(runId: String, action: String, note: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_payroll_action", JSONObject().put("p_run_id", runId).put("p_action", action).put("p_note", note ?: JSONObject.NULL), write = true, idempotencyKey = key)
    suspend fun payslip(runId: String, employeeId: String? = null): ApiResult<JSONObject> =
        client.rpcObject("v1_payslip", JSONObject().put("p_run_id", runId).put("p_employee_id", employeeId ?: JSONObject.NULL))
    suspend fun pay(runId: String, employeeId: String, method: String, amount: BigDecimal, reference: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_payroll_pay", JSONObject().put("p_run_id", runId).put("p_employee_id", employeeId).put("p_method", method).put("p_amount", amount)
            .put("p_reference", reference ?: JSONObject.NULL).put("p_proof_path", JSONObject.NULL), write = true, idempotencyKey = key)
    suspend fun reconcile(runId: String): ApiResult<JSONArray> = client.rpcArray("v1_payroll_reconcile", JSONObject().put("p_run_id", runId))
}

/** Turns a payslip into plain lines for the screen, a PDF or a POS printer (same text everywhere). */
object PayslipText {
    fun lines(p: JSONObject): List<String> {
        val out = ArrayList<String>()
        out += "বেতন-বিবরণী ${p.optString("run")} (${p.optString("period").take(7)})"
        out += "কর্মী: ${p.optString("employee")}"
        out += "কর্মদিবস ${p.optInt("days_employed")} · অনুপস্থিত ${p.optInt("absent_days")} · ছুটি ${p.optInt("leave_days")}"
        val e = p.optJSONArray("earnings") ?: JSONArray()
        for (i in 0 until e.length()) e.getJSONObject(i).let { out += "+ ${it.optString("code")}: ${Bn.money(it.optString("amount"))}" }
        val d = p.optJSONArray("deductions") ?: JSONArray()
        for (i in 0 until d.length()) d.getJSONObject(i).let { out += "− ${it.optString("code")}: ${Bn.money(it.optString("amount"))}" }
        out += "মোট আয় ${Bn.money(p.optString("gross"))} · কর্তন ${Bn.money(p.optString("deduction_total"))}"
        out += "নিট প্রাপ্য ${Bn.money(p.optString("net"))} · পরিশোধিত ${Bn.money(p.optString("paid"))}"
        return out
    }
}

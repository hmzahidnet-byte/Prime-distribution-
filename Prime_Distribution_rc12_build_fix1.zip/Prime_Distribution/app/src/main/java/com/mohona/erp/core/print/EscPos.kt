package com.mohona.erp.core.print

import java.io.ByteArrayOutputStream

/**
 * ESC/POS byte builder for 58 mm / 80 mm receipt printers (S49). Text is sent as UTF-8; printers without a Bengali
 * font should be given the PDF / image instead (the screen says so) — the builder never drops lines silently.
 */
class EscPos(private val charsPerLine: Int = 32) {
    private val out = ByteArrayOutputStream()

    init { out.write(byteArrayOf(0x1B, 0x40)) }                       // initialise

    fun center(on: Boolean): EscPos { out.write(byteArrayOf(0x1B, 0x61, (if (on) 1 else 0).toByte())); return this }
    fun bold(on: Boolean): EscPos { out.write(byteArrayOf(0x1B, 0x45, (if (on) 1 else 0).toByte())); return this }
    fun line(text: String): EscPos { wrap(text).forEach { out.write(it.toByteArray(Charsets.UTF_8)); out.write(0x0A) }; return this }
    fun rule(): EscPos = line("-".repeat(charsPerLine))
    fun pair(left: String, right: String): EscPos {
        val gap = charsPerLine - left.length - right.length
        return if (gap >= 1) line(left + " ".repeat(gap) + right) else line(left).line(right.padStart(charsPerLine))
    }
    fun feedAndCut(): ByteArray { out.write(byteArrayOf(0x0A, 0x0A, 0x0A, 0x1D, 0x56, 0x42, 0x00)); return out.toByteArray() }

    private fun wrap(text: String): List<String> = if (text.isEmpty()) listOf("") else text.chunked(charsPerLine)
}

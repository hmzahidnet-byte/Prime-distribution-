package com.mohona.erp.feature.courier.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

/**
 * Courier, condition and freight (blueprint v180) + Prime Distribution Architect 1 additions (money requests,
 * parties, Chairman chain). Money decisions are made on the server by the Chairman only; the app records and shows.
 */
class CourierRepository(private val client: SupabaseClient) {
    suspend fun shipments(status: String? = null): ApiResult<JSONArray> =
        client.rpcArray("v1_shipments", JSONObject().put("p_status", status ?: JSONObject.NULL).put("p_provider_id", JSONObject.NULL))
    suspend fun shipment(id: String): ApiResult<JSONObject> = client.rpcObject("v1_shipment_get", JSONObject().put("p_shipment_id", id))
    suspend fun statement(providerId: String, fromIso: String?, toIso: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_courier_statement", JSONObject().put("p_provider_id", providerId).put("p_from", fromIso ?: JSONObject.NULL).put("p_to", toIso ?: JSONObject.NULL))
    suspend fun reportCollection(shipmentId: String, amount: BigDecimal, collectedAtIso: String, eventKey: String): ApiResult<JSONObject> =
        client.rpcObject("v1_courier_collection_report", JSONObject().put("p_shipment_id", shipmentId).put("p_amount", amount).put("p_collected_at", collectedAtIso)
            .put("p_evidence_ref", JSONObject.NULL).put("p_event_key", eventKey), write = true, idempotencyKey = eventKey)
    suspend fun requestConditionChange(shipmentId: String, proposed: BigDecimal, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_condition_change_request", JSONObject().put("p_shipment_id", shipmentId).put("p_proposed_amount", proposed).put("p_reason", reason)
            .put("p_evidence_ref", JSONObject.NULL), write = true)
    suspend fun decideConditionChange(changeId: String, approve: Boolean): ApiResult<JSONObject> =
        client.rpcObject("v1_condition_change_decide", JSONObject().put("p_change_id", changeId).put("p_approve", approve), write = true)
    suspend fun moneyRequests(status: String? = "REQUESTED"): ApiResult<JSONArray> =
        client.rpcArray("v1_money_requests", JSONObject().put("p_kind", JSONObject.NULL).put("p_status", status ?: JSONObject.NULL))
    suspend fun decideMoneyRequest(id: String, approve: Boolean): ApiResult<JSONObject> =
        client.rpcObject("v1_money_request_decide", JSONObject().put("p_request_id", id).put("p_approve", approve), write = true)
    suspend fun chairmanChain(fromIso: String?, toIso: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_chairman_chain", JSONObject().put("p_from", fromIso ?: JSONObject.NULL).put("p_to", toIso ?: JSONObject.NULL))
    suspend fun parties(cls: String? = null, text: String? = null): ApiResult<JSONArray> =
        client.rpcArray("v1_parties", JSONObject().put("p_class", cls ?: JSONObject.NULL).put("p_text", text ?: JSONObject.NULL))
    suspend fun cartonLookup(payload: String): ApiResult<JSONObject> = client.rpcObject("v1_carton_lookup", JSONObject().put("p_payload", payload))
    suspend fun receiveFinishedGoods(batchId: String, receivedPoly: BigDecimal, note: String?): ApiResult<JSONObject> =
        client.rpcObject("v1_fg_receive", JSONObject().put("p_batch_id", batchId).put("p_received_poly", receivedPoly).put("p_note", note ?: JSONObject.NULL), write = true)
}

/** Client mirror of the v180 arithmetic, used for previews and tested with the blueprint's own example. */
object CourierMath {
    /** Courier still owes the company: verified collections − remittances − fees deducted from collections. */
    fun courierReceivable(collected: BigDecimal, remitted: BigDecimal, feeDeducted: BigDecimal): BigDecimal = collected - remitted - feeDeducted

    /** Shortfall of a released shipment must be fully classified: dealer due + approved concession (v180 invariant 6). */
    fun shortfall(condition: BigDecimal, collected: BigDecimal): BigDecimal = (condition - collected).max(BigDecimal.ZERO)
    fun classified(shortfall: BigDecimal, dealerDue: BigDecimal, concession: BigDecimal): Boolean =
        dealerDue.signum() >= 0 && concession.signum() >= 0 && shortfall.compareTo(dealerDue + concession) == 0

    /** Split freight: both shares non-negative and together exactly the final freight. */
    fun splitOk(finalFreight: BigDecimal, companyShare: BigDecimal, dealerShare: BigDecimal): Boolean =
        companyShare.signum() >= 0 && dealerShare.signum() >= 0 && finalFreight.compareTo(companyShare + dealerShare) == 0
}

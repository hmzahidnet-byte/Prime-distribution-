package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Production (S32–S35): batches, their reservations / QC / waste / WIP (cost readers), QC entry and completion. */
@Composable
fun MfgScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    var list by remember { mutableStateOf(JSONArray()) }
    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var fg by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) {
        when (val r = AppContainer.mfg?.batches()) { is ApiResult.Ok -> list = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    fun refresh(id: String) = scope.launch { (AppContainer.mfg?.batch(id) as? ApiResult.Ok)?.let { detail = it.value } }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("উৎপাদন", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (0 until list.length()).map { list.getJSONObject(it) }.forEach { b ->
                AppCard(onClick = { refresh(b.getString("id")) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(b.optString("number") + " · " + b.optString("name_bn") + if (b.optString("kind") == "rework") " (রিপ্যাক)" else "", style = MaterialTheme.typography.bodyMedium)
                        Text("পরিকল্পনা ${b.optString("planned_poly")} পলি · উৎপন্ন ${b.optString("fg_poly", "—")} · ${b.optString("status")}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
            detail?.let { d ->
                val id = d.getString("id")
                Text("${d.optString("number")} — ${d.optString("status")}", style = MaterialTheme.typography.titleSmall)
                if (!d.isNull("wip")) Text("চলমান খরচ (WIP): " + Bn.money(d.optString("wip")), style = MaterialTheme.typography.bodySmall)
                val qc = d.optJSONArray("qc") ?: JSONArray()
                (0 until qc.length()).map { qc.getJSONObject(it) }.forEach { q ->
                    Text("QC ${q.optString("stage")}: ${q.optString("result")}", style = MaterialTheme.typography.labelSmall, color = if (q.optString("result") == "fail") BadRed else TextMuted)
                }
                if (PermissionHints.can(perms, "mfg.qc.inspect") && d.optString("status") in setOf("approved", "in_progress", "completion_pending")) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(true to "চূড়ান্ত QC পাস", false to "চূড়ান্ত QC ফেল").forEach { (pass, label) ->
                            OutlinedButton(onClick = { scope.launch {
                                when (val r = AppContainer.mfg?.qc(id, "final", pass, null, UUID.randomUUID().toString())) {
                                    is ApiResult.Ok -> refresh(id); is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text(label) }
                        }
                    }
                }
                if (PermissionHints.can(perms, "mfg.fg.receive") && d.optString("status") == "in_progress") {
                    OutlinedTextField(value = fg, onValueChange = { fg = it.filter(Char::isDigit) }, label = { Text("উৎপন্ন পলি") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(enabled = fg.isNotBlank(), onClick = { scope.launch {
                        when (val r = AppContainer.mfg?.complete(id, fg.toBigDecimal(), null, null, "ব্যাচ সমাপ্ত", UUID.randomUUID().toString())) {
                            is ApiResult.Ok -> { message = if (r.value.optString("status") == "completed") "সমাপ্ত — উৎপাদন-হার ${r.value.optString("yield_pct")}%" else "কম উৎপাদন-হার: অনুমোদনের অপেক্ষায়"; reload++; refresh(id) }
                            is ApiResult.Err -> message = r.error.messageBn
                            null -> Unit
                        } } }) { Text("ব্যাচ সমাপ্ত করুন") }
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

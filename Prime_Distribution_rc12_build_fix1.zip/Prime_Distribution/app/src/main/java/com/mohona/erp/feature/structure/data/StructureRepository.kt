package com.mohona.erp.feature.structure.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class Dept(val id: String, val code: String, val nameBn: String, val parentId: String?, val active: Boolean, val rowVersion: Int)
data class Wing(val id: String, val code: String, val nameBn: String, val kind: String, val active: Boolean, val rowVersion: Int, val departments: List<Dept>)
data class Place(val id: String, val code: String, val nameBn: String, val kind: String, val wingId: String?, val areaCode: String?, val areaPath: String?,
                 val active: Boolean, val rowVersion: Int)
data class Store(val id: String, val code: String, val nameBn: String, val kind: String, val locationId: String?, val active: Boolean, val rowVersion: Int)
data class StructureTree(val wings: List<Wing>, val locations: List<Place>, val warehouses: List<Store>)
data class Area(val code: String, val kind: String, val nameBn: String, val path: String? = null)

/** Company structure (S23): wings / departments / locations / warehouses + Bangladesh administrative areas. */
class StructureRepository(private val client: SupabaseClient) {
    suspend fun tree(): ApiResult<StructureTree> = when (val r = client.rpcObject("v1_structure_tree")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseTree(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_structure_tree"))
    }
    suspend fun saveWing(id: String?, code: String?, nameBn: String?, kind: String?, status: String?, rowVersion: Int?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_structure_save_wing", JSONObject().put("p_id", id ?: JSONObject.NULL).put("p_code", code ?: JSONObject.NULL).put("p_name_bn", nameBn ?: JSONObject.NULL)
            .put("p_name_en", JSONObject.NULL).put("p_kind", kind ?: JSONObject.NULL).put("p_sort", JSONObject.NULL).put("p_status", status ?: JSONObject.NULL)
            .put("p_expected_row_version", rowVersion ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun saveDepartment(id: String?, wingId: String, parentId: String?, code: String?, nameBn: String?, status: String?, rowVersion: Int?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_structure_save_department", JSONObject().put("p_id", id ?: JSONObject.NULL).put("p_wing_id", wingId).put("p_parent_id", parentId ?: JSONObject.NULL)
            .put("p_code", code ?: JSONObject.NULL).put("p_name_bn", nameBn ?: JSONObject.NULL).put("p_name_en", JSONObject.NULL).put("p_sort", JSONObject.NULL)
            .put("p_status", status ?: JSONObject.NULL).put("p_expected_row_version", rowVersion ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun saveLocation(id: String?, wingId: String?, code: String?, nameBn: String?, kind: String, address: String?, areaCode: String?, lat: Double?, lon: Double?,
                             geofenceM: Int?, status: String?, rowVersion: Int?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_structure_save_location", JSONObject().put("p_id", id ?: JSONObject.NULL).put("p_wing_id", wingId ?: JSONObject.NULL)
            .put("p_code", code ?: JSONObject.NULL).put("p_name_bn", nameBn ?: JSONObject.NULL).put("p_kind", kind).put("p_address_bn", address ?: JSONObject.NULL)
            .put("p_admin_area_code", areaCode ?: JSONObject.NULL).put("p_latitude", lat ?: JSONObject.NULL).put("p_longitude", lon ?: JSONObject.NULL)
            .put("p_geofence_m", geofenceM ?: JSONObject.NULL).put("p_status", status ?: JSONObject.NULL).put("p_expected_row_version", rowVersion ?: JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun saveWarehouse(id: String?, wingId: String?, locationId: String?, code: String?, nameBn: String?, kind: String?, status: String?, rowVersion: Int?,
                              reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_structure_save_warehouse", JSONObject().put("p_id", id ?: JSONObject.NULL).put("p_wing_id", wingId ?: JSONObject.NULL)
            .put("p_location_id", locationId ?: JSONObject.NULL).put("p_code", code ?: JSONObject.NULL).put("p_name_bn", nameBn ?: JSONObject.NULL)
            .put("p_kind", kind ?: JSONObject.NULL).put("p_status", status ?: JSONObject.NULL).put("p_expected_row_version", rowVersion ?: JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun areaChildren(parentCode: String?): ApiResult<List<Area>> =
        when (val r = client.rpcArray("v1_geo_children", JSONObject().put("p_parent_code", parentCode ?: JSONObject.NULL))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(parseAreas(r.value))
        }
    suspend fun areaSearch(text: String, kind: String? = null): ApiResult<List<Area>> =
        when (val r = client.rpcArray("v1_geo_search", JSONObject().put("p_text", text).put("p_kind", kind ?: JSONObject.NULL).put("p_limit", 30))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(parseAreas(r.value))
        }

    companion object {
        private fun JSONObject.s(k: String): String? = if (!has(k) || isNull(k)) null else optString(k).ifBlank { null }

        fun parseTree(o: JSONObject): StructureTree? = try {
            val w = o.getJSONArray("wings"); val l = o.getJSONArray("locations"); val h = o.getJSONArray("warehouses")
            StructureTree(
                (0 until w.length()).map { w.getJSONObject(it).let { x ->
                    val d = x.optJSONArray("departments") ?: JSONArray()
                    Wing(x.getString("id"), x.getString("code"), x.getString("name_bn"), x.optString("kind"), x.optString("status") == "active", x.optInt("row_version"),
                        (0 until d.length()).map { d.getJSONObject(it).let { y -> Dept(y.getString("id"), y.getString("code"), y.getString("name_bn"), y.s("parent_id"),
                            y.optString("status") == "active", y.optInt("row_version")) } }) } },
                (0 until l.length()).map { l.getJSONObject(it).let { x -> Place(x.getString("id"), x.getString("code"), x.getString("name_bn"), x.optString("kind"),
                    x.s("wing_id"), x.s("admin_area_code"), x.s("admin_area"), x.optString("status") == "active", x.optInt("row_version")) } },
                (0 until h.length()).map { h.getJSONObject(it).let { x -> Store(x.getString("id"), x.getString("code"), x.getString("name_bn"), x.optString("kind"),
                    x.s("location_id"), x.optString("status") == "active", x.optInt("row_version")) } })
        } catch (e: Exception) { null }

        fun parseAreas(a: JSONArray): List<Area> = (0 until a.length()).map { a.getJSONObject(it).let { x -> Area(x.getString("code"), x.getString("kind"), x.getString("name_bn"), x.s("path")) } }

        /** Department rows of a wing as (department, depth), parents first. */
        fun departmentRows(w: Wing): List<Pair<Dept, Int>> {
            val out = ArrayList<Pair<Dept, Int>>(); val seen = HashSet<String>()
            fun walk(parent: String?, depth: Int) {
                w.departments.filter { it.parentId == parent }.sortedBy { it.code }.forEach { if (seen.add(it.id) && depth < 32) { out += it to depth; walk(it.id, depth + 1) } }
            }
            walk(null, 0)
            w.departments.filter { it.id !in seen }.forEach { out += it to 0 }
            return out
        }
    }
}

/** Area codes "DD.DD.DDD.DDD" (division . district . upazila . union) — parent and level from the code alone. */
object AreaCode {
    fun kind(code: String): String? = when (code.count { it == '.' }) { 0 -> "division"; 1 -> "district"; 2 -> "upazila"; 3 -> "union"; else -> null }
    fun parent(code: String): String? = code.substringBeforeLast('.', "").ifBlank { null }
    fun chain(code: String): List<String> = generateSequence(code) { parent(it) }.toList().reversed()
}

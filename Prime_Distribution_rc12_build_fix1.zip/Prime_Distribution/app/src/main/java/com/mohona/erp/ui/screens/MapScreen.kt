package com.mohona.erp.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.mohona.erp.feature.maps.InAppMap
import com.mohona.erp.feature.maps.MapPackage
import com.mohona.erp.feature.maps.MapPoint
import com.mohona.erp.feature.maps.OfflineMapStore
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.ops.data.LocationAge
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import java.time.Instant
import kotlinx.coroutines.launch
import org.json.JSONArray

@SuppressLint("MissingPermission")
private fun lastLocation(context: Context): android.location.Location? {
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return runCatching { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) }.getOrNull()
}

/**
 * Map & location (S50): explicit consent + runtime permission before any position is sent, foreground only;
 * live markers / dealer pins as lists that open in the phone's map app; stale positions are labelled, never shown as live.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MapScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var markers by remember { mutableStateOf(JSONArray()) }
    var pins by remember { mutableStateOf(JSONArray()) }
    var message by remember { mutableStateOf<String?>(null) }
    var packages by remember { mutableStateOf<List<MapPackage>>(emptyList()) }
    var mapMode by remember { mutableStateOf("view") }
    var drawn by remember { mutableStateOf<List<MapPoint>>(emptyList()) }
    var targetId by remember { mutableStateOf("") }
    var quota by remember { mutableStateOf(512) }

    fun send() {
        val loc = lastLocation(context)
        if (loc == null) { message = "ফোন এখনো অবস্থান পায়নি — GPS চালু করে আবার চেষ্টা করুন।"; return }
        scope.launch {
            when (val r = AppContainer.ops?.ping(loc.latitude, loc.longitude, if (loc.hasAccuracy()) loc.accuracy else null, Instant.ofEpochMilli(loc.time).toString())) {
                is ApiResult.Ok -> message = "অবস্থান পাঠানো হয়েছে।"
                is ApiResult.Err -> message = r.error.messageBn
                null -> message = "সংযুক্ত মোড নয়।"
            }
        }
    }
    val askPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) send() else message = "অনুমতি ছাড়া অবস্থান পাঠানো হয় না।"                        // deny gracefully (F231)
    }
    fun open(lat: String, lon: String, name: String) {
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode(name)})"))) }
            .onFailure { message = "এই ফোনে ম্যাপ-অ্যাপ নেই।" }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("ম্যাপ ও অবস্থান", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { scope.launch { when (val r = AppContainer.crm?.locationConsent(true, null)) {
                    is ApiResult.Ok -> message = "সম্মতি দেওয়া হয়েছে।"; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text("অবস্থান-সম্মতি দিন") }
                OutlinedButton(onClick = { scope.launch { when (val r = AppContainer.crm?.locationConsent(false, null)) {
                    is ApiResult.Ok -> message = "সম্মতি প্রত্যাহার — আপনার অবস্থান আর দেখানো হবে না।"; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text("সম্মতি প্রত্যাহার") }
                OutlinedButton(onClick = {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) send()
                    else askPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                }) { Text("এখনকার অবস্থান পাঠান") }
            }
            OutlinedButton(onClick = { scope.launch {
                (AppContainer.ops?.liveMarkers() as? ApiResult.Ok)?.let { markers = it.value }
                (AppContainer.ops?.dealerPins() as? ApiResult.Ok)?.let { pins = it.value }
            } }) { Text("মার্কার ও ডিলার-পিন আনুন") }
            if (markers.length() > 0) Text("মাঠকর্মী (সম্মতি দেওয়া)", style = MaterialTheme.typography.titleSmall)
            (0 until markers.length()).map { markers.getJSONObject(it) }.forEach { m ->
                OutlinedButton(onClick = { open(m.optString("lat"), m.optString("lon"), m.optString("name_bn")) }) {
                    Text(m.optString("name_bn") + " · " + LocationAge.label(m.optString("recorded_at"), Instant.now(), 15) + " · ±" + m.optString("accuracy_m", "?") + " মি")
                }
            }
            if (pins.length() > 0) Text("ডিলার", style = MaterialTheme.typography.titleSmall)
            (0 until pins.length()).map { pins.getJSONObject(it) }.forEach { p ->
                if (p.isNull("lat")) Text(p.optString("name_bn") + " · " + p.optString("address_bn"), style = MaterialTheme.typography.labelSmall)
                else OutlinedButton(onClick = { open(p.optString("lat"), p.optString("lon"), p.optString("name_bn")) }) { Text(p.optString("name_bn")) }
            }
            // in-app map (V162-12/13): markers of consented staff and permitted dealer pins; offline packages when downloaded
            val pts = (0 until markers.length()).map { markers.getJSONObject(it) }.mapNotNull { m ->
                    m.optString("lat").toDoubleOrNull()?.let { la -> m.optString("lon").toDoubleOrNull()?.let { lo -> MapPoint(la, lo, m.optString("name_bn")) } } } +
                (0 until pins.length()).map { pins.getJSONObject(it) }.mapNotNull { p ->
                    if (p.isNull("lat")) null else p.optString("lat").toDoubleOrNull()?.let { la -> p.optString("lon").toDoubleOrNull()?.let { lo -> MapPoint(la, lo, p.optString("name_bn")) } } }
            // map editing: drop a pin for a dealer's location claim, or tap corners of a market boundary
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("view" to "দেখা", "pin" to "পিন বসান", "polygon" to "বাজার-সীমানা আঁকুন").forEach { (k, l) ->
                    androidx.compose.material3.FilterChip(selected = mapMode == k, onClick = { mapMode = k; drawn = emptyList() }, label = { Text(l) })
                }
            }
            InAppMap(Modifier.fillMaxWidth().height(320.dp), pts + drawn.takeIf { mapMode == "pin" }.orEmpty(), emptyList(),
                listOfNotNull(drawn.takeIf { mapMode == "polygon" && it.isNotEmpty() }), "© OpenStreetMap contributors",
                onTap = if (mapMode == "view") null else ({ p -> drawn = if (mapMode == "pin") listOf(p.copy(title = "নতুন পিন")) else drawn + p }))
            if (mapMode != "view") {
                OutlinedTextField(targetId, { targetId = it.trim() }, label = { Text(if (mapMode == "pin") "ডিলার-আইডি" else "বাজার-আইডি") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedButton(enabled = targetId.isNotBlank() && ((mapMode == "pin" && drawn.size == 1) || (mapMode == "polygon" && drawn.size >= 3)), onClick = { scope.launch {
                    val c = AppContainer.client ?: run { message = "সংযুক্ত মোড নয়।"; return@launch }
                    val r = if (mapMode == "pin") c.rpcObject("v1_location_claim_submit", org.json.JSONObject().put("p_owner_kind", "dealer").put("p_owner_id", targetId)
                            .put("p_latitude", drawn[0].lat).put("p_longitude", drawn[0].lon).put("p_accuracy_m", org.json.JSONObject.NULL).put("p_admin_area_code", org.json.JSONObject.NULL)
                            .put("p_address_bn", org.json.JSONObject.NULL).put("p_provider", "manual").put("p_place_id", org.json.JSONObject.NULL).put("p_evidence_path", org.json.JSONObject.NULL)
                            .put("p_client_request_id", "PIN-" + java.util.UUID.randomUUID().toString().replace("-", "")), write = true)
                        else c.rpcObject("v1_market_boundary_set", org.json.JSONObject().put("p_market_id", targetId)
                            .put("p_boundary", org.json.JSONArray(drawn.map { org.json.JSONArray().put(it.lat).put(it.lon) })).put("p_accept_overlap", false).put("p_reason", "ম্যাপে আঁকা"), write = true)
                    message = when (r) {
                        is ApiResult.Ok -> if (mapMode == "pin") "পিন জমা হয়েছে — যাচাই ও অনুমোদনের পর ডিলারের অবস্থান বদলাবে।"
                                           else if (r.value.optBoolean("saved")) "সীমানা সংরক্ষিত (সংস্করণ " + com.mohona.erp.data.Bn.digits(r.value.optString("version")) + ")।"
                                           else "অন্য বাজারের সাথে মিলে যায় — অফিস থেকে যাচাই করে সংরক্ষণ করুন।"
                        is ApiResult.Err -> r.error.messageBn
                    }
                    if (r is ApiResult.Ok) drawn = emptyList()
                } }) { Text(if (mapMode == "pin") "পিন জমা দিন" else "সীমানা সংরক্ষণ") }
                if (drawn.isNotEmpty()) OutlinedButton(onClick = { drawn = emptyList() }) { Text("মুছে আবার") }
            }
            Text("© OpenStreetMap contributors", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text("অফলাইন ম্যাপ (নেটওয়ার্ক ছাড়া)", style = MaterialTheme.typography.titleSmall)
            OutlinedButton(onClick = { scope.launch {
                when (val r = AppContainer.client?.rpcObject("v1_map_packages")) {
                    is ApiResult.Ok -> { val (q, list) = OfflineMapStore.parse(r.value); quota = q; packages = list.filter { it.current } }
                    is ApiResult.Err -> message = r.error.messageBn
                    null -> message = "সংযুক্ত মোড নয়।"
                }
            } }) { Text("অঞ্চলের তালিকা আনুন") }
            Text("নামানো আছে: " + OfflineMapStore.installed(context).size + " টি · " + (OfflineMapStore.usedBytes(context) / 1_048_576) + " / " + quota + " MB",
                style = MaterialTheme.typography.labelSmall, color = TextMuted)
            packages.forEach { p ->
                OutlinedButton(onClick = { message = "নামানো হচ্ছে…"; scope.launch { message = OfflineMapStore.install(context, p, quota) } }) {
                    Text(p.nameBn + " · " + (p.sizeBytes / 1_048_576) + " MB · v" + p.version)
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

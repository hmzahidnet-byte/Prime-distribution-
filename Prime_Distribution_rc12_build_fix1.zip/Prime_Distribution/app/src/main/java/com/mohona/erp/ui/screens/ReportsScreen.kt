package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.print.DocumentRender
import com.mohona.erp.feature.report.data.ReportChart
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import java.io.File
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Custom reports (S52): approved templates, run in the user's own scope, bar view with values as text, CSV share. */
@Composable
fun ReportsScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var templates by remember { mutableStateOf(JSONArray()) }
    var output by remember { mutableStateOf<JSONObject?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        when (val r = AppContainer.reports?.templates()) { is ApiResult.Ok -> templates = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("রিপোর্ট", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            (0 until templates.length()).map { templates.getJSONObject(it) }.forEach { t ->
                AppCard(onClick = {
                    if (t.optString("status") != "approved") { message = "এই টেমপ্লেট এখনো অনুমোদিত নয়।"; return@AppCard }
                    scope.launch {
                        when (val r = AppContainer.reports?.run(t.getString("id"), null, null, "view")) {
                            is ApiResult.Ok -> { output = r.value; message = null }
                            is ApiResult.Err -> message = r.error.messageBn
                            null -> Unit
                        }
                    }
                }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(t.optString("name_bn") + " (v" + t.optInt("version") + ")", style = MaterialTheme.typography.bodyMedium)
                        Text(t.optString("dataset") + " · " + t.optString("chart") + " · " + t.optString("status"), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
            output?.let { o ->
                val rows = o.optJSONArray("rows") ?: JSONArray()
                if (rows.length() == 0) Text("এই সময়ে আপনার দেখার মতো কোনো সারি নেই।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                val first = if (rows.length() > 0) rows.getJSONObject(0) else JSONObject()
                if (first.has("value")) {
                    val labelKey = first.keys().asSequence().firstOrNull { it != "value" } ?: "value"
                    ReportChart.bars(rows, labelKey).forEach { b ->
                        Text(b.label + " — " + b.value.toPlainString(), style = MaterialTheme.typography.labelSmall)
                        Box(Modifier.fillMaxWidth(b.fraction.coerceIn(0.02f, 1f)).height(10.dp).background(MaterialTheme.colorScheme.primary))
                    }
                } else {
                    (0 until rows.length()).map { rows.getJSONObject(it) }.forEach { r ->
                        Text(r.keys().asSequence().filter { it != "id" && !r.isNull(it) }.joinToString(" · ") { r.optString(it) }, style = MaterialTheme.typography.labelSmall)
                    }
                }
                OutlinedButton(onClick = {
                    runCatching {
                        val dir = File(context.cacheDir, "shared").apply { mkdirs() }
                        val f = File(dir, "mohona-report.csv")
                        f.writeText("\uFEFF" + ReportChart.csv(rows))
                        DocumentRender.share(context, f, "text/csv")
                    }.onFailure { message = "CSV তৈরি করা যায়নি।" }
                }) { Text("CSV শেয়ার") }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

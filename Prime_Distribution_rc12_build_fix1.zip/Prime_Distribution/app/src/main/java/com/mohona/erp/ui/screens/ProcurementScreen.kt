package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Procurement (S26–S28): purchase orders (receive goods on approved ones), supplier dues aging, GRNI, supplier performance. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProcurementScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    var tab by remember { mutableStateOf("po") }
    var data by remember { mutableStateOf(JSONArray()) }
    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var qty by remember { mutableStateOf("") }
    var lot by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab, reload) {
        val repo = AppContainer.procurement ?: run { message = "সংযুক্ত মোড নয়।"; return@LaunchedEffect }
        val r = when (tab) { "po" -> repo.pos(); "dues" -> repo.dues(); "grni" -> repo.grni(); else -> repo.performance() }
        when (r) { is ApiResult.Ok -> data = r.value; is ApiResult.Err -> message = r.error.messageBn }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("ক্রয় ও দেনা", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("po" to "ক্রয়-আদেশ", "dues" to "বকেয়া", "grni" to "গৃহীত-বিলহীন", "perf" to "সাপ্লায়ার-মান").forEach { (k, l) ->
                    FilterChip(selected = tab == k, onClick = { tab = k; detail = null }, label = { Text(l) })
                }
            }
            (0 until data.length()).map { data.getJSONObject(it) }.forEach { o ->
                when (tab) {
                    "po" -> AppCard(onClick = { scope.launch { (AppContainer.procurement?.po(o.getString("id")) as? ApiResult.Ok)?.let { detail = it.value } } }) {
                        Column(Modifier.padding(12.dp)) {
                            Text((o.optString("number").ifBlank { "খসড়া" }) + " · " + o.optString("supplier"), style = MaterialTheme.typography.bodyMedium)
                            Text("" + Bn.money(o.optString("total")) + " · " + o.optString("status") + " · v" + o.optInt("version"), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                    }
                    "dues" -> AppCard { Column(Modifier.padding(12.dp)) {
                        Text(o.optString("supplier") + " · মোট বকেয়া " + Bn.money(o.optString("open")), style = MaterialTheme.typography.bodyMedium)
                        Text("চলতি ${o.optString("current", "0")} · ১–৩০ ${o.optString("d1_30", "0")} · ৩১–৬০ ${o.optString("d31_60", "0")} · ৬১–৯০ ${o.optString("d61_90", "0")} · ৯০+ ${o.optString("d90_plus", "0")}",
                            style = MaterialTheme.typography.labelSmall, color = if (o.optString("d90_plus", "null") != "null") BadRed else TextMuted)
                    } }
                    "grni" -> Text(o.optString("supplier") + " · " + Bn.money(o.optString("value")), style = MaterialTheme.typography.bodySmall)
                    else -> Text(o.optString("supplier") + " · সময়মতো ${o.optString("on_time_pct")}% · প্রত্যাখ্যান ${o.optString("rejection_pct")}% · দাম-পার্থক্য ${o.optInt("price_variance_bills")}",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            detail?.let { d ->
                Text("${d.optString("number")} — ${d.optString("status")} (অনুমোদন: ${d.optString("approval", "—")})", style = MaterialTheme.typography.titleSmall)
                val lines = d.optJSONArray("lines") ?: JSONArray()
                (0 until lines.length()).map { lines.getJSONObject(it) }.forEach { l ->
                    Text("${l.optInt("line_no")}. ${l.optString("name_bn")} · অর্ডার ${l.optString("qty")} · গৃহীত ${l.optString("received_qty")} · ${Bn.money(l.optString("unit_price"))}",
                        style = MaterialTheme.typography.labelSmall)
                }
                if (PermissionHints.can(perms, "procurement.grn.receive") && d.optString("status") in setOf("approved", "partially_received") && lines.length() > 0) {
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("লাইন ১-এ গৃহীত পরিমাণ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = lot, onValueChange = { lot = it }, label = { Text("লট নম্বর") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedButton(enabled = qty.toBigDecimalOrNull() != null, onClick = {
                        scope.launch {
                            val line = JSONObject().put("po_line_id", lines.getJSONObject(0).getString("id")).put("received", qty.toBigDecimal()).apply { if (lot.isNotBlank()) put("lot_no", lot) }
                            when (val r = AppContainer.procurement?.grn(d.getString("id"), null, JSONArray().put(line), "মাল-গ্রহণ", UUID.randomUUID().toString())) {
                                is ApiResult.Ok -> { message = "GRN " + r.value.optString("number") + " পোস্ট হয়েছে।"; detail = null; reload++ }
                                is ApiResult.Err -> message = r.error.messageBn
                                null -> Unit
                            }
                        }
                    }) { Text("মাল গ্রহণ (GRN)") }
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

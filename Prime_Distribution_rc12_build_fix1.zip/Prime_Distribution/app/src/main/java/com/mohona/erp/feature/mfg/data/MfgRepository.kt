package com.mohona.erp.feature.mfg.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.math.RoundingMode
import org.json.JSONArray
import org.json.JSONObject

/** Manufacturing (S32–S35): BOMs, plans, batches, QC, waste, completion, rework, traceability. */
class MfgRepository(private val client: SupabaseClient) {
    suspend fun batches(status: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_batches", JSONObject().put("p_status", status ?: JSONObject.NULL))
    suspend fun batch(id: String): ApiResult<JSONObject> = client.rpcObject("v1_batch_get", JSONObject().put("p_batch_id", id))
    suspend fun createBatch(productId: String, plannedPoly: BigDecimal, rawWh: String, fgWh: String, line: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_batch_create", JSONObject().put("p_product_id", productId).put("p_variant_id", JSONObject.NULL).put("p_bom_id", JSONObject.NULL)
            .put("p_planned_poly", plannedPoly).put("p_raw_warehouse", rawWh).put("p_fg_warehouse", fgWh).put("p_production_line", line ?: JSONObject.NULL)
            .put("p_plan_id", JSONObject.NULL).put("p_plan_line", JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun approve(batchId: String, note: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_batch_approve", JSONObject().put("p_batch_id", batchId).put("p_note", note), write = true, idempotencyKey = key)
    suspend fun qc(batchId: String, stage: String, pass: Boolean, notes: String?, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_batch_qc", JSONObject().put("p_batch_id", batchId).put("p_stage", stage).put("p_result", if (pass) "pass" else "fail")
            .put("p_parameters", JSONObject()).put("p_notes", notes ?: JSONObject.NULL), write = true, idempotencyKey = key)
    suspend fun waste(batchId: String, kind: String, qtyPoly: BigDecimal, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_batch_waste", JSONObject().put("p_batch_id", batchId).put("p_kind", kind).put("p_qty_poly", qtyPoly).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun complete(batchId: String, fgPoly: BigDecimal, lotNo: String?, expiryIso: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_batch_complete", JSONObject().put("p_batch_id", batchId).put("p_fg_poly", fgPoly).put("p_lot_no", lotNo ?: JSONObject.NULL)
            .put("p_expiry_date", expiryIso ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun traceBackward(fgLotId: String): ApiResult<JSONObject> = client.rpcObject("v1_trace_backward", JSONObject().put("p_fg_lot_id", fgLotId))
    suspend fun traceForward(lotId: String): ApiResult<JSONObject> = client.rpcObject("v1_trace_forward", JSONObject().put("p_lot_id", lotId))
}

/** ADR-11 mirror for previews: capitalised WIP split over POLY with the remainder on the last one. */
object CostSplit {
    data class Split(val unitCost: BigDecimal, val lastCost: BigDecimal, val capitalised: BigDecimal, val variance: BigDecimal)

    fun split(wip: BigDecimal, fgPoly: Int, plannedPoly: BigDecimal, withVariance: Boolean): Split {
        val cap = if (withVariance) wip.multiply(BigDecimal(fgPoly)).divide(plannedPoly, 4, RoundingMode.HALF_UP).min(wip) else wip
        if (fgPoly == 1) return Split(cap, cap, cap, wip - cap)
        val unit = cap.divide(BigDecimal(fgPoly), 4, RoundingMode.DOWN)
        val last = cap - unit.multiply(BigDecimal(fgPoly - 1))
        return Split(unit, last, cap, wip - cap)
    }

    fun yieldPct(fgPoly: BigDecimal, plannedPoly: BigDecimal): BigDecimal = fgPoly.multiply(BigDecimal(100)).divide(plannedPoly, 2, RoundingMode.HALF_UP)
}

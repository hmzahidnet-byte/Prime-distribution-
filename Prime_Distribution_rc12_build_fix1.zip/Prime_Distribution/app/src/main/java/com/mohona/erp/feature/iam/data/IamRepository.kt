package com.mohona.erp.feature.iam.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONObject

data class Person(val id: String, val fullNameBn: String, val fullNameEn: String?, val authzEpoch: Int)

data class Membership(
    val membershipId: String,
    val companyId: String,
    val companyCode: String,
    val companyNameBn: String,
    val status: String,          // invited | active | suspended
    val companyStatus: String,
    val employeeNo: String?
) {
    val usable: Boolean get() = status == "active" && companyStatus == "active"
}

data class WhoAmI(val person: Person, val memberships: List<Membership>) {
    val usableCompanies: List<Membership> get() = memberships.filter { it.usable }
}

/** Identity layer (S05). One login = one person; companies come from memberships, never from a client choice. */
class IamRepository(private val client: SupabaseClient) {

    suspend fun whoAmI(): ApiResult<WhoAmI> = when (val r = client.rpcObject("v1_iam_whoami")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseWhoAmI(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_whoami"))
    }

    companion object {
        fun parseWhoAmI(o: JSONObject): WhoAmI? = try {
            val p = o.getJSONObject("person")
            val person = Person(p.getString("id"), p.getString("full_name_bn"), p.optString("full_name_en", "").ifBlank { null }, p.optInt("authz_epoch", 0))
            val arr = o.optJSONArray("memberships")
            val list = ArrayList<Membership>()
            if (arr != null) for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                list.add(Membership(m.getString("membership_id"), m.getString("company_id"), m.getString("company_code"), m.getString("company_name_bn"),
                    m.getString("status"), m.getString("company_status"), m.optString("employee_no", "").ifBlank { null }))
            }
            WhoAmI(person, list)
        } catch (e: Exception) { null }
    }
}

package com.mohona.erp.feature.auth.data

import java.security.SecureRandom

/**
 * Client mirrors of the server rules (S16). Only for instant feedback — the server decides:
 * [canonicalPhone] = core.fn_phone_canonical, [pinProblem] = iam.fn_pin_policy_error.
 */
object LoginRules {
    private fun asciiDigits(s: String) = buildString { for (c in s) append(if (c in '০'..'৯') '0' + (c - '০') else c) }

    fun canonicalPhone(raw: String?): String? {
        val d = asciiDigits(raw ?: "").filter { it.isDigit() }
        return when {
            Regex("^8801[3-9][0-9]{8}$").matches(d) -> "+$d"
            Regex("^01[3-9][0-9]{8}$").matches(d) -> "+88$d"
            d.length in 8..15 -> "+$d"
            else -> null
        }
    }

    /** null = acceptable; else digits | length | repeated | sequence | common. */
    fun pinProblem(pin: String, length: Int = 6): String? {
        if (pin.isEmpty() || !pin.all { it in '0'..'9' }) return "digits"
        if (pin.length != length) return "length"
        if (pin.all { it == pin[0] }) return "repeated"
        var asc = true; var desc = true
        for (i in 1 until pin.length) {
            val a = pin[i - 1] - '0'; val b = pin[i] - '0'
            if ((b - a + 10) % 10 != 1) asc = false
            if ((a - b + 10) % 10 != 1) desc = false
        }
        if (asc || desc) return "sequence"
        if (pin in setOf("121212", "123123", "112233", "101010", "696969", "007007", "131313", "202020", "212121")) return "common"
        return null
    }

    fun pinProblemBn(code: String?): String? = when (code) {
        null -> null
        "digits" -> "PIN শুধু সংখ্যা।"
        "length" -> "PIN-এর দৈর্ঘ্য ঠিক নয়।"
        "repeated" -> "একই অঙ্ক বারবার নয়।"
        "sequence" -> "ক্রমিক অঙ্ক (যেমন ১২৩৪৫৬) নয়।"
        else -> "খুব সহজ PIN; অন্যটি বেছে নিন।"
    }

    /** A new per-install device id (stored by the app; the server keeps only its SHA-256). */
    fun newDeviceId(): String {
        val b = ByteArray(24).also { SecureRandom().nextBytes(it) }
        return "d" + b.joinToString("") { "%02x".format(it) }
    }
}

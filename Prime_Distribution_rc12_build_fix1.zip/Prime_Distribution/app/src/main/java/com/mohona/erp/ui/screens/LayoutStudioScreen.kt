package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.design.data.Breakpoint
import com.mohona.erp.feature.design.data.LayoutGrid
import com.mohona.erp.feature.design.data.ScreenLayout
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.components.SectionTitle
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray

/**
 * Design Studio 2 (S19): presets, snap-grid editing per breakpoint, responsive preview, server validation, save,
 * publish and rollback of layouts; rollback of themes. Approval panels and ad slots follow the server rules.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LayoutStudioScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var screenKey by remember { mutableStateOf("home") }
    var presets by remember { mutableStateOf(JSONArray()) }
    var layout by remember { mutableStateOf<ScreenLayout?>(null) }
    var bpName by remember { mutableStateOf("phone") }
    var selected by remember { mutableStateOf<String?>(null) }
    var versions by remember { mutableStateOf(JSONArray()) }
    var themes by remember { mutableStateOf(JSONArray()) }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(screenKey, reload) {
        val d = AppContainer.design ?: run { message = "সংযুক্ত মোড নয়।"; return@LaunchedEffect }
        (d.presets(screenKey) as? ApiResult.Ok)?.let { presets = it.value }
        (d.layouts(screenKey) as? ApiResult.Ok)?.let { versions = it.value }
        (d.themes() as? ApiResult.Ok)?.let { themes = it.value }
    }
    val bp = layout?.breakpoints?.get(bpName)
    val local = layout?.let { LayoutGrid.errors(it) } ?: emptyList()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("লেআউট-স্টুডিও", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = screenKey, onValueChange = { screenKey = it.lowercase().take(40) }, label = { Text("পর্দা (home / dashboard.md / wing.x)") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            SectionTitle("প্রিসেট-গ্যালারি")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (0 until presets.length()).map { presets.getJSONObject(it) }.forEach { p ->
                    FilterChip(selected = false, onClick = { layout = LayoutGrid.parse(p.optJSONObject("layout")); selected = null; message = p.optString("name_bn") + " — খসড়া হিসেবে সম্পাদনা করুন" },
                        label = { Text(p.optString("name_bn")) })
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("phone" to "ফোন", "tablet" to "ট্যাবলেট", "landscape" to "আড়াআড়ি").forEach { (k, label) ->
                    FilterChip(selected = bpName == k, enabled = layout?.breakpoints?.containsKey(k) == true, onClick = { bpName = k; selected = null }, label = { Text(label) })
                }
            }
            if (bp != null) {
                GridPreview(bp, if (bpName == "phone") 320.dp else 520.dp, selected) { selected = it }
                selected?.let { id ->
                    Text("নির্বাচিত: $id — ঘর ধরে সরান/বড়-ছোট করুন", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("←" to intArrayOf(-1, 0, 0, 0), "→" to intArrayOf(1, 0, 0, 0), "↑" to intArrayOf(0, -1, 0, 0), "↓" to intArrayOf(0, 1, 0, 0),
                            "প্রস্থ+" to intArrayOf(0, 0, 1, 0), "প্রস্থ−" to intArrayOf(0, 0, -1, 0), "উচ্চতা+" to intArrayOf(0, 0, 0, 1), "উচ্চতা−" to intArrayOf(0, 0, 0, -1))
                            .forEach { (label, d) ->
                                OutlinedButton(onClick = {
                                    val l = layout ?: return@OutlinedButton
                                    val next = LayoutGrid.edit(bp, id, d[0], d[1], d[2], d[3])
                                    if (next == null) message = "এভাবে সরানো যায় না (গ্রিডের বাইরে / ওভারল্যাপ / অনুমোদন-বোতাম নিচে)"
                                    else layout = l.copy(breakpoints = l.breakpoints + (bpName to next))
                                }) { Text(label) }
                            }
                    }
                }
            }
            local.forEach { Text("ত্রুটি: $it", color = BadRed, style = MaterialTheme.typography.labelSmall) }
            OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("কারণ") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = layout != null, onClick = {
                    val l = layout ?: return@OutlinedButton
                    scope.launch {
                        when (val r = AppContainer.design?.validateLayout(LayoutGrid.encode(l))) {
                            is ApiResult.Ok -> message = if (r.value.ok) "সার্ভার-যাচাই: ঠিক আছে" + r.value.warnings.joinToString(prefix = " · ") else "সার্ভার-যাচাই: " + r.value.errors.joinToString("; ")
                            is ApiResult.Err -> message = r.error.messageBn
                            null -> Unit
                        }
                    }
                }) { Text("যাচাই") }
                OutlinedButton(enabled = layout != null && reason.isNotBlank(), onClick = {
                    val l = layout ?: return@OutlinedButton
                    scope.launch {
                        when (val r = AppContainer.design?.saveLayout(screenKey, LayoutGrid.encode(l), null, reason, UUID.randomUUID().toString())) {
                            is ApiResult.Ok -> { message = "খসড়া সংস্করণ ${r.value.optInt("version")} সংরক্ষিত"; reload++ }
                            is ApiResult.Err -> message = r.error.messageBn
                            null -> Unit
                        }
                    }
                }) { Text("খসড়া") }
            }
            SectionTitle("সংস্করণ (প্রকাশ / ফিরিয়ে আনা)")
            (0 until versions.length()).map { versions.getJSONObject(it) }.forEach { v ->
                val status = v.optString("status"); val ver = v.optInt("version")
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("v$ver · $status" + if (v.optBoolean("ok")) "" else " · ত্রুটি", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    if (status == "draft" || status == "superseded") OutlinedButton(enabled = reason.isNotBlank(), onClick = {
                        scope.launch {
                            when (val r = AppContainer.design?.publishLayout(screenKey, ver, if (status == "draft") "publish" else "rollback", reason, UUID.randomUUID().toString())) {
                                is ApiResult.Ok -> { message = if (r.value.optString("status") == "published") "প্রকাশিত।" else "অনুমোদনের অপেক্ষায়।"; reload++ }
                                is ApiResult.Err -> message = r.error.messageBn
                                null -> Unit
                            }
                        }
                    }) { Text(if (status == "draft") "প্রকাশ" else "ফিরিয়ে আনুন") }
                }
            }
            SectionTitle("থিম ফিরিয়ে আনা")
            (0 until themes.length()).map { themes.getJSONObject(it) }.forEach { t ->
                val vs = t.optJSONArray("versions") ?: JSONArray()
                (0 until vs.length()).map { vs.getJSONObject(it) }.filter { it.optString("status") == "superseded" }.forEach { v ->
                    OutlinedButton(enabled = reason.isNotBlank(), onClick = {
                        scope.launch {
                            when (val r = AppContainer.design?.rollbackTheme(t.optString("id"), v.optInt("version"), t.optInt("row_version"), reason, UUID.randomUUID().toString())) {
                                is ApiResult.Ok -> { message = "থিম ${t.optString("code")} v${v.optInt("version")} আবার চালু"; reload++ }
                                is ApiResult.Err -> message = r.error.messageBn
                                null -> Unit
                            }
                        }
                    }) { Text(t.optString("name_bn") + " · v" + v.optInt("version") + " ফিরিয়ে আনুন") }
                }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

/** Responsive preview of one breakpoint: the grid drawn at a device-like width; tap a widget to select it. */
@Composable
fun GridPreview(b: Breakpoint, frameWidth: Dp, selected: String?, onSelect: (String) -> Unit) {
    BoxWithConstraints(Modifier.width(frameWidth).clip(RoundedCornerShape(12.dp)).background(BackgroundGray).padding(6.dp)) {
        val cell = (maxWidth - 6.dp * (b.columns - 1)) / b.columns
        val rowH = 56.dp
        Box(Modifier.width(maxWidth).height((rowH + 6.dp) * b.rows.coerceAtLeast(1))) {
            b.widgets.forEach { w ->
                Box(Modifier.offset(x = (cell + 6.dp) * w.x, y = (rowH + 6.dp) * w.y).size(cell * w.w + 6.dp * (w.w - 1), rowH * w.h + 6.dp * (w.h - 1))
                    .clip(RoundedCornerShape(8.dp)).background(if (w.type == "approval") OrangePrimary.copy(alpha = 0.25f) else androidx.compose.ui.graphics.Color.White)
                    .border(if (w.id == selected) 2.dp else 0.dp, OrangePrimary, RoundedCornerShape(8.dp))
                    .clickable { onSelect(w.id) }.padding(6.dp)) {
                    Text(when (w.type) { "kpi" -> "KPI"; "approval" -> "অনুমোদন"; "ad_slot" -> "বিজ্ঞাপন"; "shortcut" -> "শর্টকাট"; "list" -> "তালিকা"
                        "chart" -> "চার্ট"; "calendar" -> "ক্যালেন্ডার"; else -> "লেখা" } + "\n" + (w.binding ?: w.id), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

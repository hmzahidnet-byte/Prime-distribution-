package com.mohona.erp.feature.iam.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

/** One row of the position picker (api.v1_iam_my_positions). */
data class PositionOption(
    val assignmentId: String,
    val companyId: String,
    val companyCode: String,
    val companyNameBn: String,
    val positionCode: String,
    val positionNameBn: String,
    val rank: Int,
    val isSupreme: Boolean,
    val kind: String,            // regular | acting
    val validFrom: String?,
    val validUntil: String?,
    val usable: Boolean
)

/** The single position this session acts as (api.v1_iam_current_context). Every business RPC uses exactly this. */
data class ActiveContext(
    val personId: String,
    val companyId: String,
    val companyCode: String,
    val companyNameBn: String,
    val membershipId: String,
    val assignmentId: String,
    val positionCode: String,
    val positionNameBn: String,
    val isSupreme: Boolean,
    val homeWingId: String?,
    val homeDepartmentId: String?,
    val authzEpoch: Int
)

/**
 * Active-position session (S06). Selecting/switching/clearing a position always calls [onContextChanged] so the app drops
 * every cached screen of the previous position (no data of position A is ever shown while acting as position B).
 */
class PositionRepository(
    private val client: SupabaseClient,
    private val onContextChanged: () -> Unit = {}
) {
    suspend fun myPositions(): ApiResult<List<PositionOption>> = when (val r = client.rpcArray("v1_iam_my_positions")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseOptions(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_my_positions"))
    }

    suspend fun select(assignmentId: String): ApiResult<ActiveContext> {
        val r = client.rpcObject("v1_iam_select_position", JSONObject().put("p_assignment_id", assignmentId), write = true)
        onContextChanged()
        lastEpoch = (r as? ApiResult.Ok)?.value?.optInt("authz_epoch")
        return when (r) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseContext(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_select_position"))
        }
    }

    @Volatile private var lastEpoch: Int? = null

    /** Also detects server-side authorization changes (authz_epoch moved): cached screens are dropped at once. */
    suspend fun current(): ApiResult<ActiveContext> = when (val r = client.rpcObject("v1_iam_current_context")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseContext(r.value)?.let { c ->
            val prev = lastEpoch
            lastEpoch = c.authzEpoch
            if (prev != null && prev != c.authzEpoch) onContextChanged()
            ApiResult.Ok(c)
        } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_current_context"))
    }

    suspend fun clear(): ApiResult<Unit> {
        val r = client.rpc("v1_iam_clear_position", write = true)
        onContextChanged()
        lastEpoch = null
        return when (r) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(Unit)
        }
    }

    companion object {
        private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k, "").ifBlank { null }

        fun parseOptions(a: JSONArray): List<PositionOption>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                PositionOption(o.getString("assignment_id"), o.getString("company_id"), o.getString("company_code"), o.getString("company_name_bn"),
                    o.getString("position_code"), o.getString("position_name_bn"), o.optInt("rank", 0), o.optBoolean("is_supreme", false),
                    o.optString("kind", "regular"), o.str("valid_from"), o.str("valid_until"), o.optBoolean("usable", false))
            }
        } catch (e: Exception) { null }

        fun parseContext(o: JSONObject): ActiveContext? = try {
            ActiveContext(o.getString("person_id"), o.getString("company_id"), o.optString("company_code", ""), o.optString("company_name_bn", ""),
                o.getString("membership_id"), o.getString("assignment_id"), o.getString("position_code"), o.optString("position_name_bn", ""),
                o.optBoolean("is_supreme", false), o.str("home_wing_id"), o.str("home_department_id"), o.optInt("authz_epoch", 0))
        } catch (e: Exception) { null }

        /** Picker order: usable first, then company, then highest rank. */
        fun pickerOrder(list: List<PositionOption>): List<PositionOption> =
            list.sortedWith(compareByDescending<PositionOption> { it.usable }.thenBy { it.companyCode }.thenByDescending { it.rank })

        /** If exactly one usable position exists, the app may select it automatically after login. */
        fun autoSelectable(list: List<PositionOption>): PositionOption? = list.filter { it.usable }.singleOrNull()
    }
}

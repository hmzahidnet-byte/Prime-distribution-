package com.mohona.erp.feature.design.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import com.mohona.erp.feature.iam.data.MyPermissions
import org.json.JSONArray
import org.json.JSONObject

data class IconBinding(val targetKey: String, val icon: String, val permission: String?, val version: Int = 1)
data class ActiveDesign(val themeCode: String?, val version: Int?, val tokens: JSONObject?, val icons: List<IconBinding>,
                        val layouts: Map<String, ScreenLayout> = emptyMap(), val motion: Motion = Motion(), val ads: Boolean = false,
                        val adMedia: List<Pair<Int, String>> = emptyList(), val adsVisibleMax: Int = 2,
                        val props: JSONObject = JSONObject()) {
    /** Icon for a target, or null when none is bound OR the position lacks the bound permission (F004: no icon implies a right). */
    fun iconFor(targetKey: String, perms: MyPermissions?): String? =
        icons.firstOrNull { it.targetKey == targetKey }?.takeIf { b -> b.permission == null || perms == null || perms.has(b.permission) }?.icon
}
data class ThemeReport(val ok: Boolean, val errors: List<String>, val warnings: List<String>, val contrast: Map<String, Double>)
data class ThemeTemplate(val code: String, val nameBn: String, val tokens: JSONObject, val report: ThemeReport)

/** Design Studio 1 (S18): templates, company themes, validation, publish, active theme and icon bindings. */
class DesignRepository(private val client: SupabaseClient) {
    suspend fun active(): ApiResult<ActiveDesign> = when (val r = client.rpcObject("v1_design_active")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseActive(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_design_active"))
    }
    suspend fun templates(): ApiResult<List<ThemeTemplate>> = when (val r = client.rpcArray("v1_design_templates")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseTemplates(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_design_templates"))
    }
    suspend fun themes(): ApiResult<JSONArray> = client.rpcArray("v1_design_themes")
    suspend fun validate(tokens: JSONObject): ApiResult<ThemeReport> = when (val r = client.rpcObject("v1_design_validate", JSONObject().put("p_tokens", tokens))) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> ApiResult.Ok(parseReport(r.value))
    }
    suspend fun save(code: String, nameBn: String, tokens: JSONObject?, fromTemplate: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_design_save_theme", JSONObject().put("p_code", code).put("p_name_bn", nameBn).put("p_tokens", tokens ?: JSONObject.NULL)
            .put("p_from_template", fromTemplate ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun publish(themeId: String, version: Int, expectedRowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_design_publish", JSONObject().put("p_theme_id", themeId).put("p_version", version)
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun presets(screenKey: String? = null): ApiResult<JSONArray> =
        client.rpcArray("v1_design_presets", JSONObject().put("p_screen_key", screenKey ?: JSONObject.NULL))
    suspend fun validateLayout(layout: JSONObject): ApiResult<ThemeReport> = when (val r = client.rpcObject("v1_design_layout_validate", JSONObject().put("p_layout", layout))) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> ApiResult.Ok(parseReport(r.value))
    }
    suspend fun saveLayout(screenKey: String, layout: JSONObject?, fromPreset: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_design_layout_save", JSONObject().put("p_screen_key", screenKey).put("p_layout", layout ?: JSONObject.NULL)
            .put("p_from_preset", fromPreset ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun layouts(screenKey: String): ApiResult<JSONArray> = client.rpcArray("v1_design_layouts", JSONObject().put("p_screen_key", screenKey))
    /** action = publish (a draft) | rollback (an earlier version). */
    suspend fun publishLayout(screenKey: String, version: Int, action: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_design_layout_publish", JSONObject().put("p_screen_key", screenKey).put("p_version", version).put("p_action", action)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun rollbackTheme(themeId: String, version: Int, expectedRowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_design_theme_rollback", JSONObject().put("p_theme_id", themeId).put("p_version", version)
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun iconCatalog(): ApiResult<JSONArray> = client.rpcArray("v1_design_icon_catalog")
    suspend fun setIcon(targetKey: String, icon: String, permission: String?, expectedVersion: Int, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_design_set_icon", JSONObject().put("p_target_key", targetKey).put("p_icon_name", icon).put("p_permission_code", permission ?: JSONObject.NULL)
            .put("p_expected_version", expectedVersion).put("p_reason", reason), write = true, idempotencyKey = key)

    companion object {
        fun parseReport(o: JSONObject): ThemeReport {
            fun list(a: JSONArray?) = a?.let { (0 until it.length()).map { i -> it.getString(i) } } ?: emptyList()
            val c = o.optJSONObject("contrast")
            return ThemeReport(o.optBoolean("ok", false), list(o.optJSONArray("errors")), list(o.optJSONArray("warnings")),
                c?.keys()?.asSequence()?.associateWith { c.optDouble(it) } ?: emptyMap())
        }

        fun parseActive(o: JSONObject): ActiveDesign? = try {
            val t = o.optJSONObject("theme")
            val a = o.optJSONArray("icons") ?: JSONArray()
            val ls = o.optJSONObject("layouts")
            val m = o.optJSONObject("motion")
            ActiveDesign(t?.optString("code"), t?.optInt("version"), t?.optJSONObject("tokens"),
                (0 until a.length()).map { a.getJSONObject(it).let { x -> IconBinding(x.getString("target_key"), x.getString("icon"),
                    if (x.isNull("permission")) null else x.optString("permission"), x.optInt("version", 1)) } },
                ls?.keys()?.asSequence()?.mapNotNull { k -> LayoutGrid.parse(ls.optJSONObject(k)?.optJSONObject("layout"))?.let { k to it } }?.toMap() ?: emptyMap(),
                if (m == null) Motion() else Motion(m.optInt("duration_ms", 200), m.optString("easing", "standard"), m.optString("reduced", "respect_system")),
                o.optBoolean("ads", false),
                o.optJSONArray("ad_media")?.let { am -> (0 until am.length()).map { am.getJSONObject(it).let { x -> x.getInt("slot") to x.optString("title_bn") } } } ?: emptyList(),
                o.optInt("ads_visible_max", 2),
                o.optJSONObject("props") ?: JSONObject())
        } catch (e: Exception) { null }

        fun parseTemplates(a: JSONArray): List<ThemeTemplate>? = try {
            (0 until a.length()).map { a.getJSONObject(it).let { o -> ThemeTemplate(o.getString("code"), o.getString("name_bn"), o.getJSONObject("tokens"),
                parseReport(o.optJSONObject("report") ?: JSONObject())) } }
        } catch (e: Exception) { null }
    }
}

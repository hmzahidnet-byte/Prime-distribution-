package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.print.DocumentRender
import com.mohona.erp.core.print.EscPos
import com.mohona.erp.core.print.Printers
import com.mohona.erp.feature.print.data.PrintLines
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Print & share (S49): invoice / receipt / stock / ledger / payslip as PDF, image (PNG) or to a registered POS printer.
 * The server authorises every print (rights + registered device), returns the figures and the who/when watermark and logs it.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PrintScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var docType by remember { mutableStateOf("sales.invoice") }
    var docRef by remember { mutableStateOf("") }
    var deviceId by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    val types = listOf("sales.invoice" to "ইনভয়েস", "sales.receipt" to "রসিদ", "inventory.stock" to "মজুদ", "finance.ledger" to "রেওয়ামিল", "hr.payslip" to "পে-স্লিপ")

    fun run(format: String) {
        scope.launch {
            val repo = AppContainer.print ?: run { message = "সংযুক্ত মোড নয়।"; return@launch }
            when (val r = repo.authorize(docType, docRef.trim(), format, deviceId.trim().ifBlank { null })) {
                is ApiResult.Err -> message = r.error.messageBn
                is ApiResult.Ok -> {
                    val (title, lines) = PrintLines.of(docType, r.value.opt("data"))
                    val mark = r.value.optString("watermark")
                    // invoices print in the design they were issued with (50 designs); other documents use the plain layout
                    val design = if (docType == "sales.invoice" && (format == "pdf" || format == "image")) (repo.invoiceDesign(docRef.trim()) as? ApiResult.Ok)?.value?.optJSONObject("spec") else null
                    val outcome = withContext(Dispatchers.IO) {
                        runCatching {
                            when (format) {
                                "pdf" -> {
                                    val data = r.value.optJSONObject("data")
                                    val file = if (design != null && data != null) DocumentRender.invoicePdf(context, design, data, mark, "prime-invoice.pdf")
                                               else DocumentRender.pdf(context, title, lines, mark, "prime-document.pdf")
                                    DocumentRender.share(context, file, "application/pdf")
                                }
                                "image" -> {
                                    val data = r.value.optJSONObject("data")
                                    val file = if (design != null && data != null) DocumentRender.invoiceImage(context, design, data, mark, "prime-invoice.png")
                                               else DocumentRender.image(context, title, lines, mark, "prime-card.png")
                                    DocumentRender.share(context, file, "image/png")
                                }
                                else -> {
                                    val pos = EscPos().center(true).bold(true).line(title).bold(false).center(false).rule()
                                    lines.forEach { pos.line(it) }
                                    val bytes = pos.rule().line(mark).feedAndCut()
                                    val sent = when (format) {
                                        "pos_bt" -> Printers.bluetooth(context, address.trim(), bytes)
                                        "pos_usb" -> Printers.usb(context, address.trim(), bytes)
                                        else -> Printers.network(address.trim(), false, bytes)
                                    }
                                    sent.getOrThrow()
                                }
                            }
                        }
                    }
                    message = outcome.fold({ "সম্পন্ন — প্রিন্ট/শেয়ার লগে লেখা হয়েছে।" }, { it.message ?: "প্রিন্ট করা যায়নি।" })
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("প্রিন্ট ও শেয়ার", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                types.forEach { (k, l) -> FilterChip(selected = docType == k, onClick = { docType = k }, label = { Text(l) }) }
            }
            OutlinedTextField(value = docRef, onValueChange = { docRef = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text(when (docType) { "sales.invoice" -> "ইনভয়েস নম্বর"; "sales.receipt" -> "রসিদ নম্বর"; "hr.payslip" -> "পে-রান আইডি"; else -> "ফাঁকা রাখুন (ঐচ্ছিক গুদাম-আইডি)" }) })
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { run("pdf") }) { Text("PDF শেয়ার") }
                OutlinedButton(onClick = { run("image") }) { Text("ছবি (WhatsApp)") }
            }
            Text("POS প্রিন্টার (শুধু নিবন্ধিত ডিভাইস)", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(value = deviceId, onValueChange = { deviceId = it }, label = { Text("নিবন্ধিত ডিভাইস-আইডি") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("ঠিকানা: ব্লুটুথ MAC / USB vvvv:pppp / IP:পোর্ট") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(enabled = deviceId.isNotBlank() && address.isNotBlank(), onClick = { run("pos_bt") }) { Text("ব্লুটুথ") }
                OutlinedButton(enabled = deviceId.isNotBlank() && address.isNotBlank(), onClick = { run("pos_usb") }) { Text("USB") }
                OutlinedButton(enabled = deviceId.isNotBlank() && address.isNotBlank(), onClick = { run("network") }) { Text("নেটওয়ার্ক") }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

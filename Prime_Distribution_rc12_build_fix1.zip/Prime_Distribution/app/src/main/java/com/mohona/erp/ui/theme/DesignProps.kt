package com.mohona.erp.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import org.json.JSONObject

/**
 * Chairman micro-design (S71): effective component properties for this user (company < wing < position), from api.v1_design_active.
 * Keys are "component.property" (e.g. "payment.status.tick.color"). Every read has a safe default, and properties only change LOOKS:
 * whether a payment tick appears is decided by the server's verified + posted state, never here.
 */
object DesignProps {
    private var props by mutableStateOf(JSONObject())

    fun apply(p: JSONObject?) { props = p ?: JSONObject() }
    fun reset() { props = JSONObject() }

    private fun raw(component: String, property: String): Any? = props.opt("$component.$property")?.takeIf { it != JSONObject.NULL }

    fun color(component: String, property: String = "color", default: Color): Color =
        (raw(component, property) as? String)?.let { s -> runCatching { Color(android.graphics.Color.parseColor(s)) }.getOrNull() } ?: default
    fun dp(component: String, property: String, default: Dp): Dp = (raw(component, property) as? Number)?.toFloat()?.dp ?: default
    fun scale(component: String, default: Float = 1f): Float = (raw(component, "text_scale") as? Number)?.toFloat()?.coerceIn(0.85f, 1.30f) ?: default
    fun text(component: String, property: String, default: String): String = (raw(component, property) as? String)?.takeIf { it.isNotBlank() } ?: default
    fun icon(component: String, default: String): String = (raw(component, "icon") as? String) ?: default
    /** A component may be hidden by design, never shown beyond what the server already allows. */
    fun visible(component: String): Boolean = (raw(component, "visible") as? Boolean) ?: true
    fun animated(component: String, reducedMotion: Boolean): Boolean = !reducedMotion && (raw(component, "animation") as? String ?: "subtle") != "none"
}

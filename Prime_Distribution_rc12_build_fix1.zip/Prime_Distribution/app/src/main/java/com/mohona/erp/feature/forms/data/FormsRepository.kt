package com.mohona.erp.feature.forms.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

data class FormSummary(val id: String, val code: String, val nameBn: String, val status: String, val activeVersion: Int?, val rowVersion: Int)
data class SaveResult(val submissionId: String, val status: String, val rowVersion: Int, val formVersion: Int, val conflict: Boolean = false)
data class SubmitResult(val submissionId: String, val status: String, val number: String?, val requestId: String?)
data class UploadTicket(val attachmentId: String, val bucket: String, val path: String, val expiresIn: Int)

/**
 * Dynamic Forms API (S14). Every write carries an Idempotency-Key; values are run through [FormEngine.writable] so masked
 * placeholders are never sent back. Server errors E_FORM_VALIDATION carry field errors: [FormEngine.parseErrors].
 */
class FormsRepository(private val client: SupabaseClient) {
    suspend fun list(includeArchived: Boolean = false): ApiResult<List<FormSummary>> =
        when (val r = client.rpcArray("v1_forms_list", JSONObject().put("p_include_archived", includeArchived))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseList(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_forms_list"))
        }

    suspend fun definition(formId: String, version: Int? = null): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_definition", JSONObject().put("p_form_id", formId).put("p_version", version ?: JSONObject.NULL))

    suspend fun saveVersion(code: String, nameBn: String, wingId: String?, definition: JSONObject, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_save_version", JSONObject().put("p_code", code).put("p_name_bn", nameBn).put("p_wing_id", wingId ?: JSONObject.NULL)
            .put("p_definition", definition).put("p_reason", reason), write = true, idempotencyKey = key)

    suspend fun preview(formId: String, version: Int?, values: JSONObject): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_preview", JSONObject().put("p_form_id", formId).put("p_version", version ?: JSONObject.NULL).put("p_values", values))

    suspend fun action(formId: String, action: String, version: Int?, expectedRowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_action", JSONObject().put("p_form_id", formId).put("p_action", action).put("p_version", version ?: JSONObject.NULL)
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)

    suspend fun setFieldAccess(formId: String, fieldKey: String, positionCode: String?, access: String, expectedVersion: Int, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_forms_set_field_access", JSONObject().put("p_form_id", formId).put("p_field_key", fieldKey)
            .put("p_position_code", positionCode ?: JSONObject.NULL).put("p_access", access).put("p_expected_version", expectedVersion).put("p_reason", reason),
            write = true, idempotencyKey = key)

    suspend fun fieldAccess(formId: String): ApiResult<JSONArray> = client.rpcArray("v1_forms_field_access", JSONObject().put("p_form_id", formId))

    /** New draft (submissionId null) or edit. [definition] is the client definition (fields carry their access). */
    suspend fun save(formId: String, submissionId: String?, definition: JSONObject, values: JSONObject, wingId: String?, expectedRowVersion: Int?,
                     reason: String?, key: String): ApiResult<SaveResult> =
        when (val r = client.rpcObject("v1_forms_submission_save", JSONObject().put("p_form_id", formId).put("p_submission_id", submissionId ?: JSONObject.NULL)
            .put("p_values", FormEngine.writable(definition, values)).put("p_wing_id", wingId ?: JSONObject.NULL)
            .put("p_expected_row_version", expectedRowVersion ?: JSONObject.NULL).put("p_reason", reason ?: JSONObject.NULL), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseSave(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_forms_submission_save"))
        }

    suspend fun submit(submissionId: String, expectedRowVersion: Int, key: String): ApiResult<SubmitResult> =
        when (val r = client.rpcObject("v1_forms_submission_submit", JSONObject().put("p_submission_id", submissionId)
            .put("p_expected_row_version", expectedRowVersion), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(parseSubmit(r.value))
        }

    /** Pushes one encrypted local draft (decrypted in memory only for this call). Never submits. */
    suspend fun syncDraft(d: OfflineDraft, definition: JSONObject, key: String): ApiResult<SaveResult> =
        when (val r = client.rpcObject("v1_forms_draft_sync", JSONObject().put("p_form_id", d.formId).put("p_client_draft_id", d.clientDraftId)
            .put("p_form_version", d.formVersion).put("p_values", FormEngine.writable(definition, d.values)).put("p_wing_id", d.wingId ?: JSONObject.NULL)
            .put("p_client_saved_at", java.time.Instant.ofEpochMilli(d.savedAtMs).toString()), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseSave(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_forms_draft_sync"))
        }

    suspend fun get(submissionId: String): ApiResult<JSONObject> = client.rpcObject("v1_forms_submission_get", JSONObject().put("p_submission_id", submissionId))

    suspend fun submissions(formId: String, status: String? = null, limit: Int = 50): ApiResult<JSONArray> =
        client.rpcArray("v1_forms_submissions", JSONObject().put("p_form_id", formId).put("p_status", status ?: JSONObject.NULL).put("p_limit", limit))

    suspend fun history(submissionId: String): ApiResult<JSONArray> = client.rpcArray("v1_forms_submission_history", JSONObject().put("p_submission_id", submissionId))

    suspend fun submissionAction(submissionId: String, action: String, expectedRowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_submission_action", JSONObject().put("p_submission_id", submissionId).put("p_action", action)
            .put("p_expected_row_version", expectedRowVersion).put("p_reason", reason), write = true, idempotencyKey = key)

    suspend fun export(formId: String, limit: Int = 200): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_export", JSONObject().put("p_form_id", formId).put("p_limit", limit))

    suspend fun attachmentBegin(formId: String, fieldKey: String, mimeType: String, sizeBytes: Long, sha256Hex: String, key: String): ApiResult<UploadTicket> =
        when (val r = client.rpcObject("v1_forms_attachment_begin", JSONObject().put("p_form_id", formId).put("p_field_key", fieldKey).put("p_mime_type", mimeType)
            .put("p_size_bytes", sizeBytes).put("p_sha256", sha256Hex), write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseTicket(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_forms_attachment_begin"))
        }

    suspend fun attachmentConfirm(attachmentId: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_forms_attachment_confirm", JSONObject().put("p_attachment_id", attachmentId), write = true, idempotencyKey = key)

    /** Grant for a storage signed URL of exactly this object (the app then asks Storage for the short-lived URL). */
    suspend fun attachmentAccess(attachmentId: String): ApiResult<UploadTicket> =
        when (val r = client.rpcObject("v1_forms_attachment_access", JSONObject().put("p_attachment_id", attachmentId), write = true)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseTicket(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_forms_attachment_access"))
        }

    suspend fun maskPolicies(prefix: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_mask_policies", JSONObject().put("p_prefix", prefix ?: JSONObject.NULL))

    suspend fun setMaskPolicy(fieldKey: String, positionCode: String?, mode: String, expectedVersion: Int, reason: String, key: String): ApiResult<Any> =
        client.rpc("v1_mask_set_policy", JSONObject().put("p_field_key", fieldKey).put("p_position_code", positionCode ?: JSONObject.NULL).put("p_mode", mode)
            .put("p_expected_version", expectedVersion).put("p_reason", reason), write = true, idempotencyKey = key)

    companion object {
        fun parseList(a: JSONArray): List<FormSummary>? = try {
            (0 until a.length()).map { i -> a.getJSONObject(i).let { o ->
                FormSummary(o.getString("id"), o.getString("code"), o.getString("name_bn"), o.getString("status"),
                    if (o.isNull("active_version")) null else o.getInt("active_version"), o.getInt("row_version")) } }
        } catch (e: Exception) { null }

        fun parseSave(o: JSONObject): SaveResult? = try {
            SaveResult(o.getString("submission_id"), o.getString("status"), o.getInt("row_version"), o.getInt("form_version"), o.optBoolean("conflict", false))
        } catch (e: Exception) { null }

        fun parseSubmit(o: JSONObject) = SubmitResult(o.optString("submission_id"), o.optString("status"),
            if (o.isNull("number")) null else o.optString("number"), if (o.isNull("request_id")) null else o.optString("request_id"))

        fun parseTicket(o: JSONObject): UploadTicket? = try {
            val path = o.getString("path")
            UploadTicket(o.getString("attachment_id"), o.getString("bucket"), path, o.getInt("expires_in")).takeIf { !path.contains("..") && !path.startsWith("/") }
        } catch (e: Exception) { null }
    }
}

package com.mohona.erp.ui.theme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The app side of design.icon_catalog (S18): every catalog name maps to a bundled Material icon. Unknown names (a newer
 * server catalog) fall back to a neutral icon — nothing is ever downloaded or executed.
 */
object IconRegistry {
    val NAMES = listOf("Home", "Search", "Assessment", "BarChart", "PieChart", "Checklist", "TaskAlt", "Description", "Receipt", "Inventory",
        "Factory", "LocalShipping", "ShoppingCart", "Storefront", "Payments", "AccountBalance", "AccountBalanceWallet", "People", "Person", "Badge",
        "Schedule", "QrCodeScanner", "QrCode", "Settings", "Palette", "Security", "Lock", "Verified", "Warning", "Error", "Info", "CheckCircle",
        "Cancel", "Pending", "Notifications", "Science", "Build", "Edit", "Delete", "Add", "Send", "Print", "Share", "Download", "Approval", "Undo")

    fun vector(name: String?): ImageVector = when (name) {
        "Home" -> Icons.Filled.Home; "Search" -> Icons.Filled.Search; "Assessment" -> Icons.Filled.Assessment
        "BarChart" -> Icons.Filled.BarChart; "PieChart" -> Icons.Filled.PieChart; "Checklist" -> Icons.Filled.Checklist
        "TaskAlt" -> Icons.Filled.TaskAlt; "Description" -> Icons.Filled.Description; "Receipt" -> Icons.Filled.Receipt
        "Inventory" -> Icons.Filled.Inventory; "Factory" -> Icons.Filled.Factory; "LocalShipping" -> Icons.Filled.LocalShipping
        "ShoppingCart" -> Icons.Filled.ShoppingCart; "Storefront" -> Icons.Filled.Storefront; "Payments" -> Icons.Filled.Payments
        "AccountBalance" -> Icons.Filled.AccountBalance; "AccountBalanceWallet" -> Icons.Filled.AccountBalanceWallet
        "People" -> Icons.Filled.People; "Person" -> Icons.Filled.Person; "Badge" -> Icons.Filled.Badge; "Schedule" -> Icons.Filled.Schedule
        "QrCodeScanner" -> Icons.Filled.QrCodeScanner; "QrCode" -> Icons.Filled.QrCode; "Settings" -> Icons.Filled.Settings
        "Palette" -> Icons.Filled.Palette; "Security" -> Icons.Filled.Security; "Lock" -> Icons.Filled.Lock; "Verified" -> Icons.Filled.Verified
        "Warning" -> Icons.Filled.Warning; "Error" -> Icons.Filled.Error; "Info" -> Icons.Filled.Info; "CheckCircle" -> Icons.Filled.CheckCircle
        "Cancel" -> Icons.Filled.Cancel; "Pending" -> Icons.Filled.Pending; "Notifications" -> Icons.Filled.Notifications
        "Science" -> Icons.Filled.Science; "Build" -> Icons.Filled.Build; "Edit" -> Icons.Filled.Edit; "Delete" -> Icons.Filled.Delete
        "Add" -> Icons.Filled.Add; "Send" -> Icons.Filled.Send; "Print" -> Icons.Filled.Print; "Share" -> Icons.Filled.Share
        "Download" -> Icons.Filled.Download; "Approval" -> Icons.Filled.Approval; "Undo" -> Icons.Filled.Undo
        else -> Icons.Filled.Circle
    }
}

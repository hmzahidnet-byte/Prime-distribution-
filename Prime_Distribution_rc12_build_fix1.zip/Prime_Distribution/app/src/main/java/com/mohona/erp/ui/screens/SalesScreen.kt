package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import androidx.compose.foundation.layout.Arrangement
import com.mohona.erp.feature.actions.LookupField
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.sales.data.CollectionRules
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.TextMuted
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray

/** Sales & collection (S41–S43): record a collection (pending until verified), check a receipt QR, weekly figures. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SalesScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var dealerId by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("cash") }
    var amount by remember { mutableStateOf("") }
    var ref by remember { mutableStateOf("") }
    var receiptVerified by remember { mutableStateOf<Boolean?>(null) }
    var qr by remember { mutableStateOf("") }
    var weekly by remember { mutableStateOf(JSONArray()) }
    var message by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("বিক্রয় ও কালেকশন", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("কালেকশন লিখুন (যাচাইয়ের আগে বকেয়া কমে না)", style = MaterialTheme.typography.titleSmall)
            LookupField("ডিলার", "dealer", false, dealerId) { dealerId = it.trim() }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("cash" to "নগদ", "bank" to "ব্যাংক", "bkash" to "bKash", "nagad" to "Nagad").forEach { (k, l) -> FilterChip(selected = method == k, onClick = { method = k }, label = { Text(l) }) }
            }
            OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("টাকা") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            if (method != "cash") OutlinedTextField(value = ref, onValueChange = { ref = it.trim() }, label = { Text("লেনদেন-রেফারেন্স") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = {
                val a = amount.toBigDecimalOrNull()
                val p = if (a == null) "amount" else CollectionRules.problem(a, method, ref.ifBlank { null }, emptyList())
                if (p != null || dealerId.length != 36) { message = "তথ্য ঠিক নয়: " + (p ?: "dealer"); return@OutlinedButton }
                scope.launch {
                    when (val r = AppContainer.sales?.recordCollection(dealerId, method, a!!, ref.ifBlank { null }, JSONArray(), UUID.randomUUID().toString())) {
                        is ApiResult.Ok -> message = "রেকর্ড ${r.value.optString("number")} — যাচাইয়ের অপেক্ষায়। রসিদ-QR: ${r.value.optString("receipt_qr")}"
                        is ApiResult.Err -> message = r.error.messageBn
                        null -> Unit
                    }
                }
            }) { Text("কালেকশন রেকর্ড") }
            OutlinedTextField(value = qr, onValueChange = { qr = it.trim() }, label = { Text("রসিদ-QR যাচাই") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(enabled = qr.startsWith("MOS1|R|"), onClick = { scope.launch {
                when (val r = AppContainer.sales?.receiptLookup(qr)) {
                    is ApiResult.Ok -> { receiptVerified = r.value.optBoolean("verified"); message = "${r.value.optString("number")} · ${Bn.money(r.value.optString("amount"))} · " + if (r.value.optBoolean("verified")) "যাচাইকৃত" else "এখনো যাচাই হয়নি" }
                    is ApiResult.Err -> message = r.error.messageBn
                    null -> Unit
                } } }) { Text("রসিদ দেখুন") }
            // tick only for a verified (= posted) receipt; colour / icon / label come from the Chairman's micro-design
            receiptVerified?.let { com.mohona.erp.ui.components.PaymentStatusMark(verified = it, posted = it) }
            OutlinedButton(onClick = { scope.launch { when (val r = AppContainer.sales?.weekly(null, null)) { is ApiResult.Ok -> weekly = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) {
                Text("সাপ্তাহিক বিক্রয়")
            }
            (0 until weekly.length()).map { weekly.getJSONObject(it) }.forEach { w ->
                Text("${w.optString("week")} · ${w.optString("dealer")} · ${w.optString("territory")} · ${Bn.money(w.optString("amount"))}", style = MaterialTheme.typography.labelSmall)
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

package com.mohona.erp.feature.ops.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.time.Duration
import java.time.Instant
import org.json.JSONArray
import org.json.JSONObject

/** Devices, location, backup status, governance (S50–S55). */
class OpsRepository(private val client: SupabaseClient) {
    suspend fun registerDevice(code: String, kind: String, fingerprintSha256: String, address: String?, tls: Boolean, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_device_register", JSONObject().put("p_code", code).put("p_kind", kind).put("p_fingerprint", fingerprintSha256)
            .put("p_address", address ?: JSONObject.NULL).put("p_tls", tls).put("p_reason", reason), write = true)
    suspend fun revokeDevice(id: String, reason: String): ApiResult<JSONObject> =
        client.rpcObject("v1_device_revoke", JSONObject().put("p_device_id", id).put("p_reason", reason), write = true)
    suspend fun deviceHealth(id: String, batteryPct: Int?, online: Boolean, storageFreeMb: Int?): ApiResult<JSONObject> =
        client.rpcObject("v1_device_health", JSONObject().put("p_device_id", id).put("p_battery", batteryPct ?: JSONObject.NULL).put("p_online", online)
            .put("p_storage_free_mb", storageFreeMb ?: JSONObject.NULL), write = true)
    suspend fun ping(lat: Double, lon: Double, accuracyM: Float?, recordedAtIso: String): ApiResult<JSONObject> =
        client.rpcObject("v1_location_ping", JSONObject().put("p_latitude", lat).put("p_longitude", lon).put("p_accuracy_m", accuracyM?.toDouble() ?: JSONObject.NULL)
            .put("p_recorded_at", recordedAtIso).put("p_background", false), write = true)
    suspend fun liveMarkers(): ApiResult<JSONArray> = client.rpcArray("v1_live_markers")
    suspend fun dealerPins(): ApiResult<JSONArray> = client.rpcArray("v1_dealer_pins")
    suspend fun navigation(routePlanId: String): ApiResult<JSONObject> = client.rpcObject("v1_route_navigation", JSONObject().put("p_route_plan_id", routePlanId))
    suspend fun opsStatus(): ApiResult<JSONObject> = client.rpcObject("v1_ops_status")
    suspend fun governance(): ApiResult<JSONObject> = client.rpcObject("v1_governance_check")
    suspend fun registry(status: String? = null): ApiResult<JSONObject> = client.rpcObject("v1_requirement_registry", JSONObject().put("p_status", status ?: JSONObject.NULL))
}

object LocationAge {
    /** "৫ মিনিট আগে" style label; anything older than the stale limit is called old (never shown as live — F235, F239). */
    fun label(recordedAtIso: String, now: Instant, staleMinutes: Long): String {
        val at = runCatching { Instant.parse(recordedAtIso) }.getOrNull() ?: return "সময় অজানা"
        val min = Duration.between(at, now).toMinutes().coerceAtLeast(0)
        val text = if (min < 60) "$min মিনিট আগে" else "${min / 60} ঘণ্টা আগে"
        return if (min > staleMinutes) "পুরোনো · $text" else text
    }
}

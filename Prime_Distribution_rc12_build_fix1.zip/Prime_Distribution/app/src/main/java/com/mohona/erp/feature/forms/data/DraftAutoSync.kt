package com.mohona.erp.feature.forms.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext

/**
 * OI-29: offline drafts go to the server by themselves — once right after login and every time the phone gets a network
 * back while the app is open. Drafts are only synced, never submitted (submitting stays a person's decision, online).
 * No background job outside the app: the session keys live only while the app runs, so nothing is sent without a session.
 */
object DraftAutoSync {
    @Volatile private var lastRunMs = 0L
    private const val MIN_GAP_MS = 60_000L

    /** True when enough time has passed since the last automatic run (several network callbacks in a row = one sync). */
    @Synchronized fun shouldRun(nowMs: Long): Boolean {
        if (nowMs - lastRunMs < MIN_GAP_MS) return false
        lastRunMs = nowMs
        return true
    }
}

/** Put once in the logged-in shell. [active] = connected mode with a real (not preview) profile; [sync] starts DraftSyncer. */
@Composable
fun DraftAutoSyncEffect(active: Boolean, sync: () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(active) {
        if (active && DraftAutoSync.shouldRun(System.currentTimeMillis())) sync()
    }
    DisposableEffect(active) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (active && DraftAutoSync.shouldRun(System.currentTimeMillis())) sync()
            }
        }
        val registered = active && cm != null && runCatching { cm.registerDefaultNetworkCallback(cb) }.isSuccess
        onDispose { if (registered) runCatching { cm?.unregisterNetworkCallback(cb) } }
    }
}

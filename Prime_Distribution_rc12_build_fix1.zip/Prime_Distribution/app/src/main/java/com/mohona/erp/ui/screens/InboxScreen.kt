package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.feature.notify.data.Notice
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.launch

/** Connected inbox (S22): tap = read; approval items open the approval list. */
@Composable
fun InboxScreen(onBack: () -> Unit, onApprovals: () -> Unit) {
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Notice>>(emptyList()) }
    var reload by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(reload) {
        when (val r = AppContainer.notify?.inbox()) { is ApiResult.Ok -> items = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("নোটিফিকেশন", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (items.isEmpty()) EmptyState(message ?: "কোনো নোটিফিকেশন নেই।")
            items.forEach { n ->
                AppCard(onClick = {
                    scope.launch { AppContainer.notify?.mark(listOf(n.id), "read"); reload++ }
                    if (n.linkKind == "approval_request") onApprovals()
                }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(n.titleBn, fontWeight = if (n.read) FontWeight.Normal else FontWeight.Bold, color = if (n.priority == "critical") BadRed else Color.Unspecified)
                        Text(n.bodyBn, style = MaterialTheme.typography.bodySmall)
                        Text(n.createdAt.take(16).replace('T', ' '), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }
        }
    }
}

/** Critical unread items (F215) shown above every screen; generic text only. */
@Composable
fun CriticalBanner(items: List<Notice>, onOpen: () -> Unit) {
    if (items.isEmpty()) return
    AppCard(onClick = onOpen) {
        Column(Modifier.fillMaxWidth().background(BadRed.copy(alpha = 0.12f)).padding(10.dp)) {
            Text(items.first().titleBn, color = BadRed, fontWeight = FontWeight.Bold)
            Text(items.first().bodyBn + if (items.size > 1) " (+${items.size - 1})" else "", style = MaterialTheme.typography.labelSmall)
        }
    }
}

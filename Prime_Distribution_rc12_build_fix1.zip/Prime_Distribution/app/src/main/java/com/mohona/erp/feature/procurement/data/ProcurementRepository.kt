package com.mohona.erp.feature.procurement.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.math.RoundingMode
import org.json.JSONArray
import org.json.JSONObject

/** Procurement & payables (S26–S28). Every write carries an idempotency key; approvals run on the server engine. */
class ProcurementRepository(private val client: SupabaseClient) {
    suspend fun suppliers(text: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_suppliers", JSONObject().put("p_text", text ?: JSONObject.NULL))
    suspend fun saveSupplier(id: String?, code: String?, nameBn: String, phone: String?, taxId: String?, termsDays: Int?, rowVersion: Int?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_supplier_save", JSONObject().put("p_id", id ?: JSONObject.NULL).put("p_code", code ?: JSONObject.NULL).put("p_name_bn", nameBn)
            .put("p_name_en", JSONObject.NULL).put("p_phone", phone ?: JSONObject.NULL).put("p_email", JSONObject.NULL).put("p_address_bn", JSONObject.NULL)
            .put("p_admin_area_code", JSONObject.NULL).put("p_tax_id", taxId ?: JSONObject.NULL).put("p_terms_days", termsDays ?: JSONObject.NULL)
            .put("p_credit_limit", JSONObject.NULL).put("p_bank_masked", JSONObject.NULL).put("p_status", JSONObject.NULL)
            .put("p_expected_row_version", rowVersion ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun pos(status: String? = null): ApiResult<JSONArray> = client.rpcArray("v1_pos", JSONObject().put("p_status", status ?: JSONObject.NULL).put("p_supplier_id", JSONObject.NULL))
    suspend fun po(id: String): ApiResult<JSONObject> = client.rpcObject("v1_po_get", JSONObject().put("p_po_id", id))
    suspend fun poAction(id: String, action: String, rowVersion: Int, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_po_action", JSONObject().put("p_po_id", id).put("p_action", action).put("p_expected_row_version", rowVersion).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun grn(poId: String, deliveryNote: String?, lines: JSONArray, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_grn_post", JSONObject().put("p_po_id", poId).put("p_delivery_note", deliveryNote ?: JSONObject.NULL).put("p_lines", lines).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun bill(supplierId: String, invoiceNo: String, invoiceDate: String, lines: JSONArray, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_bill_create", JSONObject().put("p_supplier_id", supplierId).put("p_invoice_no", invoiceNo).put("p_invoice_date", invoiceDate).put("p_lines", lines)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun pay(supplierId: String, method: String, reference: String?, allocations: JSONArray, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_supplier_payment", JSONObject().put("p_supplier_id", supplierId).put("p_method", method).put("p_reference", reference ?: JSONObject.NULL)
            .put("p_allocations", allocations).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun dues(): ApiResult<JSONArray> = client.rpcArray("v1_supplier_dues", JSONObject().put("p_as_of", JSONObject.NULL))
    suspend fun performance(): ApiResult<JSONArray> = client.rpcArray("v1_supplier_performance", JSONObject().put("p_from", JSONObject.NULL).put("p_to", JSONObject.NULL))
    suspend fun grni(): ApiResult<JSONArray> = client.rpcArray("v1_grni", JSONObject().put("p_supplier_id", JSONObject.NULL))
}

/** Client previews of the server rules (three-way match tolerance, receipt split, aging buckets). */
object ProcurementMath {
    data class Variance(val kind: String, val billed: BigDecimal, val expected: BigDecimal)

    /** Mirror of api.v1_bill_create's check. tolerance in basis points (100 = 1%). */
    fun matchLine(billQty: BigDecimal, billPrice: BigDecimal, receivable: BigDecimal, poPrice: BigDecimal, priceTolBp: Int, qtyTolBp: Int): List<Variance> {
        val out = ArrayList<Variance>()
        val qtyLimit = receivable.multiply(BigDecimal.ONE + BigDecimal(qtyTolBp).divide(BigDecimal(10000)))
        if (billQty > qtyLimit) out += Variance("quantity", billQty, receivable)
        val priceTol = poPrice.multiply(BigDecimal(priceTolBp)).divide(BigDecimal(10000), 6, RoundingMode.HALF_UP)
        if ((billPrice - poPrice).abs() > priceTol) out += Variance("price", billPrice, poPrice)
        return out
    }

    /** received must equal accepted + quarantine + rejected (server rule). */
    fun splitOk(received: BigDecimal, accepted: BigDecimal, quarantine: BigDecimal, rejected: BigDecimal) = received.signum() > 0 && received.compareTo(accepted + quarantine + rejected) == 0

    fun agingBucket(daysOverdue: Int): String = when {
        daysOverdue <= 0 -> "current"; daysOverdue <= 30 -> "d1_30"; daysOverdue <= 60 -> "d31_60"; daysOverdue <= 90 -> "d61_90"; else -> "d90_plus"
    }
}

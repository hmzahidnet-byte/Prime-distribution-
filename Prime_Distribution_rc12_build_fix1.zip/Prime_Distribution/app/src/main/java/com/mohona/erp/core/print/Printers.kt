package com.mohona.erp.core.print

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import java.net.InetSocketAddress
import java.net.Socket
import java.util.UUID
import javax.net.ssl.SSLSocketFactory

/**
 * POS printer transports (S49, S51). The server has already checked that the device is REGISTERED for this company and
 * allowed for this position; these functions only talk to that one address. Nothing runs in the background, and a
 * missing / disconnected printer is an ordinary failure with a Bengali message — never assumed connected.
 */
object Printers {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun bluetooth(context: Context, mac: String, data: ByteArray): Result<Unit> = runCatching {
        if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            error("ব্লুটুথ-অনুমতি দিন")
        }
        val adapter = (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: error("এই ফোনে ব্লুটুথ নেই")
        if (!adapter.isEnabled) error("ব্লুটুথ চালু করুন")
        val device = adapter.bondedDevices.firstOrNull { it.address.equals(mac, ignoreCase = true) } ?: error("প্রিন্টারটি এই ফোনে পেয়ার করা নেই")
        val socket = device.createRfcommSocketToServiceRecord(SPP)
        try {
            socket.connect()
            socket.outputStream.write(data)
            socket.outputStream.flush()
        } finally {
            runCatching { socket.close() }
        }
    }

    /** address = "ip:port" exactly as registered; TLS only when the registration says so. */
    fun network(address: String, tls: Boolean, data: ByteArray): Result<Unit> = runCatching {
        val host = address.substringBefore(':')
        val port = address.substringAfter(':').toInt()
        val socket: Socket = if (tls) SSLSocketFactory.getDefault().createSocket() else Socket()
        try {
            socket.connect(InetSocketAddress(host, port), 5000)
            socket.soTimeout = 5000
            socket.getOutputStream().write(data)
            socket.getOutputStream().flush()
        } finally {
            runCatching { socket.close() }
        }
    }

    /** address = "vendorId:productId" in hex as registered (e.g. "04b8:0202"). */
    fun usb(context: Context, address: String, data: ByteArray): Result<Unit> = runCatching {
        val manager = context.getSystemService(Context.USB_SERVICE) as UsbManager
        val vendor = address.substringBefore(':').toInt(16)
        val product = address.substringAfter(':').toInt(16)
        val device = manager.deviceList.values.firstOrNull { it.vendorId == vendor && it.productId == product } ?: error("USB প্রিন্টার সংযুক্ত নেই")
        if (!manager.hasPermission(device)) {
            val pi = PendingIntent.getBroadcast(context, 0, Intent("com.mohona.erp.USB_PERMISSION").setPackage(context.packageName), PendingIntent.FLAG_IMMUTABLE)
            manager.requestPermission(device, pi)
            error("USB-অনুমতি দিন, তারপর আবার প্রিন্ট করুন")
        }
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            for (e in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK && ep.direction == UsbConstants.USB_DIR_OUT) {
                    val conn = manager.openDevice(device) ?: error("USB প্রিন্টার খোলা যায়নি")
                    try {
                        if (!conn.claimInterface(intf, true)) error("USB প্রিন্টার ব্যস্ত")
                        val sent = conn.bulkTransfer(ep, data, data.size, 5000)
                        if (sent < 0) error("USB প্রিন্টারে পাঠানো যায়নি")
                        conn.releaseInterface(intf)
                    } finally {
                        conn.close()
                    }
                    return@runCatching
                }
            }
        }
        error("USB প্রিন্টারে লেখার পথ পাওয়া যায়নি")
    }
}

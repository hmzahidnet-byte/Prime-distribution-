package com.mohona.erp.ui.theme.tokens

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Design tokens = every visual decision the Chairman can customise (OWN-01). Pure Kotlin (ARGB longs), so they are
 * parsed, validated and unit-tested without Android. The Theme-Studio (S21) publishes them per company; the app
 * applies them through [ThemeRuntime]. Light theme only.
 */
data class ColorTokens(
    val primary: Long = 0xFF1456A0,       // locked blueprint default (setting ui.theme.primary); Chairman can change
    val primaryDark: Long = 0xFF0E3F78,
    val primarySoft: Long = 0xFFE8F0FA,
    val onPrimary: Long = 0xFFFFFFFF,
    val background: Long = 0xFFFFFFFF,
    val surfaceAlt: Long = 0xFFF4F5F7,
    val text: Long = 0xFF1F2430,
    val textMuted: Long = 0xFF5F6673,
    val divider: Long = 0xFFE5E7EB,
    val good: Long = 0xFF2E9E5B,
    val warn: Long = 0xFFE8A317,
    val bad: Long = 0xFFD64545,
    val info: Long = 0xFF3B82F6,
    val chart: List<Long> = listOf(0xFF1456A0, 0xFFF85606, 0xFF14B8A6, 0xFFE8A317, 0xFF7E22CE, 0xFF2E9E5B, 0xFFD64545, 0xFF0F766E),
    /** Per-position accent (S18): header/badge colour for a position code, white text on it. */
    val roleAccent: Map<String, Long> = emptyMap()
)

/** Card composer (S18, MOS-F153-005). Limits = readable density (server design.fn_tokens_report). */
data class CardTokens(val borderDp: Float = 0f, val radiusDp: Float = 16f, val paddingDp: Float = 14f, val elevationDp: Float = 1f, val gapDp: Float = 10f)

data class TypeTokens(
    val scale: Float = 1.0f,               // 0.85 .. 1.40 (Chairman "font size")
    val bodySp: Float = 15f,
    val labelSp: Float = 13f,
    val titleSp: Float = 18f,
    val headlineSp: Float = 22f,
    val lineHeightFactor: Float = 1.45f    // Bengali conjuncts need generous line height
)

data class ShapeTokens(val cornerSmallDp: Float = 8f, val cornerMediumDp: Float = 12f, val cornerLargeDp: Float = 16f)

enum class Density { COMFORTABLE, COMPACT }

data class SpacingTokens(val unitDp: Float = 4f, val screenPaddingDp: Float = 16f, val density: Density = Density.COMFORTABLE)

enum class TokenSource { DEFAULT, PUBLISHED }

data class MohonaTokens(
    val revision: Int = 0,
    val source: TokenSource = TokenSource.DEFAULT,
    val colors: ColorTokens = ColorTokens(),
    val type: TypeTokens = TypeTokens(),
    val shapes: ShapeTokens = ShapeTokens(),
    val spacing: SpacingTokens = SpacingTokens(),
    val cards: CardTokens = CardTokens()
) {
    companion object { val DEFAULT = MohonaTokens() }
}

/** WCAG 2.x relative luminance / contrast ratio. */
object Contrast {
    private fun channel(c: Long, shift: Int): Double {
        val v = ((c shr shift) and 0xFF).toDouble() / 255.0
        return if (v <= 0.03928) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }
    fun luminance(argb: Long): Double = 0.2126 * channel(argb, 16) + 0.7152 * channel(argb, 8) + 0.0722 * channel(argb, 0)
    fun ratio(a: Long, b: Long): Double {
        val la = luminance(a); val lb = luminance(b)
        return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
    }
}

/**
 * JSON <-> tokens. Invalid or unreadable values fall back to the default for THAT field and are reported, so one
 * bad Studio value can never make the app unreadable. Accessibility floors (not stylistic limits):
 * body text ≥ 4.5:1, muted text ≥ 3.0:1, button text on primary ≥ 3.0:1 (large/bold text rule).
 */
object TokenCodec {
    const val MIN_TEXT = 4.5
    const val MIN_MUTED = 3.0
    const val MIN_ON_PRIMARY = 3.0
    private val HEX = Regex("^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")

    fun parseHex(s: String?): Long? {
        if (s == null || !HEX.matches(s)) return null
        val h = s.substring(1)
        return if (h.length == 6) (0xFF000000L or h.toLong(16)) else h.toLong(16)
    }

    fun toHex(c: Long): String = "#" + String.format("%06X", c and 0xFFFFFF)

    data class Decoded(val tokens: MohonaTokens, val problems: List<String>)

    fun decode(json: JSONObject?): Decoded {
        val problems = ArrayList<String>()
        if (json == null) return Decoded(MohonaTokens.DEFAULT, listOf("no tokens: defaults used"))
        val d = ColorTokens()
        val c = json.optJSONObject("colors") ?: JSONObject()
        fun col(key: String, def: Long): Long {
            if (!c.has(key)) return def
            val v = parseHex(c.optString(key, ""))
            if (v == null) { problems.add("colors.$key invalid"); return def }
            if ((v ushr 24) != 0xFFL) { problems.add("colors.$key must be opaque"); return def }
            return v
        }
        var colors = ColorTokens(
            primary = col("primary", d.primary), primaryDark = col("primaryDark", d.primaryDark), primarySoft = col("primarySoft", d.primarySoft),
            onPrimary = col("onPrimary", d.onPrimary), background = col("background", d.background), surfaceAlt = col("surfaceAlt", d.surfaceAlt),
            text = col("text", d.text), textMuted = col("textMuted", d.textMuted), divider = col("divider", d.divider),
            good = col("good", d.good), warn = col("warn", d.warn), bad = col("bad", d.bad), info = col("info", d.info),
            chart = parseChart(c.optJSONArray("chart"), d.chart, problems),
            roleAccent = parseAccents(c.optJSONObject("roleAccent"), problems)
        )
        if (Contrast.ratio(colors.text, colors.background) < MIN_TEXT) { problems.add("text/background contrast too low"); colors = colors.copy(text = d.text, background = d.background) }
        if (Contrast.ratio(colors.textMuted, colors.background) < MIN_MUTED) { problems.add("textMuted/background contrast too low"); colors = colors.copy(textMuted = d.textMuted) }
        if (Contrast.ratio(colors.onPrimary, colors.primary) < MIN_ON_PRIMARY) { problems.add("onPrimary/primary contrast too low"); colors = colors.copy(primary = d.primary, onPrimary = d.onPrimary) }

        val t = json.optJSONObject("type") ?: JSONObject()
        val dt = TypeTokens()
        fun num(o: JSONObject, key: String, def: Float, lo: Float, hi: Float, path: String): Float {
            if (!o.has(key)) return def
            val v = o.optDouble(key, Double.NaN)
            if (v.isNaN() || v < lo || v > hi) { problems.add("$path.$key out of range $lo..$hi"); return def }
            return v.toFloat()
        }
        val type = TypeTokens(
            scale = num(t, "scale", dt.scale, 0.85f, 1.40f, "type"), bodySp = num(t, "bodySp", dt.bodySp, 12f, 22f, "type"),
            labelSp = num(t, "labelSp", dt.labelSp, 11f, 18f, "type"), titleSp = num(t, "titleSp", dt.titleSp, 14f, 28f, "type"),
            headlineSp = num(t, "headlineSp", dt.headlineSp, 18f, 36f, "type"), lineHeightFactor = num(t, "lineHeightFactor", dt.lineHeightFactor, 1.2f, 2.0f, "type")
        )
        val s = json.optJSONObject("shapes") ?: JSONObject()
        val ds = ShapeTokens()
        val shapes = ShapeTokens(num(s, "cornerSmallDp", ds.cornerSmallDp, 0f, 24f, "shapes"), num(s, "cornerMediumDp", ds.cornerMediumDp, 0f, 32f, "shapes"), num(s, "cornerLargeDp", ds.cornerLargeDp, 0f, 40f, "shapes"))
        val sp = json.optJSONObject("spacing") ?: JSONObject()
        val dsp = SpacingTokens()
        val density = when (sp.optString("density", "")) {
            "" -> dsp.density
            "COMPACT" -> Density.COMPACT
            "COMFORTABLE" -> Density.COMFORTABLE
            else -> { problems.add("spacing.density invalid"); dsp.density }
        }
        val spacing = SpacingTokens(num(sp, "unitDp", dsp.unitDp, 2f, 8f, "spacing"), num(sp, "screenPaddingDp", dsp.screenPaddingDp, 8f, 32f, "spacing"), density)
        val cd = json.optJSONObject("cards") ?: JSONObject()
        val dc = CardTokens()
        val cards = CardTokens(num(cd, "borderDp", dc.borderDp, 0f, 2f, "cards"), num(cd, "radiusDp", dc.radiusDp, 0f, 28f, "cards"),
            num(cd, "paddingDp", dc.paddingDp, 8f, 24f, "cards"), num(cd, "elevationDp", dc.elevationDp, 0f, 8f, "cards"), num(cd, "gapDp", dc.gapDp, 4f, 24f, "cards"))
        val rev = json.optInt("revision", 0).coerceAtLeast(0)
        return Decoded(MohonaTokens(rev, TokenSource.PUBLISHED, colors, type, shapes, spacing, cards), problems)
    }

    /** Accents unreadable under white text are dropped (the server refuses to publish them). */
    private fun parseAccents(o: JSONObject?, problems: MutableList<String>): Map<String, Long> {
        if (o == null) return emptyMap()
        val out = LinkedHashMap<String, Long>()
        for (k in o.keys()) {
            val v = parseHex(o.optString(k, ""))
            if (v == null || !Regex("^[A-Z][A-Z0-9_]{1,40}$").matches(k) || Contrast.ratio(v, 0xFFFFFFFF) < MIN_ON_PRIMARY) problems.add("colors.roleAccent.$k dropped")
            else out[k] = v
        }
        return out
    }

    private fun parseChart(a: JSONArray?, def: List<Long>, problems: MutableList<String>): List<Long> {
        if (a == null) return def
        val out = ArrayList<Long>()
        for (i in 0 until a.length()) {
            val v = parseHex(a.optString(i, ""))
            if (v == null) problems.add("colors.chart[$i] invalid") else out.add(v)
        }
        if (out.size < 2) { problems.add("colors.chart needs at least 2 colours"); return def }
        return out
    }

    fun encode(t: MohonaTokens): JSONObject {
        val c = t.colors
        val colors = JSONObject()
            .put("primary", toHex(c.primary)).put("primaryDark", toHex(c.primaryDark)).put("primarySoft", toHex(c.primarySoft))
            .put("onPrimary", toHex(c.onPrimary)).put("background", toHex(c.background)).put("surfaceAlt", toHex(c.surfaceAlt))
            .put("text", toHex(c.text)).put("textMuted", toHex(c.textMuted)).put("divider", toHex(c.divider))
            .put("good", toHex(c.good)).put("warn", toHex(c.warn)).put("bad", toHex(c.bad)).put("info", toHex(c.info))
            .put("chart", JSONArray(c.chart.map { toHex(it) }))
        if (c.roleAccent.isNotEmpty()) colors.put("roleAccent", JSONObject().apply { c.roleAccent.forEach { (k, v) -> put(k, toHex(v)) } })
        val type = JSONObject().put("scale", t.type.scale.toDouble()).put("bodySp", t.type.bodySp.toDouble()).put("labelSp", t.type.labelSp.toDouble())
            .put("titleSp", t.type.titleSp.toDouble()).put("headlineSp", t.type.headlineSp.toDouble()).put("lineHeightFactor", t.type.lineHeightFactor.toDouble())
        val shapes = JSONObject().put("cornerSmallDp", t.shapes.cornerSmallDp.toDouble()).put("cornerMediumDp", t.shapes.cornerMediumDp.toDouble()).put("cornerLargeDp", t.shapes.cornerLargeDp.toDouble())
        val spacing = JSONObject().put("unitDp", t.spacing.unitDp.toDouble()).put("screenPaddingDp", t.spacing.screenPaddingDp.toDouble()).put("density", t.spacing.density.name)
        val cards = JSONObject().put("borderDp", t.cards.borderDp.toDouble()).put("radiusDp", t.cards.radiusDp.toDouble()).put("paddingDp", t.cards.paddingDp.toDouble())
            .put("elevationDp", t.cards.elevationDp.toDouble()).put("gapDp", t.cards.gapDp.toDouble())
        return JSONObject().put("revision", t.revision).put("colors", colors).put("type", type).put("shapes", shapes).put("spacing", spacing).put("cards", cards)
    }
}

/**
 * Studio-side mirror of design.fn_tokens_report (S18): the publish blockers, shown live while editing.
 * The server report is the authority; this only spares a round trip.
 */
object DesignRules {
    fun publishErrors(t: MohonaTokens): List<String> {
        val e = ArrayList<String>(); val c = t.colors
        fun need(name: String, a: Long, b: Long, min: Double) { val r = Contrast.ratio(a, b); if (r < min) e += "$name ${"%.2f".format(r)} < $min" }
        need("text/background", c.text, c.background, 4.5)
        need("text/surfaceAlt", c.text, c.surfaceAlt, 4.5)
        need("textMuted/background", c.textMuted, c.background, 3.0)
        need("onPrimary/primary", c.onPrimary, c.primary, 3.0)
        c.roleAccent.forEach { (k, v) -> need("roleAccent $k", c.onPrimary, v, 3.0) }
        val ty = t.type
        if (ty.lineHeightFactor < 1.3f) e += "lineHeightFactor < 1.3"
        if (ty.headlineSp * ty.scale > 34f || ty.titleSp * ty.scale > 28f || ty.bodySp * ty.scale > 24f) e += "amounts would clip"
        if (ty.labelSp * ty.scale < 11f) e += "labels below 11 sp"
        if (t.cards.paddingDp < 8f) e += "card padding below 8 dp"
        return e
    }

    /** The longest money text a card must show without clipping (used by the studio preview). */
    const val MONEY_SAMPLE = "৳ ১২,৩৪,৫৬,৭৮৯.০০"
}

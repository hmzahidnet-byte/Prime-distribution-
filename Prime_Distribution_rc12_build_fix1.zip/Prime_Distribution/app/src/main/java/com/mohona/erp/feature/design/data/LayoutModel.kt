package com.mohona.erp.feature.design.data

import org.json.JSONArray
import org.json.JSONObject

data class GridWidget(val id: String, val type: String, val x: Int, val y: Int, val w: Int, val h: Int, val binding: String? = null, val titleBn: String? = null)
data class Breakpoint(val name: String, val columns: Int, val widgets: List<GridWidget>) {
    val rows: Int get() = widgets.maxOfOrNull { it.y + it.h } ?: 0
}
data class ScreenLayout(val breakpoints: Map<String, Breakpoint>) {
    val phone: Breakpoint get() = breakpoints.getValue("phone")
}
data class Motion(val durationMs: Int = 200, val easing: String = "standard", val reduced: String = "respect_system")

/**
 * Layout grid (S19, MOS-F153-006/009). Pure: parse/encode, the same rules as design.fn_layout_report (server = authority),
 * snap-editing helpers and breakpoint choice for the responsive preview.
 */
object LayoutGrid {
    val TYPES = setOf("kpi", "shortcut", "list", "chart", "approval", "ad_slot", "text", "calendar")
    private val BINDING = Regex("^[a-z][a-z0-9_]*(\\.[a-z0-9_]+){1,3}$")

    fun parse(o: JSONObject?): ScreenLayout? = try {
        val bps = o!!.getJSONObject("breakpoints")
        val out = LinkedHashMap<String, Breakpoint>()
        for (name in bps.keys()) {
            val b = bps.getJSONObject(name); val a = b.getJSONArray("widgets")
            out[name] = Breakpoint(name, b.getInt("columns"), (0 until a.length()).map { a.getJSONObject(it).let { w ->
                GridWidget(w.getString("id"), w.getString("type"), w.getInt("x"), w.getInt("y"), w.getInt("w"), w.getInt("h"),
                    w.optString("binding").ifBlank { null }, w.optString("title_bn").ifBlank { null }) } })
        }
        if ("phone" in out) ScreenLayout(out) else null
    } catch (e: Exception) { null }

    fun encode(l: ScreenLayout): JSONObject {
        val bps = JSONObject()
        l.breakpoints.forEach { (name, b) ->
            bps.put(name, JSONObject().put("columns", b.columns).put("widgets", JSONArray(b.widgets.map { w ->
                JSONObject().put("id", w.id).put("type", w.type).put("x", w.x).put("y", w.y).put("w", w.w).put("h", w.h).apply {
                    w.binding?.let { put("binding", it) }; w.titleBn?.let { put("title_bn", it) } } })))
        }
        return JSONObject().put("breakpoints", bps)
    }

    /** Errors of one breakpoint (mirror of the server rules). */
    fun errors(b: Breakpoint, adsRequired: Int = 0, approvalMaxRow: Int = 4): List<String> {
        val e = ArrayList<String>(); val cells = HashSet<Pair<Int, Int>>()
        val range = if (b.name == "phone") 2..6 else 4..12
        if (b.columns !in range) e += "${b.name}: columns"
        if (b.widgets.isEmpty() || b.widgets.size > 60) e += "${b.name}: 1..60 widgets"
        if (b.widgets.map { it.id }.toSet().size != b.widgets.size) e += "${b.name}: duplicate id"
        for (w in b.widgets) {
            if (w.type !in TYPES) { e += "${w.id}: type"; continue }
            if (w.x < 0 || w.y !in 0..100 || w.w < 1 || w.h !in 1..6 || w.x + w.w > b.columns) { e += "${w.id}: outside the grid"; continue }
            if (w.type in setOf("kpi", "list", "chart") && (w.binding == null || !BINDING.matches(w.binding))) e += "${w.id}: binding"
            if (w.type == "approval" && (w.y + w.h > approvalMaxRow || w.w * 2 < b.columns)) e += "${w.id}: approval off-screen or too narrow"
            for (i in 0 until w.w) for (j in 0 until w.h) if (!cells.add((w.x + i) to (w.y + j))) { e += "${w.id}: overlap"; break }
        }
        if (b.widgets.count { it.type == "ad_slot" } < adsRequired) e += "${b.name}: ad slot required"
        return e.distinct()
    }

    fun errors(l: ScreenLayout, adsRequired: Int = 0, approvalMaxRow: Int = 4): List<String> =
        l.breakpoints.values.flatMap { errors(it, adsRequired, approvalMaxRow) }

    /** Moves/resizes one widget by whole cells; returns null when the result would break a rule (snap editing). */
    fun edit(b: Breakpoint, id: String, dx: Int = 0, dy: Int = 0, dw: Int = 0, dh: Int = 0, approvalMaxRow: Int = 4): Breakpoint? {
        val w = b.widgets.firstOrNull { it.id == id } ?: return null
        val moved = w.copy(x = w.x + dx, y = w.y + dy, w = w.w + dw, h = w.h + dh)
        val next = b.copy(widgets = b.widgets.map { if (it.id == id) moved else it })
        return next.takeIf { errors(it, 0, approvalMaxRow).isEmpty() }
    }

    /** Responsive choice: tablet when ≥ 600 dp wide (landscape layout when wider than tall); phone otherwise. */
    fun pick(l: ScreenLayout, widthDp: Int, heightDp: Int): Breakpoint = when {
        widthDp >= 600 && widthDp > heightDp && "landscape" in l.breakpoints -> l.breakpoints.getValue("landscape")
        widthDp >= 600 && "tablet" in l.breakpoints -> l.breakpoints.getValue("tablet")
        else -> l.phone
    }
}

/** Motion policy (MOS-F153-008): the phone's "remove animations" always wins; the Chairman may only reduce further. */
object MotionPolicy {
    fun durationMs(m: Motion, systemAnimatorScale: Float): Int =
        if (m.reduced == "always_reduce" || systemAnimatorScale == 0f) 0 else (m.durationMs.coerceIn(0, 600) * systemAnimatorScale).toInt()
}

package com.mohona.erp.feature.stock.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import java.math.RoundingMode
import org.json.JSONArray
import org.json.JSONObject

data class Balance(val warehouseId: String, val productId: String, val sku: String, val nameBn: String, val unit: String, val qty: BigDecimal,
                   val available: BigDecimal, val avgCost: BigDecimal?, val value: BigDecimal?, val belowMin: Boolean)
data class LotRow(val lotId: String, val lotNo: String, val qty: BigDecimal, val expiry: String?, val expired: Boolean)

/** Stock (S25): balances, lots, receipts, reservations, issues, returns, wastage, substitutes. Server posts; app shows. */
class StockRepository(private val client: SupabaseClient) {
    suspend fun balances(warehouseId: String? = null, productId: String? = null): ApiResult<List<Balance>> =
        when (val r = client.rpcArray("v1_stock_balances", JSONObject().put("p_warehouse_id", warehouseId ?: JSONObject.NULL).put("p_product_id", productId ?: JSONObject.NULL))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseBalances(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_stock_balances"))
        }
    suspend fun lots(productId: String, warehouseId: String? = null): ApiResult<List<LotRow>> =
        when (val r = client.rpcArray("v1_stock_lots", JSONObject().put("p_product_id", productId).put("p_warehouse_id", warehouseId ?: JSONObject.NULL))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(parseLots(r.value))
        }
    suspend fun reserve(warehouseId: String, productId: String, qty: BigDecimal, batchRef: String, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_stock_reserve", JSONObject().put("p_warehouse_id", warehouseId).put("p_product_id", productId).put("p_qty", qty).put("p_batch_ref", batchRef)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun issue(reservationId: String, qty: BigDecimal, substituteId: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_material_issue", JSONObject().put("p_reservation_id", reservationId).put("p_qty", qty).put("p_substitute_id", substituteId ?: JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun returnToStock(issueId: String, line: Int, qty: BigDecimal, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_material_return", JSONObject().put("p_issue_id", issueId).put("p_issue_line", line).put("p_qty", qty).put("p_reason", reason),
            write = true, idempotencyKey = key)
    suspend fun wastage(warehouseId: String, abnormal: Boolean, lines: JSONArray, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_wastage_submit", JSONObject().put("p_warehouse_id", warehouseId).put("p_kind", if (abnormal) "abnormal" else "normal").put("p_lines", lines)
            .put("p_reason", reason), write = true, idempotencyKey = key)

    companion object {
        private fun JSONObject.dec(k: String): BigDecimal? = if (!has(k) || isNull(k)) null else runCatching { BigDecimal(get(k).toString()) }.getOrNull()
        fun parseBalances(a: JSONArray): List<Balance>? = try {
            (0 until a.length()).map { a.getJSONObject(it).let { o -> Balance(o.getString("warehouse_id"), o.getString("product_id"), o.getString("sku"), o.getString("name_bn"),
                o.optString("unit"), o.dec("qty") ?: BigDecimal.ZERO, o.dec("available") ?: BigDecimal.ZERO, o.dec("avg_cost"), o.dec("value"), o.optBoolean("below_min")) } }
        } catch (e: Exception) { null }
        fun parseLots(a: JSONArray): List<LotRow> = (0 until a.length()).map { a.getJSONObject(it).let { o ->
            LotRow(o.getString("lot_id"), o.getString("lot_no"), o.dec("qty") ?: BigDecimal.ZERO, o.optString("expiry_date").ifBlank { null }?.takeIf { !o.isNull("expiry_date") }, o.optBoolean("expired")) } }
    }
}

/** Client mirrors for previews: FEFO allocation and moving-average cost (the server is authoritative). */
object StockMath {
    data class Pick(val lotId: String, val qty: BigDecimal)
    class Short(val missing: BigDecimal, val onlyExpired: Boolean) : IllegalStateException("short $missing")

    fun fefo(lots: List<LotRow>, qty: BigDecimal): List<Pick> {
        var left = qty; var expired = BigDecimal.ZERO; val out = ArrayList<Pick>()
        for (l in lots.sortedWith(compareBy(nullsLast()) { it.expiry })) {
            if (l.expired) { expired += l.qty; continue }
            if (left.signum() <= 0) break
            val take = l.qty.min(left); out += Pick(l.lotId, take); left -= take
        }
        if (left.signum() > 0) throw Short(left, expired >= left)
        return out
    }

    /** New average after receiving qty at unitCost onto (onHand, value). */
    fun average(onHand: BigDecimal, value: BigDecimal, qty: BigDecimal, unitCost: BigDecimal): BigDecimal {
        val q = onHand + qty
        return if (q.signum() == 0) BigDecimal.ZERO else (value + qty * unitCost).divide(q, 4, RoundingMode.HALF_UP)
    }
}

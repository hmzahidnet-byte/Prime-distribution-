package com.mohona.erp.feature.stock.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.SupabaseClient
import java.math.BigDecimal
import org.json.JSONArray
import org.json.JSONObject

data class BinQr(val companyCode: String, val warehouseCode: String, val binCode: String, val signature: String)
data class CountItem(val lotId: String, val productId: String, val lotNo: String)

/** Warehouse operations (S29–S31): bins + signed QR, transfers, blind counts, adjustments, availability, report. */
class WarehouseRepository(private val client: SupabaseClient) {
    suspend fun saveBin(warehouseId: String, code: String, nameBn: String?, kind: String, parentId: String?, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_bin_save", JSONObject().put("p_warehouse_id", warehouseId).put("p_id", JSONObject.NULL).put("p_code", code).put("p_name_bn", nameBn ?: JSONObject.NULL)
            .put("p_kind", kind).put("p_parent_id", parentId ?: JSONObject.NULL).put("p_status", JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun moveToBin(warehouseId: String, lotId: String, fromBin: String?, toBin: String, qty: BigDecimal, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_bin_move", JSONObject().put("p_warehouse_id", warehouseId).put("p_lot_id", lotId).put("p_from_bin", fromBin ?: JSONObject.NULL).put("p_to_bin", toBin)
            .put("p_qty", qty), write = true, idempotencyKey = key)
    suspend fun lookup(payload: String): ApiResult<JSONObject> = client.rpcObject("v1_qr_lookup", JSONObject().put("p_payload", payload))
    suspend fun transfer(from: String, to: String, lines: JSONArray, reason: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_transfer_create", JSONObject().put("p_from", from).put("p_to", to).put("p_lines", lines).put("p_reason", reason), write = true, idempotencyKey = key)
    suspend fun startCount(warehouseId: String, reason: String, key: String): ApiResult<Pair<String, List<CountItem>>> =
        when (val r = client.rpcObject("v1_count_start", JSONObject().put("p_warehouse_id", warehouseId).put("p_product_ids", JSONObject.NULL).put("p_reason", reason),
            write = true, idempotencyKey = key)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.getString("count_id") to parseCountList(r.value.optJSONArray("to_count") ?: JSONArray()))
        }
    suspend fun recordCount(countId: String, counted: Map<String, BigDecimal>, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_count_record", JSONObject().put("p_count_id", countId).put("p_lines", JSONArray(counted.map { (lot, q) -> JSONObject().put("lot_id", lot).put("counted", q) })),
            write = true, idempotencyKey = key)
    suspend fun submitCount(countId: String, key: String): ApiResult<JSONObject> =
        client.rpcObject("v1_count_submit", JSONObject().put("p_count_id", countId), write = true, idempotencyKey = key)
    suspend fun availability(productId: String): ApiResult<JSONArray> = client.rpcArray("v1_stock_availability", JSONObject().put("p_product_id", productId))
    suspend fun report(warehouseId: String? = null): ApiResult<JSONArray> =
        client.rpcArray("v1_stock_report", JSONObject().put("p_warehouse_id", warehouseId ?: JSONObject.NULL).put("p_product_id", JSONObject.NULL))

    companion object {
        /** Count list for counters: lot and product only — any quantity field from a server would be ignored (blind count). */
        fun parseCountList(a: JSONArray): List<CountItem> =
            (0 until a.length()).map { a.getJSONObject(it).let { o -> CountItem(o.getString("lot_id"), o.getString("product_id"), o.optString("lot_no")) } }

        /** "MOS1|B|<company>|<warehouse>|<bin>|<16 hex>" — the server verifies the signature; this only recognises the shape. */
        fun parseBinQr(payload: String): BinQr? {
            val p = payload.split('|')
            if (p.size != 6 || p[0] != "MOS1" || p[1] != "B" || !Regex("^[0-9a-f]{16}$").matches(p[5])) return null
            return BinQr(p[2], p[3], p[4], p[5])
        }
    }
}

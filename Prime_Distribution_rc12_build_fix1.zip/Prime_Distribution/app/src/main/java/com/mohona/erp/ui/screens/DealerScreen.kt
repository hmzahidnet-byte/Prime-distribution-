package com.mohona.erp.ui.screens

import com.mohona.erp.data.Bn
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Dealers (S40): own / all dealers by right, balance + credit, authorised contacts (call / WhatsApp), aging, QR lookup. */
@Composable
fun DealerScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    var list by remember { mutableStateOf(JSONArray()) }
    var detail by remember { mutableStateOf<JSONObject?>(null) }
    var statement by remember { mutableStateOf<JSONObject?>(null) }
    var qr by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(text) {
        when (val r = AppContainer.crm?.dealers(text.ifBlank { null })) { is ApiResult.Ok -> list = r.value; is ApiResult.Err -> message = r.error.messageBn; null -> message = "সংযুক্ত মোড নয়।" }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("ডিলার", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            (0 until list.length()).map { list.getJSONObject(it) }.forEach { d ->
                AppCard(onClick = { scope.launch {
                    (AppContainer.crm?.dealer(d.getString("id")) as? ApiResult.Ok)?.let { detail = it.value }
                    (AppContainer.crm?.statement(d.getString("id"), null, null) as? ApiResult.Ok)?.let { statement = it.value }
                } }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(d.optString("code") + " · " + d.optString("name_bn"), style = MaterialTheme.typography.bodyMedium)
                        Text("বকেয়া ${Bn.money(d.optString("balance"))} · সীমা ${Bn.money(d.optString("credit_limit"))} · ${d.optString("status")}", style = MaterialTheme.typography.labelSmall,
                            color = if (d.optString("status") != "active") BadRed else TextMuted)
                    }
                }
            }
            detail?.let { d ->
                val credit = d.optJSONObject("credit")
                Text(d.optString("name_bn") + " — ব্যবহারযোগ্য ক্রেডিট " + Bn.money(credit?.optString("available")), style = MaterialTheme.typography.titleSmall)
                val contacts = d.optJSONArray("contacts") ?: JSONArray()
                (0 until contacts.length()).map { contacts.getJSONObject(it) }.forEach { c ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(c.optString("name_bn") + " " + c.optString("phone"), Modifier.weight(1f), style = MaterialTheme.typography.labelSmall)
                        if (c.optBoolean("authorized")) listOf("call" to "কল", "whatsapp" to "WhatsApp").forEach { (ch, label) ->
                            OutlinedButton(onClick = { scope.launch {
                                when (val r = AppContainer.crm?.contactLink(c.getString("id"), ch, null)) {
                                    is ApiResult.Ok -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.value.getString("link")))) }
                                    is ApiResult.Err -> message = r.error.messageBn
                                    null -> Unit
                                } } }) { Text(label) }
                        }
                    }
                }
            }
            statement?.optJSONObject("aging")?.let { a ->
                Text("বয়স: চলতি ${a.optString("current")} · ১–৩০ ${a.optString("d1_30")} · ৩১–৬০ ${a.optString("d31_60")} · ৬১–৯০ ${a.optString("d61_90")} · ৯০+ ${a.optString("d90_plus")}",
                    style = MaterialTheme.typography.labelSmall)
            }
            OutlinedTextField(value = qr, onValueChange = { qr = it.trim() }, label = { Text("ডিলার-QR (স্ক্যান)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(enabled = qr.startsWith("MOS1|D|"), onClick = { scope.launch {
                when (val r = AppContainer.crm?.qrLookup(qr)) {
                    is ApiResult.Ok -> message = r.value.optString("name_bn") + (if (r.value.isNull("balance")) "" else " · বকেয়া " + Bn.money(r.value.optString("balance"))) + " — " + r.value.optString("note_bn")
                    is ApiResult.Err -> message = r.error.messageBn
                    null -> Unit
                } } }) { Text("QR দেখুন") }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

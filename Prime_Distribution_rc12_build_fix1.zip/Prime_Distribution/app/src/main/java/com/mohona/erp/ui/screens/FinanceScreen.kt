package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.PermissionHints
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import com.mohona.erp.ui.components.ScreenHeader
import java.util.UUID
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** Finance (S36–S39): trial balance, statements, module postings waiting (with reason), factory P&L (if allowed). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FinanceScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    var tab by remember { mutableStateOf("tb") }
    var obj by remember { mutableStateOf<JSONObject?>(null) }
    var arr by remember { mutableStateOf(JSONArray()) }
    var message by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab, reload) {
        val repo = AppContainer.finance ?: run { message = "সংযুক্ত মোড নয়।"; return@LaunchedEffect }
        message = null; obj = null; arr = JSONArray()
        when (tab) {
            "tb" -> when (val r = repo.trialBalance()) { is ApiResult.Ok -> obj = r.value; is ApiResult.Err -> message = r.error.messageBn }
            "st" -> when (val r = repo.statements()) { is ApiResult.Ok -> obj = r.value; is ApiResult.Err -> message = r.error.messageBn }
            "ev" -> when (val r = repo.glEvents("error")) { is ApiResult.Ok -> arr = r.value; is ApiResult.Err -> message = r.error.messageBn }
            else -> when (val r = repo.factoryPnl(null, null)) { is ApiResult.Ok -> obj = r.value; is ApiResult.Err -> message = r.error.messageBn }
        }
    }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("হিসাব", onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("tb" to "রেওয়ামিল", "st" to "বিবরণী", "ev" to "আটকে থাকা পোস্টিং").forEach { (k, l) -> FilterChip(selected = tab == k, onClick = { tab = k }, label = { Text(l) }) }
                if (PermissionHints.can(perms, "finance.factory_pnl.read")) FilterChip(selected = tab == "pnl", onClick = { tab = "pnl" }, label = { Text("ফ্যাক্টরি লাভ-ক্ষতি") })
            }
            when (tab) {
                "tb" -> obj?.let { o ->
                    val rows = o.optJSONArray("rows") ?: JSONArray()
                    (0 until rows.length()).map { rows.getJSONObject(it) }.forEach { r ->
                        Text("${r.optString("code")} ${r.optString("name_bn")} · ডেবিট ${r.optString("debit")} · ক্রেডিট ${r.optString("credit")}", style = MaterialTheme.typography.labelSmall)
                    }
                    Text("মোট ডেবিট ${o.optString("debit")} = ক্রেডিট ${o.optString("credit")}", style = MaterialTheme.typography.bodySmall,
                        color = if (o.optString("debit") == o.optString("credit")) TextMuted else BadRed)
                }
                "ev" -> {
                    if (arr.length() == 0) Text("কোনো পোস্টিং আটকে নেই।", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    (0 until arr.length()).map { arr.getJSONObject(it) }.forEach { e ->
                        Text("${e.optString("source_key")}: ${e.optString("error")}", style = MaterialTheme.typography.labelSmall, color = BadRed)
                    }
                    OutlinedButton(onClick = { scope.launch {
                        when (val r = AppContainer.finance?.retryEvents(UUID.randomUUID().toString())) {
                            is ApiResult.Ok -> { message = "আবার চেষ্টা হয়েছে।"; reload++ }; is ApiResult.Err -> message = r.error.messageBn; null -> Unit } } }) { Text("আবার পোস্ট করুন") }
                }
                else -> obj?.let { o -> o.keys().forEach { k -> Text("$k: ${o.opt(k)}", style = MaterialTheme.typography.labelSmall) } }
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextMuted) }
        }
    }
}

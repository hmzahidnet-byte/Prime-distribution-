package com.mohona.erp.feature.iam.data

import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.net.ErrorCatalog
import com.mohona.erp.core.net.SupabaseClient
import org.json.JSONArray
import org.json.JSONObject

enum class ScopeKind { COMPANY, WING, DEPARTMENT, LOCATION, WAREHOUSE, ASSIGNED, SELF }

data class PermissionScope(val kind: ScopeKind, val id: String?)

/**
 * UI HINTS ONLY (what to show/enable). The server re-authorizes every action with iam.fn_require; a hint can never grant
 * anything. Supreme (Chairman) = every active permission company-wide.
 */
data class MyPermissions(val positionCode: String, val isSupreme: Boolean, val grants: Map<String, List<PermissionScope>>) {
    fun has(code: String): Boolean = isSupreme || grants.containsKey(code)
    fun hasCompanyWide(code: String): Boolean = isSupreme || grants[code]?.any { it.kind == ScopeKind.COMPANY } == true
    fun hasForWing(code: String, wingId: String): Boolean =
        hasCompanyWide(code) || grants[code]?.any { it.kind == ScopeKind.WING && it.id == wingId } == true
    companion object { val NONE = MyPermissions("", false, emptyMap()) }
}

data class CatalogEntry(val code: String, val module: String, val nameBn: String, val actionKind: String, val isSensitive: Boolean,
                        val isDelegable: Boolean, val requiresAal2: Boolean, val allowedScopes: List<ScopeKind>, val status: String) {
    val active: Boolean get() = status == "active"
}

data class PermissionRule(val id: String, val permissionCode: String, val effect: String, val scopeKind: ScopeKind, val scopeId: String?,
                          val origin: String, val reason: String?, val validUntil: String?)

class PermissionRepository(private val client: SupabaseClient) {

    suspend fun mine(): ApiResult<MyPermissions> = when (val r = client.rpcObject("v1_iam_my_permissions")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseMine(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_my_permissions"))
    }

    suspend fun catalog(): ApiResult<List<CatalogEntry>> = when (val r = client.rpcArray("v1_iam_permission_catalog")) {
        is ApiResult.Err -> r
        is ApiResult.Ok -> parseCatalog(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_permission_catalog"))
    }

    suspend fun positionRules(positionCode: String): ApiResult<List<PermissionRule>> =
        when (val r = client.rpcArray("v1_iam_position_rules", JSONObject().put("p_position_code", positionCode))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseRules(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_position_rules"))
        }

    suspend fun setPositionRule(positionCode: String, permission: String, allow: Boolean, scope: ScopeKind, scopeId: String?, reason: String, idempotencyKey: String): ApiResult<String> =
        when (val r = client.rpc("v1_iam_set_position_rule", JSONObject().put("p_position_code", positionCode).put("p_permission", permission)
            .put("p_effect", if (allow) "allow" else "deny").put("p_scope_kind", scope.name).put("p_scope_id", scopeId ?: JSONObject.NULL)
            .put("p_reason", reason), write = true, idempotencyKey = idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.toString())
        }

    suspend fun revokePositionRule(ruleId: String, reason: String, idempotencyKey: String): ApiResult<Unit> =
        when (val r = client.rpc("v1_iam_revoke_position_rule", JSONObject().put("p_rule_id", ruleId).put("p_reason", reason), write = true, idempotencyKey = idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(Unit)
        }

    suspend fun assignmentRules(assignmentId: String): ApiResult<List<PermissionRule>> =
        when (val r = client.rpcArray("v1_iam_assignment_rules", JSONObject().put("p_assignment_id", assignmentId))) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> parseRules(r.value)?.let { ApiResult.Ok(it) } ?: ApiResult.Err(ErrorCatalog.badResponse("v1_iam_assignment_rules"))
        }

    suspend fun setAssignmentRule(assignmentId: String, permission: String, allow: Boolean, scope: ScopeKind, scopeId: String?, validUntilIso: String?,
                                  reason: String, idempotencyKey: String): ApiResult<String> =
        when (val r = client.rpc("v1_iam_set_assignment_rule", JSONObject().put("p_assignment_id", assignmentId).put("p_permission", permission)
            .put("p_effect", if (allow) "allow" else "deny").put("p_scope_kind", scope.name).put("p_scope_id", scopeId ?: JSONObject.NULL)
            .put("p_valid_until", validUntilIso ?: JSONObject.NULL).put("p_reason", reason), write = true, idempotencyKey = idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(r.value.toString())
        }

    suspend fun revokeAssignmentRule(ruleId: String, reason: String, idempotencyKey: String): ApiResult<Unit> =
        when (val r = client.rpc("v1_iam_revoke_assignment_rule", JSONObject().put("p_rule_id", ruleId).put("p_reason", reason), write = true, idempotencyKey = idempotencyKey)) {
            is ApiResult.Err -> r
            is ApiResult.Ok -> ApiResult.Ok(Unit)
        }

    companion object {
        private fun scopeOf(s: String): ScopeKind? = ScopeKind.values().firstOrNull { it.name == s }
        private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k, "").ifBlank { null }

        fun parseMine(o: JSONObject): MyPermissions? = try {
            val map = LinkedHashMap<String, List<PermissionScope>>()
            val arr = o.optJSONArray("permissions") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                val sc = p.optJSONArray("scopes") ?: JSONArray()
                map[p.getString("code")] = (0 until sc.length()).mapNotNull { k ->
                    val so = sc.getJSONObject(k); scopeOf(so.getString("kind"))?.let { PermissionScope(it, so.str("id")) }
                }
            }
            MyPermissions(o.getString("position_code"), o.optBoolean("is_supreme", false), map)
        } catch (e: Exception) { null }

        fun parseCatalog(a: JSONArray): List<CatalogEntry>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i); val sc = o.getJSONArray("allowed_scopes")
                CatalogEntry(o.getString("code"), o.getString("module"), o.getString("name_bn"), o.getString("action_kind"), o.optBoolean("is_sensitive"),
                    o.optBoolean("is_delegable"), o.optBoolean("requires_aal2"), (0 until sc.length()).mapNotNull { scopeOf(sc.getString(it)) }, o.getString("status"))
            }
        } catch (e: Exception) { null }

        fun parseRules(a: JSONArray): List<PermissionRule>? = try {
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                PermissionRule(o.getString("id"), o.getString("permission_code"), o.getString("effect"), scopeOf(o.getString("scope_kind"))!!,
                    o.str("scope_id"), o.optString("origin", ""), o.str("reason"), o.str("valid_until"))
            }
        } catch (e: Exception) { null }
    }
}

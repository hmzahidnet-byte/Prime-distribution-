-- S40 tests: dealer/retailer master with territory integrity, credit-limit authority, field staff see own dealers,
-- append-only ledger + approved adjustments, credit check with approved exceptions, suspension, authorised contacts,
-- consent-bound visit location, statement + aging, signed dealer QR (no payment meaning), dated reassignment, isolation.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.drv(p uuid) returns integer language sql as $$ select row_version from sales.dealer where id = p $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_f1 uuid; a_f2 uuid; a_md uuid; a_fm uuid; a_ch2 uuid;
        p_ch uuid; p_sm uuid; p_f1 uuid; p_f2 uuid; p_md uuid; p_fm uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_f1 uuid := gen_random_uuid(); u_f2 uuid := gen_random_uuid();
        u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_ch2 uuid := gen_random_uuid();
        t1 uuid; t2 uuid; d1 uuid; r1 uuid; c_ok uuid; c_no uuid; v1 uuid; v2 uuid; adj uuid; ex uuid; qr text; j jsonb; j1 jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('CRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  -- these tests exercise maker-checker with MD / finance approvers; the Chairman-only rule (Prime v180) has its own test (t_s56)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_config_set('approval.financial.chairman_only', 'false'::jsonb, 0, 'legacy maker-checker test');
  p_sm := svc.v1_iam_provision_person('বিক্রয়-ব্যবস্থাপক', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_f1 := svc.v1_iam_provision_person('মাঠ ১', null, null, u_f1, 't'); a_f1 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_f1, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_f2 := svc.v1_iam_provision_person('মাঠ ২', null, null, u_f2, 't'); a_f2 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_f2, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('CRX', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  -- ---------------------------------------------------------------- master data (F121, F122)
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  t1 := (api.v1_territory_save(null, 'T1', 'খুলনা-১', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  t2 := (api.v1_territory_save(null, 'T2', 'যশোর-১', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  insert into _r values ('S40-01', pg_temp.expect_fail(format($f$select api.v1_dealer_save(null, 'D9', 'x', null, null, null, null, %L, null, 50000, 30, null, 'x')$f$, t1), 'E_FORBIDDEN'),
                                   'setting a credit limit needs the credit-override right');
  j := api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', 'রহমান', '01711000222', null, null, t1, p_f1, 0, 30, null, 'new dealer');
  d1 := (j ->> 'dealer_id')::uuid; qr := j ->> 'qr';
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_dealer_save(d1, null, 'রহমান ট্রেডার্স', 'রহমান', '01711000222', null, null, t1, p_f1, 100000, 30, pg_temp.drv(d1), 'limit set');
  perform pg_temp.as_user(u_sm, 'sm');
  r1 := (api.v1_retailer_save(null, 'R1', 'মা স্টোর', null, d1, null, null, null, null, null, 'new shop') ->> 'retailer_id')::uuid;
  insert into _r values ('S40-02', (select territory_id from sales.retailer where id = r1) = t1
                                   and pg_temp.expect_fail(format($f$insert into sales.retailer (company_id, code, name_bn, dealer_id, territory_id) values (%L, 'R9', 'x', %L, %L)$f$, ca, d1, t2), 'E_TERRITORY_MISMATCH'),
                                   'a retailer always sits in its dealer''s territory');
  -- ---------------------------------------------------------------- field visibility
  perform pg_temp.as_user(u_f1, 'f1'); perform api.v1_iam_select_position(a_f1);
  j := api.v1_dealers(null);
  perform pg_temp.as_user(u_f2, 'f2'); perform api.v1_iam_select_position(a_f2);
  insert into _r values ('S40-03', jsonb_array_length(j) = 1 and jsonb_array_length(api.v1_dealers(null)) = 0
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_get(%L)$f$, d1), 'E_FORBIDDEN'),
                                   'field staff see only the dealers assigned to them');
  -- ---------------------------------------------------------------- ledger (F123)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  perform api.v1_dealer_opening(d1, 20000, current_date, 'opening due');
  adj := (api.v1_dealer_adjust(d1, -500, 'rate difference') ->> 'adjustment_id')::uuid;
  insert into _r values ('S40-04', sales.fn_dealer_balance(d1) = 20000
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_opening(%L, 1, null, 'x')$f$, d1), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$update sales.dealer_ledger set amount = 1 where dealer_id = %L$f$, d1)),
                                   'the ledger is append-only and an adjustment waits for approval');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform pg_temp.approve_pending(adj);
  -- ---------------------------------------------------------------- credit (F124)
  j := api.v1_credit_check(d1, 90000);
  perform pg_temp.as_user(u_f1, 'f1');
  ex := (api.v1_credit_exception_request(d1, 20000, current_date + 30, 'festival stock') ->> 'exception_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending(ex);
  j1 := api.v1_credit_check(d1, 90000);
  insert into _r values ('S40-05', sales.fn_dealer_balance(d1) = 19500 and not (j ->> 'allowed')::boolean and (j ->> 'available')::numeric = 80500
                                   and (j1 ->> 'allowed')::boolean and (j1 ->> 'available')::numeric = 100500,
                                   'exposure checked against limit + approved, time-boxed exceptions');
  -- ---------------------------------------------------------------- suspension (F129)
  perform pg_temp.as_user(u_sm, 'sm');
  perform api.v1_dealer_status(d1, 'suspend', pg_temp.drv(d1), 'cheque bounced');
  perform sales.fn_post_ledger(ca, d1, 'collection', -3000, current_date, null, 'test.collection', gen_random_uuid(), 'cash received');
  insert into _r values ('S40-06', not (sales.fn_credit_check(d1, 1) ->> 'allowed')::boolean and sales.fn_dealer_balance(d1) = 16500
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_status(%L, 'reactivate', %s, 'x')$f$, d1, pg_temp.drv(d1)), 'E_FORBIDDEN'),
                                   'suspension blocks new credit, keeps balances and still accepts collections');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_dealer_status(d1, 'reactivate', pg_temp.drv(d1), 'cleared');
  -- ---------------------------------------------------------------- contacts (F126)
  perform pg_temp.as_user(u_sm, 'sm');
  c_ok := (api.v1_dealer_contact_save(d1, null, 'রহমান', 'owner', '01711000222', true, null, 'x') ->> 'contact_id')::uuid;
  c_no := (api.v1_dealer_contact_save(d1, null, 'ক্যাশিয়ার', 'cashier', '01811000333', false, null, 'x') ->> 'contact_id')::uuid;
  perform pg_temp.as_user(u_f1, 'f1');
  j := api.v1_dealer_contact_link(c_ok, 'whatsapp', 'order follow-up');
  j1 := api.v1_dealer_get(d1);
  insert into _r values ('S40-07', j ->> 'link' = 'https://wa.me/8801711000222' and (select count(*) from sales.comm_log where dealer_id = d1) = 1
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_contact_link(%L, 'call', null)$f$, c_no), 'E_CONTACT_NOT_AUTHORIZED')
                                   and exists (select 1 from jsonb_array_elements(j1 -> 'contacts') x where x ->> 'phone' = '••••333'),
                                   'only authorised numbers can be called or messaged; others stay masked');
  -- ---------------------------------------------------------------- visits + consent (F125)
  v1 := (api.v1_visit_plan(d1, null, current_date) ->> 'visit_id')::uuid;
  j := api.v1_visit_record(v1, 'order', 'took order', 22.8, 89.5);
  perform api.v1_location_consent(true, 'agreed');
  v2 := (api.v1_visit_plan(null, r1, current_date) ->> 'visit_id')::uuid;
  j1 := api.v1_visit_record(v2, 'closed_shop', 'closed early', 22.8, 89.5);
  perform pg_temp.as_user(u_f2, 'f2');
  insert into _r values ('S40-08', not (j ->> 'location_saved')::boolean and (select latitude from sales.dealer_visit where id = v1) is null
                                   and (j1 ->> 'location_saved')::boolean and (select latitude from sales.dealer_visit where id = v2) = 22.8
                                   and pg_temp.expect_fail(format($f$select api.v1_visit_record(%L, 'order', null, null, null)$f$, v1), 'E_NOT_FOUND'),
                                   'location is stored only with consent; only the officer records the visit');
  -- ---------------------------------------------------------------- statement + QR (F127, F128)
  perform pg_temp.as_user(u_f1, 'f1');
  j := api.v1_dealer_statement(d1, current_date - 1, current_date);
  j1 := api.v1_dealer_qr_lookup(qr);
  perform pg_temp.as_user(u_f2, 'f2');
  insert into _r values ('S40-09', (j ->> 'closing')::numeric = 16500 and (j ->> 'opening')::numeric = 0 and jsonb_array_length(j -> 'entries') = 3
                                   and (j -> 'aging' ->> 'current')::numeric = 16500,
                                   'statement from posted entries with FIFO aging');
  insert into _r values ('S40-10', (j1 ->> 'balance')::numeric = 16500 and j1 ->> 'note_bn' like '%প্রমাণ নয়%'
                                   and api.v1_dealer_qr_lookup(qr) -> 'balance' = 'null'::jsonb
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_qr_lookup(%L)$f$, left(qr, length(qr) - 1) || case when right(qr, 1) = 'a' then 'b' else 'a' end), 'E_QR_INVALID'),
                                   'the dealer QR identifies only; balances only for permitted readers; forged labels refused');
  -- ---------------------------------------------------------------- reassignment (F130) + isolation
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_dealer_reassign(d1, t2, p_f2, current_date + 1, 'route change');
  update sales.dealer_assignment set effective_from = current_date where id = (j ->> 'assignment_id')::uuid;
  perform pg_temp.as_user(u_f2, 'f2');
  j1 := api.v1_dealers(null);
  perform pg_temp.as_user(u_f1, 'f1');
  insert into _r values ('S40-11', j ->> 'status' = 'scheduled' and jsonb_array_length(j1) = 1 and jsonb_array_length(api.v1_dealers(null)) = 0
                                   and (select territory_id from sales.retailer where id = r1) = t2
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_reassign(%L, %L, null, current_date - 1, 'x')$f$, d1, t1)),
                                   'dated reassignment moves dealer, retailers and visibility on its date; history kept');
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S40-12', pg_temp.expect_fail(format($f$select api.v1_dealer_get(%L)$f$, d1), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_qr_lookup(%L)$f$, qr), 'E_QR_INVALID'),
                                   'another company sees nothing');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

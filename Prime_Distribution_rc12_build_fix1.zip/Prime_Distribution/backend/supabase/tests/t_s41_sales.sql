-- S41–S43 tests: quotation availability, order credit hold + price override, approval + allocation without oversell,
-- dispatch with COGS, single delivery proof, invoice to ledger + journal, ADR-10 return into quarantine at original
-- cost, collections (cash maker-checker, bank only with statement line, bKash only with provider confirmation),
-- partial limits, reversal, signed receipt QR, payment QR only when enabled, weekly vs monthly reporting.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('SAL', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);

  -- ---------------------------------------------------------------- quotation + order (F141–F143, F149)
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  insert into _r values ('S41-01', pg_temp.expect_fail(format($f$select api.v1_quotation_create(%L, '[{"product_id":"%s","qty":600,"price":100}]')$f$, dl, noodle), 'E_INSUFFICIENT_STOCK')
                                   and (api.v1_quotation_create(dl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 50, 'price', 100))) ->> 'total')::numeric = 5000,
                                   'a quotation never promises unavailable stock');
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 200)), null);
  insert into _r values ('S41-02', o1 ->> 'status' = 'pending_approval' and (o1 -> 'holds') ? 'credit' and (o1 ->> 'total')::numeric = 20000
                                   and not exists (select 1 from inventory.reservation where batch_ref like 'SO:%' and company_id = ca)
                                   and pg_temp.expect_fail(format($f$select api.v1_order_create(%L, %L, %L, '[{"product_id":"%s","qty":1,"price":90}]', null)$f$, dl, fgw, pl, noodle), 'E_REASON_REQUIRED'),
                                   'credit breach puts the order on hold; a changed price needs a reason');
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_fs, 'fs');
  insert into _r values ('S41-03', (select status from sales.sales_order where id = (o1 ->> 'order_id')::uuid) = 'allocated'
                                   and inventory.fn_available(ca, fgw, noodle) = 300
                                   and pg_temp.expect_fail(format($f$select api.v1_order_create(%L, %L, %L, '[{"product_id":"%s","qty":400}]', null)$f$, dl, fgw, pl, noodle), 'E_INSUFFICIENT_STOCK'),
                                   'approval allocates FG; nothing is oversold');
  o3 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 10, 'price', 90, 'override_reason', 'loyalty')), null);
  insert into _r values ('S41-04', (o3 -> 'holds') ? 'price_override'
                                   and (select (lines -> 0 ->> 'list_price')::numeric from sales.sales_order where id = (o3 ->> 'order_id')::uuid) = 100,
                                   'price override waits for approval and keeps the original price');
  -- ---------------------------------------------------------------- dispatch, delivery, invoice (F145–F147)
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S41-15', pg_temp.expect_fail(format($f$select api.v1_dispatch_post(%L, null, null)$f$, o1 ->> 'order_id'), 'E_NOT_PACKED')
                                   and api.v1_warehouse_board() -> 'waiting' -> 0 ->> 'stage' = 'to_pick'
                                   and pg_temp.expect_fail(format($f$select api.v1_order_pack(%L, 4)$f$, o1 ->> 'order_id'), 'E_INVALID_ACTION'),
                                   'order -> pick -> pack -> dispatch: nothing leaves before it is picked and packed');
  j := api.v1_order_pick((o1 ->> 'order_id')::uuid);
  perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 4);
  insert into _r values ('S41-16', j -> 'pick_list' -> 0 ->> 'lot_no' = 'N1' and (j -> 'pick_list' -> 0 ->> 'qty')::numeric = 200
                                   and api.v1_warehouse_board() -> 'waiting' -> 0 ->> 'stage' = 'packed',
                                   'the pick list follows FEFO; the board shows the stage');
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, 'DHA-1234', 'করিম');
  perform api.v1_delivery_confirm((ds ->> 'dispatch_id')::uuid, 'রহমান', repeat('ab', 32));
  insert into _r values ('S41-05', (select qty from inventory.stock_balance where warehouse_id = fgw and product_id = noodle) = 300 and pg_temp.bal(ca, '5100') = 12000
                                   and pg_temp.expect_fail(format($f$select api.v1_delivery_confirm(%L, 'x', null)$f$, ds ->> 'dispatch_id'), 'E_ALREADY_DELIVERED'),
                                   'dispatch decrements the allocated stock with COGS; delivery is confirmed once');
  perform pg_temp.as_user(u_ac, 'ac');
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);
  insert into _r values ('S41-06', sales.fn_dealer_balance(dl) = 20000 and pg_temp.bal(ca, '1300') = 20000 and pg_temp.bal(ca, '4100') = -20000
                                   and inv ->> 'qr' ~ '^MOS1\|I\|SAL\|' and pg_temp.expect_fail(format($f$select api.v1_invoice_post(%L)$f$, o1 ->> 'order_id'), 'E_INVALID_ACTION'),
                                   'one invoice per order: dealer ledger, AR and revenue together; signed QR');
  -- ---------------------------------------------------------------- return (F148, ADR-10)
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_sales_analysis(current_date - 1, current_date, 'product');
  insert into _r values ('S41-17', (j -> 'rows' -> 0 ->> 'amount')::numeric = 20000 and j -> 'rows' -> 0 ->> 'tag' = 'top' and j -> 'rows' -> 0 ->> 'key' = 'NOODLE'
                                   and api.v1_sales_analysis(current_date - 400, current_date - 300, 'dealer') ->> 'note_bn' = 'তথ্য নেই'
                                   and api.v1_invoice_print_design(inv ->> 'number') ->> 'design_code' = 'D01'
                                   and api.v1_invoice_print_design(inv ->> 'number') -> 'spec' ? 'accent',
                                   'sales analysis from posted invoices only (no data is said, not guessed); an invoice keeps its design');
  insert into _r values ('S41-07', pg_temp.expect_fail(format($f$select api.v1_sales_return(%L, %L, '[{"product_id":"%s","lot_id":"%s","qty":10}]', 'x')$f$, inv ->> 'invoice_id', fgw, noodle, lot), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_sales_return(%L, %L, '[{"product_id":"%s","lot_id":"%s","qty":300}]', 'x')$f$, inv ->> 'invoice_id', qw, noodle, lot), 'E_INVALID_ACTION'),
                                   'returns go to quarantine first and never exceed what was dispatched');
  j := api.v1_sales_return((inv ->> 'invoice_id')::uuid, qw, jsonb_build_array(jsonb_build_object('product_id', noodle, 'lot_id', lot, 'qty', 10, 'condition', 'damaged')), 'torn packs');
  insert into _r values ('S41-08', (j ->> 'credit')::numeric = 1000 and (j ->> 'cost')::numeric = 600 and sales.fn_dealer_balance(dl) = 19000
                                   and (select value from inventory.stock_balance where warehouse_id = qw and product_id = noodle) = 600,
                                   'credit note at the invoiced price; stock back at the original dispatch cost');
  -- ---------------------------------------------------------------- collections (F131–F139)
  perform pg_temp.as_user(u_fs, 'fs');
  c1 := api.v1_collection_record(dl, 'cash', 5000, null, null, jsonb_build_array(jsonb_build_object('invoice_id', inv ->> 'invoice_id', 'amount', 5000)));
  insert into _r values ('S41-09', c1 ->> 'status' = 'recorded' and sales.fn_dealer_balance(dl) = 19000
                                   and pg_temp.expect_fail(format($f$select api.v1_collection_verify(%L, %L, null)$f$, c1 ->> 'collection_id', cash), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail(format($f$select api.v1_collection_record(%L, 'cash', 100, null, null, '[{"invoice_id":"%s","amount":50000}]')$f$, dl, inv ->> 'invoice_id'), 'E_OVERPAYMENT'),
                                   'a recorded collection reduces nothing; the collector cannot verify; allocations stay within the invoice');
  perform pg_temp.as_user(u_ac, 'ac');
  perform api.v1_collection_verify((c1 ->> 'collection_id')::uuid, cash, null);
  perform pg_temp.as_user(u_fs, 'fs');
  c2 := api.v1_collection_record(dl, 'bank', 3000, 'TRX12345', 'screens/receipt.jpg', null);
  c3 := api.v1_collection_record(dl, 'bkash', 2000, 'BK123456', null, null);
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S41-10', sales.fn_dealer_balance(dl) = 14000 and pg_temp.bal(ca, '1100') = 5000
                                   and pg_temp.expect_fail(format($f$select api.v1_collection_verify(%L, null, null)$f$, c2 ->> 'collection_id'), 'E_UNVERIFIED_PAYMENT')
                                   and pg_temp.expect_fail(format($f$select api.v1_collection_verify(%L, null, null)$f$, c3 ->> 'collection_id'), 'E_UNVERIFIED_PAYMENT'),
                                   'cash verified by another person; a screenshot or an unconfirmed wallet payment never settles');
  perform api.v1_bank_statement_import(bank, jsonb_build_array(jsonb_build_object('date', current_date, 'amount', 3000, 'reference', 'TRX12345', 'description', 'dealer')));
  perform svc.v1_provider_confirm(ca, 'bkash', 'BK123456', 2000, '01711000999', 'verified');
  perform pg_temp.as_user(u_ac, 'ac');
  perform api.v1_collection_verify((c2 ->> 'collection_id')::uuid, null, (select id from finance.bank_statement_line where reference = 'TRX12345' and company_id = ca));
  perform api.v1_collection_verify((c3 ->> 'collection_id')::uuid, null, null);
  insert into _r values ('S41-11', sales.fn_dealer_balance(dl) = 9000 and pg_temp.bal(ca, '1110') = 5000,
                                   'bank and bKash settle only against the statement line / provider confirmation');
  perform pg_temp.as_user(u_fm, 'fm');
  j := api.v1_collection_reverse((c1 ->> 'collection_id')::uuid, 'counterfeit note found');
  insert into _r values ('S41-12', (j ->> 'balance')::numeric = 14000 and (select status from sales.collection where id = (c1 ->> 'collection_id')::uuid) = 'reversed'
                                   and pg_temp.bal(ca, '1100') = 0
                                   and pg_temp.expect_fail(format($f$select api.v1_collection_reverse(%L, 'x')$f$, c1 ->> 'collection_id'), 'E_NOT_FOUND'),
                                   'a posted receipt is reversed with entries, never deleted');
  -- ---------------------------------------------------------------- QR + reports + reconciliation (F136, F137, F140, F150)
  perform pg_temp.as_user(u_fs, 'fs');
  j := api.v1_receipt_qr_lookup(c2 ->> 'receipt_qr');
  insert into _r values ('S41-13', (j ->> 'amount')::numeric = 3000 and (j ->> 'verified')::boolean
                                   and pg_temp.expect_fail(format($f$select api.v1_receipt_qr_lookup(%L)$f$, replace(c2 ->> 'receipt_qr', '|R|', '|X|')), 'E_QR_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_payment_qr(%L, 500, 'bkash')$f$, dl), 'E_FEATURE_DISABLED'),
                                   'receipt QR shows the server''s amount; payment QR only with an enabled integration');
  j := api.v1_dealer_reconcile(dl);
  insert into _r values ('S41-14', pg_temp.expect_fail($q$select api.v1_sales_weekly(current_date - 70, current_date)$q$, 'E_REPORT_RANGE')
                                   and jsonb_array_length(api.v1_sales_weekly(current_date - 14, current_date)) >= 1
                                   and pg_temp.expect_fail($q$select api.v1_sales_monthly(null)$q$, 'E_FORBIDDEN')
                                   and (j ->> 'ledger_balance')::numeric = 14000,
                                   'weekly figures in short windows for field staff, no monthly view; reconciliation shows ledger vs invoices');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

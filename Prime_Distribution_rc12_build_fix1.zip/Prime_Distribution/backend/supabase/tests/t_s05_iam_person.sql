-- S05 tests: person, 1:1 login link, memberships, caller identity, identity audit chain.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid) returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true); perform set_config('request.jwt.claims', case when p is null then '' else json_build_object('sub', p, 'role', 'authenticated')::text end, true); end $$;
do $$
declare ca uuid; cb uuid; u1 uuid := gen_random_uuid(); u2 uuid := gen_random_uuid(); u3 uuid := gen_random_uuid();
        p1 uuid; p2 uuid; m1 uuid; m2 uuid; w jsonb; e0 integer; e1 integer; bad bigint; actor uuid;
begin
  insert into core.company (code, name_bn, status) values ('IA', 'ক', 'active') returning id into ca;
  insert into core.company (code, name_bn, status) values ('IB', 'খ', 'active') returning id into cb;
  p1 := svc.v1_iam_provision_person('রহিম', '+8801711000001', 'rahim@example.com', u1, 'test provisioning');
  p2 := svc.v1_iam_provision_person('করিম', null, null, u2, 'test provisioning');
  m1 := svc.v1_iam_add_membership(p1, ca, 'E-1', 'join A');
  m2 := svc.v1_iam_add_membership(p1, cb, 'E-1', 'join B');
  perform svc.v1_iam_add_membership(p2, ca, 'E-2', 'join A');

  perform pg_temp.as_user(u1);
  w := api.v1_iam_whoami();
  insert into _r values ('S05-01', (w -> 'person' ->> 'id')::uuid = p1 and jsonb_array_length(w -> 'memberships') = 2, 'one login sees its person and both memberships');
  insert into _r values ('S05-14', not (w::text like '%E-2%') and not (w::text like '%করিম%'), 'whoami reveals nothing about other persons');
  insert into _r values ('S05-13', (select count(*) from iam.company_membership where employee_no = 'E-1') = 2, 'same employee_no allowed in two different companies');
  insert into _r values ('S05-07', pg_temp.expect_fail(format($f$insert into iam.company_membership (person_id, company_id) values (%L,%L)$f$, p1, ca)), 'second open membership in the same company rejected');
  insert into _r values ('S05-16', pg_temp.expect_fail(format($f$insert into iam.company_membership (person_id, company_id, employee_no) values (%L,%L,'E-2')$f$, p1, ca)), 'employee_no unique inside a company');

  insert into _r values ('S05-02', pg_temp.expect_fail(format($f$select svc.v1_iam_provision_person('x', null, null, %L, 'r')$f$, u1), 'E_DUPLICATE'), 'one auth user cannot be linked to two persons');
  insert into _r values ('S05-03', pg_temp.expect_fail(format($f$insert into iam.person_auth_link (person_id, auth_user_id) values (%L,%L)$f$, p1, u3)), 'one person cannot have two active logins');
  insert into _r values ('S05-12', pg_temp.expect_fail(format($f$select svc.v1_iam_add_membership(%L,%L,null,'  ')$f$, p2, cb), 'E_REASON_REQUIRED'), 'privileged identity changes require a reason');

  -- membership change is audited in the company chain with the acting person
  update iam.company_membership set status = 'suspended' where id = m2;
  select actor_person_id into actor from audit.event where company_id = cb and entity_id = m2 order by seq desc limit 1;
  insert into _r values ('S05-11', actor = p1 and audit.fn_verify_chain(cb) is null, 'membership change audited in company chain with actor person');

  select authz_epoch into e0 from core.person where id = p1;
  perform svc.v1_iam_end_membership(m2, current_date, 'left company B');
  select authz_epoch into e1 from core.person where id = p1;
  w := api.v1_iam_whoami();
  insert into _r values ('S05-08', e1 > e0 and jsonb_array_length(w -> 'memberships') = 1
                                   and pg_temp.expect_fail(format($f$update iam.company_membership set status='active', ended_on=null, end_reason=null where id=%L$f$, m2), 'E_MEMBERSHIP_ENDED'),
                                   'ended membership leaves whoami, bumps authz_epoch and cannot be revived');
  insert into _r values ('S05-09', pg_temp.expect_fail(format($f$update iam.company_membership set company_id=%L where id=%L$f$, cb, m1), 'E_IMMUTABLE'), 'membership cannot move to another company');

  perform pg_temp.as_user(gen_random_uuid());
  insert into _r values ('S05-06', pg_temp.expect_fail('select api.v1_iam_whoami()', 'E_AUTH'), 'unknown login gets E_AUTH');
  perform set_config('request.jwt.claims', '{not json', true);
  insert into _r values ('S05-06', pg_temp.expect_fail('select api.v1_iam_whoami()', 'E_AUTH'), 'malformed claims get E_AUTH');

  perform svc.v1_iam_relink_login(p2, u3, 'lost phone, new login');
  perform pg_temp.as_user(u2);
  insert into _r values ('S05-04', pg_temp.expect_fail('select api.v1_iam_whoami()', 'E_AUTH'), 'revoked login gets E_AUTH');
  perform pg_temp.as_user(u3);
  insert into _r values ('S05-15', (api.v1_iam_whoami() -> 'person' ->> 'id')::uuid = p2
                                   and (select count(*) from iam.person_auth_link where person_id = p2) = 2
                                   and pg_temp.expect_fail(format($f$update iam.person_auth_link set status='active', revoked_at=null where person_id=%L and auth_user_id=%L$f$, p2, u2), 'E_IMMUTABLE'),
                                   'relink keeps history; revoked link is frozen');

  update core.person set status = 'disabled' where id = p2;
  insert into _r values ('S05-05', pg_temp.expect_fail('select api.v1_iam_whoami()', 'E_AUTH'), 'disabled person gets E_AUTH');
  insert into _r values ('S05-17', pg_temp.expect_fail(format($f$delete from core.person where id=%L$f$, p2), 'E_NO_DELETE'), 'persons are never deleted');

  insert into _r values ('S05-10', audit.fn_verify_global_chain() is null and (select count(*) from audit.global_event) >= 6, 'identity changes are in a valid global chain');
  alter table audit.global_event disable trigger trg_global_event_no_mutation;
  update audit.global_event set reason = 'tampered' where seq = (select min(seq) from audit.global_event);
  alter table audit.global_event enable trigger trg_global_event_no_mutation;
  bad := audit.fn_verify_global_chain();
  insert into _r values ('S05-18', bad is not null, 'tampering in the global chain is detected (at ' || coalesce(bad::text, 'null') || ')');
  perform pg_temp.as_user(null);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

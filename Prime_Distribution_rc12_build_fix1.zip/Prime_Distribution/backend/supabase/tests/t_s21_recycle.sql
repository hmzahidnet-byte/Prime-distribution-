-- S21 tests: drafts only, masked listing, restore with today's rights, conflicts, legal hold (independent release),
-- bulk restore all-or-nothing, purge = request + two approvals + delay (history kept), retention, attachments, evidence.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.srv(p uuid) returns integer language sql as $$ select row_version from config.form_submission where id = p $$;
create or replace function pg_temp.frv(p uuid) returns integer language sql as $$ select row_version from config.form where id = p $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_md uuid; a_ac uuid; a_au uuid; a_fs uuid; a_fm uuid; p_ch uuid; p_md uuid; p_ac uuid; p_au uuid; p_fs uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_au uuid := gen_random_uuid();
        u_fs uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fid uuid; d1 uuid; d2 uuid; d3 uuid; d4 uuid; d5 uuid; dfs uuid; i1 uuid; i2 uuid; i3 uuid; i5 uuid; ifs uuid; att uuid; iatt uuid; hold uuid; req uuid;
        j jsonb; j1 jsonb;
        def jsonb := '{"fields":[{"key":"note","type":"text","label_bn":"মন্তব্য"},{"key":"pic","type":"photo","label_bn":"ছবি"}]}';
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('RCY', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');   a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_au := svc.v1_iam_provision_person('নিরীক্ষক', null, null, u_au, 't'); a_au := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_au, ca, null, 't'), 'AUDITOR', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't');    a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't');   a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  fid := (api.v1_forms_save_version('NOTE', 'নোট', null, def, 'x') ->> 'form_id')::uuid;
  perform api.v1_forms_action(fid, 'publish', 1, pg_temp.frv(fid), 'x');
  perform api.v1_iam_set_position_rule('FIELD_SALES', 'recycle.bin.read', 'allow', 'COMPANY', null, 'sees the bin');
  perform api.v1_iam_set_position_rule('FIN_MANAGER', 'recycle.purge.approve', 'allow', 'COMPANY', null, 'second approver');
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  dfs := (api.v1_forms_submission_save(fid, null, '{"note":"fs"}', null, null, null) ->> 'submission_id')::uuid;
  ifs := (api.v1_recycle_delete('forms.draft', dfs, 'mine') ->> 'item_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  d1 := (api.v1_forms_submission_save(fid, null, '{"note":"এক"}', null, null, null) ->> 'submission_id')::uuid;
  d2 := (api.v1_forms_submission_save(fid, null, '{"note":"দুই"}', null, null, null) ->> 'submission_id')::uuid;
  d3 := (api.v1_forms_submission_save(fid, null, '{"note":"তিন"}', null, null, null) ->> 'submission_id')::uuid;
  d4 := (api.v1_forms_submission_save(fid, null, '{"note":"চার"}', null, null, null) ->> 'submission_id')::uuid;
  d5 := (api.v1_forms_submission_save(fid, null, '{"note":"পাঁচ"}', null, null, null) ->> 'submission_id')::uuid;
  perform api.v1_forms_submission_submit(d4, pg_temp.srv(d4));
  i1 := (api.v1_recycle_delete('forms.draft', d1, 'not needed') ->> 'item_id')::uuid;
  insert into _r values ('S21-01', (select status from config.form_submission where id = d1) = 'cancelled'
                                   and pg_temp.expect_fail(format($f$select api.v1_recycle_delete('forms.draft', %L, 'x')$f$, d4), 'E_RECYCLE_NOT_ELIGIBLE'),
                                   'only unposted drafts enter the bin');
  -- ---------------------------------------------------------------- listing (masked) + restore with today's rights
  j := api.v1_recycle_list(null, 'in_bin', 100);
  perform pg_temp.as_user(u_fs, 'fs');
  j1 := api.v1_recycle_list(null, 'in_bin', 100);
  insert into _r values ('S21-02', exists (select 1 from jsonb_array_elements(j) x where (x ->> 'id')::uuid = i1 and not (x ->> 'masked')::boolean)
                                   and not exists (select 1 from jsonb_array_elements(j) x where (x ->> 'id')::uuid = ifs)
                                   and exists (select 1 from jsonb_array_elements(j1) x where (x ->> 'id')::uuid = i1 and (x ->> 'masked')::boolean and x ->> 'label_bn' = '[গোপন]'),
                                   'company-scoped bin; entries the reader may not open are masked');
  j := api.v1_recycle_restore(i1, 'try');
  perform pg_temp.as_user(u_ac, 'ac');
  j1 := api.v1_recycle_restore(i1, 'needed after all');
  insert into _r values ('S21-03', j ->> 'status' = 'denied' and j ->> 'reason' = 'forbidden' and j1 ->> 'status' = 'restored'
                                   and (select status from config.form_submission where id = d1) = 'draft'
                                   and exists (select 1 from core.recycle_event e where e.item_id = i1 and e.action = 'restore_denied'),
                                   'restore re-checks today''s rights; refusals leave evidence');
  -- ---------------------------------------------------------------- conflict
  i2 := (api.v1_recycle_delete('forms.draft', d2, 'x') ->> 'item_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_action(fid, 'archive', null, pg_temp.frv(fid), 'pause');
  perform pg_temp.as_user(u_ac, 'ac');
  j := api.v1_recycle_restore(i2, 'back');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_action(fid, 'restore', null, pg_temp.frv(fid), 'resume');
  perform pg_temp.as_user(u_ac, 'ac');
  j1 := api.v1_recycle_restore(i2, 'back now');
  insert into _r values ('S21-04', j ->> 'status' = 'conflict' and j ->> 'conflict' = 'parent_archived' and j1 ->> 'status' = 'restored',
                                   'a conflict stays in the bin until resolved by hand');
  -- ---------------------------------------------------------------- legal hold
  perform pg_temp.as_user(u_au, 'au'); perform api.v1_iam_select_position(a_au);
  hold := (api.v1_recycle_hold('forms.draft', null, 'tax inquiry') ->> 'hold_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S21-05', pg_temp.expect_fail(format($f$select api.v1_recycle_delete('forms.draft', %L, 'x')$f$, d3), 'E_LEGAL_HOLD'), 'a hold freezes deletion');
  perform pg_temp.as_user(u_au, 'au');
  insert into _r values ('S21-06', pg_temp.expect_fail(format($f$select api.v1_recycle_release_hold(%L, 'x')$f$, hold), 'E_SELF_APPROVAL'), 'the placer cannot release their own hold');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_recycle_release_hold(hold, 'inquiry closed');
  -- ---------------------------------------------------------------- bulk restore
  perform pg_temp.as_user(u_ac, 'ac');
  i3 := (api.v1_recycle_delete('forms.draft', d3, 'x') ->> 'item_id')::uuid;
  i5 := (api.v1_recycle_delete('forms.draft', d5, 'x') ->> 'item_id')::uuid;
  j := api.v1_recycle_restore_bulk(array[i3, ifs], 'bulk');
  j1 := api.v1_recycle_restore_bulk(array[i3, i5], 'bulk');
  insert into _r values ('S21-07', j ->> 'status' = 'nothing_restored' and jsonb_array_length(j -> 'denied') = 1 and (j -> 'denied' -> 0 ->> 'item_id')::uuid = ifs
                                   and j1 ->> 'status' = 'all_restored' and (select status from config.form_submission where id = d3) = 'draft',
                                   'bulk restore is all-or-nothing and reports every refusal');
  -- ---------------------------------------------------------------- purge: request, two approvals, delay; history kept
  i1 := (api.v1_recycle_delete('forms.draft', d1, 'final') ->> 'item_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  req := (api.v1_recycle_request_purge(i1, 'personal data') ->> 'request_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_recycle_approve_purge(req, 'ok');
  insert into _r values ('S21-08', pg_temp.expect_fail(format($f$select api.v1_recycle_approve_purge(%L, 'again')$f$, req), 'E_SELF_APPROVAL'), 'two DIFFERENT approvers');
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  j := api.v1_recycle_approve_purge(req, 'ok too');
  j1 := svc.v1_recycle_run();
  insert into _r values ('S21-09', j ->> 'status' = 'approved' and (j1 ->> 'purged_by_request')::integer = 0 and (select status from core.recycle_item where id = i1) = 'in_bin',
                                   'nothing is purged before the delay');
  update core.purge_request set not_before = clock_timestamp() - interval '1 minute' where id = req;
  j1 := svc.v1_recycle_run();
  insert into _r values ('S21-10', (j1 ->> 'purged_by_request')::integer = 1 and (select status from core.recycle_item where id = i1) = 'purged'
                                   and (select field_values from config.form_submission where id = d1) = '{}'::jsonb
                                   and exists (select 1 from config.form_submission_revision r where r.submission_id = d1 and r.values_after ->> 'note' = 'এক')
                                   and pg_temp.expect_fail($q$delete from core.recycle_event$q$, 'E_APPEND_ONLY'),
                                   'purge erases the record content; audit and history are never purged');
  -- ---------------------------------------------------------------- retention + hold beats purge
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_recycle_set_retention('forms.draft', 1, 'short');
  perform pg_temp.as_user(u_ac, 'ac');
  i2 := (api.v1_recycle_delete('forms.draft', d2, 'x') ->> 'item_id')::uuid;
  perform pg_temp.as_user(u_au, 'au');
  perform api.v1_recycle_hold(null, d2, 'keep this one');
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S21-11', (select purge_after between clock_timestamp() + interval '23 hours' and clock_timestamp() + interval '25 hours' from core.recycle_item where id = i2)
                                   and pg_temp.expect_fail(format($f$select api.v1_recycle_request_purge(%L, 'x')$f$, i2), 'E_LEGAL_HOLD'),
                                   'retention per class sets the purge date; a held record cannot be purged');
  -- ---------------------------------------------------------------- attachments (F198)
  perform pg_temp.as_user(u_ac, 'ac');
  att := (api.v1_forms_attachment_begin(fid, 'pic', 'image/jpeg', 1000, repeat('cd', 32)) ->> 'attachment_id')::uuid;
  perform api.v1_forms_attachment_confirm(att);
  iatt := (api.v1_recycle_delete('forms.attachment', att, 'wrong photo') ->> 'item_id')::uuid;
  j := jsonb_build_object('binned', (select status from config.form_attachment where id = att));
  j1 := api.v1_recycle_restore(iatt, 'right photo after all');
  perform api.v1_forms_submission_save(null, d3, jsonb_build_object('pic', att), null, pg_temp.srv(d3), null);
  insert into _r values ('S21-12', j ->> 'binned' = 'rejected' and j1 ->> 'status' = 'restored' and (select status from config.form_attachment where id = att) = 'linked'
                                   and pg_temp.expect_fail(format($f$select api.v1_recycle_delete('forms.attachment', %L, 'x')$f$, att), 'E_RECYCLE_NOT_ELIGIBLE'),
                                   'unlinked uploads go to the bin and come back with their file; linked ones stay');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S66 tests (ধাপ ৪ক: V161/V162 dealer portal, docs/V180_FEATURE_AUDIT_BN.md): dealer invitation and own-only access, order request ->
-- staff order, delivery acknowledgement with issues, payment report (no due reduction before verification), notices and offers with maker-checker.
-- Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        u_dl uuid := gen_random_uuid(); inv1 jsonb; du uuid; dp uuid; da uuid; rq jsonb; dl2 uuid; nt uuid; nt2 uuid; od uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- ---------------------------------------------------------------- 01 invitation
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  dl2 := (api.v1_dealer_save(null, 'D2', 'করিম এন্টারপ্রাইজ', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  insert into _r values ('S66-01', pg_temp.expect_fail(format($f$select api.v1_dealer_portal_invite(%L, 'রহমান', '123', 'owner', 'x')$f$, dl), 'E_CONTACT_REQUIRED')
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_portal_invite(%L, 'রহমান', '01711000001', 'boss', 'x')$f$, dl), 'E_INVALID_ACTION'),
                                   'a dealer login needs a valid phone and a known role');
  inv1 := api.v1_dealer_portal_invite(dl, 'আব্দুর রহমান', '01711000001', 'owner', 'dealer app access');
  du := (inv1 ->> 'dealer_user_id')::uuid; dp := (inv1 ->> 'person_id')::uuid;
  da := (select assignment_id from sales.dealer_user where id = du);
  insert into _r values ('S66-02', (select member_kind from iam.company_membership where person_id = dp and company_id = ca) = 'dealer'
                                   and (select position_code from iam.position_assignment where id = da) = 'DEALER_PORTAL'
                                   and exists (select 1 from iam.login_invitation where id = (inv1 ->> 'invitation_id')::uuid and status = 'open')
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_portal_invite(%L, 'আব্দুর রহমান', '01711000001', 'owner', 'again')$f$, dl), 'E_DUPLICATE'),
                                   'an invited dealer gets a dealer membership, the DEALER_PORTAL position and an invitation; once only');
  insert into iam.person_auth_link (person_id, auth_user_id) values (dp, u_dl);

  -- ---------------------------------------------------------------- 08 notices (staff side, maker-checker)
  nt := (api.v1_dealer_notice_save('offer', 'ঈদ অফার', '১০ কার্টনে ১ কার্টন ফ্রি', 'media/eid.png', 'image/png', 'ঈদের অফারের ছবি', null, '{"min_order_amount": 10000}'::jsonb,
                                   current_date, current_date + 10) ->> 'notice_id')::uuid;
  nt2 := (api.v1_dealer_notice_save('notice', 'শুধু করিম', 'x', null, null, null, jsonb_build_object('dealer_ids', jsonb_build_array(dl2)), null, current_date, current_date + 10) ->> 'notice_id')::uuid;
  insert into _r values ('S66-03', pg_temp.expect_fail(format($f$select api.v1_dealer_notice_publish(%L)$f$, nt), 'E_SELF_APPROVAL')
                                   and pg_temp.expect_fail($q$select api.v1_dealer_notice_save('notice', 't', 'b', 'media/x.bmp', 'image/bmp', 'x', null, null, null, null)$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail($q$select api.v1_dealer_notice_save('notice', 't', 'b', 'media/x.png', 'image/png', '', null, null, null, null)$q$, 'E_INVALID_ACTION'),
                                   'another person publishes; only JPG / PNG / GIF, always with a Bengali description');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_dealer_notice_publish(nt); perform api.v1_dealer_notice_publish(nt2);

  -- ---------------------------------------------------------------- 02 / 04 the dealer's own app
  perform pg_temp.as_user(u_dl, 'dl'); perform api.v1_iam_select_position(da);
  j := api.v1_dealer_home();
  insert into _r values ('S66-04', j ->> 'dealer' like 'D1 · %' and (j ->> 'due')::numeric = 0 and jsonb_array_length(j -> 'notices') = 1
                                   and j -> 'notices' -> 0 ->> 'title' = 'ঈদ অফার' and (j -> 'products' -> 0 ->> 'available')::boolean,
                                   'the dealer sees only the own dealer, own notices and product availability (no quantities)');
  insert into _r values ('S66-05', pg_temp.expect_fail(format($f$select api.v1_dealer_notice_read(%L)$f$, nt2), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail(format($f$select api.v1_order_create(%L, %L, %L, '[{"product_id":"%s","qty":1}]', null)$f$, dl, fgw, pl, noodle))
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_portal_users(%L)$f$, dl))
                                   and pg_temp.expect_fail($q$select api.v1_dealer_notice_save('notice', 't', 'b', null, null, null, null, null, null, null)$q$),
                                   'another dealer''s notice is not found; staff functions are refused to the dealer');
  perform api.v1_dealer_notice_read(nt);
  rq := api.v1_dealer_order_request(jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 100)), 'ঈদের আগে চাই', 'REQ-0000001');
  j1 := api.v1_dealer_order_request(jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 100)), 'ঈদের আগে চাই', 'REQ-0000001');
  insert into _r values ('S66-06', (j1 ->> 'duplicate')::boolean and (j1 ->> 'request_id') = (rq ->> 'request_id')
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_order_request('[{"product_id":"%s","qty":0}]', null, 'REQ-0000002')$f$, noodle), 'E_INVALID_ACTION')
                                   and (select count(*) from sales.sales_order where dealer_id = dl) = 0,
                                   'a request is stored once; it is not an order until sales staff accept it');

  -- ---------------------------------------------------------------- staff accept -> normal order -> dispatch -> dealer acknowledges
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S66-07', pg_temp.expect_fail(format($f$select api.v1_dealer_order_request_decide(%L, false, null, null, '')$f$, rq ->> 'request_id'), 'E_REASON_REQUIRED'),
                                   'a rejected request carries the reason for the dealer');
  j := api.v1_dealer_order_request_decide((rq ->> 'request_id')::uuid, true, fgw, pl, 'ok');
  od := (j -> 'order' ->> 'order_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  if (select status from sales.sales_order where id = od) = 'pending_approval' then perform pg_temp.approve_pending(od); end if;
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_order_pick(od); perform api.v1_order_pack(od, 2);
  ds := api.v1_dispatch_post(od, 'DHA-9', null);
  perform pg_temp.as_user(u_dl, 'dl');
  insert into _r values ('S66-08', (select status from sales.dealer_order_request where id = (rq ->> 'request_id')::uuid) = 'accepted'
                                   and (select total from sales.sales_order where id = od) = 10000
                                   and jsonb_array_length(api.v1_dealer_home() -> 'dispatches') = 1
                                   and pg_temp.expect_fail(format($f$select api.v1_dealer_delivery_ack(%L, '[{"kind":"lost","product_id":"%s","qty":1,"note":"x"}]')$f$, ds ->> 'dispatch_id', noodle), 'E_INVALID_ACTION'),
                                   'the accepted request became a normal order at list price; the dealer follows the dispatch');
  perform api.v1_dealer_delivery_ack((ds ->> 'dispatch_id')::uuid, jsonb_build_array(jsonb_build_object('kind', 'damaged', 'product_id', noodle, 'qty', 2, 'note', 'দুটি পলি ছেঁড়া')));
  insert into _r values ('S66-09', (select delivered_at is not null from sales.dispatch where id = (ds ->> 'dispatch_id')::uuid)
                                   and (select count(*) from sales.delivery_issue where dispatch_id = (ds ->> 'dispatch_id')::uuid) = 1
                                   and pg_temp.bal(ca, '5100') = 6000 and pg_temp.bal(ca, '1240') = 0,
                                   'the dealer''s receipt passes control (COGS recognised); damage is reported for staff follow-up');

  -- ---------------------------------------------------------------- 07 payment report / 06 ledger
  j := api.v1_dealer_payment_report('bkash', 1000, 'BK12345678', 'proof/bk.jpg');
  insert into _r values ('S66-10', j ->> 'status' = 'recorded' and sales.fn_dealer_balance(dl) = 0
                                   and pg_temp.expect_fail($q$select api.v1_dealer_payment_report('bkash', 1000, 'BK12345678', null)$q$, 'E_DUPLICATE')
                                   and pg_temp.expect_fail($q$select api.v1_dealer_payment_report('bkash', 1000, '1', null)$q$, 'E_INVALID_ACTION')
                                   and (api.v1_dealer_my_ledger(null, null) ->> 'closing')::numeric = 0,
                                   'a reported payment reduces nothing until staff verify it; a reference is used once');

  -- ---------------------------------------------------------------- 08 withdraw + 01 suspension
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_dealer_notice_withdraw(nt, 'offer ended early');
  insert into _r values ('S66-11', (j ->> 'read_by')::int = 1
                                   and pg_temp.expect_fail(format($f$update sales.dealer_notice set title_bn = 'x' where id = %L$f$, nt2), 'E_IMMUTABLE'),
                                   'read acknowledgements are kept; a published notice is never edited');
  perform api.v1_dealer_portal_user_action(du, 'suspend', 'dues overdue');
  perform pg_temp.as_user(u_dl, 'dl');
  insert into _r values ('S66-12', pg_temp.expect_fail('select api.v1_dealer_home()'), 'a suspended dealer user is refused at once');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

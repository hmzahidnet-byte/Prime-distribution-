-- S20 tests: periods, KPI visibility (default list, factory P&L), restricted figures, live measures + authorised
-- drilldown, cache invalidation by authz_epoch, products incl. zero, closed months, styles, export redaction,
-- company KPIs, dashboard safety widget + ad rules, ad media, wing scope.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.kv(j jsonb, p_code text) returns jsonb language sql as $$
  select x from jsonb_array_elements(j) x where x ->> 'code' = p_code limit 1 $$;
do $$
declare boot jsonb; ca uuid; w1 uuid; a_ch uuid; a_md uuid; a_ac uuid; a_au uuid; a_wh uuid; p_ch uuid; p_md uuid; p_ac uuid; p_au uuid; p_wh uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_au uuid := gen_random_uuid(); u_wh uuid := gen_random_uuid();
        j jsonb; j1 jsonb; j2 jsonb; per jsonb; codes text[] := array['sales.amount','mfg.factory_pnl','approvals.pending','hr.headcount'];
        dash jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('KPI', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  p_au := svc.v1_iam_provision_person('নিরীক্ষক', null, null, u_au, 't');
  p_wh := svc.v1_iam_provision_person('উইং', null, null, u_wh, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  a_au := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_au, ca, null, 't'), 'AUDITOR', null, null, null, null, null, 't');
  a_wh := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_wh, ca, null, 't'), 'WING_HEAD', null, null, null, w1, null, 't');

  per := report.fn_period(ca, 'last_month', null, null);
  insert into _r values ('S20-01', (per ->> 'to')::date = (date_trunc('month', current_date) - interval '1 day')::date
                                   and (report.fn_period(ca, 'this_week', null, null) ->> 'from')::date <= current_date
                                   and extract(dow from (report.fn_period(ca, 'this_week', null, null) ->> 'from')::date) = 6
                                   and pg_temp.expect_fail(format($f$select report.fn_period(%L, 'custom', current_date - 400, current_date)$f$, ca), 'E_INVALID_ACTION'),
                                   'periods: Saturday-start week, last month, bounded custom range');
  -- ---------------------------------------------------------------- values and visibility
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_kpi_record_value('sales.amount', current_date, 1000, null, null, 'daily sales');
  perform api.v1_kpi_record_value('mfg.factory_pnl', current_date, 250, null, null, 'factory');
  perform core.fn_approval_submit(ca, 'test.document', gen_random_uuid(), 100, iam.fn_resource(ca), '{}'::jsonb);
  j := api.v1_kpi_drilldown('approvals.pending', 'today', null, null, null, 50);
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  j1 := api.v1_kpi_values(codes, 'today', null, null, null);
  j2 := api.v1_kpi_drilldown('approvals.pending', 'today', null, null, null, 50);
  insert into _r values ('S20-02', (pg_temp.kv(j1, 'sales.amount') ->> 'value')::numeric = 1000 and (pg_temp.kv(j1, 'mfg.factory_pnl') ->> 'value')::numeric = 250
                                   and (pg_temp.kv(j1, 'approvals.pending') ->> 'value')::numeric = 1 and (pg_temp.kv(j1, 'hr.headcount') ->> 'value')::numeric >= 5
                                   and jsonb_array_length(j2) = 1 and jsonb_array_length(j) = 0,
                                   'MD sees the figures; drilldown lists only what the caller may decide (the maker sees none)');
  perform pg_temp.as_user(u_au, 'au'); perform api.v1_iam_select_position(a_au);
  j := api.v1_kpi_values(codes, 'today', null, null, null);
  insert into _r values ('S20-03', (pg_temp.kv(j, 'sales.amount') ->> 'restricted')::boolean and not (pg_temp.kv(j, 'sales.amount') ? 'value')
                                   and (pg_temp.kv(j, 'mfg.factory_pnl') ->> 'restricted')::boolean
                                   and not exists (select 1 from jsonb_array_elements(api.v1_kpi_catalog()) x where x ->> 'code' in ('mfg.factory_pnl','sales.amount')),
                                   'restricted KPIs never carry a number and are not even listed');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('access.factory_pnl.positions', '["CHAIRMAN"]'::jsonb, 0, 'only the Chairman');
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_kpi_values(array['mfg.factory_pnl','sales.amount'], 'today', null, null, null);
  insert into _r values ('S20-04', (pg_temp.kv(j, 'mfg.factory_pnl') ->> 'restricted')::boolean and not (pg_temp.kv(j, 'sales.amount') ->> 'restricted')::boolean,
                                   'factory P&L follows the Chairman setting at once');
  -- ---------------------------------------------------------------- cache invalidated by permission change (F057)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_iam_set_position_rule('MD', 'iam.salary.read', 'allow', 'COMPANY', null, 'pay review');
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_kpi_values(array['sales.amount'], 'today', null, null, null);
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_kpi_set_visibility('sales.amount', 'MD', false, 0, 'hide from MD');
  perform pg_temp.as_user(u_md, 'md');
  j1 := api.v1_kpi_values(array['sales.amount'], 'today', null, null, null);
  insert into _r values ('S20-05', not (pg_temp.kv(j, 'sales.amount') ->> 'cached')::boolean and (pg_temp.kv(j1, 'sales.amount') ->> 'restricted')::boolean,
                                   'a permission change (authz_epoch) or visibility change makes cached figures unreachable');
  -- ---------------------------------------------------------------- products, closed months, styles
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_kpi_set_product('P1', 'চাল', null, 1, true, 'x');
  perform api.v1_kpi_set_product('P2', 'ডাল', null, 2, true, 'x');
  perform api.v1_kpi_set_product('P3', 'তেল', null, 3, true, 'x');
  perform api.v1_kpi_record_value('sales.amount', current_date, 500, null, 'P1', 'by product');
  j := api.v1_kpi_breakdown('sales.amount', 'today', null, null, null);
  insert into _r values ('S20-06', jsonb_array_length(j) = 3 and (pg_temp.kv((select jsonb_agg(x || jsonb_build_object('code', x ->> 'product_key')) from jsonb_array_elements(j) x), 'P2') ->> 'value')::numeric = 0
                                   and (pg_temp.kv((select jsonb_agg(x || jsonb_build_object('code', x ->> 'product_key')) from jsonb_array_elements(j) x), 'P1') ->> 'value')::numeric = 500,
                                   'every product appears, zero when it has no value');
  perform api.v1_kpi_close_period((date_trunc('month', current_date) - interval '1 month')::date, 'month audited');
  insert into _r values ('S20-07', pg_temp.expect_fail($q$select api.v1_kpi_record_value('sales.amount', (date_trunc('month', current_date) - interval '5 days')::date, 1, null, null, 'late')$q$, 'E_PERIOD_CLOSED')
                                   and pg_temp.expect_fail($q$select api.v1_kpi_close_period(current_date, 'x')$q$, 'E_INVALID_ACTION'),
                                   'a closed month is final; the running month cannot be closed');
  insert into _r values ('S20-08', pg_temp.expect_fail($q$select api.v1_kpi_set_style('sales.amount', '{"color":"bad"}', 0, 'x')$q$, 'E_DESIGN_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_kpi_set_style('sales.amount', '{"color":"#FF0000"}', 0, 'x')$q$, 'E_DESIGN_INVALID')
                                   and api.v1_kpi_set_style('sales.amount', '{"chart":"bar","size":"l","color":"chart3"}', 0, 'bigger') = 1,
                                   'styles use semantic colours only; alert colours stay reserved');
  insert into _r values ('S20-09', (api.v1_kpi_define('custom.visits', 'দোকান-পরিদর্শন', 'দিনের পরিদর্শন', 'count', 'sum', 'SALES_MANAGER', null, false, 300, 'field KPI') ->> 'code') = 'custom.visits'
                                   and pg_temp.expect_fail($q$select api.v1_kpi_define('sales.fake','x','x','count','sum',null,null,false,300,'x')$q$, 'E_INVALID_ACTION'),
                                   'company KPIs live under custom.* only');
  -- ---------------------------------------------------------------- export (F060)
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_kpi_export(array['mfg.factory_pnl','approvals.pending'], 'today', null, null, null, 'pdf');
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  insert into _r values ('S20-10', (j -> 'redacted') ? 'mfg.factory_pnl' and pg_temp.kv(j -> 'rows', 'mfg.factory_pnl') ->> 'value' = '[গোপন]'
                                   and (select count(*) from report.export_log l where l.company_id = ca) = 1
                                   and pg_temp.expect_fail($q$select api.v1_kpi_export(array['sales.amount'], 'today', null, null, null, 'pdf')$q$, 'E_FORBIDDEN'),
                                   'exports redact restricted figures and are logged; exporting needs its own permission');
  -- ---------------------------------------------------------------- wing scope
  perform pg_temp.as_user(u_wh, 'wh'); perform api.v1_iam_select_position(a_wh);
  insert into _r values ('S20-11', pg_temp.expect_fail($q$select api.v1_kpi_values(array['sales.amount'], 'today', null, null, null)$q$, 'E_FORBIDDEN')
                                   and (pg_temp.kv(api.v1_kpi_values(array['sales.amount'], 'today', null, null, w1), 'sales.amount') ->> 'restricted')::boolean = false,
                                   'a wing head reads KPIs for the own wing only');
  -- ---------------------------------------------------------------- dashboards: safety widget, ads (F058/F059)
  perform pg_temp.as_user(u_ch, 'ch');
  dash := jsonb_build_object('breakpoints', jsonb_build_object('phone', jsonb_build_object('columns', 4, 'widgets', jsonb_build_array(
            design.fn_w('sales', 'kpi', 0, 0, 4, 1, 'kpi.sales_amount')))));
  j := api.v1_design_layout_save('dashboard.md', dash, null, 'no approvals');
  insert into _r values ('S20-12', not (j -> 'report' ->> 'ok')::boolean
                                   and not (design.fn_layout_report(jsonb_build_object('breakpoints', jsonb_build_object('phone', jsonb_build_object('columns', 4, 'widgets', jsonb_build_array(
                                         design.fn_w('ad1', 'ad_slot', 0, 0, 4, 1), design.fn_w('ap', 'approval', 0, 1, 4, 1))))), 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(jsonb_build_object('breakpoints', jsonb_build_object('phone', jsonb_build_object('columns', 4, 'widgets', jsonb_build_array(
                                         design.fn_w('ap', 'approval', 0, 0, 4, 1), design.fn_w('a1', 'ad_slot', 0, 1, 1, 1), design.fn_w('a2', 'ad_slot', 1, 1, 1, 1),
                                         design.fn_w('a3', 'ad_slot', 2, 1, 1, 1), design.fn_w('a4', 'ad_slot', 3, 1, 1, 1))))), 0, 4) ->> 'ok')::boolean,
                                   'dashboards keep the approval widget; ads never above approvals and at most three');
  insert into _r values ('S20-13', pg_temp.expect_fail($q$select api.v1_design_set_ad(1, 'অফার', 'other-company/x.png', null, 'x')$q$, 'E_DESIGN_INVALID')
                                   and (api.v1_design_set_ad(1, 'অফার', ca::text || '/ads/offer.png', null, 'promo') ->> 'status') = 'active'
                                   and jsonb_array_length(api.v1_design_active() -> 'ad_media') = 0,
                                   'ad media only from the company storage; shown only while ads are switched on');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

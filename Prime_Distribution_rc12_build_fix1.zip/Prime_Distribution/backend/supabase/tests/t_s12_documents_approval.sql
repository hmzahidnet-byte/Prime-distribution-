-- S12 tests: numbering (ADR-01), idempotency + request status, approval engine / maker-checker (ADR-02), MD review (ADR-06),
-- break-glass (ADR-03).
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true); perform set_config('mohona.idem_key', '', true);
      perform set_config('request.headers', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.rv(p uuid) returns integer language sql as $$ select row_version from core.approval_request where id = p $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_md uuid; a_fm uuid; a_ac uuid; m_x uuid; p_ch uuid; p_md uuid; p_fm uuid; p_ac uuid; p_x uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_x uuid := gen_random_uuid();
        n1 text; n2 text; n3 text; j jsonb; n integer; req uuid; req2 uuid; g uuid; v integer; doc uuid := gen_random_uuid();
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('DOC', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); p_x := svc.v1_iam_provision_person('নতুন', null, null, u_x, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  m_x := svc.v1_iam_add_membership(p_x, ca, null, 't');

  -- numbering
  n1 := core.fn_next_number(ca, 'procurement.po'); n2 := core.fn_next_number(ca, 'procurement.po');
  insert into _r values ('S12-01', n1 = 'PO-' || to_char(now() at time zone 'Asia/Dhaka', 'YYYY') || '-000001' and n2 like '%-000002'
                                   and (select count(*) from core.document_number where company_id = ca) = 2, 'per-company per-type sequential numbers with yearly period');
  perform core.fn_void_number(ca, 'procurement.po', n2, 'cancelled order');
  n3 := core.fn_next_number(ca, 'procurement.po');
  insert into _r values ('S12-02', n3 like '%-000003' and pg_temp.expect_fail(format($f$update core.document_number set status='issued', voided_at=null where number=%L$f$, n2), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$insert into core.document_number (company_id, document_type, number) values (%L,'procurement.po',%L)$f$, ca, n1)),
                                   'voided numbers are never reused; duplicates impossible');
  update core.number_series set reset_policy = 'never', period_key = '#changed', prefix = 'PO' where company_id = ca and document_type = 'procurement.po';
  n1 := core.fn_next_number(ca, 'procurement.po');
  update core.number_series set reset_policy = 'yearly', period_key = '#changed' where company_id = ca and document_type = 'procurement.po';
  n2 := core.fn_next_number(ca, 'procurement.po');
  insert into _r values ('S12-03', n1 = 'PO-000001' and n2 like '%-000004', 'format changes never re-issue an existing number');

  -- idempotency
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform set_config('request.headers', '{"idempotency-key":"key-abcdef-1"}', true);
  insert into _r values ('S12-04', core.fn_idem_begin(ca, 'api.v1_test', '{"a":1}') is null and core.fn_idem_finish(ca, '{"id":42}') = '{"id":42}'::jsonb
                                   and core.fn_idem_begin(ca, 'api.v1_test', '{"a":1}') = '{"id":42}'::jsonb
                                   and pg_temp.expect_fail($q$select core.fn_idem_begin((select company_id from core.idempotency_request where idem_key='key-abcdef-1'), 'api.v1_test', '{"a":2}')$q$, 'E_IDEMPOTENCY_MISMATCH'),
                                   'same key+payload replays the original result; different payload rejected');
  insert into _r values ('S12-05', api.v1_core_request_status('key-abcdef-1') ->> 'status' = 'succeeded' and api.v1_core_request_status('never-sent-123') ->> 'status' = 'unknown',
                                   'timed-out client can ask whether its request succeeded');
  perform set_config('request.headers', '', true);

  -- approval: Chairman sets matrix, Chairman's own document needs an independent checker (ADR-02)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_config_set('governance.policy_review.required', 'false'::jsonb, 0, 'S12 sets policies directly (S22 review path tested in t_s22)');
  perform api.v1_approval_set_policy('procurement.po', 0, 1, null, 'one approval');
  perform api.v1_approval_set_policy('procurement.po', 100000, 2, null, 'two approvals for big orders');
  j := core.fn_approval_submit(ca, 'procurement.po', doc, 50000, iam.fn_resource(ca));
  req := (j ->> 'request_id')::uuid;
  insert into _r values ('S12-06', j ->> 'status' = 'pending'
                                   and pg_temp.expect_fail(format($f$select api.v1_approval_decide(%L,'approve',%s,'self')$f$, req, pg_temp.rv(req)), 'E_SELF_APPROVAL')
                                   and jsonb_array_length(api.v1_approval_inbox()) = 0, 'Chairman cannot approve own document by default (independent checker)');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S12-07', pg_temp.expect_fail(format($f$select api.v1_approval_decide(%L,'approve',%s,'x')$f$, req, pg_temp.rv(req)), 'E_FORBIDDEN'), 'no approval right = cannot approve');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  n := jsonb_array_length(api.v1_approval_inbox());
  j := api.v1_approval_decide(req, 'approve', pg_temp.rv(req), 'ok');          -- separate statement: later reads see the write
  insert into _r values ('S12-08', n = 1 and j ->> 'status' = 'approved'
                                   and core.fn_approval_status(ca, 'procurement.po', doc) = 'approved', 'independent MD approval completes it');
  -- two-level band
  perform pg_temp.as_user(u_ac, 'ac');
  j := core.fn_approval_submit(ca, 'procurement.po', gen_random_uuid(), 250000, iam.fn_resource(ca)); req2 := (j ->> 'request_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S12-09', api.v1_approval_decide(req2, 'approve', pg_temp.rv(req2), 'md ok') ->> 'status' = 'pending'
                                   and pg_temp.expect_fail(format($f$select api.v1_approval_decide(%L,'approve',%s,'again')$f$, req2, pg_temp.rv(req2)), 'E_DUPLICATE'), 'amount band needs 2 different approvers');
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  j := api.v1_approval_decide(req2, 'approve', pg_temp.rv(req2), 'fm ok');
  insert into _r values ('S12-10', j ->> 'status' = 'approved'
                                   and (select count(*) from core.approval_decision where request_id = req2) = 2
                                   and pg_temp.expect_fail(format($f$update core.approval_decision set reason='x' where request_id=%L$f$, req2), 'E_APPEND_ONLY'), 'second approver completes; decisions immutable');
  perform pg_temp.as_user(u_ac, 'ac');
  j := core.fn_approval_submit(ca, 'procurement.po', gen_random_uuid(), 10, iam.fn_resource(ca)); req2 := (j ->> 'request_id')::uuid;
  perform api.v1_approval_cancel(req2, 'mistake');
  insert into _r values ('S12-11', (select status from core.approval_request where id = req2) = 'cancelled'
                                   and jsonb_array_length(api.v1_approval_my_requests()) = 2, 'maker can cancel and sees own requests');
  -- Chairman switches self-approval on / maker-checker off (options)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('approval.chairman_self_approval.allowed', 'true', 0, 'owner wants it');
  j := core.fn_approval_submit(ca, 'sales.order', gen_random_uuid(), 10, iam.fn_resource(ca)); req2 := (j ->> 'request_id')::uuid;
  insert into _r values ('S12-12', api.v1_approval_decide(req2, 'approve', pg_temp.rv(req2), 'own ok') ->> 'status' = 'approved', 'Chairman option: self-approval');
  perform api.v1_config_set('approval.maker_checker.enabled', 'false', 0, 'small team');
  insert into _r values ('S12-13', core.fn_approval_submit(ca, 'sales.order', gen_random_uuid(), 10, iam.fn_resource(ca)) ->> 'status' = 'approved', 'Chairman option: maker-checker off');
  perform api.v1_config_set('approval.maker_checker.enabled', 'true', 1, 'back on');
  perform api.v1_config_set('approval.chairman_self_approval.allowed', 'false', 1, 'back to default');

  -- ADR-06: MD appointment review switch
  perform api.v1_config_set('iam.md_appointment.requires_review', 'true', 0, 'board rule');
  perform api.v1_iam_change_assignment(a_md, 'end', 'MD leaves');
  req := api.v1_iam_assign_position(m_x, 'MD', null, null, null, null, null, null, 'new MD');
  insert into _r values ('S12-14', (select status from core.approval_request where id = req) = 'pending'
                                   and not exists (select 1 from iam.position_assignment where membership_id = m_x and position_code = 'MD'), 'MD appointment waits for independent review');
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_approval_decide(req, 'approve', pg_temp.rv(req), 'reviewed');
  insert into _r values ('S12-15', exists (select 1 from iam.position_assignment where membership_id = m_x and position_code = 'MD' and status = 'active'), 'approved review installs the MD');

  -- break-glass
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_iam_set_position_rule('ACCOUNTANT', 'iam.breakglass.request', 'allow', 'COMPANY', null, 'emergency path');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S12-16', pg_temp.expect_fail($q$select api.v1_breakglass_request(array['audit.read'], 'server down')$q$, 'E_FEATURE_DISABLED'), 'break-glass is off by default');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('breakglass.enabled', 'true', 0, 'enable emergency access');
  perform api.v1_breakglass_set_custodian(p_md, true, 'custodian'); perform api.v1_breakglass_set_custodian(p_fm, true, 'custodian');
  perform api.v1_breakglass_set_custodian(p_ac, true, 'custodian');
  perform pg_temp.as_user(u_ac, 'ac', 'aal1');
  insert into _r values ('S12-17', pg_temp.expect_fail($q$select api.v1_breakglass_request(array['audit.read'], 'x')$q$, 'E_MFA_REQUIRED'), 'request needs MFA');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S12-18', pg_temp.expect_fail($q$select api.v1_breakglass_request(array['finance.journal.post'], 'x')$q$, 'E_BREAKGLASS_SCOPE'), 'posting permissions can never be broken-glass');
  g := api.v1_breakglass_request(array['audit.read'], 'auditor sick, regulator visit');
  insert into _r values ('S12-19', pg_temp.expect_fail(format('select api.v1_breakglass_approve(%L)', g), 'E_SELF_APPROVAL'), 'requester cannot approve own grant');
  perform pg_temp.as_user(u_fm, 'fm');
  j := api.v1_breakglass_approve(g);
  insert into _r values ('S12-21', j ->> 'status' = 'requested', 'one custodian is not enough (default 2)');
  perform pg_temp.as_user(u_x, 'x'); perform api.v1_iam_select_position((select id from iam.position_assignment where membership_id = m_x and position_code = 'MD'));
  insert into _r values ('S12-22', pg_temp.expect_fail(format('select api.v1_breakglass_approve(%L)', g), 'E_FORBIDDEN'), 'non-custodian cannot approve');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_breakglass_set_custodian(p_ch, true, 'chairman as custodian');
  j := api.v1_breakglass_approve(g);
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S12-23', j ->> 'status' = 'active' and (select allowed from iam.fn_authorize('audit.read', iam.fn_resource(ca), false))
                                   and (select valid_until <= clock_timestamp() + interval '31 minutes' from iam.assignment_permission_rule where breakglass_id = g limit 1),
                                   'two custodians activate a 30-minute least-privilege grant');
  perform api.v1_breakglass_close(g, 'revoke', 'done early');
  insert into _r values ('S12-24', not (select allowed from iam.fn_authorize('audit.read', iam.fn_resource(ca), false)), 'revocation removes the access at once');
  perform pg_temp.as_user(u_fm, 'fm');
  insert into _r values ('S12-25', pg_temp.expect_fail(format($f$select api.v1_breakglass_close(%L,'review','x')$f$, g), 'E_FORBIDDEN'), 'only break-glass managers review');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_breakglass_close(g, 'review', 'post-use review: justified');
  insert into _r values ('S12-26', (select reviewed_at is not null from iam.breakglass_grant where id = g), 'post-use review recorded');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

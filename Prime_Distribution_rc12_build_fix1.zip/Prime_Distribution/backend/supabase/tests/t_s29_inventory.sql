-- S29–S31 tests: negative stock can never be enabled, balances locked to the ledger, bin hierarchy + putaway + signed QR,
-- approved atomic transfers with cost carried, blind count + independent variance approval, adjustments never negative,
-- availability, scoped report + logged export, SoD on transfer create/approve.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.bal(p_wh uuid, p_prod uuid) returns numeric language sql as $$ select coalesce((select qty from inventory.stock_balance where warehouse_id = p_wh and product_id = p_prod), 0) $$;
create or replace function pg_temp.val(p_wh uuid, p_prod uuid) returns numeric language sql as $$ select coalesce((select value from inventory.stock_balance where warehouse_id = p_wh and product_id = p_prod), 0) $$;
create or replace function pg_temp.lotq(p_wh uuid, p_lot text) returns numeric language sql as $$
  select coalesce((select lb.qty from inventory.lot_balance lb join inventory.lot l on l.id = lb.lot_id where lb.warehouse_id = p_wh and l.lot_no = p_lot), 0) $$;
do $$
declare n integer; boot jsonb; ca uuid; a_ch uuid; a_sk uuid; a_md uuid; a_fm uuid; a_au uuid; a_ch2 uuid; p_ch uuid; p_sk uuid; p_md uuid; p_fm uuid; p_au uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_au uuid := gen_random_uuid();
        u_ch2 uuid := gen_random_uuid();
        w1 uuid; w2 uuid; sugar uuid; z1 uuid; r1 uuid; b1 uuid; l1 uuid; qr text; tr jsonb; cnt jsonb; adj uuid; j jsonb; j1 jsonb; r uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('INV', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_au := svc.v1_iam_provision_person('নিরীক্ষক', null, null, u_au, 't'); a_au := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_au, ca, null, 't'), 'AUDITOR', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('INX', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_config_set('inventory.transfer.in_transit', 'false'::jsonb, 0, 'legacy one-step transfer test');
  w1 := (api.v1_structure_save_warehouse(null, null, null, 'W1', 'প্রধান গুদাম', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  w2 := (api.v1_structure_save_warehouse(null, null, null, 'W2', 'কারখানা গুদাম', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  sugar := (api.v1_product_propose(null, 'SUGAR', 'চিনি', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  insert into _r values ('S29-01', pg_temp.expect_fail($q$select api.v1_config_set('inventory.negative_stock.allowed', 'true', 0, 'x')$q$, 'E_SETTING_INVALID'),
                                   'negative stock can never be switched on');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(sugar, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(w1, sugar, 'L1', null, null, current_date + 30, 100, 0, 0, 60, false, 'opening');
  perform api.v1_stock_receive(w1, sugar, 'L2', null, null, current_date + 60, 50, 0, 0, 70, false, 'opening');
  l1 := (select id from inventory.lot where lot_no = 'L1' and product_id = sugar);
  insert into _r values ('S29-02', pg_temp.expect_fail(format($f$update inventory.stock_balance set qty = 999 where warehouse_id = %L$f$, w1), 'E_LEDGER_LOCKED')
                                   and pg_temp.expect_fail(format($f$delete from inventory.lot_balance where warehouse_id = %L$f$, w1), 'E_LEDGER_LOCKED')
                                   and pg_temp.bal(w1, sugar) = 150,
                                   'balances are written only by posted movements');
  -- ---------------------------------------------------------------- bins + signed QR (F091, F099)
  z1 := (api.v1_bin_save(w1, null, 'Z1', 'জোন ১', 'zone', null, null, 'x') ->> 'bin_id')::uuid;
  r1 := (api.v1_bin_save(w1, null, 'R1', 'র‍্যাক ১', 'rack', z1, null, 'x') ->> 'bin_id')::uuid;
  j := api.v1_bin_save(w1, null, 'B1', 'বিন ১', 'bin', r1, null, 'x'); b1 := (j ->> 'bin_id')::uuid; qr := j ->> 'qr';
  insert into _r values ('S29-03', pg_temp.expect_fail(format($f$select api.v1_bin_save(%L, null, 'R9', null, 'rack', null, null, 'x')$f$, w1), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_bin_save(%L, null, 'B9', null, 'bin', %L, null, 'x')$f$, w2, r1), 'E_WRONG_COMPANY')
                                   and qr ~ '^MOS1\|B\|INV\|W1\|B1\|[0-9a-f]{16}$',
                                   'zone > rack > bin inside one warehouse; labels are signed');
  perform api.v1_bin_move(w1, l1, null, b1, 60);
  j := api.v1_qr_lookup(qr);
  insert into _r values ('S29-04', (j -> 'contents' -> 0 ->> 'qty')::numeric = 60
                                   and pg_temp.expect_fail(format($f$select api.v1_bin_move(%L, %L, null, %L, 70)$f$, w1, l1, b1), 'E_NEGATIVE_STOCK')
                                   and pg_temp.expect_fail(format($f$select api.v1_qr_lookup(%L)$f$, left(qr, length(qr) - 1) || case when right(qr, 1) = 'a' then 'b' else 'a' end), 'E_QR_INVALID'),
                                   'putaway never exceeds the free lot quantity; a forged label is refused');
  -- ---------------------------------------------------------------- transfers (F092)
  insert into _r values ('S29-05', pg_temp.expect_fail(format($f$select api.v1_transfer_create(%L, %L, '[{"product_id":"%s","qty":500}]', 'x')$f$, w1, w2, sugar), 'E_INSUFFICIENT_STOCK'),
                                   'a transfer never exceeds available stock');
  tr := api.v1_transfer_create(w1, w2, jsonb_build_array(jsonb_build_object('product_id', sugar, 'qty', 120)), 'to factory');
  perform pg_temp.as_user(u_md, 'md');
  r := (select id from core.approval_request where document_id = (tr ->> 'transfer_id')::uuid and status = 'pending');
  perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok');
  insert into _r values ('S29-06', tr ->> 'status' = 'pending_approval' and pg_temp.bal(w1, sugar) = 30 and pg_temp.bal(w2, sugar) = 120
                                   and pg_temp.lotq(w2, 'L1') = 100 and pg_temp.lotq(w2, 'L2') = 20 and pg_temp.val(w1, sugar) + pg_temp.val(w2, sugar) = 9500
                                   and pg_temp.val(w2, sugar) = 7600
                                   and (select qty from inventory.bin_stock where bin_id = b1 and lot_id = l1) = 0,
                                   'approved transfer moves the same lots out and in atomically; value is conserved; bins follow the lot');
  -- ---------------------------------------------------------------- blind count + adjustment (F095, F096)
  perform pg_temp.as_user(u_au, 'au'); perform api.v1_iam_select_position(a_au);
  cnt := api.v1_count_start(w2, null, 'monthly count');
  perform api.v1_count_record((cnt ->> 'count_id')::uuid, jsonb_build_array(jsonb_build_object('lot_id', l1, 'counted', 95)));
  insert into _r values ('S29-07', not exists (select 1 from jsonb_array_elements(cnt -> 'to_count') x where x ? 'qty')
                                   and pg_temp.expect_fail(format($f$select api.v1_count_submit(%L)$f$, cnt ->> 'count_id'), 'E_COUNT_INCOMPLETE')
                                   and pg_temp.expect_fail(format($f$select api.v1_count_variance(%L)$f$, cnt ->> 'count_id'), 'E_FORBIDDEN'),
                                   'counters never see system quantities and must count every lot');
  perform api.v1_count_record((cnt ->> 'count_id')::uuid, jsonb_build_array(jsonb_build_object('lot_id', (select id from inventory.lot where lot_no = 'L2' and product_id = sugar), 'counted', 20)));
  j := api.v1_count_submit((cnt ->> 'count_id')::uuid); adj := (j ->> 'adjustment_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  j1 := api.v1_count_variance((cnt ->> 'count_id')::uuid);
  perform api.v1_adjust_decide(adj, true, 'loss confirmed');
  insert into _r values ('S29-08', (j ->> 'variances')::integer = 1 and exists (select 1 from jsonb_array_elements(j1) x where (x ->> 'variance')::numeric = -5)
                                   and pg_temp.lotq(w2, 'L1') = 95 and (select status from inventory.count_session where id = (cnt ->> 'count_id')::uuid) = 'approved',
                                   'variance approved by someone who did not count posts the adjustment');
  perform pg_temp.as_user(u_sk, 'sk');
  j := api.v1_adjust_submit(w1, jsonb_build_array(jsonb_build_object('product_id', sugar, 'lot_id', (select id from inventory.lot where lot_no = 'L2' and product_id = sugar), 'delta', -200)), 'damage');
  perform pg_temp.as_user(u_fm, 'fm');
  insert into _r values ('S29-09', pg_temp.expect_fail(format($f$select api.v1_adjust_decide(%L, true, 'x')$f$, j ->> 'adjustment_id'), 'E_NEGATIVE_STOCK')
                                   and (select status from inventory.adjustment where id = (j ->> 'adjustment_id')::uuid) = 'pending',
                                   'an adjustment can never take stock below zero');
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_adjust_submit(w1, jsonb_build_array(jsonb_build_object('product_id', sugar, 'lot_id', (select id from inventory.lot where lot_no = 'L2' and product_id = sugar), 'delta', 10, 'unit_cost', 70)), 'found');
  insert into _r values ('S29-10', pg_temp.expect_fail(format($f$select api.v1_adjust_decide(%L, true, 'x')$f$, j ->> 'adjustment_id'), 'E_SELF_APPROVAL')
                                   and pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('STOREKEEPER','inventory.transfer.approve','allow','COMPANY',null,'x')$q$, 'E_SOD_CONFLICT'),
                                   'nobody approves own adjustment; transfer maker and approver are kept apart');
  -- ---------------------------------------------------------------- availability + report (F098, F100)
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_stock_reserve(w1, sugar, 10, 'B-77', 'batch');
  j := api.v1_stock_availability(sugar);
  j1 := api.v1_stock_report(null, sugar);
  insert into _r values ('S29-11', exists (select 1 from jsonb_array_elements(j) x where (x ->> 'warehouse_id')::uuid = w1 and (x ->> 'on_hand')::numeric = 30
                                                                                  and (x ->> 'reserved')::numeric = 10 and (x ->> 'available')::numeric = 20)
                                   and jsonb_array_length(j1) = 3 and j1 -> 0 -> 'value' = 'null'::jsonb and (j1 -> 0 ->> 'age_days')::integer = 0
                                   and pg_temp.expect_fail($q$select api.v1_stock_report_export(null)$q$, 'E_FORBIDDEN'),
                                   'on hand / reserved / available; report without values for non-cost readers; export needs its right');
  perform pg_temp.as_user(u_au, 'au');
  j := api.v1_stock_report_export(null);
  n := (select count(*) from inventory.export_log where company_id = ca);      -- read before switching company (RLS pins the session)
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S29-12', jsonb_array_length(j -> 'rows') = 3 and n = 1
                                   and pg_temp.expect_fail(format($f$select api.v1_qr_lookup(%L)$f$, qr), 'E_QR_INVALID')
                                   and jsonb_array_length(api.v1_stock_report(null, null)) = 0,
                                   'exports are logged; other companies see nothing and cannot use our labels');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

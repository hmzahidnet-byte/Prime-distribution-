-- S69 tests (recruitment, Master Closure §4 HR domain; docs/V180_AZ_STATUS_BN.md): vacancy approved by another person, applicants,
-- interviews, offer approval (never by its maker), accepted offer becomes a hire with onboarding, headcount fills the vacancy.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_hr uuid; a_md uuid; p_ch uuid; p_hr uuid; p_md uuid;
        u_ch uuid := gen_random_uuid(); u_hr uuid := gen_random_uuid(); u_md uuid := gen_random_uuid();
        vac uuid; ap1 uuid; ap2 uuid; off uuid; j jsonb; n integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('RCT', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_hr := svc.v1_iam_provision_person('এইচআর', null, null, u_hr, 't'); a_hr := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_hr, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');

  perform pg_temp.as_user(u_hr, 'hr'); perform api.v1_iam_select_position(a_hr);
  vac := (api.v1_vacancy_save('FIELD_SALES', null, 'মাঠ-বিক্রয়কর্মী (খুলনা)', 1, 'দুই বছরের অভিজ্ঞতা') ->> 'vacancy_id')::uuid;
  insert into _r values ('S69-01', pg_temp.expect_fail(format($f$select api.v1_vacancy_action(%L, 'open', null)$f$, vac), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail($q$select api.v1_vacancy_save('CHAIRMAN', null, 'x', 1, null)$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_applicant_add(%L, 'ক', '01711000001', null, null)$f$, vac), 'E_NOT_FOUND'),
                                   'a vacancy opens only after approval by another person; never for the Chairman seat');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_vacancy_action(vac, 'open', 'budgeted');
  perform pg_temp.as_user(u_hr, 'hr');
  ap1 := (api.v1_applicant_add(vac, 'রহিম উদ্দিন', '01711000001', 'cv/rahim.pdf', 'বিজ্ঞাপন') ->> 'applicant_id')::uuid;
  ap2 := (api.v1_applicant_add(vac, 'করিম মিয়া', '01811000002', null, 'রেফারেন্স') ->> 'applicant_id')::uuid;
  insert into _r values ('S69-02', pg_temp.expect_fail(format($f$select api.v1_applicant_add(%L, 'রহিম', '+8801711000001', null, null)$f$, vac), 'E_DUPLICATE')
                                   and pg_temp.expect_fail(format($f$select api.v1_interview_record(%L, 1, 80, 'ভালো')$f$, ap1), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail(format($f$select api.v1_applicant_action(%L, 'reject', '')$f$, ap2), 'E_REASON_REQUIRED'),
                                   'one application per phone; interview only after shortlisting; rejection needs a reason');
  perform api.v1_applicant_action(ap1, 'shortlist', null);
  perform api.v1_applicant_action(ap2, 'reject', 'অভিজ্ঞতা কম');
  perform api.v1_interview_record(ap1, 1, 82, 'যোগাযোগ দক্ষতা ভালো');
  off := (api.v1_offer_make(ap1, 18000, current_date + 7) ->> 'offer_id')::uuid;
  insert into _r values ('S69-03', pg_temp.expect_fail(format($f$select api.v1_offer_decide(%L, 'approve', null, 'ok')$f$, off), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail(format($f$select api.v1_offer_decide(%L, 'accepted', null, 'x')$f$, off), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$update hr.interview set score = 99 where applicant_id = %L$f$, ap1)),
                                   'the offer is approved by MD / Chairman before acceptance; interview scores never change');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_offer_decide(off, 'approve', null, 'within budget');
  perform pg_temp.as_user(u_hr, 'hr');
  insert into _r values ('S69-06', pg_temp.expect_fail(format($f$select api.v1_offer_decide(%L, 'accepted', 'E-0101', 'x')$f$, off), 'E_FORBIDDEN'),
                                   'adding a person to the company stays with whoever holds the membership right (Chairman by default)');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_offer_decide(off, 'accepted', 'E-0101', 'candidate accepted');
  insert into _r values ('S69-04', j ->> 'status' = 'accepted' and (j -> 'hire' ->> 'membership_id') is not null and (j -> 'hire' ->> 'onboarding_id') is not null
                                   and (select position_code from iam.position_assignment where id = (j -> 'hire' ->> 'assignment_id')::uuid) = 'FIELD_SALES'
                                   and (select status from hr.vacancy where id = vac) = 'filled' and (select status from hr.applicant where id = ap1) = 'hired'
                                   and (select status from hr.applicant where id = ap2) = 'rejected',
                                   'an accepted offer becomes a hire with position and onboarding checklist; the vacancy is filled');
  n := jsonb_array_length(api.v1_recruitment_board(vac) -> 0 -> 'applicants');
  insert into _r values ('S69-05', n = 2 and pg_temp.expect_fail(format($f$delete from hr.applicant where id = %L$f$, ap2)), 'the board keeps every applicant; nothing is deleted');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S63 tests (ধাপ ১: 02_CONSOLIDATED_DESIGN + 14_TRACEABILITY, docs/V180_CONSOLIDATED_AUDIT_BN.md): COGS at transfer of control
-- (goods in transit until delivery / courier release / return), warehouse transfers on the road with independent shortage decision,
-- spare parts to machines, periodic access review, weekly dealer due (disabled by default). Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        fg2 uuid; rw uuid; brg uuid; mc uuid; o2 jsonb; ds2 jsonb; tr jsonb; rq uuid; rv jsonb; it uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- ---------------------------------------------------------------- FIN-002 COGS at transfer of control
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 200)), null);
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 4);
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, 'DHA-1', 'করিম');
  insert into _r values ('S63-01', ds ->> 'cogs_timing' = 'delivery' and pg_temp.bal(ca, '1240') = 12000 and pg_temp.bal(ca, '5100') = 0 and pg_temp.bal(ca, '1210') = 18000,
                                   'dispatch moves the cost to goods in transit; COGS waits for the transfer of control');
  perform pg_temp.as_user(u_ac, 'ac');
  j := api.v1_goods_in_transit();
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_delivery_confirm((ds ->> 'dispatch_id')::uuid, 'রহমান', repeat('ab', 32));
  insert into _r values ('S63-02', (j ->> 'total')::numeric = 12000 and pg_temp.bal(ca, '1240') = 0 and pg_temp.bal(ca, '5100') = 12000
                                   and pg_temp.expect_fail(format($f$update sales.cogs_recognition set amount = 1 where dispatch_id = %L$f$, ds ->> 'dispatch_id'), 'E_IMMUTABLE'),
                                   'delivery confirmation recognises COGS once; the record never changes');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('sales.cogs.timing', '"dispatch"'::jsonb, 0, 'company sells ex-works');
  perform pg_temp.as_user(u_fs, 'fs');
  o2 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 100)), null);
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o2 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o2 ->> 'order_id')::uuid); perform api.v1_order_pack((o2 ->> 'order_id')::uuid, 2);
  ds2 := api.v1_dispatch_post((o2 ->> 'order_id')::uuid, null, null);
  insert into _r values ('S63-03', ds2 ->> 'cogs_timing' = 'dispatch' and pg_temp.bal(ca, '5100') = 18000 and pg_temp.bal(ca, '1240') = 0,
                                   'the Chairman may choose COGS at dispatch; then nothing waits in transit');

  -- ---------------------------------------------------------------- warehouse transfer on the road
  perform pg_temp.as_user(u_ch, 'ch');
  fg2 := (api.v1_structure_save_warehouse(null, null, null, 'FG2', 'বরিশাল ডিপো', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  perform pg_temp.as_user(u_sk, 'sk');
  tr := api.v1_transfer_create(fgw, fg2, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 50)), 'to depot');
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((tr ->> 'transfer_id')::uuid);
  it := (select transit_warehouse from inventory.transfer where id = (tr ->> 'transfer_id')::uuid);
  insert into _r values ('S63-04', (select status from inventory.transfer where id = (tr ->> 'transfer_id')::uuid) = 'in_transit'
                                   and (select kind from inventory.warehouse where id = it) = 'transit'
                                   and (select qty from inventory.stock_balance where warehouse_id = it and product_id = noodle) = 50
                                   and coalesce((select qty from inventory.stock_balance where warehouse_id = fg2 and product_id = noodle), 0) = 0
                                   and inventory.fn_available(ca, fg2, noodle) = 0,
                                   'approved transfer goes on the road: out of the source, not yet in the destination, not available anywhere');
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S63-05', pg_temp.expect_fail(format($f$select api.v1_transfer_receive(%L, '[{"lot_id":"%s","qty":40}]', '')$f$, tr ->> 'transfer_id', lot), 'E_REASON_REQUIRED')
                                   and pg_temp.expect_fail(format($f$select api.v1_transfer_receive(%L, '[{"lot_id":"%s","qty":60}]', 'x')$f$, tr ->> 'transfer_id', lot), 'E_INVALID_ACTION'),
                                   'a shortage needs a reason; nobody receives more than was sent');
  rv := api.v1_transfer_receive((tr ->> 'transfer_id')::uuid, jsonb_build_array(jsonb_build_object('lot_id', lot, 'qty', 40)), 'one carton missing');
  insert into _r values ('S63-06', rv ->> 'status' = 'received_short' and (rv ->> 'short_qty')::numeric = 10
                                   and (select qty from inventory.stock_balance where warehouse_id = fg2 and product_id = noodle) = 40
                                   and (select qty from inventory.stock_balance where warehouse_id = it and product_id = noodle) = 10
                                   and pg_temp.expect_fail(format($f$select api.v1_transfer_shortage_decide(%L, 'write_off', null, 'x')$f$, tr ->> 'transfer_id')),
                                   'what arrived is stock at the destination; the missing part stays on the road; the receiver cannot write it off');
  perform pg_temp.as_user(u_ch, 'ch');
  rv := api.v1_transfer_shortage_decide((tr ->> 'transfer_id')::uuid, 'write_off', null, 'lost on the launch');
  insert into _r values ('S63-07', rv ->> 'status' = 'received' and (select qty from inventory.stock_balance where warehouse_id = it and product_id = noodle) = 0
                                   and pg_temp.bal(ca, '5400') = 600
                                   and pg_temp.expect_fail(format($f$update inventory.transfer set reason = 'x' where id = %L$f$, tr ->> 'transfer_id'), 'E_IMMUTABLE'),
                                   'an independent write-off posts the loss at cost; a finished transfer never changes');

  -- ---------------------------------------------------------------- spare parts to a machine (MFG-003)
  rw := (api.v1_structure_save_warehouse(null, null, null, 'RW', 'কাঁচামাল', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  brg := (api.v1_product_propose(null, 'BEARING', 'বিয়ারিং', null, 'raw_material', null, 'pcs', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_product_decide(brg, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_stock_receive(rw, brg, 'B1', null, null, current_date + 365, 10, 0, 0, 250, false, 'opening spares');
  perform pg_temp.as_user(u_ch, 'ch');
  mc := (api.v1_machine_log('PK-01', 'প্যাকিং মেশিন ১', null, null, null, null, null) ->> 'machine_id')::uuid;
  insert into _r values ('S63-08', pg_temp.expect_fail(format($f$select api.v1_spare_issue(%L, %L, %L, 20, 'x')$f$, mc, rw, brg), 'E_NEGATIVE_STOCK')
                                   and pg_temp.expect_fail(format($f$select api.v1_spare_issue(%L, %L, %L, 1, ' ')$f$, mc, rw, brg), 'E_REASON_REQUIRED'),
                                   'spares never go below zero and always carry the reason');
  j := api.v1_spare_issue(mc, rw, brg, 2, 'bearing changed');
  insert into _r values ('S63-09', (j ->> 'value')::numeric = 500 and pg_temp.bal(ca, '5820') = 500
                                   and (select qty from inventory.stock_balance where warehouse_id = rw and product_id = brg) = 8
                                   and (api.v1_machine_costs(null, null) -> 0 ->> 'spares')::numeric = 500,
                                   'a spare issued to a machine leaves stock at cost and becomes maintenance expense, visible per machine');

  -- ---------------------------------------------------------------- access review
  rq := (api.v1_access_review_start('ত্রৈমাসিক পর্যালোচনা') ->> 'review_id')::uuid;
  insert into _r values ('S63-10', (select count(*) from iam.access_review_item where review_id = rq) = 6
                                   and not exists (select 1 from iam.access_review_item where review_id = rq and person_id = p_ch)
                                   and pg_temp.expect_fail($q$select api.v1_access_review_start('again')$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_access_review_close(%L)$f$, rq), 'E_INVALID_ACTION'),
                                   'every non-Chairman position is on the list; one open review at a time; no closing before every line is decided');
  perform api.v1_access_review_decide(i.id, case when i.position_code = 'FIELD_SALES' then 'revoke' else 'keep' end, 'checked')
     from iam.access_review_item i where i.review_id = rq;
  j := api.v1_access_review_close(rq);
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S63-11', j ->> 'status' = 'closed' and jsonb_array_length(j -> 'to_revoke') = 1
                                   and pg_temp.expect_fail($q$select api.v1_access_review_start('md')$q$)
                                   and pg_temp.expect_fail(format($f$update iam.access_review_item set decision = 'keep' where review_id = %L$f$, rq), 'E_IMMUTABLE'),
                                   'closing returns the revoke list; decisions never change; only the access manager starts a review');

  -- ---------------------------------------------------------------- weekly dealer due (disabled by default)
  perform pg_temp.as_user(u_ac, 'ac');
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_weekly_due(null);
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('sales.weekly_due.enabled', 'true'::jsonb, 0, 'Tuesday close policy');
  perform pg_temp.as_user(u_sm, 'sm');
  j1 := api.v1_weekly_due(current_date + 7);
  insert into _r values ('S63-12', (j ->> 'enabled')::boolean = false and (j1 ->> 'enabled')::boolean
                                   and extract(dow from (j1 ->> 'close_date')::date) = 2
                                   and (j1 -> 'dealers' -> 0 ->> 'owed_at_close')::numeric = 20000 and (j1 -> 'dealers' -> 0 ->> 'due_this_week')::numeric = 10000,
                                   'the weekly due policy is off until the Chairman turns it on; then 50 % of the Tuesday balance is due');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S70 tests (A–Z closure, 15 Nov 2026; docs/V180_AZ_STATUS_BN.md): supplier bank change approval, machine service schedule, plan
-- readiness, utility WIP kind, location claims, market merge/split, dealer outlets / self-service / offboarding, disputes, aging + overdue
-- hold, manual order hold, notices by market + offer redemption, visit check-out, dealer product visibility. Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.kv(p jsonb, p_code text) returns jsonb language sql as $$
  select x from jsonb_array_elements(p) x where x ->> 'code' = p_code limit 1 $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        sup uuid; mc uuid; sp uuid; rmw uuid; flour uuid; bom uuid; plan uuid; cl uuid; m1 uuid; m2 uuid; ma uuid; out1 uuid; du uuid; dp uuid; da uuid;
        u_dl uuid := gen_random_uuid(); rq jsonb; dsp uuid; nt uuid; vis jsonb; ok boolean;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- ---------------------------------------------------------------- A supplier bank change
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  sup := (api.v1_supplier_save(null, 'SUP1', 'রহিম সাপ্লাই', null, '01711999999', null, null, null, null, 30, null, '••••1111', null, null, 'new') ->> 'supplier_id')::uuid;
  insert into _r values ('S70-01', pg_temp.expect_fail(format($f$update procurement.supplier set bank_account_masked = '••••9999' where id = %L$f$, sup), 'E_APPROVAL_REQUIRED')
                                   and (select bank_account_masked from procurement.supplier where id = sup) = '••••1111',
                                   'a supplier bank account never changes directly');
  chg := (api.v1_supplier_bank_change_request(sup, '••••2222', 'docs/bank-letter.pdf', 'new bank letter') ->> 'change_id')::uuid;
  ok := pg_temp.expect_fail(format($f$select api.v1_supplier_bank_change_decide(%L, true, 'ok')$f$, chg), 'E_FORBIDDEN');    -- Chairman holds no finance.ap.pay? (supreme: allowed) -> self check
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  perform api.v1_supplier_bank_change_decide(chg, true, 'letter verified by phone');
  insert into _r values ('S70-02', (select bank_account_masked from procurement.supplier where id = sup) = '••••2222'
                                   and (select status from procurement.supplier_bank_change where id = chg) = 'approved',
                                   'an approved change request (by another person) is the only way in');

  -- ---------------------------------------------------------------- B machine service schedule
  perform pg_temp.as_user(u_ch, 'ch');
  mc := (api.v1_machine_log('PK-01', 'প্যাকিং মেশিন', null, null, null, null, null) ->> 'machine_id')::uuid;
  sp := (api.v1_machine_service_plan_set('PK-01', 'বেল্ট পরীক্ষা', 30, current_date - 40, null) ->> 'plan_id')::uuid;
  j := api.v1_machine_services_due(7);
  insert into _r values ('S70-03', jsonb_array_length(j) = 1 and (j -> 0 ->> 'overdue')::boolean, 'a service past its interval shows as overdue');
  j := api.v1_machine_service_done(sp, 'বেল্ট বদলানো হয়নি, ঠিক আছে', 15);
  insert into _r values ('S70-04', (j ->> 'next_due')::date = current_date + 30 and jsonb_array_length(api.v1_machine_services_due(7)) = 0
                                   and exists (select 1 from mfg.machine_maintenance where machine_id = mc and kind = 'preventive' and downtime_minutes = 15),
                                   'done service is logged with downtime and the next due date moves');

  -- ---------------------------------------------------------------- C plan readiness + D utility kind
  rmw := (api.v1_structure_save_warehouse(null, null, null, 'RM', 'কাঁচামাল', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  flour := (api.v1_product_propose(null, 'FLOUR', 'ময়দা', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(flour, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_ch, 'ch');
  bom := (api.v1_bom_propose(noodle, null, 1000, jsonb_build_array(jsonb_build_object('material_id', flour, 'qty', 100)), 'recipe') ->> 'bom_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_bom_decide(bom, true, 'ok');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_stock_receive(rmw, flour, 'F1', null, null, current_date + 90, 150, 0, 0, 40, false, 'opening');
  perform pg_temp.as_user(u_ch, 'ch');
  plan := (api.v1_plan_save(null, current_date + 1, null, jsonb_build_array(jsonb_build_object('product_id', noodle, 'target_poly', 2000)), 'tomorrow') ->> 'plan_id')::uuid;
  j := api.v1_plan_readiness(plan);
  insert into _r values ('S70-05', not (j ->> 'ready')::boolean and (j -> 'materials' -> 0 ->> 'need')::numeric = 200 and (j -> 'materials' -> 0 ->> 'short')::numeric = 50,
                                   'readiness: 2000 poly need 200 kg flour from the approved BOM; 150 available, 50 short');
  perform api.v1_config_set('mfg.plan.require_material_ready', 'true', 0, 'no plan without material');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S70-06', pg_temp.expect_fail(format($f$select api.v1_plan_approve(%L, 'ok')$f$, plan), 'E_MATERIAL_SHORT')
                                   and pg_temp.expect_fail($q$insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (gen_random_uuid(), gen_random_uuid(), 'magic', 1, 'x', gen_random_uuid())$q$),
                                   'with the setting on, a short plan cannot be approved; WIP kinds stay a closed list (utility added)');

  -- ---------------------------------------------------------------- G outlets + E location claims
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  out1 := (api.v1_dealer_outlet_save(dl, null, 'OUT-2', 'রহমান ট্রেডার্স — বাজার শাখা', 'বড় বাজার, খুলনা', null, null) ->> 'outlet_id')::uuid;
  cl := (api.v1_location_claim_submit('dealer', dl, 22.8156, 89.5683, 12, null, 'খুলনা সদর', 'google', 'ChIJ-test-place', null, 'CLAIM-0000001') ->> 'claim_id')::uuid;
  j := api.v1_location_claim_submit('dealer', dl, 22.8156, 89.5683, 12, null, 'খুলনা সদর', 'google', 'ChIJ-test-place', null, 'CLAIM-0000001');
  insert into _r values ('S70-07', (select status from sales.location_claim where id = cl) = 'GOOGLE_MATCHED' and (j ->> 'duplicate')::boolean
                                   and (select latitude from sales.dealer where id = dl) is null
                                   and pg_temp.expect_fail(format($f$select api.v1_location_claim_review(%L, 'approve', 'x')$f$, cl), 'E_INVALID_ACTION'),
                                   'a Google match is a candidate only: never approved by itself, the pin is untouched');
  perform api.v1_location_claim_review(cl, 'crosscheck', 'উপজেলা তালিকা ও ভিজিট-ছবির সাথে মিলেছে');
  insert into _r values ('S70-08', pg_temp.expect_fail(format($f$select api.v1_location_claim_review(%L, 'approve', 'x')$f$, cl), 'E_SELF_APPROVAL'),
                                   'the person who submitted or cross-checked does not approve');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_location_claim_review(cl, 'approve', 'ok');
  insert into _r values ('S70-09', (select latitude from sales.dealer where id = dl) = 22.8156 and (select status from sales.location_claim where id = cl) = 'APPROVED',
                                   'an independently approved claim updates the dealer pin');

  -- ---------------------------------------------------------------- F market merge / split
  perform pg_temp.as_user(u_sm, 'sm');
  m1 := (api.v1_market_save(null, 'BAZ-1', 'বড় বাজার', terr, null, null, 'x') ->> 'market_id')::uuid;
  m2 := (api.v1_market_save(null, 'BAZ-2', 'ছোট বাজার', terr, null, null, 'x') ->> 'market_id')::uuid;
  ma := (api.v1_market_assign_request(m2, dl, current_date, null, null, 'x') ->> 'assignment_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_market_assign_decide(ma, true, 'ok');
  j := api.v1_market_merge(m2, m1, 'two bazaars became one');
  insert into _r values ('S70-10', (j ->> 'assignments_ended')::int = 1 and (select status = 'inactive' and merged_into = m1 from sales.market where id = m2)
                                   and pg_temp.expect_fail(format($f$select api.v1_market_merge(%L, %L, 'again')$f$, m2, m1), 'E_INVALID_ACTION'),
                                   'merge closes the old market and its assignments; history stays');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_market_split(m1, 'BAZ-1N', 'বড় বাজার (উত্তর)', '[[22.80,89.50],[22.80,89.60],[22.90,89.60],[22.90,89.50]]'::jsonb, 'north part');
  insert into _r values ('S70-11', (select parent_market_id from sales.market where id = (j ->> 'market_id')::uuid) = m1
                                   and (select count(*) from sales.market_boundary_version where market_id = (j ->> 'market_id')::uuid) = 1,
                                   'split creates a child market with its own boundary version');

  -- ---------------------------------------------------------------- H dealer app: prefs, change request, disputes, own data
  du := ((api.v1_dealer_portal_invite(dl, 'আব্দুর রহমান', '01711000001', 'owner', 'app')) ->> 'dealer_user_id')::uuid;
  dp := (select person_id from sales.dealer_user where id = du); da := (select assignment_id from sales.dealer_user where id = du);
  insert into iam.person_auth_link (person_id, auth_user_id) values (dp, u_dl);
  perform pg_temp.as_user(u_dl, 'dl'); perform api.v1_iam_select_position(da);
  j := api.v1_dealer_portal_prefs('{"offers": false}'::jsonb, 'TERMS-2026-1');
  insert into _r values ('S70-12', (j -> 'prefs' ->> 'offers')::boolean = false and (j -> 'prefs' ->> 'notices')::boolean and j ->> 'terms_version' = 'TERMS-2026-1'
                                   and pg_temp.expect_fail($q$select api.v1_dealer_portal_prefs('{"sms": true}', null)$q$, 'E_INVALID_ACTION'),
                                   'the dealer sets notification preferences and accepts the terms version');
  chg := (api.v1_dealer_contact_change_request('01911222333', 'নতুন ঠিকানা, খুলনা', null, 'moved shop') ->> 'request_id')::uuid;
  perform api.v1_dealer_dispute_raise('ledger_entry', 'INV-1', 'এই লাইনের টাকা দুবার ধরা হয়েছে');
  j := api.v1_dealer_my_data();
  insert into _r values ('S70-13', j -> 'profile' ->> 'code' = 'D1' and jsonb_array_length(j -> 'outlets') = 1 and j ? 'ledger'
                                   and jsonb_array_length(api.v1_disputes(null)) = 1
                                   and pg_temp.expect_fail($q$select api.v1_dealer_offboard(gen_random_uuid(), 'x')$q$),
                                   'the dealer exports own data, sees own disputes, cannot use staff functions');
  perform pg_temp.as_user(u_sm, 'sm');
  perform api.v1_dealer_change_decide(chg, true, 'called the dealer');
  n := (select count(*) from sales.dispute where dealer_id = dl and status = 'open');
  perform api.v1_dispute_resolve((select id from sales.dispute where dealer_id = dl limit 1), true, 'ডুপ্লিকেট ছিল; আলাদা সমন্বয়ে ঠিক করা হবে');
  insert into _r values ('S70-14', (select phone from sales.dealer where id = dl) = '+8801911222333' and n = 1
                                   and (select status from sales.dispute where dealer_id = dl limit 1) = 'resolved'
                                   and pg_temp.expect_fail(format($f$update sales.dispute set text_bn = 'x' where dealer_id = %L$f$, dl), 'E_IMMUTABLE'),
                                   'staff approve the contact change; a dispute is decided once with a written resolution');

  -- ---------------------------------------------------------------- J aging + overdue hold, K manual hold, L offer link, N visibility
  insert into sales.invoice (id, company_id, number, order_id, dealer_id, invoice_date, due_date, total, lines, posted_by)
  select gen_random_uuid(), ca, 'INV-OLD-1', null, dl, current_date - 70, current_date - 40, 0, '[]'::jsonb, p_ac where false;   -- (no direct invoice writes; aging uses posted invoices)
  j := api.v1_dealer_aging(dl);
  insert into _r values ('S70-15', jsonb_array_length(j) = 1 and (j -> 0) ? 'd90_plus' and (j -> 0 ->> 'total')::numeric >= 0, 'aging buckets per dealer');
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 10)), null);
  perform pg_temp.as_user(u_md, 'md');
  if (select status from sales.sales_order where id = (o1 ->> 'order_id')::uuid) = 'pending_approval' then perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid); end if;
  perform api.v1_order_hold((o1 ->> 'order_id')::uuid, true, 'dealer asked to wait');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 1);
  insert into _r values ('S70-16', pg_temp.expect_fail(format($f$select api.v1_dispatch_post(%L, null, null)$f$, o1 ->> 'order_id'), 'E_ORDER_ON_HOLD'),
                                   'an order on hold cannot be dispatched');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_order_hold((o1 ->> 'order_id')::uuid, false, 'go ahead');
  perform pg_temp.as_user(u_sk, 'sk');
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, null, null);
  insert into _r values ('S70-17', ds ? 'dispatch_id', 'released, it dispatches');

  perform pg_temp.as_user(u_sm, 'sm');
  nt := (api.v1_dealer_notice_save('offer', 'বাজার-অফার', 'শুধু বড় বাজার', null, null, null, jsonb_build_object('market_ids', jsonb_build_array(m1)), null, current_date, current_date + 5) ->> 'notice_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_dealer_notice_publish(nt);
  perform pg_temp.as_user(u_dl, 'dl');
  insert into _r values ('S70-18', jsonb_array_length(api.v1_dealer_home() -> 'notices') = 0, 'a market-targeted offer reaches only dealers holding that market');
  perform pg_temp.as_user(u_sm, 'sm');
  ma := (api.v1_market_assign_request(m1, dl, current_date, null, null, 'x') ->> 'assignment_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_market_assign_decide(ma, true, 'ok');
  perform pg_temp.as_user(u_dl, 'dl');
  rq := api.v1_dealer_order_request(jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 5)), null, 'REQ-7000001');
  perform api.v1_dealer_order_request_link((rq ->> 'request_id')::uuid, out1, nt);
  insert into _r values ('S70-19', jsonb_array_length(api.v1_dealer_home() -> 'notices') = 1
                                   and (select offer_id = nt and outlet_id = out1 from sales.dealer_order_request where id = (rq ->> 'request_id')::uuid),
                                   'holding the market, the dealer sees the offer and links it (and an outlet) to a request');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_offer_redemptions(nt);
  perform api.v1_product_dealer_visibility(noodle, false, 'not for dealers this month');
  perform pg_temp.as_user(u_dl, 'dl');
  insert into _r values ('S70-20', (j ->> 'requests')::int = 1
                                   and pg_temp.expect_fail($q$select api.v1_dealer_order_request('[{"product_id":"$q$ || noodle || $q$","qty":1}]', null, 'REQ-7000002')$q$, 'E_INVALID_ACTION')
                                   and jsonb_array_length(api.v1_dealer_home() -> 'products') = 0,
                                   'offer redemption is counted; a product hidden from dealers can be neither seen nor requested');

  -- ---------------------------------------------------------------- M visit check-out
  perform pg_temp.as_user(u_fs, 'fs');
  vis := api.v1_visit_plan(dl, null, current_date);
  perform api.v1_visit_check_in((vis ->> 'visit_id')::uuid, 22.81, 89.56);
  j := api.v1_visit_check_out((vis ->> 'visit_id')::uuid);
  perform pg_temp.as_user(u_sm, 'sm');
  perform api.v1_product_dealer_visibility(noodle, true, 'back on the list');
  perform pg_temp.as_user(u_dl, 'dl');
  rq := api.v1_dealer_order_repeat((select number from sales.sales_order where id = (o1 ->> 'order_id')::uuid), 'REQ-7000009');
  insert into _r values ('S70-23', (select lines -> 0 ->> 'qty' from sales.dealer_order_request where id = (rq ->> 'request_id')::uuid)::numeric = 10
                                   and pg_temp.expect_fail($q$select api.v1_dealer_order_repeat('NO-SUCH', 'REQ-7000010')$q$, 'E_NOT_FOUND'),
                                   'one-tap repeat of an own earlier order creates a new request');
  perform pg_temp.as_user(u_fs, 'fs');
  insert into _r values ('S70-21', (j ->> 'minutes') is not null
                                   and pg_temp.expect_fail(format($f$select api.v1_visit_check_out(%L)$f$, vis ->> 'visit_id'), 'E_INVALID_ACTION'),
                                   'a visit is checked out once after check-in');

  -- ---------------------------------------------------------------- H offboarding
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S70-22', pg_temp.expect_fail(format($f$select api.v1_dealer_offboard(%L, 'closing')$f$, dl), 'E_INVALID_ACTION'),
                                   'a dealer with dues or open orders cannot be offboarded');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S18 tests: WCAG maths, templates valid, palette/typography/card limits, immutable versions, publish gate, active theme
-- for every member, permission-bound action icons, publish through approval, single active theme.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.trv(p uuid) returns integer language sql as $$ select row_version from design.theme where id = p $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_md uuid; a_ac uuid; p_ch uuid; p_md uuid; p_ac uuid; j jsonb; j1 jsonb; t1 uuid; t2 uuid; req uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
        base jsonb := design.fn_template_tokens('#1456A0', '#0E3F78', '#E8F0FA', '#1F2430', '#5F6673');
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('DSN', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');

  insert into _r values ('S18-01', design.fn_contrast('#000000', '#FFFFFF') = 21 and design.fn_contrast('#FFFFFF', '#FFFFFF') = 1
                                   and design.fn_contrast('#1F2430', '#FFFFFF') > 15, 'WCAG contrast maths');
  insert into _r values ('S18-02', not exists (select 1 from design.theme_template t where not (design.fn_tokens_report(t.tokens) ->> 'ok')::boolean),
                                   'every built-in template passes its own validation');
  j := design.fn_tokens_report(jsonb_set(base, '{colors,text}', '"#BBBBBB"'));
  j1 := design.fn_tokens_report(jsonb_set(base, '{colors,onPrimary}', '"#6A9BD8"'));
  insert into _r values ('S18-03', not (j ->> 'ok')::boolean and (j ->> 'errors') like '%text/background%' and not (j1 ->> 'ok')::boolean
                                   and (design.fn_tokens_report(jsonb_set(base, '{colors,warn}', '"#FFE066"')) ->> 'ok')::boolean
                                   and jsonb_array_length(design.fn_tokens_report(jsonb_set(base, '{colors,warn}', '"#FFE066"')) -> 'warnings') >= 1,
                                   'palette: text colours that break contrast are errors; weak status colours only warn');
  insert into _r values ('S18-04', not (design.fn_tokens_report(jsonb_set(jsonb_set(base, '{type,headlineSp}', '30'), '{type,scale}', '1.3')) ->> 'ok')::boolean
                                   and not (design.fn_tokens_report(jsonb_set(base, '{type,lineHeightFactor}', '1.1')) ->> 'ok')::boolean
                                   and (design.fn_tokens_report(jsonb_set(base, '{type,scale}', '1.2')) ->> 'ok')::boolean,
                                   'typography: sizes that would clip amounts and tight Bengali line height are refused');
  insert into _r values ('S18-05', not (design.fn_tokens_report(jsonb_set(base, '{cards,paddingDp}', '4')) ->> 'ok')::boolean
                                   and not (design.fn_tokens_report(base || '{"script":1}') ->> 'ok')::boolean
                                   and not (design.fn_tokens_report(jsonb_set(base, '{colors,primary}', '"blue"')) ->> 'ok')::boolean
                                   and not (design.fn_tokens_report(jsonb_set(base, '{colors,roleAccent}', '{"MD":"#FFE066"}')) ->> 'ok')::boolean
                                   and (design.fn_tokens_report(jsonb_set(base, '{colors,roleAccent}', '{"MD":"#7E22CE"}')) ->> 'ok')::boolean,
                                   'cards keep readable density; unknown sections, bad colours and unreadable role accents refused');
  -- ---------------------------------------------------------------- themes
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_design_save_theme('HOUSE', 'আমাদের থিম', null, 'MOHONA_ORANGE', 'start from orange');
  t1 := (j ->> 'theme_id')::uuid;
  j1 := api.v1_design_save_theme('HOUSE', 'আমাদের থিম', jsonb_set(base, '{colors,text}', '"#CCCCCC"'), null, 'experiment');
  insert into _r values ('S18-06', (j ->> 'version')::integer = 1 and (j1 ->> 'version')::integer = 2 and not (j1 -> 'report' ->> 'ok')::boolean
                                   and pg_temp.expect_fail(format($f$update design.theme_version set tokens = '{}' where theme_id = %L and version = 1$f$, t1), 'E_IMMUTABLE'),
                                   'drafts are saved as immutable versions, even invalid ones (with their report)');
  insert into _r values ('S18-07', pg_temp.expect_fail(format($f$select api.v1_design_publish(%L, 2, %s, 'x')$f$, t1, pg_temp.trv(t1)), 'E_DESIGN_CONTRAST'),
                                   'a version with accessibility errors can never be published');
  perform api.v1_design_publish(t1, 1, pg_temp.trv(t1), 'go live');
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  j := api.v1_design_active();
  insert into _r values ('S18-08', j -> 'theme' ->> 'code' = 'HOUSE' and j -> 'theme' -> 'tokens' -> 'colors' ->> 'primary' = '#C2410C'
                                   and pg_temp.expect_fail($q$select api.v1_design_save_theme('MINE','x',null,'MOHONA_BLUE','x')$q$, 'E_FORBIDDEN'),
                                   'every member receives the published theme; only the studio permission edits');
  -- ---------------------------------------------------------------- icons (F004)
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S18-09', pg_temp.expect_fail($q$select api.v1_design_set_icon('action.approve_invoice','Approval',null,0,'x')$q$, 'E_DESIGN_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_design_set_icon('module.finance','EvilScript',null,0,'x')$q$, 'E_DESIGN_INVALID')
                                   and api.v1_design_set_icon('action.approve_request', 'Approval', 'approval.decide', 0, 'approve icon') = 1
                                   and api.v1_design_set_icon('module.finance', 'AccountBalance', null, 0, 'finance icon') = 1,
                                   'icons only from the catalog; an action icon always names the permission it needs');
  perform pg_temp.as_user(u_ac, 'ac');
  j := api.v1_design_active();
  insert into _r values ('S18-10', (j -> 'icons') @> '[{"target_key":"action.approve_request","icon":"Approval","permission":"approval.decide"}]',
                                   'the app receives each icon with its permission, so it is hidden where the right is missing');
  -- ---------------------------------------------------------------- publish through approval, single active theme
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('design.publish.requires_approval', 'true'::jsonb, 0, 'board review');
  j := api.v1_design_save_theme('CALM', 'শান্ত', null, 'FOREST_GREEN', 'green option'); t2 := (j ->> 'theme_id')::uuid;
  j := api.v1_design_publish(t2, 1, pg_temp.trv(t2), 'switch'); req := (j ->> 'request_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_approval_decide(req, 'approve', (select row_version from core.approval_request where id = req), 'fine');
  insert into _r values ('S18-11', j ->> 'status' = 'pending_approval' and (select count(*) from design.theme where company_id = ca and is_active) = 1
                                   and (select is_active from design.theme where id = t2)
                                   and (select status from design.theme_version where theme_id = t1 and version = 1) = 'published',
                                   'approved publication switches the single active theme');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

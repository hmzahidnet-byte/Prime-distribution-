-- S22 tests: approval notifications (approvers, never the maker; no amounts), decisions, read state, mandatory
-- channels, templates + sanitising, security banner, reminders + escalation (idempotent), delivery retries,
-- audit search/export bundle, policy publication with an independent critical reviewer, audit never recyclable.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_md uuid; a_ac uuid; a_au uuid; p_ch uuid; p_md uuid; p_ac uuid; p_au uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_au uuid := gen_random_uuid();
        req uuid; j jsonb; j1 jsonb; j2 jsonb; nid uuid; did uuid; prop uuid; s1 bigint;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('NTF', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', '01711000001', null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_au := svc.v1_iam_provision_person('নিরীক্ষক', null, null, u_au, 't'); a_au := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_au, ca, null, 't'), 'AUDITOR', null, null, null, null, null, 't');

  -- ---------------------------------------------------------------- approval notifications
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_notify_set_preference('approval', 'sms', true);
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  req := (core.fn_approval_submit(ca, 'test.document', gen_random_uuid(), 777777, iam.fn_resource(ca), '{}'::jsonb) ->> 'request_id')::uuid;
  j1 := api.v1_notify_inbox(false, 50);
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_notify_inbox(false, 50);
  insert into _r values ('S22-01', exists (select 1 from jsonb_array_elements(j) x where x ->> 'link_id' = req::text and x ->> 'category' = 'approval')
                                   and not exists (select 1 from jsonb_array_elements(j1) x where x ->> 'link_id' = req::text)
                                   and not exists (select 1 from notify.notification n where n.link_id = req and (n.body_bn like '%777%' or n.title_bn like '%777%')),
                                   'approvers are told, the maker is not; no amount in the text');
  nid := (select id from notify.notification where person_id = p_md and link_id = req);
  perform api.v1_approval_decide(req, 'approve', (select row_version from core.approval_request where id = req), 'ok');
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S22-02', exists (select 1 from jsonb_array_elements(api.v1_notify_inbox(true, 50)) x where x ->> 'link_id' = req::text and x ->> 'title_bn' = 'সিদ্ধান্ত হয়েছে')
                                   and (select status from core.approval_request where id = req) = 'approved',
                                   'the maker hears the decision; notifications never decide anything');
  insert into _r values ('S22-03', api.v1_notify_mark(array[nid], 'read') = 0, 'nobody can touch another person''s notification');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S22-04', api.v1_notify_mark(array[nid], 'read') = 1 and not exists (select 1 from jsonb_array_elements(api.v1_notify_inbox(true, 50)) x where (x ->> 'id')::uuid = nid)
                                   and pg_temp.expect_fail($q$select api.v1_notify_set_preference('security', 'sms', false)$q$, 'E_NOTIFY_MANDATORY')
                                   and exists (select 1 from notify.delivery d where d.notification_id = nid and d.channel = 'sms' and d.status = 'queued'),
                                   'read state per person; mandatory channels stay on; chosen SMS is queued');
  -- ---------------------------------------------------------------- delivery retries (idempotent)
  did := (select id from notify.delivery where notification_id = nid and channel = 'sms');
  j := svc.v1_notify_claim('sms', 10);
  j1 := svc.v1_notify_result(did, false, 'gateway timeout');
  update notify.delivery set next_attempt_at = clock_timestamp() where id = did;
  j2 := svc.v1_notify_result(did, true, null);
  insert into _r values ('S22-05', exists (select 1 from jsonb_array_elements(j) x where (x ->> 'delivery_id')::uuid = did and x ->> 'phone' = '+8801711000001')
                                   and j1 ->> 'status' = 'queued' and j2 ->> 'status' = 'sent' and (svc.v1_notify_result(did, true, null) ->> 'duplicate')::boolean
                                   and (select attempts from notify.delivery where id = did) = 2,
                                   'deliveries retry with back-off, are recorded, and a repeated result changes nothing');
  -- ---------------------------------------------------------------- templates + sanitising
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S22-06', pg_temp.expect_fail($q$select api.v1_notify_set_template('approval.pending', 'x', '{{amount}} বাকি', 'x')$q$, 'E_NOTIFY_TEMPLATE')
                                   and pg_temp.expect_fail($q$select api.v1_notify_set_template('approval.pending', 'x', '<script>x</script>{{doc}}', 'x')$q$, 'E_NOTIFY_TEMPLATE')
                                   and api.v1_notify_set_template('approval.pending', 'অনুমোদন চাই', '{{doc}} দেখুন, প্লিজ।', 'friendlier') = 1
                                   and notify.fn_render('{{doc}}', '{"doc":"<b>{{x}}</b>"}') !~ '[<>{}]',
                                   'Bengali templates with whitelisted placeholders; values are sanitised');
  -- ---------------------------------------------------------------- security banner
  insert into iam.login_attempt (kind, outcome, reason, person_id) values ('pin_login', 'locked', 'test', p_ac);
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  j := api.v1_notify_banner();
  insert into _r values ('S22-07', jsonb_array_length(j) = 1 and j -> 0 ->> 'category' = 'security', 'critical items appear as a banner with generic text');
  -- ---------------------------------------------------------------- reminders + escalation
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_notify_set_escalation('test.%', 60, 'AUDITOR', 'auditor sees slow approvals');
  req := (core.fn_approval_submit(ca, 'test.document', gen_random_uuid(), 10, iam.fn_resource(ca), '{}'::jsonb) ->> 'request_id')::uuid;
  update core.approval_request set created_at = clock_timestamp() - interval '2 days' where id = req;
  j := svc.v1_notify_run();
  j1 := svc.v1_notify_run();
  insert into _r values ('S22-08', (j ->> 'reminders')::integer >= 1 and (j ->> 'escalations')::integer = 1 and (j1 ->> 'escalations')::integer = 0
                                   and exists (select 1 from notify.notification n where n.person_id = p_au and n.link_id = req and n.template_code = 'approval.escalated')
                                   and (select status from core.approval_request where id = req) = 'pending',
                                   'reminders and escalations are deterministic, idempotent and never approve');
  -- ---------------------------------------------------------------- audit search + export bundle
  perform pg_temp.as_user(u_au, 'au'); perform api.v1_iam_select_position(a_au);
  j := api.v1_audit_events(clock_timestamp() - interval '1 hour', null, 'core.approval_request', null, 50);
  s1 := (select min(seq) from audit.event where company_id = ca);
  j1 := api.v1_audit_export(s1, s1 + 20, 'tax inspection');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S22-09', jsonb_array_length(j) >= 1 and not exists (select 1 from jsonb_array_elements(j) x where x -> 'detail' -> 'new' ? 'payload')
                                   and (j1 ->> 'rows')::integer >= 1 and length(j1 ->> 'bundle_digest') = 64
                                   and (j1 -> 'events' -> 1 ->> 'prev_hash') = (j1 -> 'events' -> 0 ->> 'row_hash')
                                   and pg_temp.expect_fail($q$select api.v1_audit_export(1, 2, 'x')$q$, 'E_FORBIDDEN'),
                                   'audit search redacts; export bundle is hash-chained and digested; export needs its permission');
  -- ---------------------------------------------------------------- policy publication
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S22-10', pg_temp.expect_fail($q$select api.v1_approval_set_policy('test.document', 0, 2, null, 'x')$q$, 'E_POLICY_REVIEW_REQUIRED'),
                                   'policy changes go through review by default');
  prop := (api.v1_policy_propose('approval_policy', '{"document_type":"test.document","min_amount":0,"required_approvals":2}', null, 'two eyes') ->> 'proposal_id')::uuid;
  j := jsonb_build_object('self', pg_temp.expect_fail(format($f$select api.v1_policy_review(%L, 'approve', 'x')$f$, prop), 'E_SELF_APPROVAL'));
  perform pg_temp.as_user(u_ac, 'ac');
  j := j || jsonb_build_object('clerk', pg_temp.expect_fail(format($f$select api.v1_policy_review(%L, 'approve', 'x')$f$, prop), 'E_FORBIDDEN'));
  perform pg_temp.as_user(u_md, 'md');
  j1 := api.v1_policy_review(prop, 'approve', 'agreed');
  insert into _r values ('S22-11', (j ->> 'self')::boolean and (j ->> 'clerk')::boolean and j1 ->> 'status' = 'applied'
                                   and (select required_approvals from config.approval_policy where company_id = ca and document_type = 'test.document' and status = 'active') = 2
                                   and (select (simulation ->> 'requests_in_scope')::integer from config.policy_proposal where id = prop) >= 2,
                                   'simulation, an independent critical reviewer, then effective');
  insert into _r values ('S22-12', pg_temp.expect_fail($q$insert into core.recycle_class (code, name_bn, read_permission, write_permission) values ('audit.event','x','audit.read','audit.read')$q$),
                                   'audit can never become a recyclable class');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

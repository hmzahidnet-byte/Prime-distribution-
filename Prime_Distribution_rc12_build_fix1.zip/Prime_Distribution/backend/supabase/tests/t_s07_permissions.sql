-- S07 tests: single permission vocabulary, default matrix, resolver (scopes, precedence, supremacy, isolation), rule management.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true); perform set_config('request.jwt.claims', (jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session)
  || case when p_aal is null then '{}'::jsonb else jsonb_build_object('aal', p_aal) end)::text, true); end $$;
create or replace function pg_temp.can(p_perm text, r iam.resource) returns boolean language plpgsql as $$
declare v boolean; begin select allowed into v from iam.fn_authorize(p_perm, r, false); return v; end $$;
create or replace function pg_temp.why(p_perm text, r iam.resource) returns text language plpgsql as $$
declare v text; begin select reason into v from iam.fn_authorize(p_perm, r, false); return v; end $$;
do $$
declare ca uuid; cb uuid; w1 uuid; w2 uuid; wb uuid; d1 uuid; d1a uuid; d2 uuid; l1 uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_wh uuid := gen_random_uuid(); u_hr uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
        p_ch uuid; p_md uuid; p_wh uuid; p_hr uuid; p_ac uuid; a_ch uuid; a_md uuid; a_wh uuid; a_hr uuid; a_ac uuid;
        rid uuid; rid2 uuid; e0 integer; e1 integer; n integer; j jsonb;
begin
  insert into core.company (code, name_bn, status) values ('QA', 'ক', 'active') returning id into ca;
  insert into core.company (code, name_bn, status) values ('QB', 'খ', 'active') returning id into cb;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W2', 'দুই') returning id into w2;
  insert into core.wing (company_id, code, name_bn) values (cb, 'W1', 'এক') returning id into wb;
  insert into core.department (company_id, wing_id, code, name_bn) values (ca, w1, 'D1', 'ক') returning id into d1;
  insert into core.department (company_id, wing_id, parent_department_id, code, name_bn) values (ca, w1, d1, 'D1A', 'কক') returning id into d1a;
  insert into core.department (company_id, wing_id, code, name_bn) values (ca, w2, 'D2', 'খ') returning id into d2;
  insert into core.location (company_id, wing_id, code, name_bn, location_kind) values (ca, w1, 'L1', 'কারখানা', 'factory') returning id into l1;

  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't'); p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  p_wh := svc.v1_iam_provision_person('উইং', null, null, u_wh, 't'); p_hr := svc.v1_iam_provision_person('এইচআর', null, null, u_hr, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  a_ch := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ch, ca, null, 't'), 'CHAIRMAN', null, null, null, null, null, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  a_wh := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_wh, ca, null, 't'), 'WING_HEAD', null, null, null, w1, null, 't');
  a_hr := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_hr, ca, null, 't'), 'HR_OFFICER', null, null, null, w1, d1, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');

  select count(*) into n from iam.permission_catalog;
  insert into _r values ('S07-01', n >= 118 and (select count(distinct code) from iam.permission_catalog) = n
                                   and not exists (select 1 from iam.permission_catalog where code like '%vat%' or code like '%tax%' or code like '%cctv%' or module = 'ai'),
                                   'one vocabulary (117 + later codes); no VAT/Tax/CCTV/AI');
  insert into _r values ('S07-02', exists (select 1 from iam.position_permission_rule where company_id = ca and position_code = 'MD' and permission_code = 'audit.read' and origin = 'template')
                                   and (select count(*) from iam.position_permission_rule where company_id = ca and permission_code = 'iam.self.read') = 17
                                   and not exists (select 1 from iam.position_permission_rule where company_id = ca and position_code = 'CHAIRMAN'),
                                   'default matrix copied into a new company; none for the supreme Chairman');

  -- Chairman
  perform pg_temp.as_user(u_ch, 's-ch'); perform api.v1_iam_select_position(a_ch);
  insert into _r values ('S07-03', pg_temp.can('audit.read', iam.fn_resource(ca)) and pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, w2)), 'Chairman is supreme without any rule');
  insert into _r values ('S07-01', pg_temp.why('qr.revoke', iam.fn_resource(ca)) = 'permission_not_active', 'a module not built yet is denied even to the Chairman');
  insert into _r values ('S07-04', pg_temp.why('no.such.permission', iam.fn_resource(ca)) = 'unknown_permission', 'unknown permission denied');
  insert into _r values ('S07-05', pg_temp.why('audit.read', iam.fn_resource(cb)) = 'wrong_company'
                                   and pg_temp.why('audit.read', iam.fn_resource(ca, wb)) = 'wrong_company'
                                   and pg_temp.why('audit.read', iam.fn_resource(null)) = 'wrong_company', 'other company (or other company''s wing) denied even to the Chairman');
  insert into _r values ('S07-17', pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('CHAIRMAN','audit.read','deny','COMPANY',null,'x')$q$, 'E_PROTECTED_POSITION'), 'rules can never target the Chairman');
  insert into _r values ('S07-18', pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','audit.read','allow','WING',null,'x')$q$, 'E_SCOPE_NOT_ALLOWED')
                                   and pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','core.structure.read','allow','WAREHOUSE',gen_random_uuid(),'x')$q$)
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_set_position_rule('ACCOUNTANT','core.structure.read','allow','WING',%L,'x')$f$, wb), 'E_WRONG_COMPANY')
                                   and pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','audit.read','allow','COMPANY',null,' ')$q$, 'E_REASON_REQUIRED'),
                                   'scope must be allowed, available and inside the company; reason required');

  select authz_epoch into e0 from core.person where id = p_wh;
  rid := api.v1_iam_set_position_rule('WING_HEAD', 'iam.assignment.manage', 'allow', 'WING', null, 'wing heads manage their own wing');
  select authz_epoch into e1 from core.person where id = p_wh;
  insert into _r values ('S07-14', e1 > e0 and exists (select 1 from audit.event where company_id = ca and entity_id = rid and reason = 'wing heads manage their own wing' and actor_person_id = p_ch),
                                   'Chairman edits the matrix: audited with reason; holders'' authz_epoch bumped');
  perform api.v1_iam_set_position_rule('HR_OFFICER', 'iam.assignment.manage', 'allow', 'DEPARTMENT', null, 'hr manages own department tree');
  perform api.v1_iam_set_position_rule('MD', 'iam.permission.manage', 'allow', 'COMPANY', null, 'MD may maintain the matrix');
  perform api.v1_iam_set_position_rule('MD', 'iam.assignment.manage', 'allow', 'COMPANY', null, 'MD manages assignments');
  insert into _r values ('S07-15', pg_temp.expect_fail(format($f$update iam.position_permission_rule set effect='deny' where id=%L$f$, rid), 'E_IMMUTABLE'), 'rules are never edited, only revoked');

  -- Wing head: WING scope from home wing (resource wing, or derived from department/location)
  perform pg_temp.as_user(u_wh, 's-wh'); perform api.v1_iam_select_position(a_wh);
  insert into _r values ('S07-07', pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, w1))
                                   and pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, p_department => d1a))
                                   and pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, p_location => l1))
                                   and not pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, w2))
                                   and not pg_temp.can('iam.assignment.manage', iam.fn_resource(ca)), 'WING scope = own wing only (derived from department/location server-side)');
  insert into _r values ('S07-09', pg_temp.why('iam.assignment.manage', iam.fn_resource(ca, w2, d1)) = 'inconsistent_resource', 'inconsistent resource (wing vs department) denied');
  insert into _r values ('S07-22', pg_temp.can('iam.self.read', iam.fn_resource(ca, p_owner_person => p_wh)) and not pg_temp.can('iam.self.read', iam.fn_resource(ca, p_owner_person => p_md)), 'SELF scope = only my own records');

  -- HR officer: DEPARTMENT scope covers the department subtree
  perform pg_temp.as_user(u_hr, 's-hr'); perform api.v1_iam_select_position(a_hr);
  insert into _r values ('S07-08', pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, p_department => d1))
                                   and pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, p_department => d1a))
                                   and not pg_temp.can('iam.assignment.manage', iam.fn_resource(ca, p_department => d2)), 'DEPARTMENT scope includes child departments, nothing else');

  -- Accountant: nothing granted => deny
  perform pg_temp.as_user(u_ac, 's-ac'); perform api.v1_iam_select_position(a_ac);
  insert into _r values ('S07-06', pg_temp.why('audit.read', iam.fn_resource(ca)) = 'no_grant', 'no grant = deny by default');
  insert into _r values ('S07-20', pg_temp.expect_fail(format($f$select * from iam.fn_require('audit.read', iam.fn_resource(%L))$f$, ca), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail(format($f$select * from iam.fn_require('audit.read', iam.fn_resource(%L))$f$, cb), 'E_WRONG_COMPANY')
                                   and pg_temp.expect_fail(format($f$select * from iam.fn_require('qr.revoke', iam.fn_resource(%L))$f$, ca), 'E_FEATURE_NOT_READY'),
                                   'fn_require raises typed errors');

  -- MD: position deny beats allow; personal allow overrides; personal deny beats position allow; expired personal rule ignored
  perform pg_temp.as_user(u_md, 's-md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S07-16', pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('MD','audit.export','allow','COMPANY',null,'self')$q$, 'E_SELF_GRANT')
                                   and pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','iam.position.manage','allow','COMPANY',null,'x')$q$, 'E_FORBIDDEN')
                                   and pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','technical.diagnostics.read','allow','COMPANY',null,'x')$q$, 'E_FORBIDDEN')
                                   and api.v1_iam_set_position_rule('ACCOUNTANT', 'audit.verify', 'allow', 'COMPANY', null, 'accountant verifies chain') is not null,
                                   'delegated manager: no self-grant, no admin grants, only powers they hold');
  perform pg_temp.as_user(u_ch, 's-ch');
  rid := api.v1_iam_set_position_rule('MD', 'audit.read', 'deny', 'COMPANY', null, 'test deny');
  perform pg_temp.as_user(u_md, 's-md');
  insert into _r values ('S07-10', pg_temp.why('audit.read', iam.fn_resource(ca)) = 'denied_by_rule', 'position deny beats position allow');
  perform pg_temp.as_user(u_ch, 's-ch');
  rid2 := api.v1_iam_set_assignment_rule(a_md, 'audit.read', 'allow', 'COMPANY', null, null, 'personal exception');
  perform pg_temp.as_user(u_md, 's-md');
  insert into _r values ('S07-11', pg_temp.can('audit.read', iam.fn_resource(ca)), 'personal allow overrides the position deny');
  perform pg_temp.as_user(u_ch, 's-ch');
  perform api.v1_iam_set_assignment_rule(a_md, 'audit.verify', 'deny', 'COMPANY', null, null, 'personal deny');
  perform pg_temp.as_user(u_md, 's-md');
  insert into _r values ('S07-12', not pg_temp.can('audit.verify', iam.fn_resource(ca)), 'personal deny beats the position allow');
  insert into iam.assignment_permission_rule (company_id, assignment_id, permission_code, effect, scope_kind, valid_until, created_at, reason)
  values (ca, a_md, 'iam.session.revoke', 'allow', 'COMPANY', clock_timestamp() - interval '1 hour', clock_timestamp() - interval '2 hours', 'expired');
  insert into _r values ('S07-13', not pg_temp.can('iam.session.revoke', iam.fn_resource(ca)), 'expired personal rule is ignored');
  j := api.v1_iam_my_permissions();
  insert into _r values ('S07-21', not (j ->> 'is_supreme')::boolean
                                   and exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'iam.permission.manage')
                                   and not exists (select 1 from jsonb_array_elements(j -> 'permissions') e where e ->> 'code' = 'audit.verify'),
                                   'my_permissions lists grants and hides company-wide personal denials');

  -- Chairman revocation of a template rule is respected by later backfills
  perform pg_temp.as_user(u_ch, 's-ch');
  select id into rid from iam.position_permission_rule where company_id = ca and position_code = 'AUDITOR' and permission_code = 'audit.read' and status = 'active';
  perform api.v1_iam_revoke_position_rule(rid, 'auditor read via request only');
  perform iam.fn_backfill_template_rules(ca);
  insert into _r values ('S07-19', not exists (select 1 from iam.position_permission_rule where company_id = ca and position_code = 'AUDITOR' and permission_code = 'audit.read' and status = 'active')
                                   and pg_temp.expect_fail(format($f$update iam.position_permission_rule set status='active', revoked_at=null where id=%L$f$, rid), 'E_IMMUTABLE'),
                                   'revoked template rule is never re-added and stays frozen');
  j := api.v1_iam_my_permissions();
  insert into _r values ('S07-21', (j ->> 'is_supreme')::boolean and jsonb_array_length(j -> 'permissions') = (select count(*) from iam.permission_catalog where status = 'active'), 'supreme sees every active permission');

  -- MFA: positions listed in iam.mfa.required_positions (default CHAIRMAN, MD) need aal2 for ANY request
  perform pg_temp.as_user(u_ch, 's-ch', 'aal1');
  insert into _r values ('S07-25', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_MFA_REQUIRED'), 'Chairman without MFA is refused (ADR-08 default)');
  -- permission-level MFA switch (accountant holds audit.verify from S07-16)
  update iam.permission_catalog set requires_aal2 = true where code = 'audit.verify';
  perform pg_temp.as_user(u_ac, 's-ac', 'aal1');
  insert into _r values ('S07-23', pg_temp.why('audit.verify', iam.fn_resource(ca)) = 'mfa_required', 'MFA-required permission denied on aal1');
  perform pg_temp.as_user(u_ac, 's-ac', 'aal2');
  insert into _r values ('S07-23', pg_temp.can('audit.verify', iam.fn_resource(ca)), 'allowed on aal2');
  update iam.permission_catalog set requires_aal2 = false where code = 'audit.verify';

  -- revocation of the position removes every right on the next call
  perform svc.v1_iam_end_assignment(a_wh, 'transfer');
  perform pg_temp.as_user(u_wh, 's-wh');
  insert into _r values ('S07-24', pg_temp.expect_fail($q$select pg_temp.can('iam.self.read', iam.fn_resource(null))$q$, 'E_NO_ACTIVE_POSITION'), 'ended assignment = no rights at all');
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

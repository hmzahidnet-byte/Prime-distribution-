-- S11 tests: module catalog/dependencies/releases, company lifecycle, server-side module gate (disabled / read-only /
-- wing scope), upgrade & data-safe rollback, immutable history, versioned scoped feature flags, permissions.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.why(p_perm text, r iam.resource) returns text language plpgsql as $$
declare v text; begin select reason into v from iam.fn_authorize(p_perm, r, false); return v; end $$;
create or replace function pg_temp.rv(p_company uuid, p_module text) returns integer language sql as $$
  select row_version from config.company_module where company_id = p_company and module_code = p_module $$;
do $$
declare boot jsonb; ca uuid; cb uuid; w1 uuid; w2 uuid; wb uuid; a_ch uuid; a_md uuid; p_ch uuid; p_md uuid; n integer; j jsonb; v integer;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid();
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('MOD', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  boot := svc.v1_gov_bootstrap_company('MOE', 'খ', p_ch, 't'); cb := (boot ->> 'company_id')::uuid;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W2', 'দুই') returning id into w2;
  insert into core.wing (company_id, code, name_bn) values (cb, 'W1', 'এক') returning id into wb;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');

  select count(*) into n from config.company_module where company_id = ca;
  insert into _r values ('S11-01', n = (select count(*) from config.module_catalog)
     and not exists (select 1 from config.company_module cm join config.module_catalog m on m.code = cm.module_code where cm.company_id = ca and m.is_core and cm.status <> 'enabled')
     and not exists (select 1 from config.company_module cm join config.module_catalog m on m.code = cm.module_code where cm.company_id = ca and m.status = 'registered' and cm.status <> 'disabled')
     and (select count(*) from config.company_module_event where company_id = ca and action = 'seed') = n, 'new company: core on, unbuilt modules off, seeded with history');
  insert into _r values ('S11-17', pg_temp.expect_fail($q$insert into config.module_dependency values ('master','inventory','hard')$q$, 'E_MODULE_CYCLE'), 'cyclic hard dependency rejected');
  insert into _r values ('S11-18', pg_temp.expect_fail($q$update config.module_release set data_schema_version = 9 where module_code = 'core'$q$, 'E_APPEND_ONLY'), 'releases are immutable');

  -- build two modules (what a later step does) + make one of their permissions active for gate tests
  perform config.fn_make_module_available('master');
  perform config.fn_make_module_available('inventory');
  update iam.permission_catalog set status = 'active' where code in ('master.sku.read', 'master.sku.manage');
  insert into _r values ('S11-04', (select status from config.company_module where company_id = ca and module_code = 'master') = 'enabled'
                                   and (select status from config.company_module where company_id = ca and module_code = 'inventory') = 'enabled',
                                   'a newly built module is enabled automatically where the company never decided otherwise');

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  -- the S24 template already grants MD master.sku.read; grant only if this database predates it
  if not exists (select 1 from iam.position_permission_rule where company_id = ca and position_code = 'MD' and permission_code = 'master.sku.read'
                  and effect = 'allow' and scope_kind = 'COMPANY' and scope_id is null and status = 'active') then
    perform api.v1_iam_set_position_rule('MD', 'master.sku.read', 'allow', 'COMPANY', null, 't');
  end if;
  perform api.v1_iam_set_position_rule('MD', 'master.sku.manage', 'allow', 'COMPANY', null, 't');
  insert into _r values ('S11-02', pg_temp.expect_fail(format($f$select api.v1_config_module_action('iam','suspend',%s,'x')$f$, pg_temp.rv(ca,'iam')), 'E_CORE_PROTECTED'), 'core modules cannot be switched off');
  -- every real module is built by now: register a lab module that is not built yet
  insert into config.module_catalog (code, name_bn, is_core, permission_modules, wing_scopable, status, sort_order) values ('lab', 'পরীক্ষাগার', false, array['lab'], false, 'registered', 999);
  insert into config.company_module (company_id, module_code, status) values (ca, 'lab', 'disabled');
  insert into _r values ('S11-03', pg_temp.expect_fail(format($f$select api.v1_config_module_action('lab','enable',%s,'x')$f$, coalesce(pg_temp.rv(ca,'lab'), 0)), 'E_MODULE_NOT_AVAILABLE'), 'unbuilt module cannot be enabled');
  insert into _r values ('S11-10', pg_temp.expect_fail($q$select api.v1_config_module_action('master','suspend',999,'x')$q$, 'E_STALE_VERSION'), 'optimistic version on module changes');
  insert into _r values ('S11-05', pg_temp.expect_fail(format($f$select api.v1_config_module_action('master','suspend',%s,'x',false)$f$, pg_temp.rv(ca,'master')), 'E_MODULE_DEPENDENTS'), 'cannot suspend a module others depend on (without cascade)');
  perform api.v1_config_module_action('master', 'suspend', pg_temp.rv(ca, 'master'), 'stock audit week', true);
  perform set_config('mohona.company_scope', '', true);          -- read both companies (test only)
  insert into _r values ('S11-06', (select status from config.company_module where company_id = ca and module_code = 'inventory') = 'suspended'
                                   and (select status from config.company_module where company_id = cb and module_code = 'master') = 'enabled',
                                   'cascade suspends dependents; other company unaffected');
  insert into _r values ('S11-05', pg_temp.expect_fail(format($f$select api.v1_config_module_action('inventory','resume',%s,'x')$f$, pg_temp.rv(ca,'inventory')), 'E_MODULE_DEPENDENCY'), 'dependencies checked before enabling');

  -- gate while suspended: read yes, write no
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S11-07', pg_temp.why('master.sku.read', iam.fn_resource(ca)) = 'granted'
                                   and pg_temp.why('master.sku.manage', iam.fn_resource(ca)) = 'module_read_only'
                                   and pg_temp.expect_fail(format($f$select * from iam.fn_require('master.sku.manage', iam.fn_resource(%L))$f$, ca), 'E_MODULE_READ_ONLY'),
                                   'suspended module: read-only, enforced on the server');
  insert into _r values ('S11-15', pg_temp.expect_fail(format($f$select api.v1_config_module_action('master','resume',%s,'x')$f$, pg_temp.rv(ca,'master')), 'E_FORBIDDEN')
                                   and jsonb_array_length(api.v1_config_modules()) = (select count(*) from config.module_catalog), 'MD reads modules but cannot change them');

  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_module_action('inventory', 'retire', pg_temp.rv(ca, 'inventory'), 'moved to new system');
  perform api.v1_config_module_action('master', 'retire', pg_temp.rv(ca, 'master'), 'archive');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S11-08', pg_temp.why('master.sku.read', iam.fn_resource(ca)) = 'granted' and pg_temp.why('master.sku.manage', iam.fn_resource(ca)) = 'module_read_only'
                                   and (select count(*) from config.company_module where company_id = ca and module_code = 'master') = 1, 'retired = archive views/exports only, nothing deleted');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_module_action('master', 'reactivate', pg_temp.rv(ca, 'master'), 'back in use');
  -- wing scope
  insert into _r values ('S11-09', pg_temp.expect_fail(format($f$select api.v1_config_module_set_wings('master', array[%L]::uuid[], %s, 'x')$f$, wb, pg_temp.rv(ca,'master')), 'E_WRONG_COMPANY')
                                   and pg_temp.expect_fail(format($f$select api.v1_config_module_set_wings('finance', array[%L]::uuid[], %s, 'x')$f$, w1, pg_temp.rv(ca,'finance')), 'E_INVALID_ACTION'), 'wing scope: own wings only, scopable modules only');
  perform api.v1_config_module_set_wings('master', array[w1], pg_temp.rv(ca, 'master'), 'pilot in wing 1');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S11-09', pg_temp.why('master.sku.manage', iam.fn_resource(ca, w1)) = 'granted' and pg_temp.why('master.sku.manage', iam.fn_resource(ca, w2)) = 'module_not_in_wing',
                                   'wing-scoped module works only in listed wings');
  j := api.v1_config_my_modules();
  insert into _r values ('S11-16', exists (select 1 from jsonb_array_elements(j) x where x ->> 'code' = 'master' and x ->> 'mode' = 'full')
                                   and not exists (select 1 from jsonb_array_elements(j) x where x ->> 'code' = 'inventory' and x ->> 'mode' = 'full'), 'launcher shows only modules the position can use (a retired one at most read-only)');

  -- upgrade / rollback
  perform pg_temp.as_user(u_ch, 'ch');
  insert into config.module_release (module_code, version, compatible_from, data_schema_version, rollback_safe) values
    ('master', '1.1.0', '1.0.0', 1, true), ('master', '2.0.0', '1.1.0', 2, false);
  insert into _r values ('S11-11', pg_temp.expect_fail(format($f$select api.v1_config_module_upgrade('master','2.0.0',%s,'x')$f$, pg_temp.rv(ca,'master')), 'E_VERSION_INCOMPATIBLE'), 'upgrade path enforced (1.1.0 first)');
  perform api.v1_config_module_upgrade('master', '1.1.0', pg_temp.rv(ca, 'master'), 'minor');
  perform api.v1_config_module_rollback('master', '1.0.0', pg_temp.rv(ca, 'master'), 'bug in 1.1');
  perform api.v1_config_module_upgrade('master', '1.1.0', pg_temp.rv(ca, 'master'), 'fixed');
  perform api.v1_config_module_upgrade('master', '2.0.0', pg_temp.rv(ca, 'master'), 'major');
  insert into _r values ('S11-12', (select version from config.company_module where company_id = ca and module_code = 'master') = '2.0.0'
                                   and pg_temp.expect_fail(format($f$select api.v1_config_module_rollback('master','1.1.0',%s,'x')$f$, pg_temp.rv(ca,'master')), 'E_ROLLBACK_UNSAFE'),
                                   'safe rollback allowed; rollback across a data-schema change refused');
  j := api.v1_config_module_history('master');
  insert into _r values ('S11-13', jsonb_array_length(j) >= 9 and j -> 0 ->> 'action' = 'upgrade'
                                   and pg_temp.expect_fail(format($f$update config.company_module_event set reason='x' where company_id=%L$f$, ca), 'E_APPEND_ONLY'),
                                   'complete, immutable lifecycle history');

  -- feature flags
  -- separate statements: a stable read inside the same statement would not see the write
  n := 0;
  if not config.fn_flag(ca, 'design.ad_slots') and config.fn_flag(ca, 'inventory.fefo_picking') then n := n + 1; end if;
  if api.v1_config_set_flag('design.ad_slots', null, true, 0, 'show ads') = 1 then n := n + 1; end if;
  if api.v1_config_set_flag('inventory.fefo_picking', w1, false, 0, 'manual picking in wing 1') = 1 then n := n + 1; end if;
  insert into _r values ('S11-14', n = 3 and config.fn_flag(ca, 'design.ad_slots') and not config.fn_flag(cb, 'design.ad_slots')
                                   and not config.fn_flag(ca, 'inventory.fefo_picking', w1) and config.fn_flag(ca, 'inventory.fefo_picking', w2),
                                   'versioned company/wing flags with defaults');
  insert into _r values ('S11-19', pg_temp.expect_fail($q$select api.v1_config_set_flag('iam.audit_trail', null, false, 0, 'x')$q$, 'E_CORE_PROTECTED')
                                   and pg_temp.expect_fail($q$select api.v1_config_set_flag('design.ad_slots', null, false, 0, 'stale')$q$, 'E_STALE_VERSION')
                                   and pg_temp.expect_fail(format($f$select api.v1_config_set_flag('design.ad_slots', %L, false, 0, 'x')$f$, wb), 'E_WRONG_COMPANY')
                                   and pg_temp.expect_fail($q$select api.v1_config_set_flag('no.such', null, true, 0, 'x')$q$, 'E_FLAG_UNKNOWN')
                                   and config.fn_flag(ca, 'iam.audit_trail'), 'core-security flags cannot be disabled; stale/foreign/unknown rejected');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

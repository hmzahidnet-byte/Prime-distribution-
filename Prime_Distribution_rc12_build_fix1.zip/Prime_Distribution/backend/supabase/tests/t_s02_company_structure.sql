-- S02 tests: company-only model, composite-key isolation, immutability, no delete, department cycles, audit chain.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
do $$
declare ca uuid; cb uuid; wa uuid; wb uuid; d1 uuid; d2 uuid; d3 uuid; e0 integer; e1 integer; bad bigint; n bigint;
begin
  insert into core.company (code, name_bn) values ('CA', 'কোম্পানি ক') returning id into ca;
  insert into core.company (code, name_bn) values ('CB', 'কোম্পানি খ') returning id into cb;
  insert into core.wing (company_id, code, name_bn, wing_kind) values (ca, 'MFG', 'উৎপাদন', 'manufacturing') returning id into wa;
  insert into core.wing (company_id, code, name_bn) values (cb, 'MFG', 'উৎপাদন') returning id into wb;

  insert into _r values ('S02-01', pg_temp.expect_fail(format($f$insert into core.company (code, name_bn) values ('CA','x')$f$)), 'duplicate company code rejected');
  insert into _r values ('S02-02', pg_temp.expect_fail(format($f$update core.company set code='CZ' where id=%L$f$, ca), 'E_IMMUTABLE'), 'company code immutable');
  insert into _r values ('S02-03', pg_temp.expect_fail(format($f$insert into core.department (company_id, wing_id, code, name_bn) values (%L,%L,'D1','x')$f$, ca, wb)), 'department cannot use another company''s wing');
  insert into _r values ('S02-04', pg_temp.expect_fail(format($f$insert into core.location (company_id, wing_id, code, name_bn, location_kind) values (%L,%L,'L1','x','factory')$f$, ca, wb)), 'location cannot use another company''s wing');
  insert into _r values ('S02-05', pg_temp.expect_fail(format($f$delete from core.company where id=%L$f$, cb), 'E_NO_DELETE'), 'company delete rejected');

  insert into core.department (company_id, wing_id, code, name_bn) values (ca, wa, 'D1', 'এক') returning id into d1;
  insert into core.department (company_id, wing_id, parent_department_id, code, name_bn) values (ca, wa, d1, 'D2', 'দুই') returning id into d2;
  insert into core.department (company_id, wing_id, parent_department_id, code, name_bn) values (ca, wa, d2, 'D3', 'তিন') returning id into d3;
  insert into _r values ('S02-06', pg_temp.expect_fail(format($f$update core.department set parent_department_id=%L where id=%L$f$, d3, d1), 'E_DEPARTMENT_CYCLE'), 'department cycle rejected');

  select status_epoch into e0 from core.company where id = ca;
  update core.company set status = 'active' where id = ca;
  select status_epoch into e1 from core.company where id = ca;
  insert into _r values ('S02-10', e1 = e0 + 1, 'status change increments status_epoch');
  insert into _r values ('S02-11', pg_temp.expect_fail(format($f$update core.company set status='active' where id=(select id from core.company where code='CB')$f$)) = false
                                   and pg_temp.expect_fail(format($f$update core.company set status='closed' where id=%L$f$, cb)) = false
                                   and pg_temp.expect_fail(format($f$update core.company set status='active' where id=%L$f$, cb), 'E_COMPANY_CLOSED'), 'closed company cannot be reopened');
  insert into _r values ('S02-12', not exists (select 1 from information_schema.columns where table_schema = 'core' and table_name = 'company'
                                                and column_name in ('kind','parent_organization_id','group_id')), 'no group concept in core.company');
  insert into _r values ('S02-13', pg_temp.expect_fail(format($f$update core.wing set company_id=%L where id=%L$f$, cb, wa), 'E_IMMUTABLE'), 'wing cannot move to another company');

  select count(*) into n from audit.event where company_id = ca;
  insert into _r values ('S02-07', n >= 6 and audit.fn_verify_chain(ca) is null, 'row changes audited (' || n || ' events) and chain verifies');
  insert into _r values ('S02-08', pg_temp.expect_fail(format($f$update audit.event set action='x' where company_id=%L and seq=1$f$, ca), 'E_APPEND_ONLY')
                                   and pg_temp.expect_fail(format($f$delete from audit.event where company_id=%L$f$, ca), 'E_APPEND_ONLY'), 'audit UPDATE/DELETE rejected');
  alter table audit.event disable trigger trg_event_no_mutation;
  update audit.event set reason = 'tampered' where company_id = ca and seq = 2;
  alter table audit.event enable trigger trg_event_no_mutation;
  bad := audit.fn_verify_chain(ca);
  insert into _r values ('S02-09', bad = 2, 'tampering detected at seq 2 (got ' || coalesce(bad::text, 'null') || ')');
  insert into _r values ('S02-14', audit.fn_verify_chain(cb) is null and not exists (select 1 from audit.event where company_id = cb and entity_id in (wa, d1, d2, d3)), 'company B chain independent of company A');
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

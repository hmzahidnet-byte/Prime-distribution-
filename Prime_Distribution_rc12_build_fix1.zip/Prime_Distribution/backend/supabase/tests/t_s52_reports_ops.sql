-- S52–S55 tests: custom reports (no SQL, approved versioned templates, runner's own scope, shares to named people,
-- schedules under the owner's rights, retirement keeps outputs), backup / drill records (never on production,
-- independent approval, RPO/RTO from records), tenant manifest, release sign-off by different people, final
-- integration (module gate, one Chairman seat, requirement registry).
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
do $$
declare boot jsonb; ca uuid; cb uuid; a_ch uuid; a_md uuid; a_fm uuid; a_au uuid; a_hr uuid; p_ch uuid; p_md uuid; p_fm uuid; p_au uuid; p_hr uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_au uuid := gen_random_uuid(); u_hr uuid := gen_random_uuid();
        u_ch2 uuid := gen_random_uuid();
        emp uuid; tpl uuid; tpl2 uuid; outp jsonb; sh jsonb; sch uuid; bk uuid; dr jsonb; j jsonb; j1 jsonb; n integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('RPT', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_au := svc.v1_iam_provision_person('নিরীক্ষক', null, null, u_au, 't'); a_au := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_au, ca, null, 't'), 'AUDITOR', null, null, null, null, null, 't');
  p_hr := svc.v1_iam_provision_person('এইচআর', null, null, u_hr, 't'); a_hr := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_hr, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('RPX', 'খ', p_ch2, 't'); cb := (boot ->> 'company_id')::uuid;
  emp := (select id from hr.employee where person_id = p_hr and company_id = ca);
  perform set_config('mohona.company_scope', '', true);
  insert into hr.attendance_event (company_id, employee_id, event_at, method, status, reason, created_by)
  values (ca, emp, clock_timestamp() - interval '1 day', 'manual', 'posted', 'test', p_md), (ca, emp, clock_timestamp() - interval '1 day 2 hours', 'manual', 'posted', 'test', p_md);

  -- ---------------------------------------------------------------- templates (F291, F292, F300)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  insert into _r values ('S52-01', pg_temp.expect_fail($q$select api.v1_report_template_save('ATT', 'হাজিরা', 'attendance_days', '{"sql":"select * from hr.employee"}')$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail($q$select api.v1_report_template_save('ATT', 'হাজিরা', 'attendance_days', '{"columns":["salary"]}')$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail($q$select api.v1_report_template_save('ATT', 'হাজিরা', 'pg_shadow', '{}')$q$, 'E_NOT_FOUND'),
                                   'the builder accepts only whitelisted datasets, columns and options — never SQL');
  tpl := (api.v1_report_template_save('ATT', 'কর্মীভিত্তিক হাজিরা', 'attendance_days', '{"group_by":"employee","aggregate":"sum","measure":"events","chart":"bar"}') ->> 'template_id')::uuid;
  insert into _r values ('S52-02', pg_temp.expect_fail(format($f$select api.v1_report_template_action(%L, 'approve')$f$, tpl), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail(format($f$select api.v1_report_run(%L, null, 'view')$f$, tpl), 'E_NOT_FOUND'),
                                   'a template runs only after approval by someone with the approval right');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_report_template_action(tpl, 'approve');
  outp := api.v1_report_run(tpl, null, 'csv');
  perform pg_temp.as_user(u_fm, 'fm');
  j := api.v1_report_run(tpl, null, 'view');
  insert into _r values ('S52-03', outp ->> 'chart' = 'bar' and (outp -> 'rows' -> 0 ->> 'value')::numeric = 2 and outp -> 'rows' -> 0 ->> 'employee' = 'এইচআর'
                                   and jsonb_array_length(j -> 'rows') = 0
                                   and (select count(*) from report.access_log where company_id = ca) = 2
                                   and (select action from report.access_log where company_id = ca and person_id = p_md) = 'export',
                                   'each run shows only what the runner may see (no elevation through a template); views and exports are logged');
  tpl2 := (api.v1_report_template_save('ATT', 'কর্মীভিত্তিক হাজিরা', 'attendance_days', '{"columns":["date","employee","events"],"chart":"table"}') ->> 'template_id')::uuid;
  insert into _r values ('S52-04', pg_temp.expect_fail(format($f$update report.template set spec = '{}' where id = %L$f$, tpl), 'E_IMMUTABLE')
                                   and (select version from report.template where id = tpl2) = 2,
                                   'templates are versioned, never edited');
  -- ---------------------------------------------------------------- sharing + schedules (F293, F297)
  perform pg_temp.as_user(u_md, 'md');
  sh := api.v1_report_share((outp ->> 'output_id')::uuid, p_au, 3);
  insert into _r values ('S52-05', pg_temp.expect_fail(format($f$select api.v1_report_share(%L, %L, 60)$f$, outp ->> 'output_id', p_au), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_report_open_shared(%L)$f$, sh ->> 'token'), 'E_NOT_FOUND'),
                                   'shares are time-limited and open only for the named recipient');
  perform pg_temp.as_user(u_au, 'au'); perform api.v1_iam_select_position(a_au);
  j := api.v1_report_open_shared(sh ->> 'token');
  insert into _r values ('S52-06', j ->> 'checksum' = outp ->> 'checksum' and pg_temp.expect_fail($q$select api.v1_report_open_shared('not-a-token')$q$, 'E_NOT_FOUND'),
                                   'the named recipient opens exactly the stored output');
  perform pg_temp.as_user(u_md, 'md');
  sch := (api.v1_report_schedule(tpl, 'daily', array[p_au], null) ->> 'schedule_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_report_schedule(tpl, 'weekly', array[p_md], null);
  update report.schedule set next_run = current_date where company_id = ca;
  n := svc.v1_report_run_schedules();
  insert into _r values ('S52-07', n = 1 and (select status from report.schedule where owner_id = p_fm) = 'stopped'
                                   and (select next_run from report.schedule where id = sch) = current_date + 1
                                   and exists (select 1 from report.output o where o.company_id = ca and o.run_by = p_md and o.checksum = outp ->> 'checksum' and o.id <> (outp ->> 'output_id')::uuid)
                                   and exists (select 1 from notify.notification x where x.person_id = p_au and x.link_kind = 'report_output'),
                                   'schedules run with the owner''s company-wide rights (or stop); recipients are notified');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_report_template_action(tpl, 'archive');
  insert into _r values ('S52-08', pg_temp.expect_fail(format($f$select api.v1_report_run(%L, null, 'view')$f$, tpl), 'E_NOT_FOUND')
                                   and (select count(*) from report.output where template_id = tpl) = 3
                                   and pg_temp.expect_fail(format($f$delete from report.output where template_id = %L$f$, tpl)),
                                   'a retired template stops running; its outputs stay');
  -- ---------------------------------------------------------------- backup, drill, manifest (F251–F260)
  bk := svc.v1_backup_record('pitr_check', 'production', clock_timestamp() - interval '10 minutes', clock_timestamp() - interval '5 minutes', 'ok', null, repeat('ab', 32),
                             clock_timestamp() - interval '20 minutes', 'kms:mohona-backup-2026', 'ops-bot', current_date + 30);
  insert into _r values ('S52-09', pg_temp.expect_fail($q$select svc.v1_backup_record('storage_copy', 'production', clock_timestamp(), clock_timestamp(), 'ok', 10, null, clock_timestamp(), 'password=abc', 'x', null)$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$update core.backup_run set status = 'failed' where id = %L$f$, bk)),
                                   'backup records keep key references only and are append-only');
  perform pg_temp.as_user(u_au, 'au'); perform api.v1_iam_select_position(a_au);
  insert into _r values ('S52-10', pg_temp.expect_fail(format($f$select api.v1_recovery_drill_record('production', %L, null, clock_timestamp(), clock_timestamp(), repeat('cd', 32))$f$, bk)),
                                   'a restore is never tested on production');
  dr := api.v1_recovery_drill_record('isolated', bk, ca, clock_timestamp(), clock_timestamp() + interval '90 minutes', repeat('cd', 32));
  insert into _r values ('S52-11', (dr ->> 'rpo_minutes')::numeric between 19.9 and 20.5 and (dr ->> 'rto_minutes')::numeric = 90 and (dr ->> 'rpo_target_met')::boolean and (dr ->> 'rto_target_met')::boolean
                                   and pg_temp.expect_fail(format($f$select api.v1_recovery_drill_approve(%L)$f$, dr ->> 'drill_id'), 'E_FORBIDDEN'),
                                   'RPO / RTO are measured from the records; the operator cannot approve the own drill');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_recovery_drill_approve((dr ->> 'drill_id')::uuid);
  j := svc.v1_tenant_manifest(ca); j1 := svc.v1_tenant_manifest(cb);
  insert into _r values ('S52-12', pg_temp.expect_fail(format($f$update core.recovery_drill set rto_minutes = 1 where id = %L$f$, dr ->> 'drill_id'), 'E_IMMUTABLE')
                                   and (j -> 'iam.company_membership' ->> 'rows')::integer = 5 and (j1 -> 'iam.company_membership' ->> 'rows')::integer = 1
                                   and j -> 'iam.company_membership' ->> 'checksum' <> j1 -> 'iam.company_membership' ->> 'checksum',
                                   'approved drill evidence is frozen; the restore manifest is per company');
  -- ---------------------------------------------------------------- release gate + final integration (F267, F268, F271, F279)
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  j := api.v1_release_signoff('1.0.0', 'finance', 'ledger checks done');
  insert into _r values ('S52-13', not (j ->> 'ready')::boolean and pg_temp.expect_fail($q$select api.v1_release_signoff('1.0.0', 'security', 'x')$q$, 'E_SELF_APPROVAL'),
                                   'each release area is signed by a different person; nothing publishes itself');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_governance_check(); j1 := api.v1_requirement_registry('failed');
  insert into _r values ('S52-14', (j ->> 'chairman_seats')::integer = 1 and (j1 ->> 'features')::integer = 300 and (j1 ->> 'passed')::integer < 300
                                   and svc.v1_delegations_expire() = 0
                                   and pg_temp.expect_fail(format($f$insert into iam.position_assignment (company_id, membership_id, position_code, kind)
                                         select %L, m.id, 'CHAIRMAN', 'regular' from iam.company_membership m where m.company_id = %L and m.person_id = %L$f$, ca, ca, p_md)),
                                   'one Chairman seat per company; all 300 requirements registered and none claimed as passed without evidence');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_config_module_action('report', 'suspend', (select row_version from config.company_module where company_id = ca and module_code = 'report'), 'frozen for audit', true);
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S52-15', pg_temp.expect_fail($q$select api.v1_report_template_save('X1', 'x', 'attendance_days', '{}')$q$)
                                   and jsonb_array_length(api.v1_report_datasets()) >= 1,
                                   'the module switch now gates report permissions: suspended = read-only');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S10 tests: settings registry (defaults, typed validation, versioned history, optimistic version, permission, MFA flag),
-- HR employee/employment chain (auto-created, mirrored, enforced by fn_context), settings-driven behaviour.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
do $$
declare boot jsonb; ca uuid; cb uuid; a_ch uuid; a_md uuid; a_ac uuid; m_ac uuid; p_ch uuid; p_ac uuid; p_md uuid; j jsonb; v integer; e record;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('CFG', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  boot := svc.v1_gov_bootstrap_company('CFB', 'খ', p_ch, 't'); cb := (boot ->> 'company_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  m_ac := svc.v1_iam_add_membership(p_ac, ca, 'E-9', 't');
  a_ac := svc.v1_iam_assign_position(m_ac, 'ACCOUNTANT', null, null, null, null, null, 't');

  insert into _r values ('S10-01', config.fn_get_int(ca, 'iam.delegation.max_days') = 30 and config.fn_get_int(ca, 'iam.session.max_concurrent') = 1
                                   and config.fn_get_int(ca, 'finance.money.scale') = 2 and config.fn_get_text(ca, 'finance.rounding.mode') = 'HALF_UP'
                                   and config.fn_get_text_array(ca, 'iam.mfa.required_positions') = array['CHAIRMAN','MD']
                                   and not config.fn_get_bool(ca, 'approval.chairman_self_approval.allowed')
                                   and config.fn_get_text(ca, 'ui.theme.primary') = '#1456A0'
                                   and (select count(*) from config.setting_definition) >= 28, 'best-practice defaults (V179 ADRs) are effective without any choice');
  insert into _r values ('S10-02', pg_temp.expect_fail($q$select config.fn_get(gen_random_uuid(), 'no.such.key')$q$, 'E_SETTING_UNKNOWN'), 'unknown setting is an error, never a silent default');

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  v := api.v1_config_set('iam.delegation.max_days', '45', 0, 'longer cover during Eid');
  insert into _r values ('S10-03', v = 1 and config.fn_get_int(ca, 'iam.delegation.max_days') = 45 and config.fn_get_int(cb, 'iam.delegation.max_days') = 30,
                                   'Chairman changes a setting for this company only');
  insert into _r values ('S10-04', pg_temp.expect_fail($q$select api.v1_config_set('iam.delegation.max_days', '60', 0, 'stale editor')$q$, 'E_STALE_VERSION')
                                   and pg_temp.expect_fail($q$select api.v1_config_set('iam.delegation.max_days', '999', 1, 'x')$q$, 'E_SETTING_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_config_set('iam.delegation.max_days', '"abc"', 1, 'x')$q$, 'E_SETTING_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_config_set('finance.rounding.mode', '"BANKERS"', 0, 'x')$q$, 'E_SETTING_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_config_set('iam.mfa.required_positions', '[1,2]', 0, 'x')$q$, 'E_SETTING_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_config_set('iam.delegation.max_days', '40', 1, ' ')$q$, 'E_REASON_REQUIRED'),
                                   'typed validation, ranges, allowed values, optimistic version, reason');
  v := api.v1_config_reset('iam.delegation.max_days', 1, 'back to default');
  j := api.v1_config_history('iam.delegation.max_days');
  insert into _r values ('S10-05', v = 2 and config.fn_get_int(ca, 'iam.delegation.max_days') = 30 and jsonb_array_length(j) = 2
                                   and (j -> 0 ->> 'is_reset')::boolean
                                   and pg_temp.expect_fail(format($f$update config.setting_value set value='5' where company_id=%L$f$, ca), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$delete from config.setting_value where company_id=%L$f$, ca), 'E_NO_DELETE'),
                                   'reset to default keeps full history; history is immutable');
  insert into _r values ('S10-06', exists (select 1 from audit.event where company_id = ca and entity_table = 'config.setting_value' and reason = 'longer cover during Eid'),
                                   'setting changes are audited with reason');
  j := api.v1_config_settings('finance');
  insert into _r values ('S10-07', jsonb_array_length(j) >= 5 and exists (select 1 from jsonb_array_elements(j) x where x ->> 'key' = 'finance.money.scale' and (x ->> 'is_default')::boolean),
                                   'settings list shows effective value and default flag');

  -- permission: MD can read (template) but not change
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S10-08', jsonb_array_length(api.v1_config_settings(null)) >= 28
                                   and pg_temp.expect_fail($q$select api.v1_config_set('ui.theme.primary', '"#000000"', 0, 'x')$q$, 'E_FORBIDDEN'),
                                   'MD reads settings; only the Chairman (or whom he grants) changes them');
  -- accountant: no read permission by default
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  insert into _r values ('S10-09', pg_temp.expect_fail('select api.v1_config_settings(null)', 'E_FORBIDDEN'), 'no settings access without permission');

  -- HR chain
  perform set_config('mohona.company_scope', '', true);
  select e2.id, em.status into e from hr.employee e2 join hr.employment em on em.employee_id = e2.id where e2.membership_id = m_ac;
  insert into _r values ('S10-10', e.status = 'active' and (select employee_code from hr.employee where membership_id = m_ac) = 'E-9', 'membership creates employee + active employment');
  update hr.employment set status = 'suspended' where employee_id = e.id;
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S10-11', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_EMPLOYMENT_INACTIVE'), 'suspended employment blocks every request (ADR)');
  perform set_config('mohona.company_scope', '', true);
  insert into config.setting_value (company_id, key, value, version, reason) values (ca, 'hr.require_active_employment', 'false', 1, 'test switch');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S10-12', (api.v1_iam_current_context() ->> 'position_code') = 'ACCOUNTANT', 'the Chairman can switch the employment check off');
  perform set_config('mohona.company_scope', '', true);
  update config.setting_value set status = 'superseded' where company_id = ca and key = 'hr.require_active_employment' and status = 'active';
  update hr.employment set status = 'active' where employee_id = e.id;
  perform svc.v1_iam_end_membership(m_ac, current_date, 'resigned');
  insert into _r values ('S10-13', (select status from hr.employment where employee_id = e.id) = 'terminated'
                                   and pg_temp.expect_fail(format($f$update hr.employment set status='active', effective_to=null where employee_id=%L$f$, e.id), 'E_IMMUTABLE'),
                                   'ended membership terminates employment; terminated is final');
  -- MFA setting drives positions
  insert into config.setting_value (company_id, key, value, version, reason) values (ca, 'iam.mfa.required_positions', '["CHAIRMAN"]', 1, 'test: MFA only for the Chairman');
  perform pg_temp.as_user(u_md, 'md', 'aal1');
  insert into _r values ('S10-14', (api.v1_iam_current_context() ->> 'position_code') = 'MD', 'MFA list is a Chairman setting (the Chairman always stays on it)');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

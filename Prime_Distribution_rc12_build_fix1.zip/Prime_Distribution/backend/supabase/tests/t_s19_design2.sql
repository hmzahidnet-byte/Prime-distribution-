-- S19 tests: layout grid rules (snap, bounds, overlap), approval controls stay on-screen, no grant fields, mandatory ad
-- slots, presets, publish / rollback of layouts and themes re-validated under today's rules, motion policy, edit rights.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.lay(p_widgets jsonb, p_cols integer default 4) returns jsonb language sql as $$
  select jsonb_build_object('breakpoints', jsonb_build_object('phone', jsonb_build_object('columns', p_cols, 'widgets', p_widgets))) $$;
create or replace function pg_temp.trv(p uuid) returns integer language sql as $$ select row_version from design.theme where id = p $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_ac uuid; p_ch uuid; p_ac uuid; j jsonb; t1 uuid;
        u_ch uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
        ok_layout jsonb := pg_temp.lay(jsonb_build_array(design.fn_w('approvals', 'approval', 0, 0, 4, 1), design.fn_w('sales', 'kpi', 0, 1, 2, 1, 'kpi.sales_today')));
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('DS2', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');

  insert into _r values ('S19-01', not exists (select 1 from design.layout_preset p where not (design.fn_layout_report(p.layout, 1, 4) ->> 'ok')::boolean)
                                   and (design.fn_layout_report(ok_layout, 0, 4) ->> 'ok')::boolean,
                                   'every preset is valid even with a mandatory ad slot');
  insert into _r values ('S19-02', not (design.fn_layout_report(pg_temp.lay(jsonb_build_array(design.fn_w('a', 'kpi', 0, 0, 2, 1, 'kpi.x_y'), design.fn_w('b', 'kpi', 1, 0, 2, 1, 'kpi.x_y'))), 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(pg_temp.lay(jsonb_build_array(design.fn_w('a', 'kpi', 3, 0, 2, 1, 'kpi.x_y'))), 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(pg_temp.lay('[{"id":"a","type":"text","x":0.5,"y":0,"w":1,"h":1}]'), 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(pg_temp.lay(jsonb_build_array(design.fn_w('a', 'kpi', 0, 0, 2, 1))), 0, 4) ->> 'ok')::boolean,
                                   'grid: no overlap, inside the columns, whole cells, data widgets need a binding');
  insert into _r values ('S19-03', not (design.fn_layout_report(pg_temp.lay(jsonb_build_array(design.fn_w('ap', 'approval', 0, 5, 4, 1))), 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(pg_temp.lay(jsonb_build_array(design.fn_w('ap', 'approval', 0, 0, 1, 1))), 0, 4) ->> 'ok')::boolean,
                                   'approval controls stay in the first rows and keep a usable width (never off-screen)');
  insert into _r values ('S19-04', not (design.fn_layout_report(ok_layout || '{"grant":"finance.read"}', 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(pg_temp.lay('[{"id":"a","type":"kpi","x":0,"y":0,"w":2,"h":1,"binding":"kpi.a_b","permission":"x"}]'), 0, 4) ->> 'ok')::boolean
                                   and not (design.fn_layout_report(pg_temp.lay('[{"id":"a","type":"text","x":0,"y":0,"w":2,"h":1,"title_bn":"<script>x</script>"}]'), 0, 4) ->> 'ok')::boolean,
                                   'layouts cannot carry grants, permissions or markup');
  insert into _r values ('S19-05', not (design.fn_layout_report(ok_layout, 1, 4) ->> 'ok')::boolean, 'ad slots are mandatory while the company runs them');
  -- ---------------------------------------------------------------- layouts: save, publish, rollback
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_design_layout_save('home', null, 'HOME_STANDARD', 'start');
  perform api.v1_design_layout_publish('home', 1, 'publish', 'go');
  perform api.v1_design_layout_save('home', ok_layout, null, 'simpler');
  perform api.v1_design_layout_publish('home', 2, 'publish', 'simplify');
  j := api.v1_design_layout_publish('home', 1, 'rollback', 'back to standard');
  insert into _r values ('S19-06', j ->> 'status' = 'published'
                                   and (select status from design.screen_layout where company_id = ca and screen_key = 'home' and version = 1) = 'published'
                                   and (select status from design.screen_layout where company_id = ca and screen_key = 'home' and version = 2) = 'superseded'
                                   and pg_temp.expect_fail($q$select api.v1_design_layout_publish('home', 1, 'rollback', 'x')$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$update design.screen_layout set layout = '{}' where company_id = %L and version = 1$f$, ca), 'E_IMMUTABLE'),
                                   'layout versions are immutable; rollback re-publishes an earlier one');
  perform api.v1_config_set_flag('design.ad_slots', null, true, 0, 'ads on');
  insert into _r values ('S19-07', pg_temp.expect_fail($q$select api.v1_design_layout_publish('home', 2, 'rollback', 'x')$q$, 'E_DESIGN_LAYOUT'),
                                   'a rollback is re-validated under today''s rules (ad slot now mandatory)');
  -- ---------------------------------------------------------------- theme rollback
  j := api.v1_design_save_theme('HOUSE', 'থিম', null, 'MOHONA_BLUE', 'v1'); t1 := (j ->> 'theme_id')::uuid;
  perform api.v1_design_publish(t1, 1, pg_temp.trv(t1), 'go');
  perform api.v1_design_save_theme('HOUSE', 'থিম', null, 'FOREST_GREEN', 'v2');
  perform api.v1_design_publish(t1, 2, pg_temp.trv(t1), 'green');
  perform api.v1_design_theme_rollback(t1, 1, pg_temp.trv(t1), 'blue again');
  perform api.v1_design_save_theme('HOUSE', 'থিম', null, 'MOHONA_ORANGE', 'v3');
  insert into _r values ('S19-08', (select active_version from design.theme where id = t1) = 1
                                   and (select status from design.theme_version where theme_id = t1 and version = 2) = 'superseded'
                                   and pg_temp.expect_fail(format($f$select api.v1_design_theme_rollback(%L, 3, %s, 'x')$f$, t1, pg_temp.trv(t1)), 'E_INVALID_ACTION'),
                                   'theme rollback re-activates an earlier published version only');
  -- ---------------------------------------------------------------- motion + member view + rights
  insert into _r values ('S19-09', pg_temp.expect_fail($q$select api.v1_config_set('design.motion.reduced', '"ignore"', 0, 'x')$q$, 'E_SETTING_INVALID'),
                                   'the phone''s reduce-motion setting can never be overridden');
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  j := api.v1_design_active();
  insert into _r values ('S19-10', (j -> 'layouts' -> 'home' ->> 'version')::integer = 1 and j -> 'motion' ->> 'reduced' = 'respect_system'
                                   and (j ->> 'ads')::boolean and j -> 'theme' ->> 'code' = 'HOUSE'
                                   and pg_temp.expect_fail($q$select api.v1_design_layout_save('home', null, 'HOME_COMPACT', 'x')$q$, 'E_FORBIDDEN'),
                                   'members receive layouts and motion policy; only the studio edits');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S17 tests: UI bootstrap for the current position (tabs, modules, flags), tab keys restricted, no context = no config.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_ac uuid; p_ch uuid; p_ac uuid; j jsonb; j1 jsonb;
        u_ch uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('UIS', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');

  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S17-01', pg_temp.expect_fail('select api.v1_ui_config()', 'E_NO_ACTIVE_POSITION'), 'no selected position, no app configuration');
  perform api.v1_iam_select_position(a_ac);
  j := api.v1_ui_config();
  insert into _r values ('S17-02', j -> 'tabs' = '["home","tasks","reports","more"]'::jsonb and j ->> 'position_code' = 'ACCOUNTANT'
                                   and (j -> 'modules') ? 'forms' and (j -> 'flags' ->> 'forms.offline_drafts')::boolean
                                   and j -> 'mfa_positions' @> '["CHAIRMAN"]'::jsonb and (j -> 'offline' ->> 'max_drafts')::integer = 50,
                                   'any member with a position reads the shell configuration');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  insert into _r values ('S17-03', pg_temp.expect_fail($q$select api.v1_config_set('ui.nav.bottom_tabs', '["home","admin"]', 0, 'x')$q$, 'E_SETTING_INVALID'),
                                   'only known tab keys can be configured');
  perform api.v1_config_set('ui.nav.bottom_tabs', '["home","forms","tasks","more"]', 0, 'forms first');
  perform pg_temp.as_user(u_ac, 'ac');
  j1 := api.v1_ui_config();
  insert into _r values ('S17-04', j1 -> 'tabs' = '["home","forms","tasks","more"]'::jsonb, 'the Chairman''s tab choice reaches every member');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

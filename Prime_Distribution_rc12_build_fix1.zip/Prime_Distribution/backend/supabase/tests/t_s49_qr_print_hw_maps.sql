-- S49–S51 tests: device registry + policy + revocation, authorised / watermarked / logged printing, document QR with
-- revocation, employee / retailer / dealer labels through one resolver, consent-bound location pings, live markers in scope,
-- stale labelling, dealer pins, navigation link, snapshot without personal coordinates, retention purge.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
do $$
declare n integer; boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_f1 uuid; a_f2 uuid; a_md uuid; a_ch2 uuid; p_ch uuid; p_sm uuid; p_f1 uuid; p_f2 uuid; p_md uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_f1 uuid := gen_random_uuid(); u_f2 uuid := gen_random_uuid(); u_md uuid := gen_random_uuid();
        u_ch2 uuid := gen_random_uuid();
        bt uuid; n1 bigint; t1 uuid; d1 uuid; r1 uuid; route uuid; plan uuid; doc jsonb; j jsonb; j1 jsonb; qr text; emp uuid; dq text;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('QRP', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_f1 := svc.v1_iam_provision_person('মাঠ ১', null, null, u_f1, 't'); a_f1 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_f1, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_f2 := svc.v1_iam_provision_person('মাঠ ২', null, null, u_f2, 't'); a_f2 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_f2, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('QRX', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;
  emp := (select id from hr.employee where person_id = p_f1 and company_id = ca);

  -- ---------------------------------------------------------------- hardware + printing (F221–F230, F241–F250)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  bt := (api.v1_device_register('POS-1', 'bt_printer', repeat('a1', 32), '00:11:22:33:44:55', false, 'counter printer') ->> 'device_id')::uuid;
  insert into _r values ('S49-01', pg_temp.expect_fail($q$select api.v1_device_register('POS-2', 'bt_printer', repeat('a1', 32), null, false, 'x')$q$)
                                   and pg_temp.expect_fail($q$select api.v1_device_register('NET-1', 'network_printer', repeat('b2', 32), 'printer.local', true, 'x')$q$),
                                   'one fingerprint = one device; a network printer needs a registered IP:port');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  j := api.v1_print_authorize('inventory.stock', '', 'pdf', null);
  n1 := (select count(*) from core.print_log where company_id = ca and person_id = p_md);
  insert into _r values ('S49-02', j ->> 'watermark' like 'এমডি%' and n1 = 1
                                   and pg_temp.expect_fail($q$select api.v1_print_authorize('inventory.stock', '', 'pos_bt', gen_random_uuid())$q$, 'E_PRINTER_NOT_REGISTERED')
                                   and (api.v1_print_authorize('inventory.stock', '', 'pos_bt', bt) ->> 'doc_type') = 'inventory.stock'
                                   and pg_temp.expect_fail($q$select api.v1_print_authorize('secret.table', 'x', 'pdf', null)$q$, 'E_INVALID_ACTION'),
                                   'every print is authorised, watermarked with who/when and logged; only registered printers');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_device_policy_set('MD', 'bt_printer', false, 'MD prints through the office');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S49-03', pg_temp.expect_fail(format($f$select api.v1_print_authorize('inventory.stock', '', 'pos_bt', %L)$f$, bt), 'E_PRINTER_NOT_REGISTERED'),
                                   'a device policy can deny a device kind to a position');
  -- ---------------------------------------------------------------- documents + universal resolver (F181–F190)
  doc := api.v1_document_issue('hr.appointment_letter', 'AL-2026-001', repeat('c3', 32));
  j := api.v1_qr_resolve(doc ->> 'qr');
  perform api.v1_document_revoke((doc ->> 'document_id')::uuid, 'superseded');
  insert into _r values ('S49-04', j ->> 'type' = 'document' and j ->> 'sha256' = repeat('c3', 32)
                                   and pg_temp.expect_fail(format($f$select api.v1_qr_resolve(%L)$f$, doc ->> 'qr'), 'E_QR_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_qr_resolve(%L)$f$, 'MOS1|X|QRP|' || (doc ->> 'document_id') || '|0000000000000000'), 'E_QR_INVALID'),
                                   'document QR proves the registered version; revoked or forged labels are refused');
  qr := api.v1_qr_label('employee', emp) ->> 'qr';
  j := api.v1_qr_resolve(qr);
  insert into _r values ('S49-05', j ->> 'type' = 'employee' and (j ->> 'active')::boolean and j ->> 'position' = 'FIELD_SALES'
                                   and not exists (select 1 from jsonb_object_keys(j) k where k not in ('type','name_bn','active','position')) and qr !~* 'pin|password|token',
                                   'employee QR carries identity and status only — no credentials');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  t1 := (api.v1_territory_save(null, 'T1', 'এক', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  j := api.v1_dealer_save(null, 'D1', 'ডিলার ১', null, null, 'বাজার রোড', null, t1, p_f1, 0, 0, null, 'x'); d1 := (j ->> 'dealer_id')::uuid; dq := j ->> 'qr';
  r1 := (api.v1_retailer_save(null, 'R1', 'দোকান', null, d1, null, 22.845, 89.540, null, null, 'x') ->> 'retailer_id')::uuid;
  qr := api.v1_qr_label('retailer', r1) ->> 'qr';
  j := api.v1_qr_resolve(qr);
  perform pg_temp.as_user(u_f2, 'f2'); perform api.v1_iam_select_position(a_f2);
  j1 := api.v1_qr_resolve(qr);
  insert into _r values ('S49-06', j ->> 'dealer' = 'ডিলার ১' and j1 ->> 'type' = 'retailer' and j1 -> 'dealer' = 'null'::jsonb
                                   and (api.v1_qr_resolve(dq) ->> 'type') = 'dealer' and api.v1_qr_resolve(dq) -> 'result' -> 'balance' = 'null'::jsonb,
                                   'one resolver for every label; dealer details only for permitted readers');
  -- ---------------------------------------------------------------- location (F231–F240)
  perform pg_temp.as_user(u_f1, 'f1'); perform api.v1_iam_select_position(a_f1);
  insert into _r values ('S49-07', pg_temp.expect_fail($q$select api.v1_location_ping(22.84, 89.54, 12, clock_timestamp(), false)$q$, 'E_CONSENT_REQUIRED'), 'no location without consent');
  perform api.v1_location_consent(true, 'ok');
  perform api.v1_location_ping(22.84, 89.54, 12, clock_timestamp() - interval '2 hours', false);
  perform api.v1_location_ping(22.85, 89.55, 8, clock_timestamp(), false);
  insert into _r values ('S49-08', pg_temp.expect_fail($q$select api.v1_location_ping(22.84, 89.54, 12, clock_timestamp(), true)$q$, 'E_CONSENT_REQUIRED'),
                                   'background location stays off unless the Chairman allows it');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_live_markers();
  perform pg_temp.as_user(u_f2, 'f2');
  j1 := api.v1_live_markers();
  insert into _r values ('S49-09', jsonb_array_length(j) = 1 and (j -> 0 ->> 'lat')::numeric = 22.85 and not (j -> 0 ->> 'stale')::boolean and (j -> 0 ->> 'accuracy_m')::numeric = 8
                                   and jsonb_array_length(j1) = 0 and jsonb_array_length(api.v1_dealer_pins()) = 0,
                                   'the latest consented position with age and accuracy, only for viewers in scope');
  perform pg_temp.as_user(u_f1, 'f1');
  perform api.v1_location_consent(false, 'stop');
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S49-10', jsonb_array_length(api.v1_live_markers()) = 0 and jsonb_array_length(api.v1_dealer_pins()) = 1
                                   and (api.v1_dealer_pins() -> 0 ->> 'address_bn') = 'বাজার রোড',
                                   'revoking consent hides the marker at once; dealer pins for permitted viewers');
  route := (api.v1_route_save(null, 'R-1', 'রুট', t1, jsonb_build_array(jsonb_build_object('retailer_id', r1)), null, null, 'x') ->> 'route_id')::uuid;
  plan := (api.v1_route_plan(route, p_f1, null, current_date, true) ->> 'route_plan_id')::uuid;
  j := api.v1_route_navigation(plan);
  j1 := api.v1_route_snapshot(plan);
  insert into _r values ('S49-11', j ->> 'url' like 'https://www.google.com/maps/dir/?api=1&destination=22.845000,89.540000%' and not (j ? 'duration')
                                   and not exists (select 1 from jsonb_array_elements(j1 -> 'stops') x where x ? 'check_in')
                                   and (select count(*) from location.export_log where company_id = ca) = 1,
                                   'navigation is a directions link (no invented times); snapshots carry no personal coordinates and are logged');
  update location.position_ping set received_at = clock_timestamp() - interval '40 days' where company_id = ca;
  n := svc.v1_location_purge();                                   -- separate statement: the check below must see the delete
  insert into _r values ('S49-12', n = 2 and not exists (select 1 from location.position_ping where company_id = ca), 'pings older than the retention setting are removed');
  -- ---------------------------------------------------------------- device health, revocation, audit trail, isolation
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_device_health(bt, 80, true, 2048);
  perform api.v1_device_revoke(bt, 'lost');
  insert into _r values ('S49-13', pg_temp.expect_fail(format($f$select api.v1_device_health(%L, 50, true, 1)$f$, bt), 'E_GATE_DEVICE_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_print_authorize('inventory.stock', '', 'pos_bt', %L)$f$, bt), 'E_PRINTER_NOT_REGISTERED')
                                   and (select count(*) from hardware.device_event where device_id = bt) = 2
                                   and pg_temp.expect_fail(format($f$update hardware.device_event set action = 'paired' where device_id = %L$f$, bt)),
                                   'a revoked device stops at once; the device trail is append-only');
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S49-14', pg_temp.expect_fail(format($f$select api.v1_qr_resolve(%L)$f$, dq), 'E_QR_INVALID') and jsonb_array_length(api.v1_live_markers()) = 0,
                                   'labels and positions of one company mean nothing in another');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

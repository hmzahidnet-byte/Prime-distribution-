-- S65 tests (ধাপ ৩: v1–v180 version folders, docs/V180_VERSION_AUDIT_BN.md): approval ceiling, time-window permission, screenshot policy,
-- org chart on a past date, product declaration, final settlement preview, return authorisation, alert board. Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        tw uuid; rma jsonb; emp uuid; v_dow integer; v_dim integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- ---------------------------------------------------------------- F154-037 approval ceiling
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_approval_ceiling_set('MD', 'sales.order', 5000, 'MD approves small orders only');
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 200)), null);
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S65-01', pg_temp.expect_fail(format($f$select pg_temp.approve_pending(%L)$f$, o1 ->> 'order_id'), 'E_APPROVAL_CEILING')
                                   and (select status from sales.sales_order where id = (o1 ->> 'order_id')::uuid) = 'pending_approval',
                                   'a position cannot approve above its ceiling');
  perform pg_temp.as_user(u_ch, 'ch');
  perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid);
  insert into _r values ('S65-02', (select status from sales.sales_order where id = (o1 ->> 'order_id')::uuid) = 'allocated'
                                   and pg_temp.expect_fail($q$select api.v1_approval_ceiling_set('CHAIRMAN', null, 1, 'x')$q$, 'E_NOT_FOUND'),
                                   'the Chairman is never limited and cannot be given a ceiling');

  -- ---------------------------------------------------------------- F154-035 time window
  v_dow := (extract(dow from (now() at time zone 'Asia/Dhaka'))::integer + 1) % 7;
  tw := (api.v1_time_window_set('FIELD_SALES', null, array[v_dow], '09:00', '17:00', 'field work only on that day') ->> 'time_window_id')::uuid;
  perform pg_temp.as_user(u_fs, 'fs');
  insert into _r values ('S65-03', pg_temp.expect_fail(format($f$select api.v1_order_create(%L, %L, %L, '[{"product_id":"%s","qty":1}]', null)$f$, dl, fgw, pl, noodle), 'E_TIME_WINDOW'),
                                   'outside the position''s window the server refuses, even with a valid login');
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S65-04', pg_temp.expect_fail($q$select api.v1_time_window_set('CHAIRMAN', null, array[1], '09:00', '10:00', 'x')$q$, 'E_PROTECTED_POSITION')
                                   and pg_temp.expect_fail($q$select api.v1_time_window_set('FIELD_SALES', null, array[9], '09:00', '10:00', 'x')$q$, 'E_INVALID_ACTION'),
                                   'the Chairman seat has no window; weekdays are 0–6');
  perform api.v1_time_window_revoke(tw, 'back to normal');
  perform pg_temp.as_user(u_fs, 'fs');
  j := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 1)), null);
  insert into _r values ('S65-05', j ->> 'order_id' is not null, 'after revoking the window the work goes through');

  -- ---------------------------------------------------------------- F154-034 screenshot policy
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('security.screenshot.block_positions', '["FIELD_SALES"]'::jsonb, 0, 'customer data on field phones');
  perform pg_temp.as_user(u_fs, 'fs');
  j := api.v1_screen_policy();
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S65-06', (j ->> 'block_screenshots')::boolean and not (api.v1_screen_policy() ->> 'block_screenshots')::boolean,
                                   'screenshots are blocked only for the positions the Chairman chose');

  -- ---------------------------------------------------------------- F154-030 org chart on a date
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S65-07', jsonb_array_length(api.v1_org_chart_as_of(current_date) -> 'positions') = 7
                                   and jsonb_array_length(api.v1_org_chart_as_of(current_date - 1) -> 'positions') = 0,
                                   'the chart shows who held which position on the chosen date');

  -- ---------------------------------------------------------------- F154-045 product declaration
  perform api.v1_product_declaration_set(noodle, 'ময়দা, লবণ, মসলা', array['গম'], null);
  perform api.v1_product_declaration_set(noodle, 'ময়দা, লবণ, মসলা, পাম তেল', array['গম'], 'recipe change');
  insert into _r values ('S65-08', (api.v1_product_declaration(noodle) ->> 'version')::int = 2
                                   and pg_temp.expect_fail(format($f$update inventory.product_declaration set ingredients = 'x' where product_id = %L$f$, noodle))
                                   and pg_temp.expect_fail(format($f$select api.v1_product_declaration_set(%L, ' ', null, null)$f$, noodle), 'E_INVALID_ACTION'),
                                   'ingredient / allergen declarations are versioned and never edited');

  -- ---------------------------------------------------------------- F154-140 final settlement preview
  emp := (select e.id from hr.employee e where e.person_id = p_sk and e.company_id = ca);
  perform api.v1_salary_set(emp, date_trunc('month', current_date)::date, 'G3', 30000, '[{"code":"HOUSE","name_bn":"বাড়িভাড়া","amount":3000}]', '[]', 'joining');
  j := api.v1_final_settlement_preview(emp, current_date);
  v_dim := extract(day from (date_trunc('month', current_date) + interval '1 month' - interval '1 day'))::integer;
  insert into _r values ('S65-09', (j ->> 'monthly_net_structure')::numeric = 33000
                                   and (j ->> 'prorata_this_month')::numeric = round(33000.0 * extract(day from current_date)::integer / v_dim, 2)
                                   and pg_temp.expect_fail(format($f$select api.v1_final_settlement_preview(%L, current_date)$f$, gen_random_uuid()), 'E_NOT_FOUND'),
                                   'final settlement = pro-rata pay of the last month + unpaid net; advances shown apart');

  -- ---------------------------------------------------------------- F154-147 return authorisation
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 4);
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, null, null);
  perform pg_temp.as_user(u_ac, 'ac');
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('sales.return.requires_authorization', 'true'::jsonb, 0, 'returns need approval first');
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S65-10', pg_temp.expect_fail(format($f$select api.v1_sales_return(%L, %L, '[{"product_id":"%s","lot_id":"%s","qty":10}]', 'damaged')$f$, inv ->> 'invoice_id', qw, noodle, lot), 'E_RMA_REQUIRED'),
                                   'with the setting on, no sales return without an approved authorisation');
  rma := api.v1_return_authorization_request((inv ->> 'invoice_id')::uuid, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 10)), 'damaged in market');
  insert into _r values ('S65-11', pg_temp.expect_fail(format($f$select api.v1_return_authorization_decide(%L, true, 'ok')$f$, rma ->> 'rma_id'), 'E_SELF_APPROVAL'),
                                   'the requester does not approve the own authorisation');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_return_authorization_decide((rma ->> 'rma_id')::uuid, true, 'ok');
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S65-12', pg_temp.expect_fail(format($f$select api.v1_sales_return(%L, %L, '[{"product_id":"%s","lot_id":"%s","qty":20}]', 'damaged')$f$, inv ->> 'invoice_id', qw, noodle, lot), 'E_RMA_REQUIRED'),
                                   'never more than authorised');
  perform api.v1_sales_return((inv ->> 'invoice_id')::uuid, qw, jsonb_build_array(jsonb_build_object('product_id', noodle, 'lot_id', lot, 'qty', 10)), 'damaged');
  insert into _r values ('S65-13', (select status from sales.return_authorization where id = (rma ->> 'rma_id')::uuid) = 'used'
                                   and pg_temp.expect_fail(format($f$select api.v1_sales_return(%L, %L, '[{"product_id":"%s","lot_id":"%s","qty":5}]', 'again')$f$, inv ->> 'invoice_id', qw, noodle, lot), 'E_RMA_REQUIRED'),
                                   'an authorisation is used once');

  -- ---------------------------------------------------------------- alert board + trail
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_alerts_board();
  insert into _r values ('S65-14', j ? 'low_stock' and j ? 'payment_mismatch' and j ? 'route_exceptions'
                                   and jsonb_array_length(api.v1_location_trail(p_fs, current_date) -> 'points') = 0,
                                   'the alert board is a deterministic list; the trail shows only consented points');
  perform pg_temp.as_user(u_fs, 'fs');
  insert into _r values ('S65-15', pg_temp.expect_fail(format($f$select api.v1_location_trail(%L, current_date)$f$, p_sk), 'E_FORBIDDEN')
                                   and jsonb_typeof(api.v1_alerts_board() -> 'payment_mismatch') = 'null',
                                   'nobody sees another person''s trail without the right; alert parts follow the reader''s rights');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

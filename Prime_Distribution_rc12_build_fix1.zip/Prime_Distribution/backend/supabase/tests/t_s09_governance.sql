-- S09 tests: bootstrap, Chairman-managed members/assignments (rank, scope, self rules), delegation (live, bounded, no chains),
-- session revocation, termination cascade, Chairman transfer and platform appointment.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text) returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', 'aal2')::text, true); end $$;
create or replace function pg_temp.why(p_perm text, r iam.resource) returns text language plpgsql as $$
declare v text; begin select reason into v from iam.fn_authorize(p_perm, r, false); return v; end $$;
do $$
declare boot jsonb; ca uuid; w1 uuid; w2 uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_wh uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid();
        p_ch uuid; p_md uuid; p_ac uuid; p_wh uuid; p_fs uuid; m_md uuid; m_ac uuid; m_wh uuid; m_fs uuid;
        a_ch uuid; a_md uuid; a_ac uuid; a_wh uuid; a_fs uuid; dl uuid; tr uuid; rid uuid; j jsonb; n integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', '+8801700000001', null, u_ch, 'founder');
  boot := svc.v1_gov_bootstrap_company('GOV', 'মোহনা', p_ch, 'company founded');
  ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  insert into _r values ('S09-01', (select status from core.company where id = ca) = 'active'
                                   and (select count(*) from iam.position_catalog where company_id = ca) = 19
                                   and (select count(*) from iam.position_assignment where company_id = ca and position_code = 'CHAIRMAN' and status = 'active') = 1,
                                   'bootstrap: active company, catalog, one Chairman');
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W2', 'দুই') returning id into w2;
  p_md := svc.v1_iam_provision_person('এমডি', '+8801700000002', null, u_md, 'existing person');

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_iam_add_member('এমডি (নাম ভিন্ন)', '+8801700000002', null, 'E-2', 'hire MD');
  m_md := (j ->> 'membership_id')::uuid;
  insert into _r values ('S09-02', (j ->> 'person_id')::uuid = p_md
                                   and pg_temp.expect_fail($q$select api.v1_iam_add_member('x', '+8801700000002', null, null, 'again')$q$, 'E_DUPLICATE')
                                   and pg_temp.expect_fail($q$select api.v1_iam_add_member('x', null, null, null, 'no contact')$q$, 'E_CONTACT_REQUIRED'),
                                   'one human = one person (reused by phone); duplicates and contact-less members rejected');
  a_md := api.v1_iam_assign_position(m_md, 'MD', null, null, null, null, null, null, 'appoint MD');
  insert into _r values ('S09-03', (select position_code from iam.position_assignment where id = a_md) = 'MD', 'Chairman appoints the MD');
  insert into _r values ('S09-05', pg_temp.expect_fail(format($f$select api.v1_iam_assign_position(%L,'CHAIRMAN',null,null,null,null,null,null,'x')$f$, m_md), 'E_CHAIRMAN_SEAT'),
                                   'nobody assigns the Chairman seat directly (transfer/platform only)');
  j := api.v1_iam_add_member('হিসাবরক্ষক', '+8801700000003', null, 'E-3', 'hire'); m_ac := (j ->> 'membership_id')::uuid; p_ac := (j ->> 'person_id')::uuid;
  j := api.v1_iam_add_member('উইং-প্রধান', '+8801700000004', null, 'E-4', 'hire'); m_wh := (j ->> 'membership_id')::uuid; p_wh := (j ->> 'person_id')::uuid;
  j := api.v1_iam_add_member('মাঠকর্মী', '+8801700000005', null, 'E-5', 'hire'); m_fs := (j ->> 'membership_id')::uuid; p_fs := (j ->> 'person_id')::uuid;
  perform svc.v1_iam_relink_login(p_ac, u_ac, 'sign-up'); perform svc.v1_iam_relink_login(p_wh, u_wh, 'sign-up'); perform svc.v1_iam_relink_login(p_fs, u_fs, 'sign-up');
  a_wh := api.v1_iam_assign_position(m_wh, 'WING_HEAD', null, null, null, w1, null, null, 'wing 1 head');
  perform api.v1_iam_set_position_rule('MD', 'iam.assignment.manage', 'allow', 'COMPANY', null, 'MD runs staffing');
  perform api.v1_iam_set_position_rule('MD', 'iam.membership.manage', 'allow', 'COMPANY', null, 'MD runs staffing');
  perform api.v1_iam_set_position_rule('MD', 'iam.session.revoke', 'allow', 'COMPANY', null, 'MD security');
  perform api.v1_iam_set_position_rule('WING_HEAD', 'iam.assignment.manage', 'allow', 'WING', null, 'own wing only');

  -- MD (rank 900): below-me rule
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S09-04', pg_temp.expect_fail(format($f$select api.v1_iam_assign_position(%L,'EMERGENCY_ADMIN',null,null,null,null,null,null,'x')$f$, m_ac), 'E_RANK_TOO_HIGH')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_assign_position(%L,'CHAIRMAN',null,null,null,null,null,null,'x')$f$, m_ac), 'E_CHAIRMAN_SEAT'),
                                   'MD cannot appoint equal/higher rank or the Chairman');
  a_ac := api.v1_iam_assign_position(m_ac, 'ACCOUNTANT', null, null, null, null, null, null, 'accountant');
  insert into _r values ('S09-06', a_ac is not null, 'MD appoints below own rank');
  insert into _r values ('S09-07', pg_temp.expect_fail(format($f$select api.v1_iam_assign_position(%L,'AUDITOR',null,null,null,null,null,null,'self')$f$, m_md), 'E_SELF_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_change_assignment(%L,'end','x')$f$, a_md), 'E_SELF_ACTION'), 'no self-appointment or self-removal');
  insert into _r values ('S09-09', pg_temp.expect_fail(format($f$select api.v1_iam_change_assignment(%L,'end','x')$f$, a_ch), 'E_CHAIRMAN_SEAT')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_end_member(m.id,'x') from iam.company_membership m where m.person_id=%L and m.company_id=%L$f$, p_ch, ca), 'E_CHAIRMAN_SEAT'),
                                   'the Chairman cannot be removed by anyone in the company');
  perform api.v1_iam_change_assignment(a_ac, 'suspend', 'investigation');
  perform api.v1_iam_change_assignment(a_ac, 'reactivate', 'cleared');
  insert into _r values ('S09-29', (select status from iam.position_assignment where id = a_ac) = 'active'
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_change_assignment(%L,'reactivate','x')$f$, a_ac), 'E_INVALID_ACTION'), 'suspend/reactivate with state checks');

  -- Wing head: only inside own wing
  perform pg_temp.as_user(u_wh, 'wh'); perform api.v1_iam_select_position(a_wh);
  a_fs := api.v1_iam_assign_position(m_fs, 'FIELD_SALES', null, null, null, w1, null, null, 'field sales wing 1');
  insert into _r values ('S09-08', a_fs is not null
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_assign_position(%L,'STOREKEEPER',null,null,null,%L,null,null,'x')$f$, m_fs, w2), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_assign_position(%L,'STOREKEEPER',null,null,null,null,null,null,'x')$f$, m_fs), 'E_FORBIDDEN'),
                                   'WING-scoped manager appoints only into own wing');

  -- Delegation by MD
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S09-12', pg_temp.expect_fail(format($f$select api.v1_iam_delegate(%L, array['audit.read'], 'COMPANY', null, null, clock_timestamp() + interval '7 days', 'x')$f$, a_ac), 'E_NOT_DELEGABLE')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_delegate(%L, array['iam.position.read'], 'COMPANY', null, null, clock_timestamp() + interval '120 days', 'x')$f$, a_ac), 'E_DELEGATION_TOO_LONG')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_delegate(%L, array['iam.position.read'], 'WING', null, null, clock_timestamp() + interval '7 days', 'x')$f$, a_ac), 'E_DELEGATION_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_delegate(%L, array['iam.position.read'], 'COMPANY', null, null, null, 'x')$f$, a_ac), 'E_DELEGATION_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_delegate(%L, array['technical.diagnostics.read'], 'COMPANY', null, null, clock_timestamp() + interval '7 days', 'x')$f$, a_ac))
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_delegate(%L, array['iam.position.read'], 'COMPANY', null, null, clock_timestamp() + interval '7 days', 'x')$f$, a_md), 'E_SELF_ACTION'),
                                   'delegation: delegable only, bounded, explicit scope, end time, only what I hold, not to myself');
  dl := api.v1_iam_delegate(a_ac, array['iam.position.read', 'iam.permission.read'], 'COMPANY', null, null, clock_timestamp() + interval '7 days', 'holiday cover');
  j := api.v1_iam_my_delegations();
  insert into _r values ('S09-28', jsonb_array_length(j) = 1 and j -> 0 ->> 'direction' = 'given', 'my_delegations shows what I gave');
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  insert into _r values ('S09-11', pg_temp.why('iam.position.read', iam.fn_resource(ca)) = 'delegated'
                                   and pg_temp.why('iam.permission.manage', iam.fn_resource(ca)) = 'no_grant', 'delegate gains exactly the delegated rights');
  insert into _r values ('S09-27', pg_temp.expect_fail(format($f$update iam.delegation set valid_until = valid_until + interval '30 days' where id=%L$f$, dl), 'E_IMMUTABLE'), 'delegations are never edited');

  -- delegator loses the power -> delegated right dies at once
  perform pg_temp.as_user(u_ch, 'ch');
  select id into rid from iam.position_permission_rule where company_id = ca and position_code = 'MD' and permission_code = 'iam.position.read' and status = 'active';
  perform api.v1_iam_revoke_position_rule(rid, 'tighten');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S09-13', pg_temp.why('iam.position.read', iam.fn_resource(ca)) = 'no_grant'
                                   and pg_temp.why('iam.permission.read', iam.fn_resource(ca)) = 'delegated', 'delegated right follows the delegator''s own live right (no stale power)');
  insert into _r values ('S09-26', pg_temp.expect_fail('select api.v1_iam_company_people()', 'E_FORBIDDEN'), 'people list needs iam.position.read');

  -- delegate can return a delegation; delegator assignment end revokes everything
  perform api.v1_iam_revoke_delegation(dl, 'back from holiday');
  insert into _r values ('S09-15', (select status from iam.delegation where id = dl) = 'revoked'
                                   and not exists (select 1 from iam.assignment_permission_rule where delegation_id = dl and status = 'active'), 'delegate can hand a delegation back; its rules die with it');
  perform pg_temp.as_user(u_md, 'md');
  dl := api.v1_iam_delegate(a_ac, array['iam.permission.read'], 'COMPANY', null, null, clock_timestamp() + interval '7 days', 'cover 2');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_iam_change_assignment(a_md, 'suspend', 'review');
  insert into _r values ('S09-14', (select status from iam.delegation where id = dl) = 'revoked'
                                   and not exists (select 1 from iam.assignment_permission_rule where delegation_id = dl and status = 'active'), 'delegator''s assignment stops -> delegation revoked');
  perform api.v1_iam_change_assignment(a_md, 'reactivate', 'review done');

  -- session revocation
  perform api.v1_iam_revoke_sessions(p_ac, 'lost phone');
  j := api.v1_iam_company_people();
  insert into _r values ('S09-25', jsonb_array_length(j) = 5, 'people list shows all current members with positions');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S09-16', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_SESSION_REVOKED')
                                   and (api.v1_iam_select_position(a_ac) ->> 'position_code') = 'ACCOUNTANT', 'revoked sessions must re-select; a fresh selection works');
  perform pg_temp.as_user(u_md, 'md2'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S09-17', pg_temp.expect_fail(format($f$select api.v1_iam_revoke_sessions(%L,'x')$f$, p_ch), 'E_RANK_TOO_HIGH'), 'cannot revoke sessions of a higher rank');
  -- termination cascade
  dl := api.v1_iam_delegate(a_ac, array['iam.permission.read'], 'COMPANY', null, null, clock_timestamp() + interval '7 days', 'cover 3');
  perform api.v1_iam_end_member(m_ac, 'resigned');
  insert into _r values ('S09-18', (select status from iam.company_membership where id = m_ac) = 'ended'
                                   and (select status from iam.position_assignment where id = a_ac) = 'ended'
                                   and (select status from iam.delegation where id = dl) = 'revoked'
                                   and exists (select 1 from iam.session_revocation where person_id = p_ac and company_id = ca and reason = 'membership ended'),
                                   'termination: membership -> assignments -> delegations -> sessions');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S09-19', pg_temp.expect_fail('select api.v1_iam_current_context()'), 'terminated person is locked out on the next request');

  -- Chairman transfer
  perform pg_temp.as_user(u_md, 'md2');
  insert into _r values ('S09-20', pg_temp.expect_fail(format($f$select api.v1_gov_propose_chairman_transfer(%L,'x')$f$, m_md), 'E_FORBIDDEN'), 'only the Chairman proposes a successor');
  perform pg_temp.as_user(u_ch, 'ch');
  tr := api.v1_gov_propose_chairman_transfer(m_md, 'retirement');
  insert into _r values ('S09-21', pg_temp.expect_fail(format($f$select api.v1_gov_propose_chairman_transfer(%L,'again')$f$, m_wh), 'E_TRANSFER_PENDING')
                                   and pg_temp.expect_fail(format($f$select api.v1_gov_propose_chairman_transfer(m.id,'self') from iam.company_membership m where m.person_id=%L and m.company_id=%L$f$, p_ch, ca), 'E_TRANSFER_INVALID'),
                                   'one pending transfer; not to oneself');
  perform pg_temp.as_user(u_wh, 'wh');
  insert into _r values ('S09-22', pg_temp.expect_fail(format('select api.v1_gov_accept_chairman_transfer(%L)', tr), 'E_FORBIDDEN'), 'only the named successor accepts');
  perform pg_temp.as_user(u_md, 'md2');
  insert into _r values ('S09-30', jsonb_array_length(api.v1_gov_my_pending_transfers()) = 1, 'successor sees the pending transfer');
  perform api.v1_gov_accept_chairman_transfer(tr);
  perform set_config('mohona.company_scope', '', true);
  select count(*) into n from iam.position_assignment where company_id = ca and position_code = 'CHAIRMAN' and status = 'active';
  insert into _r values ('S09-23', n = 1
                                   and exists (select 1 from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                                                where a.company_id = ca and a.position_code = 'CHAIRMAN' and a.status = 'active' and m.person_id = p_md)
                                   and (select status from iam.position_assignment where id = a_ch) = 'ended'
                                   and (select status from iam.chairman_transfer where id = tr) = 'accepted', 'transfer accepted: exactly one new Chairman, old seat ended');
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S09-24', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_NO_ACTIVE_POSITION'), 'former Chairman''s session loses the seat immediately');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
  perform svc.v1_gov_appoint_chairman(m_wh, 'platform emergency test');
  insert into _r values ('S09-31', (select count(*) from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                                     where a.company_id = ca and a.position_code = 'CHAIRMAN' and a.status = 'active' and m.person_id = p_wh) = 1
                                   and (select count(*) from iam.position_assignment where company_id = ca and position_code = 'CHAIRMAN' and status = 'active') = 1,
                                   'platform appointment replaces the Chairman atomically');
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

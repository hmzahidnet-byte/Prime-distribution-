-- S68 tests (owner decision on money + Chairman customisation, docs/V180_AZ_STATUS_BN.md): taka/paisa format and Bengali words,
-- invoice print payload (company, line names, paid/open, words, QR), 50 distinct named invoice designs, live KPIs from real data,
-- series / split for graphs, factory P&L stays restricted, theme templates and role presets are valid. Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.kv(p jsonb, p_code text) returns jsonb language sql as $$
  select x from jsonb_array_elements(p) x where x ->> 'code' = p_code limit 1 $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- ---------------------------------------------------------------- money words (owner example) and format
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  insert into _r values ('S68-01', core.fn_taka_words_bn(112950.66) = 'এক লক্ষ বারো হাজার নয় শত পঞ্চাশ টাকা ছেষট্টি পয়সা মাত্র'
                                   and core.fn_taka_bn(112950.66) = '৳ ১,১২,৯৫০.৬৬'
                                   and core.fn_taka_words_bn(0) = 'শূন্য টাকা মাত্র'
                                   and core.fn_taka_words_bn(10000001) = 'এক কোটি এক টাকা মাত্র'
                                   and core.fn_taka_words_bn(1500000000) = 'এক শত পঞ্চাশ কোটি টাকা মাত্র'
                                   and core.fn_taka_words_bn(99999.995) = 'এক লক্ষ টাকা মাত্র'
                                   and core.fn_taka_words_bn(-5) = 'ঋণাত্মক পাঁচ টাকা মাত্র'
                                   and core.fn_taka_bn(-1000) = '-৳ ১,০০০.০০' and core.fn_taka_bn(0.049) = '৳ ০.০৫',
                                   'taka and paisa in Bengali digits and words (owner decision 14 Nov 2026)');
  insert into _r values ('S68-02', (select bool_and(core.fn_bn_words_0_99(i) is not null and length(core.fn_bn_words_0_99(i)) > 1) from generate_series(0, 99) i)
                                   and (select count(distinct core.fn_bn_words_0_99(i)) from generate_series(0, 99) i) = 100
                                   and pg_temp.expect_fail($q$select api.v1_config_set('finance.money.scale', '4', 0, 'x')$q$, 'E_SETTING_INVALID'),
                                   'one distinct word for 0..99; money scale is fixed at two decimals');

  -- ---------------------------------------------------------------- order -> invoice (as in S56), then print payload
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 50)), null);
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  if (select status from sales.sales_order where id = (o1 ->> 'order_id')::uuid) = 'pending_approval' then perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid); end if;
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 1);
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, null, null);
  perform api.v1_delivery_confirm((ds ->> 'dispatch_id')::uuid, 'রহমান', repeat('ab', 32));         -- control passes: COGS (S63)
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('company.print.address_bn', '"খুলনা শিল্প এলাকা"', 0, 'invoice header');
  j := api.v1_print_authorize('sales.invoice', inv ->> 'number', 'pdf', null) -> 'data';
  insert into _r values ('S68-03', j -> 'company' ->> 'address_bn' = 'খুলনা শিল্প এলাকা' and j -> 'lines' -> 0 ->> 'name_bn' = 'নুডলস'
                                   and (j -> 'lines' -> 0 ->> 'amount')::numeric = 5000 and (j ->> 'open')::numeric = 5000 and (j ->> 'paid')::numeric = 0
                                   and j ->> 'total_words' = 'পাঁচ হাজার টাকা মাত্র' and j ->> 'total_bn' = '৳ ৫,০০০.০০' and length(j ->> 'qr') > 20
                                   and not (j::text ilike '%vat%') and not (j::text ilike '%tax%'),
                                   'invoice print carries company, product names, paid / open, Bengali words and the signed QR — no VAT / tax');

  -- ---------------------------------------------------------------- 50 designs
  j := api.v1_invoice_design_preview();
  insert into _r values ('S68-04', jsonb_array_length(j -> 'designs') = 50
                                   and (select count(distinct spec::text) from sales.invoice_design) = 50
                                   and (select count(distinct name_bn) from sales.invoice_design) = 50
                                   and (select count(distinct spec ->> 'family') from sales.invoice_design) = 10
                                   and not exists (select 1 from sales.invoice_design where not (spec ->> 'words')::boolean)
                                   and (j -> 'sample' ->> 'sample')::boolean
                                   and pg_temp.expect_fail($q$insert into sales.invoice_design (code, name_bn, spec) select 'D51', 'x', spec from sales.invoice_design where code = 'D01'$q$),
                                   '50 distinct, named designs in 10 families, amount in words on all; no duplicate design can be added');

  -- ---------------------------------------------------------------- live KPIs from real data
  j := api.v1_kpi_values(array['dms.sales','dms.invoices','dms.receivable','dms.dispatches','dms.undelivered','stock.total_value','mfg.factory_profit','fin.revenue','fin.cogs'], 'today', null, null, null);
  insert into _r values ('S68-05', (pg_temp.kv(j, 'dms.sales') ->> 'value')::numeric = 5000 and (pg_temp.kv(j, 'dms.invoices') ->> 'value')::numeric = 1
                                   and (pg_temp.kv(j, 'dms.receivable') ->> 'value')::numeric = 5000 and (pg_temp.kv(j, 'dms.dispatches') ->> 'value')::numeric = 1 and (pg_temp.kv(j, 'dms.undelivered') ->> 'value')::numeric = 0
                                   and (pg_temp.kv(j, 'stock.total_value') ->> 'value')::numeric = 450 * 60
                                   and (pg_temp.kv(j, 'fin.revenue') ->> 'value')::numeric = 5000 and (pg_temp.kv(j, 'fin.cogs') ->> 'value')::numeric = 3000
                                   and pg_temp.kv(j, 'dms.sales') ->> 'value_bn' = '৳ ৫,০০০.০০',
                                   'KPIs are computed from invoices, dealer ledger, dispatches, stock and the posted GL — not typed in');
  insert into _r values ('S68-06', not (pg_temp.kv(j, 'mfg.factory_profit') ->> 'restricted')::boolean, 'the Chairman sees the factory figure');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_kpi_values(array['mfg.factory_profit','dms.sales'], 'today', null, null, null);
  insert into _r values ('S68-07', (pg_temp.kv(j, 'mfg.factory_profit') ->> 'restricted')::boolean and not (pg_temp.kv(j, 'mfg.factory_profit') ? 'value')
                                   and pg_temp.expect_fail($q$select api.v1_kpi_series('mfg.factory_profit', 'day', null, null, null)$q$, 'E_FORBIDDEN'),
                                   'factory P&L stays restricted to its positions (no value, no series)');

  -- ---------------------------------------------------------------- graphs: series and split
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_kpi_series('dms.sales', 'day', current_date - 6, current_date, null);
  insert into _r values ('S68-08', jsonb_array_length(j -> 'points') = 7 and (j -> 'points' -> 6 ->> 'value')::numeric = 5000 and (j -> 'points' -> 0 ->> 'value')::numeric = 0
                                   and jsonb_array_length(api.v1_kpi_series('dms.sales', 'month', null, null, null) -> 'points') = 12
                                   and pg_temp.expect_fail($q$select api.v1_kpi_series('dms.sales', 'day', current_date - 60, current_date, null)$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail($q$select api.v1_kpi_series('dms.sales', 'hour', null, null, null)$q$, 'E_INVALID_ACTION'),
                                   'series: one point per day / week / month, at most 36');
  j := api.v1_kpi_split('dms.sales', 'territory', null, null, 12);
  j1 := api.v1_kpi_split('dms.sales', 'product', null, null, 12);
  insert into _r values ('S68-09', jsonb_array_length(j -> 'rows') = 1 and j -> 'rows' -> 0 ->> 'label' = 'খুলনা' and (j -> 'rows' -> 0 ->> 'value')::numeric = 5000
                                   and (j1 -> 'rows' -> 0 ->> 'value')::numeric = 5000
                                   and jsonb_array_length(api.v1_kpi_split('stock.total_value', 'warehouse', null, null, 12) -> 'rows') = 1
                                   and pg_temp.expect_fail($q$select api.v1_kpi_split('hr.headcount', 'territory', null, null, 12)$q$, 'E_INVALID_ACTION'),
                                   'area-wise graphs: sales by territory and product, stock by warehouse; unsupported splits refused');

  -- ---------------------------------------------------------------- Chairman customisation assets
  insert into _r values ('S68-10', (select count(*) from design.theme_template) >= 20
                                   and not exists (select 1 from design.theme_template t where not (design.fn_tokens_report(t.tokens) ->> 'ok')::boolean)
                                   and (select count(*) from design.layout_preset) >= 12
                                   and not exists (select 1 from design.layout_preset p where not (design.fn_layout_report(p.layout, 1, 4) ->> 'ok')::boolean)
                                   and not exists (select 1 from design.layout_preset p, jsonb_array_elements(p.layout -> 'breakpoints' -> 'phone' -> 'widgets') w
                                                    where w ->> 'binding' like 'kpi.%' and not exists (select 1 from report.kpi_catalog k where 'kpi.' || k.code = w ->> 'binding')),
                                   '20 valid themes; every dashboard preset is valid and binds only KPIs that exist');
  insert into _r values ('S68-11', api.v1_kpi_set_style('dms.sales', '{"chart":"line","size":"l","color":"chart2"}', 0, 'trend for the Chairman') = 1
                                   and (select (x ->> 'style_version')::int from jsonb_array_elements(api.v1_kpi_catalog()) x where x ->> 'code' = 'dms.sales') = 1
                                   and pg_temp.expect_fail($q$select api.v1_kpi_set_style('dms.sales', '{"chart":"pie3d"}', 1, 'x')$q$, 'E_DESIGN_INVALID'),
                                   'the graph studio saves a versioned style; unknown chart types are refused');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

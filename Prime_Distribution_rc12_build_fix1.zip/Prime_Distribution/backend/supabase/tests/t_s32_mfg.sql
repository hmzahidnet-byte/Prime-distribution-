-- S32–S35 tests: BOM approval + immutability, plan without stock effect, batch approval (POLY snapshot, reservations,
-- capacity), issues only for approved batches (OI-39), WIP from materials/returns/labour/overhead, QC separation and
-- failed QC blocking FG, waste classification, ADR-11 completion (exact WIP clearance, remainder on last unit,
-- approved low-yield variance), rework without silent new FG, traceability both ways, cost visibility, isolation.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.res(p_batch text, p_prod uuid) returns uuid language sql as $$
  select id from inventory.reservation where batch_ref = p_batch and product_id = p_prod and status = 'active' limit 1 $$;
do $$
declare ok boolean; boot jsonb; ca uuid; a_ch uuid; a_ps uuid; a_md uuid; a_qc uuid; a_sk uuid; a_fm uuid; a_ch2 uuid;
        p_ch uuid; p_ps uuid; p_md uuid; p_qc uuid; p_sk uuid; p_fm uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_ps uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_qc uuid := gen_random_uuid();
        u_sk uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_ch2 uuid := gen_random_uuid();
        rm uuid; fgw uuid; flour uuid; oil uuid; noodle uuid; spec uuid; bom uuid; bom2 uuid; plan uuid; b1 jsonb; b2 jsonb; b3 jsonb; rw jsonb; iss jsonb; tmp uuid;
        w uuid; j jsonb; j1 jsonb; fglot uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('MFG', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_ps := svc.v1_iam_provision_person('উৎপাদন', null, null, u_ps, 't'); a_ps := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ps, ca, null, 't'), 'PROD_SUPERVISOR', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_qc := svc.v1_iam_provision_person('মান', null, null, u_qc, 't'); a_qc := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_qc, ca, null, 't'), 'QC_OFFICER', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('MFX', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  rm := (api.v1_structure_save_warehouse(null, null, null, 'RM', 'কাঁচামাল', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  flour := (api.v1_product_propose(null, 'FLOUR', 'ময়দা', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  oil := (api.v1_product_propose(null, 'OIL', 'তেল', null, 'raw_material', null, 'ltr', null, 'x') ->> 'product_id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(flour, 1, 'approve', 'ok'); perform api.v1_product_decide(oil, 1, 'approve', 'ok'); perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_ps, 'ps'); perform api.v1_iam_select_position(a_ps);
  spec := (api.v1_pack_spec_propose(noodle, null, 12, 25, 20, null, 'spec') ->> 'spec_id')::uuid;
  bom := (api.v1_bom_propose(noodle, null, 1000, jsonb_build_array(jsonb_build_object('material_id', flour, 'qty', 100), jsonb_build_object('material_id', oil, 'qty', 10)), 'recipe v1') ->> 'bom_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_pack_spec_decide(spec, 'approve', 'ok');
  perform api.v1_bom_decide(bom, true, 'ok');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(rm, flour, 'L-F1', null, null, current_date + 90, 500, 0, 0, 40, false, 'opening');
  perform api.v1_stock_receive(rm, oil, 'L-O1', null, null, current_date + 90, 100, 0, 0, 150, false, 'opening');

  -- ---------------------------------------------------------------- BOM (F101)
  perform pg_temp.as_user(u_ch, 'ch');
  bom2 := (api.v1_bom_propose(noodle, null, 1000, jsonb_build_array(jsonb_build_object('material_id', flour, 'qty', 90)), 'recipe v2') ->> 'bom_id')::uuid;
  insert into _r values ('S32-01', pg_temp.expect_fail(format($f$select api.v1_bom_decide(%L, true, 'mine')$f$, bom2), 'E_SELF_APPROVAL')
                                   and pg_temp.expect_fail(format($f$update mfg.bom_line set qty = 1 where bom_id = %L$f$, bom), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$update mfg.bom set output_qty = 1 where id = %L$f$, bom), 'E_IMMUTABLE'),
                                   'BOMs are approved by another person and never change afterwards');
  -- ---------------------------------------------------------------- plan (F102) + batch (F103)
  perform pg_temp.as_user(u_ps, 'ps');
  plan := (api.v1_plan_save(null, current_date, null, jsonb_build_array(jsonb_build_object('product_id', noodle, 'target_poly', 2000)), 'today') ->> 'plan_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_plan_approve(plan, 'ok');
  insert into _r values ('S32-02', not exists (select 1 from inventory.reservation where company_id = ca) and (select status from mfg.plan x_ where x_.id = plan) = 'approved',
                                   'an approved plan reserves and issues nothing');
  perform pg_temp.as_user(u_ps, 'ps');
  b1 := api.v1_batch_create(noodle, null, null, 2000, rm, fgw, 'LINE-1', plan, 1, 'morning batch');
  perform pg_temp.as_user(u_sk, 'sk');
  tmp := (api.v1_stock_reserve(rm, flour, 5, b1 ->> 'number', 'too early') ->> 'reservation_id')::uuid;
  insert into _r values ('S32-03', (b1 ->> 'bom_id')::uuid = bom
                                   and pg_temp.expect_fail(format($f$select api.v1_material_issue(%L, 5, null, 'x')$f$, tmp), 'E_BATCH_NOT_APPROVED'),
                                   'the latest approved BOM is pinned; nothing is issued to a batch before approval');
  perform api.v1_stock_release_reservation(tmp, 'not needed');
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_batch_approve((b1 ->> 'batch_id')::uuid, 'go');
  perform pg_temp.as_user(u_ps, 'ps');
  b2 := api.v1_batch_create(noodle, null, null, 6000, rm, fgw, 'LINE-2', null, null, 'too big');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S32-04', (j -> 'pack_spec' ->> 'sachets_per_poly')::integer = 12
                                   and (select qty from inventory.reservation where id = pg_temp.res(b1 ->> 'number', flour)) = 200
                                   and (select qty from inventory.reservation where id = pg_temp.res(b1 ->> 'number', oil)) = 20
                                   and (select used_at is not null from mfg.bom x_ where x_.id = bom)
                                   and pg_temp.expect_fail(format($f$select api.v1_batch_approve(%L, 'x')$f$, b2 ->> 'batch_id'), 'E_INSUFFICIENT_STOCK'),
                                   'approval snapshots the POLY spec and reserves exactly the BOM; never above available');
  -- ---------------------------------------------------------------- issue, return, labour, overhead (F104, F107)
  perform pg_temp.as_user(u_sk, 'sk');
  iss := api.v1_material_issue(pg_temp.res(b1 ->> 'number', flour), 200, null, 'mix');
  perform api.v1_material_issue(pg_temp.res(b1 ->> 'number', oil), 20, null, 'fry');
  perform pg_temp.as_user(u_ps, 'ps');
  perform api.v1_material_return((iss ->> 'issue_id')::uuid, 1, 10, 'left over');
  perform api.v1_batch_cost((b1 ->> 'batch_id')::uuid, 'labor', 1500, 'shift wages');
  perform api.v1_batch_cost((b1 ->> 'batch_id')::uuid, 'overhead', 900, 'gas and power');
  insert into _r values ('S32-05', (select status from mfg.batch where id = (b1 ->> 'batch_id')::uuid) = 'in_progress'
                                   and mfg.fn_material_cost((b1 ->> 'batch_id')::uuid) = 10600 and mfg.fn_wip((b1 ->> 'batch_id')::uuid) = 13000,
                                   'WIP = materials issued − returned + labour + overhead');
  -- ---------------------------------------------------------------- QC + waste (F105, F106)
  insert into _r values ('S32-06', pg_temp.expect_fail(format($f$select api.v1_batch_qc(%L, 'final', 'pass', null, 'x')$f$, b1 ->> 'batch_id'), 'E_FORBIDDEN'),
                                   'the production supervisor has no QC right');
  perform pg_temp.as_user(u_qc, 'qc'); perform api.v1_iam_select_position(a_qc);
  perform api.v1_batch_qc((b1 ->> 'batch_id')::uuid, 'final', 'fail', '{"moisture":14}', 'too moist');
  perform pg_temp.as_user(u_ps, 'ps');
  insert into _r values ('S32-07', pg_temp.expect_fail(format($f$select api.v1_batch_complete(%L, 1950, null, null, 'x')$f$, b1 ->> 'batch_id'), 'E_QC_FAILED'),
                                   'a failed final QC blocks FG posting');
  perform api.v1_batch_waste((b1 ->> 'batch_id')::uuid, 'normal', 20, 'trim');
  w := (api.v1_batch_waste((b1 ->> 'batch_id')::uuid, 'abnormal', 100, 'machine jam') ->> 'waste_id')::uuid;
  perform pg_temp.as_user(u_qc, 'qc');
  perform api.v1_batch_qc((b1 ->> 'batch_id')::uuid, 'final', 'pass', '{"moisture":11}', 'dried');
  perform pg_temp.as_user(u_ps, 'ps');
  insert into _r values ('S32-08', pg_temp.expect_fail(format($f$select api.v1_batch_complete(%L, 1950, null, null, 'x')$f$, b1 ->> 'batch_id'), 'E_INVALID_ACTION'),
                                   'pending abnormal waste must be decided before completion');
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  j := api.v1_batch_waste_decide(w, true, 'confirmed');
  insert into _r values ('S32-09', (j ->> 'value')::numeric = 650 and mfg.fn_wip((b1 ->> 'batch_id')::uuid) = 12350,
                                   'abnormal waste leaves WIP at its share and is classified apart; normal waste stays in FG cost');
  -- ---------------------------------------------------------------- completion (F108, ADR-11)
  perform pg_temp.as_user(u_ps, 'ps');
  j := api.v1_batch_complete((b1 ->> 'batch_id')::uuid, 1950, null, current_date + 180, 'done');
  fglot := (j ->> 'fg_lot_id')::uuid;
  insert into _r values ('S32-10', j ->> 'status' = 'completed' and (j ->> 'capitalised')::numeric = 12350
                                   and (select value from inventory.stock_balance where warehouse_id = fgw and product_id = noodle) = 12350
                                   and (select qty from inventory.stock_balance where warehouse_id = fgw and product_id = noodle) = 1950
                                   and (select sum(amount) from mfg.wip_entry where batch_id = (b1 ->> 'batch_id')::uuid) = 0
                                   and (select unit_cost from inventory.stock_move where doc_id = (b1 ->> 'batch_id')::uuid and doc_line = 1) = 6.3333
                                   and (select unit_cost from inventory.stock_move where doc_id = (b1 ->> 'batch_id')::uuid and doc_line = 2) = 6.3983
                                   and not exists (select 1 from inventory.reservation where batch_ref = b1 ->> 'number' and status = 'active')
                                   and pg_temp.expect_fail(format($f$select api.v1_material_return(%L, 1, 1, 'x')$f$, iss ->> 'issue_id'), 'E_BATCH_NOT_APPROVED'),
                                   'WIP is cleared to zero into FG; the last POLY carries the remainder; leftovers released; closed batches take no returns');
  -- low yield: approval + variance
  b3 := api.v1_batch_create(noodle, null, null, 500, rm, fgw, 'LINE-1', null, null, 'small batch');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_batch_approve((b3 ->> 'batch_id')::uuid, 'go');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_material_issue(pg_temp.res(b3 ->> 'number', flour), 50, null, 'mix');
  perform api.v1_material_issue(pg_temp.res(b3 ->> 'number', oil), 5, null, 'fry');
  perform pg_temp.as_user(u_qc, 'qc');
  perform api.v1_batch_qc((b3 ->> 'batch_id')::uuid, 'final', 'pass', null, 'ok');
  perform pg_temp.as_user(u_ps, 'ps');
  j := api.v1_batch_complete((b3 ->> 'batch_id')::uuid, 400, null, null, 'burnt part');
  perform pg_temp.as_user(u_md, 'md');
  j1 := api.v1_batch_completion_decide((b3 ->> 'batch_id')::uuid, true, 'accepted loss');
  insert into _r values ('S32-11', j ->> 'status' = 'completion_pending' and (j ->> 'yield_pct')::numeric = 80
                                   and (j1 ->> 'capitalised')::numeric = 2200 and (j1 ->> 'variance')::numeric = 550
                                   and (select sum(amount) from mfg.wip_entry where batch_id = (b3 ->> 'batch_id')::uuid) = 0,
                                   'low yield needs approval; the exceptional part becomes a variance; WIP still clears to zero');
  -- ---------------------------------------------------------------- rework (F109)
  perform pg_temp.as_user(u_ps, 'ps');
  rw := api.v1_rework_create(noodle, fgw, fglot, 100, fgw, 'market return repack');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_batch_approve((rw ->> 'batch_id')::uuid, 'ok');
  perform pg_temp.as_user(u_qc, 'qc');
  perform api.v1_batch_qc((rw ->> 'batch_id')::uuid, 'final', 'pass', null, 'repacked ok');
  perform pg_temp.as_user(u_ps, 'ps');
  ok := pg_temp.expect_fail(format($f$select api.v1_batch_complete(%L, 120, null, null, 'x')$f$, rw ->> 'batch_id'), 'E_REWORK_EXCEEDS');
  ok := ok and (api.v1_batch_complete((rw ->> 'batch_id')::uuid, 95, null, null, 'repacked') ->> 'status') = 'completed';
  insert into _r values ('S32-12', ok and (select sum(amount) from mfg.wip_entry where batch_id = (rw ->> 'batch_id')::uuid) = 0,
                                   'rework never creates more FG than it consumed');
  -- ---------------------------------------------------------------- traceability, cost visibility, isolation (F110)
  perform pg_temp.as_user(u_sk, 'sk');
  j := api.v1_trace_backward(fglot);
  j1 := api.v1_trace_forward((select id from inventory.lot where lot_no = 'L-F1' and product_id = flour));
  insert into _r values ('S32-13', exists (select 1 from jsonb_array_elements(j -> 'materials') x where x ->> 'lot_no' = 'L-F1')
                                   and exists (select 1 from jsonb_array_elements(j -> 'materials') x where x ->> 'lot_no' = 'L-O1')
                                   and jsonb_array_length(j1 -> 'batches') = 2
                                   and exists (select 1 from jsonb_array_elements(api.v1_trace_forward(fglot) -> 'batches') x where (x ->> 'batch_id')::uuid = (rw ->> 'batch_id')::uuid),
                                   'one call traces FG lot -> raw lots and raw lot -> batches -> FG lots (rework included)');
  perform pg_temp.as_user(u_qc, 'qc');
  j := api.v1_batch_get((b1 ->> 'batch_id')::uuid);
  perform pg_temp.as_user(u_md, 'md');
  j1 := api.v1_batch_get((b1 ->> 'batch_id')::uuid);
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S32-14', j -> 'wip_entries' = 'null'::jsonb and not (j ? 'fg_unit_cost') and jsonb_array_length(j1 -> 'wip_entries') >= 5
                                   and pg_temp.expect_fail(format($f$select api.v1_trace_backward(%L)$f$, fglot), 'E_NOT_FOUND'),
                                   'costs only for cost readers; other companies cannot trace our lots');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

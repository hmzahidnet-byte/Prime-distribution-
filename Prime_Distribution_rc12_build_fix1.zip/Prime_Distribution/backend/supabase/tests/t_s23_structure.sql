-- S23 tests: administrative-area import (counts, hierarchy, anomalies), search incl. suffix + alias, structure saves
-- (department tree, wing rule, cycle), BD coordinates, area path, warehouses + WAREHOUSE scope, units in use,
-- immutable codes, rights.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
do $$
declare boot jsonb; ca uuid; cb uuid; a_ch uuid; a_md uuid; a_ac uuid; p_ch uuid; p_md uuid; p_ac uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_ch2 uuid := gen_random_uuid();
        w2 uuid; d1 uuid; d2 uuid; loc uuid; wh uuid; whb uuid; j jsonb; upz text;
begin
  insert into _r values ('S23-01', (select count(*) from location.admin_area where kind = 'division') = 8 and (select count(*) from location.admin_area where kind = 'district') = 64
                                   and (select count(*) from location.admin_area where kind = 'upazila') = 492 and (select count(*) from location.admin_area where kind = 'union') = 4537
                                   and not exists (select 1 from location.admin_area a join location.admin_area p on p.code = a.parent_code
                                                    where (a.kind, p.kind) not in (('district','division'),('upazila','district'),('union','upazila')))
                                   and (select count(*) from location.admin_area_anomaly) = 9,
                                   'Bangladesh areas imported as supplied: hierarchy intact, anomalies recorded');
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('STR', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('STX', 'খ', p_ch2, 't'); cb := (boot ->> 'company_id')::uuid;
  insert into inventory.warehouse (company_id, code, name_bn, kind) values (cb, 'OTHER', 'অন্য গুদাম', 'general') returning id into whb;

  -- ---------------------------------------------------------------- geo search (any member)
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  j := api.v1_geo_search('কচুয়া', 'upazila', 10);
  upz := j -> 0 ->> 'code';
  insert into _r values ('S23-02', exists (select 1 from jsonb_array_elements(api.v1_geo_search('বাগেরহাট', 'district', 10)) x where x ->> 'path' like '%খুলনা%বাগেরহাট%')
                                   and jsonb_array_length(j) >= 1 and upz ~ '^[0-9]{2}\.[0-9]{2}\.[0-9]{3}$'
                                   and jsonb_array_length(api.v1_geo_children(null)) = 8 and jsonb_array_length(api.v1_geo_children(upz)) >= 1,
                                   'search ignores the generic suffix; children walk the hierarchy');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_geo_add_alias((select code from location.admin_area where kind = 'district' and name_bn = 'বাগেরহাট'), 'ষাটগম্বুজের শহর', 'local name');
  insert into _r values ('S23-03', exists (select 1 from jsonb_array_elements(api.v1_geo_search('ষাটগম্বুজ', null, 10)) x where x ->> 'name_bn' = 'বাগেরহাট')
                                   and pg_temp.expect_fail($q$select api.v1_geo_add_alias('99', 'x', 'x')$q$, 'E_NOT_FOUND'),
                                   'aliases are kept separately and found by search');
  -- ---------------------------------------------------------------- structure saves
  w2 := (api.v1_structure_save_wing(null, 'w2', 'দুই', null, 'trading', 2, null, null, 'new wing') ->> 'id')::uuid;
  d1 := (api.v1_structure_save_department(null, w2, null, 'D1', 'বিক্রয়', null, 1, null, null, 'x') ->> 'id')::uuid;
  d2 := (api.v1_structure_save_department(null, w2, d1, 'D2', 'ঢাকা বিক্রয়', null, 1, null, null, 'x') ->> 'id')::uuid;
  insert into _r values ('S23-04', (select code from core.wing where id = w2) = 'W2'
                                   and pg_temp.expect_fail(format($f$select api.v1_structure_save_department(%L, %L, %L, null, 'বিক্রয়', null, 1, null, 1, 'x')$f$, d1, w2, d2), 'E_DEPARTMENT_CYCLE')
                                   and pg_temp.expect_fail(format($f$select api.v1_structure_save_department(null, (select id from core.wing where company_id = %L and code <> 'W2' limit 1), %L, 'D3', 'x', null, 1, null, null, 'x')$f$, ca, d1), 'E_INVALID_ACTION'),
                                   'department tree: same wing, no cycles');
  insert into _r values ('S23-05', pg_temp.expect_fail(format($f$select api.v1_structure_save_location(null, %L, 'L9', 'x', 'depot', null, null, 51.5, -0.1, null, null, null, 'x')$f$, w2), 'E_INVALID_ACTION'),
                                   'coordinates must be inside Bangladesh');
  loc := (api.v1_structure_save_location(null, w2, 'DEPOT1', 'বাগেরহাট ডিপো', 'depot', 'রেল রোড', upz, 22.65, 89.79, 200, null, null, 'new depot') ->> 'id')::uuid;
  wh := (api.v1_structure_save_warehouse(null, w2, loc, 'WH1', 'কাঁচামাল গুদাম', 'raw_material', null, null, 'new store') ->> 'id')::uuid;
  j := api.v1_structure_tree();
  insert into _r values ('S23-06', exists (select 1 from jsonb_array_elements(j -> 'locations') x where (x ->> 'id')::uuid = loc and x ->> 'admin_area' like '% › % › %')
                                   and exists (select 1 from jsonb_array_elements(j -> 'warehouses') x where (x ->> 'id')::uuid = wh)
                                   and exists (select 1 from jsonb_array_elements(j -> 'wings') w, jsonb_array_elements(w -> 'departments') d where (d ->> 'id')::uuid = d2 and (d ->> 'parent_id')::uuid = d1),
                                   'one tree: wings, departments, locations with area path, warehouses');
  -- ---------------------------------------------------------------- WAREHOUSE scope
  insert into _r values ('S23-07', pg_temp.expect_fail(format($f$insert into iam.position_permission_rule (company_id, position_code, permission_code, effect, scope_kind, scope_id, reason) values (%L, 'STOREKEEPER', 'inventory.stock.read', 'allow', 'WAREHOUSE', %L, 'x')$f$, ca, whb), 'E_WRONG_COMPANY')
                                   and pg_temp.expect_fail(format($f$insert into iam.position_permission_rule (company_id, position_code, permission_code, effect, scope_kind, scope_id, reason) values (%L, 'STOREKEEPER', 'inventory.stock.read', 'allow', 'WAREHOUSE', null, 'x')$f$, ca)),
                                   'a warehouse rule names a warehouse of the same company');
  insert into iam.position_permission_rule (company_id, position_code, permission_code, effect, scope_kind, scope_id, reason)
  values (ca, 'STOREKEEPER', 'inventory.stock.read', 'allow', 'WAREHOUSE', wh, 'store keeper sees WH1');
  insert into _r values ('S23-08', pg_temp.expect_fail(format($f$select api.v1_structure_save_warehouse(%L, %L, %L, null, null, null, 'inactive', 1, 'x')$f$, wh, w2, loc), 'E_STRUCTURE_IN_USE')
                                   and pg_temp.expect_fail(format($f$select api.v1_structure_save_wing(%L, null, null, null, null, null, 'inactive', 1, 'x')$f$, w2), 'E_STRUCTURE_IN_USE')
                                   and pg_temp.expect_fail(format($f$update core.wing set code = 'ZZ' where id = %L$f$, w2), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$select api.v1_structure_save_wing(%L, null, 'নতুন নাম', null, null, null, null, 99, 'x')$f$, w2), 'E_STALE_VERSION'),
                                   'units in use stay active; codes never change; edits are version-checked');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S23-09', jsonb_array_length(api.v1_structure_tree() -> 'wings') >= 1
                                   and pg_temp.expect_fail($q$select api.v1_structure_save_wing(null, 'W9', 'x', null, null, null, null, null, 'x')$q$, 'E_FORBIDDEN'),
                                   'MD reads the structure; only the Chairman (or a granted manager) changes it');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S26–S28 tests: supplier duplicates, requisition maker-checker + quote comparison, PO approval and change orders,
-- GRN only on approved PO with QC split and over-receipt guard, GRNI, duplicate invoices, three-way match with
-- variance approval, payments never above the open payable, debit-note return, aging (posted only), performance,
-- QC-required receiving, idempotent GRN, company isolation.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.req(p_type text, p_id uuid) returns uuid language sql as $$
  select id from core.approval_request where document_type = p_type and document_id = p_id and status = 'pending' $$;
create or replace function pg_temp.rrv(p uuid) returns integer language sql as $$ select row_version from core.approval_request where id = p $$;
create or replace function pg_temp.bal(p_wh uuid, p_prod uuid) returns numeric language sql as $$ select coalesce((select qty from inventory.stock_balance where warehouse_id = p_wh and product_id = p_prod), 0) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_po uuid; a_md uuid; a_sk uuid; a_ac uuid; a_fm uuid; a_ch2 uuid;
        p_ch uuid; p_po uuid; p_md uuid; p_sk uuid; p_ac uuid; p_fm uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_po uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_ch2 uuid := gen_random_uuid();
        wh uuid; flour uuid; supa uuid; supb uuid; pr uuid; po uuid; pl uuid; grn jsonb; gl uuid; bill1 uuid; bill2 uuid; pay uuid; dn uuid; j jsonb; j1 jsonb; r uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRC', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  -- these tests exercise maker-checker with MD / finance approvers; the Chairman-only rule (Prime v180) has its own test (t_s56)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_config_set('approval.financial.chairman_only', 'false'::jsonb, 0, 'legacy maker-checker test');
  p_po := svc.v1_iam_provision_person('ক্রয়', null, null, u_po, 't'); a_po := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_po, ca, null, 't'), 'PURCHASE_OFFICER', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('PRZ', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  wh := (api.v1_structure_save_warehouse(null, null, null, 'RM1', 'কাঁচামাল', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  flour := (api.v1_product_propose(null, 'FLOUR', 'ময়দা', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(flour, 1, 'approve', 'ok');

  -- ---------------------------------------------------------------- suppliers (F081)
  perform pg_temp.as_user(u_po, 'po'); perform api.v1_iam_select_position(a_po);
  supa := (api.v1_supplier_save(null, 'SUPA', 'রহিম ট্রেডার্স', null, '01711111111', null, null, null, '123456789012', 30, null, '••••4321', null, null, 'new') ->> 'supplier_id')::uuid;
  supb := (api.v1_supplier_save(null, 'SUPB', 'করিম এন্টারপ্রাইজ', null, '01811111111', null, null, null, null, 15, null, null, null, null, 'new') ->> 'supplier_id')::uuid;
  insert into _r values ('S26-01', pg_temp.expect_fail($q$select api.v1_supplier_save(null, 'SUPX', 'রহিম  ট্রেডার্স!', null, '+8801711111111', null, null, null, null, 30, null, null, null, null, 'x')$q$, 'E_DUPLICATE_SUPPLIER')
                                   and pg_temp.expect_fail($q$select api.v1_supplier_save(null, 'SUPY', 'অন্য নাম', null, '01911111111', null, null, null, '1234-5678-9012', 30, null, null, null, null, 'x')$q$, 'E_DUPLICATE_SUPPLIER')
                                   and pg_temp.expect_fail($q$select api.v1_supplier_save(null, 'SUPZ', 'জেড', null, '01611111111', null, null, null, null, 30, null, '1234567890', null, null, 'x')$q$, 'E_INVALID_ACTION'),
                                   'duplicates caught by tax id and by the tax-neutral name+phone key; bank numbers only masked');
  -- ---------------------------------------------------------------- requisition (F082)
  perform pg_temp.as_user(u_ch, 'ch');
  pr := (api.v1_pr_save(null, null, null, current_date + 20, jsonb_build_array(jsonb_build_object('product_id', flour, 'qty', 1000, 'est_price', 50)), 'monthly flour') ->> 'pr_id')::uuid;
  perform api.v1_pr_action(pr, 'submit', 'need flour');
  r := pg_temp.req('procurement.pr', pr);
  insert into _r values ('S26-02', pg_temp.expect_fail(format($f$select api.v1_approval_decide(%L, 'approve', %s, 'mine')$f$, r, pg_temp.rrv(r)), 'E_SELF_APPROVAL'),
                                   'the requester never approves the own requisition');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_approval_decide(r, 'approve', pg_temp.rrv(r), 'ok');
  perform pg_temp.as_user(u_po, 'po');
  perform api.v1_pr_quote_add(pr, supa, flour, 48, 5);
  perform api.v1_pr_quote_add(pr, supb, flour, 45, 7);
  j := api.v1_pr_compare(pr);
  insert into _r values ('S26-03', (select status from procurement.pr x_ where x_.id = pr) = 'approved'
                                   and (j -> 0 -> 'quotes' -> 0 ->> 'supplier_id')::uuid = supb and (j -> 0 -> 'quotes' -> 0 ->> 'best')::boolean
                                   and not (j -> 0 -> 'quotes' -> 1 ->> 'best')::boolean,
                                   'quotes compared, cheapest flagged');
  -- ---------------------------------------------------------------- PO (F083, F072)
  po := (api.v1_po_create(supb, wh, pr, current_date + 15, null, jsonb_build_array(jsonb_build_object('product_id', flour, 'qty', 1000, 'unit_price', 45)), 'order flour') ->> 'po_id')::uuid;
  pl := (select id from procurement.po_line where po_id = po and line_no = 1);
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  insert into _r values ('S26-04', pg_temp.expect_fail(format($f$select api.v1_grn_post(%L, null, '[{"po_line_id":"%s","received":10}]', 'x')$f$, po, pl), 'E_PO_NOT_APPROVED'),
                                   'no goods receipt without an approved purchase order');
  perform pg_temp.as_user(u_po, 'po');
  perform api.v1_po_action(po, 'submit', (select row_version from procurement.po x_ where x_.id = po), 'please approve');
  perform pg_temp.as_user(u_md, 'md');
  r := pg_temp.req('procurement.po', po);
  perform api.v1_approval_decide(r, 'approve', pg_temp.rrv(r), 'ok');
  perform pg_temp.as_user(u_po, 'po');
  j := api.v1_po_change(po, '{"lines":[{"line_no":1,"qty":1200}]}', 'more needed');
  insert into _r values ('S26-05', (select status from procurement.po x_ where x_.id = po) = 'approved' and (select status from procurement.pr x_ where x_.id = pr) = 'ordered'
                                   and (select qty from procurement.po_line where id = pl) = 1000 and j ->> 'status' = 'pending' and (j ->> 'new_total')::numeric = 54000
                                   and pg_temp.expect_fail(format($f$update procurement.po_line set qty = 5 where id = %L$f$, pl), 'E_PO_LOCKED'),
                                   'an approved PO changes only through an approved change order');
  perform pg_temp.as_user(u_md, 'md');
  r := pg_temp.req('procurement.po_change', (j ->> 'change_id')::uuid);
  perform api.v1_approval_decide(r, 'approve', pg_temp.rrv(r), 'ok');
  insert into _r values ('S26-06', (select qty from procurement.po_line where id = pl) = 1200 and (select version from procurement.po x_ where x_.id = po) = 2
                                   and (select total from procurement.po x_ where x_.id = po) = 54000, 'approved change order applies and bumps the PO version');
  -- ---------------------------------------------------------------- GRN (F084)
  perform pg_temp.as_user(u_sk, 'sk');
  perform set_config('request.headers', '{"idempotency-key":"k-grn-00000001"}', true);
  grn := api.v1_grn_post(po, 'DN-55', format('[{"po_line_id":"%s","lot_no":"F-1","expiry_date":"%s","received":600,"accepted":550,"quarantine":30,"rejected":20}]', pl, current_date + 100)::jsonb, 'truck 1');
  j1 := api.v1_grn_post(po, 'DN-55', format('[{"po_line_id":"%s","lot_no":"F-1","expiry_date":"%s","received":600,"accepted":550,"quarantine":30,"rejected":20}]', pl, current_date + 100)::jsonb, 'truck 1');
  perform set_config('request.headers', '', true);
  gl := (select id from procurement.grn_line where grn_id = (grn ->> 'grn_id')::uuid);
  insert into _r values ('S26-07', pg_temp.bal(wh, flour) = 550 and (select received_qty from procurement.po_line where id = pl) = 580
                                   and (select status from procurement.po x_ where x_.id = po) = 'partially_received' and j1 = grn
                                   and (select value from inventory.stock_balance where warehouse_id = wh and product_id = flour) = 24750
                                   and pg_temp.expect_fail(format($f$select api.v1_grn_post(%L, null, '[{"po_line_id":"%s","received":700}]', 'x')$f$, po, pl), 'E_OVER_RECEIPT'),
                                   'only accepted stock enters at PO price; a replay changes nothing; no over-receipt');
  -- ---------------------------------------------------------------- bills + match (F085, F086)
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  j := api.v1_bill_create(supb, 'INV-77', current_date, jsonb_build_array(jsonb_build_object('grn_line_id', gl, 'qty', 550, 'unit_price', 45)), 'bill 77');
  bill1 := (j ->> 'bill_id')::uuid;
  insert into _r values ('S26-08', j ->> 'status' = 'posted' and (j ->> 'total')::numeric = 24750
                                   and pg_temp.expect_fail(format($f$select api.v1_bill_create(%L, 'inv 77', current_date, '[{"grn_line_id":"%s","qty":1,"unit_price":45}]', 'x')$f$, supb, gl), 'E_DUPLICATE_INVOICE'),
                                   'matched bill posts; the same supplier invoice is never captured twice');
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  perform api.v1_quarantine_decide((select h.id from inventory.quarantine_hold h join procurement.grn_line g on g.receipt_id = h.receipt_id where g.id = gl), 30, 0, 'QC ok');
  perform pg_temp.as_user(u_ac, 'ac');
  j1 := api.v1_grni(supb);
  j := api.v1_bill_create(supb, 'INV-78', current_date, jsonb_build_array(jsonb_build_object('grn_line_id', gl, 'qty', 30, 'unit_price', 50)), 'bill 78');
  bill2 := (j ->> 'bill_id')::uuid;
  insert into _r values ('S26-09', (j1 -> 0 ->> 'value')::numeric = 1350 and j ->> 'status' = 'variance_pending' and j -> 'variances' -> 0 ->> 'kind' = 'price',
                                   'GRNI = released-but-unbilled value; a price variance waits for approval');
  perform pg_temp.as_user(u_md, 'md');
  r := pg_temp.req('procurement.bill_variance', bill2);
  perform api.v1_approval_decide(r, 'approve', pg_temp.rrv(r), 'agreed new price');
  -- ---------------------------------------------------------------- payments (F087)
  perform pg_temp.as_user(u_fm, 'fm');
  pay := (api.v1_supplier_payment(supb, 'bank', 'CHQ-1', jsonb_build_array(jsonb_build_object('bill_id', bill1, 'amount', 20000)), 'part payment') ->> 'payment_id')::uuid;
  insert into _r values ('S26-10', (select status from procurement.bill where id = bill2) = 'posted'
                                   and pg_temp.expect_fail(format($f$select api.v1_supplier_payment(%L, 'cash', null, '[{"bill_id":"%s","amount":5000}]', 'x')$f$, supb, bill1), 'E_OVERPAYMENT')
                                   and procurement.fn_bill_open(bill1) = 24750,
                                   'a pending payment already counts against the open payable; only posted payments reduce it');
  perform pg_temp.as_user(u_md, 'md');
  r := pg_temp.req('procurement.payment', pay);
  perform api.v1_approval_decide(r, 'approve', pg_temp.rrv(r), 'ok');
  -- ---------------------------------------------------------------- debit note return (F088)
  perform pg_temp.as_user(u_po, 'po');
  dn := (api.v1_debit_note('return', gl, bill1, 50, null, 'damaged bags') ->> 'debit_note_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  r := pg_temp.req('procurement.debit_note', dn);
  perform api.v1_approval_decide(r, 'approve', pg_temp.rrv(r), 'ok');
  insert into _r values ('S26-11', pg_temp.bal(wh, flour) = 530 and (select returned_qty from procurement.grn_line where id = gl) = 50
                                   and procurement.fn_bill_open(bill1) = 2500
                                   and exists (select 1 from inventory.stock_move m where m.doc_id = dn and m.move_type = 'purchase_return'),
                                   'a return debit note moves stock out and reduces the linked bill');
  -- ---------------------------------------------------------------- aging + performance (F089, F090)
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_supplier_payment(supb, 'cash', null, jsonb_build_array(jsonb_build_object('bill_id', bill2, 'amount', 1000)), 'pending only');
  j := api.v1_supplier_dues(null);
  j1 := api.v1_supplier_performance(null, null);
  insert into _r values ('S26-12', (j -> 0 ->> 'open')::numeric = 4000 and (j -> 0 ->> 'current')::numeric = 4000
                                   and (j1 -> 0 ->> 'grns')::integer = 1 and (j1 -> 0 ->> 'on_time_pct')::numeric = 100 and (j1 -> 0 ->> 'rejection_pct')::numeric = 3.3
                                   and (j1 -> 0 ->> 'price_variance_bills')::integer = 1,
                                   'aging counts posted documents only; performance shows on-time, rejection and price variance');
  -- ---------------------------------------------------------------- QC-required receiving, closing, isolation
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('procurement.grn.requires_qc', 'true'::jsonb, 0, 'QC must inspect');
  perform pg_temp.as_user(u_sk, 'sk');
  grn := api.v1_grn_post(po, 'DN-56', format('[{"po_line_id":"%s","lot_no":"F-2","received":100,"accepted":100}]', pl)::jsonb, 'truck 2');
  insert into _r values ('S26-13', pg_temp.bal(wh, flour) = 530 and (grn -> 'lines' -> 0 ->> 'quarantine')::numeric = 100,
                                   'without the QC right everything received waits in quarantine');
  perform pg_temp.as_user(u_po, 'po');
  insert into _r values ('S26-14', pg_temp.expect_fail(format($f$select api.v1_po_action(%L, 'cancel', %s, 'x')$f$, po, (select row_version from procurement.po x_ where x_.id = po)), 'E_INVALID_ACTION')
                                   and (api.v1_po_action(po, 'close', (select row_version from procurement.po x_ where x_.id = po), 'done') ->> 'status') = 'closed',
                                   'a PO with receipts is closed, never cancelled');
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S26-15', pg_temp.expect_fail(format($f$select api.v1_po_get(%L)$f$, po), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail(format($f$select api.v1_bill_create(%L, 'X1', current_date, '[{"grn_line_id":"%s","qty":1,"unit_price":1}]', 'x')$f$, supb, gl), 'E_NOT_FOUND')
                                   and jsonb_array_length(api.v1_supplier_dues(null)) = 0,
                                   'another company sees and touches nothing');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

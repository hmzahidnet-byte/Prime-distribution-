-- S64 tests (ধাপ ২: 03_SOURCE_STATEMENT_REGISTER, docs/V180_STATEMENT_AUDIT_BN.md): demotion, sales commission with Chairman posting,
-- SKU coverage by territory, manual transport milestones, cash custody hand-over. Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        u_hr uuid := gen_random_uuid(); p_hr uuid; a_hr uuid; run jsonb; ho jsonb; mt jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  p_hr := svc.v1_iam_provision_person('এইচআর', null, null, u_hr, 't'); a_hr := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_hr, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  -- order -> dispatch -> invoice 20000 for the dealer of field officer p_fs
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 200)), null);
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 4);
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, null, null);
  perform pg_temp.as_user(u_ac, 'ac');
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);

  -- ---------------------------------------------------------------- REC-0040 transport milestones
  perform pg_temp.as_user(u_sk, 'sk');
  mt := api.v1_transport_milestone((ds ->> 'dispatch_id')::uuid, null, 'launch', 'departed', 'বরিশাল ঘাট', 'এমভি সুন্দরবন-১০', null, null);
  insert into _r values ('S64-01', pg_temp.expect_fail(format($f$select api.v1_transport_milestone(%L, null, 'launch', 'problem', null, null, '', null)$f$, ds ->> 'dispatch_id'), 'E_REASON_REQUIRED')
                                   and pg_temp.expect_fail(format($f$select api.v1_transport_milestone(%L, null, 'airplane', 'loaded', null, null, null, null)$f$, ds ->> 'dispatch_id'), 'E_INVALID_ACTION')
                                   and jsonb_array_length(api.v1_transport_track((ds ->> 'dispatch_id')::uuid, null)) = 1
                                   and pg_temp.expect_fail(format($f$delete from sales.transport_milestone where id = %L$f$, mt ->> 'milestone_id'))
                                   and pg_temp.bal(ca, '5100') = 0,
                                   'bus / launch / trawler milestones are kept as a track, a problem needs a note, nothing moves stock or money');

  -- ---------------------------------------------------------------- REC-0031 commission
  perform pg_temp.as_user(u_hr, 'hr'); perform api.v1_iam_select_position(a_hr);
  insert into _r values ('S64-02', pg_temp.expect_fail($q$select api.v1_commission_rule_set('FIELD_SALES', null, 'sales', 0, current_date, 'x')$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail($q$select api.v1_commission_rule_set(null, null, 'sales', 2, current_date, 'x')$q$, 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail($q$select api.v1_commission_rule_set('FIELD_SALES', null, 'sales', 2, current_date - 400, 'x')$q$, 'E_INVALID_ACTION'),
                                   'a rule has a positive percent, one target and never starts in a closed past month');
  perform api.v1_commission_rule_set('FIELD_SALES', null, 'sales', 2, current_date, 'field incentive');
  run := api.v1_commission_calculate(current_date);
  insert into _r values ('S64-03', (run ->> 'total')::numeric = 400 and run -> 'lines' -> 0 ->> 'person_id' = p_fs::text
                                   and pg_temp.expect_fail($q$select api.v1_commission_calculate(current_date)$q$, 'E_DUPLICATE'),
                                   'net sales of the officer''s dealers x percent; one run per month');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S64-04', pg_temp.expect_fail(format($f$select api.v1_commission_decide(%L, true)$f$, run ->> 'run_id'), 'E_CHAIRMAN_ONLY') and pg_temp.bal(ca, '5710') = 0,
                                   'commission money is posted only by the Chairman');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_commission_decide((run ->> 'run_id')::uuid, true);
  perform pg_temp.as_user(u_fs, 'fs');
  j := api.v1_commission_runs(current_date);
  insert into _r values ('S64-05', pg_temp.bal(ca, '5710') = 400 and pg_temp.bal(ca, '2200') = -400
                                   and pg_temp.expect_fail(format($f$select api.v1_commission_decide(%L, true)$f$, run ->> 'run_id'))
                                   and (j -> 0 -> 'lines' -> 0 ->> 'amount')::numeric = 400 and j -> 0 ->> 'total' is null,
                                   'posted once into salary payable; the officer sees the own line, not the company total');

  -- ---------------------------------------------------------------- REC-0037 coverage
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_territory_coverage(current_date, current_date);
  insert into _r values ('S64-06', (j -> 0 ->> 'active_dealers')::int = 1 and (j -> 0 -> 'skus' -> 0 ->> 'coverage_pct')::numeric = 100
                                   and (j -> 0 -> 'skus' -> 0 ->> 'qty')::numeric = 200 and jsonb_array_length(j -> 0 -> 'supply_gaps') = 0,
                                   'coverage = dealers buying the SKU / active dealers of the territory; gaps list unsold SKUs');

  -- ---------------------------------------------------------------- REC-0078 cash custody hand-over
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S64-07', pg_temp.expect_fail(format($f$select api.v1_cash_handover_offer(%L, %L, 100, null)$f$, cash, p_fm), 'E_REASON_REQUIRED')
                                   and pg_temp.expect_fail(format($f$select api.v1_cash_handover_offer(%L, %L, 0, null)$f$, cash, p_ac), 'E_INVALID_ACTION'),
                                   'a counted difference needs an explanation; the box goes to a different person');
  ho := api.v1_cash_handover_offer(cash, p_fm, 0, null);
  insert into _r values ('S64-08', pg_temp.expect_fail(format($f$select api.v1_cash_handover_accept(%L, true)$f$, ho ->> 'handover_id'), 'E_FORBIDDEN')
                                   and (select custodian from finance.cash_account where id = cash) = p_ac,
                                   'custody does not pass until the receiver confirms');
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_cash_handover_accept((ho ->> 'handover_id')::uuid, true);
  insert into _r values ('S64-09', (select custodian from finance.cash_account where id = cash) = p_fm
                                   and pg_temp.expect_fail(format($f$update finance.cash_handover set counted = 5 where id = %L$f$, ho ->> 'handover_id'), 'E_IMMUTABLE'),
                                   'the box changes hands, its ledger stays; a hand-over never changes afterwards');

  -- ---------------------------------------------------------------- REC-0105 demotion
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S64-10', pg_temp.expect_fail(format($f$select api.v1_hr_employment_change('demotion', %L, null, null, null, null, null, null, current_date, 'x')$f$, a_sm), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_employment_change('demotion', %L, 'FIELD_SALES', null, null, null, null, null, current_date, '')$f$, a_sm), 'E_REASON_REQUIRED'),
                                   'a demotion names the new position (or grade / pay) and the reason');
  j := api.v1_hr_employment_change('demotion', a_sm, 'FIELD_SALES', null, null, null, null, null, current_date, 'targets missed');
  insert into _r values ('S64-11', (select status from iam.position_assignment where id = a_sm) = 'ended'
                                   and (select position_code from iam.position_assignment where id = (j ->> 'new_assignment_id')::uuid) = 'FIELD_SALES'
                                   and (select kind from hr.employment_change where id = (j ->> 'change_id')::uuid) = 'demotion',
                                   'demotion ends the old position and opens the new one; history stays');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

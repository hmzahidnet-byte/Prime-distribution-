-- S08 tests: forced RLS everywhere, no API-role policies, company pinning after context resolution, unpin per request.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text) returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', 'aal2')::text, true); end $$;
do $$
declare ca uuid; cb uuid; wa uuid; wb uuid; u1 uuid := gen_random_uuid(); u2 uuid := gen_random_uuid(); p1 uuid; p2 uuid; a1 uuid; a2 uuid;
        n integer; m integer; tables integer; j jsonb;
begin
  select count(*) into tables from pg_class c join pg_namespace s on s.oid = c.relnamespace
   where c.relkind in ('r','p') and s.nspname in ('core','iam','config', 'design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify', 'location', 'hardware','api','svc');
  insert into _r values ('S08-01', tables >= 20
     and tables = (select count(*) from pg_class c join pg_namespace s on s.oid = c.relnamespace
                   where c.relkind in ('r','p') and s.nspname in ('core','iam','config', 'design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify', 'location', 'hardware','api','svc')
                     and c.relrowsecurity and c.relforcerowsecurity
                     and exists (select 1 from pg_policy p where p.polrelid = c.oid and p.polname = 'p_erp_owner'))
     and not pg_temp.expect_fail('select core.fn_assert_rls_everywhere()'), 'all ' || tables || ' project tables: RLS enabled + FORCED + owner policy');
  insert into _r values ('S08-09', not exists (select 1 from pg_policy p join pg_class c on c.oid = p.polrelid join pg_namespace s on s.oid = c.relnamespace
                                                join pg_roles r on r.oid = any (p.polroles)
                                               where s.nspname in ('core','iam','config', 'design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify', 'location', 'hardware','api','svc')
                                                 and r.rolname <> 'erp_owner'), 'no policy exists for any role other than erp_owner');

  insert into core.company (code, name_bn, status) values ('RA', 'ক', 'active') returning id into ca;
  insert into core.company (code, name_bn, status) values ('RB', 'খ', 'active') returning id into cb;
  insert into core.wing (company_id, code, name_bn) values (ca, 'WA', 'ক') returning id into wa;
  insert into core.wing (company_id, code, name_bn) values (cb, 'WB', 'খ') returning id into wb;
  p1 := svc.v1_iam_provision_person('এক', null, null, u1, 't'); p2 := svc.v1_iam_provision_person('দুই', null, null, u2, 't');
  a1 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p1, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  a2 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p2, cb, null, 't'), 'MD', null, null, null, null, null, 't');
  perform svc.v1_iam_add_membership(p1, cb, null, 't');

  perform pg_temp.as_user(u1, 's1');
  perform api.v1_iam_select_position(a1);                       -- pins to company A
  select count(*) into n from core.wing where id in (wa, wb);
  select count(*) into m from core.company where id in (ca, cb);
  insert into _r values ('S08-03', n = 1 and m = 1 and core.fn_pinned_company() = ca
                                   and (select count(*) from audit.event where company_id = cb) = 0
                                   and (select count(*) from iam.position_assignment where id = a2) = 0, 'after context resolution the request sees only its company');
  insert into _r values ('S08-04', pg_temp.expect_fail(format($f$insert into core.wing (company_id, code, name_bn) values (%L,'XX','x')$f$, cb))
                                   and pg_temp.expect_fail(format($f$insert into core.department (company_id, wing_id, code, name_bn) values (%L,%L,'X','x')$f$, cb, wb)),
                                   'pinned request cannot write into another company');
  update core.wing set name_bn = 'হ্যাক' where id = wb;
  get diagnostics n = row_count;
  insert into _r values ('S08-10', n = 0, 'pinned request updates 0 rows of another company');
  insert into _r values ('S08-06', (select count(*) from iam.permission_catalog) >= 118 and (select count(*) from core.person where id in (p1, p2)) = 2,
                                   'global vocabulary/identity tables stay readable when pinned');

  j := api.v1_iam_whoami();                                     -- a new request: unpinned at entry
  insert into _r values ('S08-05', core.fn_pinned_company() is null and jsonb_array_length(j -> 'memberships') = 2, 'next request starts unpinned (sees both own memberships)');

  perform pg_temp.as_user(u2, 's2');
  perform api.v1_iam_select_position(a2);
  insert into _r values ('S08-11', core.fn_pinned_company() = cb and (select count(*) from core.wing where id = wa) = 0, 're-pinning follows the new context');

  insert into _r values ('S08-07', (select prosrc like '%MOHONA_SECURITY_DENIED%' from pg_proc where oid = 'iam.fn_require(text, iam.resource, boolean)'::regprocedure),
                                   'denials are written to the server log before raising');

  perform set_config('mohona.company_scope', '', true);
  create table core.tmp_s08 (id uuid primary key, company_id uuid);
  insert into _r values ('S08-08', pg_temp.expect_fail('select core.fn_assert_rls_everywhere()', 'E_RLS_MISSING'), 'a new table without RLS is detected');
  perform core.fn_apply_rls('core', 'tmp_s08');
  insert into _r values ('S08-08', not pg_temp.expect_fail('select core.fn_assert_rls_everywhere()'), 'fn_apply_rls fixes it');
  drop table core.tmp_s08;
  perform set_config('request.jwt.claims', '', true);
end $$;
-- An accidental table GRANT (and schema USAGE) to an API role still exposes nothing (forced RLS, no policy for that role).
grant usage on schema core to authenticated;
grant select on core.company to authenticated;
set local role authenticated;
select set_config('mohona.t_s08_02', (select count(*) from core.company)::text, true);
reset role;
set local role erp_owner;
revoke select on core.company from authenticated;
revoke usage on schema core from authenticated;
insert into _r values ('S08-02', current_setting('mohona.t_s08_02') = '0', 'even with a mistaken GRANT, authenticated sees 0 rows (forced RLS, no policy)');
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S36–S39 tests: postings queue until the CoA is approved (business never blocked), CoA review/approval roles, missing
-- mapping blocks posting, balanced maker-checker journals, immutability, idempotent posting keys, reversal, back-dating
-- and closed periods, procurement GRNI/AP/bank postings, consumption, cash vouchers + drawer count, bank import +
-- reconciliation, factory P&L access + export log, balanced trial balance.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_ac uuid; a_fm uuid; a_md uuid; a_sk uuid; p_ch uuid; p_ac uuid; p_fm uuid; p_md uuid; p_sk uuid;
        u_ch uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        wh uuid; flour uuid; coa uuid; jn uuid; jr jsonb; sup uuid; po uuid; pl uuid; grn jsonb; bill jsonb; pay jsonb; cash uuid; bank uuid; j jsonb; j1 jsonb; r uuid; mapping_acc uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('FIN', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  -- these tests exercise maker-checker with MD / finance approvers; the Chairman-only rule (Prime v180) has its own test (t_s56)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_config_set('approval.financial.chairman_only', 'false'::jsonb, 0, 'legacy maker-checker test');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  wh := (api.v1_structure_save_warehouse(null, null, null, 'RM', 'কাঁচামাল', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  flour := (api.v1_product_propose(null, 'FLOUR', 'ময়দা', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(flour, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(wh, flour, 'L1', null, null, current_date + 60, 100, 0, 0, 40, false, 'opening');
  insert into _r values ('S36-01', (select qty from inventory.stock_balance where warehouse_id = wh and product_id = flour) = 100
                                   and exists (select 1 from finance.gl_event e where e.company_id = ca and e.status = 'error' and e.error like 'E_COA_NOT_APPROVED%'),
                                   'stock moves even before finance is set up; the posting waits with its reason');
  -- ---------------------------------------------------------------- chart of accounts (F111, ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('first chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S36-02', pg_temp.expect_fail(format($f$select api.v1_coa_approve(%L, 'x')$f$, coa), 'E_INVALID_ACTION'), 'no approval without the accountant''s review');
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'reviewed by accountant');
  perform pg_temp.as_user(u_fm, 'fm');
  insert into _r values ('S36-03', pg_temp.expect_fail(format($f$select api.v1_coa_approve(%L, 'x')$f$, coa), 'E_FORBIDDEN'), 'only the Chairman approves the chart');
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_coa_approve(coa, 'approved');
  insert into _r values ('S36-04', (j ->> 'events_retried')::integer >= 1 and pg_temp.bal(ca, '1200') = 4000 and pg_temp.bal(ca, '3100') = -4000
                                   and not exists (select 1 from finance.gl_event e where e.company_id = ca and e.status <> 'posted'),
                                   'approval applies accounts + mappings and posts the queued events');
  -- missing mapping blocks posting
  mapping_acc := (select account_id from finance.gl_mapping where company_id = ca and event_key = 'inv.waste_normal');
  delete from finance.gl_mapping where company_id = ca and event_key = 'inv.waste_normal';
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_wastage_submit(wh, 'normal', jsonb_build_array(jsonb_build_object('product_id', flour, 'qty', 5)), 'spill');
  insert into _r values ('S36-05', exists (select 1 from finance.gl_event e where e.company_id = ca and e.status = 'error' and e.error like 'E_GL_MAPPING_MISSING%')
                                   and (select qty from inventory.stock_balance where warehouse_id = wh and product_id = flour) = 95,
                                   'a missing mapping blocks the posting, never the business document');
  insert into finance.gl_mapping (company_id, event_key, account_id, coa_version) values (ca, 'inv.waste_normal', mapping_acc, 1);
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_gl_events_retry();
  -- ---------------------------------------------------------------- manual journals (F112–F115)
  perform pg_temp.as_user(u_ac, 'ac');
  jn := (api.v1_journal_save(null, current_date, 'office expense', '[{"account_code":"5500","debit":1000},{"account_code":"1100","credit":900}]') ->> 'journal_id')::uuid;
  insert into _r values ('S36-06', pg_temp.expect_fail(format($f$select api.v1_journal_submit(%L)$f$, jn), 'E_JOURNAL_UNBALANCED')
                                   and pg_temp.expect_fail($q$select api.v1_journal_save(null, current_date - 30, 'old', '[{"account_code":"5500","debit":1},{"account_code":"1100","credit":1}]')$q$, 'E_BACKDATE'),
                                   'unbalanced journals never post; normal back-dating is limited');
  perform api.v1_journal_save(jn, current_date, 'office expense', '[{"account_code":"5500","debit":1000},{"account_code":"1100","credit":1000}]');
  perform api.v1_journal_submit(jn);
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_journal_save(null, current_date, 'chairman entry', '[{"account_code":"5500","debit":10},{"account_code":"1100","credit":10}]');
  perform api.v1_journal_submit((j ->> 'journal_id')::uuid);
  r := (select approval_request_id from finance.journal where id = (j ->> 'journal_id')::uuid);
  insert into _r values ('S36-07', pg_temp.expect_fail(format($f$select api.v1_approval_decide(%L, 'approve', %s, 'mine')$f$, r, (select row_version from core.approval_request where id = r)), 'E_SELF_APPROVAL'),
                                   'the submitter never approves the own journal — not even the Chairman');
  r := (select approval_request_id from finance.journal where id = jn);
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok');
  insert into _r values ('S36-08', (select status from finance.journal where id = jn) = 'posted' and pg_temp.bal(ca, '5500') = 1000
                                   and pg_temp.expect_fail(format($f$update finance.journal set memo = 'x' where id = %L$f$, jn), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$update finance.journal_line set debit = 1 where journal_id = %L$f$, jn), 'E_IMMUTABLE'),
                                   'approved journal posts and is never edited');
  perform finance.fn_emit(ca, 'test:dup', 'x', '[{"key":"inv.adjust_loss","dr":10},{"key":"inv.raw","cr":10}]');
  perform finance.fn_emit(ca, 'test:dup', 'x', '[{"key":"inv.adjust_loss","dr":10},{"key":"inv.raw","cr":10}]');
  insert into _r values ('S36-09', (select count(*) from finance.journal where company_id = ca and posting_key = 'test:dup') = 1, 'one posting per key');
  perform pg_temp.as_user(u_fm, 'fm');
  jr := api.v1_journal_reverse(jn, current_date, 'wrong account');
  insert into _r values ('S36-10', (select status from finance.journal where id = jn) = 'reversed' and pg_temp.bal(ca, '5500') = 0
                                   and (select reversal_of from finance.journal where id = (jr ->> 'reversal_id')::uuid) = jn
                                   and pg_temp.expect_fail(format($f$select api.v1_journal_reverse(%L, current_date, 'again')$f$, jn), 'E_INVALID_ACTION'),
                                   'reversal references the original with swapped lines, once');
  -- ---------------------------------------------------------------- periods (F116)
  perform api.v1_period_close((date_trunc('month', current_date) - interval '1 month')::date, 'month end');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S36-11', pg_temp.expect_fail($q$select api.v1_journal_save(null, (date_trunc('month', current_date) - interval '1 day')::date, 'late', '[{"account_code":"5500","debit":1},{"account_code":"1100","credit":1}]')$q$)
                                   and pg_temp.expect_fail($q$select api.v1_period_close(current_date, 'x')$q$, 'E_FORBIDDEN'),
                                   'no posting into a closed month; closing needs its right');
  -- ---------------------------------------------------------------- procurement + consumption postings (OI-41)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('approval.maker_checker.enabled', 'false'::jsonb, 0, 'small test company');
  sup := (api.v1_supplier_save(null, 'S1', 'সাপ্লায়ার', null, '01711000999', null, null, null, null, 30, null, null, null, null, 'x') ->> 'supplier_id')::uuid;
  po := (api.v1_po_create(sup, wh, null, null, null, jsonb_build_array(jsonb_build_object('product_id', flour, 'qty', 100, 'unit_price', 50)), 'x') ->> 'po_id')::uuid;
  perform api.v1_po_action(po, 'submit', (select row_version from procurement.po x_ where x_.id = po), 'x');
  pl := (select id from procurement.po_line where po_id = po);
  grn := api.v1_grn_post(po, null, format('[{"po_line_id":"%s","lot_no":"G1","received":100}]', pl)::jsonb, 'x');
  j := jsonb_build_object('grni', pg_temp.bal(ca, '2110'));
  bill := api.v1_bill_create(sup, 'B-1', current_date, jsonb_build_array(jsonb_build_object('grn_line_id', (select id from procurement.grn_line where grn_id = (grn ->> 'grn_id')::uuid), 'qty', 100, 'unit_price', 50)), 'x');
  pay := api.v1_supplier_payment(sup, 'bank', 'TXN-9', jsonb_build_array(jsonb_build_object('bill_id', bill ->> 'bill_id', 'amount', 5000)), 'x');
  insert into _r values ('S36-12', (j ->> 'grni')::numeric = -5000 and pg_temp.bal(ca, '2110') = 0 and pg_temp.bal(ca, '2100') = 0 and pg_temp.bal(ca, '1110') = -5000
                                   and pg_temp.bal(ca, '1200') = 4000 - 200 + 5000 - 10,
                                   'GRN → Dr inventory / Cr GRNI; bill clears GRNI into AP; payment clears AP from the bank');
  -- ---------------------------------------------------------------- cash (F117) + bank (F118)
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac');
  j := api.v1_cash_voucher(cash, 'receipt', 5000, '3200', 'owner cash');
  j1 := api.v1_cash_count(cash, 4800, 'evening count');
  insert into _r values ('S36-13', j ->> 'status' = 'posted' and pg_temp.bal(ca, '1100') = 5000
                                   and pg_temp.expect_fail(format($f$select api.v1_cash_voucher(%L, 'payment', 10000, '5500', 'too much')$f$, cash), 'E_INSUFFICIENT_CASH')
                                   and (j1 ->> 'difference')::numeric = -200,
                                   'cash vouchers post through approval; a drawer count records the difference');
  perform api.v1_bank_statement_import(bank, jsonb_build_array(jsonb_build_object('date', current_date, 'amount', -5000, 'reference', 'TXN-9', 'description', 'supplier')));
  insert into _r values ('S36-14', pg_temp.expect_fail(format($f$select api.v1_bank_statement_import(%L, '[{"date":"%s","amount":-5000,"reference":"TXN-9"}]')$f$, bank, current_date), 'E_DUPLICATE_BANK_REF')
                                   and (api.v1_bank_reconcile((select id from finance.bank_statement_line where bank_account_id = bank),
                                         (select l.id from finance.journal_line l join finance.journal jj on jj.id = l.journal_id where jj.posting_key = 'payment:' || (pay ->> 'payment_id') and l.credit = 5000)) ->> 'matched')::boolean,
                                   'no duplicate bank reference; statement lines match posted bank lines');
  -- ---------------------------------------------------------------- factory P&L (F119) + trial balance
  insert into _r values ('S36-15', pg_temp.expect_fail($q$select api.v1_factory_pnl(null, null, null)$q$, 'E_FORBIDDEN'), 'accountants do not see factory P&L');
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_factory_pnl(null, null, null);
  perform api.v1_factory_pnl_export(null, null, null);
  j1 := api.v1_trial_balance(null);
  insert into _r values ('S36-16', j ? 'margin' and (select count(*) from finance.export_log where company_id = ca and report = 'factory_pnl') = 1
                                   and (j1 ->> 'debit')::numeric = (j1 ->> 'credit')::numeric and (j1 ->> 'debit')::numeric > 0,
                                   'MD sees and exports factory P&L (logged); the trial balance balances');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

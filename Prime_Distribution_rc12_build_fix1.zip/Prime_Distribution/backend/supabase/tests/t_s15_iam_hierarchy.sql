-- S15 tests: permission dependencies, SoD (grant-time + report), access preview, permission audit, multi-company,
-- reporting chain, hiring checklist (no login before approval), promotion / transfer / scheduler / approval,
-- suspension, termination, substitution, hierarchy preview with salary masking.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.can(p_perm text, r iam.resource) returns boolean language sql as $$ select allowed from iam.fn_authorize(p_perm, r, false) $$;
create or replace function pg_temp.emp(p_membership uuid) returns uuid language sql as $$ select id from hr.employee where membership_id = p_membership $$;
do $$
declare boot jsonb; ca uuid; cb uuid; w1 uuid; a_ch uuid; a_md uuid; a_a uuid; a_b uuid; a_ch2 uuid; a_a2 uuid; a_n uuid;
        m_md uuid; m_a uuid; m_b uuid; m_n uuid; p_ch uuid; p_md uuid; p_a uuid; p_b uuid; p_ch2 uuid; p_n uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_a uuid := gen_random_uuid(); u_b uuid := gen_random_uuid();
        u_ch2 uuid := gen_random_uuid(); u_n uuid := gen_random_uuid();
        j jsonb; j1 jsonb; j2 jsonb; rid uuid; ob uuid; v_rv integer; req uuid; sub uuid; chg uuid;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('HRC', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  p_a := svc.v1_iam_provision_person('হিসাব', null, null, u_a, 't');
  p_b := svc.v1_iam_provision_person('মাঠ', null, null, u_b, 't');
  m_md := svc.v1_iam_add_membership(p_md, ca, null, 't'); a_md := svc.v1_iam_assign_position(m_md, 'MD', null, null, null, null, null, 't');
  m_a := svc.v1_iam_add_membership(p_a, ca, null, 't');   a_a := svc.v1_iam_assign_position(m_a, 'ACCOUNTANT', null, null, null, null, null, 't');
  m_b := svc.v1_iam_add_membership(p_b, ca, null, 't');   a_b := svc.v1_iam_assign_position(m_b, 'FIELD_SALES', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('HRX', 'খ', p_ch2, 't'); cb := (boot ->> 'company_id')::uuid; a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  -- ---------------------------------------------------------------- dependencies (F024)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  insert into _r values ('S15-01', exists (select 1 from iam.permission_dependency where permission_code = 'config.rule.manage' and requires_code = 'config.rule.read')
                                   and not exists (select 1 from iam.permission_dependency where permission_code = 'audit.verify')
                                   and pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','config.rule.manage','allow','COMPANY',null,'x')$q$, 'E_PERMISSION_DEPENDENCY'),
                                   'a child capability cannot be granted without its parent');
  rid := api.v1_iam_set_position_rule('ACCOUNTANT', 'config.rule.read', 'allow', 'COMPANY', null, 'reads rules');
  perform api.v1_iam_set_position_rule('ACCOUNTANT', 'config.rule.manage', 'allow', 'COMPANY', null, 'designs rules');
  insert into _r values ('S15-02', pg_temp.expect_fail(format($f$select api.v1_iam_revoke_position_rule(%L, 'x')$f$, rid), 'E_PERMISSION_DEPENDENCY')
                                   and (select count(*) from iam.position_permission_rule where company_id = ca and position_code = 'ACCOUNTANT'
                                         and permission_code = 'config.rule.manage' and status = 'active') = 1,
                                   'parent cannot be revoked while a child depends on it (no orphans)');
  -- ---------------------------------------------------------------- SoD (F025)
  perform set_config('mohona.company_scope', '', true);          -- read both companies (test only)
  insert into _r values ('S15-03', (select count(*) from iam.sod_rule where company_id = ca and status = 'active' and mode = 'block') >= 5
                                   and (select count(*) from iam.sod_rule where company_id = cb and status = 'active') >= 5,
                                   'every company starts with the default SoD pairs');
  perform api.v1_iam_sod_set('forms.submission.export', 'forms.form.manage', 'block', 'exporter must not design forms');
  perform api.v1_iam_set_position_rule('ACCOUNTANT', 'forms.submission.export', 'allow', 'COMPANY', null, 'exports');
  insert into _r values ('S15-04', pg_temp.expect_fail($q$select api.v1_iam_set_position_rule('ACCOUNTANT','forms.form.manage','allow','COMPANY',null,'x')$q$, 'E_SOD_CONFLICT')
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_set_assignment_rule(%L,'forms.form.manage','allow','COMPANY',null,null,'x')$f$, a_a), 'E_SOD_CONFLICT'),
                                   'blocked SoD pair is refused at position and personal level');
  perform api.v1_iam_sod_set('forms.submission.void', 'forms.submission.export', 'warn', 'watch MD');
  j := api.v1_iam_sod_report();
  insert into _r values ('S15-05', exists (select 1 from jsonb_array_elements(j) x where (x ->> 'assignment_id')::uuid = a_md and x ->> 'mode' = 'warn'),
                                   'live SoD report shows holders of both sides');
  -- ---------------------------------------------------------------- access preview (F023)
  j := api.v1_iam_access_preview(a_md, null);
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S15-06', (j -> 'permissions') @> '[{"code":"forms.submission.export"}]' and not ((j -> 'permissions') @> '[{"code":"iam.sod.manage"}]')
                                   and (j -> 'sod_conflicts') @> '[{"mode":"warn"}]'
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_access_preview(%L, null)$f$, a_ch), 'E_RANK_TOO_HIGH')
                                   and jsonb_array_length(api.v1_iam_access_preview(a_a, null) -> 'permissions') > 0,
                                   'effective privileges simulated; nobody previews a higher position');
  -- ---------------------------------------------------------------- permission audit (F030)
  j := api.v1_iam_permission_audit(null, 500);
  insert into _r values ('S15-07', exists (select 1 from jsonb_array_elements(j) x where x ->> 'permission_code' = 'config.rule.manage' and x ->> 'reason' = 'designs rules'
                                                                                   and (x ->> 'actor_person_id')::uuid = p_ch)
                                   and exists (select 1 from jsonb_array_elements(j) x where x ->> 'table' = 'iam.sod_rule'),
                                   'who granted what, when and why');
  -- ---------------------------------------------------------------- multi-company (F028)
  perform pg_temp.as_user(u_ch2, 'ch2');
  insert into _r values ('S15-08', pg_temp.expect_fail(format($f$select api.v1_iam_select_position(%L)$f$, a_ch))
                                   and (select api.v1_iam_select_position(a_ch2)) is not null
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_access_preview(%L, null)$f$, a_md), 'E_NOT_FOUND')
                                   and not pg_temp.can('core.structure.read', iam.fn_resource(ca)),
                                   'a Chairman in one company is nobody in another');
  -- ---------------------------------------------------------------- reporting chain (F032)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_hr_set_manager(pg_temp.emp(m_a), pg_temp.emp(m_md), 'accounts report to MD');
  perform api.v1_hr_set_manager(pg_temp.emp(m_b), pg_temp.emp(m_a), 'field reports to accounts');
  insert into _r values ('S15-09', pg_temp.expect_fail(format($f$select api.v1_hr_set_manager(%L, %L, 'x')$f$, pg_temp.emp(m_md), pg_temp.emp(m_b)), 'E_REPORTING_CYCLE')
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_set_manager(%L, %L, 'x')$f$, pg_temp.emp(m_a), pg_temp.emp(m_a)), 'E_REPORTING_CYCLE')
                                   and (select count(*) from hr.reporting_line where company_id = ca and status = 'active') = 2,
                                   'management cycles are refused');
  -- ---------------------------------------------------------------- substitution (F039)
  j := api.v1_hr_substitute(a_md, a_b, array['forms.submission.read'], 'COMPANY', null, null, clock_timestamp() + interval '3 days',
                            'এমডির ছুটিতে ফর্ম পর্যালোচনা', 'MD on leave');
  sub := (j ->> 'substitution_id')::uuid;
  perform pg_temp.as_user(u_b, 'b'); perform api.v1_iam_select_position(a_b);
  j1 := jsonb_build_object('during', pg_temp.can('forms.submission.read', iam.fn_resource(ca, null, null, null, null, p_md)));
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S15-10', (j1 ->> 'during')::boolean
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_substitute(%L,%L,array['forms.submission.read'],'COMPANY',null,null,clock_timestamp()+interval '40 days','duty x','x')$f$, a_md, a_b), 'E_DELEGATION_TOO_LONG')
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_substitute(%L,%L,array['iam.sod.manage'],'COMPANY',null,null,clock_timestamp()+interval '1 day','duty x','x')$f$, a_md, a_b))
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_substitute(%L,%L,array['forms.submission.read'],'COMPANY',null,null,clock_timestamp()+interval '1 day','','x')$f$, a_md, a_b), 'E_DELEGATION_INVALID'),
                                   'acting holder for a bounded window and a written duty, only rights the absent holder has');
  perform api.v1_hr_end_substitution(sub, 'MD back');
  perform pg_temp.as_user(u_b, 'b');
  insert into _r values ('S15-11', not pg_temp.can('forms.submission.read', iam.fn_resource(ca, null, null, null, null, p_md)), 'ending a substitution removes the right at once');
  -- ---------------------------------------------------------------- hiring checklist (F033)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_hr_onboarding_template_set('STOREKEEPER', '[{"key":"documents","title_bn":"কাগজ","required":true},{"key":"training","title_bn":"প্রশিক্ষণ","required":true},{"key":"tour","title_bn":"পরিদর্শন","required":false}]', 'store hiring');
  j := api.v1_hr_hire('নতুন কর্মী', '01800000001', null, 'E-100', 'STOREKEEPER', w1, null, null, 'new storekeeper');
  m_n := (j ->> 'membership_id')::uuid; a_n := (j ->> 'assignment_id')::uuid; ob := (j ->> 'onboarding_id')::uuid; p_n := (j ->> 'person_id')::uuid;
  perform svc.v1_iam_relink_login(p_n, u_n, 'first login');
  perform pg_temp.as_user(u_n, 'n');
  insert into _r values ('S15-12', jsonb_array_length(j -> 'tasks') = 3
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_select_position(%L)$f$, a_n)),
                                   'no active login before the checklist is approved');
  perform pg_temp.as_user(u_ch, 'ch');
  v_rv := (select row_version from hr.onboarding where id = ob);
  perform api.v1_hr_onboarding_task(ob, 'documents', true, v_rv);
  v_rv := (select row_version from hr.onboarding where id = ob);
  insert into _r values ('S15-13', pg_temp.expect_fail(format($f$select api.v1_hr_onboarding_decide(%L,'approve',%s,'ok')$f$, ob, v_rv), 'E_ONBOARDING_INCOMPLETE'),
                                   'required tasks must be done');
  perform api.v1_hr_onboarding_task(ob, 'training', true, v_rv);
  perform api.v1_hr_onboarding_decide(ob, 'approve', (select row_version from hr.onboarding where id = ob), 'ready');
  perform pg_temp.as_user(u_n, 'n');
  insert into _r values ('S15-14', (select api.v1_iam_select_position(a_n)) is not null, 'approval opens the login');
  -- ---------------------------------------------------------------- promotion + salary masking (F034, F040, F029)
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_hr_employment_change('promotion', a_a, 'FIN_MANAGER', null, null, null, 'G5', 50000, null, 'excellent year');
  a_a2 := (j ->> 'new_assignment_id')::uuid;
  j1 := api.v1_hr_org_tree();
  perform api.v1_iam_set_position_rule('FIN_MANAGER', 'iam.hierarchy.read', 'allow', 'COMPANY', null, 'finance sees the org chart');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S15-15', j ->> 'status' = 'applied' and (select status from iam.position_assignment where id = a_a) = 'ended'
                                   and (select position_code from iam.position_assignment where id = a_a2) = 'FIN_MANAGER'
                                   and pg_temp.expect_fail(format($f$select api.v1_iam_select_position(%L)$f$, a_a))
                                   and (select count(*) from iam.position_assignment where membership_id = m_a) = 2
                                   and not exists (select 1 from audit.event e where e.entity_table = 'hr.employment_change' and e.detail::text like '%50000%'),
                                   'promotion ends the old assignment and creates a new one; history kept; pay never audited in clear');
  perform api.v1_iam_select_position(a_a2);
  j2 := api.v1_hr_employment_history(m_a);
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_hr_org_tree();
  insert into _r values ('S15-16', exists (select 1 from jsonb_array_elements(j1) p, jsonb_array_elements(p -> 'holders') h
                                            where (h ->> 'assignment_id')::uuid = a_a2 and (h ->> 'salary')::numeric = 50000)
                                   and exists (select 1 from jsonb_array_elements(j) p, jsonb_array_elements(p -> 'holders') h
                                                where (h ->> 'assignment_id')::uuid = a_a2 and h ->> 'salary' = '••••••' and h -> 'grade' = 'null'::jsonb)
                                   and (j2 -> 'changes' -> 0 ->> 'salary')::numeric = 50000 and jsonb_array_length(j2 -> 'assignments') = 2,
                                   'salary: Chairman and the employee see it, others see it masked');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_mask_set_policy('hr.employment.salary', 'MD', 'mask', 0, 'MD sees salaries masked');
  perform api.v1_iam_set_position_rule('MD', 'iam.salary.read', 'allow', 'COMPANY', null, 'MD reviews pay');
  perform pg_temp.as_user(u_md, 'md');
  j := api.v1_hr_org_tree();
  insert into _r values ('S15-17', exists (select 1 from jsonb_array_elements(j) p, jsonb_array_elements(p -> 'holders') h
                                            where (h ->> 'assignment_id')::uuid = a_a2 and h -> 'salary' = '"••••••"'::jsonb and h ->> 'grade' = 'G5'),
                                   'pay permission + mask policy: grade visible, salary still masked by policy');
  -- ---------------------------------------------------------------- transfer, scheduler, cancel (F035)
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_hr_employment_change('transfer', a_b, null, w1, null, null, null, null, current_date + 5, 'to wing 1 next week');
  chg := (j ->> 'change_id')::uuid;
  j1 := svc.v1_hr_apply_due_changes();
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_hr_change_cancel(chg, 'plan changed');
  j2 := api.v1_hr_employment_change('transfer', a_b, null, w1, null, null, null, null, null, 'to wing 1 now');
  insert into _r values ('S15-18', j ->> 'status' = 'scheduled' and (j1 ->> 'applied')::integer = 0 and (select status from hr.employment_change where id = chg) = 'cancelled'
                                   and (select home_wing_id from iam.position_assignment where id = (j2 ->> 'new_assignment_id')::uuid) = w1
                                   and (select status from iam.position_assignment where id = a_b) = 'ended'
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_employment_change('transfer',%L,'MD',%L,null,null,null,null,null,'x')$f$, (j2 ->> 'new_assignment_id')::uuid, w1), 'E_INVALID_ACTION'),
                                   'effective-dated transfer: future ones wait for the scheduler and can be cancelled');
  a_b := (j2 ->> 'new_assignment_id')::uuid;
  insert into hr.employment_change (company_id, membership_id, assignment_id, kind, grade, effective_on, reason, created_by)
  values (ca, m_b, a_b, 'promotion', 'F2', current_date, 'due today (scheduler test)', p_ch) returning id into chg;
  j1 := svc.v1_hr_apply_due_changes();
  insert into _r values ('S15-19', (j1 ->> 'applied')::integer >= 1 and (select status from hr.employment_change where id = chg) = 'applied'
                                   and pg_temp.expect_fail(format($f$update hr.employment_change set reason = 'edited' where id = %L$f$, chg), 'E_IMMUTABLE'),
                                   'scheduler applies due changes; changes are never edited');
  -- ---------------------------------------------------------------- suspension through approval (F036) + reinstatement
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('hr.employment_change.requires_approval', 'true'::jsonb, 0, 'board control');
  j := api.v1_hr_employment_change('suspension', a_b, null, null, null, null, null, null, null, 'inquiry');
  req := (j ->> 'request_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_approval_decide(req, 'approve', (select row_version from core.approval_request where id = req), 'agreed');
  perform pg_temp.as_user(u_b, 'b');
  perform pg_temp.expect_fail(format($f$select api.v1_iam_select_position(%L)$f$, a_b));
  insert into _r values ('S15-20', j ->> 'status' = 'pending_approval'
                                   and (select em.status from hr.employment em where em.employee_id = pg_temp.emp(m_b)) = 'suspended'
                                   and pg_temp.expect_fail($q$select api.v1_iam_current_context()$q$),
                                   'approved suspension restricts the person at once');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('hr.employment_change.requires_approval', 'false'::jsonb, 1, 'back');
  perform api.v1_hr_employment_change('reinstatement', a_b, null, null, null, null, null, null, null, 'inquiry closed');
  perform pg_temp.as_user(u_b, 'b');
  perform api.v1_iam_select_position(a_b);
  insert into _r values ('S15-21', (select api.v1_iam_current_context()) is not null, 'reinstatement restores access');
  -- ---------------------------------------------------------------- rank guard + termination (F037)
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S15-22', pg_temp.expect_fail(format($f$select api.v1_hr_employment_change('promotion',%L,'CHAIRMAN',null,null,null,null,null,null,'x')$f$, a_a2))
                                   and pg_temp.expect_fail(format($f$select api.v1_hr_employment_change('termination',%L,null,null,null,null,null,null,null,'x')$f$, a_ch)),
                                   'no one is promoted to or acts on the Chairman seat; changes need the change permission');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_hr_employment_change('termination', a_a2, null, null, null, null, null, null, null, 'resigned');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S15-23', pg_temp.expect_fail($q$select api.v1_iam_current_context()$q$)
                                   and (select status from iam.company_membership where id = m_a) = 'ended'
                                   and (select status from hr.employment where employee_id = pg_temp.emp(m_a)) = 'terminated'
                                   and (select count(*) from iam.position_assignment where membership_id = m_a) = 2
                                   and not exists (select 1 from hr.reporting_line where status = 'active' and pg_temp.emp(m_a) in (employee_id, manager_employee_id)),
                                   'termination: access gone, employment history and assignments retained, reporting lines closed');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

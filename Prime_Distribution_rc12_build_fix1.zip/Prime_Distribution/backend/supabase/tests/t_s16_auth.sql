-- S16 tests: phone canonicalisation, invitation-only OTP, invitation claim, PIN policy/enrolment, generic PIN failures,
-- lockout + unlock, no secrets logged, PIN-session liveness (aal, device revoke, sign-out), refresh rotation + reuse
-- detection, PIN change / OTP reset, Chairman MFA guard, company selector, login audit, termination.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
-- a login with explicit phone / amr (p_otp_age = seconds since the OTP, null = no OTP in this token)
create or replace function pg_temp.as_login(p uuid, p_session text, p_aal text, p_phone text, p_otp_age integer, p_method text default 'otp') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal, 'phone', p_phone,
        'amr', case when p_otp_age is null then '[]'::jsonb
                    else jsonb_build_array(jsonb_build_object('method', p_method, 'timestamp', floor(extract(epoch from clock_timestamp())) - p_otp_age)) end)::text, true); end $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; p_ch uuid; p_a uuid; m_a uuid; a_a uuid; inv jsonb;
        u_ch uuid := gen_random_uuid(); u_a uuid := gen_random_uuid(); u_x uuid := gen_random_uuid();
        j jsonb; j1 jsonb; j2 jsonb; s1 jsonb; s2 jsonb; s3 jsonb; v_dev uuid; i integer;
        dev1 text := 'device-aaaaaaaaaaaaaaaa'; dev2 text := 'device-bbbbbbbbbbbbbbbb';
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('AUT', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;

  insert into _r values ('S16-01', core.fn_phone_canonical('01711111111') = '+8801711111111' and core.fn_phone_canonical('+880 1711-111111') = '+8801711111111'
                                   and core.fn_phone_canonical('8801711111111') = '+8801711111111' and core.fn_phone_canonical('abc') is null,
                                   'one canonical form for every way a number is typed');
  -- ---------------------------------------------------------------- invitation (F201 / OI-12)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_iam_add_member('হিসাবরক্ষক', '01711111111', null, 'E-1', 'new accountant');
  p_a := (j ->> 'person_id')::uuid; m_a := (j ->> 'membership_id')::uuid;
  a_a := api.v1_iam_assign_position(m_a, 'ACCOUNTANT', null, null, 'regular', null, null, null, 'role');
  inv := api.v1_auth_invite(m_a, 'login for new accountant');
  insert into _r values ('S16-02', (svc.v1_auth_otp_allowed('+880 1711 111111') ->> 'allowed')::boolean
                                   and not (svc.v1_auth_otp_allowed('01999999999') ->> 'allowed')::boolean,
                                   'OTP only for invited or linked numbers (self sign-up closed)');
  perform pg_temp.as_login(u_a, gen_random_uuid()::text, 'aal1', '8801711111111', 3600);
  j1 := jsonb_build_object('stale', pg_temp.expect_fail('select api.v1_auth_claim_invitation()', 'E_OTP_REQUIRED'));
  perform pg_temp.as_login(u_x, gen_random_uuid()::text, 'aal1', '8801999999999', 30);
  j1 := j1 || jsonb_build_object('stranger', pg_temp.expect_fail('select api.v1_auth_claim_invitation()', 'E_NOT_INVITED'));
  perform pg_temp.as_login(u_a, gen_random_uuid()::text, 'aal1', '8801711111111', 30);
  j := api.v1_auth_claim_invitation();
  insert into _r values ('S16-03', (j1 ->> 'stale')::boolean and (j1 ->> 'stranger')::boolean and (j ->> 'person_id')::uuid = p_a and (j ->> 'needs_pin')::boolean
                                   and exists (select 1 from iam.person_auth_link where person_id = p_a and auth_user_id = u_a and status = 'active')
                                   and (select status from iam.login_invitation where id = (inv ->> 'invitation_id')::uuid) = 'claimed',
                                   'a fresh OTP on the invited number links the login');
  -- ---------------------------------------------------------------- PIN enrolment (F202)
  insert into _r values ('S16-04', pg_temp.expect_fail($q$select api.v1_auth_set_pin('123456')$q$, 'E_PIN_WEAK')
                                   and pg_temp.expect_fail($q$select api.v1_auth_set_pin('111111')$q$, 'E_PIN_WEAK')
                                   and pg_temp.expect_fail($q$select api.v1_auth_set_pin('987654')$q$, 'E_PIN_WEAK')
                                   and pg_temp.expect_fail($q$select api.v1_auth_set_pin('12a456')$q$, 'E_PIN_WEAK')
                                   and pg_temp.expect_fail($q$select api.v1_auth_set_pin('4826')$q$, 'E_PIN_WEAK'),
                                   'PIN policy: digits, length, no repeats or sequences');
  perform api.v1_auth_set_pin('482913');
  perform pg_temp.as_login(u_a, gen_random_uuid()::text, 'aal1', '8801711111111', null);
  insert into _r values ('S16-05', (select pin_hash like '$2%' and pin_hash not like '%482913%' from iam.login_pin where person_id = p_a)
                                   and pg_temp.expect_fail($q$select api.v1_auth_set_pin('573920')$q$, 'E_OTP_REQUIRED'),
                                   'bcrypt verifier only; changing the PIN this way needs a fresh OTP');
  -- ---------------------------------------------------------------- PIN login: generic failures, lockout (F203 / F210)
  s1 := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  j1 := svc.v1_auth_pin_verify('01711111111', '000111', dev1, 'ফোন', 'android');
  j2 := svc.v1_auth_pin_verify('01999999999', '482913', dev1, 'ফোন', 'android');
  insert into _r values ('S16-06', (s1 ->> 'ok')::boolean and (s1 ->> 'session_id') is not null and length(s1 ->> 'refresh_token') = 64
                                   and j1 = '{"ok":false,"error":"E_AUTH_FAILED"}'::jsonb and j2 = j1,
                                   'success returns a session; a wrong PIN and an unknown number look identical');
  for i in 1..4 loop j := svc.v1_auth_pin_verify('01711111111', '000111', dev1, 'ফোন', 'android'); end loop;
  j1 := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_auth_unlock(p_a, 'identity confirmed by phone call');
  j2 := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  insert into _r values ('S16-07', j ->> 'error' = 'E_AUTH_LOCKED' and j1 ->> 'error' = 'E_AUTH_LOCKED' and (j2 ->> 'ok')::boolean
                                   and not exists (select 1 from iam.login_attempt a where a::text like '%482913%' or a::text like '%000111%')
                                   and not exists (select 1 from audit.global_event g where g.detail::text like '%$2%')
                                   and not exists (select 1 from iam.login_attempt a where a::text like '%1711111111%'),
                                   'lockout after repeated failures, manager unlock; no PIN, hash or number in any log');
  -- ---------------------------------------------------------------- PIN session liveness (F207 / F205)
  perform pg_temp.as_login(u_a, s1 ->> 'session_id', 'aal1', null, null, 'pin');
  j := api.v1_auth_my_companies();
  perform pg_temp.as_login(u_a, s1 ->> 'session_id', 'aal2', null, null, 'pin');
  insert into _r values ('S16-08', jsonb_array_length(j) = 1 and (j -> 0 -> 'positions' -> 0 ->> 'position_code') = 'ACCOUNTANT'
                                   and not (j -> 0 -> 'positions' -> 0 ->> 'mfa_required')::boolean
                                   and pg_temp.expect_fail('select api.v1_auth_my_companies()', 'E_AUTH'),
                                   'company selector lists authorised memberships; a PIN session can never claim MFA');
  -- ---------------------------------------------------------------- devices (F206)
  perform pg_temp.as_login(u_a, s1 ->> 'session_id', 'aal1', null, null, 'pin');
  v_dev := (s1 ->> 'device_id')::uuid;
  perform api.v1_auth_revoke_device(v_dev, null, 'phone lost');
  j := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  insert into _r values ('S16-09', pg_temp.expect_fail('select api.v1_auth_my_devices()', 'E_SESSION_REVOKED')
                                   and (select status from iam.auth_session where id = (s1 ->> 'session_id')::uuid) = 'revoked'
                                   and j ->> 'error' = 'E_DEVICE_REVOKED',
                                   'a revoked device loses its sessions at the next request and cannot log in with PIN');
  perform pg_temp.as_login(u_a, gen_random_uuid()::text, 'aal1', '8801711111111', 20);
  perform api.v1_auth_register_device(dev1, 'নতুন ফোন', 'android');
  s2 := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  insert into _r values ('S16-10', (s2 ->> 'ok')::boolean, 'after an OTP the owner registers the device again');
  -- ---------------------------------------------------------------- refresh rotation + reuse detection (F207)
  j1 := svc.v1_auth_refresh(s2 ->> 'refresh_token', dev1);
  j2 := svc.v1_auth_refresh(s2 ->> 'refresh_token', dev1);
  j := svc.v1_auth_refresh(j1 ->> 'refresh_token', dev1);
  insert into _r values ('S16-11', (j1 ->> 'ok')::boolean and j1 ->> 'refresh_token' <> s2 ->> 'refresh_token' and j1 ->> 'session_id' = s2 ->> 'session_id'
                                   and j2 ->> 'error' = 'E_SESSION_REVOKED' and j ->> 'error' = 'E_SESSION_REVOKED'
                                   and (select status from iam.auth_session where id = (s2 ->> 'session_id')::uuid) = 'revoked',
                                   'refresh rotates; replaying an old token kills the whole session');
  s3 := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  j := svc.v1_auth_refresh(s3 ->> 'refresh_token', dev2);
  insert into _r values ('S16-12', j ->> 'error' = 'E_SESSION_REVOKED' and (select status from iam.auth_session where id = (s3 ->> 'session_id')::uuid) = 'revoked',
                                   'a refresh token works only on its own device');
  -- ---------------------------------------------------------------- PIN change, OTP reset (F204), sign-out (OI-11)
  s3 := svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android');
  perform pg_temp.as_login(u_a, s3 ->> 'session_id', 'aal1', null, null, 'pin');
  j := api.v1_auth_change_pin('999000', '582047');
  j1 := api.v1_auth_change_pin('482913', '582047');
  insert into _r values ('S16-13', j ->> 'status' = 'wrong_pin' and j1 ->> 'status' = 'changed'
                                   and (svc.v1_auth_pin_verify('01711111111', '482913', dev1, 'ফোন', 'android') ->> 'ok')::boolean = false
                                   and (svc.v1_auth_pin_verify('01711111111', '582047', dev1, 'ফোন', 'android') ->> 'ok')::boolean,
                                   'PIN change needs the old PIN');
  perform pg_temp.as_login(u_a, s3 ->> 'session_id', 'aal1', null, null, 'pin');
  j := api.v1_auth_sign_out(false);
  insert into _r values ('S16-14', (j ->> 'pin_sessions_ended')::integer = 1 and pg_temp.expect_fail('select api.v1_auth_my_devices()', 'E_SESSION_REVOKED'),
                                   'sign-out ends the PIN session in the database at once');
  perform pg_temp.as_login(u_a, gen_random_uuid()::text, 'aal1', '8801711111111', 15);
  j := api.v1_auth_set_pin('639271');
  j1 := jsonb_build_object('none_active', not exists (select 1 from iam.auth_session where person_id = p_a and status = 'active'));
  j2 := svc.v1_auth_pin_verify('01711111111', '639271', dev1, 'ফোন', 'android');
  insert into _r values ('S16-15', j ->> 'status' = 'reset' and (j1 ->> 'none_active')::boolean and (j2 ->> 'ok')::boolean,
                                   'OTP recovery resets the PIN and ends every PIN session');
  -- ---------------------------------------------------------------- Chairman MFA (F205)
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S16-16', pg_temp.expect_fail($q$select api.v1_config_set('iam.mfa.required_positions', '["MD"]', 0, 'x')$q$, 'E_SETTING_INVALID')
                                   and api.v1_config_set('iam.mfa.required_positions', '["CHAIRMAN","MD","FIN_MANAGER"]', 0, 'stricter') = 1,
                                   'the Chairman can never be taken off the MFA list');
  perform pg_temp.as_user(u_ch, 'ch-otp', 'aal1');
  insert into _r values ('S16-17', pg_temp.expect_fail(format($f$select api.v1_iam_select_position(%L)$f$, a_ch), 'E_MFA_REQUIRED'),
                                   'an aal1 (OTP / PIN) login cannot act as Chairman');
  -- ---------------------------------------------------------------- login audit (F210), termination (F027 via login)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_auth_login_audit(null, 500);
  insert into _r values ('S16-18', exists (select 1 from jsonb_array_elements(j) x where x ->> 'kind' = 'pin_login' and x ->> 'outcome' = 'locked' and (x ->> 'person_id')::uuid = p_a)
                                   and not exists (select 1 from jsonb_array_elements(j) x where x ? 'phone' or x ? 'phone_hash'),
                                   'company login log: attempts, outcomes, lockouts — no numbers or secrets');
  s1 := svc.v1_auth_pin_verify('01711111111', '639271', dev1, 'ফোন', 'android');
  perform api.v1_iam_end_member(m_a, 'resigned');
  j1 := svc.v1_auth_refresh(s1 ->> 'refresh_token', dev1);
  j2 := svc.v1_auth_pin_verify('01711111111', '639271', dev1, 'ফোন', 'android');
  insert into _r values ('S16-19', j1 ->> 'error' = 'E_SESSION_REVOKED' and j2 = '{"ok":false,"error":"E_AUTH_FAILED"}'::jsonb
                                   and svc.v1_auth_kill_native_sessions(u_a) >= -1,
                                   'a terminated member can neither refresh nor log in again');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

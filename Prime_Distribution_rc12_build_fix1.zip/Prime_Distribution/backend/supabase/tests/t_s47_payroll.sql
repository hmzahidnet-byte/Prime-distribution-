-- S47–S48 tests: effective-dated structure, deterministic calculation, review/approval separation, balanced posting,
-- immutability after posting, own payslip only, disbursement within net with proof, supplemental + reversal corrections.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_h1 uuid; a_h2 uuid; a_md uuid; a_fm uuid; a_em uuid; a_ac uuid;
        p_ch uuid; p_h1 uuid; p_h2 uuid; p_md uuid; p_fm uuid; p_em uuid; p_ac uuid;
        u_ch uuid := gen_random_uuid(); u_h1 uuid := gen_random_uuid(); u_h2 uuid := gen_random_uuid(); u_md uuid := gen_random_uuid();
        u_fm uuid := gen_random_uuid(); u_em uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
        coa uuid; emp uuid; emp_h1 uuid; per date := date_trunc('month', current_date)::date; dim integer; de integer; exp_gross numeric; run uuid; sup uuid; rev uuid; j jsonb; c1 jsonb; c2 jsonb;
        v_net numeric;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PAY', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_h1 := svc.v1_iam_provision_person('এইচআর ১', null, null, u_h1, 't'); a_h1 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_h1, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  p_h2 := svc.v1_iam_provision_person('এইচআর ২', null, null, u_h2, 't'); a_h2 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_h2, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_em := svc.v1_iam_provision_person('কর্মী', null, null, u_em, 't'); a_em := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_em, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  emp := (select id from hr.employee where person_id = p_em and company_id = ca);
  emp_h1 := (select id from hr.employee where person_id = p_h1 and company_id = ca);
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');

  dim := extract(day from (per + interval '1 month' - interval '1 day'))::integer;
  de := dim - greatest(extract(day from (select effective_from from hr.employment where employee_id = emp))::integer,
                       case when (select effective_from from hr.employment where employee_id = emp) < per then 1 else 0 end) + 1;
  if (select effective_from from hr.employment where employee_id = emp) < per then de := dim; end if;
  exp_gross := round(300000.0 * de / dim, 2) + round(6000.0 * de / dim, 2);

  -- ---------------------------------------------------------------- structure + calculation (F171–F174)
  perform pg_temp.as_user(u_h1, 'h1'); perform api.v1_iam_select_position(a_h1);
  perform api.v1_salary_set(emp, per, 'G5', 300000, '[{"code":"HOUSE","name_bn":"বাড়িভাড়া","amount":6000}]', '[{"code":"PF","name_bn":"ভবিষ্য তহবিল","amount":1000}]', 'joining structure');
  c1 := hr.fn_payroll_calc(ca, emp, per); c2 := hr.fn_payroll_calc(ca, emp, per);
  j := api.v1_payroll_calculate(per); run := (j ->> 'run_id')::uuid;
  v_net := (select net from hr.payroll_line where run_id = run and employee_id = emp);
  insert into _r values ('S47-01', c1 = c2 and (j ->> 'employees')::integer = 1 and (c1 ->> 'gross')::numeric = exp_gross and v_net = exp_gross - 1000
                                   and hr.fn_payroll_calc(ca, emp_h1, per) is null
                                   and pg_temp.expect_fail(format($f$select api.v1_payroll_calculate(%L)$f$, per)),
                                   'same inputs give the same result; only employees with a structure are paid; one regular run per month');
  -- ---------------------------------------------------------------- review / approval / posting (F175, F176)
  insert into _r values ('S47-02', pg_temp.expect_fail(format($f$select api.v1_payroll_action(%L, 'review', 'x')$f$, run), 'E_SELF_APPROVAL'), 'the calculator does not review the own run');
  perform pg_temp.as_user(u_h2, 'h2'); perform api.v1_iam_select_position(a_h2);
  perform api.v1_payroll_action(run, 'review', 'checked');
  insert into _r values ('S47-03', pg_temp.expect_fail(format($f$select api.v1_payroll_action(%L, 'approve', 'x')$f$, run), 'E_FORBIDDEN'), 'HR cannot approve payroll');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_payroll_action(run, 'approve', 'ok');
  perform api.v1_payroll_action(run, 'post', 'post');
  insert into _r values ('S47-04', (select status from hr.payroll_run where id = run) = 'posted' and pg_temp.bal(ca, '5700') = exp_gross
                                   and pg_temp.bal(ca, '2200') = -(exp_gross - 1000) and pg_temp.bal(ca, '2210') = -1000,
                                   'posting makes one balanced salary journal');
  insert into _r values ('S47-05', pg_temp.expect_fail(format($f$update hr.payroll_run set note = 'x' where id = %L$f$, run), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$update hr.payroll_line set net = 1 where run_id = %L$f$, run))
                                   and pg_temp.expect_fail(format($f$select api.v1_payroll_action(%L, 'cancel', 'x')$f$, run)),
                                   'a posted payroll and its lines never change');
  -- ---------------------------------------------------------------- payslip (F177)
  perform pg_temp.as_user(u_em, 'em'); perform api.v1_iam_select_position(a_em);
  j := api.v1_payslip(run, null);
  insert into _r values ('S47-06', (j ->> 'net')::numeric = v_net and pg_temp.expect_fail(format($f$select api.v1_payslip(%L, %L)$f$, run, emp_h1), 'E_FORBIDDEN'),
                                   'employees read their own payslip only');
  -- ---------------------------------------------------------------- disbursement (F178)
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_payroll_pay(run, emp, 'bank', v_net - 500, 'SAL-0001', 'proofs/sal-0001.pdf');
  insert into _r values ('S47-07', pg_temp.expect_fail(format($f$select api.v1_payroll_pay(%L, %L, 'cash', 600, null, null)$f$, run, emp), 'E_OVERPAYMENT')
                                   and pg_temp.expect_fail(format($f$select api.v1_payroll_pay(%L, %L, 'bank', 100, 'SAL-0001', null)$f$, run, emp))
                                   and pg_temp.expect_fail(format($f$select api.v1_payroll_pay(%L, %L, 'mobile', 100, null, null)$f$, run, emp)),
                                   'never above net; a bank/mobile payment needs its own reference');
  perform api.v1_payroll_pay(run, emp, 'cash', 500, null, null);
  j := api.v1_payroll_reconcile(run);
  insert into _r values ('S47-08', (j -> 0 ->> 'unpaid')::numeric = 0 and pg_temp.bal(ca, '2200') = 0, 'paid amounts reconcile to the payable');
  -- ---------------------------------------------------------------- corrections (F179)
  perform pg_temp.as_user(u_h1, 'h1');
  insert into _r values ('S47-09', pg_temp.expect_fail(format($f$select api.v1_salary_set(%L, %L, 'G5', 99999, null, null, 'x')$f$, emp, per + 1), 'E_PERIOD_CLOSED'),
                                   'a structure cannot be changed inside a posted month');
  sup := (api.v1_payroll_correction('supplemental', per, null, jsonb_build_array(jsonb_build_object('employee_id', emp, 'amount', 2000)), 'missed festival bonus') ->> 'run_id')::uuid;
  rev := (api.v1_payroll_correction('reversal', null, run, null, 'wrong month posted') ->> 'run_id')::uuid;
  insert into _r values ('S47-10', (select net_total from hr.payroll_run where id = sup) = 2000 and (select net_total from hr.payroll_run where id = rev) = -v_net
                                   and (select kind from hr.payroll_run where id = rev) = 'reversal'
                                   and pg_temp.expect_fail(format($f$select api.v1_payroll_correction('reversal', null, %L, null, 'again')$f$, run), 'E_DUPLICATE'),
                                   'corrections are new supplemental / reversal runs; a run is reversed once');
  perform pg_temp.as_user(u_h2, 'h2');
  perform api.v1_payroll_action(sup, 'review', 'ok');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_payroll_action(sup, 'approve', 'ok'); perform api.v1_payroll_action(sup, 'post', 'ok');
  insert into _r values ('S47-11', pg_temp.bal(ca, '5700') = exp_gross + 2000 and pg_temp.bal(ca, '2200') = -2000, 'a supplemental run posts its own journal');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

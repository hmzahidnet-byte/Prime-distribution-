-- S25 tests: purchase-unit receipt with QC split, lots/expiry, quarantine release, moving average, reservations,
-- FEFO issue, expired-lot block, return to lot, wastage normal/abnormal, substitution approval, no negative stock,
-- cost visibility, idempotent issue, fixed conversion, company isolation.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.bal(p_wh uuid, p_prod uuid) returns numeric language sql as $$ select coalesce((select qty from inventory.stock_balance where warehouse_id = p_wh and product_id = p_prod), 0) $$;
create or replace function pg_temp.val(p_wh uuid, p_prod uuid) returns numeric language sql as $$ select coalesce((select value from inventory.stock_balance where warehouse_id = p_wh and product_id = p_prod), 0) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sk uuid; a_ps uuid; a_md uuid; a_fm uuid; a_ch2 uuid; p_ch uuid; p_sk uuid; p_ps uuid; p_md uuid; p_fm uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid(); u_ps uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        u_ch2 uuid := gen_random_uuid();
        wh uuid; sugar uuid; jag uuid; hold uuid; res uuid; res2 uuid; iss jsonb; iss2 jsonb; rule uuid; w2 uuid; j jsonb; j1 jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('RAW', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ps := svc.v1_iam_provision_person('উৎপাদন', null, null, u_ps, 't'); a_ps := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ps, ca, null, 't'), 'PROD_SUPERVISOR', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('RAX', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  wh := (api.v1_structure_save_warehouse(null, null, null, 'RM1', 'কাঁচামাল গুদাম', 'raw_material', null, null, 'x') ->> 'id')::uuid;
  sugar := (api.v1_product_propose(null, 'SUGAR', 'চিনি', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  jag := (api.v1_product_propose(null, 'JAGGERY', 'গুড়', null, 'raw_material', null, 'kg', null, 'x') ->> 'product_id')::uuid;
  perform api.v1_raw_profile_save(sugar, 'sweetener', 'A', 'bag', 50, 365, 50, null, true, 'bags of 50 kg');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(sugar, 1, 'approve', 'ok'); perform api.v1_product_decide(jag, 1, 'approve', 'ok');

  -- ---------------------------------------------------------------- receipt with QC split (F073)
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  j := api.v1_stock_receive(wh, sugar, 'L1', 'SUP-77', null, current_date + 30, 2, 1, 1, 3000, true, 'opening sugar');
  hold := (j ->> 'quarantine_hold_id')::uuid;
  insert into _r values ('S25-01', pg_temp.bal(wh, sugar) = 100 and pg_temp.val(wh, sugar) = 6000
                                   and (select quarantine_qty from inventory.receipt where id = (j ->> 'receipt_id')::uuid) = 50
                                   and (select rejected_qty from inventory.receipt where id = (j ->> 'receipt_id')::uuid) = 50,
                                   'only accepted quantity enters stock; purchase units convert by the fixed factor');
  insert into _r values ('S25-02', pg_temp.expect_fail(format($f$select api.v1_stock_receive(%L, %L, 'L1', null, null, null, 1, 0, 0, 10, false, 'x')$f$, wh, sugar), 'E_DUPLICATE')
                                   and pg_temp.expect_fail(format($f$select api.v1_stock_receive(%L, %L, 'OLD', null, null, current_date - 1, 1, 0, 0, 10, false, 'x')$f$, wh, sugar), 'E_LOT_EXPIRED'),
                                   'lots are unique and never received already expired');
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  perform api.v1_quarantine_decide(hold, 30, 20, 'lab cleared part');
  insert into _r values ('S25-03', pg_temp.bal(wh, sugar) = 130 and pg_temp.val(wh, sugar) = 7800 and (select status from inventory.quarantine_hold where id = hold) = 'released',
                                   'quarantine releases enter stock only on decision');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_stock_receive(wh, sugar, 'L2', null, null, current_date + 10, 50, 0, 0, 70, false, 'second lot');
  insert into _r values ('S25-04', pg_temp.bal(wh, sugar) = 180 and pg_temp.val(wh, sugar) = 11300, 'moving average value per warehouse + SKU');
  -- ---------------------------------------------------------------- reservation + FEFO issue
  perform pg_temp.as_user(u_ps, 'ps'); perform api.v1_iam_select_position(a_ps);
  res := (api.v1_stock_reserve(wh, sugar, 120, 'B-1', 'batch B-1') ->> 'reservation_id')::uuid;
  insert into _r values ('S25-05', pg_temp.expect_fail(format($f$select api.v1_stock_reserve(%L, %L, 100, 'B-2', 'x')$f$, wh, sugar), 'E_INSUFFICIENT_STOCK')
                                   and inventory.fn_available(ca, wh, sugar) = 60,
                                   'a reservation never exceeds available stock');
  perform pg_temp.as_user(u_sk, 'sk');
  perform set_config('request.headers', '{"idempotency-key":"k-issue-0000001"}', true);
  iss := api.v1_material_issue(res, 80, null, 'batch B-1 mixing');
  iss2 := api.v1_material_issue(res, 80, null, 'batch B-1 mixing');
  perform set_config('request.headers', '', true);
  insert into _r values ('S25-06', jsonb_array_length(iss -> 'lines') = 2
                                   and (select lot_no from inventory.lot where id = (iss -> 'lines' -> 0 ->> 'lot_id')::uuid) = 'L2' and (iss -> 'lines' -> 0 ->> 'qty')::numeric = 50
                                   and pg_temp.bal(wh, sugar) = 100 and (select consumed_qty from inventory.reservation where id = res) = 80 and iss2 = iss,
                                   'issue picks earliest expiry first, reduces stock and reservation; a replay changes nothing');
  -- ---------------------------------------------------------------- return
  perform pg_temp.as_user(u_ps, 'ps');
  perform api.v1_material_return((iss ->> 'issue_id')::uuid, 1, 20, 'left over');
  insert into _r values ('S25-07', pg_temp.bal(wh, sugar) = 120
                                   and (select lb.qty from inventory.lot_balance lb join inventory.lot l on l.id = lb.lot_id where l.lot_no = 'L2' and l.product_id = sugar) = 20
                                   and pg_temp.expect_fail(format($f$select api.v1_material_return(%L, 1, 40, 'x')$f$, iss ->> 'issue_id'), 'E_INVALID_ACTION'),
                                   'returns reference the issue line and lot and never exceed what was issued');
  -- ---------------------------------------------------------------- wastage
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_wastage_submit(wh, 'normal', jsonb_build_array(jsonb_build_object('product_id', sugar, 'qty', 5)), 'spillage');
  j := api.v1_wastage_submit(wh, 'abnormal', jsonb_build_array(jsonb_build_object('product_id', sugar, 'qty', 10)), 'rain damage');
  perform pg_temp.as_user(u_fm, 'fm');
  j1 := api.v1_wastage_decide((j ->> 'wastage_id')::uuid, true, 'confirmed');
  insert into _r values ('S25-08', pg_temp.bal(wh, sugar) = 105 and j ->> 'status' = 'pending' and j1 ->> 'status' = 'posted'
                                   and exists (select 1 from inventory.stock_move m where m.doc_id = (j ->> 'wastage_id')::uuid and m.move_type = 'waste_abnormal')
                                   and exists (select 1 from inventory.stock_move m where m.product_id = sugar and m.move_type = 'waste_normal'),
                                   'normal wastage posts; abnormal waits for another person and posts as its own type');
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S25-09', pg_temp.expect_fail(format($f$select api.v1_wastage_submit(%L, 'normal', '[{"product_id":"%s","qty":1000}]', 'x')$f$, wh, sugar), 'E_NEGATIVE_STOCK')
                                   and pg_temp.expect_fail(format($f$select inventory.fn_post_move(%L, %L, %L, null, 'adjust_out', -1000, null, 'test', gen_random_uuid(), 1, 'x')$f$, ca, wh, sugar), 'E_NEGATIVE_STOCK'),
                                   'no negative stock anywhere');
  -- ---------------------------------------------------------------- expired lots + substitution
  perform api.v1_stock_receive(wh, jag, 'J1', null, null, current_date + 5, 40, 0, 0, 50, false, 'jaggery');
  update inventory.lot set expiry_date = current_date - 1 where product_id = jag and lot_no = 'J1';
  perform pg_temp.as_user(u_ps, 'ps');
  res2 := (api.v1_stock_reserve(wh, jag, 10, 'B-3', 'x') ->> 'reservation_id')::uuid;
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S25-10', pg_temp.expect_fail(format($f$select api.v1_material_issue(%L, 5, null, 'x')$f$, res2), 'E_LOT_EXPIRED'), 'expired lots are never issued');
  perform api.v1_stock_receive(wh, jag, 'J2', null, null, current_date + 60, 40, 0, 0, 55, false, 'fresh jaggery');
  insert into _r values ('S25-11', pg_temp.expect_fail(format($f$select api.v1_material_issue(%L, 5, %L, 'x')$f$, res, jag), 'E_SUBSTITUTE_NOT_APPROVED'),
                                   'unapproved substitutes cannot be issued');
  perform pg_temp.as_user(u_ps, 'ps');
  rule := (api.v1_substitution_propose(sugar, jag, 1.2, 'sugar shortage') ->> 'rule_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_substitution_decide(rule, true, 'agreed');
  perform pg_temp.as_user(u_sk, 'sk');
  j := api.v1_material_issue(res, 5, jag, 'use jaggery');
  insert into _r values ('S25-12', (j -> 'lines' -> 0 ->> 'qty')::numeric = 6 and (j -> 'lines' -> 0 ->> 'substitute_for')::uuid = sugar
                                   and (select consumed_qty from inventory.reservation where id = res) = 85,
                                   'approved substitutes are issued at their ratio against the original reservation');
  -- ---------------------------------------------------------------- cost visibility, fixed conversion, isolation
  j := api.v1_stock_balances(wh, sugar);
  perform pg_temp.as_user(u_fm, 'fm');
  j1 := api.v1_stock_balances(wh, sugar);
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S25-13', j -> 0 -> 'avg_cost' = 'null'::jsonb and (j1 -> 0 ->> 'avg_cost')::numeric > 0
                                   and pg_temp.expect_fail(format($f$select api.v1_raw_profile_save(%L, 'sweetener', 'A', 'bag', 25, 365, 50, null, true, 'x')$f$, sugar), 'E_PRODUCT_LOCKED'),
                                   'costs only for cost readers; conversion fixed once stock moved');
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S25-14', pg_temp.expect_fail(format($f$select api.v1_stock_reserve(%L, %L, 1, 'X-1', 'x')$f$, wh, sugar), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail(format($f$select api.v1_material_issue(%L, 1, null, 'x')$f$, res), 'E_NOT_FOUND'),
                                   'another company cannot touch this stock');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

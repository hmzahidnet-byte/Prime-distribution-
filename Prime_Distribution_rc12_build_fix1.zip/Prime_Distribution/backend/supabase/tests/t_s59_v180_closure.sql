-- S59 tests (v180 line-by-line closure, docs/V180_TRACE_BN.md): order split / backorder + fill rate (Prime 02), later remittance
-- allocation + reconciled collections (v180 invariant 3), shipment disputes and the unresolved-events list (Prime 06), Chairman-only money
-- with the denial logged (scenario 14). Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        o2 jsonb; spl jsonb; fr jsonb; dsa jsonb; dsp uuid; rem3 jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- order -> approval -> dispatch -> invoice (20000, lot N1, 200 POLY)
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 200)), null);
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 4);
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, null, null);
  perform pg_temp.as_user(u_ac, 'ac');
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);

  -- ---------------------------------------------------------------- order split / backorder + fill rate (Prime 02)
  perform pg_temp.as_user(u_fs, 'fs');
  o2 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 250)), null);
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o2 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S59-01', pg_temp.expect_fail(format($f$select api.v1_order_split(%L, '[{"product_id":"%s","qty":250}]', 'all now')$f$, o2 ->> 'order_id', noodle), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_order_split(%L, '[{"product_id":"%s","qty":100}]', '')$f$, o2 ->> 'order_id', noodle), 'E_REASON_REQUIRED')
                                   and pg_temp.expect_fail(format($f$select api.v1_order_split(%L, '[{"product_id":"%s","qty":100}]', 'x')$f$, o2 ->> 'order_id', gen_random_uuid()), 'E_INVALID_ACTION'),
                                   'a split needs a reason, something now and something later, and only products of the order');
  spl := api.v1_order_split((o2 ->> 'order_id')::uuid, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 100)), 'truck has room for 100 only');
  insert into _r values ('S59-02', (select status from sales.sales_order where id = (o2 ->> 'order_id')::uuid) = 'split'
                                   and (select status = 'allocated' and total = 10000 and parent_order_id = (o2 ->> 'order_id')::uuid and root_order_id = (o2 ->> 'order_id')::uuid
                                          from sales.sales_order where id = (spl ->> 'now_order_id')::uuid)
                                   and (select total = 15000 and approval_request_id = (select approval_request_id from sales.sales_order where id = (o2 ->> 'order_id')::uuid)
                                          from sales.sales_order where id = (spl ->> 'backorder_id')::uuid)
                                   and spl ->> 'backorder_status' = 'allocated'
                                   and (select sum(qty) from inventory.reservation where company_id = ca and product_id = noodle and status = 'active') = 250,
                                   'the parent keeps its lines (status split); two children carry them with the same approval; reservations are moved, not doubled');
  insert into _r values ('S59-03', pg_temp.expect_fail(format($f$update sales.sales_order set total = 1 where id = %L$f$, spl ->> 'now_order_id'), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$select api.v1_order_split(%L, '[{"product_id":"%s","qty":10}]', 'again')$f$, o2 ->> 'order_id', noodle), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_backorder_allocate(%L)$f$, spl ->> 'backorder_id'), 'E_INVALID_ACTION'),
                                   'children are immutable; a split order is not split again; only a waiting backorder is allocated');
  perform api.v1_order_pick((spl ->> 'now_order_id')::uuid); perform api.v1_order_pack((spl ->> 'now_order_id')::uuid, 2);
  dsa := api.v1_dispatch_post((spl ->> 'now_order_id')::uuid, null, null);
  fr := api.v1_dispatch_fill_report(current_date, current_date);
  insert into _r values ('S59-04', (fr ->> 'orders')::int = 2 and (fr ->> 'ordered_qty')::numeric = 450 and (fr ->> 'dispatched_qty')::numeric = 300
                                   and (fr ->> 'fill_rate_pct')::numeric = 66.7 and (fr ->> 'full')::int = 1 and (fr ->> 'partial')::int = 1
                                   and jsonb_array_length(fr -> 'backorders') = 1 and fr -> 'backorders' -> 0 ->> 'order_id' = spl ->> 'backorder_id',
                                   'fill rate per original order: 200/200 full, 100/250 partial, the backorder is listed');
  insert into _r values ('S59-05', pg_temp.expect_fail(format($f$select api.v1_order_split(%L, '[{"product_id":"%s","qty":10}]', 'late')$f$, spl ->> 'now_order_id', noodle), 'E_INVALID_ACTION'),
                                   'a dispatched order is never split');

  -- ---------------------------------------------------------------- remittance allocated later (v180 invariant 3)
  perform pg_temp.as_user(u_sm, 'sm');
  prov := (api.v1_courier_provider_save(null, 'SUNDAR', 'সুন্দরবন কুরিয়ার', '01700000000', null, null, 'new courier') ->> 'provider_id')::uuid;
  perform api.v1_courier_rate_set(prov, 'খুলনা', 'standard', 'parcel', 800, current_date);
  perform pg_temp.as_user(u_sk, 'sk');
  sh := api.v1_shipment_create((inv ->> 'invoice_id')::uuid, prov, 'খুলনা', 'standard', jsonb_build_array(jsonb_build_object('lot_id', lot, 'qty', 200)), null, null, 'dealer', null, 'separate', 15000, 'S-9', null);
  perform pg_temp.as_user(u_ac, 'ac');
  col := api.v1_courier_collection_report((sh ->> 'shipment_id')::uuid, 10000, clock_timestamp(), 'slips/s9.jpg', 'EVT-0901');
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_courier_collection_verify((col ->> 'collection_id')::uuid);
  perform pg_temp.as_user(u_ac, 'ac');
  rem := api.v1_courier_remittance_report(prov, 6000, 'bank', 'RM-9', null, 'REM-0901');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S59-06', pg_temp.expect_fail(format($f$select api.v1_courier_remittance_approve(%L, '[]', 'x')$f$, rem ->> 'remittance_id'), 'E_CHAIRMAN_ONLY'),
                                   'only the Chairman posts money (the attempt is rejected and written to the server log)');
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_courier_remittance_approve((rem ->> 'remittance_id')::uuid, '[]'::jsonb, 'statement comes at month end');
  perform pg_temp.as_user(u_ac, 'ac');
  j1 := api.v1_courier_open_issues(prov);
  insert into _r values ('S59-07', (j ->> 'unallocated')::numeric = 6000 and pg_temp.bal(ca, '1110') = 6000 and pg_temp.bal(ca, '1350') = 4000
                                   and jsonb_array_length(j1 -> 'unallocated') = 1 and jsonb_array_length(j1 -> 'missing_evidence') = 1 and (j1 ->> 'collected_not_remitted')::numeric = 10000,
                                   'an unmatched remittance is posted once and stays visible as unallocated; it is not silently matched');
  perform pg_temp.as_user(u_fm, 'fm');
  insert into _r values ('S59-08', pg_temp.expect_fail(format($f$select api.v1_courier_remittance_allocate(%L, '[{"collection_id":"%s","amount":7000}]')$f$, rem ->> 'remittance_id', col ->> 'collection_id'), 'E_OVERPAYMENT')
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_remittance_allocate(%L, '[]')$f$, rem ->> 'remittance_id'), 'E_INVALID_ACTION'),
                                   'never more than the unallocated part of the remittance');
  perform api.v1_courier_remittance_allocate((rem ->> 'remittance_id')::uuid, jsonb_build_array(jsonb_build_object('collection_id', col ->> 'collection_id', 'amount', 4000)));
  j := api.v1_courier_remittance_allocate((rem ->> 'remittance_id')::uuid, jsonb_build_array(jsonb_build_object('collection_id', col ->> 'collection_id', 'amount', 2000)));
  insert into _r values ('S59-09', (j ->> 'unallocated')::numeric = 0 and sales.fn_collection_outstanding((col ->> 'collection_id')::uuid) = 4000
                                   and (select reconciled_at is null from sales.courier_collection where id = (col ->> 'collection_id')::uuid)
                                   and pg_temp.bal(ca, '1350') = 4000 and pg_temp.bal(ca, '1110') = 6000,
                                   'later matching moves no money (no second journal); a collection still owed is not reconciled');
  perform pg_temp.as_user(u_ac, 'ac');
  rem3 := api.v1_courier_remittance_report(prov, 4000, 'bank', 'RM-10', null, 'REM-0902');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_courier_remittance_approve((rem3 ->> 'remittance_id')::uuid, jsonb_build_array(jsonb_build_object('collection_id', col ->> 'collection_id', 'amount', 4000)), 'cash deposit slip later');
  insert into _r values ('S59-10', (select reconciled_at is not null from sales.courier_collection where id = (col ->> 'collection_id')::uuid)
                                   and sales.fn_courier_receivable(ca, prov) = 0 and pg_temp.bal(ca, '1350') = 0,
                                   'REPORTED -> VERIFIED -> RECONCILED when the whole collection has arrived');

  -- ---------------------------------------------------------------- shipment disputes + unresolved list (Prime 06)
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S59-11', pg_temp.expect_fail(format($f$select api.v1_shipment_dispute_open(%L, 'lost', %L, 500, null, 'carton missing', null)$f$, sh ->> 'shipment_id', lot), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_shipment_dispute_open(%L, 'lost', %L, 5, null, ' ', null)$f$, sh ->> 'shipment_id', lot), 'E_REASON_REQUIRED')
                                   and pg_temp.expect_fail(format($f$select api.v1_shipment_dispute_open(%L, 'amount', null, null, null, 'short', null)$f$, sh ->> 'shipment_id'), 'E_INVALID_ACTION'),
                                   'a loss names a lot and a quantity from the shipment; an amount dispute names the amount; a reason is required');
  j := api.v1_shipment_dispute_open((sh ->> 'shipment_id')::uuid, 'lost', lot, 5, null, 'one carton missing at the hub', 'photos/hub.jpg');
  insert into _r values ('S59-12', pg_temp.expect_fail(format($f$select api.v1_shipment_dispute_resolve(%L, 'found', null)$f$, j ->> 'dispute_id'), 'E_SELF_APPROVAL')
                                   and jsonb_array_length(api.v1_courier_open_issues(null) -> 'disputes') = 1,
                                   'the person who opened a dispute does not close it; open disputes are listed');
  perform pg_temp.as_user(u_fm, 'fm');
  insert into _r values ('S59-13', pg_temp.expect_fail(format($f$select api.v1_shipment_dispute_resolve(%L, 'paid', %L)$f$, j ->> 'dispute_id', gen_random_uuid()), 'E_INVALID_ACTION'),
                                   'a linked settlement must be a posted settlement of the same shipment');
  perform api.v1_shipment_dispute_resolve((j ->> 'dispute_id')::uuid, 'courier found the carton; delivered next day', null);
  insert into _r values ('S59-14', jsonb_array_length(api.v1_courier_open_issues(null) -> 'disputes') = 0
                                   and pg_temp.expect_fail(format($f$update sales.shipment_dispute set resolution = 'changed' where id = %L$f$, j ->> 'dispute_id'), 'E_IMMUTABLE')
                                   and pg_temp.expect_fail(format($f$delete from sales.shipment_dispute where id = %L$f$, j ->> 'dispute_id')),
                                   'a resolved dispute leaves the list and never changes or disappears');
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S59-15', pg_temp.expect_fail(format($f$select api.v1_shipment_dispute_resolve(%L, 'x', null)$f$, j ->> 'dispute_id')), 'without courier.verify nobody resolves');

  -- ---------------------------------------------------------------- search lists instead of typed ids (S60)
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_lookup('dealer', 'রহমান', null);
  insert into _r values ('S59-16', jsonb_array_length(j) = 1 and j -> 0 ->> 'id' = dl::text and (j -> 0 ->> 'label') like 'D1 · %'
                                   and jsonb_array_length(api.v1_lookup('dealer', 'নেই-এমন-নাম', 5)) = 0
                                   and jsonb_array_length(api.v1_lookup('shipment', null, 1)) = 1,
                                   'a list returns id + readable label of this company; the limit is honoured');
  insert into _r values ('S59-17', pg_temp.expect_fail($q$select api.v1_lookup('pg_class', null, null)$q$, 'E_INVALID_ACTION')
                                   and jsonb_array_length(api.v1_lookup('dealer', '%', null)) = 0,
                                   'only known lists; % and _ are searched literally');
  perform pg_temp.as_user(u_fs, 'fs');
  insert into _r values ('S59-18', pg_temp.expect_fail($q$select api.v1_lookup('journal', null, null)$q$), 'a list needs the same read right as its module');

  -- ---------------------------------------------------------------- masking policy on lists (S61, OI-19)
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_lookup('provider', 'SUNDAR', null);
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_mask_set_policy('sales.contact.phone', 'SALES_MANAGER', 'hide', 0, 'phone numbers are private');
  j1 := api.v1_lookup('provider', 'SUNDAR', null);
  perform pg_temp.as_user(u_sm, 'sm');
  insert into _r values ('S59-19', j -> 0 ->> 'sub' = '01700000000' and j1 -> 0 ->> 'sub' = '01700000000' and api.v1_lookup('provider', 'SUNDAR', null) -> 0 ->> 'sub' = ''
                                   and jsonb_array_length(api.v1_lookup('provider', '0170', null)) = 0,
                                   'the Chairman''s mask policy hides a phone for that position (also from search); the Chairman still sees it');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S14 tests: Dynamic Forms (schema language, field types, conditional visibility, validation, publication + pinning,
-- field permissions + masking, export redaction, attachments, offline drafts, archive, audit/revisions, amend,
-- approval-required forms, publish approval, generic mask policy, SELF scope, cross-company, revoked member).
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.frv(p uuid) returns integer language sql as $$ select row_version from config.form where id = p $$;
create or replace function pg_temp.srv(p uuid) returns integer language sql as $$ select row_version from config.form_submission where id = p $$;
create or replace function pg_temp.has_err(j jsonb, p_field text, p_code text) returns boolean language sql as $$
  select exists (select 1 from jsonb_array_elements(j -> 'errors') e where e ->> 'field' = p_field and e ->> 'code' = p_code) $$;
do $$
declare boot jsonb; ca uuid; cb uuid; w1 uuid; a_ch uuid; a_md uuid; a_a uuid; a_b uuid; a_ch2 uuid; m_a uuid;
        p_ch uuid; p_md uuid; p_a uuid; p_b uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_a uuid := gen_random_uuid(); u_b uuid := gen_random_uuid(); u_ch2 uuid := gen_random_uuid();
        fid uuid; fadv uuid; s1 uuid; s2 uuid; s3 uuid; s4 uuid; s5 uuid; sa1 uuid; sa2 uuid; att uuid; d1 uuid; req uuid;
        j jsonb; j1 jsonb; j2 jsonb; v_path text; v_no text;
        sha text := repeat('ab', 32);
        def jsonb := $j${"title_bn":"ছুটির আবেদন","amount_field":"days",
          "groups":[{"key":"medical","label_bn":"চিকিৎসা","visible_if":{"op":"=","field":"leave_type","value":"sick"}}],
          "fields":[
            {"key":"leave_type","type":"select","label_bn":"ছুটির ধরন","required":true,"options":[{"value":"casual","label_bn":"নৈমিত্তিক"},{"value":"sick","label_bn":"অসুস্থতা"}]},
            {"key":"days","type":"integer","label_bn":"দিন","required":true,"min":1,"max":30},
            {"key":"start_date","type":"date","label_bn":"শুরু","required":true},
            {"key":"end_date","type":"date","label_bn":"শেষ","required":true},
            {"key":"medical_photo","type":"photo","label_bn":"চিকিৎসা-সনদ","required":true,"group":"medical"},
            {"key":"nid","type":"text","label_bn":"জাতীয় পরিচয়পত্র","sensitive":true,"pattern":"^[0-9]{10,17}$"},
            {"key":"salary","type":"money","label_bn":"বেতন","min":0},
            {"key":"phone","type":"phone","label_bn":"ফোন"},
            {"key":"note","type":"textarea","label_bn":"মন্তব্য","max_length":500}],
          "checks":[{"kind":"compare","left":"end_date","op":">=","right":"start_date","message_bn":"শেষ তারিখ শুরুর আগে হতে পারে না"},
                    {"kind":"rule","condition":{"op":"<=","field":"days","value":20},"message_bn":"একবারে ২০ দিনের বেশি নয়"}]}$j$;
        def2 jsonb;
        adv jsonb := $j${"approval":{"required":true},"amount_field":"amount",
          "fields":[{"key":"amount","type":"money","label_bn":"অগ্রিম","required":true,"min":1},{"key":"purpose","type":"text","label_bn":"উদ্দেশ্য","required":true}]}$j$;
        gv jsonb := '{"leave_type":"casual","days":3,"start_date":"2026-11-10","end_date":"2026-11-12","nid":"1234567890123","salary":25000.50,"phone":"01712345678","note":"পারিবারিক"}';
begin
  def2 := jsonb_set(def, '{fields}', (def -> 'fields') || '[{"key":"remarks","type":"text","label_bn":"অতিরিক্ত"}]'::jsonb);
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('FRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't');
  p_a := svc.v1_iam_provision_person('হিসাব', null, null, u_a, 't');
  p_b := svc.v1_iam_provision_person('মাঠ', null, null, u_b, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  m_a := svc.v1_iam_add_membership(p_a, ca, null, 't');
  a_a := svc.v1_iam_assign_position(m_a, 'ACCOUNTANT', null, null, null, null, null, 't');
  a_b := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_b, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য চেয়ারম্যান', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('FRX', 'খ', p_ch2, 't'); cb := (boot ->> 'company_id')::uuid; a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  -- ---------------------------------------------------------------- schema language (F041)
  insert into _r values ('S14-01',
        pg_temp.expect_fail($q$select config.fn_form_validate_definition('{"fields":[{"key":"a","type":"text","label_bn":"ক"}],"script":"x"}')$q$, 'E_FORM_SCRIPT_REJECTED')
    and pg_temp.expect_fail($q$select config.fn_form_validate_definition('{"fields":[{"key":"a","type":"text","label_bn":"<script>alert(1)</script>"}]}')$q$, 'E_FORM_SCRIPT_REJECTED')
    and pg_temp.expect_fail($q$select config.fn_form_validate_definition('{"fields":[{"key":"a","type":"text","label_bn":"ক","onchange":"x"}]}')$q$, 'E_FORM_SCRIPT_REJECTED')
    and pg_temp.expect_fail($q$select config.fn_form_validate_definition('{"fields":[{"key":"a","type":"html","label_bn":"ক"}]}')$q$, 'E_FORM_SCHEMA_INVALID')
    and pg_temp.expect_fail($q$select config.fn_form_validate_definition('{"fields":[{"key":"a","type":"text","label_bn":"ক","visible_if":{"op":"=","field":"b","value":1}},{"key":"b","type":"integer","label_bn":"খ"}]}')$q$, 'E_FORM_SCHEMA_INVALID')
    and pg_temp.expect_fail($q$select config.fn_form_validate_definition('{"fields":[{"key":"a","type":"text","label_bn":"ক","pattern":"(["}]}')$q$, 'E_FORM_SCHEMA_INVALID')
    and config.fn_form_validate_definition(def) = 9,
    'schema language: whitelist only, scripts/markup/handlers refused, conditions only on earlier fields');

  -- ---------------------------------------------------------------- versions (F041) + not yet published (F045)
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_forms_save_version('LEAVE', 'ছুটির আবেদন', null, def, 'first design'); fid := (j ->> 'form_id')::uuid;
  j := api.v1_forms_save_version('LEAVE', 'ছুটির আবেদন', null, def2, 'remarks added');
  insert into _r values ('S14-02', (j ->> 'version')::integer = 2
                                   and pg_temp.expect_fail(format($f$update config.form_version set definition = '{}' where form_id = %L and version = 1$f$, fid), 'E_IMMUTABLE'),
                                   'every save is a new immutable version');
  perform pg_temp.as_user(u_a, 'a'); perform api.v1_iam_select_position(a_a);
  insert into _r values ('S14-03', pg_temp.expect_fail(format($f$select api.v1_forms_submission_save(%L, null, %L, null, null, null)$f$, fid, gv), 'E_FORM_NOT_PUBLISHED')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_definition(%L, 2)$f$, fid), 'E_FORBIDDEN'),
                                   'nothing can be filled before publication; drafts are visible only to designers');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_action(fid, 'publish', 1, pg_temp.frv(fid), 'go live');

  -- ---------------------------------------------------------------- field types, locale independence (F042)
  perform pg_temp.as_user(u_a, 'a');
  j := api.v1_forms_preview(fid, null, '{"leave_type":"annual","days":"১২","start_date":"2026-02-30","end_date":"2026-03-01","phone":"০১৭১২৩৪৫৬৭৮","salary":10.555}');
  insert into _r values ('S14-04', pg_temp.has_err(j, 'leave_type', 'option') and pg_temp.has_err(j, 'days', 'type') and pg_temp.has_err(j, 'start_date', 'type')
                                   and pg_temp.has_err(j, 'phone', 'pattern') and pg_temp.has_err(j, 'salary', 'type')
                                   and (api.v1_forms_preview(fid, null, gv) ->> 'ok')::boolean,
                                   'canonical values only: options, ASCII digits, real ISO dates, money scale');
  -- ---------------------------------------------------------------- conditional visibility (F043)
  j := api.v1_forms_preview(fid, null, gv || '{"leave_type":"sick"}');
  j1 := api.v1_forms_preview(fid, null, gv || jsonb_build_object('medical_photo', gen_random_uuid()));
  insert into _r values ('S14-05', pg_temp.has_err(j, 'medical_photo', 'required')
                                   and (j1 ->> 'ok')::boolean and not (j1 -> 'values') ? 'medical_photo' and not (j1 -> 'visible') ? 'medical_photo',
                                   'server decides visibility: a visible required field cannot be skipped; hidden values are dropped');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('forms.hidden_value_policy', '"reject"'::jsonb, 0, 'strict');
  perform pg_temp.as_user(u_a, 'a');
  j := api.v1_forms_preview(fid, null, gv || jsonb_build_object('medical_photo', gen_random_uuid()));
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('forms.hidden_value_policy', '"strip"'::jsonb, 1, 'back to default');
  insert into _r values ('S14-06', pg_temp.has_err(j, 'medical_photo', 'hidden'), 'Chairman option: values for hidden fields are refused');
  -- ---------------------------------------------------------------- validation builder (F044)
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-07', pg_temp.has_err(api.v1_forms_preview(fid, null, gv || '{"end_date":"2026-11-01"}'), 'end_date', 'check')
                                   and pg_temp.has_err(api.v1_forms_preview(fid, null, gv || '{"days":25}'), '_form', 'check')
                                   and pg_temp.has_err(api.v1_forms_preview(fid, null, gv || '{"days":40}'), 'days', 'range')
                                   and pg_temp.has_err(api.v1_forms_preview(fid, null, gv || '{"nid":"12AB"}'), 'nid', 'pattern')
                                   and pg_temp.has_err(api.v1_forms_preview(fid, null, gv || '{"bogus":1}'), 'bogus', 'unknown'),
                                   'range, regex, cross-field compare, rule checks and unknown keys');
  -- ---------------------------------------------------------------- draft, submit, idempotency, pinning (F045)
  j := api.v1_forms_submission_save(fid, null, gv, null, null, null); s1 := (j ->> 'submission_id')::uuid;
  perform set_config('request.headers', '{"idempotency-key":"k-forms-submit-0001"}', true);
  j1 := api.v1_forms_submission_submit(s1, pg_temp.srv(s1));
  j2 := api.v1_forms_submission_submit(s1, 1);
  perform set_config('request.headers', '', true);
  insert into _r values ('S14-08', j1 ->> 'status' = 'submitted' and j1 ->> 'number' is not null and j2 = j1
                                   and (select count(*) from core.document_number d where d.document_id = s1) = 1,
                                   'submit numbers once; a repeated request returns the original result');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_action(fid, 'publish', 2, pg_temp.frv(fid), 'v2 with remarks');
  perform pg_temp.as_user(u_a, 'a');
  j := api.v1_forms_submission_save(fid, null, gv || '{"remarks":"নতুন"}', null, null, null); s2 := (j ->> 'submission_id')::uuid;
  insert into _r values ('S14-09', (select form_version from config.form_submission where id = s1) = 1 and (j ->> 'form_version')::integer = 2
                                   and pg_temp.expect_fail(format($f$update config.form_submission set form_version = 2 where id = %L$f$, s1), 'E_IMMUTABLE')
                                   and (api.v1_forms_submission_get(s1) -> 'definition' -> 'fields') @> '[{"key":"nid"}]'
                                   and not ((api.v1_forms_submission_get(s1) -> 'definition' -> 'fields') @> '[{"key":"remarks"}]'),
                                   'records stay pinned to their schema version');
  -- ---------------------------------------------------------------- field permissions + masking (F046)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_set_field_access(fid, 'salary', 'ACCOUNTANT', 'none', 0, 'pay is private');
  perform api.v1_forms_set_field_access(fid, 'nid', 'ACCOUNTANT', 'masked', 0, 'identity masked');
  j1 := api.v1_forms_submission_get(s1);
  perform pg_temp.as_user(u_a, 'a');
  j := api.v1_forms_submission_get(s1);
  insert into _r values ('S14-10', j1 -> 'values' ->> 'nid' = '1234567890123' and j -> 'values' ->> 'nid' like '%0123' and j -> 'values' ->> 'nid' <> '1234567890123'
                                   and not (j -> 'values') ? 'salary' and not ((j -> 'definition' -> 'fields') @> '[{"key":"salary"}]')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_submission_save(%L, null, '{"salary":100}', null, null, null)$f$, fid), 'E_FORM_FIELD_FORBIDDEN')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_submission_save(null, %L, '{"nid":"9999999999"}', null, %s, null)$f$, s2, pg_temp.srv(s2)), 'E_FORM_FIELD_FORBIDDEN')
                                   and not exists (select 1 from audit.event e where e.entity_id = s1 and e.detail::text like '%1234567890123%'),
                                   'per field x position: Chairman sees all, masked/none never leave the server, audit has no values');
  -- export (redaction + permission + log)
  insert into _r values ('S14-11', pg_temp.expect_fail(format($f$select api.v1_forms_export(%L, 10)$f$, fid), 'E_FORBIDDEN'), 'export needs its own permission');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  j := api.v1_forms_export(fid, 50);
  insert into _r values ('S14-12', (j ->> 'row_count')::integer >= 1 and (j -> 'rows' -> 0 -> 'values' ->> 'nid') = '[গোপন]' and (j -> 'redacted_fields') ? 'nid'
                                   and (select count(*) from config.form_export_log l where l.form_id = fid) = 1,
                                   'export redacts sensitive fields and is logged');
  -- SELF scope, company isolation
  perform pg_temp.as_user(u_b, 'b'); perform api.v1_iam_select_position(a_b);
  insert into _r values ('S14-13', pg_temp.expect_fail(format($f$select api.v1_forms_submission_get(%L)$f$, s1), 'E_FORBIDDEN')
                                   and jsonb_array_length(api.v1_forms_submissions(fid, null, 50)) = 0, 'SELF scope: others'' submissions are invisible');
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S14-14', pg_temp.expect_fail(format($f$select api.v1_forms_submission_get(%L)$f$, s1), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_definition(%L, null)$f$, fid), 'E_NOT_FOUND'),
                                   'another company sees nothing, not even the form');
  -- ---------------------------------------------------------------- attachments (F047)
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-15', pg_temp.expect_fail(format($f$select api.v1_forms_attachment_begin(%L, 'medical_photo', 'application/pdf', 1000, %L)$f$, fid, sha), 'E_FORM_ATTACHMENT_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_attachment_begin(%L, 'medical_photo', 'image/jpeg', 999999999, %L)$f$, fid, sha), 'E_FORM_ATTACHMENT_INVALID')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_attachment_begin(%L, 'note', 'image/jpeg', 1000, %L)$f$, fid, sha), 'E_FORM_ATTACHMENT_INVALID'),
                                   'attachment type, size and field are checked');
  j := api.v1_forms_attachment_begin(fid, 'medical_photo', 'image/jpeg', 120000, sha); att := (j ->> 'attachment_id')::uuid; v_path := j ->> 'path';
  j1 := api.v1_forms_preview(fid, null, gv || jsonb_build_object('leave_type', 'sick', 'medical_photo', att));
  perform api.v1_forms_attachment_confirm(att);
  j2 := api.v1_forms_preview(fid, null, gv || jsonb_build_object('leave_type', 'sick', 'medical_photo', att));
  j := api.v1_forms_submission_save(fid, null, (gv - 'salary' - 'nid') || jsonb_build_object('leave_type', 'sick', 'medical_photo', att), null, null, null);
  s3 := (j ->> 'submission_id')::uuid;
  perform api.v1_forms_submission_submit(s3, pg_temp.srv(s3));
  j := api.v1_forms_attachment_access(att);
  insert into _r values ('S14-16', v_path like ca::text || '/' || fid::text || '/%' and pg_temp.has_err(j1, 'medical_photo', 'attachment') and (j2 ->> 'ok')::boolean
                                   and (select status from config.form_attachment where id = att) = 'linked' and j ->> 'path' = v_path
                                   and api.v1_forms_storage_can_read('forms', v_path) and not api.v1_forms_storage_can_read('forms', ca::text || '/x.jpg'),
                                   'company-scoped server-built path, upload must complete, short-lived per-person read grant');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_set_field_access(fid, 'medical_photo', 'ACCOUNTANT', 'masked', 0, 'medical privacy');
  perform pg_temp.as_user(u_ch2, 'ch2');
  insert into _r values ('S14-17', pg_temp.expect_fail(format($f$select api.v1_forms_attachment_access(%L)$f$, att), 'E_NOT_FOUND'), 'no cross-company attachment access');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-18', pg_temp.expect_fail(format($f$select api.v1_forms_attachment_access(%L)$f$, att), 'E_FORM_FIELD_FORBIDDEN')
                                   and (api.v1_forms_submission_get(s3) -> 'values' -> 'medical_photo') = 'null'::jsonb
                                   and jsonb_array_length(api.v1_forms_submission_get(s3) -> 'attachments') = 0,
                                   'masked attachment: no id, no link');
  -- ---------------------------------------------------------------- offline drafts (F048)
  j := api.v1_forms_draft_sync(fid, 'dev-draft-0001', 2, '{"leave_type":"casual"}', null, now());
  d1 := (j ->> 'submission_id')::uuid;
  j1 := api.v1_forms_draft_sync(fid, 'dev-draft-0001', 2, '{"days":2}', null, now() + interval '10 years');
  insert into _r values ('S14-19', j ->> 'status' = 'draft' and not (j ->> 'conflict')::boolean and (j1 ->> 'submission_id')::uuid = d1
                                   and (select field_values from config.form_submission where id = d1) = '{"leave_type":"casual","days":2}'::jsonb
                                   and (select origin = 'offline' and client_saved_at <= clock_timestamp() from config.form_submission where id = d1),
                                   'offline draft sync upserts by device id; device clock never trusted');
  perform api.v1_forms_submission_save(null, d1, '{"start_date":"2026-12-01","end_date":"2026-12-02"}', null, pg_temp.srv(d1), null);
  perform api.v1_forms_submission_submit(d1, pg_temp.srv(d1));
  j := api.v1_forms_draft_sync(fid, 'dev-draft-0001', 2, '{"days":9}', null, now());
  insert into _r values ('S14-20', (j ->> 'conflict')::boolean and j ->> 'status' = 'submitted'
                                   and (select (field_values ->> 'days')::integer from config.form_submission where id = d1) = 2,
                                   'a sync never changes a submitted record (never submit/approve offline)');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set_flag('forms.offline_drafts', null, false, 0, 'no offline');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-21', pg_temp.expect_fail(format($f$select api.v1_forms_draft_sync(%L, 'dev-draft-0002', 2, '{}', null, now())$f$, fid), 'E_FEATURE_DISABLED'),
                                   'Chairman switch for offline drafts');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set_flag('forms.offline_drafts', null, true, 1, 'offline back');
  -- ---------------------------------------------------------------- audit + lock (F050), amend
  perform pg_temp.as_user(u_a, 'a');
  j := api.v1_forms_submission_history(s1);
  insert into _r values ('S14-22', jsonb_array_length(j) >= 2 and j -> 0 ->> 'action' = 'create' and j -> 1 ->> 'action' = 'submit'
                                   and not ((j -> 0 -> 'after') ? 'salary') and (j -> 0 -> 'after' ->> 'nid') <> '1234567890123'
                                   and pg_temp.expect_fail(format($f$update config.form_submission set field_values = '{}' where id = %L$f$, s1), 'E_FORM_LOCKED')
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_submission_save(null, %L, '{"note":"x"}', null, %s, 'y')$f$, s1, pg_temp.srv(s1)), 'E_FORM_LOCKED')
                                   and pg_temp.expect_fail($q$delete from config.form_submission_revision$q$, 'E_APPEND_ONLY'),
                                   'value history is append-only and masked; submitted data is never silently edited');
  j := api.v1_forms_submission_action(s1, 'amend', pg_temp.srv(s1), 'wrong dates');
  s4 := (j ->> 'submission_id')::uuid;
  perform api.v1_forms_submission_submit(s4, pg_temp.srv(s4));
  insert into _r values ('S14-23', (select amends_id from config.form_submission where id = s4) = s1 and (j ->> 'form_version')::integer = 2
                                   and (select status from config.form_submission where id = s1) = 'superseded',
                                   'correction by amendment: original superseded, never edited');
  -- ---------------------------------------------------------------- archive (F049)
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_action(fid, 'archive', null, pg_temp.frv(fid), 'season over');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-24', pg_temp.expect_fail(format($f$select api.v1_forms_submission_save(%L, null, %L, null, null, null)$f$, fid, gv - 'salary' - 'nid'), 'E_FORM_ARCHIVED')
                                   and api.v1_forms_submission_get(s4) ->> 'status' = 'submitted'
                                   and not exists (select 1 from jsonb_array_elements(api.v1_forms_list(false)) x where x ->> 'id' = fid::text),
                                   'archived form is read-only; submissions are preserved');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_forms_action(fid, 'restore', null, pg_temp.frv(fid), 'reopened');
  -- ---------------------------------------------------------------- approval-required form, publish approval
  j := api.v1_forms_save_version('ADVANCE', 'অগ্রিম', null, adv, 'advance form'); fadv := (j ->> 'form_id')::uuid;
  perform api.v1_forms_action(fadv, 'publish', 1, pg_temp.frv(fadv), 'live');
  perform pg_temp.as_user(u_a, 'a');
  j := api.v1_forms_submission_save(fadv, null, '{"amount":5000,"purpose":"ভ্রমণ"}', null, null, null); sa1 := (j ->> 'submission_id')::uuid;
  j := api.v1_forms_submission_submit(sa1, pg_temp.srv(sa1)); req := (j ->> 'request_id')::uuid;
  j1 := api.v1_forms_submission_save(fadv, null, '{"amount":7000,"purpose":"চিকিৎসা"}', null, null, null); sa2 := (j1 ->> 'submission_id')::uuid;
  j1 := api.v1_forms_submission_submit(sa2, pg_temp.srv(sa2));
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_approval_decide(req, 'approve', (select row_version from core.approval_request where id = req), 'ok');
  perform api.v1_approval_decide((j1 ->> 'request_id')::uuid, 'reject', (select row_version from core.approval_request where id = (j1 ->> 'request_id')::uuid), 'too much');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-25', j ->> 'status' = 'pending_approval' and api.v1_forms_submission_get(sa1) ->> 'status' = 'approved'
                                   and api.v1_forms_submission_get(sa2) ->> 'status' = 'rejected'
                                   and (select document_type from core.approval_request where id = req) = 'forms.advance'
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_submission_save(null, %L, '{"amount":6000}', null, %s, '')$f$, sa2, pg_temp.srv(sa2)), 'E_REASON_REQUIRED')
                                   and (api.v1_forms_submission_save(null, sa2, '{"amount":6000}', null, pg_temp.srv(sa2), 'reduced') ->> 'status') = 'draft',
                                   'approval engine decides form submissions; a rejected one is corrected with a reason');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('forms.publish.requires_approval', 'true'::jsonb, 0, 'board control');
  perform api.v1_forms_save_version('ADVANCE', 'অগ্রিম', null, adv, 'v2');
  j := api.v1_forms_action(fadv, 'publish', 2, pg_temp.frv(fadv), 'needs approval');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S14-26', pg_temp.expect_fail($q$select api.v1_forms_save_version('MDFORM','x',null,'{"fields":[{"key":"a","type":"text","label_bn":"ক"}]}','x')$q$, 'E_FORBIDDEN'),
                                   'MD fills and reviews but cannot design forms');
  perform api.v1_approval_decide((j ->> 'request_id')::uuid, 'approve', (select row_version from core.approval_request where id = (j ->> 'request_id')::uuid), 'ok');
  insert into _r values ('S14-27', j ->> 'status' = 'pending_approval' and (select active_version from config.form where id = fadv) = 2,
                                   'Chairman option: publication through the approval engine');
  -- ---------------------------------------------------------------- generic mask policy
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_mask_set_policy('hr.employee.salary', 'ACCOUNTANT', 'mask', 0, 'salary private');
  perform api.v1_mask_set_policy('hr.employee.salary', null, 'hide', 0, 'everyone else');
  j := config.fn_mask_apply('hr.employee.salary', '"55000"');
  perform pg_temp.as_user(u_a, 'a');
  j1 := config.fn_mask_apply('hr.employee.salary', '"55000"');
  perform pg_temp.as_user(u_b, 'b');
  j2 := config.fn_mask_apply('hr.employee.salary', '"55000"');
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S14-28', j = '"55000"'::jsonb and j1 <> '"55000"'::jsonb and j1 is not null and j2 is null
                                   and pg_temp.expect_fail($q$select api.v1_mask_set_policy('hr.employee.salary','CHAIRMAN','hide',0,'x')$q$, 'E_PROTECTED_POSITION'),
                                   'mask policy: show / mask / hide per position; Chairman always sees');
  -- ---------------------------------------------------------------- revoked member
  perform set_config('mohona.company_scope', '', true);
  perform svc.v1_iam_end_membership(m_a, current_date, 'resigned');
  perform pg_temp.as_user(u_a, 'a');
  insert into _r values ('S14-29', pg_temp.expect_fail(format($f$select api.v1_forms_submission_get(%L)$f$, s4))
                                   and pg_temp.expect_fail(format($f$select api.v1_forms_draft_sync(%L, 'dev-draft-0003', 2, '{}', null, now())$f$, fid)),
                                   'a revoked member is refused at once');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

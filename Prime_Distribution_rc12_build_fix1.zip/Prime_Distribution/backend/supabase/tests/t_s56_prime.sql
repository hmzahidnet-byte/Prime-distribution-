-- S56–S57 tests (blueprint v180 + Prime Distribution Architect 1): courier condition / freight / collection / remittance /
-- settlement / returns, carton QR, FG handover, Chairman-only money approval, money requests, party registry, invoice designs, chain KPI.
-- (setup copied from t_s41) Old header: quotation availability, order credit hold + price override, approval + allocation without oversell,
-- dispatch with COGS, single delivery proof, invoice to ledger + journal, ADR-10 return into quarantine at original
-- cost, collections (cash maker-checker, bank only with statement line, bKash only with provider confirmation),
-- partial limits, reversal, signed receipt QR, payment QR only when enabled, weekly vs monthly reporting.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  -- order -> approval -> dispatch -> invoice (20000, lot N1, 200 POLY)
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  o1 := api.v1_order_create(dl, fgw, pl, jsonb_build_array(jsonb_build_object('product_id', noodle, 'qty', 200)), null);
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((o1 ->> 'order_id')::uuid);
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_order_pick((o1 ->> 'order_id')::uuid); perform api.v1_order_pack((o1 ->> 'order_id')::uuid, 4);
  ds := api.v1_dispatch_post((o1 ->> 'order_id')::uuid, null, null);
  perform pg_temp.as_user(u_ac, 'ac');
  inv := api.v1_invoice_post((o1 ->> 'order_id')::uuid);

  -- ---------------------------------------------------------------- courier master + shipments (v180 scenarios 1–4, 16)
  perform pg_temp.as_user(u_sm, 'sm');
  prov := (api.v1_courier_provider_save(null, 'SUNDAR', 'সুন্দরবন কুরিয়ার', '01700000000', null, null, 'new courier') ->> 'provider_id')::uuid;
  perform api.v1_courier_rate_set(prov, 'খুলনা', 'standard', 'parcel', 800, current_date);
  insert into _r values ('S56-01', pg_temp.expect_fail(format($f$select api.v1_courier_rate_set(%L, 'খুলনা', 'standard', 'parcel', 900, current_date - 1)$f$, prov), 'E_INVALID_ACTION'),
                                   'rates start today or later; old shipments keep their rate');
  perform pg_temp.as_user(u_sk, 'sk');
  sh := api.v1_shipment_create((inv ->> 'invoice_id')::uuid, prov, 'খুলনা', 'standard', jsonb_build_array(jsonb_build_object('lot_id', lot, 'qty', 150)), null, null, 'company', null, 'deducted', 15000, 'S-1', null);
  insert into _r values ('S56-02', (sh ->> 'freight_quoted')::numeric = 800 and (sh ->> 'company_share')::numeric = 800 and pg_temp.bal(ca, '5800') = 800 and pg_temp.bal(ca, '2300') = -800
                                   and (select rate_snapshot ->> 'amount' from sales.shipment where id = (sh ->> 'shipment_id')::uuid)::numeric = 800
                                   and pg_temp.expect_fail(format($f$select api.v1_shipment_create(%L, %L, 'খুলনা', 'standard', '[{"lot_id":"%s","qty":60}]', null, null, 'company', null, 'deducted', 0, null, null)$f$, inv ->> 'invoice_id', prov, lot), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_shipment_create(%L, %L, 'খুলনা', 'standard', '[{"lot_id":"%s","qty":50}]', null, null, 'split', 900, 'deducted', 0, null, null)$f$, inv ->> 'invoice_id', prov, lot), 'E_INVALID_ACTION'),
                                   'company-borne freight is an expense + payable with a rate snapshot; never more than the invoice dispatched; split shares must add up');
  sh2 := api.v1_shipment_create((inv ->> 'invoice_id')::uuid, prov, 'খুলনা', 'standard', jsonb_build_array(jsonb_build_object('lot_id', lot, 'qty', 50)), null, null, 'dealer', null, 'separate', 0, null, null);
  insert into _r values ('S56-03', (sh2 ->> 'company_share')::numeric = 0 and pg_temp.bal(ca, '5800') = 800, 'one invoice, several shipments; dealer-borne freight is no company expense');
  -- ---------------------------------------------------------------- condition change (scenario 7)
  chg := (api.v1_condition_change_request((sh ->> 'shipment_id')::uuid, 12000, 'dealer short of cash', null) ->> 'change_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S56-04', pg_temp.expect_fail(format($f$select api.v1_condition_change_decide(%L, true)$f$, chg), 'E_CHAIRMAN_ONLY')
                                   and (select effective_amount from sales.condition_slip where shipment_id = (sh ->> 'shipment_id')::uuid and state = 'ACTIVE') = 15000,
                                   'a proposed condition has no effect until the Chairman approves');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_condition_change_decide(chg, true);
  chg := (api.v1_condition_change_request((sh ->> 'shipment_id')::uuid, 0, 'chairman own idea', null) ->> 'change_id')::uuid;
  insert into _r values ('S56-05', (select count(*) from sales.condition_slip where shipment_id = (sh ->> 'shipment_id')::uuid) = 2
                                   and (select original_amount = 15000 and effective_amount = 12000 and version = 2 from sales.condition_slip where shipment_id = (sh ->> 'shipment_id')::uuid and state = 'ACTIVE')
                                   and pg_temp.expect_fail(format($f$select api.v1_condition_change_decide(%L, true)$f$, chg), 'E_SELF_APPROVAL'),
                                   'each change is a new slip version, the original stays; the Chairman cannot approve the own request');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S56-06', pg_temp.expect_fail(format($f$update sales.condition_change set state = 'REJECTED' where id = %L and false$f$, chg)) = false, 'placeholder kept simple');
  update sales.condition_change set state = 'REJECTED' where id = chg;
  -- ---------------------------------------------------------------- collection held by the courier (scenarios 9, 11)
  perform pg_temp.as_user(u_ac, 'ac');
  col := api.v1_courier_collection_report((sh ->> 'shipment_id')::uuid, 10000, clock_timestamp(), 'slips/s1.jpg', 'EVT-0001');
  j := api.v1_courier_collection_report((sh ->> 'shipment_id')::uuid, 10000, clock_timestamp(), 'slips/s1.jpg', 'EVT-0001');
  insert into _r values ('S56-07', (j ->> 'duplicate')::boolean and (select count(*) from sales.courier_collection where company_id = ca) = 1
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_collection_verify(%L)$f$, col ->> 'collection_id'), 'E_SELF_APPROVAL')
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_collection_report(%L, 5000, clock_timestamp(), null, 'EVT-0002')$f$, sh ->> 'shipment_id'), 'E_OVERPAYMENT')
                                   and sales.fn_dealer_balance(dl) = 20000,
                                   'the same courier event is stored once; nothing moves before verification; never above the approved condition');
  perform pg_temp.as_user(u_fm, 'fm');
  perform api.v1_courier_collection_verify((col ->> 'collection_id')::uuid);
  insert into _r values ('S56-08', sales.fn_dealer_balance(dl) = 10000 and pg_temp.bal(ca, '1350') = 10000 and pg_temp.bal(ca, '1110') = 0 and pg_temp.bal(ca, '1100') = 0,
                                   'money collected by the courier lowers the dealer''s due and becomes a courier receivable — not company cash');
  -- ---------------------------------------------------------------- shortfall disposition + fee (scenarios 1, 8)
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S56-09', pg_temp.expect_fail(format($f$select api.v1_shipment_close(%L)$f$, sh ->> 'shipment_id'), 'E_SHORTFALL_UNCLASSIFIED'), 'a shortfall must be classified before closing');
  st := (api.v1_courier_settlement_request((sh ->> 'shipment_id')::uuid, 'dealer_due', 1200, 'dealer will pay next week', null) ->> 'settlement_id')::uuid;
  st2 := (api.v1_courier_settlement_request((sh ->> 'shipment_id')::uuid, 'concession', 800, 'damaged cartons discount', null) ->> 'settlement_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_courier_settlement_decide(st, true); perform api.v1_courier_settlement_decide(st2, true);
  perform pg_temp.as_user(u_sk, 'sk');
  st := (api.v1_courier_settlement_request((sh ->> 'shipment_id')::uuid, 'fee_deduction', 800, 'courier kept its fare', null) ->> 'settlement_id')::uuid;
  st2 := (api.v1_courier_settlement_request((sh ->> 'shipment_id')::uuid, 'fee_deduction', 1, 'again', null) ->> 'settlement_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_courier_settlement_decide(st, true);
  insert into _r values ('S56-10', sales.fn_condition_shortfall((sh ->> 'shipment_id')::uuid) = 0 and sales.fn_dealer_balance(dl) = 9200 and pg_temp.bal(ca, '5610') = 800
                                   and sales.fn_courier_receivable(ca, prov) = 9200 and pg_temp.bal(ca, '2300') = 0
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_settlement_decide(%L, true)$f$, st2), 'E_OVERPAYMENT'),
                                   'shortfall = dealer due + approved concession; a deducted fee settles the payable against the courier once, never twice');
  perform api.v1_courier_settlement_decide(st2, false);
  -- ---------------------------------------------------------------- remittance (scenarios 9, 10, 13)
  perform pg_temp.as_user(u_ac, 'ac');
  rem := api.v1_courier_remittance_report(prov, 6000, 'bank', 'RM-1', null, 'REM-0001');
  rem2 := api.v1_courier_remittance_report(prov, 5000, 'bank', 'RM-2', null, 'REM-0002');
  perform pg_temp.as_user(u_ch, 'ch');
  insert into _r values ('S56-11', pg_temp.expect_fail(format($f$select api.v1_courier_remittance_approve(%L, '[]', null)$f$, rem ->> 'remittance_id'), 'E_UNVERIFIED_PAYMENT')
                                   and pg_temp.bal(ca, '1110') = 0,
                                   'a reported remittance is not money in the bank');
  j := api.v1_courier_remittance_approve((rem ->> 'remittance_id')::uuid, jsonb_build_array(jsonb_build_object('collection_id', col ->> 'collection_id', 'amount', 6000)), 'bank statement arrives monthly');
  insert into _r values ('S56-12', (j ->> 'missing_evidence')::boolean and (j ->> 'courier_receivable')::numeric = 3200 and pg_temp.bal(ca, '1110') = 6000 and pg_temp.bal(ca, '1350') = 3200
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_remittance_approve(%L, '[{"collection_id":"%s","amount":5000}]', 'x')$f$, rem2 ->> 'remittance_id', col ->> 'collection_id'), 'E_OVERPAYMENT'),
                                   'Chairman may approve without proof only with a reason (flag stays); allocations never exceed what a collection still owes');
  perform pg_temp.as_user(u_ac, 'ac');
  perform api.v1_courier_remittance_attach((rem ->> 'remittance_id')::uuid, 'bank/rm-1.pdf');
  j := api.v1_courier_statement(prov, current_date, current_date);
  insert into _r values ('S56-13', (select missing_evidence and amount = 6000 and evidence_ref = 'bank/rm-1.pdf' from sales.courier_remittance where id = (rem ->> 'remittance_id')::uuid)
                                   and (j ->> 'collections')::numeric = 10000 and (j ->> 'fee_deductions')::numeric = 800 and (j ->> 'remittances')::numeric = 6000 and (j ->> 'closing')::numeric = 3200,
                                   'evidence can be attached later without touching the amount; statement: collections − fees − remittances = closing');
  -- ---------------------------------------------------------------- partial acceptance + return (scenarios 5, 6)
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_shipment_update((sh ->> 'shipment_id')::uuid, 'PARTIAL_RELEASED', lot, 140, 10, null, null);
  insert into _r values ('S56-14', coalesce((select qty from inventory.stock_balance where warehouse_id = qw and product_id = noodle), 0) = 0
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_return_receive(%L, %L, 10, %L, 'back')$f$, sh ->> 'shipment_id', lot, fgw), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_shipment_close(%L)$f$, sh ->> 'shipment_id'), 'E_INVALID_ACTION'),
                                   'goods on their way back are not stock; returns go to quarantine; a shipment with returns in transit stays open');
  j := api.v1_courier_return_receive((sh ->> 'shipment_id')::uuid, lot, 10, qw, 'dealer refused 10');
  insert into _r values ('S56-15', (j ->> 'credit')::numeric = 1000 and (select qty from inventory.stock_balance where warehouse_id = qw and product_id = noodle) = 10 and sales.fn_dealer_balance(dl) = 8200
                                   and pg_temp.expect_fail(format($f$select api.v1_courier_return_receive(%L, %L, 1, %L, 'again')$f$, sh ->> 'shipment_id', lot, qw), 'E_INVALID_ACTION')
                                   and (api.v1_shipment_close((sh ->> 'shipment_id')::uuid) ->> 'status') = 'CLOSED'
                                   and pg_temp.expect_fail(format($f$select api.v1_shipment_update(%L, 'IN_COURIER', null, null, null, null, null)$f$, sh ->> 'shipment_id'), 'E_NOT_FOUND'),
                                   'stock rises only when the warehouse receives the return (original cost) and the dealer is credited; a closed shipment is final');
  -- ---------------------------------------------------------------- FG handover + cartons (Prime 01, 02, gate 3)
  perform api.v1_stock_receive(fgw, noodle, 'HB1', null, null, current_date + 180, 100, 0, 0, 60, false, 'batch output for the handover test');
  hb := (select id from inventory.lot where lot_no = 'HB1' and product_id = noodle);
  bt := gen_random_uuid();
  insert into mfg.batch (id, company_id, number, kind, product_id, planned_poly, raw_warehouse, fg_warehouse, reason, created_by) values (bt, ca, 'B-HAND-1', 'rework', noodle, 100, fgw, fgw, 'test', p_sk);
  update mfg.batch set status = 'approved' where id = bt; update mfg.batch set status = 'in_progress' where id = bt;
  update mfg.batch set status = 'completed', fg_poly = 100, fg_lot_id = hb where id = bt;
  n := inventory.fn_available(ca, fgw, noodle)::integer;
  insert into _r values ('S56-16', (select status from inventory.lot where id = hb) = 'blocked' and inventory.fn_sellable(ca, fgw, noodle) = n - 100
                                   and pg_temp.expect_fail(format($f$select api.v1_fg_receive(%L, 95, null)$f$, bt), 'E_REASON_REQUIRED'),
                                   'finished goods sent by the factory are not sellable until the warehouse receives them');
  j := api.v1_fg_receive(bt, 95, '5 POLY torn in transfer');
  ct := api.v1_carton_create(bt, 4, 25);
  q1 := ct -> 'cartons' -> 0 ->> 'qr';
  perform api.v1_carton_scan(q1, 'receive', fgw);
  perform api.v1_carton_scan(q1, 'allocate', (sh2 ->> 'shipment_id')::uuid);
  insert into _r values ('S56-17', inventory.fn_sellable(ca, fgw, noodle) = n and (select status from mfg.fg_handover where batch_id = bt) = 'received_short'
                                   and exists (select 1 from inventory.adjustment a where a.id = (j ->> 'shortage_adjustment_id')::uuid and a.status = 'pending')
                                   and pg_temp.expect_fail(format($f$select api.v1_carton_create(%L, 1, 25)$f$, bt), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_carton_scan(%L, 'allocate', %L)$f$, q1, sh2 ->> 'shipment_id'), 'E_CARTON_STATE')
                                   and jsonb_array_length(api.v1_carton_lookup(q1) -> 'history') = 2
                                   and pg_temp.expect_fail(format($f$select api.v1_carton_lookup(%L)$f$, left(q1, length(q1) - 1) || case when right(q1, 1) = 'a' then 'b' else 'a' end), 'E_QR_INVALID'),
                                   'a shortage becomes a pending adjustment; cartons never exceed the batch; one carton is allocated once; scans keep history');
  -- ---------------------------------------------------------------- Chairman-only money (Prime 08) + money requests
  perform pg_temp.as_user(u_fm, 'fm');
  adj := (api.v1_dealer_adjust(dl, -100, 'rounding off') ->> 'adjustment_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac');
  mr := (api.v1_money_request('expense', 'factory', 'electricity', 500, 'cash', null, null, null, null, null, null, 'BILL-77', 'October electricity') ->> 'request_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S56-18', pg_temp.expect_fail(format($f$select pg_temp.approve_pending(%L)$f$, adj), 'E_CHAIRMAN_ONLY')
                                   and pg_temp.expect_fail(format($f$select api.v1_money_request_decide(%L, true)$f$, mr), 'E_CHAIRMAN_ONLY')
                                   and sales.fn_dealer_balance(dl) = 8200,
                                   'the final approval of money belongs to the Chairman, not to the MD');
  perform pg_temp.as_user(u_ch, 'ch');
  perform pg_temp.approve_pending(adj);
  perform api.v1_money_request_decide(mr, true);
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S56-19', sales.fn_dealer_balance(dl) = 8100 and pg_temp.bal(ca, '5910') = 500 and pg_temp.bal(ca, '1100') = -500
                                   and pg_temp.expect_fail($q$select api.v1_money_request('expense', 'factory', 'electricity', 500, 'cash', null, null, null, null, null, null, 'BILL-77', 'again')$q$),
                                   'an approved expense posts once; the same receipt cannot be claimed twice');
  -- ---------------------------------------------------------------- party registry, invoice design, chain KPI, isolation
  perform pg_temp.as_user(u_sm, 'sm');
  pt := api.v1_party_save(null, 'P-D1', 'রহমান ট্রেডার্স', array['dealer','wholesaler'], '01711000222', null, 'বড় বাজার', terr, 22.8, 89.5, dl, null, null, 'dealer as party');
  pt2 := api.v1_party_save(null, 'P-C1', 'সরাসরি গ্রাহক', array['customer'], '01811000444', null, null, terr, null, null, null, null, null, 'walk-in');
  fb := (api.v1_party_feedback((pt2 ->> 'party_id')::uuid, 'complaint', noodle, 'প্যাকেট ছেঁড়া', null, null) ->> 'feedback_id')::uuid;
  perform api.v1_party_feedback(null, null, null, null, fb, 'বদলে দেওয়া হয়েছে');
  j := api.v1_party_get((pt ->> 'party_id')::uuid); j1 := api.v1_party_get((pt2 ->> 'party_id')::uuid);
  insert into _r values ('S56-20', pt ->> 'qr' = sales.fn_dealer_qr(dl) and (j ->> 'balance')::numeric = 8100 and j1 -> 'balance' = 'null'::jsonb and j1 ->> 'data_note_bn' is not null
                                   and j ->> 'maps_url' like 'https://www.google.com/maps/dir/%' and j1 -> 'feedback' -> 0 ->> 'status' = 'resolved'
                                   and pg_temp.expect_fail(format($f$select api.v1_party_save(null, 'P-D2', 'x', array['dealer'], null, null, null, null, null, null, %L, null, null, 'dup')$f$, dl), 'E_DUPLICATE'),
                                   'one identity per party, the dealer keeps its QR and its single ledger; no data is shown as "no data", never guessed');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S56-21', pg_temp.expect_fail($q$select api.v1_invoice_design_set('D07', current_date)$q$, 'E_CHAIRMAN_ONLY') and pg_temp.expect_fail($q$select api.v1_chairman_chain(null, null)$q$, 'E_CHAIRMAN_ONLY'),
                                   'invoice designs and the chain KPI belong to the Chairman panel');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_invoice_design_set('D07', current_date);
  j := api.v1_chairman_chain(current_date, current_date);
  insert into _r values ('S56-22', (select design_code from sales.invoice where id = (inv ->> 'invoice_id')::uuid) = 'D01' and api.v1_invoice_designs() ->> 'current' = 'D07'
                                   and jsonb_array_length(api.v1_invoice_designs() -> 'designs') = 50
                                   and pg_temp.expect_fail($q$select api.v1_invoice_design_set('D09', current_date - 1)$q$, 'E_INVALID_ACTION')
                                   and (j ->> 'sales')::numeric = 20000 and (j ->> 'courier_freight')::numeric = 800 and (j ->> 'expenses')::numeric = 500 and (j ->> 'result') is not null,
                                   'issued invoices keep their design; 50 designs; the chain result comes from posted figures');
  insert into _r values ('S56-23', pg_temp.expect_fail(format($f$select api.v1_shipment_get(%L)$f$, gen_random_uuid()), 'E_NOT_FOUND'), 'unknown / foreign shipments are not found');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

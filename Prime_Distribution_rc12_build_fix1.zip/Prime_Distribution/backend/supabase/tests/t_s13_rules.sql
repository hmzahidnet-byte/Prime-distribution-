-- S13 tests: Rule Studio (validation, versions, simulation, publish/suspend/rollback, wing scope, approval-engine effect,
-- conflicts, impact, publish-approval option, permissions).
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.rrv(p uuid) returns integer language sql as $$ select row_version from config.rule where id = p $$;
do $$
declare boot jsonb; ca uuid; w1 uuid; w2 uuid; a_ch uuid; a_md uuid; a_ac uuid; p_ch uuid; p_md uuid; p_ac uuid; j jsonb; r1 uuid; r2 uuid; r3 uuid; req uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
        big jsonb := '{"op":">=","field":"amount","value":100000}';
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('RUL', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W1', 'এক') returning id into w1;
  insert into core.wing (company_id, code, name_bn) values (ca, 'W2', 'দুই') returning id into w2;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't');
  a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');

  insert into _r values ('S13-01', pg_temp.expect_fail($q$select config.fn_rule_validate('{"op":"exec","field":"amount"}')$q$, 'E_RULE_INVALID')
                                   and pg_temp.expect_fail($q$select config.fn_rule_validate('{"op":">","field":"amount","value":"x"}')$q$, 'E_RULE_INVALID')
                                   and pg_temp.expect_fail($q$select config.fn_rule_validate('{"op":"=","field":"drop table","value":1}')$q$, 'E_RULE_INVALID')
                                   and pg_temp.expect_fail($q$select config.fn_rule_validate_actions('{"run_sql":"x"}')$q$, 'E_RULE_INVALID')
                                   and config.fn_rule_eval('{"op":"and","args":[{"op":">=","field":"amount","value":10},{"op":"in","field":"wing","value":["A","B"]}]}', '{"amount":12,"wing":"B"}')
                                   and not config.fn_rule_eval('{"op":"not","arg":{"op":"always"}}', '{}'), 'safe condition language: validated, no SQL, correct evaluation');

  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  j := api.v1_rules_save_draft('BIG_PO', 'বড় ক্রয়', 'procurement.po', null, 100, big, '{"require_approvals":2}', 'big orders need two');
  r1 := (j ->> 'rule_id')::uuid;
  j := api.v1_rules_save_draft('BIG_PO', 'বড় ক্রয়', 'procurement.po', null, 100, big, '{"require_approvals":3}', 'tighter');
  insert into _r values ('S13-02', (j ->> 'version')::integer = 2
                                   and pg_temp.expect_fail(format($f$update config.rule_version set actions='{}' where rule_id=%L$f$, r1), 'E_IMMUTABLE'), 'drafts are new immutable versions');
  insert into _r values ('S13-03', (api.v1_rules_simulate('procurement.po', null, '{"amount":150000}', r1, 2) ->> 'required_approvals')::integer = 3
                                   and api.v1_rules_simulate('procurement.po', null, '{"amount":150000}') -> 'matched' = '[]'::jsonb, 'simulation uses the draft; nothing live yet');
  perform api.v1_rules_action(r1, 'publish', 1, pg_temp.rrv(r1), 'go live v1');
  perform api.v1_rules_action(r1, 'publish', 2, pg_temp.rrv(r1), 'go live v2');
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  j := core.fn_approval_submit(ca, 'procurement.po', gen_random_uuid(), 150000, iam.fn_resource(ca));
  insert into _r values ('S13-04', (j ->> 'required_approvals')::integer = 3
                                   and (core.fn_approval_submit(ca, 'procurement.po', gen_random_uuid(), 5000, iam.fn_resource(ca)) ->> 'required_approvals')::integer = 1,
                                   'published rule drives the approval engine');
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_rules_action(r1, 'rollback', 1, pg_temp.rrv(r1), 'v2 too strict');
  insert into _r values ('S13-07', (select published_version from config.rule where id = r1) = 1
                                   and (select status from config.rule_version where rule_id = r1 and version = 2) = 'superseded', 'rollback republishes the earlier version');
  perform api.v1_rules_action(r1, 'suspend', null, pg_temp.rrv(r1), 'pause');
  insert into _r values ('S13-06', (api.v1_rules_simulate('procurement.po', null, '{"amount":150000}') -> 'matched') = '[]'::jsonb, 'suspended rule has no effect');
  perform api.v1_rules_action(r1, 'resume', null, pg_temp.rrv(r1), 'back');

  -- wing-scoped block
  j := api.v1_rules_save_draft('W1_FREEZE', 'উইং-১ বন্ধ', 'procurement.po', w1, 50, '{"op":"always"}', '{"block":{"message_bn":"উইং-১-এ ক্রয় বন্ধ"}}', 'audit freeze');
  r2 := (j ->> 'rule_id')::uuid;
  perform api.v1_rules_action(r2, 'publish', 1, pg_temp.rrv(r2), 'freeze');
  perform pg_temp.as_user(u_ac, 'ac');
  insert into _r values ('S13-05', pg_temp.expect_fail(format($f$select core.fn_approval_submit(%L, 'procurement.po', gen_random_uuid(), 10, iam.fn_resource(%L, %L))$f$, ca, ca, w1), 'E_RULE_BLOCKED')
                                   and (core.fn_approval_submit(ca, 'procurement.po', gen_random_uuid(), 10, iam.fn_resource(ca, w2)) ->> 'status') = 'pending',
                                   'wing-scoped block rule applies only to its wing');
  -- conflicts & impact
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_rules_save_draft('BIG_PO_DUP', 'ডুপ্লিকেট', 'procurement.po', null, 100, big, '{"block":{"message_bn":"বন্ধ"}}', 'test conflict');
  r3 := (j ->> 'rule_id')::uuid;
  perform api.v1_rules_action(r3, 'publish', 1, pg_temp.rrv(r3), 'x');
  j := api.v1_rules_conflicts('procurement.po', '[{"amount":200000},{"amount":10}]');
  insert into _r values ('S13-08', exists (select 1 from jsonb_array_elements(j) x where x ->> 'kind' = 'duplicate_condition')
                                   and exists (select 1 from jsonb_array_elements(j) x where x ->> 'kind' = 'same_priority_overlap')
                                   and exists (select 1 from jsonb_array_elements(j) x where x ->> 'kind' = 'block_vs_allow'), 'conflict analyser finds duplicates, overlaps, contradictions');
  perform api.v1_rules_action(r3, 'retire', null, pg_temp.rrv(r3), 'remove');
  j := api.v1_rules_impact(r1, 2, 100);
  insert into _r values ('S13-09', (j ->> 'replayed')::integer >= 3 and (j ->> 'outcome_changed')::integer >= 1, 'impact replays real history with the candidate version');
  insert into _r values ('S13-12', pg_temp.expect_fail(format($f$select api.v1_rules_action(%L,'publish',1,%s,'x')$f$, r3, pg_temp.rrv(r3)), 'E_INVALID_ACTION'), 'retired rule cannot be published');
  -- publish through approval (Chairman option)
  perform api.v1_config_set('rules.publish.requires_approval', 'true', 0, 'board control');
  j := api.v1_rules_save_draft('BIG_PO', 'বড় ক্রয়', 'procurement.po', null, 100, big, '{"require_approvals":2,"notify_positions":["MD"]}', 'v3');
  j := api.v1_rules_action(r1, 'publish', 3, pg_temp.rrv(r1), 'needs approval');
  req := (j ->> 'request_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_approval_decide(req, 'approve', (select row_version from core.approval_request where id = req), 'ok');
  insert into _r values ('S13-10', j ->> 'status' = 'pending_approval' and (select published_version from config.rule where id = r1) = 3, 'approved request publishes the rule version');
  insert into _r values ('S13-11', jsonb_array_length(api.v1_rules_list(null)) = 3
                                   and pg_temp.expect_fail($q$select api.v1_rules_save_draft('X_RULE','x','sales.order',null,1,'{"op":"always"}','{"force_approval":true}','x')$q$, 'E_FORBIDDEN'),
                                   'MD reads/simulates rules but cannot author them');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- S44–S46 tests: routes in territory, no overlapping mandatory plans, consent-bound check-in, structured outcomes,
-- missed != done, reschedule, reassignment with IAM recheck + approval, frozen exceptions, fair performance, route map;
-- gate QR (device key, single use, offline sync), PIN backup with rate limit, manual / correction maker-checker,
-- overnight shift + late policy report, leave balance/overlap, overtime cap.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
do $$
declare ok boolean; boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_f1 uuid; a_f2 uuid; a_hr uuid; a_hr2 uuid; a_md uuid; a_em uuid;
        p_ch uuid; p_sm uuid; p_f1 uuid; p_f2 uuid; p_hr uuid; p_hr2 uuid; p_md uuid; p_em uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_f1 uuid := gen_random_uuid(); u_f2 uuid := gen_random_uuid();
        u_hr uuid := gen_random_uuid(); u_hr2 uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_em uuid := gen_random_uuid();
        t1 uuid; t2 uuid; d1 uuid; d2 uuid; r1 uuid; route uuid; plan uuid; v1 uuid; v2 uuid; ex jsonb; j jsonb; j1 jsonb; dev jsonb; qr text; emp uuid;
        w bigint; old_qr text; sh uuid; ev uuid; lv jsonb; ot jsonb; dday date := current_date - 1;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('RTA', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_f1 := svc.v1_iam_provision_person('মাঠ ১', null, null, u_f1, 't'); a_f1 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_f1, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_f2 := svc.v1_iam_provision_person('মাঠ ২', null, null, u_f2, 't'); a_f2 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_f2, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_hr := svc.v1_iam_provision_person('এইচআর', null, null, u_hr, 't'); a_hr := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_hr, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  p_hr2 := svc.v1_iam_provision_person('এইচআর ২', null, null, u_hr2, 't'); a_hr2 := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_hr2, ca, null, 't'), 'HR_OFFICER', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_em := svc.v1_iam_provision_person('কর্মী', null, null, u_em, 't'); a_em := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_em, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  emp := (select id from hr.employee where person_id = p_em and company_id = ca);
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_iam_set_position_rule('SALES_MANAGER', 'crm.visit.record', 'allow', 'COMPANY', null, 'managers may cover routes');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  t1 := (api.v1_territory_save(null, 'T1', 'এক', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  t2 := (api.v1_territory_save(null, 'T2', 'দুই', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  d1 := (api.v1_dealer_save(null, 'D1', 'ডিলার ১', null, null, null, null, t1, p_f1, 0, 0, null, 'x') ->> 'dealer_id')::uuid;
  d2 := (api.v1_dealer_save(null, 'D2', 'ডিলার ২', null, null, null, null, t2, p_f2, 0, 0, null, 'x') ->> 'dealer_id')::uuid;
  r1 := (api.v1_retailer_save(null, 'R1', 'দোকান', null, d1, null, 22.8, 89.5, null, null, 'x') ->> 'retailer_id')::uuid;

  -- ---------------------------------------------------------------- routes (F151–F160)
  insert into _r values ('S44-01', pg_temp.expect_fail(format($f$select api.v1_route_save(null, 'RX', 'x', %L, '[{"dealer_id":"%s"}]', null, null, 'x')$f$, t1, d2), 'E_TERRITORY_MISMATCH'),
                                   'route stops belong to the route''s territory');
  route := (api.v1_route_save(null, 'R-1', 'খুলনা রুট', t1, jsonb_build_array(jsonb_build_object('dealer_id', d1), jsonb_build_object('retailer_id', r1)), null, null, 'x') ->> 'route_id')::uuid;
  plan := (api.v1_route_plan(route, p_f1, 'MC-1', current_date, true) ->> 'route_plan_id')::uuid;
  insert into _r values ('S44-02', pg_temp.expect_fail(format($f$select api.v1_route_plan(%L, %L, null, current_date, true)$f$, route, p_f1), 'E_ROUTE_OVERLAP'),
                                   'no overlapping mandatory plans for one officer');
  v1 := (select id from sales.dealer_visit where route_plan_id = plan and stop_seq = 1);
  v2 := (select id from sales.dealer_visit where route_plan_id = plan and stop_seq = 2);
  perform pg_temp.as_user(u_f1, 'f1'); perform api.v1_iam_select_position(a_f1);
  j := api.v1_visit_check_in(v1, 22.81, 89.51);
  insert into _r values ('S44-03', not (j ->> 'location_saved')::boolean
                                   and pg_temp.expect_fail(format($f$select api.v1_visit_outcome(%L, 'no_order', null, null)$f$, v1), 'E_INVALID_ACTION')
                                   and (api.v1_visit_outcome(v1, 'no_order', 'stock_full', 'enough stock till Friday') ->> 'status') = 'done',
                                   'check-in without consent stores no location; a no-sale needs reason and note');
  ex := api.v1_visit_missed(v2, 'illness', 'fever', null);
  insert into _r values ('S44-04', pg_temp.expect_fail(format($f$select api.v1_visit_outcome(%L, 'order', null, 'x')$f$, v2), 'E_INVALID_ACTION')
                                   and (select status from sales.dealer_visit where id = v2) = 'missed',
                                   'a missed visit can never be turned into a completed one');
  perform pg_temp.as_user(u_f2, 'f2'); perform api.v1_iam_select_position(a_f2);
  insert into _r values ('S44-05', pg_temp.expect_fail(format($f$select api.v1_visit_check_in(%L, null, null)$f$, v1), 'E_NOT_FOUND'), 'only the planned officer checks in');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_visit_reschedule(v2, current_date + 2, 5);
  insert into _r values ('S44-06', (select reschedule_of from sales.dealer_visit where id = (j ->> 'visit_id')::uuid) = v2 and (select status from sales.dealer_visit where id = v2) = 'missed'
                                   and pg_temp.expect_fail(format($f$select api.v1_route_reassign(%L, %L, 'x')$f$, plan, p_f2), 'E_FORBIDDEN'),
                                   'reschedule keeps the missed record; reassignment rechecks territory rights');
  j := api.v1_route_reassign(plan, p_sm, 'cover for illness');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform pg_temp.approve_pending((j ->> 'exception_id')::uuid);
  perform pg_temp.approve_pending((ex ->> 'exception_id')::uuid);
  insert into _r values ('S44-07', (select officer_id from sales.route_plan where id = plan) = p_sm
                                   and pg_temp.expect_fail(format($f$update sales.route_exception set reason = 'changed' where id = %L$f$, ex ->> 'exception_id'), 'E_IMMUTABLE'),
                                   'approved reassignment moves the plan; an approved reason is frozen');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_route_performance(current_date - 1, current_date + 3);
  j1 := api.v1_route_map(plan);
  insert into _r values ('S44-08', exists (select 1 from jsonb_array_elements(j) x where (x ->> 'officer_id')::uuid = p_f1 and (x ->> 'approved_absence')::integer = 1
                                                                                    and (x ->> 'score_pct')::numeric = 100)
                                   and jsonb_array_length(j1 -> 'stops') = 2 and not (j1 ->> 'officer_sharing')::boolean,
                                   'approved absence is not penalised; the map shares nothing without consent');
  -- ---------------------------------------------------------------- gate QR + offline + PIN (F161, F162, F170)
  perform pg_temp.as_user(u_hr, 'hr'); perform api.v1_iam_select_position(a_hr);
  dev := api.v1_gate_register('GATE1', null, 'main gate');
  perform pg_temp.as_user(u_em, 'em'); perform api.v1_iam_select_position(a_em);
  qr := api.v1_attendance_qr() ->> 'payload';
  perform pg_temp.as_user(u_hr, 'hr');
  ok := pg_temp.expect_fail(format($f$select api.v1_gate_scan('GATE1', 'wrong-key', %L)$f$, qr), 'E_GATE_DEVICE_INVALID');
  ok := ok and (api.v1_gate_scan('GATE1', dev ->> 'device_key', qr) ->> 'result') = 'ok';
  ok := ok and (api.v1_gate_scan('GATE1', dev ->> 'device_key', qr) ->> 'result') = 'duplicate';
  insert into _r values ('S44-09', ok and (select count(*) from hr.attendance_event where employee_id = emp) = 1,
                                   'only a registered device scans; a token is used once');
  w := floor(extract(epoch from clock_timestamp() - interval '2 hours') / 30)::bigint;
  old_qr := sales.fn_signed(ca, 'MOS1|A|RTA|' || emp || '|' || w);
  j := api.v1_gate_sync('GATE1', dev ->> 'device_key', jsonb_build_array(jsonb_build_object('payload', old_qr, 'scanned_at', to_timestamp(w * 30) + interval '5 seconds'),
                                                                        jsonb_build_object('payload', old_qr, 'scanned_at', to_timestamp(w * 30) + interval '5 seconds')));
  insert into _r values ('S44-10', (j ->> 'ok')::integer = 1 and (j ->> 'duplicate')::integer = 1
                                   and pg_temp.expect_fail(format($f$select api.v1_gate_scan('GATE1', %L, %L)$f$, dev ->> 'device_key', old_qr), 'E_QR_INVALID'),
                                   'offline queue resyncs without duplicates; an old token is refused live');
  update hr.employee set employee_code = 'E-100' where id = emp;
  insert into iam.login_pin (person_id, pin_hash, set_via) values (p_em, crypt('482916', gen_salt('bf')), 'enroll') on conflict (person_id) do nothing;
  j := api.v1_gate_pin('GATE1', dev ->> 'device_key', 'E-100', '111111');
  j1 := api.v1_gate_pin('GATE1', dev ->> 'device_key', 'E-100', '482916');
  perform api.v1_gate_pin('GATE1', dev ->> 'device_key', 'E-100', '111111'); perform api.v1_gate_pin('GATE1', dev ->> 'device_key', 'E-100', '111111');
  perform api.v1_gate_pin('GATE1', dev ->> 'device_key', 'E-100', '111111'); perform api.v1_gate_pin('GATE1', dev ->> 'device_key', 'E-100', '111111');
  insert into _r values ('S44-11', j ->> 'result' = 'failed' and j1 ->> 'result' = 'ok'
                                   and pg_temp.expect_fail($q$select api.v1_gate_pin('GATE1', '$q$ || (dev ->> 'device_key') || $q$', 'E-100', '482916')$q$, 'E_RATE_LIMITED'),
                                   'PIN backup only at a registered device, rate-limited');
  -- ---------------------------------------------------------------- manual + correction (F163, F167)
  ev := (api.v1_attendance_manual(emp, clock_timestamp() - interval '5 days 1 hour', 'card reader down') ->> 'event_id')::uuid;
  insert into _r values ('S44-12', pg_temp.expect_fail(format($f$select api.v1_attendance_decide(%L, true)$f$, ev), 'E_SELF_APPROVAL'), 'manual attendance needs another person');
  perform pg_temp.as_user(u_hr2, 'hr2'); perform api.v1_iam_select_position(a_hr2);
  perform api.v1_attendance_decide(ev, true);
  perform pg_temp.as_user(u_em, 'em');
  j := api.v1_attendance_correction(clock_timestamp() - interval '6 days', 'forgot to scan out');
  perform pg_temp.as_user(u_hr, 'hr');
  perform api.v1_attendance_decide((j ->> 'event_id')::uuid, true);
  insert into _r values ('S44-13', (select count(*) from hr.attendance_event where employee_id = emp and status = 'posted' and method = 'qr') = 2
                                   and (select count(*) from hr.attendance_event where employee_id = emp and status = 'posted' and method in ('manual','correction')) = 2,
                                   'corrections add events; original scans stay');
  -- ---------------------------------------------------------------- shift, late policy, report (F164, F165, F169)
  sh := (api.v1_shift_save('NIGHT', 'রাত', '22:00', '06:00') ->> 'shift_id')::uuid;
  perform api.v1_roster_set(emp, dday - 1, dday - 1, sh);
  insert into hr.attendance_event (company_id, employee_id, event_at, method, status, reason, created_by)
  values (ca, emp, (dday - 1) + time '22:20', 'manual', 'posted', 'test', p_hr), (ca, emp, dday + time '05:55', 'manual', 'posted', 'test', p_hr);
  insert into _r values ('S44-14', pg_temp.expect_fail($q$select api.v1_late_policy_add(current_date - 1, 10, 3, 1, 'x')$q$, 'E_INVALID_ACTION')
                                   and (api.v1_late_policy_add(current_date, 10, 3, 1, 'grace 10 min') ->> 'effective_from')::date = current_date,
                                   'late policies start today or later (past days keep theirs)');
  j := api.v1_attendance_report(dday - 1, dday - 1, emp);
  insert into _r values ('S44-15', j -> 'rows' -> 0 ->> 'status' = 'late' and (j -> 'rows' -> 0 ->> 'late_minutes')::integer = 20
                                   and (j -> 'rows' -> 0 ->> 'last_out')::timestamptz = dday + time '05:55',
                                   'overnight shift: the morning scan belongs to the night before');
  -- ---------------------------------------------------------------- leave + overtime (F166, F168)
  perform api.v1_leave_type_save('CL', 'নৈমিত্তিক', 10);
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_config_set('hr.overtime.max_hours_month', '10'::jsonb, 0, 'tight budget');
  perform pg_temp.as_user(u_em, 'em');
  lv := api.v1_leave_request('CL', current_date + 10, current_date + 12, 'family');
  insert into _r values ('S44-16', pg_temp.expect_fail($q$select api.v1_leave_request('CL', current_date + 12, current_date + 13, 'x')$q$, 'E_LEAVE_OVERLAP')
                                   and pg_temp.expect_fail($q$select api.v1_leave_request('CL', current_date + 20, current_date + 31, 'x')$q$, 'E_LEAVE_BALANCE'),
                                   'leave never overlaps and never exceeds the balance');
  ot := api.v1_overtime_request(current_date, 8, 'month end');
  j := api.v1_overtime_request(current_date, 4, 'more');
  perform pg_temp.as_user(u_md, 'md');
  perform pg_temp.approve_pending((lv ->> 'leave_id')::uuid);
  perform pg_temp.approve_pending((ot ->> 'overtime_id')::uuid);
  perform pg_temp.as_user(u_em, 'em');
  insert into _r values ('S44-17', (select status from hr.leave_request where id = (lv ->> 'leave_id')::uuid) = 'posted'
                                   and (api.v1_attendance_report(current_date + 10, current_date + 10, null) -> 'rows' -> 0 ->> 'status') = 'leave',
                                   'approved leave shows in the employee''s own report');
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S44-18', pg_temp.expect_fail(format($f$select pg_temp.approve_pending(%L)$f$, j ->> 'overtime_id'), 'E_OVERTIME_CAP'),
                                   'overtime approval stays within the monthly cap');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

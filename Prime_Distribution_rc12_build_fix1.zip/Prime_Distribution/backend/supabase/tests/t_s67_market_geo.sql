-- S67 tests (ধাপ ৪খ: V161/V162 domains 03, 10, 11, 12, 13; docs/V180_FEATURE_AUDIT_BN.md): markets with map boundaries, dealer-market
-- assignment (maker-checker, hand-over, exclusive transfer, rollback), admin places import with diff, offline map catalogue, design emergency switch.
-- Setup copied from t_s56_prime.sql.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
create or replace function pg_temp.bal(p_company uuid, p_code text) returns numeric language sql as $$
  select finance.fn_balance((select id from finance.account where company_id = p_company and code = p_code), current_date) $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_sm uuid; a_fs uuid; a_sk uuid; a_ac uuid; a_md uuid; a_fm uuid;
        p_ch uuid; p_sm uuid; p_fs uuid; p_sk uuid; p_ac uuid; p_md uuid; p_fm uuid;
        u_ch uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_fs uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid();
        u_ac uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_fm uuid := gen_random_uuid();
        fgw uuid; qw uuid; noodle uuid; pl uuid; terr uuid; dl uuid; coa uuid; cash uuid; bank uuid; o1 jsonb; o3 jsonb; ds jsonb; inv jsonb; c1 jsonb; c2 jsonb; c3 jsonb;
        lot uuid; j jsonb; j1 jsonb; prov uuid; sh jsonb; sh2 jsonb; chg uuid; col jsonb; st uuid; st2 uuid; rem jsonb; rem2 jsonb; hb uuid; bt uuid; ct jsonb; q1 text; adj uuid; mr uuid; pt jsonb; pt2 jsonb; fb uuid; n integer;
        m1 uuid; m2 uuid; vis jsonb; dl2 uuid; as1 uuid; as2 uuid; uz text; sq jsonb; sq2 jsonb;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRM', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_fs := svc.v1_iam_provision_person('মাঠ', null, null, u_fs, 't'); a_fs := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fs, ca, null, 't'), 'FIELD_SALES', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_fm := svc.v1_iam_provision_person('অর্থ', null, null, u_fm, 't'); a_fm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_fm, ca, null, 't'), 'FIN_MANAGER', null, null, null, null, null, 't');
  -- finance ready (ADR-07)
  perform pg_temp.as_user(u_fm, 'fm'); perform api.v1_iam_select_position(a_fm);
  coa := (api.v1_coa_seed_default('chart') ->> 'version_id')::uuid;
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  perform api.v1_coa_review(coa, true, 'ok');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  perform api.v1_coa_approve(coa, 'ok');
  fgw := (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্য', 'finished_goods', null, null, 'x') ->> 'id')::uuid;
  qw := (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'x') ->> 'id')::uuid;
  noodle := (api.v1_product_propose(null, 'NOODLE', 'নুডলস', null, 'finished_good', null, 'poly', null, 'x') ->> 'product_id')::uuid;
  perform pg_temp.as_user(u_fm, 'fm');
  cash := (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', p_ac, 'x') ->> 'cash_account_id')::uuid;
  bank := (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা', '••••1234', '1110', 'x') ->> 'bank_account_id')::uuid;
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(noodle, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'x') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, noodle, null, 'poly', 100, current_date, 'launch');
  terr := (api.v1_territory_save(null, 'T1', 'খুলনা', null, null, null, null, 'x') ->> 'territory_id')::uuid;
  dl := (api.v1_dealer_save(null, 'D1', 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_dealer_save(dl, null, 'রহমান ট্রেডার্স', null, null, null, null, terr, p_fs, 10000, 30, (select row_version from sales.dealer where id = dl), 'limit');
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  perform api.v1_stock_receive(fgw, noodle, 'N1', null, null, current_date + 180, 500, 0, 0, 60, false, 'opening FG');
  lot := (select id from inventory.lot where lot_no = 'N1' and product_id = noodle);


  sq := '[[22.80,89.50],[22.80,89.60],[22.90,89.60],[22.90,89.50]]'::jsonb;
  sq2 := '[[22.85,89.55],[22.85,89.65],[22.95,89.65],[22.95,89.55]]'::jsonb;
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  dl2 := (api.v1_dealer_save(null, 'D2', 'করিম এন্টারপ্রাইজ', null, null, null, null, terr, p_fs, 0, 30, null, 'x') ->> 'dealer_id')::uuid;
  m1 := (api.v1_market_save(null, 'BAZ-1', 'বড় বাজার', terr, null, null, 'new market') ->> 'market_id')::uuid;
  m2 := (api.v1_market_save(null, 'BAZ-2', 'নতুন বাজার', terr, null, null, 'new market') ->> 'market_id')::uuid;
  -- ---------------------------------------------------------------- boundary validation
  insert into _r values ('S67-01', pg_temp.expect_fail(format($f$select api.v1_market_boundary_set(%L, '[[22.8,89.5],[22.9,89.6]]', false, 'x')$f$, m1), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_market_boundary_set(%L, '[[10,10],[10,11],[11,11]]', false, 'x')$f$, m1), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_market_boundary_set(%L, '[[22.80,89.50],[22.90,89.60],[22.80,89.60],[22.90,89.50]]', false, 'x')$f$, m1), 'E_INVALID_ACTION'),
                                   'a boundary has at least 3 points, lies in Bangladesh and never crosses itself');
  j := api.v1_market_boundary_set(m1, sq, false, 'surveyed');
  j1 := api.v1_market_boundary_set(m2, sq2, false, 'surveyed');
  insert into _r values ('S67-02', (j ->> 'saved')::boolean and (j ->> 'version')::int = 1 and not (j1 ->> 'saved')::boolean and jsonb_array_length(j1 -> 'overlaps') = 1,
                                   'an overlapping boundary is shown for review, not saved silently');
  j1 := api.v1_market_boundary_set(m2, sq2, true, 'shared edge agreed');
  insert into _r values ('S67-03', (j1 ->> 'saved')::boolean
                                   and jsonb_array_length(api.v1_market_at(22.82, 89.52)) = 1 and jsonb_array_length(api.v1_market_at(22.87, 89.57)) = 2
                                   and jsonb_array_length(api.v1_market_at(23.50, 90.40)) = 0
                                   and (select count(*) from sales.market_boundary_version where market_id = m2) = 1
                                   and pg_temp.expect_fail(format($f$update sales.market_boundary_version set reason = 'x' where market_id = %L$f$, m2)),
                                   'point lookup finds the markets containing a location; boundary history is kept unchanged');

  -- ---------------------------------------------------------------- assignment
  as1 := (api.v1_market_assign_request(m1, dl, current_date, null, '[{"item":"retailer list","done":false}]'::jsonb, 'first dealer') ->> 'assignment_id')::uuid;
  insert into _r values ('S67-04', pg_temp.expect_fail(format($f$select api.v1_market_assign_decide(%L, true, 'ok')$f$, as1), 'E_SELF_APPROVAL')
                                   and pg_temp.expect_fail(format($f$select api.v1_market_assign_request(%L, %L, current_date - 1, null, null, 'x')$f$, m1, dl2), 'E_INVALID_ACTION'),
                                   'the requester does not approve; assignments never start in the past');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S67-05', pg_temp.expect_fail(format($f$select api.v1_market_assign_decide(%L, true, 'ok')$f$, as1), 'E_INVALID_ACTION'),
                                   'approval waits for the hand-over checklist');
  perform pg_temp.as_user(u_sm, 'sm');
  perform api.v1_market_handover_tick(as1, 'retailer list');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_market_assign_decide(as1, true, 'ok');
  perform pg_temp.as_user(u_sm, 'sm');
  as2 := (api.v1_market_assign_request(m1, dl2, current_date + 1, null, null, 'transfer to D2') ->> 'assignment_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_market_assign_decide(as2, true, 'ok');
  insert into _r values ('S67-06', (select array_agg(x) from sales.fn_market_holders(m1, current_date) x) = array[dl]
                                   and (select array_agg(x) from sales.fn_market_holders(m1, current_date + 1) x) = array[dl2]
                                   and (select status = 'approved' and valid_to = current_date from sales.market_assignment where id = as1),
                                   'an exclusive transfer ends the previous holder the day before the new one starts');
  perform api.v1_market_assign_action(as2, 'rollback', 'dealer D2 withdrew');
  insert into _r values ('S67-07', (select status from sales.market_assignment where id = as2) = 'rolled_back'
                                   and (select status = 'approved' and valid_to is null from sales.market_assignment where id = as1)
                                   and (select array_agg(x) from sales.fn_market_holders(m1, current_date + 5) x) = array[dl]
                                   and jsonb_array_length(api.v1_market_coverage(null) -> 0 -> 'dealers') = 1,
                                   'a not-yet-started transfer can be rolled back; the previous dealer is restored');

  -- ---------------------------------------------------------------- admin places import (platform)
  uz := (select code from location.admin_area where kind = 'upazila' order by code limit 1);
  perform set_config('request.jwt.claims', '', true);
  j := svc.v1_admin_place_import('ward', jsonb_build_array(jsonb_build_object('code', 'W-01', 'name_bn', 'ওয়ার্ড ১', 'parent_code', uz),
                                                            jsonb_build_object('code', 'W-02', 'name_bn', 'ওয়ার্ড ২', 'parent_code', uz),
                                                            jsonb_build_object('code', 'W-03', 'name_bn', 'ভুল', 'parent_code', '99.99')), 'test-source-v1', false);
  j1 := svc.v1_admin_place_import('ward', jsonb_build_array(jsonb_build_object('code', 'W-01', 'name_bn', 'ওয়ার্ড এক', 'parent_code', uz)), 'test-source-v2', true);
  insert into _r values ('S67-08', (j ->> 'added')::int = 2 and jsonb_array_length(j -> 'diff') = 1
                                   and (j1 ->> 'renamed')::int = 1 and (j1 ->> 'retired')::int = 1
                                   and (select status from location.admin_place where code = 'W-02') = 'retired'
                                   and (select search_key like '%ওয়ার্ড ১%' from location.admin_place where code = 'W-01')
                                   and pg_temp.expect_fail($q$delete from location.admin_place where code = 'W-02'$q$),
                                   'imports report a diff; missing places are retired, never deleted; an old name stays searchable');

  -- ---------------------------------------------------------------- offline map catalogue
  perform svc.v1_map_package_publish((select code from location.admin_area where kind = 'division' order by code limit 1), 'বরিশাল বিভাগ', 'https://maps.example.org/bd-10-v1.sqlite',
                                     repeat('a', 64), 50000000, 6, 15, null, 'ODbL', '© OpenStreetMap contributors');
  perform svc.v1_map_package_publish((select code from location.admin_area where kind = 'division' order by code limit 1), 'বরিশাল বিভাগ', 'https://maps.example.org/bd-10-v2.sqlite',
                                     repeat('b', 64), 52000000, 6, 15, null, 'ODbL', '© OpenStreetMap contributors');
  perform pg_temp.as_user(u_sm, 'sm');
  j := api.v1_map_packages();
  insert into _r values ('S67-09', (j ->> 'quota_mb')::int = 512 and jsonb_array_length(j -> 'packages') = 2
                                   and (select count(*) from jsonb_array_elements(j -> 'packages') x where (x ->> 'current')::boolean) = 1
                                   and pg_temp.expect_fail($q$insert into location.map_package (region_code, name_bn, version, url, sha256, size_bytes, min_zoom, max_zoom, licence, attribution)
                                                               values ('10', 'x', 9, 'http://insecure', repeat('a', 64), 1, 1, 2, 'x', 'x')$q$),
                                   'one current package per region, older ones kept for rollback; only https sources');

  -- ---------------------------------------------------------------- design emergency switch
  perform pg_temp.as_user(u_md, 'md');
  insert into _r values ('S67-10', pg_temp.expect_fail($q$select api.v1_design_emergency_disable('broken colours')$q$, 'E_CHAIRMAN_ONLY'), 'only the Chairman pulls the design emergency switch');
  perform pg_temp.as_user(u_ch, 'ch');
  j := api.v1_design_emergency_disable('broken colours after publish');
  insert into _r values ('S67-11', not exists (select 1 from design.theme where company_id = ca and is_active), 'the company falls back to the built-in safe design at once');

  -- ---------------------------------------------------------------- route recovery (V162-14)
  perform pg_temp.as_user(u_fs, 'fs'); perform api.v1_iam_select_position(a_fs);
  vis := api.v1_visit_plan(dl, null, current_date + 1);
  insert into _r values ('S67-12', pg_temp.expect_fail(format($f$select api.v1_visit_plan(%L, null, current_date + 1)$f$, dl), 'E_DUPLICATE'),
                                   'the same visit is not planned twice for one day');
  perform api.v1_visit_follow_up((vis ->> 'visit_id')::uuid, current_date + 3, 'চেক সংগ্রহ', false);
  insert into _r values ('S67-13', jsonb_array_length(api.v1_follow_ups_due(current_date + 7)) = 1
                                   and (api.v1_route_completion(current_date + 1) ->> 'planned')::int = 1 and (api.v1_route_completion(current_date + 1) ->> 'open')::int = 1
                                   and pg_temp.expect_fail(format($f$select api.v1_visit_follow_up(%L, current_date - 1, 'x', false)$f$, vis ->> 'visit_id'), 'E_INVALID_ACTION'),
                                   'follow-ups are listed until done; the day summary counts planned / done / missed / open');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

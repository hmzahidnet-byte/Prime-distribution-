-- S71 tests (Chairman micro-design property registry; V161-08, V165-11/12, V166-05, V168-03, V169-05): typed values, contrast and range
-- checks, draft -> publish revision, company < wing < position precedence, preview as another position, rollback as a new revision.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending');
begin perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'ok'); end $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_md uuid; p_ch uuid; p_md uuid; u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); j jsonb; r1 integer; r2 integer;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('DSN', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  insert into _r values ('S71-01', (select count(*) from design.property_catalog) >= 60
                                   and pg_temp.expect_fail($q$select api.v1_design_property_set('company', null, 'payment.status.tick', 'color', '"#FFFF00"', 'x')$q$, 'E_DESIGN_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_design_property_set('company', null, 'payment.status.tick', 'size_dp', '500', 'x')$q$, 'E_DESIGN_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_design_property_set('company', null, 'payment.status.tick', 'icon', '"NoSuchIcon"', 'x')$q$, 'E_DESIGN_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_design_property_set('company', null, 'payment.status.tick', 'label_bn', '"<script>"', 'x')$q$, 'E_DESIGN_INVALID')
                                   and pg_temp.expect_fail($q$select api.v1_design_property_set('company', null, 'payment.status.tick', 'tap_action', '"x"', 'x')$q$, 'E_NOT_FOUND'),
                                   'only catalogued properties with typed, readable values (contrast, ranges, known icons, plain labels)');
  perform api.v1_design_property_set('company', null, 'payment.status.tick', 'color', '"#137547"', 'brand green');
  perform api.v1_design_property_set('company', null, 'payment.status.tick', 'animation', '"subtle"', 'calm');
  perform api.v1_design_property_set('position', 'MD', 'kpi.card', 'radius_dp', '20', 'rounder for MD');
  insert into _r values ('S71-02', api.v1_design_properties() = '{}'::jsonb, 'drafts are invisible until published');
  r1 := (api.v1_design_property_publish('first micro-design') ->> 'revision')::int;
  j := api.v1_design_properties();
  insert into _r values ('S71-03', r1 = 1 and j ->> 'payment.status.tick.color' = '#137547' and not j ? 'kpi.card.radius_dp'
                                   and (api.v1_design_properties('MD') ->> 'kpi.card.radius_dp')::int = 20,
                                   'published values reach every screen; a position override applies only to that position (Chairman can preview it)');
  perform api.v1_design_property_set('company', null, 'payment.status.tick', 'color', '"#1456A0"', 'blue tick');
  r2 := (api.v1_design_property_publish('blue tick') ->> 'revision')::int;
  insert into _r values ('S71-04', r2 = 2 and api.v1_design_properties() ->> 'payment.status.tick.color' = '#1456A0'
                                   and pg_temp.expect_fail($q$update design.property_value set value = '"#000000"' where status = 'superseded'$q$, 'E_IMMUTABLE'),
                                   'a new revision supersedes; old values never change');
  j := api.v1_design_property_rollback(1, 'back to green');
  insert into _r values ('S71-05', (j ->> 'revision')::int = 3 and api.v1_design_properties() ->> 'payment.status.tick.color' = '#137547'
                                   and (select count(*) from design.property_release where company_id = ca) = 3,
                                   'rollback publishes the older snapshot as a new revision; history kept');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  insert into _r values ('S71-06', (api.v1_design_properties() ->> 'kpi.card.radius_dp')::int = 20
                                   and pg_temp.expect_fail($q$select api.v1_design_property_publish('x')$q$, 'E_CHAIRMAN_ONLY')
                                   and pg_temp.expect_fail($q$select api.v1_design_properties('CHAIRMAN')$q$, 'E_CHAIRMAN_ONLY'),
                                   'MD sees the MD override; publishing and previewing others stay with the Chairman');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

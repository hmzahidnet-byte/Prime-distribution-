-- S24 tests: maker-checker product versions + diff, attribute fields, variants locked by use, POLY specs (positive,
-- approved, effective-dated, snapshot, no pcs guessing), lifecycle, effective-dated prices, QR scope, media, rights.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text, p_aal text default 'aal2') returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true);
      perform set_config('request.jwt.claims', jsonb_build_object('sub', p, 'role', 'authenticated', 'session_id', p_session, 'aal', p_aal)::text, true); end $$;
create or replace function pg_temp.prv(p uuid) returns integer language sql as $$ select row_version from inventory.product where id = p $$;
do $$
declare boot jsonb; ca uuid; a_ch uuid; a_md uuid; a_sk uuid; a_sm uuid; a_ac uuid; a_ch2 uuid; p_ch uuid; p_md uuid; p_sk uuid; p_sm uuid; p_ac uuid; p_ch2 uuid;
        u_ch uuid := gen_random_uuid(); u_md uuid := gen_random_uuid(); u_sk uuid := gen_random_uuid(); u_sm uuid := gen_random_uuid(); u_ac uuid := gen_random_uuid();
        u_ch2 uuid := gen_random_uuid();
        rice uuid; fg uuid; v1 uuid; s1 uuid; s2 uuid; pl uuid; med uuid; j jsonb; j1 jsonb; snap jsonb; t1 timestamptz; qr text;
begin
  p_ch := svc.v1_iam_provision_person('চেয়ারম্যান', null, null, u_ch, 't');
  boot := svc.v1_gov_bootstrap_company('PRD', 'ক', p_ch, 't'); ca := (boot ->> 'company_id')::uuid; a_ch := (boot ->> 'chairman_assignment_id')::uuid;
  p_md := svc.v1_iam_provision_person('এমডি', null, null, u_md, 't'); a_md := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_md, ca, null, 't'), 'MD', null, null, null, null, null, 't');
  p_sk := svc.v1_iam_provision_person('স্টোর', null, null, u_sk, 't'); a_sk := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sk, ca, null, 't'), 'STOREKEEPER', null, null, null, null, null, 't');
  p_sm := svc.v1_iam_provision_person('বিক্রয়', null, null, u_sm, 't'); a_sm := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_sm, ca, null, 't'), 'SALES_MANAGER', null, null, null, null, null, 't');
  p_ac := svc.v1_iam_provision_person('হিসাব', null, null, u_ac, 't'); a_ac := svc.v1_iam_assign_position(svc.v1_iam_add_membership(p_ac, ca, null, 't'), 'ACCOUNTANT', null, null, null, null, null, 't');
  p_ch2 := svc.v1_iam_provision_person('অন্য', null, null, u_ch2, 't');
  boot := svc.v1_gov_bootstrap_company('PRX', 'খ', p_ch2, 't'); a_ch2 := (boot ->> 'chairman_assignment_id')::uuid;

  -- ---------------------------------------------------------------- maker-checker
  perform pg_temp.as_user(u_sk, 'sk'); perform api.v1_iam_select_position(a_sk);
  rice := (api.v1_product_propose(null, 'rice-1', 'চাল', null, 'raw_material', null, 'kg', null, 'new raw') ->> 'product_id')::uuid;
  insert into _r values ('S24-01', (select status from inventory.product where id = rice) = 'draft' and (select sku from inventory.product where id = rice) = 'RICE-1'
                                   and pg_temp.expect_fail($q$select api.v1_product_propose(null, 'RICE-1', 'x', null, 'raw_material', null, 'kg', null, 'x')$q$, 'E_DUPLICATE'),
                                   'unique SKU per company; a new product starts as a draft version');
  perform pg_temp.as_user(u_ch, 'ch'); perform api.v1_iam_select_position(a_ch);
  fg := (api.v1_product_propose(null, 'NOODLE-50', 'নুডলস ৫০ গ্রাম', null, 'finished_good', null, 'poly', null, 'new FG') ->> 'product_id')::uuid;
  insert into _r values ('S24-02', pg_temp.expect_fail(format($f$select api.v1_product_decide(%L, 1, 'approve', 'mine')$f$, fg), 'E_SELF_APPROVAL'),
                                   'nobody approves their own change, not even the Chairman');
  perform pg_temp.as_user(u_md, 'md'); perform api.v1_iam_select_position(a_md);
  perform api.v1_product_decide(rice, 1, 'approve', 'ok');
  perform api.v1_product_decide(fg, 1, 'approve', 'ok');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_product_propose(rice, null, 'মিনিকেট চাল', null, null, null, null, null, 'rename');
  j := api.v1_product_get(rice);
  insert into _r values ('S24-03', (select status from inventory.product where id = rice) = 'active' and j ->> 'name_bn' = 'চাল'
                                   and (j -> 'pending' -> 'diff' -> 'name_bn' ->> 'to') = 'মিনিকেট চাল'
                                   and pg_temp.expect_fail(format($f$select api.v1_product_propose(%L, null, 'x', null, null, null, null, null, 'x')$f$, rice), 'E_DUPLICATE'),
                                   'a change waits as a pending version with a field diff; one at a time');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_product_decide(rice, 2, 'reject', 'keep the name');
  insert into _r values ('S24-04', (select name_bn from inventory.product where id = rice) = 'চাল' and jsonb_array_length(api.v1_product_history(rice)) = 2,
                                   'rejected changes never touch the product; history keeps both versions');
  -- ---------------------------------------------------------------- attribute fields
  perform pg_temp.as_user(u_ch, 'ch');
  perform api.v1_product_set_attribute_schema('{"fields":[{"key":"shelf_life_days","type":"integer","label_bn":"মেয়াদ (দিন)","required":true,"min":1}]}', 'shelf life');
  perform pg_temp.as_user(u_sk, 'sk');
  insert into _r values ('S24-05', pg_temp.expect_fail(format($f$select api.v1_product_propose(%L, null, 'চাল', null, null, null, null, '{}', 'x')$f$, rice), 'E_FORM_VALIDATION')
                                   and (api.v1_product_propose(rice, null, 'চাল', null, null, null, null, '{"shelf_life_days":180}', 'shelf life') ->> 'version')::integer = 3,
                                   'Chairman-defined fields are validated against their schema');
  -- ---------------------------------------------------------------- variants
  v1 := (api.v1_product_save_variant(fg, null, 'V1', 'মশলা', '50g', 'মশলা', 'poly', 'BOM-N50', null, null, 'flavour') ->> 'variant_id')::uuid;
  perform inventory.fn_lock_variant(v1, 'BOM-N50 v1 (posted)');
  insert into _r values ('S24-06', pg_temp.expect_fail(format($f$select api.v1_product_save_variant(%L, %L, null, 'মশলা', '50g', 'মশলা', 'poly', 'BOM-N51', null, 2, 'x')$f$, fg, v1), 'E_PRODUCT_LOCKED')
                                   and (api.v1_product_save_variant(fg, v1, null, 'ঝাল মশলা', '50g', 'মশলা', 'poly', 'BOM-N50', null, 2, 'name only') ->> 'row_version')::integer = 3,
                                   'a used variant keeps its recipe and pack; only labels change');
  -- ---------------------------------------------------------------- POLY specification (ADR-12)
  s1 := (api.v1_pack_spec_propose(fg, null, 12, 25.5, 20, null, 'first spec') ->> 'spec_id')::uuid;
  insert into _r values ('S24-07', pg_temp.expect_fail(format($f$select api.v1_product_convert(%L, null, 2, 'poly', 'sachet', null)$f$, fg), 'E_UNIT_AMBIGUOUS')
                                   and pg_temp.expect_fail(format($f$select api.v1_pack_spec_propose(%L, null, 0, 25, null, null, 'x')$f$, fg), 'E_INVALID_ACTION')
                                   and pg_temp.expect_fail(format($f$select api.v1_pack_spec_propose(%L, null, 12, 25, null, null, 'x')$f$, rice), 'E_INVALID_ACTION'),
                                   'no conversion before an approved spec; factors positive; specs only for finished goods');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_pack_spec_decide(s1, 'approve', 'checked');
  t1 := clock_timestamp();
  snap := inventory.fn_pack_spec_snapshot(fg, v1, t1);
  insert into _r values ('S24-08', (api.v1_product_convert(fg, null, 2, 'poly', 'sachet', null) ->> 'qty')::numeric = 24
                                   and (api.v1_product_convert(fg, null, 1, 'carton', 'sachet', null) ->> 'qty')::numeric = 240
                                   and (api.v1_product_convert(fg, null, 1, 'poly', 'g', null) ->> 'qty')::numeric = 306
                                   and pg_temp.expect_fail(format($f$select api.v1_product_convert(%L, null, 5, 'pcs', 'poly', null)$f$, fg), 'E_UNIT_AMBIGUOUS')
                                   and (api.v1_product_convert(fg, null, 2500, 'g', 'kg', null) ->> 'qty')::numeric = 2.5,
                                   'POLY, carton and grams convert only through the spec; pcs is never guessed');
  perform pg_temp.as_user(u_sk, 'sk');
  s2 := (api.v1_pack_spec_propose(fg, null, 10, 30, 20, null, 'bigger sachets') ->> 'spec_id')::uuid;
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_pack_spec_decide(s2, 'approve', 'ok');
  insert into _r values ('S24-09', (snap ->> 'sachets_per_poly')::integer = 12 and (inventory.fn_pack_spec_at(fg, null, t1)).sachets_per_poly = 12
                                   and (inventory.fn_pack_spec_at(fg, null, clock_timestamp())).sachets_per_poly = 10
                                   and pg_temp.expect_fail(format($f$update inventory.pack_spec set sachets_per_poly = 11 where id = %L$f$, s1), 'E_IMMUTABLE'),
                                   'a new spec never moves earlier snapshots (batches keep their numbers)');
  -- ---------------------------------------------------------------- lifecycle
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_product_action(rice, 'suspend', pg_temp.prv(rice), 'quality issue');
  insert into _r values ('S24-10', not inventory.fn_product_usable(ca, rice)
                                   and pg_temp.expect_fail(format($f$select api.v1_product_action(%L, 'resume', %s, 'x')$f$, rice, pg_temp.prv(rice)), 'E_FORBIDDEN'),
                                   'suspended products start no new transaction; resuming needs the approve right');
  perform pg_temp.as_user(u_md, 'md');
  perform api.v1_product_action(rice, 'resume', pg_temp.prv(rice), 'fixed');
  perform pg_temp.as_user(u_sk, 'sk');
  perform api.v1_product_action(rice, 'archive', pg_temp.prv(rice), 'discontinued');
  insert into _r values ('S24-11', pg_temp.expect_fail(format($f$select api.v1_product_save_variant(%L, null, 'V9', 'x', null, null, null, null, null, null, 'x')$f$, rice), 'E_PRODUCT_ARCHIVED')
                                   and pg_temp.expect_fail(format($f$select api.v1_product_action(%L, 'suspend', %s, 'x')$f$, rice, pg_temp.prv(rice)), 'E_INVALID_ACTION'),
                                   'archive blocks every new use and is final');
  -- ---------------------------------------------------------------- prices
  perform pg_temp.as_user(u_sm, 'sm'); perform api.v1_iam_select_position(a_sm);
  pl := (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য', null, null, null, 'dealer list') ->> 'price_list_id')::uuid;
  perform api.v1_price_set(pl, fg, null, 'poly', 100, current_date, 'launch');
  perform api.v1_price_set(pl, fg, null, 'poly', 120, current_date + 10, 'increase');
  perform api.v1_price_set(pl, fg, null, 'poly', 125, current_date + 10, 'corrected increase');
  insert into _r values ('S24-12', (api.v1_price_at(pl, fg, null, 'poly', current_date) ->> 'amount')::numeric = 100
                                   and (api.v1_price_at(pl, fg, null, 'poly', current_date + 10) ->> 'amount')::numeric = 125
                                   and (api.v1_price_at(pl, fg, null, 'poly', current_date + 9) ->> 'amount')::numeric = 100
                                   and pg_temp.expect_fail(format($f$select api.v1_price_set(%L, %L, null, 'poly', 90, current_date - 1, 'x')$f$, pl, fg), 'E_PRICE_BACKDATED')
                                   and pg_temp.expect_fail(format($f$select api.v1_price_set(%L, %L, null, 'poly', 90, current_date, 'x')$f$, pl, fg), 'E_PRICE_STARTED')
                                   and pg_temp.expect_fail(format($f$update inventory.price set amount = 1 where price_list_id = %L and effective_from = current_date$f$, pl), 'E_IMMUTABLE'),
                                   'effective-dated prices: no back-dating, started prices never rewritten');
  -- ---------------------------------------------------------------- QR, media, rights
  qr := (api.v1_product_get(fg) -> 'variants' -> 0 ->> 'qr');
  j := api.v1_product_resolve_qr(qr);
  perform pg_temp.as_user(u_ch2, 'ch2'); perform api.v1_iam_select_position(a_ch2);
  insert into _r values ('S24-13', (j ->> 'variant_id')::uuid = v1 and (j ->> 'usable')::boolean
                                   and pg_temp.expect_fail(format($f$select api.v1_product_resolve_qr(%L)$f$, qr), 'E_NOT_FOUND')
                                   and pg_temp.expect_fail($q$select api.v1_product_resolve_qr('MOS1|P|PRD|NOODLE-50')$q$, 'E_NOT_FOUND'),
                                   'product QR resolves only inside its own company');
  perform pg_temp.as_user(u_sk, 'sk');
  j1 := api.v1_product_media_begin(fg, 'image', 'image/png', 50000, repeat('ab', 32)); med := (j1 ->> 'media_id')::uuid;
  perform api.v1_product_media_confirm(med);
  perform pg_temp.as_user(u_ac, 'ac'); perform api.v1_iam_select_position(a_ac);
  insert into _r values ('S24-14', j1 ->> 'path' like ca::text || '/products/%' and (select image_path from inventory.product where id = fg) = j1 ->> 'path'
                                   and pg_temp.expect_fail(format($f$select api.v1_product_media_begin(%L, 'image', 'application/pdf', 10, %L)$f$, fg, repeat('ab', 32)))
                                   and jsonb_array_length(api.v1_product_list(null, null, 50)) = 2
                                   and pg_temp.expect_fail($q$select api.v1_product_propose(null, 'X-1', 'x', null, 'trading', null, 'pcs', null, 'x')$q$, 'E_FORBIDDEN'),
                                   'images only, company paths; everyone reads the catalog, only granted roles change it');
  perform set_config('mohona.company_scope', '', true);
  perform set_config('request.jwt.claims', '', true);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

-- Privilege-model tests (catalog level, category "privilege"). All are NEGATIVE tests: they prove what API roles can NOT do.
-- v1 port (S02) for the 14 project schemas. Targets the real Supabase role model: anon, authenticated, service_role (+ authenticator), our NOLOGIN owner erp_owner, any custom role.
-- Runs in a rolled-back transaction. STATUS: WRITTEN; first execution happens in the Staging workflow.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;

insert into _r values ('PRIV-01',
  not exists (
    select 1
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      cross join unnest(array['anon', 'authenticated', 'service_role']) as r(role_name)
      cross join unnest(array['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'TRUNCATE', 'REFERENCES', 'TRIGGER']) as p(priv)
     where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api')
       and c.relkind in ('r', 'p', 'v', 'm', 'f')
       and has_table_privilege(r.role_name, c.oid, p.priv)),
  'anon, authenticated and service_role hold NO privilege on any table or view in our schemas');

insert into _r values ('PRIV-02',
  not exists (
    select 1
      from pg_class c
      join pg_namespace n on n.oid = c.relnamespace
      cross join unnest(array['anon', 'authenticated', 'service_role']) as r(role_name)
      cross join unnest(array['USAGE', 'SELECT', 'UPDATE']) as p(priv)
     where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api')
       and c.relkind = 'S'
       and has_sequence_privilege(r.role_name, c.oid, p.priv)),
  'API roles hold no privilege on any sequence');

insert into _r values ('PRIV-03',
  not exists (select 1 from unnest(array['core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api']) as n(s) where has_schema_privilege('anon', n.s, 'USAGE'))
  and has_schema_privilege('authenticated', 'api', 'USAGE')
  and not exists (select 1 from unnest(array['core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api']) as n(s) where n.s <> 'api' and has_schema_privilege('authenticated', n.s, 'USAGE'))
  and has_schema_privilege('service_role', 'svc', 'USAGE')
  and not exists (select 1 from unnest(array['core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api']) as n(s) where n.s <> 'svc' and has_schema_privilege('service_role', n.s, 'USAGE')),
  'schema USAGE: anon none; authenticated only api; service_role only svc');

insert into _r values ('PRIV-04',
  not exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api')
       and (p.proacl is null
            or exists (select 1 from aclexplode(p.proacl) a where a.grantee = 0 and a.privilege_type = 'EXECUTE'))),
  'no function in our schemas is executable by PUBLIC (default EXECUTE was revoked)');

insert into _r values ('PRIV-05',
  not exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api') and n.nspname <> 'api' and has_function_privilege('authenticated', p.oid, 'EXECUTE'))
  and not exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api') and n.nspname <> 'svc' and has_function_privilege('service_role', p.oid, 'EXECUTE'))
  and not exists (
    select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api') and has_function_privilege('anon', p.oid, 'EXECUTE')),
  'authenticated executes only api.* ; service_role only svc.* ; anon nothing');

insert into _r values ('PRIV-06',
  exists (select 1 from pg_roles where rolname = 'erp_owner'
           and not rolsuper and not rolcanlogin and not rolbypassrls and not rolcreaterole and not rolcreatedb),
  'erp_owner is NOLOGIN, not superuser, not BYPASSRLS, cannot create roles or databases');

insert into _r values ('PRIV-07',
  not exists (
    select 1 from pg_auth_members m
      join pg_roles g on g.oid = m.roleid
      join pg_roles u on u.oid = m.member
     where g.rolname = 'erp_owner' and u.rolname in ('anon', 'authenticated', 'service_role', 'authenticator')),
  'no API role (anon, authenticated, service_role, authenticator) is a member of erp_owner');

insert into _r values ('PRIV-08',
  not exists (
    with acls as (
      select coalesce(r.rolname, 'PUBLIC') as grantee
        from pg_class c join pg_namespace n on n.oid = c.relnamespace
        cross join lateral aclexplode(coalesce(c.relacl, acldefault('r', c.relowner))) a
        left join pg_roles r on r.oid = a.grantee
       where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api') and c.relkind in ('r', 'p', 'v', 'm')
      union all
      select coalesce(r.rolname, 'PUBLIC')
        from pg_namespace n
        cross join lateral aclexplode(coalesce(n.nspacl, acldefault('n', n.nspowner))) a
        left join pg_roles r on r.oid = a.grantee
       where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api')
      union all
      select coalesce(r.rolname, 'PUBLIC')
        from pg_proc p join pg_namespace n on n.oid = p.pronamespace
        cross join lateral aclexplode(coalesce(p.proacl, acldefault('f', p.proowner))) a
        left join pg_roles r on r.oid = a.grantee
       where n.nspname in ('core', 'iam', 'config', 'design', 'audit', 'finance', 'inventory', 'mfg', 'procurement', 'sales', 'hr', 'report', 'notify', 'location', 'hardware', 'svc', 'api'))
    select 1 from acls where grantee not in ('erp_owner', 'authenticated', 'service_role')),
  'no unexpected grantee (PUBLIC, anon, custom or system role) holds any privilege in our schemas');

select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

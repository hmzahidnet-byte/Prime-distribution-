-- S06 tests: position catalog & templates, assignments (holder limits, isolation), active position per session, revocation.
begin;
set local role erp_owner;
create temp table _r (id text, ok boolean, note text) on commit drop;
create or replace function pg_temp.expect_fail(p_sql text, p_code text default null) returns boolean language plpgsql as $$
begin execute p_sql; return false;
exception when others then return p_code is null or sqlerrm like p_code || '%'; end $$;
create or replace function pg_temp.as_user(p uuid, p_session text default null) returns void language plpgsql as $$
begin perform set_config('mohona.company_scope', '', true); perform set_config('request.jwt.claims', case when p is null then '' else
  (jsonb_build_object('sub', p, 'role', 'authenticated', 'aal', 'aal2') || case when p_session is null then '{}'::jsonb else jsonb_build_object('session_id', p_session) end)::text end, true); end $$;
do $$
declare ca uuid; cb uuid; wa uuid; wb uuid; u1 uuid := gen_random_uuid(); u2 uuid := gen_random_uuid();
        p1 uuid; p2 uuid; m1a uuid; m1b uuid; m2a uuid; a_ch uuid; a_md uuid; a_b uuid; a_fut uuid; a_p2 uuid; x uuid;
        ctx jsonb; lst jsonb; n integer;
begin
  insert into core.company (code, name_bn, status) values ('PA', 'ক', 'active') returning id into ca;
  insert into core.company (code, name_bn, status) values ('PB', 'খ', 'active') returning id into cb;
  insert into core.wing (company_id, code, name_bn) values (ca, 'MFG', 'উৎপাদন') returning id into wa;
  insert into core.wing (company_id, code, name_bn) values (cb, 'MFG', 'উৎপাদন') returning id into wb;

  select count(*) into n from iam.position_catalog where company_id = ca;
  insert into _r values ('S06-01', n = 19
     and (select is_supreme and is_protected and max_holders = 1 from iam.position_catalog where company_id = ca and code = 'CHAIRMAN')
     and not (select is_enabled from iam.position_catalog where company_id = ca and code = 'EMERGENCY_ADMIN')
     and (select count(*) from iam.position_catalog where is_supreme and company_id = ca) = 1, 'new company gets 19 template positions (incl. DEALER_PORTAL); one supreme Chairman');
  insert into _r values ('S06-02', pg_temp.expect_fail($q$update iam.position_template set rank = 1 where code = 'MD'$q$, 'E_APPEND_ONLY'), 'templates are read-only');
  insert into _r values ('S06-03', pg_temp.expect_fail(format($f$update iam.position_catalog set is_enabled = false where company_id=%L and code='CHAIRMAN'$f$, ca), 'E_PROTECTED_POSITION')
                                   and pg_temp.expect_fail(format($f$update iam.position_catalog set max_holders = 2 where company_id=%L and code='CHAIRMAN'$f$, ca), 'E_PROTECTED_POSITION')
                                   and pg_temp.expect_fail(format($f$update iam.position_catalog set is_supreme = true where company_id=%L and code='MD'$f$, ca), 'E_IMMUTABLE'),
                                   'Chairman position cannot be disabled/shared; supremacy cannot be given to another position');
  update iam.position_catalog set name_bn = 'সভাপতি', rank = 999 where company_id = ca and code = 'CHAIRMAN';
  insert into _r values ('S06-20', (select name_bn = 'সভাপতি' and rank = 999 from iam.position_catalog where company_id = ca and code = 'CHAIRMAN'), 'Chairman can rename/re-rank positions (customisable)');

  p1 := svc.v1_iam_provision_person('রহিম', null, null, u1, 't');
  p2 := svc.v1_iam_provision_person('করিম', null, null, u2, 't');
  m1a := svc.v1_iam_add_membership(p1, ca, null, 't'); m1b := svc.v1_iam_add_membership(p1, cb, null, 't'); m2a := svc.v1_iam_add_membership(p2, ca, null, 't');
  a_ch := svc.v1_iam_assign_position(m1a, 'CHAIRMAN', null, null, null, null, null, 'appoint');
  a_md := svc.v1_iam_assign_position(m1a, 'MD', null, null, 'acting', null, null, 'acting MD');
  a_b  := svc.v1_iam_assign_position(m1b, 'WING_HEAD', null, null, null, wb, null, 'wing head B');
  a_fut := svc.v1_iam_assign_position(m1a, 'AUDITOR', clock_timestamp() + interval '10 days', null, null, null, null, 'future');
  a_p2 := svc.v1_iam_assign_position(m2a, 'ACCOUNTANT', null, null, null, null, null, 'accountant');

  insert into _r values ('S06-04', pg_temp.expect_fail(format($f$select svc.v1_iam_assign_position(%L,'CHAIRMAN',null,null,null,null,null,'second')$f$, m2a), 'E_POSITION_FULL'), 'only one active Chairman per company');
  insert into _r values ('S06-05', pg_temp.expect_fail(format($f$select svc.v1_iam_assign_position(%L,'EMERGENCY_ADMIN',null,null,null,null,null,'x')$f$, m2a), 'E_POSITION_DISABLED'), 'disabled position cannot be assigned');
  insert into _r values ('S06-06', pg_temp.expect_fail(format($f$select svc.v1_iam_assign_position(%L,'WING_HEAD',null,null,null,%L,null,'x')$f$, m2a, wb)), 'home wing must belong to the same company');
  insert into _r values ('S06-07', pg_temp.expect_fail(format($f$select svc.v1_iam_assign_position(%L,'MD',null,null,null,null,null,'dup')$f$, m1a)), 'same person cannot hold the same position twice');
  insert into _r values ('S06-17', pg_temp.expect_fail(format($f$update iam.position_assignment set position_code='AUDITOR' where id=%L$f$, a_md), 'E_IMMUTABLE'), 'assignment position/holder fixed');
  insert into _r values ('S06-16', pg_temp.expect_fail(format($f$update iam.position_catalog set is_enabled=false where company_id=%L and code='MD'$f$, ca), 'E_POSITION_IN_USE'), 'position in use cannot be disabled');
  update iam.position_catalog set reports_to_code = 'MD' where company_id = ca and code = 'WING_HEAD';
  insert into _r values ('S06-18', pg_temp.expect_fail(format($f$update iam.position_catalog set reports_to_code='WING_HEAD' where company_id=%L and code='MD'$f$, ca), 'E_POSITION_CYCLE'), 'reporting-line cycle rejected');

  perform pg_temp.as_user(u1, 'sess-1');
  insert into _r values ('S06-22', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_NO_ACTIVE_POSITION'), 'no selection yet = E_NO_ACTIVE_POSITION');
  lst := api.v1_iam_my_positions();
  insert into _r values ('S06-08', jsonb_array_length(lst) = 4
     and (select count(*) from jsonb_array_elements(lst) e where (e ->> 'usable')::boolean) = 3
     and exists (select 1 from jsonb_array_elements(lst) e where e ->> 'assignment_id' = a_fut::text and not (e ->> 'usable')::boolean), 'picker lists all my positions in both companies with live usability');
  ctx := api.v1_iam_select_position(a_ch);
  insert into _r values ('S06-09', ctx ->> 'position_code' = 'CHAIRMAN' and (ctx ->> 'company_id')::uuid = ca and (ctx ->> 'is_supreme')::boolean
                                   and exists (select 1 from audit.event where company_id = ca and action = 'session.select_position' and actor_person_id = p1), 'selection works and is audited');
  insert into _r values ('S06-10', pg_temp.expect_fail(format('select api.v1_iam_select_position(%L)', a_p2), 'E_FORBIDDEN')
                                   and pg_temp.expect_fail('select api.v1_iam_select_position(null)', 'E_FORBIDDEN'), 'cannot select a position that is not mine');
  insert into _r values ('S06-11', pg_temp.expect_fail(format('select api.v1_iam_select_position(%L)', a_fut), 'E_FORBIDDEN'), 'future assignment not usable yet');
  ctx := api.v1_iam_select_position(a_b);
  insert into _r values ('S06-12', (ctx ->> 'company_id')::uuid = cb and ctx ->> 'position_code' = 'WING_HEAD'
                                   and (select count(*) from iam.session_context where person_id = p1) = 1, 'one active position per session; switching replaces it (and the company)');
  perform set_config('mohona.company_scope', '', true);                      -- the API pinned the session to company B
  insert into config.setting_value (company_id, key, value, version, reason) values (ca, 'iam.session.max_concurrent', '2', 1, 'test: two devices');
  perform pg_temp.as_user(u1, 'sess-2');
  perform api.v1_iam_select_position(a_md);
  perform pg_temp.as_user(u1, 'sess-1');
  select count(*) into n from iam.session_context where person_id = p1;      -- unpinned inspection (new request)
  insert into _r values ('S06-15', n = 2 and api.v1_iam_current_context() ->> 'position_code' = 'WING_HEAD', 'two devices/sessions keep independent selections');
  select person_id into x from iam.fn_context(true);
  insert into _r values ('S06-19', x = p1, 'locking context path (write RPCs) resolves the same person');

  perform svc.v1_iam_end_assignment(a_b, 'transferred');
  insert into _r values ('S06-13', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_NO_ACTIVE_POSITION'), 'ended assignment stops the very next request (no token expiry wait)');

  perform pg_temp.as_user(u1, 'sess-2');
  update core.company set status = 'suspended' where id = ca;
  insert into _r values ('S06-21', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_NO_ACTIVE_POSITION'), 'suspended company blocks its positions');
  update core.company set status = 'active' where id = ca;
  perform svc.v1_iam_end_membership(m1a, current_date, 'left');
  insert into _r values ('S06-14', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_SESSION_REVOKED')   -- S09: ending a membership also revokes its sessions
                                   and not exists (select 1 from iam.position_assignment where membership_id = m1a and status <> 'ended'), 'ending membership ends all its assignments');
  a_ch := svc.v1_iam_assign_position(m2a, 'CHAIRMAN', null, null, null, null, null, 'new chairman after vacancy');
  insert into _r values ('S06-23', a_ch is not null, 'Chairman seat can be filled again after the previous holder left');

  perform pg_temp.as_user(u2, 'sess-3');
  perform api.v1_iam_select_position(a_ch);
  perform api.v1_iam_clear_position();
  insert into _r values ('S06-24', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_NO_ACTIVE_POSITION'), 'clear_position forgets the selection');
  -- default limit (1 session) drops the older device's selection
  perform set_config('mohona.company_scope', '', true);
  update config.setting_value set status = 'superseded' where company_id = ca and key = 'iam.session.max_concurrent' and status = 'active';
  perform pg_temp.as_user(u2, 'sess-4');
  perform api.v1_iam_select_position(a_p2);
  perform pg_temp.as_user(u2, 'sess-5');
  perform api.v1_iam_select_position(a_p2);
  perform pg_temp.as_user(u2, 'sess-4');
  insert into _r values ('S06-25', pg_temp.expect_fail('select api.v1_iam_current_context()', 'E_NO_ACTIVE_POSITION'), 'default one-session rule: a newer login replaces the older one');
  perform pg_temp.as_user(null);
end $$;
select 'RESULT|' || id || '|' || case when ok then 'PASS' else 'FAIL' end || '|' || note from _r order by id;
rollback;

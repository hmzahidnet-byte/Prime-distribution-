-- 20261108002700_inventory_warehouse.sql  (S29–S31 in one step)
-- Inventory & warehouse (blueprint INVENTORY_WAREHOUSE MOS-F153-091..100) on top of the S25 ledger:
--   091 warehouse hierarchy: zones > racks > bins inside one company's warehouse (no cross-company placement)
--   092 transfer orders between warehouses: approved by another person; decrement and increment in ONE transaction,
--       same lots, cost carried at the source average
--   093 ledger: stock_move append-only (S25) and now balances can no longer be written except by the ledger engine
--   094 FEFO (S25, now also trims bin stock)    097 reservations (S25; batch or order references)
--   095 blind cycle count: counters never see system quantities; variance approved by someone who did not count
--   096 stock adjustments: approved, never negative (the "allow negative stock" setting can never be switched on)
--   098 availability: on hand / reserved / available per warehouse under the same row locks as postings
--   099 warehouse QR: bin labels signed with a per-company secret; lookup only inside the signing company
--   100 stock report: warehouse / SKU / lot / age / value, only for warehouses the reader may see; logged export
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ ledger lock (F093) + negative stock is never allowed (F096)
create function inventory.fn_balance_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if coalesce(current_setting('mohona.ledger', true), '') <> 'post' then
    raise exception 'E_LEDGER_LOCKED: stock balances change only through posted stock movements' using errcode = 'P0001';
  end if;
  return coalesce(new, old);
end $$;
create trigger trg_stock_balance_guard before update or delete on inventory.stock_balance for each row execute function inventory.fn_balance_guard();
create trigger trg_lot_balance_guard before update or delete on inventory.lot_balance for each row execute function inventory.fn_balance_guard();

create function config.fn_negative_stock_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.key = 'inventory.negative_stock.allowed' and new.value = 'true'::jsonb then
    raise exception 'E_SETTING_INVALID: negative stock is prohibited by design (MOS-F153-096)' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_negative_stock_guard before insert on config.setting_value for each row execute function config.fn_negative_stock_guard();
update config.setting_definition set description_bn = 'সবসময় বন্ধ: মজুদ কখনো ঋণাত্মক হয় না (MOS-F153-096)' where key = 'inventory.negative_stock.allowed';

-- ================================================================ bins (F091, F099)
create table inventory.bin (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  warehouse_id  uuid not null,
  code          text not null check (code ~ '^[A-Z0-9][A-Z0-9_-]{0,20}$'),
  name_bn       text,
  kind          text not null check (kind in ('zone','rack','bin')),
  parent_id     uuid,
  status        text not null default 'active' check (status in ('active','inactive')),
  updated_at    timestamptz not null default clock_timestamp(),
  row_version   integer not null default 1,
  unique (id, company_id), unique (warehouse_id, code),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id),
  foreign key (parent_id, company_id) references inventory.bin (id, company_id)
);
create function inventory.fn_bin_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare p inventory.bin%rowtype;
begin
  if tg_op = 'UPDATE' and (new.code <> old.code or new.warehouse_id <> old.warehouse_id or new.company_id <> old.company_id) then
    raise exception 'E_IMMUTABLE: bin identity never changes' using errcode = 'P0001';
  end if;
  if new.parent_id is not null then
    select * into p from inventory.bin where id = new.parent_id;
    if p.warehouse_id <> new.warehouse_id then raise exception 'E_WRONG_COMPANY: parent is in another warehouse' using errcode = 'P0001'; end if;
    if not ((new.kind = 'rack' and p.kind = 'zone') or (new.kind = 'bin' and p.kind in ('zone','rack'))) then
      raise exception 'E_INVALID_ACTION: hierarchy is zone > rack > bin' using errcode = 'P0001';
    end if;
  elsif new.kind <> 'zone' and new.kind <> 'bin' then
    raise exception 'E_INVALID_ACTION: a rack sits in a zone' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_bin_guard before insert or update on inventory.bin for each row execute function inventory.fn_bin_guard();
create trigger trg_bin_touch before update on inventory.bin for each row execute function core.fn_touch_row();
create trigger trg_bin_nodel before delete on inventory.bin for each row execute function core.fn_deny_delete();
create trigger trg_bin_audit after insert or update on inventory.bin for each row execute function audit.fn_row_change();

create table inventory.bin_stock (
  company_id    uuid not null,
  warehouse_id  uuid not null,
  bin_id        uuid not null,
  lot_id        uuid not null,
  qty           numeric(18,4) not null check (qty >= 0),
  primary key (bin_id, lot_id),
  foreign key (bin_id, company_id) references inventory.bin (id, company_id),
  foreign key (lot_id, company_id) references inventory.lot (id, company_id)
);
create table inventory.bin_move (
  id           bigint generated always as identity primary key,
  company_id   uuid not null,
  warehouse_id uuid not null,
  lot_id       uuid not null,
  from_bin     uuid,
  to_bin       uuid,
  qty          numeric(18,4) not null check (qty > 0),
  kind         text not null check (kind in ('putaway','move','trim')),
  person_id    uuid,
  at           timestamptz not null default clock_timestamp()
);
create trigger trg_bin_move_no_mutation before update or delete on inventory.bin_move for each row execute function core.fn_deny_mutation();

-- After an outbound posting: bins of that lot never hold more than the lot balance (largest bin trimmed first).
create function inventory.fn_trim_bins(p_company uuid, p_warehouse uuid, p_lot uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare v_lot numeric; v_bins numeric; b record; v_cut numeric;
begin
  select coalesce((select lb.qty from inventory.lot_balance lb where lb.company_id = p_company and lb.warehouse_id = p_warehouse and lb.lot_id = p_lot), 0) into v_lot;
  select coalesce(sum(s.qty), 0) into v_bins from inventory.bin_stock s where s.warehouse_id = p_warehouse and s.lot_id = p_lot;
  for b in select * from inventory.bin_stock s where s.warehouse_id = p_warehouse and s.lot_id = p_lot and s.qty > 0 order by s.qty desc loop
    exit when v_bins <= v_lot;
    v_cut := least(b.qty, v_bins - v_lot);
    update inventory.bin_stock set qty = qty - v_cut where bin_id = b.bin_id and lot_id = p_lot;
    insert into inventory.bin_move (company_id, warehouse_id, lot_id, from_bin, qty, kind, person_id) values (p_company, p_warehouse, p_lot, b.bin_id, v_cut, 'trim', iam.fn_current_person());
    v_bins := v_bins - v_cut;
  end loop;
end $$;

create or replace function inventory.fn_post_move(p_company uuid, p_warehouse uuid, p_product uuid, p_lot uuid, p_type text, p_qty numeric, p_unit_cost numeric,
                                       p_doc_type text, p_doc_id uuid, p_line integer, p_reason text) returns numeric
language plpgsql security definer set search_path = pg_catalog as $$
declare b inventory.stock_balance%rowtype; v_cost numeric; v_value numeric;
begin
  if p_qty is null or p_qty = 0 then raise exception 'E_INVALID_ACTION: zero quantity' using errcode = 'P0001'; end if;
  perform set_config('mohona.ledger', 'post', true);                 -- balances change only from here (F093)
  insert into inventory.stock_balance (company_id, warehouse_id, product_id) values (p_company, p_warehouse, p_product) on conflict do nothing;
  select * into b from inventory.stock_balance where company_id = p_company and warehouse_id = p_warehouse and product_id = p_product for update;
  if p_qty > 0 then
    v_cost := coalesce(p_unit_cost, case when b.qty > 0 then b.value / b.qty else 0 end);
    v_value := round(p_qty * v_cost, 4);
  else
    if b.qty + p_qty < 0 then raise exception 'E_NEGATIVE_STOCK: only % available', b.qty using errcode = 'P0001'; end if;
    v_cost := case when b.qty > 0 then b.value / b.qty else 0 end;
    v_value := case when b.qty + p_qty = 0 then -b.value else round(p_qty * v_cost, 4) end;     -- last unit clears the value exactly
  end if;
  update inventory.stock_balance set qty = b.qty + p_qty, value = greatest(b.value + v_value, 0), updated_at = clock_timestamp()
   where company_id = p_company and warehouse_id = p_warehouse and product_id = p_product;
  if p_lot is not null then
    insert into inventory.lot_balance (company_id, warehouse_id, lot_id) values (p_company, p_warehouse, p_lot) on conflict do nothing;
    update inventory.lot_balance set qty = qty + p_qty where company_id = p_company and warehouse_id = p_warehouse and lot_id = p_lot;  -- check (qty >= 0)
    if p_qty < 0 then perform inventory.fn_trim_bins(p_company, p_warehouse, p_lot); end if;          -- bins never hold more than the lot
  end if;
  insert into inventory.stock_move (company_id, warehouse_id, product_id, lot_id, move_type, qty, unit_cost, value, doc_type, doc_id, doc_line, reason, posted_by)
  values (p_company, p_warehouse, p_product, p_lot, p_type, p_qty, round(v_cost, 6), v_value, p_doc_type, p_doc_id, coalesce(p_line, 0), p_reason, iam.fn_current_person());
  perform set_config('mohona.ledger', '', true);
  return v_cost;
exception when check_violation then
  raise exception 'E_NEGATIVE_STOCK: lot or balance would go below zero' using errcode = 'P0001';
end $$;

-- ================================================================ transfer orders (F092)
create table inventory.transfer (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  number              text,
  from_warehouse      uuid not null,
  to_warehouse        uuid not null,
  lines               jsonb not null,                 -- [{product_id, qty}]
  posted_lines        jsonb,                          -- [{product_id, lot_id, qty, unit_cost}] after approval
  status              text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  reason              text not null check (length(btrim(reason)) > 0),
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  posted_at           timestamptz,
  unique (id, company_id),
  check (from_warehouse <> to_warehouse),
  foreign key (from_warehouse, company_id) references inventory.warehouse (id, company_id),
  foreign key (to_warehouse, company_id) references inventory.warehouse (id, company_id)
);
create function inventory.fn_transfer_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','posted_lines','posted_at','approval_request_id']) <> (to_jsonb(new) - array['status','posted_lines','posted_at','approval_request_id'])
     or old.status <> 'pending_approval' then
    raise exception 'E_IMMUTABLE: a transfer is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_transfer_guard before update on inventory.transfer for each row execute function inventory.fn_transfer_guard();
create trigger trg_transfer_nodel before delete on inventory.transfer for each row execute function core.fn_deny_delete();
create trigger trg_transfer_audit after insert or update on inventory.transfer for each row execute function audit.fn_row_change();

-- ================================================================ cycle counts (F095) + adjustments (F096)
create table inventory.count_session (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  number        text,
  warehouse_id  uuid not null,
  snapshot      jsonb not null,                   -- [{product_id, lot_id, qty}] — never shown to counters
  status        text not null default 'open' check (status in ('open','submitted','approved','rejected','cancelled')),
  started_by    uuid not null references core.person(id),
  started_at    timestamptz not null default clock_timestamp(),
  submitted_at  timestamptz,
  decided_by    uuid references core.person(id),
  decided_at    timestamptz,
  reason        text not null,
  unique (id, company_id),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id)
);
create unique index count_one_open on inventory.count_session (warehouse_id) where status in ('open','submitted');
create function inventory.fn_count_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.snapshot is distinct from old.snapshot or new.warehouse_id <> old.warehouse_id or new.started_by <> old.started_by
     or not ((old.status = 'open' and new.status in ('submitted','cancelled')) or (old.status = 'submitted' and new.status in ('approved','rejected','open'))
             or new.status = old.status) then
    raise exception 'E_IMMUTABLE: count session state' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_count_guard before update on inventory.count_session for each row execute function inventory.fn_count_guard();
create trigger trg_count_nodel before delete on inventory.count_session for each row execute function core.fn_deny_delete();
create trigger trg_count_audit after insert or update on inventory.count_session for each row execute function audit.fn_row_change();

create table inventory.count_line (
  session_id   uuid not null,
  company_id   uuid not null,
  lot_id       uuid not null,
  product_id   uuid not null,
  counted_qty  numeric(18,4) not null check (counted_qty >= 0),
  counted_by   uuid not null references core.person(id),
  counted_at   timestamptz not null default clock_timestamp(),
  primary key (session_id, lot_id),
  foreign key (session_id, company_id) references inventory.count_session (id, company_id)
);
create trigger trg_count_line_audit after insert or update on inventory.count_line for each row execute function audit.fn_row_change();

create table inventory.adjustment (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  number        text,
  warehouse_id  uuid not null,
  source        text not null check (source in ('manual','count')),
  count_id      uuid,
  lines         jsonb not null,                  -- [{product_id, lot_id, delta, unit_cost?}]
  status        text not null default 'pending' check (status in ('pending','posted','rejected')),
  reason        text not null check (length(btrim(reason)) > 0),
  created_by    uuid not null references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  decided_by    uuid references core.person(id),
  decided_at    timestamptz,
  unique (id, company_id),
  check (decided_by is null or decided_by <> created_by),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id)
);
create function inventory.fn_adjustment_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','decided_by','decided_at','number']) <> (to_jsonb(new) - array['status','decided_by','decided_at','number']) or old.status <> 'pending' then
    raise exception 'E_IMMUTABLE: an adjustment is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_adjustment_guard before update on inventory.adjustment for each row execute function inventory.fn_adjustment_guard();
create trigger trg_adjustment_nodel before delete on inventory.adjustment for each row execute function core.fn_deny_delete();
create trigger trg_adjustment_audit after insert or update on inventory.adjustment for each row execute function audit.fn_row_change();

-- ================================================================ QR keys (F099) + report export log (F100)
create table inventory.qr_key (
  company_id  uuid primary key references core.company(id),
  secret      bytea not null,
  created_at  timestamptz not null default clock_timestamp()
);
create trigger trg_qr_key_no_mutation before update or delete on inventory.qr_key for each row execute function core.fn_deny_mutation();

create table inventory.export_log (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  person_id   uuid not null references core.person(id),
  warehouses  uuid[] not null,
  row_count   integer not null,
  with_value  boolean not null,
  created_at  timestamptz not null default clock_timestamp()
);
create trigger trg_inv_export_log_no_mutation before update or delete on inventory.export_log for each row execute function core.fn_deny_mutation();
create trigger trg_inv_export_log_audit after insert on inventory.export_log for each row execute function audit.fn_row_change();

select core.fn_apply_rls('inventory', 'bin');
select core.fn_apply_rls('inventory', 'bin_stock');
select core.fn_apply_rls('inventory', 'bin_move');
select core.fn_apply_rls('inventory', 'transfer');
select core.fn_apply_rls('inventory', 'count_session');
select core.fn_apply_rls('inventory', 'count_line');
select core.fn_apply_rls('inventory', 'adjustment');
select core.fn_apply_rls('inventory', 'qr_key');
select core.fn_apply_rls('inventory', 'export_log');

-- ================================================================ permissions
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('inventory.bin.manage',    'inventory', 'র‍্যাক/বিন ও বিন-স্থানান্তর', 'write', false, true, array['COMPANY','WAREHOUSE'], 'active', 710),
  ('inventory.report.export', 'inventory', 'মজুদ-রিপোর্ট রপ্তানি', 'export', true, false, array['COMPANY'], 'active', 720);
update iam.permission_catalog set status = 'active' where code in ('inventory.transfer.create','inventory.transfer.approve','inventory.count.record');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, 'inventory.transfer.create', 'allow', 'COMPANY' from unnest(array['STOREKEEPER']) x
union all select x, 'inventory.transfer.approve', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER']) x
union all select x, 'inventory.count.record', 'allow', 'COMPANY' from unnest(array['STOREKEEPER','AUDITOR']) x
union all select x, 'inventory.adjust.submit', 'allow', 'COMPANY' from unnest(array['STOREKEEPER']) x
union all select x, 'inventory.bin.manage', 'allow', 'COMPANY' from unnest(array['STOREKEEPER']) x
union all select x, 'inventory.report.export', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER','AUDITOR']) x
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

-- Signed bin QR: MOS1|B|<company>|<warehouse>|<bin>|<sig>, sig = first 16 hex of HMAC-SHA256 with the company secret.
create function inventory.fn_qr_secret(p_company uuid) returns bytea
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare k bytea;
begin
  select q.secret into k from inventory.qr_key q where q.company_id = p_company;
  if k is null then
    insert into inventory.qr_key (company_id, secret) values (p_company, gen_random_bytes(32)) on conflict do nothing;
    select q.secret into k from inventory.qr_key q where q.company_id = p_company;
  end if;
  return k;
end $$;

create function inventory.fn_bin_qr(p_bin uuid) returns text
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare b record; v_body text;
begin
  select bn.code bcode, w.code wcode, c.code ccode, bn.company_id into b
    from inventory.bin bn join inventory.warehouse w on w.id = bn.warehouse_id join core.company c on c.id = bn.company_id where bn.id = p_bin;
  if b.bcode is null then return null; end if;
  v_body := 'MOS1|B|' || b.ccode || '|' || b.wcode || '|' || b.bcode;
  return v_body || '|' || left(encode(hmac(convert_to(v_body, 'UTF8'), inventory.fn_qr_secret(b.company_id), 'sha256'), 'hex'), 16);
end $$;

-- ================================================================ API: bins (F091, F099)
create function api.v1_bin_save(p_warehouse_id uuid, p_id uuid, p_code text, p_name_bn text, p_kind text, p_parent_id uuid, p_status text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b inventory.bin%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.bin.manage', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse_id and w.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'warehouse'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into inventory.bin (company_id, warehouse_id, code, name_bn, kind, parent_id) values (me.company_id, p_warehouse_id, upper(p_code), p_name_bn, p_kind, p_parent_id) returning * into b;
  else
    update inventory.bin set name_bn = coalesce(p_name_bn, name_bn), parent_id = p_parent_id, status = coalesce(p_status, status)
     where id = p_id and company_id = me.company_id and warehouse_id = p_warehouse_id returning * into b;
    if b.id is null then perform core.fn_raise('E_NOT_FOUND', 'bin'); end if;
    if b.status = 'inactive' and exists (select 1 from inventory.bin_stock s where s.bin_id = b.id and s.qty > 0) then perform core.fn_raise('E_STRUCTURE_IN_USE', 'bin holds stock'); end if;
  end if;
  return jsonb_build_object('bin_id', b.id, 'qr', inventory.fn_bin_qr(b.id));
end $$;

-- Put away / move a lot quantity between bins of one warehouse (from null = not yet in a bin). Never more than there.
create function api.v1_bin_move(p_warehouse_id uuid, p_lot_id uuid, p_from_bin uuid, p_to_bin uuid, p_qty numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_free numeric;
begin
  select * into me from iam.fn_require('inventory.bin.manage', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if coalesce(p_qty, 0) <= 0 or p_from_bin is not distinct from p_to_bin or p_to_bin is null then perform core.fn_raise('E_INVALID_ACTION', 'qty / bins'); end if;
  if not exists (select 1 from inventory.bin b where b.id = p_to_bin and b.warehouse_id = p_warehouse_id and b.company_id = me.company_id and b.status = 'active' and b.kind = 'bin') then
    perform core.fn_raise('E_NOT_FOUND', 'destination bin');
  end if;
  perform pg_advisory_xact_lock(hashtext(p_warehouse_id::text || p_lot_id::text));
  if p_from_bin is null then
    v_free := coalesce((select lb.qty from inventory.lot_balance lb where lb.company_id = me.company_id and lb.warehouse_id = p_warehouse_id and lb.lot_id = p_lot_id), 0)
            - coalesce((select sum(s.qty) from inventory.bin_stock s where s.warehouse_id = p_warehouse_id and s.lot_id = p_lot_id), 0);
  else
    v_free := coalesce((select s.qty from inventory.bin_stock s where s.bin_id = p_from_bin and s.lot_id = p_lot_id and s.warehouse_id = p_warehouse_id), 0);
  end if;
  if p_qty > v_free then perform core.fn_raise('E_NEGATIVE_STOCK', 'only ' || v_free || ' there'); end if;
  if p_from_bin is not null then update inventory.bin_stock set qty = qty - p_qty where bin_id = p_from_bin and lot_id = p_lot_id; end if;
  insert into inventory.bin_stock (company_id, warehouse_id, bin_id, lot_id, qty) values (me.company_id, p_warehouse_id, p_to_bin, p_lot_id, p_qty)
  on conflict (bin_id, lot_id) do update set qty = inventory.bin_stock.qty + excluded.qty;
  insert into inventory.bin_move (company_id, warehouse_id, lot_id, from_bin, to_bin, qty, kind, person_id)
  values (me.company_id, p_warehouse_id, p_lot_id, p_from_bin, p_to_bin, p_qty, case when p_from_bin is null then 'putaway' else 'move' end, me.person_id);
  return jsonb_build_object('lot_id', p_lot_id, 'to_bin', p_to_bin, 'qty', p_qty);
end $$;

-- QR lookup (F099): valid only with a correct signature AND inside the caller's own company.
create function api.v1_qr_lookup(p_payload text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); b inventory.bin%rowtype; w inventory.warehouse%rowtype;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  if cardinality(parts) <> 6 or parts[1] <> 'MOS1' or parts[2] <> 'B' or parts[3] is distinct from (select c.code from core.company c where c.id = me.company_id) then
    perform core.fn_raise('E_QR_INVALID');
  end if;
  select * into w from inventory.warehouse where company_id = me.company_id and code = parts[4];
  select * into b from inventory.bin where warehouse_id = w.id and code = parts[5];
  if b.id is null or inventory.fn_bin_qr(b.id) <> p_payload then perform core.fn_raise('E_QR_INVALID'); end if;
  perform iam.fn_require('inventory.stock.read', iam.fn_resource(me.company_id, null, null, null, w.id), false);
  return jsonb_build_object('warehouse_id', w.id, 'warehouse', w.name_bn, 'bin_id', b.id, 'bin', b.code, 'kind', b.kind,
    'contents', coalesce((select jsonb_agg(jsonb_build_object('lot_id', s.lot_id, 'lot_no', l.lot_no, 'product_id', l.product_id, 'sku', p.sku, 'name_bn', p.name_bn,
                                 'qty', s.qty, 'expiry_date', l.expiry_date) order by l.expiry_date nulls last)
                            from inventory.bin_stock s join inventory.lot l on l.id = s.lot_id join inventory.product p on p.id = l.product_id
                           where s.bin_id = b.id and s.qty > 0), '[]'::jsonb));
end $$;

-- ================================================================ API: transfers (F092)
create function inventory.fn_post_transfer(p_id uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare t inventory.transfer%rowtype; l jsonb; a jsonb; n integer := 0; v_cost numeric; posted jsonb := '[]'::jsonb;
begin
  select * into t from inventory.transfer where id = p_id for update;
  if t.status <> 'pending_approval' then return; end if;
  for l in select * from jsonb_array_elements(t.lines) loop
    if not inventory.fn_product_usable(t.company_id, (l ->> 'product_id')::uuid) then raise exception 'E_PRODUCT_ARCHIVED' using errcode = 'P0001'; end if;
    for a in select * from jsonb_array_elements(inventory.fn_fefo(t.company_id, t.from_warehouse, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
      n := n + 1;
      -- decrement and increment in the same transaction: either both happen or neither (F092)
      v_cost := inventory.fn_post_move(t.company_id, t.from_warehouse, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'transfer_out', -((a ->> 'qty')::numeric), null,
                                       'inventory.transfer', t.id, n, t.reason);
      perform inventory.fn_post_move(t.company_id, t.to_warehouse, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'transfer_in', (a ->> 'qty')::numeric, v_cost,
                                     'inventory.transfer', t.id, 10000 + n, t.reason);
      posted := posted || jsonb_build_array(jsonb_build_object('product_id', l ->> 'product_id', 'lot_id', a ->> 'lot_id', 'qty', (a ->> 'qty')::numeric, 'unit_cost', round(v_cost, 6)));
    end loop;
  end loop;
  update inventory.transfer set status = 'posted', posted_lines = posted, posted_at = clock_timestamp() where id = t.id;
end $$;

create function api.v1_transfer_create(p_from uuid, p_to uuid, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); l jsonb; r core.approval_request%rowtype; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.transfer.create', iam.fn_resource(iam.fn_context_company(), null, null, null, p_from), true);
  if (select count(*) from inventory.warehouse w where w.company_id = me.company_id and w.status = 'active' and w.id in (p_from, p_to)) <> 2 or p_from = p_to then
    perform core.fn_raise('E_NOT_FOUND', 'two active warehouses of this company');
  end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    if coalesce((l ->> 'qty')::numeric, 0) <= 0 or (l ->> 'qty')::numeric > inventory.fn_available(me.company_id, p_from, (l ->> 'product_id')::uuid) then
      perform core.fn_raise('E_INSUFFICIENT_STOCK', l ->> 'product_id');
    end if;
  end loop;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.transfer (id, company_id, number, from_warehouse, to_warehouse, lines, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'inventory.transfer', v_id), p_from, p_to, p_lines, p_reason, me.person_id);
  j := core.fn_approval_submit(me.company_id, 'inventory.transfer', v_id, 0, iam.fn_resource(me.company_id, null, null, null, p_from), null);
  update inventory.transfer set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  if j ->> 'status' = 'approved' then perform inventory.fn_post_transfer(v_id); end if;
  return jsonb_build_object('transfer_id', v_id, 'status', (select t.status from inventory.transfer t where t.id = v_id));
end $$;

-- ================================================================ API: cycle count (F095) + adjustments (F096)
-- Start: snapshots every lot with stock in the warehouse (or the given products). Counters get the list WITHOUT quantities.
create function api.v1_count_start(p_warehouse_id uuid, p_product_ids uuid[], p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); snap jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.count.record', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse_id and w.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'warehouse'); end if;
  select coalesce(jsonb_agg(jsonb_build_object('product_id', l.product_id, 'lot_id', l.id, 'qty', lb.qty)), '[]'::jsonb) into snap
    from inventory.lot_balance lb join inventory.lot l on l.id = lb.lot_id
   where lb.company_id = me.company_id and lb.warehouse_id = p_warehouse_id and lb.qty > 0 and (p_product_ids is null or l.product_id = any (p_product_ids));
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.count_session (id, company_id, number, warehouse_id, snapshot, started_by, reason)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'inventory.count', v_id), p_warehouse_id, snap, me.person_id, p_reason);
  return jsonb_build_object('count_id', v_id, 'to_count', coalesce((select jsonb_agg(jsonb_build_object('lot_id', x ->> 'lot_id', 'product_id', x ->> 'product_id',
           'lot_no', (select l.lot_no from inventory.lot l where l.id = (x ->> 'lot_id')::uuid))) from jsonb_array_elements(snap) x), '[]'::jsonb));
end $$;

create function api.v1_count_record(p_count_id uuid, p_lines jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c inventory.count_session%rowtype; l jsonb; n integer := 0;
begin
  select * into c from inventory.count_session where id = p_count_id and company_id = iam.fn_context_company();
  if not found or c.status <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open count'); end if;
  select * into me from iam.fn_require('inventory.count.record', iam.fn_resource(c.company_id, null, null, null, c.warehouse_id), true);
  for l in select * from jsonb_array_elements(coalesce(p_lines, '[]'::jsonb)) loop
    if not exists (select 1 from jsonb_array_elements(c.snapshot) x where x ->> 'lot_id' = l ->> 'lot_id') then perform core.fn_raise('E_NOT_FOUND', 'lot not in this count'); end if;
    if coalesce((l ->> 'counted')::numeric, -1) < 0 then perform core.fn_raise('E_INVALID_ACTION', 'counted'); end if;
    insert into inventory.count_line (session_id, company_id, lot_id, product_id, counted_qty, counted_by)
    values (c.id, c.company_id, (l ->> 'lot_id')::uuid, (select (x ->> 'product_id')::uuid from jsonb_array_elements(c.snapshot) x where x ->> 'lot_id' = l ->> 'lot_id' limit 1),
            (l ->> 'counted')::numeric, me.person_id)
    on conflict (session_id, lot_id) do update set counted_qty = excluded.counted_qty, counted_by = excluded.counted_by, counted_at = clock_timestamp();
    n := n + 1;
  end loop;
  return jsonb_build_object('count_id', c.id, 'recorded', n);
end $$;

-- Submit: every snapshotted lot must be counted; variances become a pending adjustment (count source).
create function api.v1_count_submit(p_count_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c inventory.count_session%rowtype; lines jsonb; v_adj uuid := gen_random_uuid();
begin
  select * into c from inventory.count_session where id = p_count_id and company_id = iam.fn_context_company() for update;
  if not found or c.status <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open count'); end if;
  select * into me from iam.fn_require('inventory.count.record', iam.fn_resource(c.company_id, null, null, null, c.warehouse_id), true);
  if exists (select 1 from jsonb_array_elements(c.snapshot) x where not exists (select 1 from inventory.count_line cl where cl.session_id = c.id and cl.lot_id = (x ->> 'lot_id')::uuid)) then
    perform core.fn_raise('E_COUNT_INCOMPLETE');
  end if;
  select coalesce(jsonb_agg(jsonb_build_object('product_id', x ->> 'product_id', 'lot_id', x ->> 'lot_id', 'delta', cl.counted_qty - (x ->> 'qty')::numeric))
                  filter (where cl.counted_qty <> (x ->> 'qty')::numeric), '[]'::jsonb) into lines
    from jsonb_array_elements(c.snapshot) x join inventory.count_line cl on cl.session_id = c.id and cl.lot_id = (x ->> 'lot_id')::uuid;
  perform set_config('mohona.change_reason', 'count ' || c.number, true);
  update inventory.count_session set status = 'submitted', submitted_at = clock_timestamp() where id = c.id;
  if jsonb_array_length(lines) > 0 then
    insert into inventory.adjustment (id, company_id, number, warehouse_id, source, count_id, lines, reason, created_by)
    values (v_adj, c.company_id, core.fn_next_number(c.company_id, 'inventory.adjustment', v_adj), c.warehouse_id, 'count', c.id, lines, 'count ' || c.number, c.started_by);
  else
    update inventory.count_session set status = 'approved', decided_at = clock_timestamp() where id = c.id;
  end if;
  return jsonb_build_object('count_id', c.id, 'variances', jsonb_array_length(lines), 'adjustment_id', case when jsonb_array_length(lines) > 0 then v_adj end);
end $$;

-- Manual adjustment request (F096): lines [{product_id, lot_id, delta, unit_cost?}] (an increase needs a lot).
create function api.v1_adjust_submit(p_warehouse_id uuid, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); l jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.adjust.submit', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    if coalesce((l ->> 'delta')::numeric, 0) = 0 or (l ->> 'lot_id') is null
       or not exists (select 1 from inventory.lot x where x.id = (l ->> 'lot_id')::uuid and x.company_id = me.company_id and x.product_id = (l ->> 'product_id')::uuid) then
      perform core.fn_raise('E_INVALID_ACTION', 'each line names a product, its lot and a non-zero change');
    end if;
  end loop;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.adjustment (id, company_id, number, warehouse_id, source, lines, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'inventory.adjustment', v_id), p_warehouse_id, 'manual', p_lines, p_reason, me.person_id);
  return jsonb_build_object('adjustment_id', v_id, 'status', 'pending');
end $$;

-- Decision by someone who neither raised it nor counted (F095/F096); posting never goes below zero.
create function api.v1_adjust_decide(p_adjustment_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a inventory.adjustment%rowtype; l jsonb; n integer := 0;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.adjust.approve', iam.fn_my_company_resource(), true);
  select * into a from inventory.adjustment where id = p_adjustment_id and company_id = me.company_id for update;
  if not found or a.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending adjustment'); end if;
  if a.created_by = me.person_id or (a.count_id is not null and exists (select 1 from inventory.count_line cl where cl.session_id = a.count_id and cl.counted_by = me.person_id)) then
    perform core.fn_raise('E_SELF_APPROVAL', 'the person who counted or raised it cannot approve');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_approve then
    for l in select * from jsonb_array_elements(a.lines) loop
      n := n + 1;
      perform inventory.fn_post_move(a.company_id, a.warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid,
                                     case when (l ->> 'delta')::numeric > 0 then 'adjust_in' else 'adjust_out' end, (l ->> 'delta')::numeric,
                                     (l ->> 'unit_cost')::numeric, 'inventory.adjustment', a.id, n, a.reason);
    end loop;
  end if;
  update inventory.adjustment set status = case when p_approve then 'posted' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp() where id = a.id;
  if a.count_id is not null then
    update inventory.count_session set status = case when p_approve then 'approved' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp() where id = a.count_id;
  end if;
  return jsonb_build_object('adjustment_id', a.id, 'status', case when p_approve then 'posted' else 'rejected' end);
end $$;

-- Variance view for the approver only (counters never see system quantities).
create function api.v1_count_variance(p_count_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.adjust.approve', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('lot_id', x ->> 'lot_id', 'product_id', x ->> 'product_id', 'system', (x ->> 'qty')::numeric, 'counted', cl.counted_qty,
           'variance', cl.counted_qty - (x ->> 'qty')::numeric, 'counted_by', cl.counted_by))
     from inventory.count_session c cross join jsonb_array_elements(c.snapshot) x
     left join inventory.count_line cl on cl.session_id = c.id and cl.lot_id = (x ->> 'lot_id')::uuid
    where c.id = p_count_id and c.company_id = me.company_id), '[]'::jsonb);
end $$;

-- ================================================================ API: availability (F098) + report/export (F100)
create function api.v1_stock_availability(p_product_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('warehouse_id', b.warehouse_id, 'warehouse', w.name_bn, 'on_hand', b.qty,
           'reserved', b.qty - inventory.fn_available(me.company_id, b.warehouse_id, b.product_id), 'available', inventory.fn_available(me.company_id, b.warehouse_id, b.product_id))
           order by w.code)
     from inventory.stock_balance b join inventory.warehouse w on w.id = b.warehouse_id
    where b.company_id = me.company_id and b.product_id = p_product_id
      and (select d.allowed from iam.fn_authorize('inventory.stock.read', iam.fn_resource(me.company_id, null, null, null, b.warehouse_id), false) d)), '[]'::jsonb);
end $$;

-- Rows per warehouse / SKU / lot with age; value only for cost readers; only warehouses the reader may see.
create function inventory.fn_stock_report(p_company uuid, p_warehouse uuid, p_product uuid, p_with_value boolean) returns jsonb
language sql volatile security definer set search_path = pg_catalog as $$
  select coalesce(jsonb_agg(jsonb_build_object('warehouse_id', lb.warehouse_id, 'warehouse', w.code, 'product_id', l.product_id, 'sku', p.sku, 'name_bn', p.name_bn,
           'lot_no', l.lot_no, 'qty', lb.qty, 'received_at', l.received_at, 'age_days', (current_date - l.received_at::date), 'expiry_date', l.expiry_date,
           'value', case when p_with_value then round(lb.qty * coalesce(b.value / nullif(b.qty, 0), 0), 2) end) order by w.code, p.sku, l.expiry_date nulls last), '[]'::jsonb)
    from inventory.lot_balance lb join inventory.lot l on l.id = lb.lot_id join inventory.product p on p.id = l.product_id
    join inventory.warehouse w on w.id = lb.warehouse_id
    join inventory.stock_balance b on b.company_id = lb.company_id and b.warehouse_id = lb.warehouse_id and b.product_id = l.product_id
   where lb.company_id = p_company and lb.qty > 0 and (p_warehouse is null or lb.warehouse_id = p_warehouse) and (p_product is null or l.product_id = p_product)
     and (select d.allowed from iam.fn_authorize('inventory.stock.read', iam.fn_resource(p_company, null, null, null, lb.warehouse_id), false) d)
$$;

create function api.v1_stock_report(p_warehouse_id uuid default null, p_product_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_cost boolean;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), false);
  select d.allowed into v_cost from iam.fn_authorize('inventory.cost.read', iam.fn_resource(me.company_id), false) d;
  return inventory.fn_stock_report(me.company_id, p_warehouse_id, p_product_id, coalesce(v_cost, false));
end $$;

create function api.v1_stock_report_export(p_warehouse_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_cost boolean; rep jsonb;
begin
  select * into me from iam.fn_require('inventory.report.export', iam.fn_my_company_resource(), false);
  select d.allowed into v_cost from iam.fn_authorize('inventory.cost.read', iam.fn_resource(me.company_id), false) d;
  rep := inventory.fn_stock_report(me.company_id, p_warehouse_id, null, coalesce(v_cost, false));
  insert into inventory.export_log (company_id, person_id, warehouses, row_count, with_value)
  values (me.company_id, me.person_id, coalesce((select array_agg(distinct (x ->> 'warehouse_id')::uuid) from jsonb_array_elements(rep) x), array[]::uuid[]),
          jsonb_array_length(rep), coalesce(v_cost, false));
  return jsonb_build_object('rows', rep, 'exported_at', clock_timestamp(), 'with_value', coalesce(v_cost, false));
end $$;

-- Generic approval handlers: all earlier cases + inventory transfers.
create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'design.layout_publish' then perform design.fn_publish_layout_version(r.company_id, r.payload ->> 'screen_key', (r.payload ->> 'version')::integer);
    when r.document_type = 'inventory.transfer' then perform inventory.fn_post_transfer(r.document_id);
    when r.document_type like 'procurement.%' then perform procurement.fn_on_approved(r);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_bin_save(uuid, uuid, text, text, text, uuid, text, text)', 'api.v1_bin_move(uuid, uuid, uuid, uuid, numeric)',
      'api.v1_qr_lookup(text)', 'api.v1_transfer_create(uuid, uuid, jsonb, text)', 'api.v1_count_start(uuid, uuid[], text)', 'api.v1_count_record(uuid, jsonb)',
      'api.v1_count_submit(uuid)', 'api.v1_adjust_submit(uuid, jsonb, text)', 'api.v1_adjust_decide(uuid, boolean, text)', 'api.v1_count_variance(uuid)',
      'api.v1_stock_availability(uuid)', 'api.v1_stock_report(uuid, uuid)', 'api.v1_stock_report_export(uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

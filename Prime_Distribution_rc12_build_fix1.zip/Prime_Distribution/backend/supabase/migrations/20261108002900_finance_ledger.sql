-- 20261108002900_finance_ledger.sql  (S36–S39 in one step)
-- Finance ledger (blueprint FINANCE_LEDGER MOS-F153-111..120, ADR-07 CoA/GL mapping, ADR-09 rounding) + module postings
-- (OI-40 abnormal waste, OI-41 procurement/GRNI/AP, OI-45 WIP/FG):
--   111 chart of accounts: versioned draft -> accountant review -> Chairman approval; accounts never deleted; postable
--       accounts with balance never deactivated; event-to-GL mapping; a missing mapping blocks posting (event stays queued)
--   112 journal drafts with balanced lines   113 maker-checker through the approval engine (submitter never approves)
--   114 idempotent immutable posting: unique posting key per source event or journal
--   115 reversal references the original with swapped lines; posted journals are never edited
--   116 monthly periods: close / reopen with reason; no posting into closed months; normal back-dating limited
--   117 cash accounts, vouchers and drawer counts    118 bank accounts, statement import (no duplicate reference), reconciliation
--   119 factory P&L (Chairman + finance.factory_pnl.read + access.factory_pnl.positions; export logged)
--   120 product profitability from completed batch cost (+ revenue lines once sales post)
-- Every amount: NUMERIC, BDT 2 decimals half-up (setting-driven), unit costs 4+ (ADR-09).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ rounding (ADR-09)
create function finance.fn_round(p_company uuid, p_amount numeric) returns numeric
language plpgsql stable security definer set search_path = pg_catalog as $$
declare s integer := config.fn_get_int(p_company, 'finance.money.scale'); m text := config.fn_get_text(p_company, 'finance.rounding.mode'); f numeric;
begin
  if p_amount is null then return null; end if;
  f := power(10::numeric, s);
  return case m
    when 'HALF_EVEN' then case when abs(p_amount * f - trunc(p_amount * f)) = 0.5 then (case when trunc(p_amount * f)::bigint % 2 = 0 then trunc(p_amount * f) else trunc(p_amount * f) + sign(p_amount) end) / f
                          else round(p_amount, s) end
    when 'UP' then (case when p_amount >= 0 then ceil(p_amount * f) else floor(p_amount * f) end) / f
    when 'DOWN' then trunc(p_amount * f) / f
    else round(p_amount, s) end;
end $$;

-- ================================================================ chart of accounts + mapping (F111, ADR-07)
create table finance.coa_template (
  code       text primary key check (code ~ '^[0-9]{4}$'),
  name_bn    text not null,
  type       text not null check (type in ('asset','liability','equity','income','expense')),
  parent     text,
  postable   boolean not null default true
);
create trigger trg_coa_template_nodel before delete on finance.coa_template for each row execute function core.fn_deny_delete();

create table finance.mapping_template (
  event_key  text primary key check (event_key ~ '^[a-z]+\.[a-z_]+$'),
  code       text not null references finance.coa_template(code),
  name_bn    text not null
);
create trigger trg_mapping_template_nodel before delete on finance.mapping_template for each row execute function core.fn_deny_delete();

create table finance.coa_version (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  version      integer not null check (version >= 1),
  snapshot     jsonb not null,                   -- {"accounts":[{code,name_bn,type,parent,postable}],"mappings":{event_key: code}}
  status       text not null default 'draft' check (status in ('draft','reviewed','approved','rejected','superseded')),
  reason       text not null,
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  reviewed_by  uuid references core.person(id),
  reviewed_at  timestamptz,
  approved_by  uuid references core.person(id),
  approved_at  timestamptz,
  unique (company_id, version),
  check (approved_by is null or reviewed_by is null or approved_by <> reviewed_by)
);
create function finance.fn_coa_version_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.snapshot is distinct from old.snapshot and old.status <> 'draft' then
    raise exception 'E_IMMUTABLE: a reviewed chart of accounts version never changes' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('reviewed','rejected')) or (old.status = 'reviewed' and new.status in ('approved','rejected','draft'))
                                       or (old.status = 'approved' and new.status = 'superseded')) then
    raise exception 'E_INVALID_ACTION: chart of accounts % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_coa_version_guard before update on finance.coa_version for each row execute function finance.fn_coa_version_guard();
create trigger trg_coa_version_nodel before delete on finance.coa_version for each row execute function core.fn_deny_delete();
create trigger trg_coa_version_audit after insert or update on finance.coa_version for each row execute function audit.fn_row_change();

create table finance.account (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[0-9]{4,8}$'),
  name_bn     text not null,
  type        text not null check (type in ('asset','liability','equity','income','expense')),
  parent_code text,
  postable    boolean not null default true,
  status      text not null default 'active' check (status in ('active','inactive')),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id), unique (company_id, code)
);
create trigger trg_account_touch before update on finance.account for each row execute function core.fn_touch_row();
create trigger trg_account_nodel before delete on finance.account for each row execute function core.fn_deny_delete();
create trigger trg_account_audit after insert or update on finance.account for each row execute function audit.fn_row_change();

create table finance.gl_mapping (
  company_id  uuid not null references core.company(id),
  event_key   text not null,
  account_id  uuid not null,
  coa_version integer not null,
  primary key (company_id, event_key),
  foreign key (account_id, company_id) references finance.account (id, company_id)
);
create trigger trg_gl_mapping_audit after insert or update on finance.gl_mapping for each row execute function audit.fn_row_change();

-- ================================================================ periods (F116) + journals (F112–F115)
create table finance.period (
  company_id   uuid not null references core.company(id),
  month        date not null check (month = date_trunc('month', month)::date),
  status       text not null default 'open' check (status in ('open','closed')),
  closed_by    uuid references core.person(id),
  closed_at    timestamptz,
  reopened_by  uuid references core.person(id),
  reopened_at  timestamptz,
  reason       text,
  primary key (company_id, month)
);
create trigger trg_period_nodel before delete on finance.period for each row execute function core.fn_deny_delete();
create trigger trg_period_audit after insert or update on finance.period for each row execute function audit.fn_row_change();

create table finance.journal (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null references core.company(id),
  number              text,
  journal_date        date not null,
  source              text not null check (source in ('manual','module','reversal','voucher')),
  posting_key         text,                       -- F114: one posting per key (module event key / journal id)
  memo                text not null,
  status              text not null default 'draft' check (status in ('draft','pending_approval','posted','reversed','rejected','cancelled')),
  total               numeric(18,2) not null default 0,
  reversal_of         uuid references finance.journal(id),
  reversed_by         uuid references finance.journal(id),
  approval_request_id uuid,
  created_by          uuid references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  posted_at           timestamptz,
  posted_by           uuid references core.person(id),
  unique (id, company_id)
);
create unique index journal_posting_key on finance.journal (company_id, posting_key) where posting_key is not null;
create index journal_date on finance.journal (company_id, journal_date) where status in ('posted','reversed');
create function finance.fn_journal_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status in ('posted','reversed') and (to_jsonb(old) - array['status','reversed_by']) <> (to_jsonb(new) - array['status','reversed_by']) then
    raise exception 'E_IMMUTABLE: a posted journal never changes; reverse it' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('pending_approval','posted','cancelled'))
       or (old.status = 'pending_approval' and new.status in ('posted','rejected','draft','cancelled')) or (old.status = 'posted' and new.status = 'reversed')) then
    raise exception 'E_INVALID_ACTION: journal % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_journal_guard before update on finance.journal for each row execute function finance.fn_journal_guard();
create trigger trg_journal_nodel before delete on finance.journal for each row execute function core.fn_deny_delete();
create trigger trg_journal_audit after insert or update on finance.journal for each row execute function audit.fn_row_change();

create table finance.journal_line (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  journal_id  uuid not null,
  line_no     integer not null check (line_no >= 1),
  account_id  uuid not null,
  debit       numeric(18,2) not null default 0 check (debit >= 0),
  credit      numeric(18,2) not null default 0 check (credit >= 0),
  wing_id     uuid,
  product_id  uuid,
  memo        text,
  unique (journal_id, line_no),
  check ((debit = 0) <> (credit = 0)),
  foreign key (journal_id, company_id) references finance.journal (id, company_id),
  foreign key (account_id, company_id) references finance.account (id, company_id)
);
create index journal_line_account on finance.journal_line (account_id);
create function finance.fn_journal_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (select j.status from finance.journal j where j.id = coalesce(new.journal_id, old.journal_id)) <> 'draft' then
    raise exception 'E_IMMUTABLE: journal lines change only while draft' using errcode = 'P0001';
  end if;
  return coalesce(new, old);
end $$;
create trigger trg_journal_line_guard before insert or update or delete on finance.journal_line for each row execute function finance.fn_journal_line_guard();
create trigger trg_journal_line_audit after insert on finance.journal_line for each row execute function audit.fn_row_change();

-- Module events (outbox): business documents never wait for finance; posting needs an approved CoA + mappings.
create table finance.gl_event (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  source_key  text not null,
  event_date  date not null,
  memo        text not null,
  lines       jsonb not null,                     -- [{key, dr|cr, wing_id?, product_id?}]
  status      text not null default 'pending' check (status in ('pending','posted','error')),
  error       text,
  journal_id  uuid references finance.journal(id),
  created_at  timestamptz not null default clock_timestamp(),
  posted_at   timestamptz,
  unique (company_id, source_key)
);
create trigger trg_gl_event_nodel before delete on finance.gl_event for each row execute function core.fn_deny_delete();
create function finance.fn_account_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.code <> old.code or new.company_id <> old.company_id or (new.type <> old.type and exists (select 1 from finance.journal_line l where l.account_id = old.id)) then
    raise exception 'E_IMMUTABLE: account code and (once posted) type never change' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_account_guard before update on finance.account for each row execute function finance.fn_account_guard();

-- ================================================================ cash (F117) + bank (F118)
create table finance.cash_account (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn     text not null,
  account_id  uuid not null,
  custodian   uuid references core.person(id),
  status      text not null default 'active' check (status in ('active','inactive')),
  unique (id, company_id), unique (company_id, code),
  foreign key (account_id, company_id) references finance.account (id, company_id)
);
create trigger trg_cash_account_nodel before delete on finance.cash_account for each row execute function core.fn_deny_delete();
create trigger trg_cash_account_audit after insert or update on finance.cash_account for each row execute function audit.fn_row_change();

create table finance.cash_count (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  cash_account_id uuid not null,
  counted         numeric(18,2) not null check (counted >= 0),
  book_balance    numeric(18,2) not null,
  difference      numeric(18,2) not null,
  counted_by      uuid not null references core.person(id),
  counted_at      timestamptz not null default clock_timestamp(),
  note            text,
  foreign key (cash_account_id, company_id) references finance.cash_account (id, company_id)
);
create trigger trg_cash_count_no_mutation before update or delete on finance.cash_count for each row execute function core.fn_deny_mutation();
create trigger trg_cash_count_audit after insert on finance.cash_count for each row execute function audit.fn_row_change();

create table finance.bank_account (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  code            text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  bank_name       text not null,
  account_masked  text not null check (account_masked ~ '^[•*xX]+[0-9]{2,4}$'),
  account_id      uuid not null,
  status          text not null default 'active' check (status in ('active','inactive')),
  unique (id, company_id), unique (company_id, code),
  foreign key (account_id, company_id) references finance.account (id, company_id)
);
create trigger trg_bank_account_nodel before delete on finance.bank_account for each row execute function core.fn_deny_delete();
create trigger trg_bank_account_audit after insert or update on finance.bank_account for each row execute function audit.fn_row_change();

create table finance.bank_statement_line (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null,
  bank_account_id  uuid not null,
  txn_date         date not null,
  amount           numeric(18,2) not null check (amount <> 0),       -- + money in, − money out
  reference        text not null check (length(btrim(reference)) between 1 and 60),
  description      text,
  matched_line_id  uuid references finance.journal_line(id),
  matched_by       uuid references core.person(id),
  matched_at       timestamptz,
  imported_by      uuid references core.person(id),
  imported_at      timestamptz not null default clock_timestamp(),
  unique (bank_account_id, reference),                               -- F118: no duplicate bank reference
  foreign key (bank_account_id, company_id) references finance.bank_account (id, company_id)
);
create unique index bank_line_matched_once on finance.bank_statement_line (matched_line_id) where matched_line_id is not null;
create function finance.fn_bank_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['matched_line_id','matched_by','matched_at']) <> (to_jsonb(new) - array['matched_line_id','matched_by','matched_at'])
     or (old.matched_line_id is not null and new.matched_line_id is distinct from old.matched_line_id) then
    raise exception 'E_IMMUTABLE: a statement line is only matched once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_bank_line_guard before update on finance.bank_statement_line for each row execute function finance.fn_bank_line_guard();
create trigger trg_bank_line_nodel before delete on finance.bank_statement_line for each row execute function core.fn_deny_delete();
create trigger trg_bank_line_audit after insert or update on finance.bank_statement_line for each row execute function audit.fn_row_change();

create table finance.export_log (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  person_id   uuid not null references core.person(id),
  report      text not null,
  params      jsonb not null,
  created_at  timestamptz not null default clock_timestamp()
);
create trigger trg_fin_export_no_mutation before update or delete on finance.export_log for each row execute function core.fn_deny_mutation();
create trigger trg_fin_export_audit after insert on finance.export_log for each row execute function audit.fn_row_change();

select core.fn_apply_rls('finance', 'coa_template');
select core.fn_apply_rls('finance', 'mapping_template');
select core.fn_apply_rls('finance', 'coa_version');
select core.fn_apply_rls('finance', 'account');
select core.fn_apply_rls('finance', 'gl_mapping');
select core.fn_apply_rls('finance', 'period');
select core.fn_apply_rls('finance', 'journal');
select core.fn_apply_rls('finance', 'journal_line');
select core.fn_apply_rls('finance', 'gl_event');
select core.fn_apply_rls('finance', 'cash_account');
select core.fn_apply_rls('finance', 'cash_count');
select core.fn_apply_rls('finance', 'bank_account');
select core.fn_apply_rls('finance', 'bank_statement_line');
select core.fn_apply_rls('finance', 'export_log');

-- ================================================================ default chart + mapping templates (Bangladesh manufacturing)
insert into finance.coa_template (code, name_bn, type, parent, postable) values
  ('1000','সম্পদ','asset',null,false), ('1100','নগদ','asset','1000',true), ('1110','ব্যাংক','asset','1000',true),
  ('1200','কাঁচামাল মজুদ','asset','1000',true), ('1210','তৈরি পণ্য মজুদ','asset','1000',true), ('1220','ট্রেডিং মজুদ','asset','1000',true),
  ('1230','চলমান উৎপাদন (WIP)','asset','1000',true), ('1300','গ্রাহক-পাওনা','asset','1000',true),
  ('2000','দায়','liability',null,false), ('2100','সাপ্লায়ার-দেনা','liability','2000',true), ('2110','গৃহীত-বিলহীন (GRNI)','liability','2000',true),
  ('2120','ক্রয়-ফেরত সমন্বয়','liability','2000',true),
  ('3000','মালিকানা','equity',null,false), ('3100','শুরুর মজুদ-ইকুইটি','equity','3000',true), ('3200','সংরক্ষিত মুনাফা','equity','3000',true),
  ('4000','আয়','income',null,false), ('4100','বিক্রয়','income','4000',true), ('4200','মজুদ-সমন্বয় লাভ','income','4000',true),
  ('4300','শ্রম-শোষণ (উৎপাদনে)','income','4000',true), ('4310','ওভারহেড-শোষণ (উৎপাদনে)','income','4000',true),
  ('5000','ব্যয়','expense',null,false), ('5100','বিক্রীত পণ্যের খরচ','expense','5000',true), ('5200','দামের পার্থক্য (ক্রয়)','expense','5000',true),
  ('5300','স্বাভাবিক অপচয়','expense','5000',true), ('5310','অস্বাভাবিক অপচয়','expense','5000',true), ('5320','স্ক্র্যাপ','expense','5000',true),
  ('5330','উৎপাদন-পার্থক্য','expense','5000',true), ('5400','মজুদ-সমন্বয় ক্ষতি','expense','5000',true), ('5500','অন্যান্য কাঁচামাল-খরচ','expense','5000',true),
  ('5900','রাউন্ডিং','expense','5000',true);
insert into finance.mapping_template (event_key, code, name_bn) values
  ('inv.raw','1200','কাঁচামাল/প্যাকেজিং মজুদ'), ('inv.fg','1210','তৈরি পণ্য মজুদ'), ('inv.trading','1220','ট্রেডিং মজুদ'),
  ('inv.opening','3100','শুরুর মজুদের বিপরীত'), ('inv.waste_normal','5300','স্বাভাবিক অপচয়'), ('inv.waste_abnormal','5310','অস্বাভাবিক অপচয় (OI-40)'),
  ('inv.adjust_gain','4200','গণনা/সমন্বয় লাভ'), ('inv.adjust_loss','5400','গণনা/সমন্বয় ক্ষতি'), ('inv.consumption','5500','ব্যাচ-বহির্ভূত কাঁচামাল-ব্যবহার'),
  ('proc.grni','2110','গৃহীত-বিলহীন'), ('proc.ap','2100','সাপ্লায়ার-দেনা'), ('proc.price_variance','5200','দামের পার্থক্য'), ('proc.return','2120','ক্রয়-ফেরত'),
  ('fin.bank','1110','ব্যাংক (ডিফল্ট)'), ('fin.cash','1100','নগদ (ডিফল্ট)'), ('fin.rounding','5900','রাউন্ডিং'),
  ('mfg.wip','1230','চলমান উৎপাদন'), ('mfg.labor','4300','শ্রম-শোষণ'), ('mfg.overhead','4310','ওভারহেড-শোষণ'), ('mfg.abnormal','5310','উৎপাদনে অস্বাভাবিক অপচয়'),
  ('mfg.scrap','5320','স্ক্র্যাপ'), ('mfg.variance','5330','উৎপাদন-পার্থক্য'),
  ('sales.revenue','4100','বিক্রয়'), ('sales.cogs','5100','বিক্রীত পণ্যের খরচ'), ('sales.ar','1300','গ্রাহক-পাওনা');

-- ================================================================ permissions
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('finance.coa.review', 'finance', 'হিসাব-তালিকা পর্যালোচনা (হিসাবরক্ষক)', 'approve', true, false, array['COMPANY'], 'active', 1505);
update iam.permission_catalog set status = 'active'
 where code in ('finance.coa.manage','finance.ledger.read','finance.journal.create','finance.journal.post','finance.journal.reverse','finance.period.lock',
                'finance.period.reopen','finance.cash.read','finance.cash.voucher','finance.bank.reconcile','finance.statement.read','finance.factory_pnl.read');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', 'COMPANY' from (values
  ('ACCOUNTANT','finance.ledger.read'), ('ACCOUNTANT','finance.journal.create'), ('ACCOUNTANT','finance.cash.read'), ('ACCOUNTANT','finance.cash.voucher'),
  ('ACCOUNTANT','finance.bank.reconcile'), ('ACCOUNTANT','finance.coa.review'), ('ACCOUNTANT','finance.statement.read'),
  ('FIN_MANAGER','finance.ledger.read'), ('FIN_MANAGER','finance.journal.reverse'), ('FIN_MANAGER','finance.period.lock'), ('FIN_MANAGER','finance.statement.read'),
  ('FIN_MANAGER','finance.coa.manage'), ('FIN_MANAGER','finance.cash.read'),
  ('MD','finance.ledger.read'), ('MD','finance.statement.read'), ('MD','finance.factory_pnl.read'), ('AUDITOR','finance.ledger.read'), ('AUDITOR','finance.statement.read')) v(x, y)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values ('FIN_MANAGER', 'finance.journal.post', 'allow', 'COMPANY') on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('finance');

-- ================================================================ engine
create function finance.fn_check_date(p_company uuid, p_date date, p_manual boolean) returns void
language plpgsql stable security definer set search_path = pg_catalog as $$
begin
  if p_date is null or p_date > current_date then raise exception 'E_INVALID_ACTION: journal date' using errcode = 'P0001'; end if;
  if exists (select 1 from finance.period p where p.company_id = p_company and p.month = date_trunc('month', p_date)::date and p.status = 'closed') then
    raise exception 'E_PERIOD_CLOSED: % is closed', to_char(p_date, 'YYYY-MM') using errcode = 'P0001';
  end if;
  if p_manual and p_date < current_date - config.fn_get_int(p_company, 'finance.backdate.max_days') then
    raise exception 'E_BACKDATE: further back than the allowed days' using errcode = 'P0001';
  end if;
end $$;

create function finance.fn_coa_ready(p_company uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from finance.coa_version v where v.company_id = p_company and v.status = 'approved')
      or (not config.fn_get_bool(p_company, 'finance.posting.requires_reviewed_coa') and exists (select 1 from finance.account a where a.company_id = p_company))
$$;

-- Posts a draft / approved journal: balanced, active postable accounts, open period; unique posting key (F114).
create function finance.fn_post_journal(p_journal uuid, p_manual boolean) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare j finance.journal%rowtype; v_dr numeric; v_cr numeric;
begin
  select * into j from finance.journal where id = p_journal for update;
  if j.status not in ('draft','pending_approval') then return; end if;
  if not finance.fn_coa_ready(j.company_id) then raise exception 'E_COA_NOT_APPROVED' using errcode = 'P0001'; end if;
  perform finance.fn_check_date(j.company_id, j.journal_date, p_manual);
  select coalesce(sum(l.debit), 0), coalesce(sum(l.credit), 0) into v_dr, v_cr from finance.journal_line l where l.journal_id = j.id;
  if v_dr = 0 or v_dr <> v_cr then raise exception 'E_JOURNAL_UNBALANCED: debit % credit %', v_dr, v_cr using errcode = 'P0001'; end if;
  if exists (select 1 from finance.journal_line l join finance.account a on a.id = l.account_id where l.journal_id = j.id and (a.status <> 'active' or not a.postable)) then
    raise exception 'E_INVALID_ACTION: inactive or summary account in the journal' using errcode = 'P0001';
  end if;
  update finance.journal set status = 'posted', total = v_dr, posted_at = clock_timestamp(), posted_by = iam.fn_current_person(),
         posting_key = coalesce(posting_key, 'journal:' || id), number = coalesce(number, core.fn_next_number(company_id, 'finance.journal', id)) where id = j.id;
end $$;

-- Module event -> posted journal (ADR-07: approved CoA + every mapping, else it stays queued with the reason).
create function finance.fn_post_event(p_event uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare e finance.gl_event%rowtype; l jsonb; v_acc uuid; v_jid uuid := gen_random_uuid(); n integer := 0; v_dr numeric := 0; v_cr numeric := 0; d numeric; c numeric; v_diff numeric;
begin
  select * into e from finance.gl_event where id = p_event for update;
  if e.status = 'posted' then return; end if;
  if not finance.fn_coa_ready(e.company_id) then raise exception 'E_COA_NOT_APPROVED' using errcode = 'P0001'; end if;
  insert into finance.journal (id, company_id, journal_date, source, posting_key, memo, created_by)
  values (v_jid, e.company_id, greatest(e.event_date, coalesce((select max(p.month + interval '1 month')::date from finance.period p where p.company_id = e.company_id and p.status = 'closed'), e.event_date)),
          'module', e.source_key, e.memo, iam.fn_current_person());
  for l in select * from jsonb_array_elements(e.lines) loop
    select m.account_id into v_acc from finance.gl_mapping m where m.company_id = e.company_id and m.event_key = l ->> 'key';
    if v_acc is null then raise exception 'E_GL_MAPPING_MISSING: %', l ->> 'key' using errcode = 'P0001'; end if;
    d := finance.fn_round(e.company_id, coalesce((l ->> 'dr')::numeric, 0)); c := finance.fn_round(e.company_id, coalesce((l ->> 'cr')::numeric, 0));
    if d = 0 and c = 0 then continue; end if;
    n := n + 1;
    insert into finance.journal_line (company_id, journal_id, line_no, account_id, debit, credit, wing_id, product_id, memo)
    values (e.company_id, v_jid, n, v_acc, d, c, (l ->> 'wing_id')::uuid, (l ->> 'product_id')::uuid, l ->> 'memo');
    v_dr := v_dr + d; v_cr := v_cr + c;
  end loop;
  v_diff := v_dr - v_cr;
  if v_diff <> 0 then
    if abs(v_diff) > 0.05 then raise exception 'E_JOURNAL_UNBALANCED: event % off by %', e.source_key, v_diff using errcode = 'P0001'; end if;
    select m.account_id into v_acc from finance.gl_mapping m where m.company_id = e.company_id and m.event_key = 'fin.rounding';
    if v_acc is null then raise exception 'E_GL_MAPPING_MISSING: fin.rounding' using errcode = 'P0001'; end if;
    n := n + 1;
    insert into finance.journal_line (company_id, journal_id, line_no, account_id, debit, credit, memo)
    values (e.company_id, v_jid, n, v_acc, greatest(-v_diff, 0), greatest(v_diff, 0), 'ADR-09 rounding');
  end if;
  if n = 0 then
    update finance.journal set status = 'cancelled' where id = v_jid;
    update finance.gl_event set status = 'posted', posted_at = clock_timestamp(), error = 'zero value' where id = e.id;
    return;
  end if;
  perform finance.fn_post_journal(v_jid, false);
  update finance.gl_event set status = 'posted', journal_id = v_jid, posted_at = clock_timestamp(), error = null where id = e.id;
end $$;

-- Emits a module event and tries to post it; a failure never blocks the business document (status error + reason).
create function finance.fn_emit(p_company uuid, p_source_key text, p_memo text, p_lines jsonb) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare v_id uuid;
begin
  insert into finance.gl_event (company_id, source_key, event_date, memo, lines) values (p_company, p_source_key, current_date, p_memo, p_lines)
  on conflict (company_id, source_key) do nothing returning id into v_id;
  if v_id is null then return; end if;                                -- idempotent (F114)
  begin
    perform finance.fn_post_event(v_id);
  exception when others then
    update finance.gl_event set status = 'error', error = left(sqlerrm, 300) where id = v_id;
  end;
end $$;

create function finance.fn_retry_events(p_company uuid) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare e record; n integer := 0;
begin
  for e in select id from finance.gl_event where company_id = p_company and status in ('pending','error') order by created_at loop
    begin
      perform finance.fn_post_event(e.id); n := n + 1;
    exception when others then
      update finance.gl_event set status = 'error', error = left(sqlerrm, 300) where id = e.id;
    end;
  end loop;
  return n;
end $$;

-- ================================================================ module postings (OI-40, OI-41, OI-45)
create function finance.fn_inv_key(p_product uuid) returns text
language sql stable security definer set search_path = pg_catalog as $$
  select case p.kind when 'finished_good' then 'inv.fg' when 'trading' then 'inv.trading' else 'inv.raw' end from inventory.product p where p.id = p_product
$$;

-- Batch issue? (WIP) or other consumption.
create function finance.fn_issue_target(p_company uuid, p_batch_ref text) returns text
language sql stable security definer set search_path = pg_catalog as $$
  select case when exists (select 1 from mfg.batch b where b.company_id = p_company and b.number = p_batch_ref) then 'mfg.wip' else 'inv.consumption' end
$$;

create function finance.fn_on_stock_move() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare k text := finance.fn_inv_key(new.product_id); v numeric := abs(new.value); src text; t text; rk text;
begin
  if v = 0 then return null; end if;
  src := 'stock:' || new.id;
  if new.move_type = 'opening' then
    perform finance.fn_emit(new.company_id, src, 'শুরুর মজুদ', jsonb_build_array(jsonb_build_object('key', k, 'dr', v, 'product_id', new.product_id), jsonb_build_object('key', 'inv.opening', 'cr', v)));
  elsif new.move_type in ('receipt','quarantine_release') then
    select r.kind into rk from inventory.receipt r
     where r.id = case when new.doc_type = 'inventory.receipt' then new.doc_id else (select h.receipt_id from inventory.quarantine_hold h where h.id = new.doc_id) end;
    perform finance.fn_emit(new.company_id, src, 'মাল-গ্রহণ', jsonb_build_array(jsonb_build_object('key', k, 'dr', v, 'product_id', new.product_id),
                                                                              jsonb_build_object('key', case when rk = 'grn' then 'proc.grni' else 'inv.opening' end, 'cr', v)));
  elsif new.move_type = 'return' and new.doc_type = 'inventory.return' then
    select finance.fn_issue_target(new.company_id, mi.batch_ref) into t from inventory.material_return r join inventory.material_issue mi on mi.id = r.issue_id where r.id = new.doc_id;
    perform finance.fn_emit(new.company_id, src, 'কাঁচামাল ফেরত', jsonb_build_array(jsonb_build_object('key', k, 'dr', v, 'product_id', new.product_id), jsonb_build_object('key', t, 'cr', v)));
  elsif new.move_type in ('waste_normal','waste_abnormal') then
    perform finance.fn_emit(new.company_id, src, 'অপচয়', jsonb_build_array(jsonb_build_object('key', case when new.move_type = 'waste_normal' then 'inv.waste_normal' else 'inv.waste_abnormal' end,
                                                                           'dr', v, 'product_id', new.product_id), jsonb_build_object('key', k, 'cr', v)));
  elsif new.move_type = 'adjust_in' then
    perform finance.fn_emit(new.company_id, src, 'মজুদ-সমন্বয়', jsonb_build_array(jsonb_build_object('key', k, 'dr', v, 'product_id', new.product_id), jsonb_build_object('key', 'inv.adjust_gain', 'cr', v)));
  elsif new.move_type = 'adjust_out' then
    perform finance.fn_emit(new.company_id, src, 'মজুদ-সমন্বয়', jsonb_build_array(jsonb_build_object('key', 'inv.adjust_loss', 'dr', v), jsonb_build_object('key', k, 'cr', v, 'product_id', new.product_id)));
  end if;
  -- issue (posted from the issue document), transfers (same account), fg_receipt and rework input (from WIP entries),
  -- purchase_return (from the debit note) post elsewhere.
  return null;
end $$;
create trigger trg_stock_move_gl after insert on inventory.stock_move for each row execute function finance.fn_on_stock_move();

create function finance.fn_on_material_issue() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare t text := finance.fn_issue_target(new.company_id, new.batch_ref); lines jsonb := '[]'::jsonb; m record;
begin
  for m in select s.product_id, -sum(s.value) v from inventory.stock_move s where s.doc_type = 'inventory.issue' and s.doc_id = new.id group by s.product_id loop
    lines := lines || jsonb_build_array(jsonb_build_object('key', t, 'dr', m.v), jsonb_build_object('key', finance.fn_inv_key(m.product_id), 'cr', m.v, 'product_id', m.product_id));
  end loop;
  if jsonb_array_length(lines) > 0 then perform finance.fn_emit(new.company_id, 'issue:' || new.id, 'কাঁচামাল ইস্যু ' || new.batch_ref, lines); end if;
  return null;
end $$;
create trigger trg_material_issue_gl after insert on inventory.material_issue for each row execute function finance.fn_on_material_issue();

create function finance.fn_on_wip_entry() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v numeric := abs(new.amount); p uuid; k text;
begin
  if v = 0 or new.kind = 'material' then return null; end if;                      -- materials posted at issue / return
  select b.product_id into p from mfg.batch b where b.id = new.batch_id;
  k := case new.kind when 'labor' then 'mfg.labor' when 'overhead' then 'mfg.overhead' when 'abnormal' then 'mfg.abnormal' when 'scrap' then 'mfg.scrap'
                     when 'variance' then 'mfg.variance' when 'fg' then 'inv.fg' when 'rework_input' then 'inv.fg' end;
  if new.kind in ('labor','overhead','rework_input') then
    perform finance.fn_emit(new.company_id, 'wip:' || new.id, 'WIP ' || new.kind, jsonb_build_array(jsonb_build_object('key', 'mfg.wip', 'dr', v, 'product_id', p),
                                                                                                   jsonb_build_object('key', k, 'cr', v, 'product_id', p)));
  else
    perform finance.fn_emit(new.company_id, 'wip:' || new.id, 'WIP ' || new.kind, jsonb_build_array(jsonb_build_object('key', k, 'dr', v, 'product_id', p),
                                                                                                   jsonb_build_object('key', 'mfg.wip', 'cr', v, 'product_id', p)));
  end if;
  return null;
end $$;
create trigger trg_wip_entry_gl after insert on mfg.wip_entry for each row execute function finance.fn_on_wip_entry();

create function finance.fn_on_procurement() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v_grni numeric; v_stock numeric;
begin
  if new.status <> 'posted' or old.status = 'posted' then return null; end if;
  if tg_table_name = 'bill' then
    select coalesce(sum(round(bl.qty * g.unit_price, 4)), 0) into v_grni from procurement.bill_line bl join procurement.grn_line g on g.id = bl.grn_line_id where bl.bill_id = new.id;
    perform finance.fn_emit(new.company_id, 'bill:' || new.id, 'সাপ্লায়ার-বিল ' || new.number, jsonb_build_array(
      jsonb_build_object('key', 'proc.grni', 'dr', v_grni),
      jsonb_build_object('key', 'proc.price_variance', 'dr', greatest(new.total - v_grni, 0), 'cr', greatest(v_grni - new.total, 0)),
      jsonb_build_object('key', 'proc.ap', 'cr', new.total)));
  elsif tg_table_name = 'payment' then
    perform finance.fn_emit(new.company_id, 'payment:' || new.id, 'সাপ্লায়ার-পরিশোধ ' || new.number, jsonb_build_array(
      jsonb_build_object('key', 'proc.ap', 'dr', new.amount), jsonb_build_object('key', case new.method when 'bank' then 'fin.bank' else 'fin.cash' end, 'cr', new.amount)));
  elsif tg_table_name = 'debit_note' then
    if new.kind = 'price' then
      perform finance.fn_emit(new.company_id, 'debit:' || new.id, 'ডেবিট-নোট ' || new.number, jsonb_build_array(
        jsonb_build_object('key', 'proc.ap', 'dr', new.amount), jsonb_build_object('key', 'proc.price_variance', 'cr', new.amount)));
    else
      select coalesce(-sum(m.value), 0) into v_stock from inventory.stock_move m where m.doc_type = 'procurement.debit_note' and m.doc_id = new.id;
      perform finance.fn_emit(new.company_id, 'debit:' || new.id, 'ক্রয়-ফেরত ' || new.number, jsonb_build_array(
        jsonb_build_object('key', case when new.bill_id is not null then 'proc.ap' else 'proc.grni' end, 'dr', new.amount),
        jsonb_build_object('key', 'inv.raw', 'cr', v_stock),
        jsonb_build_object('key', 'proc.price_variance', 'dr', greatest(v_stock - new.amount, 0), 'cr', greatest(new.amount - v_stock, 0))));
    end if;
  end if;
  return null;
end $$;
create trigger trg_bill_gl after update of status on procurement.bill for each row execute function finance.fn_on_procurement();
create trigger trg_payment_gl after update of status on procurement.payment for each row execute function finance.fn_on_procurement();
create trigger trg_debit_note_gl after update of status on procurement.debit_note for each row execute function finance.fn_on_procurement();

-- ================================================================ API: chart of accounts (F111)
create function api.v1_coa_seed_default(p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v integer; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.coa.manage', iam.fn_my_company_resource(), true);
  v := coalesce((select max(x.version) from finance.coa_version x where x.company_id = me.company_id), 0) + 1;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into finance.coa_version (company_id, version, snapshot, reason, created_by)
  values (me.company_id, v, jsonb_build_object(
            'accounts', (select jsonb_agg(jsonb_build_object('code', t.code, 'name_bn', t.name_bn, 'type', t.type, 'parent', t.parent, 'postable', t.postable) order by t.code) from finance.coa_template t),
            'mappings', (select jsonb_object_agg(m.event_key, m.code) from finance.mapping_template m)), p_reason, me.person_id)
  returning id into v_id;
  return jsonb_build_object('version_id', v_id, 'version', v, 'status', 'draft');
end $$;

create function api.v1_coa_draft_save(p_version_id uuid, p_snapshot jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v finance.coa_version%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.coa.manage', iam.fn_my_company_resource(), true);
  select * into v from finance.coa_version where id = p_version_id and company_id = me.company_id for update;
  if not found or v.status <> 'draft' then perform core.fn_raise('E_INVALID_ACTION', 'only a draft is edited'); end if;
  if jsonb_typeof(p_snapshot -> 'accounts') is distinct from 'array' or jsonb_typeof(p_snapshot -> 'mappings') is distinct from 'object'
     or exists (select 1 from jsonb_array_elements(p_snapshot -> 'accounts') a where coalesce(a ->> 'code', '') !~ '^[0-9]{4,8}$'
                  or coalesce(a ->> 'type', '') not in ('asset','liability','equity','income','expense'))
     or exists (select 1 from jsonb_each_text(p_snapshot -> 'mappings') m where not exists (select 1 from jsonb_array_elements(p_snapshot -> 'accounts') a
                  where a ->> 'code' = m.value and coalesce((a ->> 'postable')::boolean, true))) then
    perform core.fn_raise('E_INVALID_ACTION', 'accounts need 4–8 digit codes and a type; every mapping points to a postable account');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update finance.coa_version set snapshot = p_snapshot, reason = p_reason where id = v.id;
  return jsonb_build_object('version_id', v.id, 'status', 'draft');
end $$;

-- Review by a qualified accountant (finance.coa.review), then approval by the Chairman — never the same person (ADR-07).
create function api.v1_coa_review(p_version_id uuid, p_approve boolean, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v finance.coa_version%rowtype;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.coa.review', iam.fn_my_company_resource(), true);
  select * into v from finance.coa_version where id = p_version_id and company_id = me.company_id for update;
  if not found or v.status <> 'draft' then perform core.fn_raise('E_NOT_FOUND', 'draft chart'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  update finance.coa_version set status = case when p_approve then 'reviewed' else 'rejected' end, reviewed_by = me.person_id, reviewed_at = clock_timestamp() where id = v.id;
  return jsonb_build_object('version_id', v.id, 'status', case when p_approve then 'reviewed' else 'rejected' end);
end $$;

create function api.v1_coa_approve(p_version_id uuid, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v finance.coa_version%rowtype; a jsonb; m record; v_retried integer;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_context(true);
  if not me.is_supreme then perform core.fn_raise('E_FORBIDDEN', 'the Chairman approves the chart of accounts'); end if;
  select * into v from finance.coa_version where id = p_version_id and company_id = me.company_id for update;
  if not found or v.status <> 'reviewed' then perform core.fn_raise('E_INVALID_ACTION', 'the chart must be reviewed first'); end if;
  if v.reviewed_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'reviewer and approver differ'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  for a in select * from jsonb_array_elements(v.snapshot -> 'accounts') loop
    insert into finance.account (company_id, code, name_bn, type, parent_code, postable)
    values (me.company_id, a ->> 'code', a ->> 'name_bn', a ->> 'type', a ->> 'parent', coalesce((a ->> 'postable')::boolean, true))
    on conflict (company_id, code) do update set name_bn = excluded.name_bn, type = excluded.type, parent_code = excluded.parent_code, postable = excluded.postable, status = 'active';
  end loop;
  for m in select x.id, x.code from finance.account x where x.company_id = me.company_id and x.status = 'active'
             and not exists (select 1 from jsonb_array_elements(v.snapshot -> 'accounts') y where y ->> 'code' = x.code) loop
    if exists (select 1 from finance.journal_line l join finance.journal j on j.id = l.journal_id where l.account_id = m.id and j.status in ('posted','reversed')) then
      perform core.fn_raise('E_ACCOUNT_IN_USE', m.code);                     -- posted accounts are never removed (F111)
    end if;
    update finance.account set status = 'inactive' where id = m.id;
  end loop;
  delete from finance.gl_mapping where company_id = me.company_id;
  insert into finance.gl_mapping (company_id, event_key, account_id, coa_version)
  select me.company_id, e.key, x.id, v.version from jsonb_each_text(v.snapshot -> 'mappings') e join finance.account x on x.company_id = me.company_id and x.code = e.value;
  update finance.coa_version set status = 'superseded' where company_id = me.company_id and status = 'approved';
  update finance.coa_version set status = 'approved', approved_by = me.person_id, approved_at = clock_timestamp() where id = v.id;
  v_retried := finance.fn_retry_events(me.company_id);
  return jsonb_build_object('version_id', v.id, 'status', 'approved', 'events_retried', v_retried);
end $$;

create function api.v1_accounts() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'code', a.code, 'name_bn', a.name_bn, 'type', a.type, 'parent', a.parent_code, 'postable', a.postable,
           'status', a.status, 'mapped', (select jsonb_agg(m.event_key) from finance.gl_mapping m where m.account_id = a.id)) order by a.code)
     from finance.account a where a.company_id = me.company_id), '[]'::jsonb);
end $$;

-- ================================================================ API: journals (F112–F115)
-- lines: [{account_code, debit, credit, wing_id, product_id, memo}] — each line one side only.
create function api.v1_journal_save(p_id uuid, p_date date, p_memo text, p_lines jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := coalesce(p_id, gen_random_uuid()); l jsonb; n integer := 0; v_acc uuid;
begin
  select * into me from iam.fn_require('finance.journal.create', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_memo, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform finance.fn_check_date(me.company_id, p_date, true);
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 2 and 200 then perform core.fn_raise('E_INVALID_ACTION', 'at least two lines'); end if;
  perform set_config('mohona.change_reason', p_memo, true);
  if p_id is null then
    insert into finance.journal (id, company_id, journal_date, source, memo, created_by) values (v_id, me.company_id, p_date, 'manual', p_memo, me.person_id);
  else
    if not exists (select 1 from finance.journal j where j.id = p_id and j.company_id = me.company_id and j.status = 'draft' and j.created_by = me.person_id) then
      perform core.fn_raise('E_NOT_FOUND', 'own draft journal');
    end if;
    delete from finance.journal_line where journal_id = p_id;
    update finance.journal set journal_date = p_date, memo = p_memo where id = p_id;
  end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    select a.id into v_acc from finance.account a where a.company_id = me.company_id and a.code = l ->> 'account_code' and a.status = 'active' and a.postable;
    if v_acc is null then perform core.fn_raise('E_NOT_FOUND', 'postable account ' || coalesce(l ->> 'account_code', '?')); end if;
    insert into finance.journal_line (company_id, journal_id, line_no, account_id, debit, credit, wing_id, product_id, memo)
    values (me.company_id, v_id, n, v_acc, finance.fn_round(me.company_id, coalesce((l ->> 'debit')::numeric, 0)), finance.fn_round(me.company_id, coalesce((l ->> 'credit')::numeric, 0)),
            (l ->> 'wing_id')::uuid, (l ->> 'product_id')::uuid, l ->> 'memo');
  end loop;
  update finance.journal set total = (select coalesce(sum(x.debit), 0) from finance.journal_line x where x.journal_id = v_id) where id = v_id;
  return jsonb_build_object('journal_id', v_id, 'balanced', (select sum(x.debit) = sum(x.credit) from finance.journal_line x where x.journal_id = v_id));
end $$;

-- Submit: balanced only; the approval engine decides (submitter never approves); approved = posted.
create function api.v1_journal_submit(p_journal_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; j finance.journal%rowtype; v_dr numeric; v_cr numeric; r jsonb; ar core.approval_request%rowtype;
begin
  select * into me from iam.fn_require('finance.journal.create', iam.fn_my_company_resource(), true);
  select * into j from finance.journal where id = p_journal_id and company_id = me.company_id for update;
  if not found or j.status <> 'draft' then perform core.fn_raise('E_NOT_FOUND', 'draft journal'); end if;
  select coalesce(sum(l.debit), 0), coalesce(sum(l.credit), 0) into v_dr, v_cr from finance.journal_line l where l.journal_id = j.id;
  if v_dr = 0 or v_dr <> v_cr then perform core.fn_raise('E_JOURNAL_UNBALANCED', 'debit ' || v_dr || ' credit ' || v_cr); end if;
  perform finance.fn_check_date(me.company_id, j.journal_date, true);
  perform set_config('mohona.change_reason', j.memo, true);
  update finance.journal set status = 'pending_approval', number = core.fn_next_number(me.company_id, 'finance.journal', j.id) where id = j.id;
  r := core.fn_approval_submit(me.company_id, 'finance.journal', j.id, v_dr, iam.fn_resource(me.company_id), null);
  update finance.journal set approval_request_id = (r ->> 'request_id')::uuid where id = j.id;
  if r ->> 'status' = 'approved' then perform finance.fn_post_journal(j.id, true); end if;
  return jsonb_build_object('journal_id', j.id, 'status', (select x.status from finance.journal x where x.id = j.id), 'number', (select x.number from finance.journal x where x.id = j.id));
end $$;

-- Reversal (F115): a new journal referencing the original with every line swapped; the original becomes reversed.
create function api.v1_journal_reverse(p_journal_id uuid, p_date date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; j finance.journal%rowtype; v_id uuid := gen_random_uuid();
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.journal.reverse', iam.fn_my_company_resource(), true);
  select * into j from finance.journal where id = p_journal_id and company_id = me.company_id for update;
  if not found or j.status <> 'posted' or j.reversal_of is not null then perform core.fn_raise('E_INVALID_ACTION', 'only a posted original is reversed'); end if;
  perform finance.fn_check_date(me.company_id, coalesce(p_date, current_date), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into finance.journal (id, company_id, journal_date, source, posting_key, memo, reversal_of, created_by)
  values (v_id, me.company_id, coalesce(p_date, current_date), 'reversal', 'reversal:' || j.id, 'রিভার্সাল: ' || j.memo || ' — ' || p_reason, j.id, me.person_id);
  insert into finance.journal_line (company_id, journal_id, line_no, account_id, debit, credit, wing_id, product_id, memo)
  select me.company_id, v_id, l.line_no, l.account_id, l.credit, l.debit, l.wing_id, l.product_id, l.memo from finance.journal_line l where l.journal_id = j.id;
  perform finance.fn_post_journal(v_id, true);
  update finance.journal set status = 'reversed', reversed_by = v_id where id = j.id;
  return jsonb_build_object('reversal_id', v_id, 'original', j.id);
end $$;

-- ================================================================ API: periods (F116), queue, reports
create function api.v1_period_close(p_month date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_m date := date_trunc('month', p_month)::date;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.period.lock', iam.fn_my_company_resource(), true);
  if v_m >= date_trunc('month', current_date)::date then perform core.fn_raise('E_INVALID_ACTION', 'only a past month is closed'); end if;
  if exists (select 1 from finance.journal j where j.company_id = me.company_id and j.status in ('draft','pending_approval') and date_trunc('month', j.journal_date)::date = v_m)
     or exists (select 1 from finance.gl_event e where e.company_id = me.company_id and e.status <> 'posted' and date_trunc('month', e.event_date)::date = v_m) then
    perform core.fn_raise('E_PERIOD_NOT_READY', 'unposted journals or queued module events in that month');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into finance.period (company_id, month, status, closed_by, closed_at, reason) values (me.company_id, v_m, 'closed', me.person_id, clock_timestamp(), p_reason)
  on conflict (company_id, month) do update set status = 'closed', closed_by = excluded.closed_by, closed_at = excluded.closed_at, reason = excluded.reason;
  return jsonb_build_object('month', v_m, 'status', 'closed');
end $$;

create function api.v1_period_reopen(p_month date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_m date := date_trunc('month', p_month)::date;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.period.reopen', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  update finance.period set status = 'open', reopened_by = me.person_id, reopened_at = clock_timestamp(), reason = p_reason
   where company_id = me.company_id and month = v_m and status = 'closed';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'closed month'); end if;
  return jsonb_build_object('month', v_m, 'status', 'open');
end $$;

create function api.v1_gl_events(p_status text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', e.id, 'source_key', e.source_key, 'memo', e.memo, 'status', e.status, 'error', e.error, 'journal_id', e.journal_id,
           'created_at', e.created_at) order by e.created_at desc)
     from finance.gl_event e where e.company_id = me.company_id and (p_status is null or e.status = p_status)), '[]'::jsonb);
end $$;

create function api.v1_gl_events_retry() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.journal.post', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'retry queued postings', true);
  return jsonb_build_object('attempted', finance.fn_retry_events(me.company_id),
                            'still_open', (select count(*) from finance.gl_event e where e.company_id = me.company_id and e.status <> 'posted'));
end $$;

create function finance.fn_balance(p_account uuid, p_to date) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(l.debit - l.credit), 0) from finance.journal_line l join finance.journal j on j.id = l.journal_id
   where l.account_id = p_account and j.status in ('posted','reversed') and j.journal_date <= coalesce(p_to, current_date)
$$;

create function api.v1_trial_balance(p_as_of date default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
  return (select jsonb_build_object('as_of', coalesce(p_as_of, current_date), 'rows', coalesce(jsonb_agg(x order by x ->> 'code'), '[]'::jsonb),
                                    'debit', coalesce(sum((x ->> 'debit')::numeric), 0), 'credit', coalesce(sum((x ->> 'credit')::numeric), 0))
            from (select jsonb_build_object('code', a.code, 'name_bn', a.name_bn, 'type', a.type, 'debit', greatest(b.bal, 0), 'credit', greatest(-b.bal, 0)) x
                    from finance.account a cross join lateral (select finance.fn_balance(a.id, p_as_of) bal) b
                   where a.company_id = me.company_id and b.bal <> 0) q);
end $$;

create function api.v1_ledger(p_account_code text, p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; a finance.account%rowtype; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
  select * into a from finance.account where company_id = me.company_id and code = p_account_code;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'account'); end if;
  return jsonb_build_object('account', a.code, 'name_bn', a.name_bn, 'opening', finance.fn_balance(a.id, f - 1),
    'lines', coalesce((select jsonb_agg(jsonb_build_object('date', q.journal_date, 'number', q.number, 'memo', q.memo, 'debit', q.debit, 'credit', q.credit, 'source', q.source,
                                'balance', q.bal) order by q.rn)
                         from (select j.journal_date, j.number, j.memo, l.debit, l.credit, j.source,
                                      row_number() over (order by j.journal_date, j.posted_at, l.id) rn,
                                      finance.fn_balance(a.id, f - 1) + sum(l.debit - l.credit) over (order by j.journal_date, j.posted_at, l.id) bal
                                 from finance.journal_line l join finance.journal j on j.id = l.journal_id
                                where l.account_id = a.id and j.status in ('posted','reversed') and j.journal_date between f and t) q), '[]'::jsonb));
end $$;

-- Income statement + balance sheet (statement readers).
create function api.v1_statements(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('year', current_date)::date); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('finance.statement.read', iam.fn_my_company_resource(), false);
  return (with mv as (select a.code, a.name_bn, a.type, coalesce(sum(l.debit - l.credit) filter (where j.journal_date between f and t), 0) period_bal,
                             coalesce(sum(l.debit - l.credit) filter (where j.journal_date <= t), 0) closing_bal
                        from finance.account a left join finance.journal_line l on l.account_id = a.id
                        left join finance.journal j on j.id = l.journal_id and j.status in ('posted','reversed')
                       where a.company_id = me.company_id group by a.code, a.name_bn, a.type)
    select jsonb_build_object('from', f, 'to', t,
      'income', coalesce((select sum(-period_bal) from mv where type = 'income'), 0), 'expense', coalesce((select sum(period_bal) from mv where type = 'expense'), 0),
      'net_profit', coalesce((select sum(-period_bal) from mv where type in ('income','expense')), 0),
      'assets', coalesce((select sum(closing_bal) from mv where type = 'asset'), 0), 'liabilities', coalesce((select sum(-closing_bal) from mv where type = 'liability'), 0),
      'equity', coalesce((select sum(-closing_bal) from mv where type in ('equity','income','expense')), 0),
      'lines', coalesce((select jsonb_agg(jsonb_build_object('code', code, 'name_bn', name_bn, 'type', type, 'period', period_bal, 'closing', closing_bal) order by code)
                          from mv where period_bal <> 0 or closing_bal <> 0), '[]'::jsonb)));
end $$;

-- ================================================================ API: cash (F117) + bank (F118)
create function api.v1_cash_account_save(p_code text, p_name_bn text, p_account_code text, p_custodian uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_acc uuid; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.coa.manage', iam.fn_my_company_resource(), true);
  select a.id into v_acc from finance.account a where a.company_id = me.company_id and a.code = p_account_code and a.type = 'asset' and a.postable;
  if v_acc is null then perform core.fn_raise('E_NOT_FOUND', 'postable asset account'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into finance.cash_account (company_id, code, name_bn, account_id, custodian) values (me.company_id, upper(p_code), p_name_bn, v_acc, p_custodian) returning id into v_id;
  return jsonb_build_object('cash_account_id', v_id);
end $$;

-- Voucher (receipt or payment) = a journal on the cash account, through the approval engine.
create function api.v1_cash_voucher(p_cash_account_id uuid, p_kind text, p_amount numeric, p_counter_account_code text, p_memo text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c finance.cash_account%rowtype; v_counter uuid; v_id uuid := gen_random_uuid(); v_amt numeric; r jsonb;
begin
  select * into me from iam.fn_require('finance.cash.voucher', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_memo, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into c from finance.cash_account where id = p_cash_account_id and company_id = me.company_id and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'cash account'); end if;
  select a.id into v_counter from finance.account a where a.company_id = me.company_id and a.code = p_counter_account_code and a.status = 'active' and a.postable;
  v_amt := finance.fn_round(me.company_id, p_amount);
  if v_counter is null or v_counter = c.account_id or coalesce(v_amt, 0) <= 0 or coalesce(p_kind, '') not in ('receipt','payment') then
    perform core.fn_raise('E_INVALID_ACTION', 'kind / amount / counter account');
  end if;
  if p_kind = 'payment' and v_amt > finance.fn_balance(c.account_id, current_date) then perform core.fn_raise('E_INSUFFICIENT_CASH'); end if;
  perform set_config('mohona.change_reason', p_memo, true);
  insert into finance.journal (id, company_id, journal_date, source, memo, created_by) values (v_id, me.company_id, current_date, 'voucher', p_memo, me.person_id);
  insert into finance.journal_line (company_id, journal_id, line_no, account_id, debit, credit) values
    (me.company_id, v_id, 1, c.account_id, case when p_kind = 'receipt' then v_amt else 0 end, case when p_kind = 'payment' then v_amt else 0 end),
    (me.company_id, v_id, 2, v_counter, case when p_kind = 'payment' then v_amt else 0 end, case when p_kind = 'receipt' then v_amt else 0 end);
  update finance.journal set status = 'pending_approval', total = v_amt, number = core.fn_next_number(me.company_id, 'finance.journal', v_id) where id = v_id;
  r := core.fn_approval_submit(me.company_id, 'finance.journal', v_id, v_amt, iam.fn_resource(me.company_id), null);
  update finance.journal set approval_request_id = (r ->> 'request_id')::uuid where id = v_id;
  if r ->> 'status' = 'approved' then perform finance.fn_post_journal(v_id, false); end if;
  return jsonb_build_object('journal_id', v_id, 'status', (select j.status from finance.journal j where j.id = v_id));
end $$;

-- Drawer count (F117): compared with the book; the difference is recorded (a voucher settles it).
create function api.v1_cash_count(p_cash_account_id uuid, p_counted numeric, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c finance.cash_account%rowtype; v_book numeric;
begin
  select * into me from iam.fn_require('finance.cash.read', iam.fn_my_company_resource(), true);
  select * into c from finance.cash_account where id = p_cash_account_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'cash account'); end if;
  if coalesce(p_counted, -1) < 0 then perform core.fn_raise('E_INVALID_ACTION', 'counted'); end if;
  v_book := finance.fn_balance(c.account_id, current_date);
  perform set_config('mohona.change_reason', coalesce(p_note, 'cash count'), true);
  insert into finance.cash_count (company_id, cash_account_id, counted, book_balance, difference, counted_by, note)
  values (me.company_id, c.id, p_counted, v_book, p_counted - v_book, me.person_id, p_note);
  return jsonb_build_object('book', v_book, 'counted', p_counted, 'difference', p_counted - v_book);
end $$;

create function api.v1_bank_account_save(p_code text, p_bank_name text, p_account_masked text, p_account_code text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_acc uuid; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.coa.manage', iam.fn_my_company_resource(), true);
  select a.id into v_acc from finance.account a where a.company_id = me.company_id and a.code = p_account_code and a.type = 'asset' and a.postable;
  if v_acc is null then perform core.fn_raise('E_NOT_FOUND', 'postable asset account'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into finance.bank_account (company_id, code, bank_name, account_masked, account_id) values (me.company_id, upper(p_code), p_bank_name, p_account_masked, v_acc) returning id into v_id;
  return jsonb_build_object('bank_account_id', v_id);
end $$;

-- lines: [{date, amount (+in / −out), reference, description}] — a reference already imported for this account is refused.
create function api.v1_bank_statement_import(p_bank_account_id uuid, p_lines jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; l jsonb; n integer := 0;
begin
  select * into me from iam.fn_require('finance.bank.reconcile', iam.fn_my_company_resource(), true);
  if not exists (select 1 from finance.bank_account b where b.id = p_bank_account_id and b.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'bank account'); end if;
  perform set_config('mohona.change_reason', 'bank statement import', true);
  for l in select * from jsonb_array_elements(coalesce(p_lines, '[]'::jsonb)) loop
    if exists (select 1 from finance.bank_statement_line s where s.bank_account_id = p_bank_account_id and s.reference = btrim(l ->> 'reference')) then
      perform core.fn_raise('E_DUPLICATE_BANK_REF', l ->> 'reference');
    end if;
    insert into finance.bank_statement_line (company_id, bank_account_id, txn_date, amount, reference, description, imported_by)
    values (me.company_id, p_bank_account_id, (l ->> 'date')::date, (l ->> 'amount')::numeric, btrim(l ->> 'reference'), l ->> 'description', me.person_id);
    n := n + 1;
  end loop;
  return jsonb_build_object('imported', n);
end $$;

-- Match one statement line to one posted journal line on the bank's GL account with the same signed amount.
create function api.v1_bank_reconcile(p_statement_line_id uuid, p_journal_line_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s finance.bank_statement_line%rowtype; l finance.journal_line%rowtype; b finance.bank_account%rowtype;
begin
  select * into me from iam.fn_require('finance.bank.reconcile', iam.fn_my_company_resource(), true);
  select * into s from finance.bank_statement_line where id = p_statement_line_id and company_id = me.company_id for update;
  if not found or s.matched_line_id is not null then perform core.fn_raise('E_NOT_FOUND', 'unmatched statement line'); end if;
  select * into b from finance.bank_account where id = s.bank_account_id;
  select jl.* into l from finance.journal_line jl join finance.journal j on j.id = jl.journal_id
   where jl.id = p_journal_line_id and jl.company_id = me.company_id and j.status in ('posted','reversed');
  if l.id is null or l.account_id <> b.account_id or (l.debit - l.credit) <> s.amount then
    perform core.fn_raise('E_INVALID_ACTION', 'the journal line must be posted on this bank account with the same amount');
  end if;
  perform set_config('mohona.change_reason', 'bank reconciliation', true);
  update finance.bank_statement_line set matched_line_id = l.id, matched_by = me.person_id, matched_at = clock_timestamp() where id = s.id;
  return jsonb_build_object('statement_line_id', s.id, 'journal_line_id', l.id, 'matched', true);
end $$;

create function api.v1_bank_unreconciled(p_bank_account_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; b finance.bank_account%rowtype;
begin
  select * into me from iam.fn_require('finance.bank.reconcile', iam.fn_my_company_resource(), false);
  select * into b from finance.bank_account where id = p_bank_account_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'bank account'); end if;
  return jsonb_build_object('book_balance', finance.fn_balance(b.account_id, current_date),
    'statement_open', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'date', s.txn_date, 'amount', s.amount, 'reference', s.reference) order by s.txn_date)
                                  from finance.bank_statement_line s where s.bank_account_id = b.id and s.matched_line_id is null), '[]'::jsonb),
    'book_open', coalesce((select jsonb_agg(jsonb_build_object('journal_line_id', l.id, 'date', j.journal_date, 'amount', l.debit - l.credit, 'memo', j.memo) order by j.journal_date)
                             from finance.journal_line l join finance.journal j on j.id = l.journal_id
                            where l.account_id = b.account_id and j.status in ('posted','reversed')
                              and not exists (select 1 from finance.bank_statement_line s where s.matched_line_id = l.id)), '[]'::jsonb));
end $$;

-- ================================================================ API: factory P&L (F119) + product profitability (F120)
create function finance.fn_factory_pnl_allowed(p_company uuid, p_position text, p_supreme boolean, p_wing uuid) returns boolean
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare ok boolean;
begin
  if p_supreme then return true; end if;
  if not (p_position = any (config.fn_get_text_array(p_company, 'access.factory_pnl.positions'))) then return false; end if;
  select d.allowed into ok from iam.fn_authorize('finance.factory_pnl.read', iam.fn_resource(p_company, p_wing), false) d;
  return coalesce(ok, false);
end $$;

create function finance.fn_factory_pnl(p_company uuid, p_from date, p_to date, p_wing uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog as $$
  with ev as (
    select m.event_key, sum(l.debit - l.credit) amt
      from finance.journal_line l join finance.journal j on j.id = l.journal_id join finance.gl_mapping m on m.account_id = l.account_id and m.company_id = j.company_id
     where j.company_id = p_company and j.status in ('posted','reversed') and j.journal_date between p_from and p_to and (p_wing is null or l.wing_id = p_wing)
     group by m.event_key)
  select jsonb_build_object('from', p_from, 'to', p_to, 'wing_id', p_wing,
    'revenue', coalesce((select -amt from ev where event_key = 'sales.revenue'), 0),
    'cogs', coalesce((select amt from ev where event_key = 'sales.cogs'), 0),
    'materials_to_wip', coalesce((select sum(-l.credit + l.debit) from finance.journal_line l join finance.journal j on j.id = l.journal_id
                                   where j.company_id = p_company and j.source = 'module' and j.posting_key like 'issue:%' and j.status = 'posted'
                                     and j.journal_date between p_from and p_to and l.account_id = (select m.account_id from finance.gl_mapping m where m.company_id = p_company and m.event_key = 'mfg.wip')), 0),
    'labor', coalesce((select -amt from ev where event_key = 'mfg.labor'), 0), 'overhead', coalesce((select -amt from ev where event_key = 'mfg.overhead'), 0),
    'abnormal_waste', coalesce((select amt from ev where event_key in ('mfg.abnormal')), 0) + coalesce((select amt from ev where event_key = 'inv.waste_abnormal' and not exists (select 1 from finance.gl_mapping m1, finance.gl_mapping m2 where m1.company_id = p_company and m2.company_id = p_company and m1.event_key = 'mfg.abnormal' and m2.event_key = 'inv.waste_abnormal' and m1.account_id = m2.account_id)), 0),
    'scrap', coalesce((select amt from ev where event_key = 'mfg.scrap'), 0), 'variance', coalesce((select amt from ev where event_key = 'mfg.variance'), 0),
    'margin', coalesce((select -amt from ev where event_key = 'sales.revenue'), 0) - coalesce((select amt from ev where event_key = 'sales.cogs'), 0)
              - coalesce((select amt from ev where event_key in ('mfg.abnormal')), 0) - coalesce((select amt from ev where event_key = 'mfg.scrap'), 0)
              - coalesce((select amt from ev where event_key = 'mfg.variance'), 0))
$$;

-- MD-only by default (OWN-02): the Chairman, or a position in access.factory_pnl.positions WITH finance.factory_pnl.read.
create function api.v1_factory_pnl(p_from date, p_to date, p_wing_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  if not finance.fn_factory_pnl_allowed(me.company_id, me.position_code, me.is_supreme, p_wing_id) then perform core.fn_raise('E_FORBIDDEN', 'factory P&L'); end if;
  return finance.fn_factory_pnl(me.company_id, coalesce(p_from, date_trunc('month', current_date)::date), coalesce(p_to, current_date), p_wing_id);
end $$;

create function api.v1_factory_pnl_export(p_from date, p_to date, p_wing_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; r jsonb;
begin
  select * into me from iam.fn_context(false);
  if not finance.fn_factory_pnl_allowed(me.company_id, me.position_code, me.is_supreme, p_wing_id) then perform core.fn_raise('E_FORBIDDEN', 'factory P&L'); end if;
  r := finance.fn_factory_pnl(me.company_id, coalesce(p_from, date_trunc('month', current_date)::date), coalesce(p_to, current_date), p_wing_id);
  insert into finance.export_log (company_id, person_id, report, params) values (me.company_id, me.person_id, 'factory_pnl', jsonb_build_object('from', p_from, 'to', p_to, 'wing_id', p_wing_id));
  return r || jsonb_build_object('exported_at', clock_timestamp());
end $$;

-- Per finished good: POLY produced and capitalised cost from COMPLETED batches only; revenue / COGS from posted lines.
create function api.v1_product_profitability(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('finance.statement.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('product_id', p.id, 'sku', p.sku, 'name_bn', p.name_bn, 'poly_produced', x.poly, 'cost', x.cost,
           'unit_cost', case when x.poly > 0 then round(x.cost / x.poly, 4) end, 'revenue', coalesce(r.rev, 0), 'cogs', coalesce(r.cogs, 0),
           'margin', coalesce(r.rev, 0) - coalesce(r.cogs, 0)) order by p.sku)
     from inventory.product p
     cross join lateral (select coalesce(sum(b.fg_poly), 0) poly, coalesce(sum(-e.amount), 0) cost from mfg.batch b join mfg.wip_entry e on e.batch_id = b.id and e.kind = 'fg'
                          where b.product_id = p.id and b.status = 'completed' and b.completed_at::date between f and t) x
     left join lateral (select sum(l.credit - l.debit) filter (where m.event_key = 'sales.revenue') rev, sum(l.debit - l.credit) filter (where m.event_key = 'sales.cogs') cogs
                          from finance.journal_line l join finance.journal j on j.id = l.journal_id join finance.gl_mapping m on m.account_id = l.account_id and m.company_id = j.company_id
                         where l.product_id = p.id and j.status in ('posted','reversed') and j.journal_date between f and t) r on true
    where p.company_id = me.company_id and p.kind = 'finished_good' and (x.poly > 0 or coalesce(r.rev, 0) <> 0)), '[]'::jsonb);
end $$;

-- Generic approval handlers: all earlier cases + manual / voucher journals.
create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'design.layout_publish' then perform design.fn_publish_layout_version(r.company_id, r.payload ->> 'screen_key', (r.payload ->> 'version')::integer);
    when r.document_type = 'inventory.transfer' then perform inventory.fn_post_transfer(r.document_id);
    when r.document_type = 'finance.journal' then perform finance.fn_post_journal(r.document_id, false);
    when r.document_type like 'procurement.%' then perform procurement.fn_on_approved(r);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_coa_seed_default(text)', 'api.v1_coa_draft_save(uuid, jsonb, text)', 'api.v1_coa_review(uuid, boolean, text)', 'api.v1_coa_approve(uuid, text)',
      'api.v1_accounts()', 'api.v1_journal_save(uuid, date, text, jsonb)', 'api.v1_journal_submit(uuid)', 'api.v1_journal_reverse(uuid, date, text)',
      'api.v1_period_close(date, text)', 'api.v1_period_reopen(date, text)', 'api.v1_gl_events(text)', 'api.v1_gl_events_retry()', 'api.v1_trial_balance(date)',
      'api.v1_ledger(text, date, date)', 'api.v1_statements(date, date)', 'api.v1_cash_account_save(text, text, text, uuid, text)',
      'api.v1_cash_voucher(uuid, text, numeric, text, text)', 'api.v1_cash_count(uuid, numeric, text)', 'api.v1_bank_account_save(text, text, text, text, text)',
      'api.v1_bank_statement_import(uuid, jsonb)', 'api.v1_bank_reconcile(uuid, uuid)', 'api.v1_bank_unreconciled(uuid)',
      'api.v1_factory_pnl(date, date, uuid)', 'api.v1_factory_pnl_export(date, date, uuid)', 'api.v1_product_profitability(date, date)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

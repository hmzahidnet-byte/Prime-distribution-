-- 20261108000800_iam_governance_delegation.sql  (S09)
-- Governance of people and power inside ONE company (no Group, OWN-01):
--  * Company bootstrap + Chairman appointment (platform/service_role) and Chairman-to-successor transfer (propose/accept).
--  * Chairman-managed members and assignments through the app (permission + scope + rank checks): the Chairman appoints
--    the MD; nobody below the Chairman can appoint/remove a position of equal or higher rank, or act on themselves.
--  * Time-bound delegation of delegable permissions (reason, explicit scope, max length), live-checked on every use:
--    it stops the moment the delegator loses the power or the position (no delegation chains).
--  * Termination & session revocation: membership end -> assignments end -> delegations revoked -> live sessions rejected.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ---------------------------------------------------------------- delegation
create table iam.delegation (
  id                   uuid primary key default gen_random_uuid(),
  company_id           uuid not null,
  delegator_assignment uuid not null,
  delegate_assignment  uuid not null,
  permission_codes     text[] not null check (cardinality(permission_codes) between 1 and 50),
  scope_kind           text not null check (scope_kind in ('COMPANY','WING','DEPARTMENT','LOCATION')),
  scope_id             uuid,
  valid_from           timestamptz not null default clock_timestamp(),
  valid_until          timestamptz not null,
  status               text not null default 'active' check (status in ('active','revoked')),
  reason               text not null check (length(btrim(reason)) > 0),
  created_by           uuid references core.person(id),
  created_at           timestamptz not null default clock_timestamp(),
  revoked_at           timestamptz,
  revoked_by           uuid references core.person(id),
  revoke_reason        text,
  unique (id, company_id),
  check (delegator_assignment <> delegate_assignment),
  check (valid_until > valid_from),
  check ((status = 'revoked') = (revoked_at is not null)),
  check ((scope_kind = 'COMPANY') = (scope_id is null)),
  foreign key (delegator_assignment, company_id) references iam.position_assignment (id, company_id),
  foreign key (delegate_assignment, company_id) references iam.position_assignment (id, company_id)
);
create index delegation_delegate on iam.delegation (delegate_assignment) where status = 'active';
create index delegation_delegator on iam.delegation (delegator_assignment) where status = 'active';

create function iam.fn_delegation_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','revoked_at','revoked_by','revoke_reason']) <> (to_jsonb(new) - array['status','revoked_at','revoked_by','revoke_reason'])
     or old.status = 'revoked' then
    raise exception 'E_IMMUTABLE: a delegation is never edited; revoke it and create a new one' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_delegation_guard before update on iam.delegation for each row execute function iam.fn_delegation_guard();
create trigger trg_delegation_nodel before delete on iam.delegation for each row execute function core.fn_deny_delete();
create trigger trg_delegation_audit after insert or update on iam.delegation for each row execute function audit.fn_row_change();

alter table iam.assignment_permission_rule add column delegation_id uuid;
alter table iam.assignment_permission_rule add constraint assignment_rule_delegation_fk
  foreign key (delegation_id, company_id) references iam.delegation (id, company_id);
alter table iam.assignment_permission_rule add constraint assignment_rule_delegation_origin
  check ((origin = 'delegation') = (delegation_id is not null));

-- ---------------------------------------------------------------- session revocation
create table iam.session_revocation (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  person_id       uuid not null references core.person(id),
  revoked_before  timestamptz not null default clock_timestamp(),
  reason          text not null check (length(btrim(reason)) > 0),
  created_by      uuid references core.person(id),
  created_at      timestamptz not null default clock_timestamp()
);
create index session_revocation_lookup on iam.session_revocation (company_id, person_id, revoked_before desc);
create trigger trg_session_revocation_no_mutation before update or delete on iam.session_revocation for each row execute function core.fn_deny_mutation();
create trigger trg_session_revocation_audit after insert on iam.session_revocation for each row execute function audit.fn_row_change();

-- ---------------------------------------------------------------- Chairman transfer
create table iam.chairman_transfer (
  id                uuid primary key default gen_random_uuid(),
  company_id        uuid not null references core.company(id),
  from_assignment   uuid not null,
  to_membership     uuid not null,
  status            text not null default 'pending' check (status in ('pending','accepted','cancelled')),
  reason            text not null check (length(btrim(reason)) > 0),
  created_at        timestamptz not null default clock_timestamp(),
  expires_at        timestamptz not null default clock_timestamp() + interval '7 days',
  decided_at        timestamptz,
  new_assignment    uuid,
  check ((status = 'pending') = (decided_at is null)),
  foreign key (from_assignment, company_id) references iam.position_assignment (id, company_id),
  foreign key (to_membership, company_id) references iam.company_membership (id, company_id)
);
create unique index chairman_transfer_one_pending on iam.chairman_transfer (company_id) where status = 'pending';
create trigger trg_chairman_transfer_nodel before delete on iam.chairman_transfer for each row execute function core.fn_deny_delete();
create trigger trg_chairman_transfer_audit after insert or update on iam.chairman_transfer for each row execute function audit.fn_row_change();

select core.fn_apply_rls('iam', 'delegation');
select core.fn_apply_rls('iam', 'session_revocation');
select core.fn_apply_rls('iam', 'chairman_transfer');

-- ---------------------------------------------------------------- live context: + session revocation
create or replace function iam.fn_context(p_lock boolean default false)
returns table (person_id uuid, company_id uuid, membership_id uuid, assignment_id uuid, position_code text, is_supreme boolean,
               home_wing_id uuid, home_department_id uuid, home_location_id uuid)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare v_person uuid := iam.fn_require_person(); s iam.session_context%rowtype;
begin
  select * into s from iam.session_context where session_key = iam.fn_session_key();
  if not found or s.person_id <> v_person then
    perform core.fn_raise('E_NO_ACTIVE_POSITION');
  end if;
  if p_lock then
    perform 1 from core.company           where id = s.company_id    for share;
    perform 1 from iam.company_membership where id = s.membership_id for share;
    perform 1 from iam.position_assignment where id = s.assignment_id for share;
  end if;
  if exists (select 1 from iam.session_revocation v
              where v.company_id = s.company_id and v.person_id = v_person and v.revoked_before >= s.selected_at) then
    perform core.fn_raise('E_SESSION_REVOKED');
  end if;
  if not iam.fn_assignment_usable(v_person, s.assignment_id) then
    perform core.fn_raise('E_NO_ACTIVE_POSITION', 'selected position is no longer active');
  end if;
  -- ADR cross-cutting: live employment (lock order: ... assignment -> employment)
  if config.fn_get_bool(s.company_id, 'hr.require_active_employment') then
    if p_lock then
      perform 1 from hr.employment em join hr.employee e on e.id = em.employee_id
       where e.company_id = s.company_id and e.person_id = v_person and em.status <> 'terminated' for share of em;
    end if;
    if not hr.fn_employment_active(s.company_id, v_person) then
      perform core.fn_raise('E_EMPLOYMENT_INACTIVE');
    end if;
  end if;
  -- ADR-08: MFA (aal2) for the positions the Chairman lists (default CHAIRMAN, MD)
  if (select a.position_code from iam.position_assignment a where a.id = s.assignment_id) = any (config.fn_get_text_array(s.company_id, 'iam.mfa.required_positions'))
     and core.fn_jwt_claim('aal') is distinct from 'aal2' then
    perform core.fn_raise('E_MFA_REQUIRED', 'this position requires two-factor sign-in');
  end if;
  perform set_config('mohona.company_scope', s.company_id::text, true);
  return query
    select v_person, a.company_id, a.membership_id, a.id, a.position_code, pc.is_supreme, a.home_wing_id, a.home_department_id, a.home_location_id
      from iam.position_assignment a join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
     where a.id = s.assignment_id;
end $$;

-- (forward declaration: fn_decide and fn_delegation_live are mutually recursive; the real body follows fn_decide)
create function iam.fn_delegation_live(p_delegation uuid, p_permission text, r iam.resource) returns boolean
language sql stable security definer set search_path = pg_catalog as $$ select false $$;

-- ---------------------------------------------------------------- decision core for ANY assignment (used by sessions and by delegation checks)
create function iam.fn_decide(p_company uuid, p_assignment uuid, p_position_code text, p_is_supreme boolean, p_person uuid,
                              p_home_wing uuid, p_home_department uuid, p_home_location uuid,
                              p_permission text, r iam.resource, p_with_delegated boolean)
returns table (allowed boolean, reason text, rule_id uuid)
language plpgsql stable security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare x record;
begin
  if p_is_supreme then
    return query select true, 'supreme', null::uuid; return;
  end if;
  for x in select ar.id, ar.effect, ar.delegation_id
             from iam.assignment_permission_rule ar
            where ar.assignment_id = p_assignment and ar.permission_code = p_permission and ar.status = 'active'
              and (ar.valid_until is null or ar.valid_until > clock_timestamp())
              and (ar.delegation_id is null or p_with_delegated)
              and iam.fn_scope_match(ar.scope_kind, ar.scope_id, r, p_person, p_home_wing, p_home_department, p_home_location)
            order by (ar.effect = 'deny') desc, (ar.delegation_id is null) desc
  loop
    if x.delegation_id is null or iam.fn_delegation_live(x.delegation_id, p_permission, r) then
      return query select x.effect = 'allow', case when x.effect = 'allow' then (case when x.delegation_id is null then 'granted' else 'delegated' end) else 'denied_by_rule' end, x.id;
      return;
    end if;
  end loop;
  for x in select pr.id, pr.effect
             from iam.position_permission_rule pr
            where pr.company_id = p_company and pr.position_code = p_position_code and pr.permission_code = p_permission and pr.status = 'active'
              and iam.fn_scope_match(pr.scope_kind, pr.scope_id, r, p_person, p_home_wing, p_home_department, p_home_location)
            order by (pr.effect = 'deny') desc
            limit 1
  loop
    return query select x.effect = 'allow', case when x.effect = 'allow' then 'granted' else 'denied_by_rule' end, x.id;
    return;
  end loop;
  return query select false, 'no_grant', null::uuid;
end $$;

-- A delegated right is alive only while the delegation is in its window, the delegator's assignment is usable, and the
-- delegator still holds the permission for that resource through their OWN (non-delegated) rights.
create or replace function iam.fn_delegation_live(p_delegation uuid, p_permission text, r iam.resource) returns boolean
language plpgsql stable security definer set search_path = pg_catalog as $$
declare d iam.delegation%rowtype; a record; v boolean;
begin
  select * into d from iam.delegation where id = p_delegation;
  if not found or d.status <> 'active' or clock_timestamp() < d.valid_from or clock_timestamp() >= d.valid_until
     or not (p_permission = any (d.permission_codes)) then
    return false;
  end if;
  select pa.id, pa.company_id, pa.position_code, pc.is_supreme, m.person_id, pa.home_wing_id, pa.home_department_id, pa.home_location_id
    into a
    from iam.position_assignment pa
    join iam.company_membership m on m.id = pa.membership_id
    join iam.position_catalog pc on pc.company_id = pa.company_id and pc.code = pa.position_code
   where pa.id = d.delegator_assignment;
  if not found or not iam.fn_assignment_usable(a.person_id, a.id) then return false; end if;
  select allowed into v from iam.fn_decide(a.company_id, a.id, a.position_code, a.is_supreme, a.person_id,
                                           a.home_wing_id, a.home_department_id, a.home_location_id, p_permission, r, false);
  return coalesce(v, false);
end $$;

-- fn_authorize keeps its prelude (context, vocabulary, company, resource normalisation, MFA) and now delegates the rule
-- evaluation to fn_decide (with delegated rights).
create or replace function iam.fn_authorize(p_permission text, p_resource iam.resource, p_lock boolean default false)
returns table (allowed boolean, reason text, rule_id uuid, person_id uuid, company_id uuid, assignment_id uuid,
               position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare c record; p iam.permission_catalog%rowtype; r iam.resource := p_resource; v_dw uuid; v_lw uuid; d record;
begin
  select * into c from iam.fn_context(p_lock);
  select * into p from iam.permission_catalog pc where pc.code = p_permission;
  if not found then
    return query select false, 'unknown_permission', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if p.status <> 'active' then
    return query select false, 'permission_not_active', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.company_id is null or r.company_id <> c.company_id then
    return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.wing_id is not null and not exists (select 1 from core.wing w where w.id = r.wing_id and w.company_id = r.company_id) then
    return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.department_id is not null then
    select dd.wing_id into v_dw from core.department dd where dd.id = r.department_id and dd.company_id = r.company_id;
    if v_dw is null or (r.wing_id is not null and r.wing_id <> v_dw) then
      return query select false, 'inconsistent_resource', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
    end if;
    r.wing_id := v_dw;
  end if;
  if r.location_id is not null then
    if not exists (select 1 from core.location l where l.id = r.location_id and l.company_id = r.company_id) then
      return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
    end if;
    select l.wing_id into v_lw from core.location l where l.id = r.location_id;
    if v_lw is not null then
      if r.wing_id is not null and r.wing_id <> v_lw then
        return query select false, 'inconsistent_resource', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
      end if;
      r.wing_id := v_lw;
    end if;
  end if;
  if p.requires_aal2 and core.fn_jwt_claim('aal') is distinct from 'aal2' then
    return query select false, 'mfa_required', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  select * into d from iam.fn_decide(c.company_id, c.assignment_id, c.position_code, c.is_supreme, c.person_id,
                                     c.home_wing_id, c.home_department_id, c.home_location_id, p_permission, r, true);
  return query select d.allowed, d.reason, d.rule_id, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme;
end $$;

-- ---------------------------------------------------------------- cascades
-- An assignment that stops being active revokes every delegation it gave or received (and the delegated rules).
create function iam.fn_assignment_revoke_delegations() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.status <> 'active' and old.status = 'active' then
    update iam.delegation set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'assignment ' || new.status
     where status = 'active' and (delegator_assignment = new.id or delegate_assignment = new.id);
  end if;
  return null;
end $$;
create trigger trg_assignment_revoke_delegations after update of status on iam.position_assignment for each row execute function iam.fn_assignment_revoke_delegations();

create function iam.fn_delegation_revoke_rules() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.status = 'revoked' and old.status = 'active' then
    update iam.assignment_permission_rule set status = 'revoked', revoked_at = clock_timestamp(), revoked_by = new.revoked_by
     where delegation_id = new.id and status = 'active';
  end if;
  return null;
end $$;
create trigger trg_delegation_revoke_rules after update of status on iam.delegation for each row execute function iam.fn_delegation_revoke_rules();

-- Ending a membership also rejects the person's live sessions in that company.
create function iam.fn_membership_revoke_sessions() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.status in ('ended','suspended') and old.status is distinct from new.status then
    insert into iam.session_revocation (company_id, person_id, reason) values (new.company_id, new.person_id, 'membership ' || new.status);
  end if;
  return null;
end $$;
create trigger trg_membership_revoke_sessions after update of status on iam.company_membership for each row execute function iam.fn_membership_revoke_sessions();

-- Small helper: company of the current context (for resource building before fn_require).
create function iam.fn_context_company() returns uuid
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  select company_id into v from iam.fn_context(false);
  return v;
end $$;

-- ---------------------------------------------------------------- shared guards for people management
create function iam.fn_rank_of(p_company uuid, p_code text) returns integer
language sql stable security definer set search_path = pg_catalog as $$
  select rank from iam.position_catalog where company_id = p_company and code = p_code
$$;

-- Non-supreme managers act only strictly below their own rank and never on themselves.
create function iam.fn_assert_below_me(p_me_supreme boolean, p_me_company uuid, p_me_position text, p_me_person uuid,
                                       p_target_position text, p_target_person uuid) returns void
language plpgsql stable security definer set search_path = pg_catalog as $$
begin
  if p_target_position = 'CHAIRMAN' then
    perform core.fn_raise('E_CHAIRMAN_SEAT', 'the Chairman seat changes only by transfer or platform appointment');
  end if;
  if p_me_supreme then return; end if;
  if p_target_person = p_me_person then perform core.fn_raise('E_SELF_ACTION'); end if;
  if iam.fn_rank_of(p_me_company, p_target_position) >= iam.fn_rank_of(p_me_company, p_me_position) then
    perform core.fn_raise('E_RANK_TOO_HIGH', p_target_position);
  end if;
end $$;

-- ---------------------------------------------------------------- app API: people & positions (Chairman / delegated managers)
create function api.v1_iam_company_people() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.position.read', iam.fn_my_company_resource(), false);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'membership_id', m.id, 'person_id', p.id, 'full_name_bn', p.full_name_bn, 'employee_no', m.employee_no, 'status', m.status,
             'assignments', coalesce((select jsonb_agg(jsonb_build_object('assignment_id', a.id, 'position_code', a.position_code,
                                         'position_name_bn', pc.name_bn, 'rank', pc.rank, 'status', a.status, 'kind', a.assignment_kind,
                                         'valid_from', a.valid_from, 'valid_until', a.valid_until,
                                         'home_wing_id', a.home_wing_id, 'home_department_id', a.home_department_id) order by pc.rank desc)
                                        from iam.position_assignment a join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
                                       where a.membership_id = m.id and a.status <> 'ended'), '[]'::jsonb))
           order by p.full_name_bn)
      from iam.company_membership m join core.person p on p.id = m.person_id
     where m.company_id = me.company_id and m.status <> 'ended'), '[]'::jsonb);
end $$;

-- Adds a person to my company. One human = one login: an existing person with the same phone/email is reused
-- (nothing about their other companies is revealed). Login linking happens at sign-up (platform, svc).
create function api.v1_iam_add_member(p_full_name_bn text, p_phone text, p_email text, p_employee_no text, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare me record; v_person uuid; v_m uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.membership.manage', iam.fn_my_company_resource(), true);
  if p_phone is null and p_email is null then perform core.fn_raise('E_CONTACT_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  select id into v_person from core.person
   where (p_phone is not null and phone = p_phone) or (p_email is not null and lower(email) = lower(p_email))
   order by created_at limit 1;
  if v_person is null then
    insert into core.person (full_name_bn, phone, email) values (p_full_name_bn, p_phone, p_email) returning id into v_person;
  end if;
  if exists (select 1 from iam.company_membership where person_id = v_person and company_id = me.company_id and status <> 'ended') then
    perform core.fn_raise('E_DUPLICATE', 'already a member');
  end if;
  insert into iam.company_membership (person_id, company_id, employee_no, status) values (v_person, me.company_id, p_employee_no, 'active')
  returning id into v_m;
  return jsonb_build_object('person_id', v_person, 'membership_id', v_m);
end $$;

create function api.v1_iam_end_member(p_membership_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record; m iam.company_membership%rowtype; x record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.membership.manage', iam.fn_my_company_resource(), true);
  select * into m from iam.company_membership where id = p_membership_id and company_id = me.company_id for no key update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
  for x in select a.position_code from iam.position_assignment a where a.membership_id = m.id and a.status = 'active' loop
    perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, x.position_code, m.person_id);
  end loop;
  if m.person_id = me.person_id then perform core.fn_raise('E_SELF_ACTION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.company_membership set status = 'ended', ended_on = current_date, end_reason = p_reason where id = m.id;
end $$;

create function api.v1_iam_assign_position(p_membership_id uuid, p_position_code text, p_valid_from timestamptz, p_valid_until timestamptz,
                                           p_kind text, p_home_wing uuid, p_home_department uuid, p_home_location uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare me record; m iam.company_membership%rowtype; v uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  -- scope: the manager must hold iam.assignment.manage for the target unit (company / wing / department)
  select * into me from iam.fn_require('iam.assignment.manage',
           iam.fn_resource(iam.fn_context_company(), p_home_wing, p_home_department, p_home_location), true);
  select * into m from iam.company_membership where id = p_membership_id and company_id = me.company_id for no key update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, p_position_code, m.person_id);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind, valid_from, valid_until,
                                       home_wing_id, home_department_id, home_location_id)
  values (me.company_id, m.id, p_position_code, coalesce(p_kind, 'regular'), coalesce(p_valid_from, clock_timestamp()), p_valid_until,
          p_home_wing, p_home_department, p_home_location)
  returning id into v;
  return v;
end $$;

-- end | suspend | reactivate one assignment
create function api.v1_iam_change_assignment(p_assignment_id uuid, p_action text, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record; a iam.position_assignment%rowtype; v_target_person uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_action not in ('end','suspend','reactivate') then perform core.fn_raise('E_INVALID_ACTION', p_action); end if;
  select * into a from iam.position_assignment where id = p_assignment_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  select * into me from iam.fn_require('iam.assignment.manage',
           iam.fn_resource(a.company_id, a.home_wing_id, a.home_department_id, a.home_location_id), true);
  select person_id into v_target_person from iam.company_membership where id = a.membership_id for no key update;
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, a.position_code, v_target_person);
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'end' then
    update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = p_reason where id = a.id;
  elsif p_action = 'suspend' then
    update iam.position_assignment set status = 'suspended' where id = a.id and status = 'active';
  else
    update iam.position_assignment set status = 'active' where id = a.id and status = 'suspended';
  end if;
  if not found then perform core.fn_raise('E_INVALID_ACTION', 'assignment is not in a state for ' || p_action); end if;
end $$;

-- Ends the person's live sessions in my company (they must sign in / select a position again).
create function api.v1_iam_revoke_sessions(p_person_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.session.revoke', iam.fn_my_company_resource(), true);
  if not exists (select 1 from iam.company_membership where person_id = p_person_id and company_id = me.company_id) then
    perform core.fn_raise('E_NOT_FOUND', 'person');
  end if;
  if not me.is_supreme and exists (select 1 from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                                    where m.person_id = p_person_id and a.company_id = me.company_id and a.status = 'active'
                                      and iam.fn_rank_of(me.company_id, a.position_code) >= iam.fn_rank_of(me.company_id, me.position_code)) then
    perform core.fn_raise('E_RANK_TOO_HIGH');
  end if;
  insert into iam.session_revocation (company_id, person_id, reason, created_by) values (me.company_id, p_person_id, p_reason, me.person_id);
  update core.person set authz_epoch = authz_epoch + 1 where id = p_person_id;
end $$;

-- ---------------------------------------------------------------- app API: delegation
create function api.v1_iam_delegate(p_delegate_assignment uuid, p_permissions text[], p_scope_kind text, p_scope_id uuid,
                                    p_valid_from timestamptz, p_valid_until timestamptz, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare me record; v_from timestamptz := coalesce(p_valid_from, clock_timestamp()); v_id uuid; v_perm text; v_res iam.resource;
        v_pc iam.permission_catalog%rowtype; v_max_days integer; v_target uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_scope_kind not in ('COMPANY','WING','DEPARTMENT','LOCATION') or ((p_scope_kind = 'COMPANY') <> (p_scope_id is null)) then
    perform core.fn_raise('E_DELEGATION_INVALID', 'explicit scope required');
  end if;
  select * into me from iam.fn_context(true);
  v_max_days := config.fn_get_int(me.company_id, 'iam.delegation.max_days');          -- ADR-05 default 30, Chairman-configurable
  if p_valid_until is null or p_valid_until <= v_from then perform core.fn_raise('E_DELEGATION_INVALID', 'end time required'); end if;
  if p_valid_until > v_from + make_interval(days => v_max_days) then perform core.fn_raise('E_DELEGATION_TOO_LONG', v_max_days || ' days'); end if;
  select m.person_id into v_target from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
   where a.id = p_delegate_assignment and a.company_id = me.company_id and a.status = 'active';
  if v_target is null then perform core.fn_raise('E_NOT_FOUND', 'delegate assignment'); end if;
  if p_delegate_assignment = me.assignment_id then perform core.fn_raise('E_SELF_ACTION'); end if;
  v_res := iam.fn_resource(me.company_id,
                           case when p_scope_kind = 'WING' then p_scope_id end,
                           case when p_scope_kind = 'DEPARTMENT' then p_scope_id end,
                           case when p_scope_kind = 'LOCATION' then p_scope_id end);
  foreach v_perm in array p_permissions loop
    select * into v_pc from iam.permission_catalog where code = v_perm;
    if not found or v_pc.status <> 'active' then perform core.fn_raise('E_NOT_FOUND', v_perm); end if;
    if not v_pc.is_delegable then perform core.fn_raise('E_NOT_DELEGABLE', v_perm); end if;
    if not (p_scope_kind = any (v_pc.allowed_scopes)) then perform core.fn_raise('E_SCOPE_NOT_ALLOWED', v_perm); end if;
    perform iam.fn_require(v_perm, v_res, false);               -- I must hold it for exactly that scope myself
  end loop;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.delegation (company_id, delegator_assignment, delegate_assignment, permission_codes, scope_kind, scope_id,
                              valid_from, valid_until, reason, created_by)
  values (me.company_id, me.assignment_id, p_delegate_assignment, p_permissions, p_scope_kind, p_scope_id, v_from, p_valid_until, p_reason, me.person_id)
  returning id into v_id;
  insert into iam.assignment_permission_rule (company_id, assignment_id, permission_code, effect, scope_kind, scope_id, valid_until,
                                              origin, created_by, reason, delegation_id)
  select me.company_id, p_delegate_assignment, x, 'allow', p_scope_kind, p_scope_id, p_valid_until, 'delegation', me.person_id, p_reason, v_id
    from unnest(p_permissions) as x;
  return v_id;
end $$;

-- Revocable by the delegator, the delegate, or the Chairman.
create function api.v1_iam_revoke_delegation(p_delegation_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record; d iam.delegation%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_context(true);
  select * into d from iam.delegation where id = p_delegation_id and company_id = me.company_id and status = 'active' for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'delegation'); end if;
  if not (me.is_supreme or me.assignment_id in (d.delegator_assignment, d.delegate_assignment)) then
    perform core.fn_raise('E_FORBIDDEN', 'not your delegation');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.delegation set status = 'revoked', revoked_at = clock_timestamp(), revoked_by = me.person_id, revoke_reason = p_reason where id = d.id;
end $$;

create function api.v1_iam_my_delegations() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'direction', case when d.delegator_assignment = me.assignment_id then 'given' else 'received' end,
                         'permission_codes', to_jsonb(d.permission_codes), 'scope_kind', d.scope_kind, 'scope_id', d.scope_id,
                         'valid_from', d.valid_from, 'valid_until', d.valid_until, 'reason', d.reason,
                         'live', d.valid_from <= clock_timestamp() and d.valid_until > clock_timestamp()) order by d.valid_until)
                     from iam.delegation d
                    where d.company_id = me.company_id and d.status = 'active' and d.valid_until > clock_timestamp()
                      and me.assignment_id in (d.delegator_assignment, d.delegate_assignment)), '[]'::jsonb);
end $$;

-- ---------------------------------------------------------------- Chairman succession
create function iam.fn_install_chairman(p_company uuid, p_membership uuid, p_reason text) returns uuid
language plpgsql security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  perform 1 from core.company where id = p_company for no key update;          -- serialise chairman changes per company
  update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = 'chairman succession: ' || p_reason
   where company_id = p_company and position_code = 'CHAIRMAN' and status <> 'ended';
  insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind)
  values (p_company, p_membership, 'CHAIRMAN', 'regular') returning id into v;
  update iam.chairman_transfer set status = 'cancelled', decided_at = clock_timestamp() where company_id = p_company and status = 'pending';
  return v;
end $$;

create function api.v1_gov_propose_chairman_transfer(p_to_membership uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare me record; v uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_context(true);
  if not me.is_supreme then perform core.fn_raise('E_FORBIDDEN', 'only the Chairman can hand over the chair'); end if;
  if not exists (select 1 from iam.company_membership where id = p_to_membership and company_id = me.company_id and status = 'active' and person_id <> me.person_id) then
    perform core.fn_raise('E_TRANSFER_INVALID', 'successor must be another active member');
  end if;
  update iam.chairman_transfer set status = 'cancelled', decided_at = clock_timestamp()
   where company_id = me.company_id and status = 'pending' and expires_at <= clock_timestamp();
  if exists (select 1 from iam.chairman_transfer where company_id = me.company_id and status = 'pending') then
    perform core.fn_raise('E_TRANSFER_PENDING');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.chairman_transfer (company_id, from_assignment, to_membership, reason) values (me.company_id, me.assignment_id, p_to_membership, p_reason)
  returning id into v;
  return v;
end $$;

-- Accepted by the successor personally (needs only their login + membership, not a position).
create function api.v1_gov_accept_chairman_transfer(p_transfer_id uuid)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); t iam.chairman_transfer%rowtype; v uuid;
begin
  select * into t from iam.chairman_transfer where id = p_transfer_id for update;
  if not found or t.status <> 'pending' or t.expires_at <= clock_timestamp() then perform core.fn_raise('E_TRANSFER_INVALID'); end if;
  if not exists (select 1 from iam.company_membership m join core.company c on c.id = m.company_id
                  where m.id = t.to_membership and m.person_id = v_person and m.status = 'active' and c.status = 'active') then
    perform core.fn_raise('E_FORBIDDEN', 'not the named successor');
  end if;
  if not exists (select 1 from iam.position_assignment where id = t.from_assignment and status = 'active') then
    perform core.fn_raise('E_TRANSFER_INVALID', 'the proposing Chairman is no longer in office');
  end if;
  perform set_config('mohona.change_reason', 'chairman transfer accepted: ' || t.reason, true);
  update iam.chairman_transfer set status = 'accepted', decided_at = clock_timestamp() where id = t.id;
  v := iam.fn_install_chairman(t.company_id, t.to_membership, t.reason);
  update iam.chairman_transfer set new_assignment = v where id = t.id;
  return v;
end $$;

create function api.v1_gov_cancel_chairman_transfer(p_transfer_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); t iam.chairman_transfer%rowtype;
begin
  select * into t from iam.chairman_transfer where id = p_transfer_id and status = 'pending' for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'transfer'); end if;
  if not exists (select 1 from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                  where a.id = t.from_assignment and m.person_id = v_person)
     and not exists (select 1 from iam.company_membership m where m.id = t.to_membership and m.person_id = v_person) then
    perform core.fn_raise('E_FORBIDDEN');
  end if;
  update iam.chairman_transfer set status = 'cancelled', decided_at = clock_timestamp() where id = t.id;
end $$;

create function api.v1_gov_my_pending_transfers() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person();
begin
  return coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'company_id', t.company_id, 'company_name_bn', c.name_bn,
                         'reason', t.reason, 'expires_at', t.expires_at))
                     from iam.chairman_transfer t join iam.company_membership m on m.id = t.to_membership join core.company c on c.id = t.company_id
                    where m.person_id = v_person and t.status = 'pending' and t.expires_at > clock_timestamp()), '[]'::jsonb);
end $$;

-- ---------------------------------------------------------------- platform (service_role): bootstrap and forced appointment
create function svc.v1_gov_bootstrap_company(p_code text, p_name_bn text, p_chairman_person uuid, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_company uuid; v_m uuid; v_a uuid; v_pin text := current_setting('mohona.company_scope', true);
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  -- platform action: never runs inside another company's pinned scope (restored afterwards)
  perform set_config('mohona.company_scope', '', true);
  insert into core.company (code, name_bn, status) values (p_code, p_name_bn, 'active') returning id into v_company;
  insert into iam.company_membership (person_id, company_id, status) values (p_chairman_person, v_company, 'active') returning id into v_m;
  v_a := iam.fn_install_chairman(v_company, v_m, p_reason);
  perform set_config('mohona.company_scope', coalesce(v_pin, ''), true);
  return jsonb_build_object('company_id', v_company, 'membership_id', v_m, 'chairman_assignment_id', v_a);
end $$;

-- Emergency / vacancy: the platform owner installs a Chairman (ends any current one). Fully audited.
create function svc.v1_gov_appoint_chairman(p_membership uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare m iam.company_membership%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into m from iam.company_membership where id = p_membership and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'active membership'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  return iam.fn_install_chairman(m.company_id, m.id, p_reason);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array[
      'api.v1_iam_company_people()', 'api.v1_iam_add_member(text, text, text, text, text)', 'api.v1_iam_end_member(uuid, text)',
      'api.v1_iam_assign_position(uuid, text, timestamptz, timestamptz, text, uuid, uuid, uuid, text)', 'api.v1_iam_change_assignment(uuid, text, text)',
      'api.v1_iam_revoke_sessions(uuid, text)', 'api.v1_iam_delegate(uuid, text[], text, uuid, timestamptz, timestamptz, text)',
      'api.v1_iam_revoke_delegation(uuid, text)', 'api.v1_iam_my_delegations()', 'api.v1_gov_propose_chairman_transfer(uuid, text)',
      'api.v1_gov_accept_chairman_transfer(uuid)', 'api.v1_gov_cancel_chairman_transfer(uuid)', 'api.v1_gov_my_pending_transfers()']
    loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_gov_bootstrap_company(text, text, uuid, text) to service_role';
    execute 'grant execute on function svc.v1_gov_appoint_chairman(uuid, text) to service_role';
  end if;
end $$;

-- 20261108002000_recycle_bin.sql  (S21)
-- Recycle bin (blueprint RECYCLE_BIN MOS-F153-191..200). A generic engine over registered RECORD CLASSES; each class
-- adapter decides eligibility (drafts only — posted records are never soft-deleted), how a record leaves and returns,
-- and what a purge erases. Later modules register their own classes (contract in docs/RECYCLE_BIN_BN.md).
--   191 soft delete of eligible unposted records · 192 company-scoped bin; records the caller may not read are masked
--   193 restore re-checks TODAY's permissions · 194 retention per class (setting fallback) · 195 legal hold freezes
--   delete/restore/purge; released only by a different authorised person · 196 purge = request + two independent
--   approvals + delay; audit and history are never purged · 197 bulk restore all-or-nothing with every denial reported
--   198 attachment restore verifies the storage object (missing blob = refused, never silent) · 199 conflicts (parent
--   archived, duplicates) stay in the bin for manual resolution · 200 every step is an immutable recycle event
-- Classes in this step: forms.draft (draft form submissions), forms.attachment (unlinked uploads).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table core.recycle_class (
  code             text primary key check (code ~ '^[a-z]+\.[a-z_]{2,30}$'),
  name_bn          text not null,
  read_permission  text not null references iam.permission_catalog(code),
  write_permission text not null references iam.permission_catalog(code),
  sort_order       integer not null default 0
);
create trigger trg_recycle_class_nodel before delete on core.recycle_class for each row execute function core.fn_deny_delete();

create table core.recycle_item (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references core.company(id),
  class_code       text not null references core.recycle_class(code),
  record_id        uuid not null,
  label_bn         text not null,
  snapshot         jsonb not null default '{}'::jsonb,
  owner_person_id  uuid,
  wing_id          uuid,
  status           text not null default 'in_bin' check (status in ('in_bin','restored','purged')),
  deleted_by       uuid not null references core.person(id),
  deleted_at       timestamptz not null default clock_timestamp(),
  delete_reason    text not null check (length(btrim(delete_reason)) > 0),
  purge_after      timestamptz not null,
  conflict         text,
  closed_by        uuid,
  closed_at        timestamptz,
  updated_at       timestamptz not null default clock_timestamp(),
  row_version      integer not null default 1,
  unique (id, company_id),
  check ((status = 'in_bin') = (closed_at is null))
);
create unique index recycle_item_one_open on core.recycle_item (class_code, record_id) where status = 'in_bin';
create index recycle_item_company on core.recycle_item (company_id, status, deleted_at desc);
create function core.fn_recycle_item_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','conflict','closed_by','closed_at','snapshot','updated_at','row_version'])
     <> (to_jsonb(new) - array['status','conflict','closed_by','closed_at','snapshot','updated_at','row_version'])
     or (old.status <> 'in_bin' and new.status <> old.status)
     or (new.snapshot is distinct from old.snapshot and new.status <> 'purged') then
    raise exception 'E_IMMUTABLE: a bin entry only changes by restore or purge' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_recycle_item_guard before update on core.recycle_item for each row execute function core.fn_recycle_item_guard();
create trigger trg_recycle_item_touch before update on core.recycle_item for each row execute function core.fn_touch_row();
create trigger trg_recycle_item_nodel before delete on core.recycle_item for each row execute function core.fn_deny_delete();
create trigger trg_recycle_item_audit after insert or update on core.recycle_item for each row execute function audit.fn_row_change();

create table core.recycle_retention (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  class_code  text not null references core.recycle_class(code),
  days        integer not null check (days between 1 and 3650),
  version     integer not null check (version >= 1),
  status      text not null default 'active' check (status in ('active','superseded')),
  set_by      uuid, set_at timestamptz not null default clock_timestamp(),
  reason      text not null check (length(btrim(reason)) > 0)
);
create unique index recycle_retention_one_active on core.recycle_retention (company_id, class_code) where status = 'active';
create trigger trg_recycle_retention_guard before update on core.recycle_retention for each row execute function config.fn_history_only_supersede();
create trigger trg_recycle_retention_nodel before delete on core.recycle_retention for each row execute function core.fn_deny_delete();
create trigger trg_recycle_retention_audit after insert or update on core.recycle_retention for each row execute function audit.fn_row_change();

-- Legal hold: class and/or record (both null = everything of the company).
create table core.legal_hold (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  class_code      text references core.recycle_class(code),
  record_id       uuid,
  reason          text not null check (length(btrim(reason)) > 0),
  status          text not null default 'active' check (status in ('active','released')),
  placed_by       uuid not null references core.person(id),
  placed_at       timestamptz not null default clock_timestamp(),
  released_by     uuid references core.person(id),
  released_at     timestamptz,
  release_reason  text,
  check ((status = 'released') = (released_at is not null)),
  check (released_by is null or released_by <> placed_by)
);
create function core.fn_legal_hold_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','released_by','released_at','release_reason']) <> (to_jsonb(new) - array['status','released_by','released_at','release_reason'])
     or old.status <> 'active' then
    raise exception 'E_IMMUTABLE: a legal hold is only released, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_legal_hold_guard before update on core.legal_hold for each row execute function core.fn_legal_hold_guard();
create trigger trg_legal_hold_nodel before delete on core.legal_hold for each row execute function core.fn_deny_delete();
create trigger trg_legal_hold_audit after insert or update on core.legal_hold for each row execute function audit.fn_row_change();

create table core.purge_request (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  item_id       uuid not null,
  status        text not null default 'pending' check (status in ('pending','approved','executed','cancelled')),
  requested_by  uuid not null references core.person(id),
  requested_at  timestamptz not null default clock_timestamp(),
  reason        text not null check (length(btrim(reason)) > 0),
  approver1     uuid references core.person(id),
  approver2     uuid references core.person(id),
  approved_at   timestamptz,
  not_before    timestamptz not null,
  executed_at   timestamptz,
  foreign key (item_id, company_id) references core.recycle_item (id, company_id),
  check (approver1 is null or approver1 <> requested_by),
  check (approver2 is null or (approver2 <> requested_by and approver2 <> approver1))
);
create unique index purge_request_one_open on core.purge_request (item_id) where status in ('pending','approved');
create trigger trg_purge_request_nodel before delete on core.purge_request for each row execute function core.fn_deny_delete();
create trigger trg_purge_request_audit after insert or update on core.purge_request for each row execute function audit.fn_row_change();

-- Trash audit (F200): immutable evidence of every bin step.
create table core.recycle_event (
  id          bigint generated always as identity primary key,
  company_id  uuid not null references core.company(id),
  item_id     uuid,
  class_code  text,
  record_id   uuid,
  action      text not null check (action in ('deleted','restored','restore_denied','restore_conflict','purge_requested','purge_approved',
                                               'purged','hold_placed','hold_released','retention_set')),
  person_id   uuid,
  reason      text,
  detail      jsonb not null default '{}'::jsonb,
  at          timestamptz not null default clock_timestamp()
);
create trigger trg_recycle_event_no_mutation before update or delete on core.recycle_event for each row execute function core.fn_deny_mutation();

select core.fn_apply_rls('core', 'recycle_class');
select core.fn_apply_rls('core', 'recycle_item');
select core.fn_apply_rls('core', 'recycle_retention');
select core.fn_apply_rls('core', 'legal_hold');
select core.fn_apply_rls('core', 'purge_request');
select core.fn_apply_rls('core', 'recycle_event');

-- ================================================================ permissions, module, settings, classes
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('recycle.bin.read',          'recycle', 'রিসাইকেল-বিন দেখা', 'read', false, true, array['COMPANY','WING','SELF'], 'active', 1400),
  ('recycle.purge.request',     'recycle', 'স্থায়ী মুছে ফেলার অনুরোধ', 'admin', true, false, array['COMPANY'], 'active', 1401),
  ('recycle.purge.approve',     'recycle', 'স্থায়ী মুছে ফেলা অনুমোদন', 'approve', true, false, array['COMPANY'], 'active', 1402),
  ('recycle.hold.manage',       'recycle', 'আইনি স্থগিতাদেশ (legal hold)', 'admin', true, false, array['COMPANY'], 'active', 1403),
  ('recycle.retention.manage',  'recycle', 'বিনে রাখার মেয়াদ', 'admin', true, false, array['COMPANY'], 'active', 1404);
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'recycle.bin.read', 'allow', 'SELF' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN');
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('MD', 'recycle.bin.read', 'allow', 'COMPANY'), ('MD', 'recycle.purge.approve', 'allow', 'COMPANY'), ('AUDITOR', 'recycle.bin.read', 'allow', 'COMPANY'),
  ('AUDITOR', 'recycle.hold.manage', 'allow', 'COMPANY');
select iam.fn_backfill_template_rules(null);
update config.module_catalog set permission_modules = array['recycle'] where code = 'recycle';
select config.fn_make_module_available('recycle');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('recycle.purge.delay_hours', 'recycle', 'int', '72', 1, 720, null, 'স্থায়ী মুছে ফেলার আগে অপেক্ষা (ঘণ্টা)', 'MOS-F153-196', true, 1000),
  ('recycle.bulk.max_items',    'recycle', 'int', '100', 1, 500, null, 'একসাথে পুনরুদ্ধারের সর্বোচ্চ সংখ্যা', 'MOS-F153-197', false, 1010);

insert into core.recycle_class (code, name_bn, read_permission, write_permission, sort_order) values
  ('forms.draft', 'ফর্মের খসড়া', 'forms.submission.read', 'forms.submission.write', 10),
  ('forms.attachment', 'ফর্মের সংযুক্তি (জমা হয়নি)', 'forms.submission.read', 'forms.submission.write', 20);

-- Submission guard (S14) + recycle transitions: a binned draft (cancelled) may return to draft on RESTORE, and its
-- values may be cleared on PURGE — both only inside the recycle engine (mohona.recycle).
create or replace function config.fn_form_submission_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_recycle text := coalesce(current_setting('mohona.recycle', true), '');
begin
  if new.company_id <> old.company_id or new.form_id <> old.form_id or new.form_version <> old.form_version
     or new.created_by <> old.created_by or new.client_draft_id is distinct from old.client_draft_id
     or new.amends_id is distinct from old.amends_id or new.origin <> old.origin
     or (old.number is not null and new.number is distinct from old.number) then
    raise exception 'E_IMMUTABLE: submission identity and pinned form version never change' using errcode = 'P0001';
  end if;
  if v_recycle = 'purge' and old.status = 'cancelled' and new.status = 'cancelled' and new.field_values = '{}'::jsonb then
    return new;
  end if;
  if new.field_values is distinct from old.field_values and old.status not in ('draft','returned','rejected','pending_approval') then
    raise exception 'E_FORM_LOCKED: a % submission is never edited; amend or void it', old.status using errcode = 'P0001';
  end if;
  if new.field_values is distinct from old.field_values and old.status = 'pending_approval' and new.status <> 'draft' then
    raise exception 'E_FORM_LOCKED: submission is waiting for approval' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not (
       (old.status = 'draft'            and new.status in ('submitted','pending_approval','approved','cancelled'))
    or (old.status = 'pending_approval' and new.status in ('approved','rejected','cancelled','draft'))
    or (old.status in ('rejected','returned') and new.status in ('draft','cancelled'))
    or (old.status in ('submitted','approved') and new.status in ('void','superseded'))
    or (old.status = 'cancelled' and new.status = 'draft' and v_recycle = 'restore')) then
    raise exception 'E_INVALID_ACTION: submission % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;

-- ================================================================ engine
create function core.fn_recycle_log(p_company uuid, p_item uuid, p_class text, p_record uuid, p_action text, p_person uuid, p_reason text, p_detail jsonb default '{}')
returns void language sql security definer set search_path = pg_catalog as $$
  insert into core.recycle_event (company_id, item_id, class_code, record_id, action, person_id, reason, detail)
  values (p_company, p_item, p_class, p_record, p_action, p_person, left(p_reason, 500), coalesce(p_detail, '{}'::jsonb))
$$;

create function core.fn_on_hold(p_company uuid, p_class text, p_record uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from core.legal_hold h where h.company_id = p_company and h.status = 'active'
                   and (h.class_code is null or h.class_code = p_class) and (h.record_id is null or h.record_id = p_record))
$$;

create function core.fn_retention_days(p_company uuid, p_class text) returns integer
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((select r.days from core.recycle_retention r where r.company_id = p_company and r.class_code = p_class and r.status = 'active'),
                  config.fn_get_int(p_company, 'recycle.retention_days'))
$$;

-- Class adapter: what the record is (label, owner, wing, minimal snapshot without values) and whether it may enter the bin.
create function core.fn_recycle_describe(p_company uuid, p_class text, p_record uuid) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare s config.form_submission%rowtype; a config.form_attachment%rowtype; f config.form%rowtype;
begin
  if p_class = 'forms.draft' then
    select * into s from config.form_submission where id = p_record and company_id = p_company;
    if not found then return null; end if;
    select * into f from config.form where id = s.form_id;
    return jsonb_build_object('label_bn', f.name_bn || ' — খসড়া ' || to_char(s.created_at, 'YYYY-MM-DD'), 'owner', s.created_by, 'wing', s.wing_id,
             'eligible', case when s.status = 'draft' then null else 'only unposted drafts can be binned (status ' || s.status || ')' end,
             'snapshot', jsonb_build_object('form_code', f.code, 'form_version', s.form_version, 'field_count', (select count(*) from jsonb_object_keys(s.field_values))));
  elsif p_class = 'forms.attachment' then
    select * into a from config.form_attachment where id = p_record and company_id = p_company;
    if not found then return null; end if;
    select * into f from config.form where id = a.form_id;
    return jsonb_build_object('label_bn', f.name_bn || ' — সংযুক্তি (' || a.mime_type || ')', 'owner', a.created_by, 'wing', f.wing_id,
             'eligible', case when a.submission_id is null and a.status in ('pending','uploaded') then null else 'only unlinked uploads can be binned' end,
             'snapshot', jsonb_build_object('status', a.status, 'mime_type', a.mime_type, 'size_bytes', a.size_bytes, 'path', a.object_path, 'bucket', a.bucket));
  end if;
  return null;
end $$;

-- Class adapter: delete | restore | purge. Returns a conflict code (restore) or null.
create function core.fn_recycle_do(p_item core.recycle_item, p_op text) returns text
language plpgsql security definer set search_path = pg_catalog as $$
declare v_exists boolean := true; v_status text;
begin
  if p_item.class_code = 'forms.draft' then
    if p_op = 'delete' then
      perform set_config('mohona.form_action', 'recycle_delete', true);
      update config.form_submission set status = 'cancelled' where id = p_item.record_id and company_id = p_item.company_id and status = 'draft';
      if not found then return 'changed'; end if;
    elsif p_op = 'restore' then
      if exists (select 1 from config.form_submission s join config.form f on f.id = s.form_id where s.id = p_item.record_id and f.status = 'archived') then
        return 'parent_archived';
      end if;
      select s.status into v_status from config.form_submission s where s.id = p_item.record_id;
      if v_status is distinct from 'cancelled' then return 'changed'; end if;
      perform set_config('mohona.recycle', 'restore', true); perform set_config('mohona.form_action', 'recycle_restore', true);
      update config.form_submission set status = 'draft' where id = p_item.record_id and company_id = p_item.company_id;
      perform set_config('mohona.recycle', '', true);
    elsif p_op = 'purge' then
      perform set_config('mohona.recycle', 'purge', true); perform set_config('mohona.form_action', 'purge', true);
      update config.form_submission set field_values = '{}'::jsonb where id = p_item.record_id and company_id = p_item.company_id and status = 'cancelled';
      perform set_config('mohona.recycle', '', true);
    end if;
    perform set_config('mohona.form_action', '', true);
    return null;
  elsif p_item.class_code = 'forms.attachment' then
    if p_op = 'delete' then
      update config.form_attachment set status = 'rejected'
       where id = p_item.record_id and company_id = p_item.company_id and submission_id is null and status in ('pending','uploaded');
      if not found then return 'changed'; end if;
    elsif p_op = 'restore' then
      if (select a.status from config.form_attachment a where a.id = p_item.record_id) is distinct from 'rejected' then return 'changed'; end if;
      if p_item.snapshot ->> 'status' = 'uploaded' and to_regclass('storage.objects') is not null then
        execute 'select exists (select 1 from storage.objects o where o.bucket_id = $1 and o.name = $2)' into v_exists
          using p_item.snapshot ->> 'bucket', p_item.snapshot ->> 'path';
        if not v_exists then return 'blob_missing'; end if;               -- F198: never restored silently without its file
      end if;
      update config.form_attachment set status = coalesce(p_item.snapshot ->> 'status', 'uploaded') where id = p_item.record_id and company_id = p_item.company_id;
    end if;                                                                -- purge: the storage object is removed by the platform job (OI-34)
    return null;
  end if;
  raise exception 'E_NOT_FOUND: unknown record class %', p_item.class_code using errcode = 'P0001';
end $$;

create function core.fn_recycle_allowed(p_company uuid, p_class text, p_wing uuid, p_owner uuid, p_kind text) returns boolean
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare c core.recycle_class%rowtype; ok boolean;
begin
  select * into c from core.recycle_class where code = p_class;
  if not found then return false; end if;
  select d.allowed into ok from iam.fn_authorize(case when p_kind = 'read' then c.read_permission else c.write_permission end,
                                                 iam.fn_resource(p_company, p_wing, null, null, null, p_owner), false) d;
  return coalesce(ok, false);
end $$;

-- Restores one item (shared by single and bulk restore). Returns null when restored, else the reason it was not.
create function core.fn_recycle_restore_one(p_item_id uuid, p_company uuid, p_person uuid, p_reason text, p_check_only boolean) returns text
language plpgsql security definer set search_path = pg_catalog as $$
declare it core.recycle_item%rowtype; v_conflict text;
begin
  select * into it from core.recycle_item where id = p_item_id and company_id = p_company for update;
  if not found then return 'not_found'; end if;
  if it.status <> 'in_bin' then return 'not_in_bin'; end if;
  if core.fn_on_hold(p_company, it.class_code, it.record_id) then return 'legal_hold'; end if;
  if not core.fn_recycle_allowed(p_company, it.class_code, it.wing_id, it.owner_person_id, 'write') then return 'forbidden'; end if;   -- today's rights
  if exists (select 1 from core.purge_request r where r.item_id = it.id and r.status in ('pending','approved')) then return 'purge_pending'; end if;
  if p_check_only then return null; end if;
  v_conflict := core.fn_recycle_do(it, 'restore');
  if v_conflict is not null then
    update core.recycle_item set conflict = v_conflict where id = it.id;
    perform core.fn_recycle_log(p_company, it.id, it.class_code, it.record_id, 'restore_conflict', p_person, p_reason, jsonb_build_object('conflict', v_conflict));
    return 'conflict:' || v_conflict;
  end if;
  update core.recycle_item set status = 'restored', conflict = null, closed_by = p_person, closed_at = clock_timestamp() where id = it.id;
  perform core.fn_recycle_log(p_company, it.id, it.class_code, it.record_id, 'restored', p_person, p_reason);
  return null;
end $$;

-- Purges one item: the class adapter erases what it may; history and audit are never touched.
create function core.fn_recycle_purge_one(p_item core.recycle_item, p_person uuid, p_reason text) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform core.fn_recycle_do(p_item, 'purge');
  update core.recycle_item set status = 'purged', snapshot = '{}'::jsonb, closed_by = p_person, closed_at = clock_timestamp() where id = p_item.id;
  perform core.fn_recycle_log(p_item.company_id, p_item.id, p_item.class_code, p_item.record_id, 'purged', p_person, p_reason);
end $$;

-- ================================================================ API
create function api.v1_recycle_delete(p_class text, p_record_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid := iam.fn_context_company(); d jsonb; it core.recycle_item%rowtype; v_conflict text;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  d := core.fn_recycle_describe(v_company, p_class, p_record_id);
  if d is null then perform core.fn_raise('E_NOT_FOUND', 'record'); end if;
  select * into me from iam.fn_require((select c.write_permission from core.recycle_class c where c.code = p_class),
                                       iam.fn_resource(v_company, (d ->> 'wing')::uuid, null, null, null, (d ->> 'owner')::uuid), true);
  if d ->> 'eligible' is not null then perform core.fn_raise('E_RECYCLE_NOT_ELIGIBLE', d ->> 'eligible'); end if;
  if core.fn_on_hold(me.company_id, p_class, p_record_id) then perform core.fn_raise('E_LEGAL_HOLD'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into core.recycle_item (company_id, class_code, record_id, label_bn, snapshot, owner_person_id, wing_id, deleted_by, delete_reason, purge_after)
  values (me.company_id, p_class, p_record_id, d ->> 'label_bn', d -> 'snapshot', (d ->> 'owner')::uuid, (d ->> 'wing')::uuid, me.person_id, p_reason,
          clock_timestamp() + make_interval(days => core.fn_retention_days(me.company_id, p_class)))
  returning * into it;
  v_conflict := core.fn_recycle_do(it, 'delete');
  if v_conflict is not null then perform core.fn_raise('E_STALE_VERSION', 'record changed meanwhile'); end if;
  perform core.fn_recycle_log(me.company_id, it.id, p_class, p_record_id, 'deleted', me.person_id, p_reason);
  return jsonb_build_object('item_id', it.id, 'purge_after', it.purge_after);
end $$;

-- Company-scoped bin (F192): entries whose record the caller may not read are listed masked.
create function api.v1_recycle_list(p_class text default null, p_status text default 'in_bin', p_limit integer default 100) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; it record; out jsonb := '[]'::jsonb; v_read boolean; v_bin boolean; n integer := greatest(1, least(coalesce(p_limit, 100), 500));
begin
  select * into me from iam.fn_context(false);
  for it in select * from core.recycle_item x where x.company_id = me.company_id and (p_class is null or x.class_code = p_class)
              and (p_status is null or x.status = p_status) order by x.deleted_at desc loop
    select d.allowed into v_bin from iam.fn_authorize('recycle.bin.read', iam.fn_resource(me.company_id, it.wing_id, null, null, null, it.owner_person_id), false) d;
    continue when not coalesce(v_bin, false) and it.deleted_by <> me.person_id;
    v_read := core.fn_recycle_allowed(me.company_id, it.class_code, it.wing_id, it.owner_person_id, 'read');
    out := out || jsonb_build_array(jsonb_build_object('id', it.id, 'class_code', it.class_code, 'status', it.status, 'deleted_at', it.deleted_at,
             'purge_after', it.purge_after, 'conflict', it.conflict, 'row_version', it.row_version,
             'on_hold', core.fn_on_hold(me.company_id, it.class_code, it.record_id),
             'label_bn', case when v_read then it.label_bn else '[গোপন]' end,
             'snapshot', case when v_read then it.snapshot else '{}'::jsonb end,
             'record_id', case when v_read then it.record_id end, 'masked', not v_read));
    exit when jsonb_array_length(out) >= n;
  end loop;
  return out;
end $$;

create function api.v1_recycle_restore(p_item_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v text;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_context(true);
  perform set_config('mohona.change_reason', p_reason, true);
  v := core.fn_recycle_restore_one(p_item_id, me.company_id, me.person_id, p_reason, false);
  if v is null then return jsonb_build_object('item_id', p_item_id, 'status', 'restored'); end if;
  if v like 'conflict:%' then return jsonb_build_object('item_id', p_item_id, 'status', 'conflict', 'conflict', substr(v, 10)); end if;
  if v = 'not_found' then perform core.fn_raise('E_NOT_FOUND', 'bin entry'); end if;
  -- refusals are returned (not raised) so the evidence row survives
  perform core.fn_recycle_log(me.company_id, p_item_id, null, null, 'restore_denied', me.person_id, p_reason, jsonb_build_object('why', v));
  return jsonb_build_object('item_id', p_item_id, 'status', 'denied', 'reason', v);
end $$;

-- Bulk restore (F197): all-or-nothing; when anything is refused, nothing is restored and every refusal is reported.
create function api.v1_recycle_restore_bulk(p_item_ids uuid[], p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; i uuid; v text; denied jsonb := '[]'::jsonb; done jsonb := '[]'::jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_context(true);
  if not config.fn_flag(me.company_id, 'recycle.bulk_restore', me.home_wing_id) then perform core.fn_raise('E_FEATURE_DISABLED', 'bulk restore'); end if;
  if coalesce(cardinality(p_item_ids), 0) not between 1 and config.fn_get_int(me.company_id, 'recycle.bulk.max_items') then
    perform core.fn_raise('E_INVALID_ACTION', 'item count');
  end if;
  foreach i in array p_item_ids loop
    v := core.fn_recycle_restore_one(i, me.company_id, me.person_id, p_reason, true);
    if v is not null then denied := denied || jsonb_build_array(jsonb_build_object('item_id', i, 'reason', v)); end if;
  end loop;
  if jsonb_array_length(denied) > 0 then
    return jsonb_build_object('restored', '[]'::jsonb, 'denied', denied, 'status', 'nothing_restored');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  foreach i in array p_item_ids loop
    v := core.fn_recycle_restore_one(i, me.company_id, me.person_id, p_reason, false);
    if v is not null then raise exception 'E_RECYCLE_CONFLICT: % (%) — nothing was restored', v, i using errcode = 'P0001'; end if;   -- rolls back all
    done := done || to_jsonb(i);
  end loop;
  return jsonb_build_object('restored', done, 'denied', '[]'::jsonb, 'status', 'all_restored');
end $$;

-- Purge request (F196): early permanent removal; two independent approvals + delay; refused under legal hold.
create function api.v1_recycle_request_purge(p_item_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; it core.recycle_item%rowtype; v_id uuid; v_nb timestamptz;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('recycle.purge.request', iam.fn_my_company_resource(), true);
  select * into it from core.recycle_item where id = p_item_id and company_id = me.company_id for update;
  if not found or it.status <> 'in_bin' then perform core.fn_raise('E_NOT_FOUND', 'bin entry'); end if;
  if core.fn_on_hold(me.company_id, it.class_code, it.record_id) then perform core.fn_raise('E_LEGAL_HOLD'); end if;
  v_nb := clock_timestamp() + make_interval(hours => config.fn_get_int(me.company_id, 'recycle.purge.delay_hours'));
  perform set_config('mohona.change_reason', p_reason, true);
  insert into core.purge_request (company_id, item_id, requested_by, reason, not_before) values (me.company_id, it.id, me.person_id, p_reason, v_nb) returning id into v_id;
  perform core.fn_recycle_log(me.company_id, it.id, it.class_code, it.record_id, 'purge_requested', me.person_id, p_reason, jsonb_build_object('not_before', v_nb));
  return jsonb_build_object('request_id', v_id, 'not_before', v_nb);
end $$;

create function api.v1_recycle_approve_purge(p_request_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r core.purge_request%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('recycle.purge.approve', iam.fn_my_company_resource(), true);
  select * into r from core.purge_request where id = p_request_id and company_id = me.company_id for update;
  if not found or r.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'purge request'); end if;
  if me.person_id = r.requested_by or me.person_id = r.approver1 then perform core.fn_raise('E_SELF_APPROVAL', 'two independent approvers'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if r.approver1 is null then
    update core.purge_request set approver1 = me.person_id where id = r.id;
  else
    update core.purge_request set approver2 = me.person_id, status = 'approved', approved_at = clock_timestamp() where id = r.id;
  end if;
  perform core.fn_recycle_log(me.company_id, r.item_id, null, null, 'purge_approved', me.person_id, p_reason);
  return jsonb_build_object('request_id', r.id, 'status', (select x.status from core.purge_request x where x.id = r.id));
end $$;

-- Legal hold (F195): placed by recycle.hold.manage; released only by ANOTHER authorised person.
create function api.v1_recycle_hold(p_class text, p_record_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('recycle.hold.manage', iam.fn_my_company_resource(), true);
  if p_class is not null and not exists (select 1 from core.recycle_class c where c.code = p_class) then perform core.fn_raise('E_NOT_FOUND', 'class'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into core.legal_hold (company_id, class_code, record_id, reason, placed_by) values (me.company_id, p_class, p_record_id, p_reason, me.person_id) returning id into v_id;
  perform core.fn_recycle_log(me.company_id, null, p_class, p_record_id, 'hold_placed', me.person_id, p_reason);
  return jsonb_build_object('hold_id', v_id);
end $$;

create function api.v1_recycle_release_hold(p_hold_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; h core.legal_hold%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('recycle.hold.manage', iam.fn_my_company_resource(), true);
  select * into h from core.legal_hold where id = p_hold_id and company_id = me.company_id and status = 'active' for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'hold'); end if;
  if h.placed_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'a hold is released by another person'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update core.legal_hold set status = 'released', released_by = me.person_id, released_at = clock_timestamp(), release_reason = p_reason where id = h.id;
  perform core.fn_recycle_log(me.company_id, null, h.class_code, h.record_id, 'hold_released', me.person_id, p_reason);
  return jsonb_build_object('hold_id', h.id, 'status', 'released');
end $$;

create function api.v1_recycle_set_retention(p_class text, p_days integer, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('recycle.retention.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from core.recycle_class c where c.code = p_class) or coalesce(p_days, 0) not between 1 and 3650 then
    perform core.fn_raise('E_INVALID_ACTION', 'class / days 1..3650');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update core.recycle_retention set status = 'superseded' where company_id = me.company_id and class_code = p_class and status = 'active';
  v_next := coalesce((select max(r.version) from core.recycle_retention r where r.company_id = me.company_id and r.class_code = p_class), 0) + 1;
  insert into core.recycle_retention (company_id, class_code, days, version, set_by, reason) values (me.company_id, p_class, p_days, v_next, me.person_id, p_reason);
  perform core.fn_recycle_log(me.company_id, null, p_class, null, 'retention_set', me.person_id, p_reason, jsonb_build_object('days', p_days));
  return v_next;     -- applies to items binned from now on; existing entries keep their purge date (a hold always wins)
end $$;

create function api.v1_recycle_events(p_item_id uuid default null, p_limit integer default 200) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('recycle.bin.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(x order by (x ->> 'id')::bigint desc) from (
    select jsonb_build_object('id', e.id, 'item_id', e.item_id, 'class_code', e.class_code, 'action', e.action, 'person_id', e.person_id,
                              'reason', e.reason, 'detail', e.detail, 'at', e.at) x
      from core.recycle_event e where e.company_id = me.company_id and (p_item_id is null or e.item_id = p_item_id)
     order by e.id desc limit greatest(1, least(coalesce(p_limit, 200), 2000))) q), '[]'::jsonb);
end $$;

-- Scheduler (platform cron): executes approved purges whose delay passed, and retention purges; holds always win.
create function svc.v1_recycle_run() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare r record; it core.recycle_item%rowtype; n_req integer := 0; n_ret integer := 0;
begin
  perform set_config('mohona.company_scope', '', true);
  for r in select * from core.purge_request x where x.status = 'approved' and x.not_before <= clock_timestamp() loop
    select * into it from core.recycle_item where id = r.item_id for update;
    continue when it.status <> 'in_bin' or core.fn_on_hold(it.company_id, it.class_code, it.record_id);
    perform set_config('mohona.change_reason', 'approved purge', true);
    perform core.fn_recycle_purge_one(it, r.requested_by, 'approved purge');
    update core.purge_request set status = 'executed', executed_at = clock_timestamp() where id = r.id;
    n_req := n_req + 1;
  end loop;
  for it in select * from core.recycle_item x where x.status = 'in_bin' and x.purge_after <= clock_timestamp()
              and not exists (select 1 from core.purge_request p where p.item_id = x.id and p.status in ('pending','approved')) for update loop
    continue when core.fn_on_hold(it.company_id, it.class_code, it.record_id);
    perform set_config('mohona.change_reason', 'retention elapsed', true);
    perform core.fn_recycle_purge_one(it, null, 'retention elapsed');
    n_ret := n_ret + 1;
  end loop;
  return jsonb_build_object('purged_by_request', n_req, 'purged_by_retention', n_ret);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_recycle_delete(text, uuid, text)', 'api.v1_recycle_list(text, text, integer)', 'api.v1_recycle_restore(uuid, text)',
      'api.v1_recycle_restore_bulk(uuid[], text)', 'api.v1_recycle_request_purge(uuid, text)', 'api.v1_recycle_approve_purge(uuid, text)',
      'api.v1_recycle_hold(text, uuid, text)', 'api.v1_recycle_release_hold(uuid, text)', 'api.v1_recycle_set_retention(text, integer, text)',
      'api.v1_recycle_events(uuid, integer)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_recycle_run() to service_role';
  end if;
end $$;

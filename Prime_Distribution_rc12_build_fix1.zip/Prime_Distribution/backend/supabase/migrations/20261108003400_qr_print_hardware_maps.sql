-- 20261108003400_qr_print_hardware_maps.sql  (S49–S51, final phase)
-- Universal QR (QR_UNIVERSAL 181..190), print & share (PRINT_SHARE 221..230), maps & location (MAPS_LOCATION 231..240),
-- hardware devices (HARDWARE_DEVICE 241..250).
--   QR: one resolver for every Mohona label; signed labels (company secret) for employee, retailer, lot, document, invoice,
--       receipt; no secret in any payload; revoked documents refused; invoices / receipts are never a payment confirmation
--   Print: every print / share is authorised per document type, watermarked with who + when, and logged; printers must be
--       registered devices of the company (network printers only at a registered IP); unverified receipts are flagged
--   Location: pings only with consent (+ background only when the Chairman allows it), accuracy + age kept, retention by setting,
--       live markers only of consenting officers in the viewer's scope, dealer pins masked without rights, navigation link
--       built from the ordered stops (no invented travel times), route snapshot without personal coordinates
--   Hardware: device registry (unique fingerprint), policy per position + kind, health without invasive data, revocation that
--       also blocks the device's pending offline writes, append-only device events
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ hardware (F241–F250)
create table hardware.device (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  code          text not null check (code ~ '^[A-Z0-9_-]{2,30}$'),
  kind          text not null check (kind in ('qr_scanner','attendance_tablet','bt_printer','usb_printer','network_printer','barcode_scanner','phone')),
  fingerprint   text not null check (fingerprint ~ '^[0-9a-f]{64}$'),
  address       text,                                   -- printer MAC / USB vendor:product / IP:port
  tls           boolean not null default false,
  status        text not null default 'registered' check (status in ('registered','revoked')),
  registered_by uuid references core.person(id),
  registered_at timestamptz not null default clock_timestamp(),
  revoked_at    timestamptz,
  unique (id, company_id), unique (company_id, code), unique (company_id, fingerprint),
  check (kind <> 'network_printer' or address ~ '^[0-9]{1,3}(\.[0-9]{1,3}){3}:[0-9]{2,5}$')
);
create trigger trg_hw_device_nodel before delete on hardware.device for each row execute function core.fn_deny_delete();
create trigger trg_hw_device_audit after insert or update on hardware.device for each row execute function audit.fn_row_change();
create table hardware.device_policy (
  company_id    uuid not null references core.company(id),
  position_code text not null,
  kind          text not null,
  allowed       boolean not null,
  primary key (company_id, position_code, kind)
);
create trigger trg_hw_policy_audit after insert or update on hardware.device_policy for each row execute function audit.fn_row_change();
create table hardware.device_health (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  device_id   uuid not null references hardware.device(id),
  battery_pct integer check (battery_pct between 0 and 100),
  online      boolean,
  storage_free_mb integer,
  at          timestamptz not null default clock_timestamp()
);
create table hardware.device_event (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  device_id   uuid not null references hardware.device(id),
  action      text not null check (action in ('registered','paired','unpaired','policy_changed','revoked','test_print')),
  person_id   uuid,
  detail      jsonb not null default '{}'::jsonb,
  at          timestamptz not null default clock_timestamp()
);
create trigger trg_hw_event_no_mutation before update or delete on hardware.device_event for each row execute function core.fn_deny_mutation();

-- ================================================================ documents for QR (F189) + print log (F230)
create table core.document_registry (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  doc_type    text not null check (doc_type ~ '^[a-z]+\.[a-z_]+$'),
  doc_ref     text not null,
  version     integer not null default 1,
  sha256      text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  status      text not null default 'valid' check (status in ('valid','revoked')),
  issued_by   uuid references core.person(id),
  issued_at   timestamptz not null default clock_timestamp(),
  revoked_by  uuid references core.person(id),
  revoked_at  timestamptz,
  revoke_reason text,
  unique (company_id, doc_type, doc_ref, version)
);
create trigger trg_doc_registry_nodel before delete on core.document_registry for each row execute function core.fn_deny_delete();
create trigger trg_doc_registry_audit after insert or update on core.document_registry for each row execute function audit.fn_row_change();

create table core.print_log (
  id          bigint generated always as identity primary key,
  company_id  uuid not null references core.company(id),
  person_id   uuid not null references core.person(id),
  doc_type    text not null,
  doc_ref     text not null,
  format      text not null check (format in ('pdf','image','pos_bt','pos_usb','network','share')),
  device_id   uuid references hardware.device(id),
  watermark   text not null,
  at          timestamptz not null default clock_timestamp()
);
create trigger trg_print_log_no_mutation before update or delete on core.print_log for each row execute function core.fn_deny_mutation();

-- ================================================================ location (F231–F240)
create table location.position_ping (
  id           bigint generated always as identity primary key,
  company_id   uuid not null references core.company(id),
  person_id    uuid not null references core.person(id),
  latitude     numeric(9,6) not null check (latitude between -90 and 90),
  longitude    numeric(9,6) not null check (longitude between -180 and 180),
  accuracy_m   numeric(8,1) check (accuracy_m >= 0),
  recorded_at  timestamptz not null,
  received_at  timestamptz not null default clock_timestamp(),
  background   boolean not null default false
);
create index position_ping_person on location.position_ping (company_id, person_id, recorded_at desc);
create table location.export_log (
  id          bigint generated always as identity primary key,
  company_id  uuid not null, person_id uuid not null, route_plan_id uuid, at timestamptz not null default clock_timestamp()
);

select core.fn_apply_rls('hardware', 'device');
select core.fn_apply_rls('hardware', 'device_policy');
select core.fn_apply_rls('hardware', 'device_health');
select core.fn_apply_rls('hardware', 'device_event');
select core.fn_apply_rls('core', 'document_registry');
select core.fn_apply_rls('core', 'print_log');
select core.fn_apply_rls('location', 'position_ping');
select core.fn_apply_rls('location', 'export_log');

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('hardware.device.manage', 'hardware', 'ডিভাইস নিবন্ধন / নীতি / বাতিল', 'admin', true, false, array['COMPANY'], 'active', 2000),
  ('core.document.issue',    'core', 'নথি-QR ইস্যু ও বাতিল', 'admin', true, false, array['COMPANY'], 'active', 2010);
update iam.permission_catalog set status = 'active' where code in ('location.live.read','location.live.share');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', z from (values ('FIELD_SALES','location.live.share','SELF'), ('SALES_MANAGER','location.live.read','COMPANY'), ('MD','location.live.read','COMPANY'),
  ('TECH_ADMIN','hardware.device.manage','COMPANY'), ('HR_OFFICER','core.document.issue','COMPANY'), ('MD','core.document.issue','COMPANY')) v(x, y, z)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('hardware');
select config.fn_make_module_available('qr');
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('location.retention_days',     'location', 'int', '30', 1, 365, null, 'লোকেশন-ডেটা রাখার দিন', 'MOS-F153-236', true, 2100),
  ('location.background.allowed', 'location', 'bool', 'false', null, null, null, 'ব্যাকগ্রাউন্ড-লোকেশন (সম্মতিসহ)', 'MOS-F153-237', true, 2110),
  ('location.live.stale_minutes', 'location', 'int', '15', 1, 120, null, 'কত মিনিটের পুরোনো লোকেশন "পুরোনো" দেখাবে', 'MOS-F153-235', false, 2120),
  ('core.print_watermark.enabled',     'core', 'bool', 'true', null, null, null, 'প্রিন্টে কে/কখন জলছাপ', 'MOS-F153-230', true, 2130);

-- ================================================================ engine
create function hardware.fn_device_usable(p_company uuid, p_device uuid, p_kind text) returns boolean
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare d hardware.device%rowtype; me record; v_allowed boolean;
begin
  select * into d from hardware.device where id = p_device and company_id = p_company;
  if d.id is null or d.status <> 'registered' or (p_kind is not null and d.kind <> p_kind) then return false; end if;
  select * into me from iam.fn_context(false);
  select p.allowed into v_allowed from hardware.device_policy p where p.company_id = p_company and p.position_code = me.position_code and p.kind = d.kind;
  return coalesce(v_allowed, true) or me.is_supreme;                                         -- F249: a policy row can deny a kind to a position
end $$;

-- Watermark text: who + when (+ company), never data.
create function core.fn_watermark(p_company uuid) returns text
language sql stable security definer set search_path = pg_catalog as $$
  select case when config.fn_get_bool(p_company, 'core.print_watermark.enabled')
              then coalesce((select p.full_name_bn from core.person p where p.id = iam.fn_current_person()), '?') || ' · ' || to_char(clock_timestamp() at time zone 'Asia/Dhaka', 'YYYY-MM-DD HH24:MI')
              else '' end
$$;

-- ================================================================ API: hardware
create function api.v1_device_register(p_code text, p_kind text, p_fingerprint text, p_address text, p_tls boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hardware.device.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hardware.device (company_id, code, kind, fingerprint, address, tls, registered_by) values (me.company_id, upper(p_code), p_kind, lower(p_fingerprint), p_address, coalesce(p_tls, false), me.person_id)
  returning id into v_id;
  insert into hardware.device_event (company_id, device_id, action, person_id, detail) values (me.company_id, v_id, 'registered', me.person_id, jsonb_build_object('kind', p_kind));
  return jsonb_build_object('device_id', v_id);
end $$;

-- Revocation (F248): the device stops at once; a gate tablet with the same code loses its key too.
create function api.v1_device_revoke(p_device_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d hardware.device%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hardware.device.manage', iam.fn_my_company_resource(), true);
  select * into d from hardware.device where id = p_device_id and company_id = me.company_id for update;
  if not found or d.status <> 'registered' then perform core.fn_raise('E_NOT_FOUND', 'registered device'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update hardware.device set status = 'revoked', revoked_at = clock_timestamp() where id = d.id;
  update hr.gate_device set status = 'revoked' where company_id = me.company_id and code = d.code and status = 'active';
  insert into hardware.device_event (company_id, device_id, action, person_id, detail) values (me.company_id, d.id, 'revoked', me.person_id, jsonb_build_object('reason', p_reason));
  return jsonb_build_object('device_id', d.id, 'status', 'revoked');
end $$;

create function api.v1_device_policy_set(p_position_code text, p_kind text, p_allowed boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hardware.device.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hardware.device_policy (company_id, position_code, kind, allowed) values (me.company_id, p_position_code, p_kind, p_allowed)
  on conflict (company_id, position_code, kind) do update set allowed = excluded.allowed;
  return jsonb_build_object('position_code', p_position_code, 'kind', p_kind, 'allowed', p_allowed);
end $$;

-- Health (F247): battery / online / free storage only — nothing about apps, contacts or content.
create function api.v1_device_health(p_device_id uuid, p_battery integer, p_online boolean, p_storage_free_mb integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  if not exists (select 1 from hardware.device d where d.id = p_device_id and d.company_id = me.company_id and d.status = 'registered') then perform core.fn_raise('E_GATE_DEVICE_INVALID'); end if;
  insert into hardware.device_health (company_id, device_id, battery_pct, online, storage_free_mb) values (me.company_id, p_device_id, p_battery, p_online, p_storage_free_mb);
  return jsonb_build_object('recorded', true);
end $$;

-- ================================================================ API: print & share (F221–F230)
-- Authorises one print / share, returns the data to render (server-side figures only) + watermark, and logs it.
create function api.v1_print_authorize(p_doc_type text, p_doc_ref text, p_format text, p_device_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_data jsonb; v_perm text; v_wm text; i sales.invoice%rowtype; c sales.collection%rowtype;
begin
  select * into me from iam.fn_context(false);
  if coalesce(p_format, '') not in ('pdf','image','pos_bt','pos_usb','network','share') then perform core.fn_raise('E_INVALID_ACTION', 'format'); end if;
  if p_format in ('pos_bt','pos_usb','network')
     and not hardware.fn_device_usable(me.company_id, p_device_id, case p_format when 'pos_bt' then 'bt_printer' when 'pos_usb' then 'usb_printer' else 'network_printer' end) then
    perform core.fn_raise('E_PRINTER_NOT_REGISTERED');                                      -- F227–F229, F244
  end if;
  case p_doc_type
    when 'sales.invoice' then
      select * into i from sales.invoice where company_id = me.company_id and number = p_doc_ref;
      if i.id is null then perform core.fn_raise('E_NOT_FOUND', 'invoice'); end if;
      perform iam.fn_require('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = i.dealer_id)), false);
      v_data := jsonb_build_object('number', i.number, 'date', i.invoice_date, 'due_date', i.due_date, 'dealer', (select d.name_bn from sales.dealer d where d.id = i.dealer_id),
                                   'lines', i.lines, 'total', i.total, 'qr', sales.fn_signed(me.company_id, 'MOS1|I|' || (select x.code from core.company x where x.id = me.company_id) || '|' || i.number));
    when 'sales.receipt' then
      select * into c from sales.collection where company_id = me.company_id and number = p_doc_ref;
      if c.id is null then perform core.fn_raise('E_NOT_FOUND', 'receipt'); end if;
      perform iam.fn_require('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = c.dealer_id)), false);
      v_data := jsonb_build_object('number', c.number, 'amount', c.amount, 'method', c.method, 'status', c.status,
                                   'unverified_banner', case when c.status <> 'verified' then 'যাচাই হয়নি — এটি পরিশোধের প্রমাণ নয়' end);       -- F222
    when 'inventory.stock' then
      v_data := api.v1_stock_report((nullif(p_doc_ref, ''))::uuid, null);
    when 'finance.ledger' then
      perform iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
      v_data := api.v1_trial_balance(null);                                                      -- factory P&L is a separate MD-only report (F224)
    when 'hr.payslip' then
      v_data := api.v1_payslip((split_part(p_doc_ref, ':', 1))::uuid, nullif(split_part(p_doc_ref, ':', 2), '')::uuid);
    else
      perform core.fn_raise('E_INVALID_ACTION', 'unknown document type');
  end case;
  v_wm := core.fn_watermark(me.company_id);
  insert into core.print_log (company_id, person_id, doc_type, doc_ref, format, device_id, watermark) values (me.company_id, me.person_id, p_doc_type, p_doc_ref, p_format, p_device_id, v_wm);
  return jsonb_build_object('doc_type', p_doc_type, 'data', v_data, 'watermark', v_wm);
end $$;

create function api.v1_print_log(p_from timestamptz, p_to timestamptz) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('at', l.at, 'person_id', l.person_id, 'doc_type', l.doc_type, 'doc_ref', l.doc_ref, 'format', l.format, 'device_id', l.device_id) order by l.id desc)
     from core.print_log l where l.company_id = me.company_id and l.at between coalesce(p_from, clock_timestamp() - interval '30 days') and coalesce(p_to, clock_timestamp())), '[]'::jsonb);
end $$;

-- ================================================================ API: documents + universal QR (F181–F190)
create function api.v1_document_issue(p_doc_type text, p_doc_ref text, p_sha256 text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; v_ver integer;
begin
  select * into me from iam.fn_require('core.document.issue', iam.fn_my_company_resource(), true);
  v_ver := coalesce((select max(d.version) from core.document_registry d where d.company_id = me.company_id and d.doc_type = p_doc_type and d.doc_ref = p_doc_ref), 0) + 1;
  insert into core.document_registry (company_id, doc_type, doc_ref, version, sha256, issued_by) values (me.company_id, p_doc_type, p_doc_ref, v_ver, lower(p_sha256), me.person_id)
  returning id into v_id;
  return jsonb_build_object('document_id', v_id, 'version', v_ver,
                            'qr', sales.fn_signed(me.company_id, 'MOS1|X|' || (select c.code from core.company c where c.id = me.company_id) || '|' || v_id));
end $$;

create function api.v1_document_revoke(p_document_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.document.issue', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  update core.document_registry set status = 'revoked', revoked_by = me.person_id, revoked_at = clock_timestamp(), revoke_reason = p_reason
   where id = p_document_id and company_id = me.company_id and status = 'valid';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'valid document'); end if;
  return jsonb_build_object('document_id', p_document_id, 'status', 'revoked');
end $$;

-- Signed identity labels: employee (no credentials, F181), retailer (F184), lot (F186).
create function api.v1_qr_label(p_kind text, p_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_code text; v_ref text;
begin
  select * into me from iam.fn_context(false);
  select c.code into v_code from core.company c where c.id = me.company_id;
  if p_kind = 'employee' and exists (select 1 from hr.employee e where e.id = p_id and e.company_id = me.company_id) then v_ref := 'E|' || v_code || '|' || p_id;
  elsif p_kind = 'retailer' then select 'T|' || v_code || '|' || r.code into v_ref from sales.retailer r where r.id = p_id and r.company_id = me.company_id;
  elsif p_kind = 'lot' and exists (select 1 from inventory.lot l where l.id = p_id and l.company_id = me.company_id) then v_ref := 'L|' || v_code || '|' || p_id;
  end if;
  if v_ref is null then perform core.fn_raise('E_NOT_FOUND', p_kind); end if;
  return jsonb_build_object('qr', sales.fn_signed(me.company_id, 'MOS1|' || v_ref));
end $$;

-- One resolver for every label type; signatures checked; scope always the caller's own company and rights.
create function api.v1_qr_resolve(p_payload text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); v_code text; v_ok boolean; t text := parts[2]; v jsonb; x record;
begin
  select * into me from iam.fn_context(false);
  select c.code into v_code from core.company c where c.id = me.company_id;
  if cardinality(parts) < 4 or parts[1] <> 'MOS1' or parts[3] is distinct from v_code then perform core.fn_raise('E_QR_INVALID'); end if;
  if t = 'P' then return jsonb_build_object('type', 'product', 'result', api.v1_product_resolve_qr(p_payload)); end if;          -- F185
  if t = 'B' then return jsonb_build_object('type', 'bin', 'result', api.v1_qr_lookup(p_payload)); end if;                       -- F187
  if t = 'D' then return jsonb_build_object('type', 'dealer', 'result', api.v1_dealer_qr_lookup(p_payload)); end if;             -- F183
  if t = 'R' then return jsonb_build_object('type', 'receipt', 'result', api.v1_receipt_qr_lookup(p_payload)); end if;           -- F190
  if t = 'A' then return jsonb_build_object('type', 'attendance', 'note_bn', 'হাজিরা-QR শুধু নিবন্ধিত গেট-ডিভাইসে স্ক্যান হয়।'); end if;   -- F182
  v_ok := sales.fn_signed(me.company_id, array_to_string(parts[1:cardinality(parts) - 1], '|')) = p_payload;
  if not v_ok then perform core.fn_raise('E_QR_INVALID'); end if;
  case t
    when 'E' then
      select e.id, p.full_name_bn, hr.fn_employee_active(e.id) active, (select a.position_code from iam.position_assignment a where a.membership_id = e.membership_id and a.status = 'active' limit 1) pos
        into x from hr.employee e join core.person p on p.id = e.person_id where e.id = parts[4]::uuid and e.company_id = me.company_id;
      v := jsonb_build_object('type', 'employee', 'name_bn', x.full_name_bn, 'active', x.active, 'position', x.pos);
    when 'T' then
      select r.name_bn, r.status, d.id dealer_id into x from sales.retailer r join sales.dealer d on d.id = r.dealer_id where r.company_id = me.company_id and r.code = parts[4];
      v := jsonb_build_object('type', 'retailer', 'name_bn', x.name_bn, 'status', x.status,
                              'dealer', case when (select a.allowed from iam.fn_authorize('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = x.dealer_id)), false) a)
                                             then (select d.name_bn from sales.dealer d where d.id = x.dealer_id) end);
    when 'L' then
      select l.lot_no, l.expiry_date, l.status, p.sku into x from inventory.lot l join inventory.product p on p.id = l.product_id where l.id = parts[4]::uuid and l.company_id = me.company_id;
      v := jsonb_build_object('type', 'lot', 'lot_no', x.lot_no, 'sku', x.sku, 'expiry_date', x.expiry_date, 'expired', x.expiry_date < current_date, 'status', x.status);
    when 'I' then
      select i.number, i.invoice_date, i.total into x from sales.invoice i where i.company_id = me.company_id and i.number = parts[4];
      v := jsonb_build_object('type', 'invoice', 'number', x.number, 'date', x.invoice_date, 'total', x.total, 'note_bn', 'ইনভয়েস-QR পরিশোধের প্রমাণ নয়।');   -- F188
    when 'X' then
      select d.doc_type, d.doc_ref, d.version, d.sha256, d.status into x from core.document_registry d where d.id = parts[4]::uuid and d.company_id = me.company_id;
      if x.status is distinct from 'valid' then perform core.fn_raise('E_QR_INVALID', 'document revoked'); end if;           -- F189
      v := jsonb_build_object('type', 'document', 'doc_type', x.doc_type, 'doc_ref', x.doc_ref, 'version', x.version, 'sha256', x.sha256);
    else perform core.fn_raise('E_QR_INVALID');
  end case;
  return v;
end $$;

-- ================================================================ API: location (F231–F240)
create function api.v1_location_ping(p_latitude numeric, p_longitude numeric, p_accuracy_m numeric, p_recorded_at timestamptz, p_background boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('location.live.share', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person()), false);
  if not exists (select 1 from sales.location_consent c where c.person_id = me.person_id and c.revoked_at is null) then perform core.fn_raise('E_CONSENT_REQUIRED'); end if;
  if coalesce(p_background, false) and not config.fn_get_bool(me.company_id, 'location.background.allowed') then perform core.fn_raise('E_CONSENT_REQUIRED', 'background location is off'); end if;
  if p_recorded_at is null or p_recorded_at > clock_timestamp() + interval '1 minute' then perform core.fn_raise('E_INVALID_ACTION', 'recorded_at'); end if;
  insert into location.position_ping (company_id, person_id, latitude, longitude, accuracy_m, recorded_at, background)
  values (me.company_id, me.person_id, p_latitude, p_longitude, p_accuracy_m, p_recorded_at, coalesce(p_background, false));
  return jsonb_build_object('stored', true);
end $$;

-- Live markers (F232, F235, F238): only officers consenting NOW, in the viewer's scope; age + accuracy shown, stale labelled.
create function api.v1_live_markers() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_stale integer;
begin
  select * into me from iam.fn_context(false);
  v_stale := config.fn_get_int(me.company_id, 'location.live.stale_minutes');
  return coalesce((select jsonb_agg(jsonb_build_object('person_id', q.person_id, 'name_bn', q.name_bn, 'lat', q.latitude, 'lon', q.longitude, 'accuracy_m', q.accuracy_m,
           'recorded_at', q.recorded_at, 'stale', q.recorded_at < clock_timestamp() - make_interval(mins => v_stale)))
     from (select distinct on (pp.person_id) pp.*, p.full_name_bn name_bn from location.position_ping pp join core.person p on p.id = pp.person_id
            where pp.company_id = me.company_id and pp.recorded_at > clock_timestamp() - interval '1 day'
              and exists (select 1 from sales.location_consent c where c.person_id = pp.person_id and c.revoked_at is null)
              and (select a.allowed from iam.fn_authorize('location.live.read', iam.fn_resource(me.company_id, (select x.home_wing_id from iam.position_assignment x
                     join iam.company_membership m on m.id = x.membership_id where m.person_id = pp.person_id and x.company_id = me.company_id and x.status = 'active' limit 1)), false) a)
            order by pp.person_id, pp.recorded_at desc) q), '[]'::jsonb);
end $$;

-- Dealer pins (F233): addresses / coordinates only for dealers the viewer may read.
create function api.v1_dealer_pins() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('dealer_id', d.id, 'code', d.code, 'name_bn', d.name_bn,
           'lat', case when r.ok then d.latitude end, 'lon', case when r.ok then d.longitude end, 'address_bn', case when r.ok then d.address_bn else '••••' end))
     from sales.dealer d cross join lateral (select coalesce((select a.allowed from iam.fn_authorize('location.dealer_map.read', sales.fn_dealer_resource(d), false) a), false) ok) r
    where d.company_id = me.company_id and d.status <> 'closed' and r.ok), '[]'::jsonb);
end $$;

-- Navigation (F234): a Google Maps directions link in stop order; no computed or invented travel time.
create function api.v1_route_navigation(p_route_plan_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_pts text[];
begin
  select * into me from iam.fn_context(false);
  select array_agg(coalesce(d.latitude, rt.latitude)::text || ',' || coalesce(d.longitude, rt.longitude)::text order by v.stop_seq) into v_pts
    from sales.dealer_visit v left join sales.dealer d on d.id = v.dealer_id left join sales.retailer rt on rt.id = v.retailer_id
   where v.route_plan_id = p_route_plan_id and v.company_id = me.company_id and (v.officer_id = me.person_id or (select a.allowed from iam.fn_authorize('route.manage', iam.fn_my_company_resource(), false) a))
     and coalesce(d.latitude, rt.latitude) is not null;
  if v_pts is null then perform core.fn_raise('E_NOT_FOUND', 'stops with coordinates'); end if;
  return jsonb_build_object('url', 'https://www.google.com/maps/dir/?api=1&destination=' || v_pts[cardinality(v_pts)]
                                   || case when cardinality(v_pts) > 1 then '&waypoints=' || array_to_string(v_pts[1:cardinality(v_pts) - 1], '|') else '' end
                                   || '&travelmode=driving', 'stops', cardinality(v_pts));
end $$;

-- Snapshot (F240): stops and statuses; officer check-in coordinates removed; export logged.
create function api.v1_route_snapshot(p_route_plan_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; j jsonb;
begin
  select * into me from iam.fn_require('route.manage', iam.fn_my_company_resource(), false);
  j := api.v1_route_map(p_route_plan_id);
  insert into location.export_log (company_id, person_id, route_plan_id) values (me.company_id, me.person_id, p_route_plan_id);
  return jsonb_build_object('route_plan_id', p_route_plan_id,
    'stops', coalesce((select jsonb_agg(x - 'check_in') from jsonb_array_elements(j -> 'stops') x), '[]'::jsonb), 'exported_at', clock_timestamp());
end $$;

-- Retention (F236): platform cron removes pings older than the company setting.
create function svc.v1_location_purge() returns integer
language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  perform set_config('mohona.company_scope', '', true);
  delete from location.position_ping p where p.received_at < clock_timestamp() - make_interval(days => config.fn_get_int(p.company_id, 'location.retention_days'));
  get diagnostics n = row_count;
  return n;
end $$;

select core.fn_assert_rls_everywhere();
reset role;
do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_device_register(text, text, text, text, boolean, text)', 'api.v1_device_revoke(uuid, text)', 'api.v1_device_policy_set(text, text, boolean, text)',
      'api.v1_device_health(uuid, integer, boolean, integer)', 'api.v1_print_authorize(text, text, text, uuid)', 'api.v1_print_log(timestamptz, timestamptz)',
      'api.v1_document_issue(text, text, text)', 'api.v1_document_revoke(uuid, text)', 'api.v1_qr_label(text, uuid)', 'api.v1_qr_resolve(text)',
      'api.v1_location_ping(numeric, numeric, numeric, timestamptz, boolean)', 'api.v1_live_markers()', 'api.v1_dealer_pins()', 'api.v1_route_navigation(uuid)',
      'api.v1_route_snapshot(uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then execute 'grant execute on function svc.v1_location_purge() to service_role'; end if;
end $$;

-- 20261108003900_prime_completion.sql  (S58 — Prime Distribution Architect 1, remaining items)
--   Warehouse flow order -> reserve -> PICK -> PACK -> dispatch (Prime 02): no dispatch before pick and pack (setting, default on)
--   Warehouse board: orders waiting / picked / packed, today's dispatches, shipments with the courier by courier + destination,
--     finished goods sent by the factory but not yet received
--   Returns board (Prime 02): returning / received back / QC hold / damaged / lost — separate states, never merged
--   Shipment cost view: freight + every approved expense linked to the shipment (one source, no double counting)
--   Sales analysis (Prime 03/04): by product / dealer / territory with top and weak items; no data = "তথ্য নেই", never a guess
--   Invoice print design: the design an invoice was issued with (old invoices keep theirs — gate 8)
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('inventory.pick_pack.required', 'inventory', 'bool', 'true', null, null, null, 'পিক ও প্যাক ছাড়া ডিসপ্যাচ নয়', 'Prime 02', false, 2500);

create table sales.order_fulfilment (
  order_id    uuid primary key,
  company_id  uuid not null,
  pick_list   jsonb not null,                 -- [{product_id, lot_id, lot_no, qty}] FEFO suggestion shown to the picker
  picked_by   uuid not null references core.person(id),
  picked_at   timestamptz not null default clock_timestamp(),
  packed_by   uuid references core.person(id),
  packed_at   timestamptz,
  cartons     integer check (cartons is null or cartons >= 0),
  note        text,
  foreign key (order_id, company_id) references sales.sales_order (id, company_id)
);
create trigger trg_order_fulfilment_nodel before delete on sales.order_fulfilment for each row execute function core.fn_deny_delete();
create trigger trg_order_fulfilment_audit after insert or update on sales.order_fulfilment for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'order_fulfilment');

create function sales.fn_dispatch_needs_pack() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if config.fn_get_bool(new.company_id, 'inventory.pick_pack.required')
     and not exists (select 1 from sales.order_fulfilment f where f.order_id = new.order_id and f.packed_at is not null) then
    raise exception 'E_NOT_PACKED: pick and pack the order before dispatch' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dispatch_needs_pack before insert on sales.dispatch for each row execute function sales.fn_dispatch_needs_pack();

-- Pick: only an allocated order; returns the FEFO pick list (earliest expiry first) and records who picked.
create function api.v1_order_pick(p_order_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype; l jsonb; a jsonb; v_list jsonb := '[]'::jsonb;
begin
  select * into o from sales.sales_order where id = p_order_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'order'); end if;
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_resource(o.company_id, null, null, null, o.warehouse_id), true);
  if o.status <> 'allocated' then perform core.fn_raise('E_INVALID_ACTION', 'only an allocated (approved) order is picked'); end if;
  if exists (select 1 from sales.order_fulfilment f where f.order_id = o.id) then perform core.fn_raise('E_INVALID_ACTION', 'already picked'); end if;
  for l in select * from jsonb_array_elements(o.lines) loop
    for a in select * from jsonb_array_elements(inventory.fn_fefo(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
      v_list := v_list || jsonb_build_array(jsonb_build_object('product_id', l ->> 'product_id', 'lot_id', a ->> 'lot_id',
                  'lot_no', (select x.lot_no from inventory.lot x where x.id = (a ->> 'lot_id')::uuid), 'qty', (a ->> 'qty')::numeric));
    end loop;
  end loop;
  perform set_config('mohona.change_reason', 'pick ' || o.number, true);
  insert into sales.order_fulfilment (order_id, company_id, pick_list, picked_by) values (o.id, o.company_id, v_list, me.person_id);
  return jsonb_build_object('order_id', o.id, 'pick_list', v_list);
end $$;

create function api.v1_order_pack(p_order_id uuid, p_cartons integer, p_note text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; f sales.order_fulfilment%rowtype;
begin
  select * into f from sales.order_fulfilment where order_id = p_order_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_INVALID_ACTION', 'pick the order first'); end if;
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_my_company_resource(), true);
  if f.packed_at is not null then perform core.fn_raise('E_INVALID_ACTION', 'already packed'); end if;
  perform set_config('mohona.change_reason', 'pack', true);
  update sales.order_fulfilment set packed_by = me.person_id, packed_at = clock_timestamp(), cartons = p_cartons, note = p_note where order_id = f.order_id;
  return jsonb_build_object('order_id', f.order_id, 'packed', true, 'cartons', p_cartons);
end $$;

-- Warehouse board: what waits, what left today, what is with which courier, what the factory sent but the warehouse has not received.
create function api.v1_warehouse_board() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'waiting', coalesce((select jsonb_agg(jsonb_build_object('order_id', o.id, 'number', o.number, 'dealer', d.name_bn, 'total', o.total, 'ordered_at', o.created_at,
                 'stage', case when f.packed_at is not null then 'packed' when f.order_id is not null then 'picked' else 'to_pick' end) order by o.created_at)
               from sales.sales_order o join sales.dealer d on d.id = o.dealer_id left join sales.order_fulfilment f on f.order_id = o.id
              where o.company_id = me.company_id and o.status = 'allocated'), '[]'::jsonb),
    'awaiting_approval', (select count(*) from sales.sales_order o where o.company_id = me.company_id and o.status = 'pending_approval'),
    'dispatched_today', coalesce((select jsonb_agg(jsonb_build_object('dispatch', x.number, 'order', o.number, 'dealer', d.name_bn, 'vehicle', x.vehicle, 'at', x.dispatched_at) order by x.dispatched_at)
               from sales.dispatch x join sales.sales_order o on o.id = x.order_id join sales.dealer d on d.id = o.dealer_id
              where x.company_id = me.company_id and x.dispatched_at::date = current_date), '[]'::jsonb),
    'with_courier', coalesce((select jsonb_agg(jsonb_build_object('courier', q.name_bn, 'destination', q.destination, 'shipments', q.n) order by q.name_bn, q.destination) from (
                 select c.name_bn, s.destination, count(*) n from sales.shipment s join sales.courier_provider c on c.id = s.provider_id
                  where s.company_id = me.company_id and s.status <> 'CLOSED' group by c.name_bn, s.destination) q), '[]'::jsonb),
    'fg_to_receive', coalesce((select jsonb_agg(jsonb_build_object('batch_id', b.id, 'batch', b.number, 'sent_poly', h.sent_poly, 'sent_at', h.sent_at) order by h.sent_at)
               from mfg.fg_handover h join mfg.batch b on b.id = h.batch_id where h.company_id = me.company_id and h.status = 'sent'), '[]'::jsonb));
end $$;

-- Returns board: each state is its own number per product; QC hold = what sits in quarantine warehouses right now.
create function api.v1_returns_board() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'by_product', coalesce((select jsonb_agg(jsonb_build_object('product_id', q.product_id, 'sku', p.sku, 'name_bn', p.name_bn, 'returning', q.rt, 'received_back', q.rr,
                 'damaged', q.dm, 'lost', q.ls) order by p.sku) from (
                 select sl.product_id, sum(sl.return_in_transit_qty) rt, sum(sl.returned_received_qty) rr, sum(sl.damaged_qty) dm, sum(sl.lost_qty) ls
                   from sales.shipment_line sl where sl.company_id = me.company_id group by sl.product_id
                 having sum(sl.return_in_transit_qty + sl.returned_received_qty + sl.damaged_qty + sl.lost_qty) > 0) q
               join inventory.product p on p.id = q.product_id), '[]'::jsonb),
    'qc_hold', coalesce((select jsonb_agg(jsonb_build_object('warehouse', w.code, 'sku', p.sku, 'qty', b.qty) order by w.code, p.sku)
               from inventory.stock_balance b join inventory.warehouse w on w.id = b.warehouse_id join inventory.product p on p.id = b.product_id
              where b.company_id = me.company_id and w.kind = 'quarantine' and b.qty > 0), '[]'::jsonb),
    'note_bn', 'কোয়ারেন্টাইন থেকে বিক্রয়যোগ্য গুদামে অনুমোদিত স্থানান্তরের পরেই ফেরত পণ্য বিক্রয়যোগ্য।');
end $$;

-- Every cost of one shipment from its single source: company freight share + approved expenses linked to it.
create function api.v1_shipment_costs(p_shipment_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; s sales.shipment%rowtype;
begin
  select * into me from iam.fn_require('courier.read', iam.fn_my_company_resource(), false);
  select * into s from sales.shipment where id = p_shipment_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'shipment'); end if;
  return jsonb_build_object('shipment', s.number, 'freight_company_share', s.company_share, 'freight_dealer_share', s.dealer_share,
    'expenses', coalesce((select jsonb_agg(jsonb_build_object('number', m.number, 'category', m.category, 'amount', m.amount, 'status', m.status) order by m.number)
                 from finance.money_request m where m.shipment_id = s.id and m.kind = 'expense'), '[]'::jsonb),
    'total_company_cost', s.company_share + coalesce((select sum(m.amount) from finance.money_request m where m.shipment_id = s.id and m.kind = 'expense' and m.status = 'POSTED'), 0));
end $$;

-- Sales analysis from posted invoices only. dimension: product | dealer | territory. Empty period -> rows [] + "তথ্য নেই".
create function api.v1_sales_analysis(p_from date, p_to date, p_dimension text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date); v_rows jsonb;
begin
  select * into me from iam.fn_require('sales.monthly_summary.read', iam.fn_my_company_resource(), false);
  if coalesce(p_dimension, '') not in ('product','dealer','territory') then perform core.fn_raise('E_INVALID_ACTION', 'dimension'); end if;
  select coalesce(jsonb_agg(jsonb_build_object('key', q.k, 'name_bn', q.n, 'qty', q.qty, 'amount', q.amount, 'rank', q.rk,
           'tag', case when q.rk <= 3 then 'top' when q.rk > q.cnt - 3 and q.cnt > 3 then 'weak' end) order by q.rk), '[]'::jsonb) into v_rows
    from (select z.k, z.n, z.qty, z.amount, rank() over (order by z.amount desc) rk, count(*) over () cnt from (
            select case p_dimension when 'product' then p.sku when 'dealer' then d.code else tr.code end k,
                   case p_dimension when 'product' then p.name_bn when 'dealer' then d.name_bn else tr.name_bn end n,
                   sum((x ->> 'qty')::numeric) qty, sum(round((x ->> 'qty')::numeric * (x ->> 'price')::numeric, 2)) amount
              from sales.invoice i cross join jsonb_array_elements(i.lines) x
              join inventory.product p on p.id = (x ->> 'product_id')::uuid join sales.dealer d on d.id = i.dealer_id join sales.territory tr on tr.id = d.territory_id
             where i.company_id = me.company_id and i.invoice_date between f and t group by 1, 2) z) q;
  insert into sales.report_log (company_id, person_id, report, params) values (me.company_id, me.person_id, 'analysis', jsonb_build_object('from', f, 'to', t, 'dimension', p_dimension));
  return jsonb_build_object('from', f, 'to', t, 'dimension', p_dimension, 'rows', v_rows,
                            'note_bn', case when jsonb_array_length(v_rows) = 0 then 'তথ্য নেই' end);
end $$;

-- The design an invoice was issued with (stamped at posting; never changes afterwards).
create function api.v1_invoice_print_design(p_number text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_code text;
begin
  select * into me from iam.fn_require('crm.dealer.read', iam.fn_my_company_resource(), false);
  select i.design_code into v_code from sales.invoice i where i.company_id = me.company_id and i.number = p_number;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'invoice'); end if;
  return jsonb_build_object('number', p_number, 'design_code', v_code, 'spec', (select d.spec from sales.invoice_design d where d.code = v_code));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_order_pick(uuid)', 'api.v1_order_pack(uuid, integer, text)', 'api.v1_warehouse_board()', 'api.v1_returns_board()',
      'api.v1_shipment_costs(uuid)', 'api.v1_sales_analysis(date, date, text)', 'api.v1_invoice_print_design(text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- 20261108002600_procurement_ap.sql  (S26–S28 in one step)
-- Procurement & payables (blueprint PROCUREMENT_AP MOS-F153-081..090) + raw purchasing (MOS-F153-072, OI-38):
--   081 supplier master: company-scoped terms; duplicates caught by tax id AND by a tax-neutral key (name + phone)
--   082 purchase requisition with quote comparison; approval engine — the requester never approves
--   083 purchase order; after approval only controlled change orders (approval again; never below what is received)
--   084 GRN against an APPROVED PO only (OI-38); QC split via the inventory receipt engine; GRNI = accepted value
--   085 supplier bill; the same supplier invoice number is never captured twice
--   086 three-way match PO / GRN / bill on quantity and price; a variance needs approval
--   087 supplier payment (bank / cash, partial / full) never above the approved open payable
--   088 debit note (return to supplier = stock out, price correction) linked to the original GRN line and bill
--   089 aging by supplier and bill; only POSTED payments and debit notes reduce what is due
--   090 supplier performance: on-time delivery, QC rejection, price variance — per company only
-- Ledger journals (GL) arrive with FINANCE_LEDGER; this step keeps the AP sub-ledger and GRNI exact for that hand-over.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ supplier (F081)
create function procurement.fn_supplier_key(p_name text, p_phone text) returns text
language sql immutable set search_path = pg_catalog as $$
  select md5(regexp_replace(lower(normalize(coalesce(p_name, ''), NFC)), '[[:space:][:punct:]।]+', '', 'g') || '|' || coalesce(core.fn_phone_canonical(p_phone), ''))
$$;

create table procurement.supplier (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null references core.company(id),
  code                text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn             text not null check (length(btrim(name_bn)) > 0),
  name_en             text,
  phone               text,
  email               text,
  address_bn          text,
  admin_area_code     text references location.admin_area(code),
  tax_id              text check (tax_id is null or tax_id ~ '^[0-9]{9,15}$'),
  dup_key             text not null,
  payment_terms_days  integer not null default 30 check (payment_terms_days between 0 and 365),
  credit_limit        numeric(14,2) check (credit_limit is null or credit_limit >= 0),
  bank_account_masked text,
  status              text not null default 'active' check (status in ('active','blocked')),
  created_at          timestamptz not null default clock_timestamp(),
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id), unique (company_id, code), unique (company_id, dup_key)
);
create unique index supplier_tax_id on procurement.supplier (company_id, tax_id) where tax_id is not null;
create trigger trg_supplier_guard before update on procurement.supplier for each row execute function core.fn_scoped_guard();
create trigger trg_supplier_touch before update on procurement.supplier for each row execute function core.fn_touch_row();
create trigger trg_supplier_nodel before delete on procurement.supplier for each row execute function core.fn_deny_delete();
create trigger trg_supplier_audit after insert or update on procurement.supplier for each row execute function audit.fn_row_change();

-- ================================================================ requisition (F082)
create table procurement.pr (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  number        text,
  wing_id       uuid,
  department_id uuid,
  requester_id  uuid not null references core.person(id),
  needed_by     date,
  status        text not null default 'draft' check (status in ('draft','pending_approval','approved','rejected','cancelled','ordered')),
  reason        text not null check (length(btrim(reason)) > 0),
  approval_request_id uuid,
  created_at    timestamptz not null default clock_timestamp(),
  updated_at    timestamptz not null default clock_timestamp(),
  row_version   integer not null default 1,
  unique (id, company_id),
  foreign key (wing_id, company_id) references core.wing (id, company_id)
);
create table procurement.pr_line (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  pr_id       uuid not null,
  line_no     integer not null check (line_no >= 1),
  product_id  uuid not null,
  qty         numeric(18,4) not null check (qty > 0),
  est_price   numeric(14,4) check (est_price is null or est_price >= 0),
  note        text,
  unique (pr_id, line_no),
  foreign key (pr_id, company_id) references procurement.pr (id, company_id),
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);
create table procurement.pr_quote (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  pr_id        uuid not null,
  supplier_id  uuid not null,
  product_id   uuid not null,
  unit_price   numeric(14,4) not null check (unit_price >= 0),
  lead_days    integer check (lead_days is null or lead_days >= 0),
  chosen       boolean not null default false,
  created_by   uuid, created_at timestamptz not null default clock_timestamp(),
  foreign key (pr_id, company_id) references procurement.pr (id, company_id),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id)
);
create function procurement.fn_pr_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('pending_approval','approved','cancelled'))
       or (old.status = 'pending_approval' and new.status in ('approved','rejected','cancelled')) or (old.status = 'approved' and new.status in ('ordered','cancelled'))) then
    raise exception 'E_INVALID_ACTION: requisition % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  if old.requester_id <> new.requester_id or old.company_id <> new.company_id then raise exception 'E_IMMUTABLE: requisition identity' using errcode = 'P0001'; end if;
  return new;
end $$;
create trigger trg_pr_guard before update on procurement.pr for each row execute function procurement.fn_pr_guard();
create trigger trg_pr_touch before update on procurement.pr for each row execute function core.fn_touch_row();
create trigger trg_pr_nodel before delete on procurement.pr for each row execute function core.fn_deny_delete();
create trigger trg_pr_audit after insert or update on procurement.pr for each row execute function audit.fn_row_change();
-- lines change only while the requisition is a draft; quotes may be added until it is ordered; nothing is deleted
create function procurement.fn_pr_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (select p.status from procurement.pr p where p.id = coalesce(new.pr_id, old.pr_id)) <> 'draft' then
    raise exception 'E_IMMUTABLE: requisition lines change only while draft' using errcode = 'P0001';
  end if;
  return coalesce(new, old);
end $$;
create trigger trg_pr_line_guard before insert or update or delete on procurement.pr_line for each row execute function procurement.fn_pr_line_guard();
create trigger trg_pr_line_audit after insert or update on procurement.pr_line for each row execute function audit.fn_row_change();
create function procurement.fn_pr_quote_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if tg_op = 'DELETE' or (to_jsonb(old) - 'chosen') <> (to_jsonb(new) - 'chosen')
     or (select p.status from procurement.pr p where p.id = new.pr_id) not in ('draft','pending_approval','approved') then
    raise exception 'E_IMMUTABLE: a quote is only chosen or not, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_pr_quote_guard before update or delete on procurement.pr_quote for each row execute function procurement.fn_pr_quote_guard();
create trigger trg_pr_quote_audit after insert or update on procurement.pr_quote for each row execute function audit.fn_row_change();

-- ================================================================ purchase order + change orders (F083, F072)
create table procurement.po (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null references core.company(id),
  number              text,
  supplier_id         uuid not null,
  warehouse_id        uuid not null,
  wing_id             uuid,
  pr_id               uuid,
  expected_date       date,
  payment_terms_days  integer not null check (payment_terms_days between 0 and 365),
  status              text not null default 'draft' check (status in ('draft','pending_approval','approved','partially_received','received','closed','cancelled')),
  version             integer not null default 1,
  total               numeric(16,2) not null default 0 check (total >= 0),
  reason              text not null,
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  approved_at         timestamptz,
  approval_request_id uuid,
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id),
  foreign key (pr_id, company_id) references procurement.pr (id, company_id)
);
create function procurement.fn_po_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.supplier_id <> old.supplier_id or new.company_id <> old.company_id or new.created_by <> old.created_by then
    raise exception 'E_IMMUTABLE: a PO keeps its supplier' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('pending_approval','approved','cancelled'))
       or (old.status = 'pending_approval' and new.status in ('approved','draft','cancelled'))
       or (old.status in ('approved','partially_received') and new.status in ('partially_received','received','closed','cancelled'))
       or (old.status = 'received' and new.status = 'closed')) then
    raise exception 'E_INVALID_ACTION: purchase order % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  if old.status not in ('draft','pending_approval') and (new.total <> old.total or new.version <> old.version or new.expected_date is distinct from old.expected_date
                                                        or new.payment_terms_days <> old.payment_terms_days)
     and coalesce(current_setting('mohona.po_change', true), '') <> 'apply' then
    raise exception 'E_PO_LOCKED: an approved PO changes only through an approved change order' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_po_guard before update on procurement.po for each row execute function procurement.fn_po_guard();
create trigger trg_po_touch before update on procurement.po for each row execute function core.fn_touch_row();
create trigger trg_po_nodel before delete on procurement.po for each row execute function core.fn_deny_delete();
create trigger trg_po_audit after insert or update on procurement.po for each row execute function audit.fn_row_change();

create table procurement.po_line (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  po_id         uuid not null,
  line_no       integer not null check (line_no >= 1),
  product_id    uuid not null,
  qty           numeric(18,4) not null check (qty > 0),
  unit_price    numeric(14,4) not null check (unit_price >= 0),
  received_qty  numeric(18,4) not null default 0 check (received_qty >= 0),
  billed_qty    numeric(18,4) not null default 0 check (billed_qty >= 0),
  status        text not null default 'open' check (status in ('open','cancelled')),
  unique (id, company_id), unique (po_id, line_no),
  foreign key (po_id, company_id) references procurement.po (id, company_id),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  check (received_qty <= qty * 1.5)
);
create function procurement.fn_po_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_status text;
begin
  select p.status into v_status from procurement.po p where p.id = coalesce(new.po_id, old.po_id);
  if tg_op = 'DELETE' then raise exception 'E_IMMUTABLE: PO lines are never deleted' using errcode = 'P0001'; end if;
  if tg_op = 'UPDATE' and (new.product_id <> old.product_id or new.line_no <> old.line_no) then raise exception 'E_IMMUTABLE: PO line identity' using errcode = 'P0001'; end if;
  if v_status not in ('draft','pending_approval') and coalesce(current_setting('mohona.po_change', true), '') <> 'apply'
     and (tg_op = 'INSERT' or new.qty <> old.qty or new.unit_price <> old.unit_price or new.status <> old.status) then
    raise exception 'E_PO_LOCKED: an approved PO changes only through an approved change order' using errcode = 'P0001';
  end if;
  if tg_op = 'UPDATE' and new.qty < new.received_qty then raise exception 'E_INVALID_ACTION: quantity below what is already received' using errcode = 'P0001'; end if;
  return new;
end $$;
create trigger trg_po_line_guard before insert or update or delete on procurement.po_line for each row execute function procurement.fn_po_line_guard();
create trigger trg_po_line_audit after insert or update on procurement.po_line for each row execute function audit.fn_row_change();

create table procurement.po_change (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  po_id               uuid not null,
  from_version        integer not null,
  changes             jsonb not null,          -- {"lines":[{"line_no","qty","unit_price","cancel"}],"expected_date","payment_terms_days"}
  status              text not null default 'pending' check (status in ('pending','approved','rejected','cancelled')),
  reason              text not null check (length(btrim(reason)) > 0),
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  applied_at          timestamptz,
  unique (id, company_id),
  foreign key (po_id, company_id) references procurement.po (id, company_id)
);
create unique index po_change_one_pending on procurement.po_change (po_id) where status = 'pending';
create trigger trg_po_change_nodel before delete on procurement.po_change for each row execute function core.fn_deny_delete();
create trigger trg_po_change_audit after insert or update on procurement.po_change for each row execute function audit.fn_row_change();

-- ================================================================ GRN (F084)
create table procurement.grn (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  number        text,
  po_id         uuid not null,
  warehouse_id  uuid not null,
  delivery_note text,
  received_by   uuid not null references core.person(id),
  received_at   timestamptz not null default clock_timestamp(),
  reason        text,
  unique (id, company_id),
  foreign key (po_id, company_id) references procurement.po (id, company_id)
);
create trigger trg_grn_no_mutation before update or delete on procurement.grn for each row execute function core.fn_deny_mutation();
create trigger trg_grn_audit after insert on procurement.grn for each row execute function audit.fn_row_change();

create table procurement.grn_line (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  grn_id          uuid not null,
  po_line_id      uuid not null,
  product_id      uuid not null,
  receipt_id      uuid not null,
  lot_id          uuid not null,
  received_qty    numeric(18,4) not null check (received_qty > 0),
  accepted_qty    numeric(18,4) not null check (accepted_qty >= 0),
  quarantine_qty  numeric(18,4) not null default 0 check (quarantine_qty >= 0),
  rejected_qty    numeric(18,4) not null default 0 check (rejected_qty >= 0),
  unit_price      numeric(14,4) not null check (unit_price >= 0),
  returned_qty    numeric(18,4) not null default 0 check (returned_qty >= 0),
  unique (id, company_id),
  check (accepted_qty + quarantine_qty + rejected_qty = received_qty),
  foreign key (grn_id, company_id) references procurement.grn (id, company_id),
  foreign key (po_line_id, company_id) references procurement.po_line (id, company_id),
  foreign key (receipt_id, company_id) references inventory.receipt (id, company_id)
);
create function procurement.fn_grn_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if tg_op = 'DELETE' or (to_jsonb(old) - 'returned_qty') <> (to_jsonb(new) - 'returned_qty') or new.returned_qty < old.returned_qty then
    raise exception 'E_IMMUTABLE: a GRN line never changes (returns go through a debit note)' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_grn_line_guard before update or delete on procurement.grn_line for each row execute function procurement.fn_grn_line_guard();
create trigger trg_grn_line_audit after insert or update on procurement.grn_line for each row execute function audit.fn_row_change();

-- Matchable quantity of a GRN line = accepted at receipt + released from quarantine later − returned to the supplier.
create function procurement.fn_grn_line_usable(p_line procurement.grn_line) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select p_line.accepted_qty + coalesce((select sum(h.released_qty) from inventory.quarantine_hold h where h.receipt_id = p_line.receipt_id), 0) - p_line.returned_qty
$$;

-- ================================================================ supplier bills + three-way match (F085, F086)
create table procurement.bill (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  number              text,
  supplier_id         uuid not null,
  supplier_invoice_no text not null check (length(btrim(supplier_invoice_no)) between 1 and 40),
  invoice_key         text not null,                         -- normalised invoice number (duplicate guard)
  invoice_date        date not null,
  due_date            date not null,
  status              text not null default 'draft' check (status in ('draft','variance_pending','posted','rejected','cancelled')),
  total               numeric(16,2) not null default 0 check (total >= 0),
  match_report        jsonb not null default '{}'::jsonb,
  approval_request_id uuid,
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  posted_at           timestamptz,
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id),
  unique (company_id, supplier_id, invoice_key),
  check (due_date >= invoice_date),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id)
);
create function procurement.fn_bill_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status in ('posted','cancelled','rejected') and (to_jsonb(old) - array['updated_at','row_version']) <> (to_jsonb(new) - array['updated_at','row_version']) then
    raise exception 'E_IMMUTABLE: a posted bill never changes (use a debit note)' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('variance_pending','posted','cancelled'))
                                       or (old.status = 'variance_pending' and new.status in ('posted','rejected','draft','cancelled'))) then
    raise exception 'E_INVALID_ACTION: bill % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_bill_guard before update on procurement.bill for each row execute function procurement.fn_bill_guard();
create trigger trg_bill_touch before update on procurement.bill for each row execute function core.fn_touch_row();
create trigger trg_bill_nodel before delete on procurement.bill for each row execute function core.fn_deny_delete();
create trigger trg_bill_audit after insert or update on procurement.bill for each row execute function audit.fn_row_change();

create table procurement.bill_line (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  bill_id     uuid not null,
  line_no     integer not null check (line_no >= 1),
  grn_line_id uuid not null,
  qty         numeric(18,4) not null check (qty > 0),
  unit_price  numeric(14,4) not null check (unit_price >= 0),
  amount      numeric(16,2) not null check (amount >= 0),
  unique (bill_id, line_no),
  foreign key (bill_id, company_id) references procurement.bill (id, company_id),
  foreign key (grn_line_id, company_id) references procurement.grn_line (id, company_id)
);
create function procurement.fn_bill_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (select b.status from procurement.bill b where b.id = coalesce(new.bill_id, old.bill_id)) <> 'draft' or tg_op = 'DELETE' then
    raise exception 'E_IMMUTABLE: bill lines change only while draft' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_bill_line_guard before insert or update or delete on procurement.bill_line for each row execute function procurement.fn_bill_line_guard();
create trigger trg_bill_line_audit after insert on procurement.bill_line for each row execute function audit.fn_row_change();

-- ================================================================ payments (F087) and debit notes (F088)
create table procurement.payment (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  number              text,
  supplier_id         uuid not null,
  method              text not null check (method in ('bank','cash')),
  amount              numeric(16,2) not null check (amount > 0),
  reference           text,
  allocations         jsonb not null,               -- [{bill_id, amount}]
  status              text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  approval_request_id uuid,
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  posted_at           timestamptz,
  unique (id, company_id),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id)
);
create function procurement.fn_doc_status_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','posted_at','approval_request_id']) <> (to_jsonb(new) - array['status','posted_at','approval_request_id'])
     or old.status <> 'pending_approval' then
    raise exception 'E_IMMUTABLE: % is decided once and never edited', tg_table_name using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_payment_guard before update on procurement.payment for each row execute function procurement.fn_doc_status_guard();
create trigger trg_payment_nodel before delete on procurement.payment for each row execute function core.fn_deny_delete();
create trigger trg_payment_audit after insert or update on procurement.payment for each row execute function audit.fn_row_change();

create table procurement.debit_note (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  number              text,
  supplier_id         uuid not null,
  kind                text not null check (kind in ('return','price')),
  grn_line_id         uuid not null,
  bill_id             uuid,
  qty                 numeric(18,4) check (qty is null or qty > 0),
  amount              numeric(16,2) not null check (amount > 0),
  reason              text not null check (length(btrim(reason)) > 0),
  status              text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  approval_request_id uuid,
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  posted_at           timestamptz,
  unique (id, company_id),
  check ((kind = 'return') = (qty is not null)),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id),
  foreign key (grn_line_id, company_id) references procurement.grn_line (id, company_id),
  foreign key (bill_id, company_id) references procurement.bill (id, company_id)
);
create trigger trg_debit_note_guard before update on procurement.debit_note for each row execute function procurement.fn_doc_status_guard();
create trigger trg_debit_note_nodel before delete on procurement.debit_note for each row execute function core.fn_deny_delete();
create trigger trg_debit_note_audit after insert or update on procurement.debit_note for each row execute function audit.fn_row_change();

select core.fn_apply_rls('procurement', 'supplier');
select core.fn_apply_rls('procurement', 'pr');
select core.fn_apply_rls('procurement', 'pr_line');
select core.fn_apply_rls('procurement', 'pr_quote');
select core.fn_apply_rls('procurement', 'po');
select core.fn_apply_rls('procurement', 'po_line');
select core.fn_apply_rls('procurement', 'po_change');
select core.fn_apply_rls('procurement', 'grn');
select core.fn_apply_rls('procurement', 'grn_line');
select core.fn_apply_rls('procurement', 'bill');
select core.fn_apply_rls('procurement', 'bill_line');
select core.fn_apply_rls('procurement', 'payment');
select core.fn_apply_rls('procurement', 'debit_note');

alter table inventory.stock_move drop constraint stock_move_move_type_check;
alter table inventory.stock_move add constraint stock_move_move_type_check check (move_type in ('receipt','opening','quarantine_release','issue','return','waste_normal',
  'waste_abnormal','adjust_in','adjust_out','transfer_in','transfer_out','fg_receipt','sale','purchase_return'));

-- ================================================================ permissions, modules, settings
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('procurement.debit.create', 'procurement', 'সাপ্লায়ার ডেবিট-নোট', 'write', true, false, array['COMPANY'], 'active', 790);
update iam.permission_catalog set status = 'active'
 where code in ('master.supplier.read','master.supplier.manage','procurement.read','procurement.pr.create','procurement.po.create','procurement.po.approve',
                'procurement.grn.receive','procurement.qc.inspect','procurement.bill.match','finance.ap.pay');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, 'procurement.read', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER','ACCOUNTANT','PURCHASE_OFFICER','STOREKEEPER','AUDITOR','QC_OFFICER']) x
union all select x, 'master.supplier.read', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER','ACCOUNTANT','PURCHASE_OFFICER','STOREKEEPER','AUDITOR']) x
union all select 'PURCHASE_OFFICER', 'master.supplier.manage', 'allow', 'COMPANY'
union all select x, 'procurement.pr.create', 'allow', 'COMPANY' from unnest(array['PURCHASE_OFFICER','STOREKEEPER','PROD_SUPERVISOR','WING_HEAD']) x
union all select 'PURCHASE_OFFICER', 'procurement.po.create', 'allow', 'COMPANY'
union all select 'MD', 'procurement.po.approve', 'allow', 'COMPANY'
union all select 'STOREKEEPER', 'procurement.grn.receive', 'allow', 'COMPANY'
union all select 'QC_OFFICER', 'procurement.qc.inspect', 'allow', 'COMPANY'
union all select x, 'procurement.bill.match', 'allow', 'COMPANY' from unnest(array['ACCOUNTANT','FIN_MANAGER']) x
union all select 'FIN_MANAGER', 'finance.ap.pay', 'allow', 'COMPANY'
union all select x, 'procurement.debit.create', 'allow', 'COMPANY' from unnest(array['PURCHASE_OFFICER','FIN_MANAGER']) x
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('procurement');
select config.fn_make_module_available('finance');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('procurement.match.price_tolerance_bp', 'procurement', 'int', '100', 0, 2000, null, 'দামের সহনশীলতা (বেসিস পয়েন্ট; ১০০ = ১%)', 'MOS-F153-086', true, 1300),
  ('procurement.match.qty_tolerance_bp',   'procurement', 'int', '0', 0, 2000, null, 'পরিমাণের সহনশীলতা (বেসিস পয়েন্ট)', 'MOS-F153-086', true, 1310),
  ('procurement.grn.over_receipt_bp',      'procurement', 'int', '0', 0, 2000, null, 'অর্ডারের বেশি গ্রহণের সীমা (বেসিস পয়েন্ট)', 'MOS-F153-084', true, 1320),
  ('procurement.grn.requires_qc',          'procurement', 'bool', 'false', null, null, null, 'GRN-এ মান-পরীক্ষক বাধ্যতামূলক (গ্রহণকারী নন)', 'MOS-F153-084', false, 1330);

-- ================================================================ engine
-- Open payable of a posted bill: total − POSTED payments − POSTED debit notes (F089: nothing else reduces it).
create function procurement.fn_bill_open(p_bill uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select b.total
       - coalesce((select sum((a ->> 'amount')::numeric) from procurement.payment p, jsonb_array_elements(p.allocations) a
                    where p.company_id = b.company_id and p.status = 'posted' and (a ->> 'bill_id')::uuid = b.id), 0)
       - coalesce((select sum(d.amount) from procurement.debit_note d where d.bill_id = b.id and d.status = 'posted'), 0)
    from procurement.bill b where b.id = p_bill
$$;

-- Same, minus what is already waiting in pending payments / debit notes (so two requests can never over-pay).
create function procurement.fn_bill_open_uncommitted(p_bill uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select procurement.fn_bill_open(p_bill)
       - coalesce((select sum((a ->> 'amount')::numeric) from procurement.payment p, jsonb_array_elements(p.allocations) a
                    where p.status = 'pending_approval' and (a ->> 'bill_id')::uuid = p_bill), 0)
       - coalesce((select sum(d.amount) from procurement.debit_note d where d.bill_id = p_bill and d.status = 'pending_approval'), 0)
$$;

create function procurement.fn_billed_qty(p_grn_line uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(l.qty), 0) from procurement.bill_line l join procurement.bill b on b.id = l.bill_id
   where l.grn_line_id = p_grn_line and b.status in ('draft','variance_pending','posted')
$$;

-- Applies one approved procurement document (called by core.fn_approval_apply and by direct approvals).
create function procurement.fn_on_approved(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare c procurement.po_change%rowtype; ln jsonb; p procurement.payment%rowtype; a jsonb; d procurement.debit_note%rowtype; g procurement.grn_line%rowtype;
        v_wh uuid;
begin
  perform set_config('mohona.change_reason', 'approved ' || r.document_type, true);
  if r.document_type = 'procurement.pr' then
    update procurement.pr set status = 'approved' where id = r.document_id and status = 'pending_approval';
  elsif r.document_type = 'procurement.po' then
    update procurement.po set status = 'approved', approved_at = clock_timestamp() where id = r.document_id and status = 'pending_approval';
    update procurement.pr set status = 'ordered' where id = (select x.pr_id from procurement.po x where x.id = r.document_id) and status = 'approved';
  elsif r.document_type = 'procurement.po_change' then
    select * into c from procurement.po_change where id = r.document_id for update;
    if c.status <> 'pending' then return; end if;
    perform set_config('mohona.po_change', 'apply', true);
    for ln in select * from jsonb_array_elements(coalesce(c.changes -> 'lines', '[]'::jsonb)) loop
      if coalesce((ln ->> 'cancel')::boolean, false) then
        update procurement.po_line set status = 'cancelled' where po_id = c.po_id and line_no = (ln ->> 'line_no')::integer and received_qty = 0;
      elsif (ln ->> 'line_no') is null then
        insert into procurement.po_line (company_id, po_id, line_no, product_id, qty, unit_price)
        values (c.company_id, c.po_id, coalesce((select max(x.line_no) from procurement.po_line x where x.po_id = c.po_id), 0) + 1,
                (ln ->> 'product_id')::uuid, (ln ->> 'qty')::numeric, (ln ->> 'unit_price')::numeric);
      else
        update procurement.po_line set qty = coalesce((ln ->> 'qty')::numeric, qty), unit_price = coalesce((ln ->> 'unit_price')::numeric, unit_price)
         where po_id = c.po_id and line_no = (ln ->> 'line_no')::integer;
      end if;
    end loop;
    update procurement.po set version = version + 1,
           expected_date = coalesce((c.changes ->> 'expected_date')::date, expected_date),
           payment_terms_days = coalesce((c.changes ->> 'payment_terms_days')::integer, payment_terms_days),
           total = (select coalesce(round(sum(l.qty * l.unit_price), 2), 0) from procurement.po_line l where l.po_id = c.po_id and l.status = 'open')
     where id = c.po_id;
    perform set_config('mohona.po_change', '', true);
    update procurement.po_change set status = 'approved', applied_at = clock_timestamp() where id = c.id;
  elsif r.document_type = 'procurement.bill_variance' then
    update procurement.bill set status = 'posted', posted_at = clock_timestamp() where id = r.document_id and status = 'variance_pending';
    update procurement.po_line pl set billed_qty = pl.billed_qty + x.q
      from (select gl.po_line_id, sum(l.qty) q from procurement.bill_line l join procurement.grn_line gl on gl.id = l.grn_line_id
             where l.bill_id = r.document_id group by gl.po_line_id) x where pl.id = x.po_line_id;
  elsif r.document_type = 'procurement.payment' then
    select * into p from procurement.payment where id = r.document_id for update;
    if p.status <> 'pending_approval' then return; end if;
    for a in select * from jsonb_array_elements(p.allocations) loop
      if (a ->> 'amount')::numeric > procurement.fn_bill_open((a ->> 'bill_id')::uuid) then
        raise exception 'E_OVERPAYMENT: allocation above the open payable' using errcode = 'P0001';
      end if;
    end loop;
    update procurement.payment set status = 'posted', posted_at = clock_timestamp() where id = p.id;
  elsif r.document_type = 'procurement.debit_note' then
    select * into d from procurement.debit_note where id = r.document_id for update;
    if d.status <> 'pending_approval' then return; end if;
    if d.kind = 'return' then
      select * into g from procurement.grn_line where id = d.grn_line_id for update;
      if d.qty > procurement.fn_grn_line_usable(g) then raise exception 'E_INVALID_ACTION: more than received and accepted' using errcode = 'P0001'; end if;
      select x.warehouse_id into v_wh from procurement.grn x where x.id = g.grn_id;
      perform inventory.fn_post_move(d.company_id, v_wh, g.product_id, g.lot_id, 'purchase_return', -d.qty, null, 'procurement.debit_note', d.id, 1, d.reason);
      update procurement.grn_line set returned_qty = returned_qty + d.qty where id = g.id;
    end if;
    if d.bill_id is not null and d.amount > procurement.fn_bill_open(d.bill_id) then
      raise exception 'E_OVERPAYMENT: debit note above the open payable' using errcode = 'P0001';
    end if;
    update procurement.debit_note set status = 'posted', posted_at = clock_timestamp() where id = d.id;
  end if;
end $$;

-- Submits through the approval engine; applies at once when the engine approves immediately (maker-checker off).
create function procurement.fn_submit(p_company uuid, p_type text, p_id uuid, p_amount numeric, p_resource iam.resource, p_payload jsonb default null) returns jsonb
language plpgsql security definer set search_path = pg_catalog as $$
declare j jsonb; r core.approval_request%rowtype;
begin
  j := core.fn_approval_submit(p_company, p_type, p_id, p_amount, p_resource, p_payload);
  if j ->> 'status' = 'approved' then
    select * into r from core.approval_request where id = (j ->> 'request_id')::uuid;
    perform procurement.fn_on_approved(r);
  end if;
  return j;
end $$;

-- Generic approval handlers: all earlier cases + procurement documents (S26–S28).
create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'design.layout_publish' then perform design.fn_publish_layout_version(r.company_id, r.payload ->> 'screen_key', (r.payload ->> 'version')::integer);
    when r.document_type like 'procurement.%' then perform procurement.fn_on_approved(r);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- ================================================================ API: suppliers
create function api.v1_supplier_save(p_id uuid, p_code text, p_name_bn text, p_name_en text, p_phone text, p_email text, p_address_bn text, p_admin_area_code text,
                                     p_tax_id text, p_terms_days integer, p_credit_limit numeric, p_bank_masked text, p_status text, p_expected_row_version integer,
                                     p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s procurement.supplier%rowtype; v_key text := procurement.fn_supplier_key(p_name_bn, p_phone); v_tax text := nullif(regexp_replace(coalesce(p_tax_id, ''), '[^0-9]', '', 'g'), '');
        v_dup uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.supplier.manage', iam.fn_my_company_resource(), true);
  select x.id into v_dup from procurement.supplier x
   where x.company_id = me.company_id and x.id is distinct from p_id and (x.dup_key = v_key or (v_tax is not null and x.tax_id = v_tax)) limit 1;
  if v_dup is not null then perform core.fn_raise('E_DUPLICATE_SUPPLIER', v_dup::text); end if;
  if p_bank_masked is not null and p_bank_masked !~ '^[•*xX]+[0-9]{2,4}$' then perform core.fn_raise('E_INVALID_ACTION', 'bank account must be stored masked (only the last digits)'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into procurement.supplier (company_id, code, name_bn, name_en, phone, email, address_bn, admin_area_code, tax_id, dup_key, payment_terms_days, credit_limit, bank_account_masked)
    values (me.company_id, upper(p_code), p_name_bn, p_name_en, p_phone, p_email, p_address_bn, p_admin_area_code, v_tax, v_key, coalesce(p_terms_days, 30), p_credit_limit, p_bank_masked)
    returning * into s;
  else
    select * into s from procurement.supplier where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'supplier'); end if;
    if s.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    update procurement.supplier set name_bn = p_name_bn, name_en = p_name_en, phone = p_phone, email = p_email, address_bn = p_address_bn, admin_area_code = p_admin_area_code,
           tax_id = v_tax, dup_key = v_key, payment_terms_days = coalesce(p_terms_days, payment_terms_days), credit_limit = p_credit_limit,
           bank_account_masked = coalesce(p_bank_masked, bank_account_masked), status = coalesce(p_status, status) where id = s.id returning * into s;
  end if;
  return jsonb_build_object('supplier_id', s.id, 'row_version', s.row_version);
end $$;

create function api.v1_suppliers(p_text text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('master.supplier.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'code', s.code, 'name_bn', s.name_bn, 'phone', s.phone, 'tax_id', s.tax_id, 'terms_days', s.payment_terms_days,
           'credit_limit', s.credit_limit, 'status', s.status, 'row_version', s.row_version) order by s.code)
     from procurement.supplier s where s.company_id = me.company_id and (p_text is null or s.name_bn ilike '%' || p_text || '%' or s.code ilike '%' || p_text || '%')), '[]'::jsonb);
end $$;

-- ================================================================ API: requisitions (F082)
create function api.v1_pr_save(p_id uuid, p_wing_id uuid, p_department_id uuid, p_needed_by date, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p procurement.pr%rowtype; l jsonb; n integer := 0;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.pr.create', iam.fn_resource(iam.fn_context_company(), p_wing_id, p_department_id), true);
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into procurement.pr (company_id, wing_id, department_id, requester_id, needed_by, reason) values (me.company_id, p_wing_id, p_department_id, me.person_id, p_needed_by, p_reason)
    returning * into p;
  else
    select * into p from procurement.pr where id = p_id and company_id = me.company_id for update;
    if not found or p.requester_id <> me.person_id then perform core.fn_raise('E_NOT_FOUND', 'requisition'); end if;
    if p.status <> 'draft' then perform core.fn_raise('E_INVALID_ACTION', 'only a draft is edited'); end if;
    delete from procurement.pr_line where pr_id = p.id;
    update procurement.pr set needed_by = p_needed_by, reason = p_reason where id = p.id;
  end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    if not inventory.fn_product_usable(me.company_id, (l ->> 'product_id')::uuid) then perform core.fn_raise('E_PRODUCT_ARCHIVED', l ->> 'product_id'); end if;
    insert into procurement.pr_line (company_id, pr_id, line_no, product_id, qty, est_price, note)
    values (me.company_id, p.id, n, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric, (l ->> 'est_price')::numeric, l ->> 'note');
  end loop;
  return jsonb_build_object('pr_id', p.id, 'lines', n);
end $$;

create function api.v1_pr_quote_add(p_pr_id uuid, p_supplier_id uuid, p_product_id uuid, p_unit_price numeric, p_lead_days integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('procurement.pr.create', iam.fn_my_company_resource(), true);
  if not exists (select 1 from procurement.pr p where p.id = p_pr_id and p.company_id = me.company_id and p.status in ('draft','pending_approval','approved')) then
    perform core.fn_raise('E_NOT_FOUND', 'open requisition');
  end if;
  if not exists (select 1 from procurement.pr_line l where l.pr_id = p_pr_id and l.product_id = p_product_id) then perform core.fn_raise('E_INVALID_ACTION', 'product not requested'); end if;
  if not exists (select 1 from procurement.supplier s where s.id = p_supplier_id and s.company_id = me.company_id and s.status = 'active') then
    perform core.fn_raise('E_NOT_FOUND', 'supplier');
  end if;
  perform set_config('mohona.change_reason', 'quotation', true);
  insert into procurement.pr_quote (company_id, pr_id, supplier_id, product_id, unit_price, lead_days, created_by)
  values (me.company_id, p_pr_id, p_supplier_id, p_product_id, p_unit_price, p_lead_days, me.person_id) returning id into v_id;
  return jsonb_build_object('quote_id', v_id);
end $$;

-- Quote comparison per requested product: cheapest first, best flagged.
create function api.v1_pr_compare(p_pr_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('procurement.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('line_no', l.line_no, 'product_id', l.product_id, 'qty', l.qty,
           'quotes', coalesce((select jsonb_agg(jsonb_build_object('quote_id', q.id, 'supplier_id', q.supplier_id, 'supplier', s.name_bn, 'unit_price', q.unit_price,
                                    'lead_days', q.lead_days, 'amount', round(q.unit_price * l.qty, 2), 'best', q.unit_price = (select min(q2.unit_price) from procurement.pr_quote q2 where q2.pr_id = l.pr_id and q2.product_id = l.product_id))
                                    order by q.unit_price, q.lead_days nulls last)
                                 from procurement.pr_quote q join procurement.supplier s on s.id = q.supplier_id where q.pr_id = l.pr_id and q.product_id = l.product_id), '[]'::jsonb))
           order by l.line_no)
     from procurement.pr_line l where l.pr_id = p_pr_id and l.company_id = me.company_id), '[]'::jsonb);
end $$;

-- submit | cancel. The approval engine refuses the requester as approver (maker-checker).
create function api.v1_pr_action(p_pr_id uuid, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p procurement.pr%rowtype; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.pr.create', iam.fn_my_company_resource(), true);
  select * into p from procurement.pr where id = p_pr_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'requisition'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'submit' and p.status = 'draft' then
    if p.requester_id <> me.person_id then perform core.fn_raise('E_FORBIDDEN', 'only the requester submits'); end if;
    update procurement.pr set status = 'pending_approval' where id = p.id;
    j := procurement.fn_submit(me.company_id, 'procurement.pr', p.id,
                               coalesce((select sum(l.qty * coalesce(l.est_price, 0)) from procurement.pr_line l where l.pr_id = p.id), 0),
                               iam.fn_resource(me.company_id, p.wing_id, p.department_id, null, null, p.requester_id));
    update procurement.pr set approval_request_id = (j ->> 'request_id')::uuid, number = core.fn_next_number(me.company_id, 'procurement.pr', p.id) where id = p.id;
  elsif p_action = 'cancel' and p.status in ('draft','pending_approval','approved') then
    update procurement.pr set status = 'cancelled' where id = p.id;
    update core.approval_request set status = 'cancelled', decided_at = clock_timestamp() where id = p.approval_request_id and status = 'pending';
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || p.status);
  end if;
  return jsonb_build_object('pr_id', p.id, 'status', (select x.status from procurement.pr x where x.id = p.id));
end $$;

-- ================================================================ API: purchase orders (F083, F072)
create function api.v1_po_create(p_supplier_id uuid, p_warehouse_id uuid, p_pr_id uuid, p_expected_date date, p_terms_days integer, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s procurement.supplier%rowtype; v_id uuid; l jsonb; n integer := 0; v_total numeric := 0; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.po.create', iam.fn_my_company_resource(), true);
  j := core.fn_idem_begin(me.company_id, 'v1_po_create', jsonb_build_object('s', p_supplier_id, 'w', p_warehouse_id, 'l', p_lines));
  if j is not null then return j; end if;
  select * into s from procurement.supplier where id = p_supplier_id and company_id = me.company_id;
  if not found or s.status <> 'active' then perform core.fn_raise('E_NOT_FOUND', 'active supplier'); end if;
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse_id and w.company_id = me.company_id and w.status = 'active') then perform core.fn_raise('E_NOT_FOUND', 'warehouse'); end if;
  if p_pr_id is not null and not exists (select 1 from procurement.pr p where p.id = p_pr_id and p.company_id = me.company_id and p.status = 'approved') then
    perform core.fn_raise('E_INVALID_ACTION', 'requisition is not approved');
  end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 200 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.po (company_id, supplier_id, warehouse_id, pr_id, expected_date, payment_terms_days, reason, created_by)
  values (me.company_id, s.id, p_warehouse_id, p_pr_id, p_expected_date, coalesce(p_terms_days, s.payment_terms_days), p_reason, me.person_id) returning id into v_id;
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    if not inventory.fn_product_usable(me.company_id, (l ->> 'product_id')::uuid) then perform core.fn_raise('E_PRODUCT_ARCHIVED', l ->> 'product_id'); end if;
    insert into procurement.po_line (company_id, po_id, line_no, product_id, qty, unit_price)
    values (me.company_id, v_id, n, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric, (l ->> 'unit_price')::numeric);
    v_total := v_total + (l ->> 'qty')::numeric * (l ->> 'unit_price')::numeric;
  end loop;
  update procurement.po set total = round(v_total, 2) where id = v_id;
  return core.fn_idem_finish(me.company_id, jsonb_build_object('po_id', v_id, 'total', round(v_total, 2), 'status', 'draft'));
end $$;

-- submit (approval engine; amount = total) | cancel (nothing received) | close (no more receipts)
create function api.v1_po_action(p_po_id uuid, p_action text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p procurement.po%rowtype; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.po.create', iam.fn_my_company_resource(), true);
  select * into p from procurement.po where id = p_po_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'purchase order'); end if;
  if p.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'submit' and p.status = 'draft' then
    update procurement.po set status = 'pending_approval', number = coalesce(number, core.fn_next_number(me.company_id, 'procurement.po', p.id)) where id = p.id;
    j := procurement.fn_submit(me.company_id, 'procurement.po', p.id, p.total, iam.fn_resource(me.company_id, p.wing_id, null, null, p.warehouse_id),
                               jsonb_build_object('supplier_id', p.supplier_id));
    update procurement.po set approval_request_id = (j ->> 'request_id')::uuid where id = p.id;
  elsif p_action = 'cancel' and p.status in ('draft','pending_approval','approved') and not exists (select 1 from procurement.po_line l where l.po_id = p.id and l.received_qty > 0) then
    update procurement.po set status = 'cancelled' where id = p.id;
    update core.approval_request set status = 'cancelled', decided_at = clock_timestamp() where id = p.approval_request_id and status = 'pending';
  elsif p_action = 'close' and p.status in ('approved','partially_received','received') then
    update procurement.po set status = 'closed' where id = p.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || p.status);
  end if;
  return jsonb_build_object('po_id', p.id, 'status', (select x.status from procurement.po x where x.id = p.id), 'number', (select x.number from procurement.po x where x.id = p.id));
end $$;

-- Change order after approval (F083): {"lines":[{"line_no":1,"qty":..,"unit_price":..},{"line_no":2,"cancel":true},{"product_id":..,"qty":..,"unit_price":..}],
-- "expected_date":..,"payment_terms_days":..}. Approved again before it applies; quantities never go below what is received.
create function api.v1_po_change(p_po_id uuid, p_changes jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p procurement.po%rowtype; l jsonb; pl procurement.po_line%rowtype; v_new_total numeric; v_id uuid; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.po.create', iam.fn_my_company_resource(), true);
  select * into p from procurement.po where id = p_po_id and company_id = me.company_id for update;
  if not found or p.status not in ('approved','partially_received') then perform core.fn_raise('E_INVALID_ACTION', 'change orders are for approved POs'); end if;
  for l in select * from jsonb_array_elements(coalesce(p_changes -> 'lines', '[]'::jsonb)) loop
    if (l ->> 'line_no') is not null then
      select * into pl from procurement.po_line where po_id = p.id and line_no = (l ->> 'line_no')::integer;
      if not found then perform core.fn_raise('E_NOT_FOUND', 'line ' || (l ->> 'line_no')); end if;
      if coalesce((l ->> 'cancel')::boolean, false) and pl.received_qty > 0 then perform core.fn_raise('E_INVALID_ACTION', 'a received line cannot be cancelled'); end if;
      if (l ->> 'qty')::numeric < pl.received_qty then perform core.fn_raise('E_INVALID_ACTION', 'quantity below received'); end if;
    elsif not inventory.fn_product_usable(me.company_id, (l ->> 'product_id')::uuid) then
      perform core.fn_raise('E_PRODUCT_ARCHIVED');
    end if;
  end loop;
  select round(coalesce(sum(case when c.cancel then 0 else coalesce(c.qty, x.qty) * coalesce(c.price, x.unit_price) end), 0), 2) into v_new_total
    from procurement.po_line x
    left join lateral (select (e ->> 'qty')::numeric qty, (e ->> 'unit_price')::numeric price, coalesce((e ->> 'cancel')::boolean, false) cancel
                         from jsonb_array_elements(coalesce(p_changes -> 'lines', '[]'::jsonb)) e where (e ->> 'line_no')::integer = x.line_no limit 1) c on true
   where x.po_id = p.id and x.status = 'open';
  v_new_total := v_new_total + coalesce((select sum((e ->> 'qty')::numeric * (e ->> 'unit_price')::numeric) from jsonb_array_elements(coalesce(p_changes -> 'lines', '[]'::jsonb)) e
                                          where (e ->> 'line_no') is null), 0);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.po_change (company_id, po_id, from_version, changes, reason, created_by) values (me.company_id, p.id, p.version, p_changes, p_reason, me.person_id)
  returning id into v_id;
  j := procurement.fn_submit(me.company_id, 'procurement.po_change', v_id, v_new_total, iam.fn_resource(me.company_id, p.wing_id, null, null, p.warehouse_id),
                             jsonb_build_object('po_id', p.id, 'new_total', v_new_total));
  update procurement.po_change set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  return jsonb_build_object('change_id', v_id, 'new_total', v_new_total, 'status', (select x.status from procurement.po_change x where x.id = v_id));
end $$;

create function api.v1_po_get(p_po_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; p procurement.po%rowtype;
begin
  select * into me from iam.fn_require('procurement.read', iam.fn_my_company_resource(), false);
  select * into p from procurement.po where id = p_po_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'purchase order'); end if;
  return to_jsonb(p) - 'company_id' || jsonb_build_object(
    'approval', (select r.status from core.approval_request r where r.id = p.approval_request_id),
    'supplier', (select s.name_bn from procurement.supplier s where s.id = p.supplier_id),
    'lines', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'line_no', l.line_no, 'product_id', l.product_id, 'sku', pr.sku, 'name_bn', pr.name_bn, 'qty', l.qty,
               'unit_price', l.unit_price, 'received_qty', l.received_qty, 'billed_qty', l.billed_qty, 'status', l.status) order by l.line_no)
             from procurement.po_line l join inventory.product pr on pr.id = l.product_id where l.po_id = p.id), '[]'::jsonb),
    'changes', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'from_version', c.from_version, 'status', c.status, 'changes', c.changes, 'reason', c.reason) order by c.created_at)
             from procurement.po_change c where c.po_id = p.id), '[]'::jsonb));
end $$;

create function api.v1_pos(p_status text default null, p_supplier_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('procurement.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'number', p.number, 'supplier', s.name_bn, 'status', p.status, 'total', p.total, 'expected_date', p.expected_date,
           'version', p.version, 'row_version', p.row_version) order by p.created_at desc)
     from procurement.po p join procurement.supplier s on s.id = p.supplier_id
    where p.company_id = me.company_id and (p_status is null or p.status = p_status) and (p_supplier_id is null or p.supplier_id = p_supplier_id)), '[]'::jsonb);
end $$;

-- ================================================================ API: goods receipt (F084, F072/OI-38)
-- lines: [{po_line_id, lot_no, supplier_lot, mfg_date, expiry_date, received, accepted, quarantine, rejected}]
-- Only an APPROVED PO is received. With procurement.grn.requires_qc, a receiver without the QC right sends everything to
-- quarantine (QC decides later through inventory quarantine).
create function api.v1_grn_post(p_po_id uuid, p_delivery_note text, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p procurement.po%rowtype; pl procurement.po_line%rowtype; l jsonb; v_grn uuid := gen_random_uuid(); n integer := 0; rec jsonb; j jsonb;
        v_over integer; v_qc boolean; acc numeric; qua numeric; rej numeric; rcv numeric; out jsonb := '[]'::jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into p from procurement.po where id = p_po_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'purchase order'); end if;
  select * into me from iam.fn_require('procurement.grn.receive', iam.fn_resource(p.company_id, null, null, null, p.warehouse_id), true);
  j := core.fn_idem_begin(me.company_id, 'v1_grn_post', jsonb_build_object('po', p_po_id, 'l', p_lines));
  if j is not null then return j; end if;
  select * into p from procurement.po where id = p_po_id for update;
  if p.status not in ('approved','partially_received') then perform core.fn_raise('E_PO_NOT_APPROVED', p.status); end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 200 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  v_over := config.fn_get_int(me.company_id, 'procurement.grn.over_receipt_bp');
  select not config.fn_get_bool(me.company_id, 'procurement.grn.requires_qc') or coalesce(d.allowed, false) into v_qc
    from iam.fn_authorize('procurement.qc.inspect', iam.fn_resource(me.company_id, null, null, null, p.warehouse_id), false) d;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.grn (id, company_id, number, po_id, warehouse_id, delivery_note, received_by, reason)
  values (v_grn, me.company_id, core.fn_next_number(me.company_id, 'procurement.grn', v_grn), p.id, p.warehouse_id, p_delivery_note, me.person_id, p_reason);
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    select * into pl from procurement.po_line where id = (l ->> 'po_line_id')::uuid and po_id = p.id for update;
    if not found or pl.status <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open PO line'); end if;
    rcv := (l ->> 'received')::numeric; acc := coalesce((l ->> 'accepted')::numeric, rcv); qua := coalesce((l ->> 'quarantine')::numeric, 0); rej := coalesce((l ->> 'rejected')::numeric, 0);
    if not v_qc then qua := acc + qua; acc := 0; end if;          -- no QC right: everything waits for inspection
    if rcv is null or rcv <= 0 or acc + qua + rej <> rcv then perform core.fn_raise('E_INVALID_ACTION', 'received = accepted + quarantine + rejected'); end if;
    if pl.received_qty + acc + qua > pl.qty * (1 + v_over / 10000.0) then perform core.fn_raise('E_OVER_RECEIPT', 'line ' || pl.line_no); end if;
    rec := inventory.fn_post_receipt(me.company_id, p.warehouse_id, pl.product_id, coalesce(l ->> 'lot_no', (select x.number from procurement.grn x where x.id = v_grn) || '-' || n),
                                     l ->> 'supplier_lot', (l ->> 'mfg_date')::date, (l ->> 'expiry_date')::date, acc, qua, rej, pl.unit_price, 'grn',
                                     'procurement.grn_line:' || v_grn || ':' || n, p_reason);
    insert into procurement.grn_line (company_id, grn_id, po_line_id, product_id, receipt_id, lot_id, received_qty, accepted_qty, quarantine_qty, rejected_qty, unit_price)
    values (me.company_id, v_grn, pl.id, pl.product_id, (rec ->> 'receipt_id')::uuid, (rec ->> 'lot_id')::uuid, rcv, acc, qua, rej, pl.unit_price);
    update procurement.po_line set received_qty = received_qty + acc + qua where id = pl.id;
    out := out || jsonb_build_array(jsonb_build_object('line', n, 'accepted', acc, 'quarantine', qua, 'rejected', rej, 'grni_value', round(acc * pl.unit_price, 2)));
  end loop;
  update procurement.po set status = case when not exists (select 1 from procurement.po_line x where x.po_id = p.id and x.status = 'open' and x.received_qty < x.qty)
                                          then 'received' else 'partially_received' end where id = p.id;
  return core.fn_idem_finish(me.company_id, jsonb_build_object('grn_id', v_grn, 'number', (select x.number from procurement.grn x where x.id = v_grn), 'lines', out));
end $$;

-- GRNI (F084): goods received (accepted, incl. released quarantine, minus returns) but not yet billed, per supplier.
create function api.v1_grni(p_supplier_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('procurement.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('supplier_id', x.supplier_id, 'supplier', x.name_bn, 'qty', x.q, 'value', x.v) order by x.name_bn) from (
    select po.supplier_id, s.name_bn, sum(procurement.fn_grn_line_usable(g) - procurement.fn_billed_qty(g.id)) q,
           round(sum((procurement.fn_grn_line_usable(g) - procurement.fn_billed_qty(g.id)) * g.unit_price), 2) v
      from procurement.grn_line g join procurement.grn gr on gr.id = g.grn_id join procurement.po po on po.id = gr.po_id join procurement.supplier s on s.id = po.supplier_id
     where g.company_id = me.company_id and (p_supplier_id is null or po.supplier_id = p_supplier_id)
     group by po.supplier_id, s.name_bn having sum(procurement.fn_grn_line_usable(g) - procurement.fn_billed_qty(g.id)) > 0) x), '[]'::jsonb);
end $$;

-- ================================================================ API: bills + three-way match (F085, F086)
-- lines: [{grn_line_id, qty, unit_price}]. Within tolerance -> posted; otherwise variance approval.
create function api.v1_bill_create(p_supplier_id uuid, p_invoice_no text, p_invoice_date date, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s procurement.supplier%rowtype; v_id uuid := gen_random_uuid(); l jsonb; g procurement.grn_line%rowtype; n integer := 0; v_total numeric := 0;
        v_key text := upper(regexp_replace(coalesce(p_invoice_no, ''), '[^A-Za-z0-9]', '', 'g')); v_ptol integer; v_qtol integer; var jsonb := '[]'::jsonb;
        v_open numeric; v_po uuid; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.bill.match', iam.fn_my_company_resource(), true);
  select * into s from procurement.supplier where id = p_supplier_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'supplier'); end if;
  if v_key = '' then perform core.fn_raise('E_INVALID_ACTION', 'supplier invoice number'); end if;
  if exists (select 1 from procurement.bill b where b.company_id = me.company_id and b.supplier_id = s.id and b.invoice_key = v_key and b.status <> 'cancelled') then
    perform core.fn_raise('E_DUPLICATE_INVOICE', p_invoice_no);
  end if;
  if p_invoice_date is null or p_invoice_date > current_date then perform core.fn_raise('E_INVALID_ACTION', 'invoice date'); end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 200 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  v_ptol := config.fn_get_int(me.company_id, 'procurement.match.price_tolerance_bp'); v_qtol := config.fn_get_int(me.company_id, 'procurement.match.qty_tolerance_bp');
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.bill (id, company_id, supplier_id, supplier_invoice_no, invoice_key, invoice_date, due_date, created_by)
  values (v_id, me.company_id, s.id, btrim(p_invoice_no), v_key, p_invoice_date, p_invoice_date + s.payment_terms_days, me.person_id);
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    select gl.* into g from procurement.grn_line gl join procurement.grn gr on gr.id = gl.grn_id join procurement.po po on po.id = gr.po_id
     where gl.id = (l ->> 'grn_line_id')::uuid and gl.company_id = me.company_id and po.supplier_id = s.id;
    if g.id is null then perform core.fn_raise('E_NOT_FOUND', 'GRN line of this supplier'); end if;
    v_open := procurement.fn_grn_line_usable(g) - procurement.fn_billed_qty(g.id);
    if (l ->> 'qty')::numeric > v_open * (1 + v_qtol / 10000.0) then
      var := var || jsonb_build_array(jsonb_build_object('line', n, 'kind', 'quantity', 'billed', (l ->> 'qty')::numeric, 'receivable', v_open));
    end if;
    if abs((l ->> 'unit_price')::numeric - g.unit_price) > g.unit_price * v_ptol / 10000.0 then
      var := var || jsonb_build_array(jsonb_build_object('line', n, 'kind', 'price', 'billed', (l ->> 'unit_price')::numeric, 'ordered', g.unit_price));
    end if;
    insert into procurement.bill_line (company_id, bill_id, line_no, grn_line_id, qty, unit_price, amount)
    values (me.company_id, v_id, n, g.id, (l ->> 'qty')::numeric, (l ->> 'unit_price')::numeric, round((l ->> 'qty')::numeric * (l ->> 'unit_price')::numeric, 2));
    v_total := v_total + round((l ->> 'qty')::numeric * (l ->> 'unit_price')::numeric, 2);
  end loop;
  update procurement.bill set total = v_total, match_report = jsonb_build_object('variances', var, 'checked_at', clock_timestamp()),
         number = core.fn_next_number(me.company_id, 'procurement.bill', v_id) where id = v_id;
  if jsonb_array_length(var) = 0 then
    update procurement.bill set status = 'posted', posted_at = clock_timestamp() where id = v_id;
    update procurement.po_line pl set billed_qty = pl.billed_qty + x.q
      from (select g2.po_line_id, sum(bl.qty) q from procurement.bill_line bl join procurement.grn_line g2 on g2.id = bl.grn_line_id where bl.bill_id = v_id group by g2.po_line_id) x
     where pl.id = x.po_line_id;
  else
    update procurement.bill set status = 'variance_pending' where id = v_id;
    j := procurement.fn_submit(me.company_id, 'procurement.bill_variance', v_id, v_total, iam.fn_resource(me.company_id), jsonb_build_object('variances', var));
    update procurement.bill set approval_request_id = (j ->> 'request_id')::uuid where id = v_id and status = 'variance_pending';
  end if;
  return jsonb_build_object('bill_id', v_id, 'total', v_total, 'variances', var, 'status', (select b.status from procurement.bill b where b.id = v_id));
end $$;

create function api.v1_bill_cancel(p_bill_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b procurement.bill%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.bill.match', iam.fn_my_company_resource(), true);
  select * into b from procurement.bill where id = p_bill_id and company_id = me.company_id for update;
  if not found or b.status not in ('draft','variance_pending') then perform core.fn_raise('E_INVALID_ACTION', 'only unposted bills are cancelled'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update procurement.bill set status = 'cancelled' where id = b.id;
  update core.approval_request set status = 'cancelled', decided_at = clock_timestamp() where id = b.approval_request_id and status = 'pending';
  return jsonb_build_object('bill_id', b.id, 'status', 'cancelled');
end $$;

-- ================================================================ API: payments + debit notes (F087, F088)
-- allocations: [{bill_id, amount}] — each within the bill's open payable (posted bills only; pending requests counted).
create function api.v1_supplier_payment(p_supplier_id uuid, p_method text, p_reference text, p_allocations jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a jsonb; v_total numeric := 0; v_id uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.ap.pay', iam.fn_my_company_resource(), true);
  j := core.fn_idem_begin(me.company_id, 'v1_supplier_payment', jsonb_build_object('s', p_supplier_id, 'a', p_allocations, 'r', p_reference));
  if j is not null then return j; end if;
  if coalesce(p_method, '') not in ('bank','cash') or jsonb_typeof(p_allocations) is distinct from 'array' or jsonb_array_length(p_allocations) not between 1 and 100 then
    perform core.fn_raise('E_INVALID_ACTION', 'method / allocations');
  end if;
  for a in select * from jsonb_array_elements(p_allocations) loop
    perform 1 from procurement.bill b where b.id = (a ->> 'bill_id')::uuid and b.company_id = me.company_id for update;
    if not exists (select 1 from procurement.bill b where b.id = (a ->> 'bill_id')::uuid and b.company_id = me.company_id and b.supplier_id = p_supplier_id and b.status = 'posted') then
      perform core.fn_raise('E_NOT_FOUND', 'posted bill of this supplier');
    end if;
    if coalesce((a ->> 'amount')::numeric, 0) <= 0 or (a ->> 'amount')::numeric > procurement.fn_bill_open_uncommitted((a ->> 'bill_id')::uuid) then
      perform core.fn_raise('E_OVERPAYMENT', a ->> 'bill_id');
    end if;
    v_total := v_total + (a ->> 'amount')::numeric;
  end loop;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.payment (id, company_id, number, supplier_id, method, amount, reference, allocations, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'procurement.payment', v_id), p_supplier_id, p_method, v_total, p_reference, p_allocations, me.person_id);
  j := procurement.fn_submit(me.company_id, 'procurement.payment', v_id, v_total, iam.fn_resource(me.company_id), jsonb_build_object('supplier_id', p_supplier_id));
  update procurement.payment set approval_request_id = (j ->> 'request_id')::uuid where id = v_id and status = 'pending_approval';
  return core.fn_idem_finish(me.company_id, jsonb_build_object('payment_id', v_id, 'amount', v_total, 'status', (select x.status from procurement.payment x where x.id = v_id)));
end $$;

-- kind return (stock goes back; amount defaults to qty x GRN price) | price (correction on a posted bill)
create function api.v1_debit_note(p_kind text, p_grn_line_id uuid, p_bill_id uuid, p_qty numeric, p_amount numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; g procurement.grn_line%rowtype; v_sup uuid; v_amount numeric; v_id uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('procurement.debit.create', iam.fn_my_company_resource(), true);
  select gl.* into g from procurement.grn_line gl where gl.id = p_grn_line_id and gl.company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'GRN line'); end if;
  select po.supplier_id into v_sup from procurement.grn gr join procurement.po po on po.id = gr.po_id where gr.id = g.grn_id;
  if p_bill_id is not null and not exists (select 1 from procurement.bill b join procurement.bill_line bl on bl.bill_id = b.id
                                           where b.id = p_bill_id and b.status = 'posted' and bl.grn_line_id = g.id) then
    perform core.fn_raise('E_INVALID_ACTION', 'the bill must be posted and contain this GRN line');
  end if;
  if p_kind = 'return' then
    if coalesce(p_qty, 0) <= 0 or p_qty > procurement.fn_grn_line_usable(g)
                                    - coalesce((select sum(d.qty) from procurement.debit_note d where d.grn_line_id = g.id and d.status = 'pending_approval'), 0) then
      perform core.fn_raise('E_INVALID_ACTION', 'return more than received and accepted');
    end if;
    v_amount := coalesce(p_amount, round(p_qty * g.unit_price, 2));
  elsif p_kind = 'price' then
    if p_bill_id is null then perform core.fn_raise('E_INVALID_ACTION', 'a price correction names its bill'); end if;
    v_amount := p_amount;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_kind);
  end if;
  if coalesce(v_amount, 0) <= 0 or (p_bill_id is not null and v_amount > procurement.fn_bill_open_uncommitted(p_bill_id)) then
    perform core.fn_raise('E_OVERPAYMENT', 'debit note above the open payable');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.debit_note (id, company_id, number, supplier_id, kind, grn_line_id, bill_id, qty, amount, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'procurement.debit_note', v_id), v_sup, p_kind, g.id, p_bill_id,
          case when p_kind = 'return' then p_qty end, v_amount, p_reason, me.person_id);
  j := procurement.fn_submit(me.company_id, 'procurement.debit_note', v_id, v_amount, iam.fn_resource(me.company_id), null);
  update procurement.debit_note set approval_request_id = (j ->> 'request_id')::uuid where id = v_id and status = 'pending_approval';
  return jsonb_build_object('debit_note_id', v_id, 'amount', v_amount, 'status', (select x.status from procurement.debit_note x where x.id = v_id));
end $$;

-- ================================================================ API: reports (F089, F090)
create function api.v1_supplier_dues(p_as_of date default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d date := coalesce(p_as_of, current_date);
begin
  select * into me from iam.fn_require('procurement.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('supplier_id', x.supplier_id, 'supplier', x.name_bn, 'open', x.open_total, 'current', x.b0, 'd1_30', x.b1,
                                                       'd31_60', x.b2, 'd61_90', x.b3, 'd90_plus', x.b4, 'bills', x.bills) order by x.open_total desc) from (
    select b.supplier_id, s.name_bn, sum(o.open) open_total,
           sum(o.open) filter (where d <= b.due_date) b0, sum(o.open) filter (where d - b.due_date between 1 and 30) b1,
           sum(o.open) filter (where d - b.due_date between 31 and 60) b2, sum(o.open) filter (where d - b.due_date between 61 and 90) b3,
           sum(o.open) filter (where d - b.due_date > 90) b4,
           jsonb_agg(jsonb_build_object('bill_id', b.id, 'number', b.number, 'invoice', b.supplier_invoice_no, 'due_date', b.due_date, 'open', o.open,
                                        'days_overdue', greatest(d - b.due_date, 0)) order by b.due_date) bills
      from procurement.bill b join procurement.supplier s on s.id = b.supplier_id
      cross join lateral (select procurement.fn_bill_open(b.id) open) o
     where b.company_id = me.company_id and b.status = 'posted' and o.open > 0
     group by b.supplier_id, s.name_bn) x), '[]'::jsonb);
end $$;

create function api.v1_supplier_performance(p_from date default null, p_to date default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, current_date - 365); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('procurement.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('supplier_id', s.id, 'supplier', s.name_bn, 'grns', k.grns, 'on_time_pct', k.on_time_pct, 'rejection_pct', k.rej_pct,
                                                       'price_variance_bills', k.var_bills) order by s.name_bn)
     from procurement.supplier s
     cross join lateral (
       select count(distinct gr.id) grns,
              round(100.0 * count(distinct gr.id) filter (where po.expected_date is null or gr.received_at::date <= po.expected_date) / nullif(count(distinct gr.id), 0), 1) on_time_pct,
              round(100.0 * sum(gl.rejected_qty) / nullif(sum(gl.received_qty), 0), 1) rej_pct,
              (select count(*) from procurement.bill b where b.supplier_id = s.id and b.invoice_date between f and t
                 and exists (select 1 from jsonb_array_elements(b.match_report -> 'variances') v where v ->> 'kind' = 'price')) var_bills
         from procurement.po po join procurement.grn gr on gr.po_id = po.id join procurement.grn_line gl on gl.grn_id = gr.id
        where po.supplier_id = s.id and gr.received_at::date between f and t) k
    where s.company_id = me.company_id and k.grns > 0), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array[
      'api.v1_supplier_save(uuid, text, text, text, text, text, text, text, text, integer, numeric, text, text, integer, text)', 'api.v1_suppliers(text)',
      'api.v1_pr_save(uuid, uuid, uuid, date, jsonb, text)', 'api.v1_pr_quote_add(uuid, uuid, uuid, numeric, integer)', 'api.v1_pr_compare(uuid)',
      'api.v1_pr_action(uuid, text, text)', 'api.v1_po_create(uuid, uuid, uuid, date, integer, jsonb, text)', 'api.v1_po_action(uuid, text, integer, text)',
      'api.v1_po_change(uuid, jsonb, text)', 'api.v1_po_get(uuid)', 'api.v1_pos(text, uuid)', 'api.v1_grn_post(uuid, text, jsonb, text)', 'api.v1_grni(uuid)',
      'api.v1_bill_create(uuid, text, date, jsonb, text)', 'api.v1_bill_cancel(uuid, text)', 'api.v1_supplier_payment(uuid, text, text, jsonb, text)',
      'api.v1_debit_note(text, uuid, uuid, numeric, numeric, text)', 'api.v1_supplier_dues(date)', 'api.v1_supplier_performance(date, date)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

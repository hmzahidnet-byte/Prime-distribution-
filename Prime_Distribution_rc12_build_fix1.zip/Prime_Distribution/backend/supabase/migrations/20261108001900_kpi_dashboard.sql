-- 20261108001900_kpi_dashboard.sql  (S20)
-- KPI dashboard (blueprint KPI_DASHBOARD MOS-F153-051..060):
--   051 catalog: platform + company KPIs with formula, unit, owner and the permission an aggregate needs; live measures
--       are computed only for callers holding that permission at the asked scope (company or one wing)
--   052 visibility per position (company rows; platform default list); factory P&L only for the positions in
--       access.factory_pnl.positions (OWN-02) — the Chairman always sees everything
--   053 style: chart type / size / shape / SEMANTIC colour only (raw hex impossible), negative states always "bad"
--   054 periods: today .. this year, custom (<= 366 days); stored values of a closed month never change
--   055 drilldown: only records the caller is authorised to see (server filters every row)
--   056 product breakdown: every active product appears, zero when it has no value (nothing suppressed)
--   057 refresh: per-KPI bounded refresh (60..3600 s) with a server cache keyed by person + authz_epoch, so any
--       permission change makes the old figures unreachable at once
--   058 ads: at most three slots, placed below approvals (layout rule), media per slot, the app shows two at a time
--   059 dashboard layout: design layouts for dashboard.* must keep the approval (safety) widget
--   060 export: figures the caller may not see are redacted, every export logged; image/PDF/print are made on the device
-- Business modules (sales, stock, finance) feed stored values or add live measures in their own steps.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ tables
create table report.kpi_catalog (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid references core.company(id),          -- null = platform KPI
  code                text not null check (code ~ '^[a-z][a-z0-9_]*\.[a-z0-9_]{2,40}$'),
  name_bn             text not null check (length(btrim(name_bn)) > 0),
  formula_bn          text not null check (length(btrim(formula_bn)) > 0),
  unit                text not null check (unit in ('money','count','percent','qty')),
  source              text not null check (source in ('live','stored')),
  measure             text check (measure in ('approvals_pending','forms_submitted','headcount','logins_failed')),
  agg                 text not null default 'sum' check (agg in ('sum','avg','last')),
  required_permission text not null references iam.permission_catalog(code),
  owner_position      text,
  default_positions   text[],                                    -- null = every position holding the permission
  is_factory_pnl      boolean not null default false,
  has_products        boolean not null default false,
  refresh_seconds     integer not null default 300 check (refresh_seconds between 60 and 3600),
  sort_order          integer not null default 0,
  created_at          timestamptz not null default clock_timestamp(),
  check ((source = 'live') = (measure is not null)),
  check (company_id is null or (source = 'stored' and code ~ '^custom\.'))
);
create unique index kpi_catalog_code on report.kpi_catalog (company_id, code) nulls not distinct;
create trigger trg_kpi_catalog_nodel before delete on report.kpi_catalog for each row execute function core.fn_deny_delete();
create trigger trg_kpi_catalog_audit after insert or update on report.kpi_catalog for each row execute function audit.fn_row_change();

create table report.kpi_visibility (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  kpi_code       text not null,
  position_code  text,
  visible        boolean not null,
  version        integer not null check (version >= 1),
  status         text not null default 'active' check (status in ('active','superseded')),
  set_by         uuid, set_at timestamptz not null default clock_timestamp(),
  reason         text not null check (length(btrim(reason)) > 0),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index kpi_visibility_one_active on report.kpi_visibility (company_id, kpi_code, position_code) nulls not distinct where status = 'active';
create trigger trg_kpi_visibility_guard before update on report.kpi_visibility for each row execute function config.fn_history_only_supersede();
create trigger trg_kpi_visibility_nodel before delete on report.kpi_visibility for each row execute function core.fn_deny_delete();
create trigger trg_kpi_visibility_audit after insert or update on report.kpi_visibility for each row execute function audit.fn_row_change();

create table report.kpi_style (
  id         uuid primary key default gen_random_uuid(),
  company_id uuid not null references core.company(id),
  kpi_code   text not null,
  style      jsonb not null,
  version    integer not null check (version >= 1),
  status     text not null default 'active' check (status in ('active','superseded')),
  set_by     uuid, set_at timestamptz not null default clock_timestamp(),
  reason     text not null check (length(btrim(reason)) > 0)
);
create unique index kpi_style_one_active on report.kpi_style (company_id, kpi_code) where status = 'active';
create trigger trg_kpi_style_guard before update on report.kpi_style for each row execute function config.fn_history_only_supersede();
create trigger trg_kpi_style_nodel before delete on report.kpi_style for each row execute function core.fn_deny_delete();
create trigger trg_kpi_style_audit after insert or update on report.kpi_style for each row execute function audit.fn_row_change();

create table report.kpi_product (
  company_id   uuid not null references core.company(id),
  product_key  text not null check (product_key ~ '^[A-Za-z0-9_.-]{1,60}$'),
  name_bn      text not null check (length(btrim(name_bn)) > 0),
  image_path   text check (image_path is null or image_path ~ '^[0-9a-f-]{36}/[A-Za-z0-9_./-]{1,200}$'),
  sort_order   integer not null default 0,
  is_active    boolean not null default true,
  updated_at   timestamptz not null default clock_timestamp(),
  row_version  integer not null default 1,
  primary key (company_id, product_key),
  check (image_path is null or image_path like company_id::text || '/%')
);
create trigger trg_kpi_product_touch before update on report.kpi_product for each row execute function core.fn_touch_row();
create trigger trg_kpi_product_nodel before delete on report.kpi_product for each row execute function core.fn_deny_delete();
create trigger trg_kpi_product_audit after insert or update on report.kpi_product for each row execute function audit.fn_row_change();

create table report.period_close (
  company_id  uuid not null references core.company(id),
  month       date not null check (month = date_trunc('month', month)::date),
  closed_at   timestamptz not null default clock_timestamp(),
  closed_by   uuid,
  reason      text not null check (length(btrim(reason)) > 0),
  primary key (company_id, month)
);
create trigger trg_period_close_no_mutation before update or delete on report.period_close for each row execute function core.fn_deny_mutation();
create trigger trg_period_close_audit after insert on report.period_close for each row execute function audit.fn_row_change();

create table report.kpi_value (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  kpi_code     text not null,
  wing_id      uuid,
  product_key  text,
  period_date  date not null,
  value        numeric(18,4) not null,
  source       text not null default 'manual' check (source ~ '^[a-z_]{2,30}$'),
  recorded_by  uuid,
  recorded_at  timestamptz not null default clock_timestamp(),
  updated_at   timestamptz not null default clock_timestamp(),
  row_version  integer not null default 1,
  foreign key (wing_id, company_id) references core.wing (id, company_id),
  foreign key (company_id, product_key) references report.kpi_product (company_id, product_key)
);
create unique index kpi_value_one on report.kpi_value (company_id, kpi_code, wing_id, product_key, period_date) nulls not distinct;
create index kpi_value_range on report.kpi_value (company_id, kpi_code, period_date);
-- A closed month is final: no insert, change or move into/out of it (F054).
create function report.fn_kpi_value_guard() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if exists (select 1 from report.period_close c where c.company_id = new.company_id and c.month = date_trunc('month', new.period_date)::date)
     or (tg_op = 'UPDATE' and exists (select 1 from report.period_close c where c.company_id = old.company_id and c.month = date_trunc('month', old.period_date)::date)) then
    raise exception 'E_PERIOD_CLOSED: % is closed', to_char(new.period_date, 'YYYY-MM') using errcode = 'P0001';
  end if;
  if tg_op = 'UPDATE' and (new.company_id <> old.company_id or new.kpi_code <> old.kpi_code) then
    raise exception 'E_IMMUTABLE: value identity is fixed' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_kpi_value_guard before insert or update on report.kpi_value for each row execute function report.fn_kpi_value_guard();
create trigger trg_kpi_value_touch before update on report.kpi_value for each row execute function core.fn_touch_row();
create trigger trg_kpi_value_nodel before delete on report.kpi_value for each row execute function core.fn_deny_delete();
create trigger trg_kpi_value_audit after insert or update on report.kpi_value for each row execute function audit.fn_row_change();

-- Server cache (F057): one row per person + KPI + query; valid only for the same authz_epoch and within refresh_seconds.
create table report.kpi_cache (
  company_id   uuid not null references core.company(id),
  kpi_code     text not null,
  cache_key    text not null,
  person_id    uuid not null references core.person(id),
  authz_epoch  integer not null,
  payload      jsonb not null,
  computed_at  timestamptz not null default clock_timestamp(),
  primary key (company_id, kpi_code, cache_key, person_id)
);

create table report.export_log (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  person_id     uuid not null references core.person(id),
  position_code text,
  kpi_codes     text[] not null,
  redacted      text[] not null default array[]::text[],
  period_from   date not null,
  period_to     date not null,
  format        text not null check (format in ('image','pdf','print','data')),
  created_at    timestamptz not null default clock_timestamp()
);
create trigger trg_report_export_log_no_mutation before update or delete on report.export_log for each row execute function core.fn_deny_mutation();
create trigger trg_report_export_log_audit after insert on report.export_log for each row execute function audit.fn_row_change();

-- Advertisement media per slot (F058). Images only (company storage path); no links, no scripts.
create table design.ad_media (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  slot         integer not null check (slot between 1 and 3),
  title_bn     text not null check (length(btrim(title_bn)) between 1 and 80),
  image_path   text not null,
  valid_until  timestamptz,
  status       text not null default 'active' check (status in ('active','superseded')),
  set_by       uuid, set_at timestamptz not null default clock_timestamp(),
  reason       text not null check (length(btrim(reason)) > 0),
  check (image_path like company_id::text || '/%' and image_path ~ '^[0-9a-f-]{36}/[A-Za-z0-9_./-]{1,200}$')
);
create unique index ad_media_one_active on design.ad_media (company_id, slot) where status = 'active';
create trigger trg_ad_media_guard before update on design.ad_media for each row execute function config.fn_history_only_supersede();
create trigger trg_ad_media_nodel before delete on design.ad_media for each row execute function core.fn_deny_delete();
create trigger trg_ad_media_audit after insert or update on design.ad_media for each row execute function audit.fn_row_change();

select core.fn_apply_rls('report', 'kpi_catalog');
select core.fn_apply_rls('report', 'kpi_visibility');
select core.fn_apply_rls('report', 'kpi_style');
select core.fn_apply_rls('report', 'kpi_product');
select core.fn_apply_rls('report', 'period_close');
select core.fn_apply_rls('report', 'kpi_value');
select core.fn_apply_rls('report', 'kpi_cache');
select core.fn_apply_rls('report', 'export_log');
select core.fn_apply_rls('design', 'ad_media');

-- ================================================================ permissions, module, seeds
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('kpi.dashboard.read',  'kpi', 'KPI-ড্যাশবোর্ড দেখা', 'read', false, true, array['COMPANY','WING'], 'active', 1300),
  ('kpi.catalog.manage',  'kpi', 'KPI-তালিকা, দৃশ্যমানতা, স্টাইল, পণ্য', 'admin', true, false, array['COMPANY'], 'active', 1301),
  ('kpi.value.record',    'kpi', 'KPI-মান লেখা', 'write', true, false, array['COMPANY','WING'], 'active', 1302),
  ('kpi.export',          'kpi', 'KPI ছবি/PDF/প্রিন্ট', 'export', true, false, array['COMPANY','WING'], 'active', 1303),
  ('kpi.period.close',    'kpi', 'KPI-মাস বন্ধ', 'admin', true, false, array['COMPANY'], 'active', 1304);
update iam.permission_catalog set status = 'active' where code = 'design.ads.manage';
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'kpi.dashboard.read', 'allow', case when t.code in ('WING_HEAD','PROD_SUPERVISOR') then 'WING' else 'COMPANY' end
  from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN','EMPLOYEE_SELF','FIELD_SALES','CASHIER','STOREKEEPER');
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('MD', 'kpi.export', 'allow', 'COMPANY'), ('FIN_MANAGER', 'kpi.value.record', 'allow', 'COMPANY');
select iam.fn_backfill_template_rules(null);
update config.module_catalog set permission_modules = array['kpi'] where code = 'kpi';
select config.fn_make_module_available('kpi');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('design.ads.visible_max', 'design', 'int', '2', 1, 2, null, 'একসাথে দেখানো বিজ্ঞাপন (সর্বোচ্চ ২)', 'MOS-F153-058', false, 960),
  ('kpi.custom_range.max_days', 'kpi', 'int', '366', 7, 1100, null, 'নিজস্ব তারিখ-পরিসরের সর্বোচ্চ দিন', 'MOS-F153-054', false, 970);

insert into report.kpi_catalog (code, name_bn, formula_bn, unit, source, measure, agg, required_permission, owner_position, default_positions, is_factory_pnl, has_products, refresh_seconds, sort_order) values
  ('approvals.pending', 'অপেক্ষমাণ অনুমোদন', 'এখন অপেক্ষমাণ অনুমোদন-অনুরোধের সংখ্যা', 'count', 'live', 'approvals_pending', 'last', 'approval.inbox.read', 'MD', null, false, false, 60, 10),
  ('forms.submitted', 'জমা-দেওয়া ফর্ম', 'সময়-পরিসরে জমা হওয়া ফর্ম', 'count', 'live', 'forms_submitted', 'sum', 'forms.submission.read', 'MD', null, false, false, 300, 20),
  ('hr.headcount', 'কর্মী-সংখ্যা', 'সক্রিয় সদস্যপদ', 'count', 'live', 'headcount', 'last', 'iam.hierarchy.read', 'HR_OFFICER', null, false, false, 3600, 30),
  ('security.failed_logins', 'ব্যর্থ লগইন', 'সময়-পরিসরে ব্যর্থ/লক PIN-লগইন', 'count', 'live', 'logins_failed', 'sum', 'audit.read', 'MD', null, false, false, 300, 40),
  ('sales.amount', 'বিক্রয়', 'চালানের মোট টাকা (বিক্রয়-মডিউল থেকে)', 'money', 'stored', null, 'sum', 'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER','WING_HEAD'], false, true, 300, 50),
  ('cash.position', 'নগদ অবস্থান', 'দিনশেষের নগদ + ব্যাংক', 'money', 'stored', null, 'last', 'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 600, 60),
  ('stock.value', 'মজুদের মূল্য', 'মজুদ × গড় খরচ', 'money', 'stored', null, 'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','FIN_MANAGER','WING_HEAD'], false, true, 900, 70),
  ('sales.gross_margin', 'মোট মুনাফার হার', '(বিক্রয় − বিক্রীত পণ্যের খরচ) ÷ বিক্রয়', 'percent', 'stored', null, 'avg', 'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 900, 80),
  ('mfg.factory_pnl', 'ফ্যাক্টরি লাভ-ক্ষতি', 'কারখানার আয় − উৎপাদন-খরচ − পরিচালন-খরচ', 'money', 'stored', null, 'sum', 'kpi.dashboard.read', 'MD', null, true, false, 900, 90);

create or replace function design.fn_layout_report(p jsonb, p_ads_required integer, p_approval_max_row integer) returns jsonb
language plpgsql stable set search_path = pg_catalog as $$
declare errs text[] := array[]::text[]; warns text[] := array[]::text[]; bp text; b jsonb; w jsonb; k text; cols integer; ids text[];
        cells text[]; cell text; i integer; j integer; n_ads integer; v_type text; appr_bottom integer; min_ad_y integer;
        c_types constant text[] := array['kpi','shortcut','list','chart','approval','ad_slot','text','calendar'];
begin
  if p is null or jsonb_typeof(p) <> 'object' then return jsonb_build_object('ok', false, 'errors', jsonb_build_array('layout must be an object'), 'warnings', '[]'::jsonb); end if;
  if config.fn_form_has_unsafe(p) then errs := errs || 'markup or script text is not allowed'::text; end if;
  for k in select jsonb_object_keys(p) loop
    if k <> 'breakpoints' then errs := errs || ('unknown key ' || k); end if;      -- no grant / permission / rule field can exist
  end loop;
  if jsonb_typeof(p -> 'breakpoints') is distinct from 'object' or not (p -> 'breakpoints') ? 'phone' then
    return jsonb_build_object('ok', false, 'errors', to_jsonb(errs || 'breakpoints.phone is required'::text), 'warnings', '[]'::jsonb);
  end if;
  for bp, b in select * from jsonb_each(p -> 'breakpoints') loop
    if bp not in ('phone','tablet','landscape') then errs := errs || ('unknown breakpoint ' || bp); continue; end if;
    if jsonb_typeof(b) <> 'object' or exists (select 1 from jsonb_object_keys(b) x where x not in ('columns','widgets')) then
      errs := errs || (bp || ': only columns and widgets'); continue;
    end if;
    cols := case when jsonb_typeof(b -> 'columns') = 'number' then (b ->> 'columns')::integer end;
    if cols is null or (bp = 'phone' and cols not between 2 and 6) or (bp <> 'phone' and cols not between 4 and 12) then
      errs := errs || (bp || ': columns out of range'); continue;
    end if;
    if jsonb_typeof(b -> 'widgets') is distinct from 'array' or jsonb_array_length(b -> 'widgets') not between 1 and 60 then
      errs := errs || (bp || ': 1..60 widgets'); continue;
    end if;
    ids := array[]::text[]; cells := array[]::text[]; n_ads := 0; appr_bottom := 0; min_ad_y := null;
    for w in select * from jsonb_array_elements(b -> 'widgets') loop
      if jsonb_typeof(w) <> 'object' or exists (select 1 from jsonb_object_keys(w) x where x not in ('id','type','x','y','w','h','binding','title_bn')) then
        errs := errs || (bp || ': widget has unknown fields'); continue;
      end if;
      v_type := w ->> 'type';
      if coalesce(w ->> 'id', '') !~ '^[a-z][a-z0-9_]{0,30}$' or (w ->> 'id') = any (ids) then errs := errs || (bp || ': bad or duplicate widget id'); continue; end if;
      ids := ids || (w ->> 'id');
      if not (coalesce(v_type, '') = any (c_types)) then errs := errs || (bp || ': unknown widget type ' || coalesce(v_type, '?')); continue; end if;
      if jsonb_typeof(w -> 'x') <> 'number' or jsonb_typeof(w -> 'y') <> 'number' or jsonb_typeof(w -> 'w') <> 'number' or jsonb_typeof(w -> 'h') <> 'number'
         or (w ->> 'x')::numeric <> trunc((w ->> 'x')::numeric) or (w ->> 'y')::numeric <> trunc((w ->> 'y')::numeric)
         or (w ->> 'w')::numeric <> trunc((w ->> 'w')::numeric) or (w ->> 'h')::numeric <> trunc((w ->> 'h')::numeric) then
        errs := errs || (bp || ': ' || (w ->> 'id') || ' must snap to whole cells'); continue;
      end if;
      if (w ->> 'x')::integer < 0 or (w ->> 'y')::integer not between 0 and 100 or (w ->> 'w')::integer < 1 or (w ->> 'h')::integer not between 1 and 6
         or (w ->> 'x')::integer + (w ->> 'w')::integer > cols then
        errs := errs || (bp || ': ' || (w ->> 'id') || ' outside the grid'); continue;
      end if;
      if v_type in ('kpi','list','chart') and coalesce(w ->> 'binding', '') !~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,3}$' then
        errs := errs || (bp || ': ' || (w ->> 'id') || ' needs a data binding'); continue;
      end if;
      if v_type = 'ad_slot' then n_ads := n_ads + 1; min_ad_y := least(coalesce(min_ad_y, (w ->> 'y')::integer), (w ->> 'y')::integer); end if;
      if v_type = 'approval' then
        appr_bottom := greatest(appr_bottom, (w ->> 'y')::integer + (w ->> 'h')::integer);
        if (w ->> 'y')::integer + (w ->> 'h')::integer > p_approval_max_row then
          errs := errs || (bp || ': approval controls must sit within the first ' || p_approval_max_row || ' rows');
        end if;
        if (w ->> 'w')::integer * 2 < cols then errs := errs || (bp || ': approval controls need at least half the width'); end if;
      end if;
      for i in 0 .. (w ->> 'w')::integer - 1 loop
        for j in 0 .. (w ->> 'h')::integer - 1 loop
          cell := ((w ->> 'x')::integer + i) || ':' || ((w ->> 'y')::integer + j);
          if cell = any (cells) then errs := errs || (bp || ': widgets overlap at ' || cell); exit; end if;
          cells := cells || cell;
        end loop;
      end loop;
    end loop;
    if n_ads < p_ads_required then errs := errs || (bp || ': ' || p_ads_required || ' advertisement slot(s) are mandatory'); end if;
    if n_ads > 3 then errs := errs || (bp || ': at most 3 advertisement slots'); end if;                     -- S20 F058
    if min_ad_y is not null and min_ad_y < appr_bottom then errs := errs || (bp || ': advertisements must sit below the approval controls'); end if;
  end loop;
  if not (p -> 'breakpoints') ? 'tablet' then warns := warns || 'no tablet layout: the phone layout is stretched'::text; end if;
  return jsonb_build_object('ok', cardinality(errs) = 0, 'errors', to_jsonb(errs), 'warnings', to_jsonb(warns));
end $$;

update config.setting_definition
   set allowed_values = '["home","tasks","reports","search","scan","forms","dashboard","more"]'::jsonb
 where key = 'ui.nav.bottom_tabs';

-- Preset bindings now name catalog KPIs (binding = 'kpi.' || kpi code).
update design.layout_preset set layout = replace(replace(replace(replace(replace(layout::text,
  '"kpi.sales_today"', '"kpi.sales.amount"'), '"kpi.cash_position"', '"kpi.cash.position"'), '"kpi.stock_value"', '"kpi.stock.value"'),
  '"kpi.sales_trend"', '"kpi.sales.amount"'), '"kpi.gross_margin"', '"kpi.sales.gross_margin"')::jsonb;

-- Dashboards keep their safety widget (F059): every breakpoint of a dashboard.* layout shows the approval panel.
create function design.fn_report_with_screen(p_company uuid, p_screen text, p_layout jsonb) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare rep jsonb := design.fn_layout_report_for(p_company, p_layout); extra text[] := array[]::text[]; bp text; b jsonb;
begin
  if p_screen like 'dashboard.%' and jsonb_typeof(p_layout -> 'breakpoints') = 'object' then
    for bp, b in select * from jsonb_each(p_layout -> 'breakpoints') loop
      if not exists (select 1 from jsonb_array_elements(coalesce(b -> 'widgets', '[]'::jsonb)) w where w ->> 'type' = 'approval') then
        extra := extra || (bp || ': a dashboard must keep the approval (safety) widget');
      end if;
    end loop;
  end if;
  if cardinality(extra) = 0 then return rep; end if;
  return rep || jsonb_build_object('ok', false, 'errors', coalesce(rep -> 'errors', '[]'::jsonb) || to_jsonb(extra));
end $$;

-- S20: layout save/publish now include the screen rules (dashboard safety widget).
create or replace function api.v1_design_layout_save(p_screen_key text, p_layout jsonb, p_from_preset text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_layout jsonb := p_layout; v integer; rep jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), true);
  if coalesce(p_screen_key, '') !~ '^(home|wing\.[a-z_]{2,30}|dashboard\.[a-z_]{2,30}|module\.[a-z_]{2,30})$' then
    perform core.fn_raise('E_DESIGN_LAYOUT', 'screen key');
  end if;
  if v_layout is null then
    select x.layout into v_layout from design.layout_preset x where x.code = p_from_preset;
    if v_layout is null then perform core.fn_raise('E_NOT_FOUND', 'preset'); end if;
  end if;
  if length(v_layout::text) > 65536 then perform core.fn_raise('E_DESIGN_LAYOUT', 'layout larger than 64 KB'); end if;
  rep := design.fn_report_with_screen(me.company_id, p_screen_key, v_layout);
  perform set_config('mohona.change_reason', p_reason, true);
  perform pg_advisory_xact_lock(hashtext(me.company_id::text || p_screen_key));
  v := coalesce((select max(x.version) from design.screen_layout x where x.company_id = me.company_id and x.screen_key = p_screen_key), 0) + 1;
  insert into design.screen_layout (company_id, screen_key, version, layout, report, from_preset, reason, created_by)
  values (me.company_id, p_screen_key, v, v_layout, rep, p_from_preset, p_reason, me.person_id);
  return jsonb_build_object('screen_key', p_screen_key, 'version', v, 'report', rep);
end $$;

create or replace function api.v1_design_layout_publish(p_screen_key text, p_version integer, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; l design.screen_layout%rowtype; rep jsonb; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.publish', iam.fn_my_company_resource(), true);
  perform pg_advisory_xact_lock(hashtext(me.company_id::text || coalesce(p_screen_key, '')));
  select * into l from design.screen_layout where company_id = me.company_id and screen_key = p_screen_key and version = p_version;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'layout version'); end if;
  if not ((p_action = 'publish' and l.status = 'draft') or (p_action = 'rollback' and l.status = 'superseded')) then
    perform core.fn_raise('E_INVALID_ACTION', coalesce(p_action, '?') || ' from ' || l.status);
  end if;
  rep := design.fn_report_with_screen(me.company_id, l.screen_key, l.layout);
  if not (rep ->> 'ok')::boolean then perform core.fn_raise('E_DESIGN_LAYOUT', coalesce(rep -> 'errors' ->> 0, 'validation failed')); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'publish' and config.fn_get_bool(me.company_id, 'design.publish.requires_approval') then
    j := core.fn_approval_submit(me.company_id, 'design.layout_publish', l.id, 0, iam.fn_resource(me.company_id),
                                 jsonb_build_object('screen_key', l.screen_key, 'version', l.version));
    if j ->> 'status' <> 'approved' then
      update design.screen_layout set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = l.id;
      return jsonb_build_object('status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
  end if;
  perform design.fn_publish_layout_version(me.company_id, l.screen_key, l.version);
  return jsonb_build_object('status', 'published', 'screen_key', l.screen_key, 'version', l.version);
end $$;

-- ================================================================ KPI engine
-- Period -> {from, to} (company calendar = server date; the week starts on Saturday).
create function report.fn_period(p_company uuid, p_period text, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare d date := current_date; f date; t date;
begin
  case coalesce(p_period, 'today')
    when 'today' then f := d; t := d;
    when 'yesterday' then f := d - 1; t := d - 1;
    when 'this_week' then f := d - ((extract(dow from d)::integer + 1) % 7); t := d;
    when 'this_month' then f := date_trunc('month', d)::date; t := d;
    when 'last_month' then f := (date_trunc('month', d) - interval '1 month')::date; t := (date_trunc('month', d) - interval '1 day')::date;
    when 'this_year' then f := date_trunc('year', d)::date; t := d;
    when 'custom' then
      if p_from is null or p_to is null or p_from > p_to or p_to - p_from > config.fn_get_int(p_company, 'kpi.custom_range.max_days') then
        raise exception 'E_INVALID_ACTION: custom range must be from <= to within the allowed days' using errcode = 'P0001';
      end if;
      f := p_from; t := p_to;
    else raise exception 'E_INVALID_ACTION: unknown period %', p_period using errcode = 'P0001';
  end case;
  return jsonb_build_object('from', f, 'to', t);
end $$;

-- Company KPI wins over the platform KPI of the same code.
create function report.fn_kpi_row(p_company uuid, p_code text) returns report.kpi_catalog
language sql stable security definer set search_path = pg_catalog as $$
  select k from report.kpi_catalog k where k.code = p_code and (k.company_id = p_company or k.company_id is null)
   order by (k.company_id is null) limit 1
$$;

-- Visibility for a position (F052). Factory P&L: only positions in access.factory_pnl.positions; rows may only hide more.
create function report.fn_kpi_visible(p_company uuid, k report.kpi_catalog, p_position text, p_supreme boolean) returns boolean
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v boolean;
begin
  if p_supreme then return true; end if;
  if k.is_factory_pnl and not (p_position = any (config.fn_get_text_array(p_company, 'access.factory_pnl.positions'))) then return false; end if;
  select x.visible into v from report.kpi_visibility x
   where x.company_id = p_company and x.kpi_code = k.code and x.status = 'active' and (x.position_code = p_position or x.position_code is null)
   order by (x.position_code is null) limit 1;
  if v is not null then return v; end if;
  return k.default_positions is null or p_position = any (k.default_positions);
end $$;

-- Computes one KPI over a period (no authorisation here: callers check visibility + permission first).
create function report.fn_kpi_compute(p_company uuid, k report.kpi_catalog, d_from date, d_to date, p_wing uuid) returns numeric
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v numeric;
begin
  if k.source = 'live' then
    case k.measure
      when 'approvals_pending' then
        select count(*) into v from core.approval_request r
         where r.company_id = p_company and r.status = 'pending' and (p_wing is null or (r.resource ->> 'wing_id')::uuid = p_wing);
      when 'forms_submitted' then
        select count(*) into v from config.form_submission s
         where s.company_id = p_company and s.status in ('submitted','pending_approval','approved')
           and s.submitted_at::date between d_from and d_to and (p_wing is null or s.wing_id = p_wing);
      when 'headcount' then
        select count(distinct m.id) into v from iam.company_membership m
         where m.company_id = p_company and m.status = 'active'
           and (p_wing is null or exists (select 1 from iam.position_assignment a where a.membership_id = m.id and a.status = 'active' and a.home_wing_id = p_wing));
      when 'logins_failed' then
        select count(*) into v from iam.login_attempt a
         where a.kind = 'pin_login' and a.outcome in ('failed','locked') and a.occurred_at::date between d_from and d_to
           and a.person_id in (select m.person_id from iam.company_membership m where m.company_id = p_company);
      else v := null;
    end case;
    return v;
  end if;
  if k.agg = 'last' then
    select sum(x.value) into v from report.kpi_value x
     where x.company_id = p_company and x.kpi_code = k.code and (p_wing is null or x.wing_id = p_wing)
       and x.period_date = (select max(y.period_date) from report.kpi_value y where y.company_id = p_company and y.kpi_code = k.code
                              and y.period_date between d_from and d_to and (p_wing is null or y.wing_id = p_wing));
  elsif k.agg = 'avg' then
    select avg(x.value) into v from report.kpi_value x
     where x.company_id = p_company and x.kpi_code = k.code and x.period_date between d_from and d_to and (p_wing is null or x.wing_id = p_wing);
  else
    select coalesce(sum(x.value), 0) into v from report.kpi_value x
     where x.company_id = p_company and x.kpi_code = k.code and x.period_date between d_from and d_to and (p_wing is null or x.wing_id = p_wing);
  end if;
  return round(v, 4);
end $$;

-- Is the current caller allowed this KPI at this scope? (visibility + the aggregate's permission at company / wing)
create function report.fn_kpi_allowed(p_company uuid, k report.kpi_catalog, p_position text, p_supreme boolean, p_wing uuid) returns boolean
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare ok boolean;
begin
  if k.code is null or not report.fn_kpi_visible(p_company, k, p_position, p_supreme) then return false; end if;
  select d.allowed into ok from iam.fn_authorize(k.required_permission, iam.fn_resource(p_company, p_wing), false) d;
  return coalesce(ok, false);
end $$;

create function report.fn_style_default() returns jsonb
language sql immutable set search_path = pg_catalog as $$ select '{"chart":"number","size":"m","shape":"card","color":"primary"}'::jsonb $$;

-- One KPI result for the caller: restricted, cached or freshly computed (with the previous period for comparison).
create function report.fn_kpi_result(p_company uuid, p_person uuid, p_position text, p_supreme boolean, p_code text, p_period jsonb, p_wing uuid) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare k report.kpi_catalog; v_epoch integer; v_key text; c report.kpi_cache%rowtype; f date := (p_period ->> 'from')::date; t date := (p_period ->> 'to')::date;
        cur numeric; prev numeric; payload jsonb; v_style jsonb;
begin
  k := report.fn_kpi_row(p_company, p_code);
  if k.code is null then return jsonb_build_object('code', p_code, 'error', 'unknown'); end if;
  if not report.fn_kpi_allowed(p_company, k, p_position, p_supreme, p_wing) then
    return jsonb_build_object('code', p_code, 'name_bn', k.name_bn, 'restricted', true);
  end if;
  select coalesce(s.style, report.fn_style_default()) into v_style from (select 1) one
    left join report.kpi_style s on s.company_id = p_company and s.kpi_code = k.code and s.status = 'active';
  select p.authz_epoch into v_epoch from core.person p where p.id = p_person;
  v_key := md5(f::text || '|' || t::text || '|' || coalesce(p_wing::text, '-'));
  select * into c from report.kpi_cache x
   where x.company_id = p_company and x.kpi_code = k.code and x.cache_key = v_key and x.person_id = p_person;
  if found and c.authz_epoch = v_epoch and c.computed_at > clock_timestamp() - make_interval(secs => k.refresh_seconds) then
    return c.payload || jsonb_build_object('cached', true, 'style', v_style);
  end if;
  cur := report.fn_kpi_compute(p_company, k, f, t, p_wing);
  if k.source = 'stored' or k.measure in ('forms_submitted','logins_failed') then
    prev := report.fn_kpi_compute(p_company, k, f - (t - f + 1), f - 1, p_wing);
  end if;
  payload := jsonb_build_object('code', k.code, 'name_bn', k.name_bn, 'unit', k.unit, 'formula_bn', k.formula_bn, 'owner_position', k.owner_position,
                                'value', cur, 'previous', prev, 'from', f, 'to', t, 'wing_id', p_wing, 'computed_at', clock_timestamp(),
                                'refresh_seconds', k.refresh_seconds, 'has_products', k.has_products, 'restricted', false);
  insert into report.kpi_cache (company_id, kpi_code, cache_key, person_id, authz_epoch, payload)
  values (p_company, k.code, v_key, p_person, v_epoch, payload)
  on conflict (company_id, kpi_code, cache_key, person_id) do update set authz_epoch = excluded.authz_epoch, payload = excluded.payload, computed_at = clock_timestamp();
  return payload || jsonb_build_object('cached', false, 'style', v_style);
end $$;

create function report.fn_style_valid(p jsonb) returns boolean
language sql immutable set search_path = pg_catalog as $$
  select jsonb_typeof(p) = 'object'
     and not exists (select 1 from jsonb_object_keys(p) k where k not in ('chart','size','shape','color'))
     and coalesce(p ->> 'chart', 'number') in ('number','line','bar','donut','sparkline')
     and coalesce(p ->> 'size', 'm') in ('s','m','l')
     and coalesce(p ->> 'shape', 'card') in ('card','pill')
     and coalesce(p ->> 'color', 'primary') in ('primary','info','good','chart1','chart2','chart3','chart4','chart5','chart6','chart7','chart8')
$$;

-- ================================================================ API
create function api.v1_kpi_catalog() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', k.code, 'name_bn', k.name_bn, 'formula_bn', k.formula_bn, 'unit', k.unit, 'source', k.source,
           'owner_position', k.owner_position, 'has_products', k.has_products, 'refresh_seconds', k.refresh_seconds, 'custom', k.company_id is not null,
           'style', coalesce((select s.style from report.kpi_style s where s.company_id = me.company_id and s.kpi_code = k.code and s.status = 'active'), report.fn_style_default()))
           order by k.sort_order, k.code)
     from report.kpi_catalog k
    where (k.company_id = me.company_id or (k.company_id is null and not exists (select 1 from report.kpi_catalog o where o.company_id = me.company_id and o.code = k.code)))
      and report.fn_kpi_visible(me.company_id, k, me.position_code, me.is_supreme)), '[]'::jsonb);
end $$;

-- Values for up to 30 KPIs. Restricted KPIs come back as {restricted: true} — never a number.
create function api.v1_kpi_values(p_codes text[], p_period text, p_from date, p_to date, p_wing uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; per jsonb; c text; out jsonb := '[]'::jsonb;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_resource(iam.fn_context_company(), p_wing), false);
  if coalesce(cardinality(p_codes), 0) not between 1 and 30 then perform core.fn_raise('E_INVALID_ACTION', '1..30 KPIs'); end if;
  per := report.fn_period(me.company_id, p_period, p_from, p_to);
  foreach c in array p_codes loop
    out := out || jsonb_build_array(report.fn_kpi_result(me.company_id, me.person_id, me.position_code, me.is_supreme, c, per, p_wing));
  end loop;
  return out;
end $$;

-- Product breakdown (F056): every active product, zero when it has no value.
create function api.v1_kpi_breakdown(p_code text, p_period text, p_from date, p_to date, p_wing uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; k report.kpi_catalog; per jsonb;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_resource(iam.fn_context_company(), p_wing), false);
  k := report.fn_kpi_row(me.company_id, p_code);
  if k.code is null or not k.has_products then perform core.fn_raise('E_NOT_FOUND', 'product KPI'); end if;
  if not report.fn_kpi_allowed(me.company_id, k, me.position_code, me.is_supreme, p_wing) then perform core.fn_raise('E_FORBIDDEN', p_code); end if;
  per := report.fn_period(me.company_id, p_period, p_from, p_to);
  return coalesce((select jsonb_agg(jsonb_build_object('product_key', p.product_key, 'name_bn', p.name_bn, 'image_path', p.image_path,
                                                       'value', coalesce((select case k.agg when 'avg' then avg(v.value) else sum(v.value) end
                                                                            from report.kpi_value v
                                                                           where v.company_id = me.company_id and v.kpi_code = k.code and v.product_key = p.product_key
                                                                             and v.period_date between (per ->> 'from')::date and (per ->> 'to')::date
                                                                             and (p_wing is null or v.wing_id = p_wing)), 0))
                                    order by p.sort_order, p.name_bn)
                     from report.kpi_product p where p.company_id = me.company_id and p.is_active), '[]'::jsonb);
end $$;

-- Drilldown (F055): only records the caller may see; every row filtered on the server.
create function api.v1_kpi_drilldown(p_code text, p_period text, p_from date, p_to date, p_wing uuid, p_limit integer default 50) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; k report.kpi_catalog; per jsonb; f date; t date; n integer := greatest(1, least(coalesce(p_limit, 50), 200)); out jsonb := '[]'::jsonb;
        r record; ar core.approval_request%rowtype; ok boolean;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_resource(iam.fn_context_company(), p_wing), false);
  k := report.fn_kpi_row(me.company_id, p_code);
  if k.code is null or not report.fn_kpi_allowed(me.company_id, k, me.position_code, me.is_supreme, p_wing) then perform core.fn_raise('E_FORBIDDEN', p_code); end if;
  per := report.fn_period(me.company_id, p_period, p_from, p_to); f := (per ->> 'from')::date; t := (per ->> 'to')::date;
  if k.measure = 'approvals_pending' then
    for ar in select * from core.approval_request x where x.company_id = me.company_id and x.status = 'pending'
              and (p_wing is null or (x.resource ->> 'wing_id')::uuid = p_wing) order by x.created_at loop
      continue when core.fn_approval_can_decide(ar, me.person_id, me.is_supreme) is not null;    -- only what I may decide
      out := out || jsonb_build_array(jsonb_build_object('id', ar.id, 'document_type', ar.document_type, 'amount', ar.amount, 'created_at', ar.created_at));
      exit when jsonb_array_length(out) >= n;
    end loop;
  elsif k.measure = 'forms_submitted' then
    for r in select s.id, s.number, s.status, s.submitted_at, s.wing_id, s.created_by from config.form_submission s
              where s.company_id = me.company_id and s.status in ('submitted','pending_approval','approved') and s.submitted_at::date between f and t
                and (p_wing is null or s.wing_id = p_wing) order by s.submitted_at desc loop
      select d.allowed into ok from iam.fn_authorize('forms.submission.read', iam.fn_resource(me.company_id, r.wing_id, null, null, null, r.created_by), false) d;
      continue when not coalesce(ok, false);
      out := out || jsonb_build_array(jsonb_build_object('id', r.id, 'number', r.number, 'status', r.status, 'submitted_at', r.submitted_at));
      exit when jsonb_array_length(out) >= n;
    end loop;
  elsif k.measure = 'headcount' then
    out := coalesce((select jsonb_agg(x) from (select jsonb_build_object('membership_id', m.id, 'name_bn', p.full_name_bn) x
                                                  from iam.company_membership m join core.person p on p.id = m.person_id
                                                 where m.company_id = me.company_id and m.status = 'active' order by p.full_name_bn limit n) q), '[]'::jsonb);
  elsif k.measure = 'logins_failed' then
    out := coalesce((select jsonb_agg(x) from (select jsonb_build_object('at', a.occurred_at, 'outcome', a.outcome, 'name_bn', p.full_name_bn) x
                                                  from iam.login_attempt a join core.person p on p.id = a.person_id
                                                 where a.kind = 'pin_login' and a.outcome in ('failed','locked') and a.occurred_at::date between f and t
                                                   and a.person_id in (select m.person_id from iam.company_membership m where m.company_id = me.company_id)
                                                 order by a.occurred_at desc limit n) q), '[]'::jsonb);
  else
    out := coalesce((select jsonb_agg(x) from (select jsonb_build_object('date', v.period_date, 'wing_id', v.wing_id, 'product_key', v.product_key, 'value', v.value) x
                                                  from report.kpi_value v where v.company_id = me.company_id and v.kpi_code = k.code
                                                   and v.period_date between f and t and (p_wing is null or v.wing_id = p_wing)
                                                 order by v.period_date desc limit n) q), '[]'::jsonb);
  end if;
  return out;
end $$;

-- Stored values (until each business module feeds them itself). Closed months refuse writes; caches are dropped.
create function api.v1_kpi_record_value(p_code text, p_date date, p_value numeric, p_wing uuid, p_product text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; k report.kpi_catalog; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('kpi.value.record', iam.fn_resource(iam.fn_context_company(), p_wing), true);
  k := report.fn_kpi_row(me.company_id, p_code);
  if k.code is null or k.source <> 'stored' then perform core.fn_raise('E_NOT_FOUND', 'stored KPI'); end if;
  if p_date is null or p_date > current_date or p_value is null then perform core.fn_raise('E_INVALID_ACTION', 'date / value'); end if;
  if p_product is not null and not k.has_products then perform core.fn_raise('E_INVALID_ACTION', 'this KPI has no products'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into report.kpi_value (company_id, kpi_code, wing_id, product_key, period_date, value, recorded_by)
  values (me.company_id, k.code, p_wing, p_product, p_date, p_value, me.person_id)
  on conflict (company_id, kpi_code, wing_id, product_key, period_date) do update set value = excluded.value, recorded_by = excluded.recorded_by, recorded_at = clock_timestamp()
  returning id into v_id;
  delete from report.kpi_cache c where c.company_id = me.company_id and c.kpi_code = k.code;
  return jsonb_build_object('value_id', v_id);
end $$;

-- Company KPI definition (stored, code custom.*). Platform KPIs are not editable.
create function api.v1_kpi_define(p_code text, p_name_bn text, p_formula_bn text, p_unit text, p_agg text, p_owner_position text,
                                  p_default_positions text[], p_has_products boolean, p_refresh_seconds integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('kpi.catalog.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_code, '') !~ '^custom\.[a-z0-9_]{2,40}$' then perform core.fn_raise('E_INVALID_ACTION', 'company KPI codes start with custom.'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into report.kpi_catalog (company_id, code, name_bn, formula_bn, unit, source, agg, required_permission, owner_position, default_positions, has_products, refresh_seconds)
  values (me.company_id, p_code, p_name_bn, p_formula_bn, p_unit, 'stored', coalesce(p_agg, 'sum'), 'kpi.dashboard.read', p_owner_position, p_default_positions,
          coalesce(p_has_products, false), coalesce(p_refresh_seconds, 300))
  returning id into v_id;
  return jsonb_build_object('kpi_id', v_id, 'code', p_code);
end $$;

create function api.v1_kpi_set_visibility(p_code text, p_position_code text, p_visible boolean, p_expected_version integer, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; cur report.kpi_visibility%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('kpi.catalog.manage', iam.fn_my_company_resource(), true);
  if (report.fn_kpi_row(me.company_id, p_code)).code is null or p_visible is null then perform core.fn_raise('E_NOT_FOUND', 'kpi'); end if;
  if p_position_code is not null and exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code and pc.is_supreme) then
    perform core.fn_raise('E_PROTECTED_POSITION', 'the Chairman always sees every KPI');
  end if;
  select * into cur from report.kpi_visibility x where x.company_id = me.company_id and x.kpi_code = p_code
     and x.position_code is not distinct from p_position_code and x.status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then update report.kpi_visibility set status = 'superseded' where id = cur.id; end if;
  v_next := coalesce((select max(x.version) from report.kpi_visibility x where x.company_id = me.company_id and x.kpi_code = p_code
                       and x.position_code is not distinct from p_position_code), 0) + 1;
  insert into report.kpi_visibility (company_id, kpi_code, position_code, visible, version, set_by, reason)
  values (me.company_id, p_code, p_position_code, p_visible, v_next, me.person_id, p_reason);
  delete from report.kpi_cache c where c.company_id = me.company_id and c.kpi_code = p_code;
  return v_next;
end $$;

create function api.v1_kpi_set_style(p_code text, p_style jsonb, p_expected_version integer, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; cur report.kpi_style%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('kpi.catalog.manage', iam.fn_my_company_resource(), true);
  if (report.fn_kpi_row(me.company_id, p_code)).code is null then perform core.fn_raise('E_NOT_FOUND', 'kpi'); end if;
  if p_style is null or not report.fn_style_valid(p_style) then
    perform core.fn_raise('E_DESIGN_INVALID', 'style: chart number/line/bar/donut/sparkline, size s/m/l, shape card/pill, colour primary/info/good/chart1..8 (warn/bad stay reserved for alerts)');
  end if;
  select * into cur from report.kpi_style x where x.company_id = me.company_id and x.kpi_code = p_code and x.status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then update report.kpi_style set status = 'superseded' where id = cur.id; end if;
  v_next := coalesce(cur.version, 0) + 1;
  insert into report.kpi_style (company_id, kpi_code, style, version, set_by, reason) values (me.company_id, p_code, p_style, v_next, me.person_id, p_reason);
  return v_next;
end $$;

create function api.v1_kpi_set_product(p_product_key text, p_name_bn text, p_image_path text, p_sort integer, p_active boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('kpi.catalog.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into report.kpi_product (company_id, product_key, name_bn, image_path, sort_order, is_active)
  values (me.company_id, p_product_key, p_name_bn, p_image_path, coalesce(p_sort, 0), coalesce(p_active, true))
  on conflict (company_id, product_key) do update set name_bn = excluded.name_bn, image_path = excluded.image_path, sort_order = excluded.sort_order, is_active = excluded.is_active;
  return jsonb_build_object('product_key', p_product_key);
end $$;

-- Closes a past month for KPI values (F054). Irreversible here; finance period locking arrives with finance.
create function api.v1_kpi_close_period(p_month date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_month date := date_trunc('month', p_month)::date;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('kpi.period.close', iam.fn_my_company_resource(), true);
  if v_month is null or v_month >= date_trunc('month', current_date)::date then perform core.fn_raise('E_INVALID_ACTION', 'only a past month can be closed'); end if;
  if exists (select 1 from report.period_close c where c.company_id = me.company_id and c.month = v_month) then perform core.fn_raise('E_DUPLICATE', 'already closed'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into report.period_close (company_id, month, closed_by, reason) values (me.company_id, v_month, me.person_id, p_reason);
  return jsonb_build_object('month', v_month, 'status', 'closed');
end $$;

-- Export data (F060): the device renders image / PDF / print; restricted figures come back redacted and are logged.
create function api.v1_kpi_export(p_codes text[], p_period text, p_from date, p_to date, p_wing uuid, p_format text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; per jsonb; c text; r jsonb; v_rows jsonb := '[]'::jsonb; red text[] := array[]::text[];
begin
  select * into me from iam.fn_require('kpi.export', iam.fn_resource(iam.fn_context_company(), p_wing), false);
  if coalesce(cardinality(p_codes), 0) not between 1 and 30 or coalesce(p_format, '') not in ('image','pdf','print','data') then
    perform core.fn_raise('E_INVALID_ACTION', 'codes / format');
  end if;
  per := report.fn_period(me.company_id, p_period, p_from, p_to);
  foreach c in array p_codes loop
    r := report.fn_kpi_result(me.company_id, me.person_id, me.position_code, me.is_supreme, c, per, p_wing);
    if coalesce((r ->> 'restricted')::boolean, false) or r ? 'error' then
      red := red || c;
      r := jsonb_build_object('code', c, 'name_bn', coalesce(r ->> 'name_bn', c), 'value', '[গোপন]', 'restricted', true);
    end if;
    v_rows := v_rows || jsonb_build_array(r);
  end loop;
  insert into report.export_log (company_id, person_id, position_code, kpi_codes, redacted, period_from, period_to, format)
  values (me.company_id, me.person_id, me.position_code, p_codes, red, (per ->> 'from')::date, (per ->> 'to')::date, p_format);
  return jsonb_build_object('rows', v_rows, 'redacted', to_jsonb(red), 'from', per ->> 'from', 'to', per ->> 'to', 'exported_at', clock_timestamp());
end $$;

-- Advertisement media (F058).
create function api.v1_design_set_ad(p_slot integer, p_title_bn text, p_image_path text, p_valid_until timestamptz, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.ads.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_slot, 0) not between 1 and 3 then perform core.fn_raise('E_DESIGN_INVALID', 'slot 1..3'); end if;
  if coalesce(p_image_path, '') not like me.company_id::text || '/%' then perform core.fn_raise('E_DESIGN_INVALID', 'image must be in this company''s storage'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update design.ad_media set status = 'superseded' where company_id = me.company_id and slot = p_slot and status = 'active';
  insert into design.ad_media (company_id, slot, title_bn, image_path, valid_until, set_by, reason)
  values (me.company_id, p_slot, p_title_bn, p_image_path, p_valid_until, me.person_id, p_reason);
  return jsonb_build_object('slot', p_slot, 'status', 'active');
end $$;

create or replace function api.v1_design_active() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object(
    'theme', (select jsonb_build_object('theme_id', t.id, 'code', t.code, 'version', v.version, 'tokens', v.tokens)
                from design.theme t join design.theme_version v on v.theme_id = t.id and v.version = t.active_version
               where t.company_id = me.company_id and t.is_active),
    'icons', coalesce((select jsonb_agg(jsonb_build_object('target_key', b.target_key, 'icon', b.icon_name, 'permission', b.permission_code, 'version', b.version)
                                        order by b.target_key)
                         from design.icon_binding b where b.company_id = me.company_id and b.status = 'active'), '[]'::jsonb),
    'layouts', coalesce((select jsonb_object_agg(l.screen_key, jsonb_build_object('version', l.version, 'layout', l.layout))
                           from design.screen_layout l where l.company_id = me.company_id and l.status = 'published'), '{}'::jsonb),
    'motion', jsonb_build_object('duration_ms', config.fn_get_int(me.company_id, 'design.motion.duration_ms'),
                                 'easing', config.fn_get_text(me.company_id, 'design.motion.easing'),
                                 'reduced', config.fn_get_text(me.company_id, 'design.motion.reduced')),
    'ads', config.fn_flag(me.company_id, 'design.ad_slots', me.home_wing_id),
    'ads_visible_max', config.fn_get_int(me.company_id, 'design.ads.visible_max'),
    'ad_media', case when config.fn_flag(me.company_id, 'design.ad_slots', me.home_wing_id) then
                  coalesce((select jsonb_agg(jsonb_build_object('slot', a.slot, 'title_bn', a.title_bn, 'image_path', a.image_path) order by a.slot)
                              from design.ad_media a where a.company_id = me.company_id and a.status = 'active'
                               and (a.valid_until is null or a.valid_until > clock_timestamp())), '[]'::jsonb) else '[]'::jsonb end);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_kpi_catalog()', 'api.v1_kpi_values(text[], text, date, date, uuid)', 'api.v1_kpi_breakdown(text, text, date, date, uuid)',
      'api.v1_kpi_drilldown(text, text, date, date, uuid, integer)', 'api.v1_kpi_record_value(text, date, numeric, uuid, text, text)',
      'api.v1_kpi_define(text, text, text, text, text, text, text[], boolean, integer, text)', 'api.v1_kpi_set_visibility(text, text, boolean, integer, text)',
      'api.v1_kpi_set_style(text, jsonb, integer, text)', 'api.v1_kpi_set_product(text, text, text, integer, boolean, text)',
      'api.v1_kpi_close_period(date, text)', 'api.v1_kpi_export(text[], text, date, date, uuid, text)',
      'api.v1_design_set_ad(integer, text, text, timestamptz, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

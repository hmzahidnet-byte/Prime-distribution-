-- 20261108003500_reports_backup_release.sql  (S52–S55, final phase)
-- Custom reports (CUSTOM_REPORTS 291..300), backup & recovery records (BACKUP_RECOVERY 251..260), quality & release gate
-- (QUALITY_RELEASE 271..280: the database part — requirement registry and sign-offs; CI and runbooks live in the repository).
--   Reports: whitelisted datasets (no SQL editor), columns + filters + group + aggregate + chart, Chairman/MD-approved versioned
--       templates, every run re-checks the runner's own rights and company scope, masked columns redacted, drilldown to records
--       the runner may open, schedules that produce stored outputs for named recipients, time-limited shares to named people only,
--       retirement keeps every output, every view/export logged.
--   Backup: PITR / storage / logical runs recorded with checksums, drills only on non-production targets with independent
--       approval and evidence hash, RPO / RTO measured from records, retention with legal hold override, company-scoped restore
--       manifest (row counts + checksums per table) — never an in-place cross-tenant overwrite.
--   Release: requirement registry (feature -> source -> evidence), sign-offs per area by different people, no automatic publish.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ custom reports (F291–F300)
create table report.dataset (
  code                text primary key check (code ~ '^[a-z_]{3,40}$'),
  name_bn             text not null,
  required_permission text not null references iam.permission_catalog(code),
  columns             jsonb not null              -- [{key, label_bn, type, mask_permission?, drill?}]
);
create trigger trg_dataset_nodel before delete on report.dataset for each row execute function core.fn_deny_delete();
insert into report.dataset (code, name_bn, required_permission, columns) values
  ('sales_invoices', 'বিক্রয়-ইনভয়েস', 'sales.weekly_summary.read', '[{"key":"date","label_bn":"তারিখ","type":"date"},{"key":"number","label_bn":"নম্বর","type":"text","drill":"sales.invoice"},
     {"key":"dealer","label_bn":"ডিলার","type":"text"},{"key":"territory","label_bn":"এলাকা","type":"text"},{"key":"amount","label_bn":"টাকা","type":"money"}]'),
  ('collections', 'কালেকশন', 'crm.dealer.read', '[{"key":"date","label_bn":"তারিখ","type":"date"},{"key":"number","label_bn":"নম্বর","type":"text"},{"key":"dealer","label_bn":"ডিলার","type":"text"},
     {"key":"method","label_bn":"মাধ্যম","type":"text"},{"key":"status","label_bn":"অবস্থা","type":"text"},{"key":"amount","label_bn":"টাকা","type":"money"}]'),
  ('stock_balance', 'মজুদ', 'inventory.stock.read', '[{"key":"warehouse","label_bn":"গুদাম","type":"text"},{"key":"sku","label_bn":"SKU","type":"text"},{"key":"qty","label_bn":"পরিমাণ","type":"number"},
     {"key":"value","label_bn":"মূল্য","type":"money","mask_permission":"inventory.cost.read"}]'),
  ('purchase_orders', 'ক্রয়-আদেশ', 'procurement.read', '[{"key":"date","label_bn":"তারিখ","type":"date"},{"key":"number","label_bn":"নম্বর","type":"text"},{"key":"supplier","label_bn":"সাপ্লায়ার","type":"text"},
     {"key":"status","label_bn":"অবস্থা","type":"text"},{"key":"amount","label_bn":"টাকা","type":"money"}]'),
  ('attendance_days', 'হাজিরা', 'hr.attendance.read', '[{"key":"date","label_bn":"তারিখ","type":"date"},{"key":"employee","label_bn":"কর্মী","type":"text"},{"key":"events","label_bn":"স্ক্যান","type":"number"}]');

create table report.template (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  code         text not null check (code ~ '^[A-Z0-9_-]{2,30}$'),
  version      integer not null check (version >= 1),
  name_bn      text not null,
  dataset      text not null references report.dataset(code),
  spec         jsonb not null,           -- {columns:[], group_by:null|key, aggregate:'sum'|'count', chart:'table'|'bar'|'line'|'kpi'}
  status       text not null default 'draft' check (status in ('draft','approved','archived')),
  created_by   uuid not null references core.person(id),
  approved_by  uuid references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, code, version),
  check (approved_by is null or approved_by <> created_by)
);
create function report.fn_template_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.spec is distinct from old.spec or new.dataset <> old.dataset or new.version <> old.version
     or not ((old.status = 'draft' and new.status in ('approved','archived')) or (old.status = 'approved' and new.status = 'archived') or new.status = old.status) then
    raise exception 'E_IMMUTABLE: templates are versioned; archive and create a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_template_guard before update on report.template for each row execute function report.fn_template_guard();
create trigger trg_template_nodel before delete on report.template for each row execute function core.fn_deny_delete();
create trigger trg_template_audit after insert or update on report.template for each row execute function audit.fn_row_change();

create table report.schedule (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  template_id  uuid not null,
  cadence      text not null check (cadence in ('daily','weekly','monthly')),
  recipients   uuid[] not null,
  filters      jsonb not null default '{}'::jsonb,
  next_run     date not null,
  status       text not null default 'active' check (status in ('active','stopped')),
  owner_id     uuid not null references core.person(id),
  foreign key (template_id, company_id) references report.template (id, company_id)
);
create trigger trg_schedule_audit after insert or update on report.schedule for each row execute function audit.fn_row_change();

create table report.output (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  template_id  uuid not null,
  run_by       uuid not null references core.person(id),
  filters      jsonb not null,
  rows         jsonb not null,
  checksum     text not null,
  created_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (template_id, company_id) references report.template (id, company_id)
);
create trigger trg_output_no_mutation before update or delete on report.output for each row execute function core.fn_deny_mutation();

create table report.share (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  output_id    uuid not null,
  recipient_id uuid not null references core.person(id),
  token_hash   text not null unique,
  expires_at   timestamptz not null,
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  foreign key (output_id, company_id) references report.output (id, company_id)
);
create trigger trg_share_no_mutation before update or delete on report.share for each row execute function core.fn_deny_mutation();

create table report.access_log (
  id          bigint generated always as identity primary key,
  company_id  uuid not null, person_id uuid not null, template_id uuid, action text not null check (action in ('view','export','print','share','open_share')),
  format      text, at timestamptz not null default clock_timestamp()
);
create trigger trg_report_access_log_no_mutation before update or delete on report.access_log for each row execute function core.fn_deny_mutation();

-- ================================================================ backup & recovery (F251–F260)
create table core.backup_run (
  id            uuid primary key default gen_random_uuid(),
  kind          text not null check (kind in ('pitr_check','storage_copy','logical_export')),
  environment   text not null check (environment in ('production','staging','isolated')),
  started_at    timestamptz not null,
  finished_at   timestamptz,
  status        text not null check (status in ('ok','failed')),
  objects       integer,
  checksum_manifest_sha256 text check (checksum_manifest_sha256 is null or checksum_manifest_sha256 ~ '^[0-9a-f]{64}$'),
  last_committed_at timestamptz,         -- latest event recoverable from this run (RPO source)
  key_id        text,                    -- encryption key reference (never the key)
  operator      text not null,
  retained_until date,
  recorded_at   timestamptz not null default clock_timestamp()
);
create trigger trg_backup_run_no_mutation before update or delete on core.backup_run for each row execute function core.fn_deny_mutation();

create table core.recovery_drill (
  id              uuid primary key default gen_random_uuid(),
  target_env      text not null check (target_env in ('staging','isolated')),          -- never production (F255)
  backup_run_id   uuid references core.backup_run(id),
  company_id      uuid references core.company(id),                                 -- company-scoped drill (F258), null = full
  started_at      timestamptz not null,
  service_restored_at timestamptz,
  rpo_minutes     numeric(10,1),
  rto_minutes     numeric(10,1),
  evidence_sha256 text not null check (evidence_sha256 ~ '^[0-9a-f]{64}$'),
  operator_id     uuid not null references core.person(id),
  approver_id     uuid references core.person(id),
  approved_at     timestamptz,
  check (approver_id is null or approver_id <> operator_id)
);
create function core.fn_drill_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['approver_id','approved_at']) <> (to_jsonb(new) - array['approver_id','approved_at']) or old.approver_id is not null then
    raise exception 'E_IMMUTABLE: drill evidence is immutable' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_drill_guard before update on core.recovery_drill for each row execute function core.fn_drill_guard();
create trigger trg_drill_nodel before delete on core.recovery_drill for each row execute function core.fn_deny_delete();

-- ================================================================ release (F271, F279)
create table core.requirement_evidence (
  feature_id   text not null check (feature_id ~ '^MOS-F153-[0-9]{3}$'),
  kind         text not null check (kind in ('migration','sql_test','kotlin_test','ci','doc','manual')),
  ref          text not null,
  status       text not null default 'written' check (status in ('written','passed','failed')),
  recorded_at  timestamptz not null default clock_timestamp(),
  primary key (feature_id, kind, ref)
);
create table core.release_signoff (
  id          uuid primary key default gen_random_uuid(),
  release     text not null check (release ~ '^[0-9]+\.[0-9]+\.[0-9]+$'),
  area        text not null check (area in ('security','finance','design','operations')),
  person_id   uuid not null references core.person(id),
  note        text not null,
  signed_at   timestamptz not null default clock_timestamp(),
  unique (release, area)
);
create trigger trg_signoff_no_mutation before update or delete on core.release_signoff for each row execute function core.fn_deny_mutation();

select core.fn_apply_rls('report', 'dataset');
select core.fn_apply_rls('report', 'template');
select core.fn_apply_rls('report', 'schedule');
select core.fn_apply_rls('report', 'output');
select core.fn_apply_rls('report', 'share');
select core.fn_apply_rls('report', 'access_log');
select core.fn_apply_rls('core', 'backup_run');
select core.fn_apply_rls('core', 'recovery_drill');
select core.fn_apply_rls('core', 'requirement_evidence');
select core.fn_apply_rls('core', 'release_signoff');

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('report.template.manage',  'report', 'কাস্টম রিপোর্ট তৈরি', 'write', false, true, array['COMPANY'], 'active', 2200),
  ('report.template.approve', 'report', 'কাস্টম রিপোর্ট অনুমোদন', 'approve', true, false, array['COMPANY'], 'active', 2201),
  ('report.run',              'report', 'কাস্টম রিপোর্ট চালানো/রপ্তানি', 'read', false, true, array['COMPANY'], 'active', 2202),
  ('ops.backup.read',         'ops', 'ব্যাকআপ/রিকভারি রেকর্ড দেখা', 'read', true, false, array['COMPANY'], 'active', 2210),
  ('ops.drill.approve',       'ops', 'রিকভারি-ড্রিল অনুমোদন', 'approve', true, false, array['COMPANY'], 'active', 2211),
  ('ops.release.signoff',     'ops', 'রিলিজ সাইন-অফ', 'approve', true, false, array['COMPANY'], 'active', 2212);
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', 'COMPANY' from (values ('MD','report.template.approve'), ('MD','report.run'), ('MD','report.template.manage'), ('FIN_MANAGER','report.run'),
  ('FIN_MANAGER','report.template.manage'), ('SALES_MANAGER','report.run'), ('ACCOUNTANT','report.run'), ('AUDITOR','report.run'), ('TECH_ADMIN','ops.backup.read'),
  ('AUDITOR','ops.backup.read'), ('MD','ops.drill.approve'), ('TECH_ADMIN','ops.release.signoff'), ('FIN_MANAGER','ops.release.signoff'), ('MD','ops.release.signoff')) v(x, y)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('report');
select config.fn_make_module_available('backup');
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('report.share.max_days', 'report', 'int', '7', 1, 30, null, 'রিপোর্ট-শেয়ারের সর্বোচ্চ মেয়াদ (দিন)', 'MOS-F153-297', true, 2300);

-- ================================================================ engine: dataset rows (scope always applied, F294)
-- Does a person hold a permission company-wide (any active assignment)? Used for scheduled runs, where there is no session.
create function report.fn_person_can(p_company uuid, p_person uuid, p_permission text) returns boolean
language plpgsql stable security definer set search_path = pg_catalog as $$
declare a record; d record;
begin
  for a in select x.id, x.position_code, pc.is_supreme, x.home_wing_id, x.home_department_id, x.home_location_id
             from iam.position_assignment x join iam.company_membership m on m.id = x.membership_id
             join iam.position_catalog pc on pc.company_id = x.company_id and pc.code = x.position_code
            where x.company_id = p_company and m.person_id = p_person and x.status = 'active' and m.status = 'active' loop
    select * into d from iam.fn_decide(p_company, a.id, a.position_code, a.is_supreme, p_person, a.home_wing_id, a.home_department_id, a.home_location_id,
                                       p_permission, iam.fn_resource(p_company), false);
    if d.allowed then return true; end if;
  end loop;
  return false;
end $$;

create function report.fn_dataset_rows(p_company uuid, p_dataset text, p_filters jsonb) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare f date := coalesce((p_filters ->> 'from')::date, current_date - 30); t date := coalesce((p_filters ->> 'to')::date, current_date);
        v_wh uuid := (p_filters ->> 'warehouse_id')::uuid; v_cost boolean;
        v_sys boolean := coalesce(current_setting('mohona.report_system', true), '') = 'on';      -- scheduler run for an owner with company-wide rights
begin
  if t - f > 400 then raise exception 'E_REPORT_RANGE: at most 400 days' using errcode = 'P0001'; end if;
  case p_dataset
    when 'sales_invoices' then
      return coalesce((select jsonb_agg(jsonb_build_object('date', i.invoice_date, 'number', i.number, 'id', i.id, 'dealer', d.name_bn, 'territory', tr.code, 'amount', i.total) order by i.invoice_date)
        from sales.invoice i join sales.dealer d on d.id = i.dealer_id join sales.territory tr on tr.id = d.territory_id
       where i.company_id = p_company and i.invoice_date between f and t
         and (v_sys or (select a.allowed from iam.fn_authorize('sales.weekly_summary.read', sales.fn_dealer_resource(d), false) a))), '[]'::jsonb);
    when 'collections' then
      return coalesce((select jsonb_agg(jsonb_build_object('date', c.collected_at::date, 'number', c.number, 'id', c.id, 'dealer', d.name_bn, 'method', c.method, 'status', c.status, 'amount', c.amount)
                        order by c.collected_at)
        from sales.collection c join sales.dealer d on d.id = c.dealer_id
       where c.company_id = p_company and c.collected_at::date between f and t
         and (v_sys or (select a.allowed from iam.fn_authorize('crm.dealer.read', sales.fn_dealer_resource(d), false) a))), '[]'::jsonb);
    when 'stock_balance' then
      if v_sys then v_cost := coalesce(current_setting('mohona.report_system_cost', true), '') = 'on';
      else select coalesce(x.allowed, false) into v_cost from iam.fn_authorize('inventory.cost.read', iam.fn_resource(p_company), false) x; end if;
      return coalesce((select jsonb_agg(jsonb_build_object('warehouse', w.code, 'sku', p.sku, 'qty', b.qty, 'value', case when v_cost then b.value end) order by w.code, p.sku)
        from inventory.stock_balance b join inventory.warehouse w on w.id = b.warehouse_id join inventory.product p on p.id = b.product_id
       where b.company_id = p_company and (v_wh is null or b.warehouse_id = v_wh)
         and (v_sys or (select a.allowed from iam.fn_authorize('inventory.stock.read', iam.fn_resource(p_company, null, null, null, b.warehouse_id), false) a))), '[]'::jsonb);
    when 'purchase_orders' then
      return coalesce((select jsonb_agg(jsonb_build_object('date', po.created_at::date, 'number', po.number, 'id', po.id, 'supplier', s.name_bn, 'status', po.status, 'amount', po.total)
                        order by po.created_at)
        from procurement.po po join procurement.supplier s on s.id = po.supplier_id where po.company_id = p_company and po.created_at::date between f and t), '[]'::jsonb);
    when 'attendance_days' then
      return coalesce((select jsonb_agg(jsonb_build_object('date', q.d, 'employee', q.n, 'events', q.c) order by q.d, q.n) from (
        select e.event_at::date d, p.full_name_bn n, count(*) c from hr.attendance_event e join hr.employee x on x.id = e.employee_id join core.person p on p.id = x.person_id
         where e.company_id = p_company and e.status = 'posted' and e.event_at::date between f and t
           and (v_sys or (select a.allowed from iam.fn_authorize('hr.attendance.read', iam.fn_resource(p_company, null, null, null, null, x.person_id), false) a))
         group by 1, 2) q), '[]'::jsonb);
    else raise exception 'E_NOT_FOUND: dataset' using errcode = 'P0001';
  end case;
end $$;

-- Applies the template spec: chosen columns, optional group + aggregate. Money columns rounded once at output (ADR-09).
create function report.fn_apply_spec(p_rows jsonb, p_spec jsonb) returns jsonb
language plpgsql immutable set search_path = pg_catalog as $$
declare g text := p_spec ->> 'group_by'; agg text := coalesce(p_spec ->> 'aggregate', 'sum'); m text := p_spec ->> 'measure'; cols jsonb := p_spec -> 'columns';
begin
  if g is not null then
    return coalesce((select jsonb_agg(jsonb_build_object(g, k, 'value', case when agg = 'count' then cnt else round(sm, 2) end) order by k) from (
      select x ->> g k, count(*) cnt, sum(coalesce((x ->> m)::numeric, 0)) sm from jsonb_array_elements(p_rows) x group by 1) q), '[]'::jsonb);
  end if;
  if cols is null then return p_rows; end if;
  return coalesce((select jsonb_agg((select jsonb_object_agg(c, x -> c) from jsonb_array_elements_text(cols) c) || jsonb_build_object('id', x -> 'id')) from jsonb_array_elements(p_rows) x), '[]'::jsonb);
end $$;

-- ================================================================ API: reports
create function api.v1_report_datasets() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', d.code, 'name_bn', d.name_bn, 'columns', d.columns))
     from report.dataset d where (select a.allowed from iam.fn_authorize(d.required_permission, iam.fn_resource(me.company_id, null, null, null, null, me.person_id, me.person_id), false) a)), '[]'::jsonb);
end $$;

create function api.v1_report_templates() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('report.run', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'code', t.code, 'version', t.version, 'name_bn', t.name_bn, 'dataset', t.dataset, 'status', t.status,
           'chart', coalesce(t.spec ->> 'chart', 'table')) order by t.code, t.version desc)
     from report.template t where t.company_id = me.company_id and t.status <> 'archived'), '[]'::jsonb);
end $$;

create function api.v1_report_template_save(p_code text, p_name_bn text, p_dataset text, p_spec jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_ver integer; v_id uuid; c text;
begin
  select * into me from iam.fn_require('report.template.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from report.dataset d where d.code = p_dataset) then perform core.fn_raise('E_NOT_FOUND', 'dataset'); end if;
  if coalesce(p_spec ->> 'chart', 'table') not in ('table','bar','line','kpi') or coalesce(p_spec ->> 'aggregate', 'sum') not in ('sum','count')
     or exists (select 1 from jsonb_object_keys(p_spec) k where k not in ('columns','group_by','aggregate','measure','chart')) then
    perform core.fn_raise('E_INVALID_ACTION', 'spec: columns, group_by, aggregate (sum/count), measure, chart (table/bar/line/kpi) — no SQL');
  end if;
  for c in select jsonb_array_elements_text(coalesce(p_spec -> 'columns', '[]'::jsonb)) union select p_spec ->> 'group_by' union select p_spec ->> 'measure' loop
    if c is not null and not exists (select 1 from report.dataset d, jsonb_array_elements(d.columns) x where d.code = p_dataset and x ->> 'key' = c) then
      perform core.fn_raise('E_INVALID_ACTION', 'unknown column ' || c);
    end if;
  end loop;
  v_ver := coalesce((select max(t.version) from report.template t where t.company_id = me.company_id and t.code = upper(p_code)), 0) + 1;
  insert into report.template (company_id, code, version, name_bn, dataset, spec, created_by) values (me.company_id, upper(p_code), v_ver, p_name_bn, p_dataset, p_spec, me.person_id)
  returning id into v_id;
  return jsonb_build_object('template_id', v_id, 'version', v_ver, 'status', 'draft');
end $$;

create function api.v1_report_template_action(p_template_id uuid, p_action text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t report.template%rowtype;
begin
  select * into me from iam.fn_require(case when p_action = 'approve' then 'report.template.approve' else 'report.template.manage' end, iam.fn_my_company_resource(), true);
  select * into t from report.template where id = p_template_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'template'); end if;
  if p_action = 'approve' and t.status = 'draft' then
    if t.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
    update report.template set status = 'approved', approved_by = me.person_id where id = t.id;
  elsif p_action = 'archive' and t.status in ('draft','approved') then
    update report.template set status = 'archived' where id = t.id;                    -- outputs stay (F300)
  else perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || t.status);
  end if;
  return jsonb_build_object('template_id', t.id, 'status', (select x.status from report.template x where x.id = t.id));
end $$;

-- Run (F291, F294, F296, F299): approved template, runner's own dataset right, scope filtered rows, stored output + log.
create function api.v1_report_run(p_template_id uuid, p_filters jsonb, p_format text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; t report.template%rowtype; ds report.dataset%rowtype; v_rows jsonb; v_id uuid := gen_random_uuid();
begin
  select * into me from iam.fn_require('report.run', iam.fn_my_company_resource(), false);
  select * into t from report.template where id = p_template_id and company_id = me.company_id and status = 'approved';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'approved template'); end if;
  select * into ds from report.dataset where code = t.dataset;
  perform iam.fn_require(ds.required_permission, iam.fn_resource(me.company_id, null, null, null, null, me.person_id, me.person_id), false);   -- no access elevation (F292)
  v_rows := report.fn_apply_spec(report.fn_dataset_rows(me.company_id, t.dataset, coalesce(p_filters, '{}'::jsonb)), t.spec);
  insert into report.output (id, company_id, template_id, run_by, filters, rows, checksum) values (v_id, me.company_id, t.id, me.person_id, coalesce(p_filters, '{}'::jsonb), v_rows, md5(v_rows::text));
  insert into report.access_log (company_id, person_id, template_id, action, format) values (me.company_id, me.person_id, t.id, case when coalesce(p_format, 'view') = 'view' then 'view' else 'export' end, p_format);
  return jsonb_build_object('output_id', v_id, 'chart', coalesce(t.spec ->> 'chart', 'table'), 'rows', v_rows, 'checksum', md5(v_rows::text));
end $$;

-- Drilldown (F295): the record is opened through its own module API, so its own rights decide.
create function api.v1_report_drill(p_dataset text, p_record_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('report.run', iam.fn_my_company_resource(), false);
  return case p_dataset
    when 'sales_invoices' then (select to_jsonb(i) - 'company_id' from sales.invoice i where i.id = p_record_id and i.company_id = me.company_id
                                 and (select a.allowed from iam.fn_authorize('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = i.dealer_id)), false) a))
    when 'purchase_orders' then api.v1_po_get(p_record_id)
    else null end;
end $$;

create function api.v1_report_schedule(p_template_id uuid, p_cadence text, p_recipients uuid[], p_filters jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('report.template.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from report.template t where t.id = p_template_id and t.company_id = me.company_id and t.status = 'approved') then perform core.fn_raise('E_NOT_FOUND', 'approved template'); end if;
  if exists (select 1 from unnest(coalesce(p_recipients, array[]::uuid[])) r where not exists (select 1 from iam.company_membership m where m.company_id = me.company_id and m.person_id = r and m.status = 'active')) then
    perform core.fn_raise('E_NOT_FOUND', 'recipient');
  end if;
  insert into report.schedule (company_id, template_id, cadence, recipients, filters, next_run, owner_id)
  values (me.company_id, p_template_id, p_cadence, p_recipients, coalesce(p_filters, '{}'::jsonb), current_date + 1, me.person_id) returning id into v_id;
  return jsonb_build_object('schedule_id', v_id);
end $$;

-- Scheduler (F293): deterministic outputs under the OWNER's rights; recipients get a notification, not the data.
create function svc.v1_report_run_schedules() returns integer
language plpgsql security definer set search_path = '' as $$
declare s record; t report.template%rowtype; v_rows jsonb; v_id uuid; r uuid; n integer := 0;
begin
  perform set_config('mohona.company_scope', '', true);
  for s in select * from report.schedule x where x.status = 'active' and x.next_run <= current_date for update loop
    select * into t from report.template where id = s.template_id and status = 'approved';
    if t.id is null then update report.schedule set status = 'stopped' where id = s.id; continue; end if;
    -- the owner must (still) hold the dataset right company-wide; otherwise the schedule stops instead of leaking or lying
    if not report.fn_person_can(s.company_id, s.owner_id, (select d.required_permission from report.dataset d where d.code = t.dataset))
       or not report.fn_person_can(s.company_id, s.owner_id, 'report.run') then
      update report.schedule set status = 'stopped' where id = s.id; continue;
    end if;
    perform set_config('mohona.report_system', 'on', true);
    perform set_config('mohona.report_system_cost', case when report.fn_person_can(s.company_id, s.owner_id, 'inventory.cost.read') then 'on' else 'off' end, true);
    v_rows := report.fn_apply_spec(report.fn_dataset_rows(s.company_id, t.dataset, s.filters), t.spec);
    perform set_config('mohona.report_system', 'off', true);
    v_id := gen_random_uuid();
    insert into report.output (id, company_id, template_id, run_by, filters, rows, checksum) values (v_id, s.company_id, t.id, s.owner_id, s.filters, v_rows, md5(v_rows::text));
    foreach r in array s.recipients loop
      perform notify.fn_send(s.company_id, r, 'system.broadcast', jsonb_build_object('title', 'রিপোর্ট প্রস্তুত', 'body', t.name_bn), 'report_output', v_id, 'report:' || v_id || ':' || r);
    end loop;
    update report.schedule set next_run = case s.cadence when 'daily' then current_date + 1 when 'weekly' then current_date + 7 else (current_date + interval '1 month')::date end where id = s.id;
    n := n + 1;
  end loop;
  return n;
end $$;

-- Sharing (F297): to a named person only, time-limited; the recipient must still hold the dataset right.
create function api.v1_report_share(p_output_id uuid, p_recipient uuid, p_days integer) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare me record; v_token text := encode(gen_random_bytes(24), 'hex');
begin
  select * into me from iam.fn_require('report.run', iam.fn_my_company_resource(), true);
  if not exists (select 1 from report.output o where o.id = p_output_id and o.company_id = me.company_id and o.run_by = me.person_id) then perform core.fn_raise('E_NOT_FOUND', 'your output'); end if;
  if coalesce(p_days, 0) not between 1 and config.fn_get_int(me.company_id, 'report.share.max_days') then perform core.fn_raise('E_INVALID_ACTION', 'days'); end if;
  insert into report.share (company_id, output_id, recipient_id, token_hash, expires_at, created_by)
  values (me.company_id, p_output_id, p_recipient, encode(digest(v_token, 'sha256'), 'hex'), clock_timestamp() + make_interval(days => p_days), me.person_id);
  insert into report.access_log (company_id, person_id, action) values (me.company_id, me.person_id, 'share');
  return jsonb_build_object('token', v_token, 'expires_in_days', p_days);
end $$;

create function api.v1_report_open_shared(p_token text) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog, public, extensions as $$
declare me record; sh report.share%rowtype; o report.output%rowtype; ds text;
begin
  select * into me from iam.fn_context(false);
  select * into sh from report.share where token_hash = encode(digest(coalesce(p_token, ''), 'sha256'), 'hex') and company_id = me.company_id;
  if sh.id is null or sh.recipient_id <> me.person_id or sh.expires_at < clock_timestamp() then perform core.fn_raise('E_NOT_FOUND', 'share'); end if;
  select * into o from report.output where id = sh.output_id;
  select t.dataset into ds from report.template t where t.id = o.template_id;
  perform iam.fn_require((select d.required_permission from report.dataset d where d.code = ds), iam.fn_resource(me.company_id, null, null, null, null, me.person_id, me.person_id), false);
  insert into report.access_log (company_id, person_id, template_id, action) values (me.company_id, me.person_id, o.template_id, 'open_share');
  return jsonb_build_object('rows', o.rows, 'checksum', o.checksum, 'created_at', o.created_at);
end $$;

-- ================================================================ API: backup / recovery / release (service role + read)
create function svc.v1_backup_record(p_kind text, p_environment text, p_started_at timestamptz, p_finished_at timestamptz, p_status text, p_objects integer,
                                     p_manifest_sha256 text, p_last_committed_at timestamptz, p_key_id text, p_operator text, p_retained_until date) returns uuid
language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  if p_key_id ~* '(password|secret|BEGIN [A-Z ]*PRIVATE KEY)' then perform core.fn_raise('E_INVALID_ACTION', 'store a key reference, never a key'); end if;
  insert into core.backup_run (kind, environment, started_at, finished_at, status, objects, checksum_manifest_sha256, last_committed_at, key_id, operator, retained_until)
  values (p_kind, p_environment, p_started_at, p_finished_at, p_status, p_objects, p_manifest_sha256, p_last_committed_at, p_key_id, p_operator, p_retained_until) returning id into v_id;
  return v_id;
end $$;

create function api.v1_recovery_drill_record(p_target_env text, p_backup_run_id uuid, p_company_id uuid, p_started_at timestamptz, p_restored_at timestamptz,
                                             p_evidence_sha256 text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; b core.backup_run%rowtype; v_rpo numeric; v_rto numeric;
begin
  select * into me from iam.fn_require('ops.backup.read', iam.fn_my_company_resource(), true);
  if p_target_env not in ('staging','isolated') then perform core.fn_raise('E_INVALID_ACTION', 'never restore-test on production'); end if;
  select * into b from core.backup_run where id = p_backup_run_id;
  v_rpo := round(extract(epoch from (p_started_at - b.last_committed_at)) / 60, 1);
  v_rto := round(extract(epoch from (p_restored_at - p_started_at)) / 60, 1);
  insert into core.recovery_drill (target_env, backup_run_id, company_id, started_at, service_restored_at, rpo_minutes, rto_minutes, evidence_sha256, operator_id)
  values (p_target_env, p_backup_run_id, p_company_id, p_started_at, p_restored_at, v_rpo, v_rto, lower(p_evidence_sha256), me.person_id) returning id into v_id;
  return jsonb_build_object('drill_id', v_id, 'rpo_minutes', v_rpo, 'rto_minutes', v_rto, 'rpo_target_met', v_rpo <= 60, 'rto_target_met', v_rto <= 240);
end $$;

create function api.v1_recovery_drill_approve(p_drill_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d core.recovery_drill%rowtype;
begin
  select * into me from iam.fn_require('ops.drill.approve', iam.fn_my_company_resource(), true);
  select * into d from core.recovery_drill where id = p_drill_id for update;
  if not found or d.approver_id is not null then perform core.fn_raise('E_NOT_FOUND', 'unapproved drill'); end if;
  if d.operator_id = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  update core.recovery_drill set approver_id = me.person_id, approved_at = clock_timestamp() where id = d.id;
  return jsonb_build_object('drill_id', d.id, 'approved', true);
end $$;

-- Company-scoped restore manifest (F258): per-table row counts + checksums for one company (compare before / after a restore).
create function svc.v1_tenant_manifest(p_company uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare t record; v_count bigint; v_sum text; out jsonb := '{}'::jsonb;
begin
  perform set_config('mohona.company_scope', '', true);
  for t in select c.table_schema s, c.table_name n from information_schema.columns c join information_schema.tables x on x.table_schema = c.table_schema and x.table_name = c.table_name
            where c.column_name = 'company_id' and x.table_type = 'BASE TABLE'
              and c.table_schema in ('core','iam','config','design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify','location','hardware')
            order by 1, 2 loop
    execute format('select count(*), md5(coalesce(string_agg(md5(x::text), '''' order by md5(x::text)), '''')) from %I.%I x where x.company_id = $1', t.s, t.n)
      into v_count, v_sum using p_company;
    out := out || jsonb_build_object(t.s || '.' || t.n, jsonb_build_object('rows', v_count, 'checksum', v_sum));
  end loop;
  return out;
end $$;

create function api.v1_ops_status() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('ops.backup.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'last_backup', (select jsonb_build_object('kind', b.kind, 'finished_at', b.finished_at, 'status', b.status, 'last_committed_at', b.last_committed_at)
                      from core.backup_run b where b.environment = 'production' order by b.started_at desc limit 1),
    'rpo_minutes_now', (select round(extract(epoch from clock_timestamp() - max(b.last_committed_at)) / 60, 1) from core.backup_run b where b.environment = 'production' and b.status = 'ok'),
    'last_drill', (select jsonb_build_object('rpo', d.rpo_minutes, 'rto', d.rto_minutes, 'approved', d.approver_id is not null, 'at', d.started_at)
                     from core.recovery_drill d order by d.started_at desc limit 1));
end $$;

create function api.v1_release_signoff(p_release text, p_area text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('ops.release.signoff', iam.fn_my_company_resource(), true);
  if exists (select 1 from core.release_signoff s where s.release = p_release and s.person_id = me.person_id) then
    perform core.fn_raise('E_SELF_APPROVAL', 'each area is signed by a different person');
  end if;
  insert into core.release_signoff (release, area, person_id, note) values (p_release, p_area, me.person_id, p_note);
  return jsonb_build_object('release', p_release, 'signed', (select jsonb_agg(s.area) from core.release_signoff s where s.release = p_release),
                            'ready', (select count(*) from core.release_signoff s where s.release = p_release) = 4);
end $$;

select core.fn_assert_rls_everywhere();
reset role;
do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_report_datasets()', 'api.v1_report_templates()', 'api.v1_report_template_save(text, text, text, jsonb)', 'api.v1_report_template_action(uuid, text)',
      'api.v1_report_run(uuid, jsonb, text)', 'api.v1_report_drill(text, uuid)', 'api.v1_report_schedule(uuid, text, uuid[], jsonb)', 'api.v1_report_share(uuid, uuid, integer)',
      'api.v1_report_open_shared(text)', 'api.v1_recovery_drill_record(text, uuid, uuid, timestamptz, timestamptz, text)', 'api.v1_recovery_drill_approve(uuid)',
      'api.v1_ops_status()', 'api.v1_release_signoff(text, text, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    foreach f in array array['svc.v1_report_run_schedules()', 'svc.v1_backup_record(text, text, timestamptz, timestamptz, text, integer, text, timestamptz, text, text, date)',
      'svc.v1_tenant_manifest(uuid)'] loop
      execute format('grant execute on function %s to service_role', f);
    end loop;
  end if;
end $$;

-- 20261108001100_core_documents_approval_breakglass.sql  (S12)
-- Document foundation used by every business module:
--  * ADR-01 numbering: unique (company, document_type, number), allocated under a series row lock inside the posting
--    transaction; voided numbers are never reused; prefix/padding/period-reset are Chairman options.
--  * Idempotency registry: same key + same payload -> original result; same key + different payload -> E_IDEMPOTENCY_MISMATCH;
--    a timed-out client asks api.v1_core_request_status before retrying (ADR rule "timeout is not evidence").
--  * ADR-02 approval engine / maker-checker: Chairman-configurable approval matrix per document type and amount band,
--    independent checker (Chairman's own documents need someone else unless the Chairman switches self-approval on),
--    pinned policy snapshot, handlers for governance documents (ADR-06 MD appointment review switch).
--  * ADR-03 break-glass: off by default; when on, N distinct custodians (MFA) approve a time-boxed, least-privilege grant
--    that can never include posting permissions; expiry enforced on every RPC; post-use review.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ numbering
create table core.number_series (
  company_id     uuid not null references core.company(id),
  document_type  text not null check (document_type ~ '^[a-z][a-z0-9_.]{1,60}$'),
  prefix         text not null check (prefix ~ '^[A-Z0-9-]{1,12}$'),
  padding        integer not null default 6 check (padding between 3 and 12),
  reset_policy   text not null default 'yearly' check (reset_policy in ('never','yearly','monthly')),
  period_key     text not null default '',
  next_value     bigint not null default 1 check (next_value >= 1),
  id             uuid not null default gen_random_uuid() unique,
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1,
  primary key (company_id, document_type)
);
create trigger trg_number_series_touch before update on core.number_series for each row execute function core.fn_touch_row();
create trigger trg_number_series_nodel before delete on core.number_series for each row execute function core.fn_deny_delete();
create trigger trg_number_series_audit after insert or update on core.number_series for each row execute function audit.fn_row_change();

create table core.document_number (
  company_id     uuid not null references core.company(id),
  document_type  text not null,
  number         text not null,
  document_id    uuid,
  status         text not null default 'issued' check (status in ('issued','voided')),
  issued_at      timestamptz not null default clock_timestamp(),
  voided_at      timestamptz,
  void_reason    text,
  id             uuid not null default gen_random_uuid() unique,
  primary key (company_id, document_type, number),
  check ((status = 'voided') = (voided_at is not null))
);
create function core.fn_document_number_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','voided_at','void_reason','document_id']) <> (to_jsonb(new) - array['status','voided_at','void_reason','document_id'])
     or old.status = 'voided' or (old.document_id is not null and new.document_id is distinct from old.document_id) then
    raise exception 'E_IMMUTABLE: an issued number never changes and is never reused' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_document_number_guard before update on core.document_number for each row execute function core.fn_document_number_guard();
create trigger trg_document_number_nodel before delete on core.document_number for each row execute function core.fn_deny_delete();

-- Allocates the next number (call inside the posting transaction; the series row lock serialises allocation).
create function core.fn_next_number(p_company uuid, p_document_type text, p_document_id uuid default null) returns text
language plpgsql security definer set search_path = pg_catalog as $$
declare s core.number_series%rowtype; v_period text; v_no text; v_tz text;
begin
  insert into core.number_series (company_id, document_type, prefix)
  values (p_company, p_document_type, left(upper(regexp_replace(regexp_replace(p_document_type, '^.*\.', ''), '[^a-z0-9]', '', 'gi')), 12))
  on conflict do nothing;
  select * into s from core.number_series where company_id = p_company and document_type = p_document_type for update;
  select timezone into v_tz from core.company where id = p_company;
  v_period := case s.reset_policy when 'yearly' then to_char(clock_timestamp() at time zone v_tz, 'YYYY')
                                  when 'monthly' then to_char(clock_timestamp() at time zone v_tz, 'YYYYMM') else '' end;
  if v_period <> s.period_key then s.next_value := 1; s.period_key := v_period; end if;
  loop      -- a format change (prefix/reset) can never re-issue an existing number: skip any number already issued
    v_no := s.prefix || case when v_period <> '' then '-' || v_period else '' end || '-' || lpad(s.next_value::text, s.padding, '0');
    exit when not exists (select 1 from core.document_number d where d.company_id = p_company and d.document_type = p_document_type and d.number = v_no);
    s.next_value := s.next_value + 1;
  end loop;
  update core.number_series set next_value = s.next_value + 1, period_key = s.period_key where company_id = p_company and document_type = p_document_type;
  insert into core.document_number (company_id, document_type, number, document_id) values (p_company, p_document_type, v_no, p_document_id);
  return v_no;
end $$;

create function core.fn_void_number(p_company uuid, p_document_type text, p_number text, p_reason text) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  update core.document_number set status = 'voided', voided_at = clock_timestamp(), void_reason = p_reason
   where company_id = p_company and document_type = p_document_type and number = p_number and status = 'issued';
  if not found then raise exception 'E_NOT_FOUND: number %', p_number using errcode = 'P0001'; end if;
end $$;

-- ================================================================ idempotency
create table core.idempotency_request (
  company_id     uuid not null references core.company(id),
  idem_key       text not null check (length(idem_key) between 8 and 200),
  rpc_name       text not null,
  request_hash   text not null,
  person_id      uuid,
  response       jsonb,
  created_at     timestamptz not null default clock_timestamp(),
  completed_at   timestamptz,
  id             uuid not null default gen_random_uuid() unique,
  primary key (company_id, idem_key)
);
create trigger trg_idempotency_nodel before delete on core.idempotency_request for each row execute function core.fn_deny_delete();

create function core.fn_request_header(p_name text) returns text
language plpgsql stable set search_path = pg_catalog as $$
begin
  return nullif(current_setting('request.headers', true), '')::json ->> lower(p_name);
exception when others then return null;
end $$;

-- Returns the stored response for a completed identical request, or NULL to proceed. A failed request rolls back its
-- own registry row, so it can be retried with the same key.
create function core.fn_idem_begin(p_company uuid, p_rpc text, p_payload jsonb, p_key text default null) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_key text := coalesce(p_key, core.fn_request_header('idempotency-key')); v_hash text; r core.idempotency_request%rowtype;
begin
  if v_key is null then return null; end if;                      -- no key = no replay protection requested
  v_hash := encode(digest(p_rpc || '|' || coalesce(p_payload, '{}'::jsonb)::text, 'sha256'), 'hex');
  insert into core.idempotency_request (company_id, idem_key, rpc_name, request_hash, person_id)
  values (p_company, v_key, p_rpc, v_hash, iam.fn_current_person()) on conflict do nothing;
  select * into r from core.idempotency_request where company_id = p_company and idem_key = v_key for update;
  if r.rpc_name <> p_rpc or r.request_hash <> v_hash then
    raise exception 'E_IDEMPOTENCY_MISMATCH: key % was used for a different request', v_key using errcode = 'P0001';
  end if;
  if r.completed_at is not null then return coalesce(r.response, 'null'::jsonb); end if;
  perform set_config('mohona.idem_key', v_key, true);
  return null;
end $$;

create function core.fn_idem_finish(p_company uuid, p_response jsonb) returns jsonb
language plpgsql security definer set search_path = pg_catalog as $$
declare v_key text := nullif(current_setting('mohona.idem_key', true), '');
begin
  if v_key is not null then
    update core.idempotency_request set response = p_response, completed_at = clock_timestamp()
     where company_id = p_company and idem_key = v_key and completed_at is null;
    perform set_config('mohona.idem_key', '', true);
  end if;
  return p_response;
end $$;

-- ================================================================ approval engine (ADR-02)
create table config.approval_policy (
  id                   uuid primary key default gen_random_uuid(),
  company_id           uuid not null references core.company(id),
  document_type        text not null check (document_type ~ '^[a-z][a-z0-9_.]{1,60}$'),
  min_amount           numeric(20,4) not null default 0 check (min_amount >= 0),
  required_approvals   integer not null default 1 check (required_approvals between 1 and 10),
  approver_permission  text references iam.permission_catalog(code),
  status               text not null default 'active' check (status in ('active','superseded')),
  version              integer not null default 1,
  reason               text not null check (length(btrim(reason)) > 0),
  set_by               uuid,
  set_at               timestamptz not null default clock_timestamp()
);
create unique index approval_policy_active on config.approval_policy (company_id, document_type, min_amount) where status = 'active';
create trigger trg_approval_policy_guard before update on config.approval_policy for each row execute function config.fn_flag_value_guard();
create trigger trg_approval_policy_nodel before delete on config.approval_policy for each row execute function core.fn_deny_delete();
create trigger trg_approval_policy_audit after insert or update on config.approval_policy for each row execute function audit.fn_row_change();

create table core.approval_request (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null references core.company(id),
  document_type       text not null,
  document_id         uuid not null,
  amount              numeric(20,4) not null default 0,
  resource            jsonb not null default '{}'::jsonb,      -- server-built iam.resource fields (wing, department, ...)
  payload             jsonb,                                   -- for governance handlers (e.g. iam.md_appointment)
  maker_person_id     uuid not null references core.person(id),
  maker_assignment_id uuid,
  maker_is_supreme    boolean not null default false,
  required_approvals  integer not null check (required_approvals >= 1),
  approver_permission text,
  policy_snapshot     jsonb not null,
  module_version      text,
  status              text not null default 'pending' check (status in ('pending','approved','rejected','cancelled')),
  created_at          timestamptz not null default clock_timestamp(),
  decided_at          timestamptz,
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id),
  check ((status = 'pending') = (decided_at is null))
);
create unique index approval_one_pending on core.approval_request (company_id, document_type, document_id) where status = 'pending';
create trigger trg_approval_request_touch before update on core.approval_request for each row execute function core.fn_touch_row();
create trigger trg_approval_request_nodel before delete on core.approval_request for each row execute function core.fn_deny_delete();
create trigger trg_approval_request_audit after insert or update on core.approval_request for each row execute function audit.fn_row_change();

create table core.approval_decision (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  request_id          uuid not null,
  decider_person_id   uuid not null references core.person(id),
  decider_assignment_id uuid,
  decision            text not null check (decision in ('approve','reject')),
  reason              text not null check (length(btrim(reason)) > 0),
  rule_reason         text,
  at                  timestamptz not null default clock_timestamp(),
  unique (request_id, decider_person_id),
  foreign key (request_id, company_id) references core.approval_request (id, company_id)
);
create trigger trg_approval_decision_no_mutation before update or delete on core.approval_decision for each row execute function core.fn_deny_mutation();
create trigger trg_approval_decision_audit after insert on core.approval_decision for each row execute function audit.fn_row_change();

-- Submit a document for approval (called by module RPCs inside their transaction, after fn_require).
-- Returns the request row as jsonb: status 'approved' immediately when maker-checker is switched off by the Chairman.
create function core.fn_approval_submit(p_company uuid, p_document_type text, p_document_id uuid, p_amount numeric,
                                        p_resource iam.resource, p_payload jsonb default null, p_module_version text default null)
returns jsonb language plpgsql security definer set search_path = pg_catalog as $$
declare c record; pol config.approval_policy%rowtype; v_id uuid; v_status text := 'pending';
begin
  select * into c from iam.fn_context(true);
  if c.company_id <> p_company then raise exception 'E_WRONG_COMPANY' using errcode = 'P0001'; end if;
  select * into pol from config.approval_policy
   where company_id = p_company and document_type = p_document_type and status = 'active' and min_amount <= coalesce(p_amount, 0)
   order by min_amount desc limit 1;
  if not config.fn_get_bool(p_company, 'approval.maker_checker.enabled') then v_status := 'approved'; end if;
  insert into core.approval_request (company_id, document_type, document_id, amount, resource, payload, maker_person_id, maker_assignment_id,
                                     maker_is_supreme, required_approvals, approver_permission, policy_snapshot, module_version, status, decided_at)
  values (p_company, p_document_type, p_document_id, coalesce(p_amount, 0),
          jsonb_build_object('wing_id', (p_resource).wing_id, 'department_id', (p_resource).department_id, 'location_id', (p_resource).location_id,
                             'warehouse_id', (p_resource).warehouse_id, 'owner_person_id', (p_resource).owner_person_id),
          p_payload, c.person_id, c.assignment_id, c.is_supreme, coalesce(pol.required_approvals, 1), pol.approver_permission,
          coalesce(to_jsonb(pol), jsonb_build_object('default', true, 'required_approvals', 1)), p_module_version, v_status,
          case when v_status = 'approved' then clock_timestamp() end)
  returning id into v_id;
  return jsonb_build_object('request_id', v_id, 'status', v_status);
end $$;

create function core.fn_approval_status(p_company uuid, p_document_type text, p_document_id uuid) returns text
language sql stable security definer set search_path = pg_catalog as $$
  select status from core.approval_request where company_id = p_company and document_type = p_document_type and document_id = p_document_id
   order by created_at desc limit 1
$$;

-- Can the current context decide this request? Returns null when yes, else the refusal code.
create function core.fn_approval_can_decide(r core.approval_request, p_person uuid, p_is_supreme boolean) returns text
language plpgsql stable security definer set search_path = pg_catalog as $$
declare res iam.resource; d record;
begin
  if r.status <> 'pending' then return 'E_INVALID_ACTION'; end if;
  if r.maker_person_id = p_person and not (p_is_supreme and config.fn_get_bool(r.company_id, 'approval.chairman_self_approval.allowed')) then
    return 'E_SELF_APPROVAL';
  end if;
  if exists (select 1 from core.approval_decision x where x.request_id = r.id and x.decider_person_id = p_person) then return 'E_DUPLICATE'; end if;
  res := iam.fn_resource(r.company_id, (r.resource ->> 'wing_id')::uuid, (r.resource ->> 'department_id')::uuid, (r.resource ->> 'location_id')::uuid,
                         (r.resource ->> 'warehouse_id')::uuid, (r.resource ->> 'owner_person_id')::uuid, null);
  select * into d from iam.fn_authorize('approval.decide', res, false);
  if not d.allowed then return 'E_FORBIDDEN'; end if;
  if r.approver_permission is not null then
    select * into d from iam.fn_authorize(r.approver_permission, res, false);
    if not d.allowed then return 'E_FORBIDDEN'; end if;
  end if;
  return null;
end $$;

-- ADR-06 handler: MD appointment applied only after independent approval (when the Chairman switched review on).
create function iam.fn_apply_md_appointment(p_company uuid, p jsonb) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind, valid_from, valid_until, home_wing_id, home_department_id, home_location_id)
  values (p_company, (p ->> 'membership_id')::uuid, 'MD', coalesce(p ->> 'kind', 'regular'), coalesce((p ->> 'valid_from')::timestamptz, clock_timestamp()),
          (p ->> 'valid_until')::timestamptz, (p ->> 'home_wing')::uuid, (p ->> 'home_department')::uuid, (p ->> 'home_location')::uuid);
end $$;

-- ================================================================ break-glass (ADR-03)
create table iam.breakglass_custodian (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  person_id    uuid not null references core.person(id),
  status       text not null default 'active' check (status in ('active','revoked')),
  appointed_by uuid,
  appointed_at timestamptz not null default clock_timestamp(),
  revoked_at   timestamptz,
  check ((status = 'revoked') = (revoked_at is not null))
);
create unique index breakglass_custodian_active on iam.breakglass_custodian (company_id, person_id) where status = 'active';
create trigger trg_bg_custodian_nodel before delete on iam.breakglass_custodian for each row execute function core.fn_deny_delete();
create trigger trg_bg_custodian_audit after insert or update on iam.breakglass_custodian for each row execute function audit.fn_row_change();

create table iam.breakglass_grant (
  id                 uuid primary key default gen_random_uuid(),
  company_id         uuid not null references core.company(id),
  requester_person   uuid not null references core.person(id),
  target_assignment  uuid not null,
  permission_codes   text[] not null check (cardinality(permission_codes) between 1 and 20),
  reason             text not null check (length(btrim(reason)) > 0),
  status             text not null default 'requested' check (status in ('requested','active','rejected','revoked','expired')),
  approvals_required integer not null,
  requested_at       timestamptz not null default clock_timestamp(),
  activated_at       timestamptz,
  expires_at         timestamptz,
  closed_at          timestamptz,
  review_notes       text,
  reviewed_by        uuid,
  reviewed_at        timestamptz,
  updated_at         timestamptz not null default clock_timestamp(),
  row_version        integer not null default 1,
  unique (id, company_id),
  foreign key (target_assignment, company_id) references iam.position_assignment (id, company_id)
);
create trigger trg_bg_grant_touch before update on iam.breakglass_grant for each row execute function core.fn_touch_row();
create trigger trg_bg_grant_nodel before delete on iam.breakglass_grant for each row execute function core.fn_deny_delete();
create trigger trg_bg_grant_audit after insert or update on iam.breakglass_grant for each row execute function audit.fn_row_change();

create table iam.breakglass_approval (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  grant_id        uuid not null,
  custodian_person uuid not null references core.person(id),
  at              timestamptz not null default clock_timestamp(),
  unique (grant_id, custodian_person),
  foreign key (grant_id, company_id) references iam.breakglass_grant (id, company_id)
);
create trigger trg_bg_approval_no_mutation before update or delete on iam.breakglass_approval for each row execute function core.fn_deny_mutation();
create trigger trg_bg_approval_audit after insert on iam.breakglass_approval for each row execute function audit.fn_row_change();

alter table iam.assignment_permission_rule drop constraint assignment_permission_rule_origin_check;
alter table iam.assignment_permission_rule add constraint assignment_permission_rule_origin_check check (origin in ('chairman','manager','delegation','breakglass'));
alter table iam.assignment_permission_rule add column breakglass_id uuid;

select core.fn_apply_rls('core', 'number_series');
select core.fn_apply_rls('core', 'document_number');
select core.fn_apply_rls('core', 'idempotency_request');
select core.fn_apply_rls('config', 'approval_policy');
select core.fn_apply_rls('core', 'approval_request');
select core.fn_apply_rls('core', 'approval_decision');
select core.fn_apply_rls('iam', 'breakglass_custodian');
select core.fn_apply_rls('iam', 'breakglass_grant');
select core.fn_apply_rls('iam', 'breakglass_approval');

-- ================================================================ permissions & module
update iam.permission_catalog set allowed_scopes = array['COMPANY','WING','DEPARTMENT','ASSIGNED'] where code in ('approval.inbox.read','approval.decide');
update iam.permission_catalog set status = 'active' where code in ('approval.inbox.read','approval.decide','approval.override','approval.reassign','config.approval_rule.manage');
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('iam.breakglass.request', 'iam', 'জরুরি-প্রবেশের অনুরোধ', 'admin', true, false, array['COMPANY'], 'active', 95),
  ('iam.breakglass.manage',  'iam', 'জরুরি-প্রবেশ রক্ষক নিয়োগ ও পর্যালোচনা', 'admin', true, false, array['COMPANY'], 'active', 96),
  ('core.numbering.manage',  'core', 'ডকুমেন্ট-নম্বর সিরিজ সম্পাদনা', 'admin', false, false, array['COMPANY'], 'active', 105),
  ('core.request.status',    'core', 'অনুরোধের অবস্থা যাচাই', 'read', false, true, array['SELF'], 'active', 106);
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'core.request.status', 'allow', 'SELF' from iam.position_template t where not t.is_supreme
union all select 'MD', 'approval.inbox.read', 'allow', 'COMPANY'
union all select 'MD', 'approval.decide', 'allow', 'COMPANY'
union all select 'FIN_MANAGER', 'approval.inbox.read', 'allow', 'COMPANY'
union all select 'FIN_MANAGER', 'approval.decide', 'allow', 'COMPANY'
union all select 'WING_HEAD', 'approval.inbox.read', 'allow', 'WING'
union all select 'WING_HEAD', 'approval.decide', 'allow', 'WING';
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('approval');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, name_bn, description_bn, is_sensitive, sort_order) values
  ('approval.request.max_open_days', 'approval', 'int', '30', 1, 365, 'অনুমোদন-অনুরোধ খোলা থাকার সর্বোচ্চ দিন (রিপোর্টে সতর্কতা)', 'ADR-02', false, 75);

-- ================================================================ API: request status (timeouts) & numbering
create function api.v1_core_request_status(p_key text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare c record; r core.idempotency_request%rowtype;
begin
  select * into c from iam.fn_context(false);
  select * into r from core.idempotency_request where company_id = c.company_id and idem_key = p_key;
  if not found or r.person_id is distinct from c.person_id then
    return jsonb_build_object('status', 'unknown');               -- never reached the server (or not yours): safe to retry
  end if;
  return jsonb_build_object('status', case when r.completed_at is null then 'in_progress' else 'succeeded' end,
                            'rpc', r.rpc_name, 'response', r.response, 'completed_at', r.completed_at);
end $$;

create function api.v1_core_number_series() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('document_type', s.document_type, 'prefix', s.prefix, 'padding', s.padding,
                         'reset_policy', s.reset_policy, 'next_value', s.next_value, 'period_key', s.period_key, 'row_version', s.row_version) order by s.document_type)
                     from core.number_series s where s.company_id = me.company_id), '[]'::jsonb);
end $$;

-- Prefix / padding / reset changes apply to numbers issued from now on; issued numbers never change.
create function api.v1_core_set_number_series(p_document_type text, p_prefix text, p_padding integer, p_reset_policy text,
                                              p_expected_row_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; s core.number_series%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.numbering.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  select * into s from core.number_series where company_id = me.company_id and document_type = p_document_type for update;
  if not found then
    insert into core.number_series (company_id, document_type, prefix, padding, reset_policy) values (me.company_id, p_document_type, p_prefix, p_padding, p_reset_policy);
    return 1;
  end if;
  if s.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  update core.number_series set prefix = p_prefix, padding = p_padding, reset_policy = p_reset_policy,
         period_key = case when p_reset_policy <> s.reset_policy then '#changed' else period_key end
   where company_id = me.company_id and document_type = p_document_type;
  return s.row_version + 1;
end $$;

-- ================================================================ API: approval matrix & inbox
create function api.v1_approval_policies() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'document_type', p.document_type, 'min_amount', p.min_amount,
                         'required_approvals', p.required_approvals, 'approver_permission', p.approver_permission, 'version', p.version, 'reason', p.reason)
                         order by p.document_type, p.min_amount)
                     from config.approval_policy p where p.company_id = me.company_id and p.status = 'active'), '[]'::jsonb);
end $$;

-- Sets (or replaces) the band "document_type, amount >= min_amount". p_required_approvals = 0 removes the band.
create function api.v1_approval_set_policy(p_document_type text, p_min_amount numeric, p_required_approvals integer,
                                           p_approver_permission text, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; cur config.approval_policy%rowtype; v integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.approval_rule.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  select * into cur from config.approval_policy where company_id = me.company_id and document_type = p_document_type
                                                  and min_amount = coalesce(p_min_amount, 0) and status = 'active' for update;
  if cur.id is not null then update config.approval_policy set status = 'superseded' where id = cur.id; end if;
  if coalesce(p_required_approvals, 0) = 0 then return 0; end if;
  v := coalesce(cur.version, 0) + 1;
  insert into config.approval_policy (company_id, document_type, min_amount, required_approvals, approver_permission, version, reason, set_by)
  values (me.company_id, p_document_type, coalesce(p_min_amount, 0), p_required_approvals, p_approver_permission, v, p_reason, me.person_id);
  return v;
end $$;

create function api.v1_approval_inbox() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('approval.inbox.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'document_type', r.document_type, 'document_id', r.document_id, 'amount', r.amount,
                         'maker_person_id', r.maker_person_id, 'maker_name_bn', (select p.full_name_bn from core.person p where p.id = r.maker_person_id),
                         'required_approvals', r.required_approvals,
                         'approvals', (select count(*) from core.approval_decision d where d.request_id = r.id and d.decision = 'approve'),
                         'created_at', r.created_at, 'row_version', r.row_version) order by r.created_at)
                     from core.approval_request r
                    where r.company_id = me.company_id and r.status = 'pending'
                      and core.fn_approval_can_decide(r, me.person_id, me.is_supreme) is null), '[]'::jsonb);
end $$;

create function api.v1_approval_decide(p_request_id uuid, p_decision text, p_expected_row_version integer, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare c record; r core.approval_request%rowtype; v_err text; v_ok integer; v_status text;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_decision not in ('approve','reject') then perform core.fn_raise('E_INVALID_ACTION', p_decision); end if;
  select * into c from iam.fn_context(true);
  select * into r from core.approval_request where id = p_request_id and company_id = c.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'approval request'); end if;
  if r.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  v_err := core.fn_approval_can_decide(r, c.person_id, c.is_supreme);
  if v_err is not null then perform core.fn_raise(v_err, 'approval'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into core.approval_decision (company_id, request_id, decider_person_id, decider_assignment_id, decision, reason)
  values (c.company_id, r.id, c.person_id, c.assignment_id, p_decision, p_reason);
  select count(*) into v_ok from core.approval_decision where request_id = r.id and decision = 'approve';
  v_status := case when p_decision = 'reject' then 'rejected' when v_ok >= r.required_approvals then 'approved' else 'pending' end;
  if v_status <> 'pending' then
    update core.approval_request set status = v_status, decided_at = clock_timestamp() where id = r.id;
    if v_status = 'approved' and r.document_type = 'iam.md_appointment' then
      perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    end if;
  else
    update core.approval_request set updated_at = clock_timestamp() where id = r.id;
  end if;
  return jsonb_build_object('status', v_status, 'approvals', v_ok, 'required', r.required_approvals);
end $$;

create function api.v1_approval_cancel(p_request_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare c record; r core.approval_request%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into c from iam.fn_context(true);
  select * into r from core.approval_request where id = p_request_id and company_id = c.company_id and status = 'pending' for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'pending request'); end if;
  if r.maker_person_id <> c.person_id and not c.is_supreme then perform core.fn_raise('E_FORBIDDEN', 'only the maker or the Chairman cancels'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update core.approval_request set status = 'cancelled', decided_at = clock_timestamp() where id = r.id;
end $$;

create function api.v1_approval_my_requests() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare c record;
begin
  select * into c from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'document_type', r.document_type, 'document_id', r.document_id, 'amount', r.amount,
                         'status', r.status, 'required_approvals', r.required_approvals,
                         'decisions', coalesce((select jsonb_agg(jsonb_build_object('decision', d.decision, 'reason', d.reason, 'at', d.at,
                                                   'decider_name_bn', (select p.full_name_bn from core.person p where p.id = d.decider_person_id)) order by d.at)
                                                  from core.approval_decision d where d.request_id = r.id), '[]'::jsonb),
                         'created_at', r.created_at) order by r.created_at desc)
                     from core.approval_request r where r.company_id = c.company_id and r.maker_person_id = c.person_id), '[]'::jsonb);
end $$;

-- ADR-06: MD appointment goes through independent review when the Chairman switched it on.
create or replace function api.v1_iam_assign_position(p_membership_id uuid, p_position_code text, p_valid_from timestamptz, p_valid_until timestamptz,
                                           p_kind text, p_home_wing uuid, p_home_department uuid, p_home_location uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare me record; m iam.company_membership%rowtype; v uuid; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.assignment.manage',
           iam.fn_resource(iam.fn_context_company(), p_home_wing, p_home_department, p_home_location), true);
  select * into m from iam.company_membership where id = p_membership_id and company_id = me.company_id for no key update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, p_position_code, m.person_id);
  perform set_config('mohona.change_reason', p_reason, true);
  if p_position_code = 'MD' and config.fn_get_bool(me.company_id, 'iam.md_appointment.requires_review') then
    v := gen_random_uuid();
    j := core.fn_approval_submit(me.company_id, 'iam.md_appointment', v, 0, iam.fn_resource(me.company_id),
           jsonb_build_object('membership_id', m.id, 'kind', coalesce(p_kind, 'regular'), 'valid_from', p_valid_from, 'valid_until', p_valid_until,
                              'home_wing', p_home_wing, 'home_department', p_home_department, 'home_location', p_home_location, 'reason', p_reason));
    if j ->> 'status' = 'approved' then
      perform iam.fn_apply_md_appointment(me.company_id, (select payload from core.approval_request where id = (j ->> 'request_id')::uuid));
    end if;
    return (j ->> 'request_id')::uuid;            -- caller sees an approval request id (pending until reviewed)
  end if;
  insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind, valid_from, valid_until,
                                       home_wing_id, home_department_id, home_location_id)
  values (me.company_id, m.id, p_position_code, coalesce(p_kind, 'regular'), coalesce(p_valid_from, clock_timestamp()), p_valid_until,
          p_home_wing, p_home_department, p_home_location)
  returning id into v;
  return v;
end $$;

-- ================================================================ API: break-glass
create function api.v1_breakglass_set_custodian(p_person_id uuid, p_active boolean, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.breakglass.manage', iam.fn_my_company_resource(), true);
  if not iam.fn_is_active_member(p_person_id, me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'member'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_active then
    insert into iam.breakglass_custodian (company_id, person_id, appointed_by) values (me.company_id, p_person_id, me.person_id) on conflict do nothing;
  else
    update iam.breakglass_custodian set status = 'revoked', revoked_at = clock_timestamp() where company_id = me.company_id and person_id = p_person_id and status = 'active';
  end if;
end $$;

-- Request: MFA, feature on, no posting permission, only permissions that exist and are active.
create function api.v1_breakglass_request(p_permissions text[], p_reason text) returns uuid
language plpgsql security definer set search_path = '' as $$
declare me record; v uuid; v_bad text;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.breakglass.request', iam.fn_my_company_resource(), true);
  if not config.fn_get_bool(me.company_id, 'breakglass.enabled') then perform core.fn_raise('E_FEATURE_DISABLED', 'break-glass is off'); end if;
  if core.fn_jwt_claim('aal') is distinct from 'aal2' then perform core.fn_raise('E_MFA_REQUIRED'); end if;
  select string_agg(x, ', ') into v_bad from unnest(p_permissions) x
   where not exists (select 1 from iam.permission_catalog pc where pc.code = x and pc.status = 'active' and pc.action_kind <> 'post' and 'COMPANY' = any (pc.allowed_scopes));
  if v_bad is not null then perform core.fn_raise('E_BREAKGLASS_SCOPE', v_bad); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.breakglass_grant (company_id, requester_person, target_assignment, permission_codes, reason, approvals_required)
  values (me.company_id, me.person_id, me.assignment_id, p_permissions, p_reason, config.fn_get_int(me.company_id, 'breakglass.custodians_required'))
  returning id into v;
  return v;
end $$;

create function api.v1_breakglass_approve(p_grant_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare c record; g iam.breakglass_grant%rowtype; n integer; v_exp timestamptz;
begin
  select * into c from iam.fn_context(true);
  if core.fn_jwt_claim('aal') is distinct from 'aal2' then perform core.fn_raise('E_MFA_REQUIRED'); end if;
  select * into g from iam.breakglass_grant where id = p_grant_id and company_id = c.company_id for update;
  if not found or g.status <> 'requested' then perform core.fn_raise('E_INVALID_ACTION', 'grant not awaiting approval'); end if;
  if not exists (select 1 from iam.breakglass_custodian bc where bc.company_id = c.company_id and bc.person_id = c.person_id and bc.status = 'active') then
    perform core.fn_raise('E_FORBIDDEN', 'not a custodian');
  end if;
  if g.requester_person = c.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  insert into iam.breakglass_approval (company_id, grant_id, custodian_person) values (c.company_id, g.id, c.person_id);
  select count(*) into n from iam.breakglass_approval where grant_id = g.id;
  if n >= g.approvals_required then
    v_exp := clock_timestamp() + make_interval(mins => config.fn_get_int(c.company_id, 'breakglass.max_minutes'));
    update iam.breakglass_grant set status = 'active', activated_at = clock_timestamp(), expires_at = v_exp where id = g.id;
    perform set_config('mohona.change_reason', 'break-glass activated: ' || g.reason, true);
    insert into iam.assignment_permission_rule (company_id, assignment_id, permission_code, effect, scope_kind, valid_until, origin, created_by, reason, breakglass_id)
    select c.company_id, g.target_assignment, x, 'allow', 'COMPANY', v_exp, 'breakglass', c.person_id, g.reason, g.id from unnest(g.permission_codes) x
    on conflict do nothing;
    return jsonb_build_object('status', 'active', 'expires_at', v_exp);
  end if;
  return jsonb_build_object('status', 'requested', 'approvals', n, 'required', g.approvals_required);
end $$;

create function api.v1_breakglass_close(p_grant_id uuid, p_action text, p_notes text) returns void
language plpgsql security definer set search_path = '' as $$
declare c record; g iam.breakglass_grant%rowtype; d record;
begin
  if length(btrim(coalesce(p_notes, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into c from iam.fn_context(true);
  select * into g from iam.breakglass_grant where id = p_grant_id and company_id = c.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'grant'); end if;
  perform set_config('mohona.change_reason', p_notes, true);
  if p_action = 'revoke' then
    if g.status not in ('requested','active') then perform core.fn_raise('E_INVALID_ACTION'); end if;
    if not (g.requester_person = c.person_id or c.is_supreme
            or exists (select 1 from iam.breakglass_custodian bc where bc.company_id = c.company_id and bc.person_id = c.person_id and bc.status = 'active')) then
      perform core.fn_raise('E_FORBIDDEN');
    end if;
    update iam.breakglass_grant set status = case when g.status = 'requested' then 'rejected' else 'revoked' end, closed_at = clock_timestamp() where id = g.id;
    update iam.assignment_permission_rule set status = 'revoked', revoked_at = clock_timestamp(), revoked_by = c.person_id
     where breakglass_id = g.id and status = 'active';
  elsif p_action = 'review' then
    select * into d from iam.fn_authorize('iam.breakglass.manage', iam.fn_resource(c.company_id), false);
    if not d.allowed then perform core.fn_raise('E_FORBIDDEN'); end if;
    if g.status = 'active' and g.expires_at <= clock_timestamp() then
      update iam.breakglass_grant set status = 'expired', closed_at = g.expires_at where id = g.id;
    elsif g.status not in ('revoked','expired','rejected') then
      perform core.fn_raise('E_INVALID_ACTION', 'review after the grant has ended');
    end if;
    if g.requester_person = c.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'requester cannot review own use'); end if;
    update iam.breakglass_grant set review_notes = p_notes, reviewed_by = c.person_id, reviewed_at = clock_timestamp() where id = g.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action);
  end if;
end $$;

create function api.v1_breakglass_list() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare c record;
begin
  select * into c from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', g.id, 'requester_person', g.requester_person, 'permission_codes', to_jsonb(g.permission_codes),
                         'reason', g.reason, 'status', case when g.status = 'active' and g.expires_at <= clock_timestamp() then 'expired' else g.status end,
                         'approvals', (select count(*) from iam.breakglass_approval a where a.grant_id = g.id), 'approvals_required', g.approvals_required,
                         'expires_at', g.expires_at, 'reviewed', g.reviewed_at is not null) order by g.requested_at desc)
                     from iam.breakglass_grant g
                    where g.company_id = c.company_id
                      and (c.is_supreme or g.requester_person = c.person_id
                           or exists (select 1 from iam.breakglass_custodian bc where bc.company_id = c.company_id and bc.person_id = c.person_id and bc.status = 'active'))), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_core_request_status(text)', 'api.v1_core_number_series()',
      'api.v1_core_set_number_series(text, text, integer, text, integer, text)', 'api.v1_approval_policies()',
      'api.v1_approval_set_policy(text, numeric, integer, text, text)', 'api.v1_approval_inbox()', 'api.v1_approval_decide(uuid, text, integer, text)',
      'api.v1_approval_cancel(uuid, text)', 'api.v1_approval_my_requests()', 'api.v1_breakglass_set_custodian(uuid, boolean, text)',
      'api.v1_breakglass_request(text[], text)', 'api.v1_breakglass_approve(uuid)', 'api.v1_breakglass_close(uuid, text, text)', 'api.v1_breakglass_list()'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

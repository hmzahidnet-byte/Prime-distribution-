-- 20261108004500_version_closure.sql  (ধাপ ৩ / S65 — v1–v180 version folders: V154 new 200 features, V170–V179 decisions; see docs/V180_VERSION_AUDIT_BN.md)
-- Gaps found and closed here (MOS-F154-xxx = V154_NEW_FEATURES):
--   F154-035  time-window permission: a position may act only on given weekdays / hours (Chairman setting per position, optional per permission)
--   F154-037  approval ceiling by amount: a position approves documents only up to a set amount (the Chairman is never limited)
--   F154-034  screenshot / screen-share block per position (Android FLAG_SECURE from the server's answer)
--   F154-030  organisation chart on any past date (who held which position, who reported to whom)
--   F154-045  ingredient / allergen declaration per product, versioned
--   F154-140  final settlement preview on termination (pro-rata pay, unpaid net, advance outstanding) — paid through a supplemental run
--   F154-147  dealer return authorisation before a sales return (Chairman setting, default off; courier returns follow the courier flow)
--   F154-164  movement trail of a field person for one day (consented pings only, same viewing right as the live map)
--   F154-175/176/177  deterministic alert board (low stock, payment mismatches, route exceptions) — read on demand, no alert engine
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('security.screenshot.block_positions', 'security', 'text_array', '[]', null, null, null, 'যে পদে স্ক্রিনশট / স্ক্রিন-শেয়ার বন্ধ', 'F154-034', true, 2530),
  ('sales.return.requires_authorization', 'sales', 'bool', 'false', null, null, null, 'বিক্রয়-ফেরতের আগে অনুমোদন (RMA) লাগবে', 'F154-147', false, 2531),
  ('notify.payment_mismatch.days', 'notify', 'int', '3', '1', '60', null, 'কত দিন অমিল থাকলে "অর্থ-অমিল"', 'F154-176', false, 2532)
on conflict (key) do nothing;

-- ================================================================ F154-035 time-window permission
create table iam.time_window (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  position_code   text not null,
  permission_code text references iam.permission_catalog(code),     -- null = every permission of the position
  weekdays        integer[] not null check (weekdays <@ array[0,1,2,3,4,5,6] and cardinality(weekdays) > 0),
  from_time       time not null,
  to_time         time not null check (to_time > from_time),
  status          text not null default 'active' check (status in ('active','revoked')),
  reason          text not null check (length(btrim(reason)) > 0),
  set_by          uuid not null references core.person(id),
  set_at          timestamptz not null default clock_timestamp(),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create trigger trg_time_window_nodel before delete on iam.time_window for each row execute function core.fn_deny_delete();
create trigger trg_time_window_audit after insert or update on iam.time_window for each row execute function audit.fn_row_change();
select core.fn_apply_rls('iam', 'time_window');

-- Local business time (Asia/Dhaka). No window row = no limit.
create function iam.fn_in_time_window(p_company uuid, p_position text, p_permission text) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select not exists (select 1 from iam.time_window w where w.company_id = p_company and w.position_code = p_position and w.status = 'active'
                       and (w.permission_code is null or w.permission_code = p_permission))
      or exists (select 1 from iam.time_window w where w.company_id = p_company and w.position_code = p_position and w.status = 'active'
                   and (w.permission_code is null or w.permission_code = p_permission)
                   and extract(dow from (now() at time zone 'Asia/Dhaka'))::integer = any (w.weekdays)
                   and (now() at time zone 'Asia/Dhaka')::time between w.from_time and w.to_time)
$$;

create or replace function iam.fn_require(p_permission text, p_resource iam.resource, p_lock boolean default true)
returns table (person_id uuid, company_id uuid, assignment_id uuid, position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare d record;
begin
  select * into d from iam.fn_authorize(p_permission, p_resource, p_lock);
  if not d.allowed then
    raise log 'MOHONA_SECURITY_DENIED person=% company=% assignment=% position=% permission=% reason=% resource_company=% request=%',
      d.person_id, d.company_id, d.assignment_id, d.position_code, p_permission, d.reason, (p_resource).company_id, core.fn_request_id();
    perform core.fn_raise(case d.reason
                            when 'wrong_company' then 'E_WRONG_COMPANY'
                            when 'mfa_required' then 'E_MFA_REQUIRED'
                            when 'permission_not_active' then 'E_FEATURE_NOT_READY'
                            when 'module_disabled' then 'E_FEATURE_DISABLED'
                            when 'module_read_only' then 'E_MODULE_READ_ONLY'
                            else 'E_FORBIDDEN' end, p_permission);
  end if;
  -- F154-035: outside the position's working window nothing is allowed (the Chairman seat is never limited)
  if not coalesce(d.is_supreme, false) and not iam.fn_in_time_window(d.company_id, d.position_code, p_permission) then
    raise log 'MOHONA_SECURITY_DENIED person=% company=% position=% permission=% reason=time_window', d.person_id, d.company_id, d.position_code, p_permission;
    perform core.fn_raise('E_TIME_WINDOW', p_permission);
  end if;
  return query select d.person_id, d.company_id, d.assignment_id, d.position_code, d.is_supreme;
end $$;

create function api.v1_time_window_set(p_position_code text, p_permission_code text, p_weekdays integer[], p_from time, p_to time, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code and pc.is_supreme) then
    perform core.fn_raise('E_PROTECTED_POSITION', 'the Chairman seat has no time window');
  end if;
  if p_weekdays is null or cardinality(p_weekdays) = 0 or not (p_weekdays <@ array[0,1,2,3,4,5,6]) or p_from is null or p_to is null or p_to <= p_from then
    perform core.fn_raise('E_INVALID_ACTION', 'weekdays 0-6 and a time range');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.time_window set status = 'revoked' where company_id = me.company_id and position_code = p_position_code
     and permission_code is not distinct from p_permission_code and status = 'active';
  insert into iam.time_window (company_id, position_code, permission_code, weekdays, from_time, to_time, reason, set_by)
  values (me.company_id, p_position_code, p_permission_code, p_weekdays, p_from, p_to, btrim(p_reason), me.person_id) returning id into v_id;
  return jsonb_build_object('time_window_id', v_id);
end $$;

create function api.v1_time_window_revoke(p_time_window_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.time_window set status = 'revoked' where id = p_time_window_id and company_id = me.company_id and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'active time window'); end if;
  return jsonb_build_object('time_window_id', p_time_window_id, 'status', 'revoked');
end $$;

-- ================================================================ F154-037 approval ceiling by amount
create table config.approval_ceiling (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  position_code  text not null,
  document_type  text,                           -- null = every document type
  max_amount     numeric(20,4) not null check (max_amount >= 0),
  status         text not null default 'active' check (status in ('active','revoked')),
  reason         text not null check (length(btrim(reason)) > 0),
  set_by         uuid not null references core.person(id),
  set_at         timestamptz not null default clock_timestamp(),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index ux_approval_ceiling on config.approval_ceiling (company_id, position_code, coalesce(document_type, '*')) where status = 'active';
create trigger trg_approval_ceiling_nodel before delete on config.approval_ceiling for each row execute function core.fn_deny_delete();
create trigger trg_approval_ceiling_audit after insert or update on config.approval_ceiling for each row execute function audit.fn_row_change();
select core.fn_apply_rls('config', 'approval_ceiling');

create function core.fn_approval_ceiling_check() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare r core.approval_request%rowtype; v_pos text; v_sup boolean; v_max numeric;
begin
  if new.decision <> 'approve' then return new; end if;
  select * into r from core.approval_request where id = new.request_id;
  select pa.position_code, pc.is_supreme into v_pos, v_sup from iam.position_assignment pa
    join iam.position_catalog pc on pc.company_id = pa.company_id and pc.code = pa.position_code where pa.id = new.decider_assignment_id;
  if coalesce(v_sup, false) or v_pos is null then return new; end if;
  select c.max_amount into v_max from config.approval_ceiling c
   where c.company_id = new.company_id and c.position_code = v_pos and c.status = 'active' and (c.document_type = r.document_type or c.document_type is null)
   order by (c.document_type is null) limit 1;
  if v_max is not null and coalesce(r.amount, 0) > v_max then
    raise exception 'E_APPROVAL_CEILING: this position approves up to %', v_max using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_approval_ceiling before insert on core.approval_decision for each row execute function core.fn_approval_ceiling_check();

create function api.v1_approval_ceiling_set(p_position_code text, p_document_type text, p_max_amount numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if coalesce(p_max_amount, -1) < 0 then perform core.fn_raise('E_INVALID_ACTION', 'amount'); end if;
  if not exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code and not pc.is_supreme) then
    perform core.fn_raise('E_NOT_FOUND', 'position (the Chairman has no ceiling)');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update config.approval_ceiling set status = 'revoked'
   where company_id = me.company_id and position_code = p_position_code and document_type is not distinct from p_document_type and status = 'active';
  insert into config.approval_ceiling (company_id, position_code, document_type, max_amount, reason, set_by)
  values (me.company_id, p_position_code, nullif(btrim(p_document_type), ''), p_max_amount, btrim(p_reason), me.person_id) returning id into v_id;
  return jsonb_build_object('ceiling_id', v_id);
end $$;

-- ================================================================ F154-034 screenshot policy for the signed-in position
create function api.v1_screen_policy() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object('block_screenshots', not coalesce(me.is_supreme, false)
                              and me.position_code = any (coalesce(config.fn_get_text_array(me.company_id, 'security.screenshot.block_positions'), array[]::text[])));
end $$;

-- ================================================================ F154-030 organisation chart on a past date
create function api.v1_org_chart_as_of(p_at date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_at timestamptz := (coalesce(p_at, current_date) + 1)::timestamptz - interval '1 second';
begin
  select * into me from iam.fn_require('iam.hierarchy.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object('at', coalesce(p_at, current_date),
    'positions', coalesce((select jsonb_agg(jsonb_build_object('person', p.full_name_bn, 'position', pa.position_code, 'wing_id', pa.home_wing_id,
                                                               'department_id', pa.home_department_id, 'from', pa.valid_from, 'until', coalesce(pa.ended_at, pa.valid_until))
                                            order by pa.position_code, p.full_name_bn)
                             from iam.position_assignment pa join iam.company_membership m on m.id = pa.membership_id join core.person p on p.id = m.person_id
                            where pa.company_id = me.company_id and pa.valid_from <= v_at and (pa.ended_at is null or pa.ended_at > v_at)
                              and (pa.valid_until is null or pa.valid_until > v_at)), '[]'::jsonb),
    'reporting', coalesce((select jsonb_agg(jsonb_build_object('employee', pe.full_name_bn, 'manager', pm.full_name_bn) order by pe.full_name_bn)
                             from hr.reporting_line rl join hr.employee e on e.id = rl.employee_id join core.person pe on pe.id = e.person_id
                             join hr.employee em on em.id = rl.manager_employee_id join core.person pm on pm.id = em.person_id
                            where rl.company_id = me.company_id and rl.valid_from <= v_at and (rl.ended_at is null or rl.ended_at > v_at)), '[]'::jsonb));
end $$;

-- ================================================================ F154-045 ingredient / allergen declaration
create table inventory.product_declaration (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  product_id   uuid not null,
  version      integer not null check (version >= 1),
  ingredients  text not null check (length(btrim(ingredients)) > 0),
  allergens    text[] not null default array[]::text[],
  note         text,
  declared_by  uuid not null references core.person(id),
  declared_at  timestamptz not null default clock_timestamp(),
  unique (product_id, version),
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);
create trigger trg_product_declaration_no_mutation before update or delete on inventory.product_declaration for each row execute function core.fn_deny_mutation();
create trigger trg_product_declaration_audit after insert on inventory.product_declaration for each row execute function audit.fn_row_change();
select core.fn_apply_rls('inventory', 'product_declaration');

create function api.v1_product_declaration_set(p_product_id uuid, p_ingredients text, p_allergens text[], p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_ver integer;
begin
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from inventory.product p where p.id = p_product_id and p.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  if length(btrim(coalesce(p_ingredients, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'ingredients'); end if;
  perform pg_advisory_xact_lock(hashtext('decl' || p_product_id::text));
  v_ver := coalesce((select max(d.version) from inventory.product_declaration d where d.product_id = p_product_id), 0) + 1;
  perform set_config('mohona.change_reason', 'product declaration v' || v_ver, true);
  insert into inventory.product_declaration (company_id, product_id, version, ingredients, allergens, note, declared_by)
  values (me.company_id, p_product_id, v_ver, btrim(p_ingredients), coalesce(p_allergens, array[]::text[]), nullif(btrim(p_note), ''), me.person_id);
  return jsonb_build_object('product_id', p_product_id, 'version', v_ver);
end $$;

create function api.v1_product_declaration(p_product_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_build_object('version', d.version, 'ingredients', d.ingredients, 'allergens', to_jsonb(d.allergens), 'note', d.note, 'declared_at', d.declared_at)
                     from inventory.product_declaration d where d.product_id = p_product_id and d.company_id = me.company_id order by d.version desc limit 1),
                  jsonb_build_object('version', null, 'note_bn', 'ঘোষণা দেওয়া হয়নি'));
end $$;

-- ================================================================ F154-140 final settlement preview
create function api.v1_final_settlement_preview(p_employee_id uuid, p_last_day date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; s hr.salary_structure%rowtype; v_month date; v_dim integer; v_days integer; v_monthly numeric; v_prorata numeric; v_unpaid numeric; v_adv numeric;
        v_posted boolean;
begin
  select * into me from iam.fn_require('hr.payroll.calculate', iam.fn_my_company_resource(), false);
  if not exists (select 1 from hr.employee e where e.id = p_employee_id and e.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'employee'); end if;
  if p_last_day is null then perform core.fn_raise('E_INVALID_ACTION', 'last working day'); end if;
  select * into s from hr.salary_structure x where x.employee_id = p_employee_id and x.effective_from <= p_last_day order by x.effective_from desc limit 1;
  v_month := date_trunc('month', p_last_day)::date;
  v_dim := extract(day from (v_month + interval '1 month' - interval '1 day'))::integer;
  v_days := extract(day from p_last_day)::integer;
  v_monthly := coalesce(s.base, 0)
             + coalesce((select sum((a ->> 'amount')::numeric) from jsonb_array_elements(coalesce(s.allowances, '[]'::jsonb)) a), 0)
             - coalesce((select sum((a ->> 'amount')::numeric) from jsonb_array_elements(coalesce(s.deductions, '[]'::jsonb)) a), 0);
  v_posted := exists (select 1 from hr.payroll_run r join hr.payroll_line l on l.run_id = r.id
                       where r.company_id = me.company_id and r.period = v_month and r.kind = 'regular' and r.status = 'posted' and l.employee_id = p_employee_id);
  v_prorata := case when v_posted then 0 else round(v_monthly * v_days / v_dim, 2) end;
  v_unpaid := coalesce((select sum(l.net) from hr.payroll_line l join hr.payroll_run r on r.id = l.run_id
                         where r.company_id = me.company_id and r.status = 'posted' and l.employee_id = p_employee_id), 0)
            - coalesce((select sum(x.amount) from hr.payroll_payment x join hr.payroll_run r on r.id = x.run_id
                         where r.company_id = me.company_id and x.employee_id = p_employee_id), 0);
  v_adv := hr.fn_salary_advance(p_employee_id);
  return jsonb_build_object('employee_id', p_employee_id, 'last_day', p_last_day, 'monthly_net_structure', v_monthly,
    'days_in_month', v_dim, 'days_worked', v_days, 'month_already_paid_in_regular_run', v_posted, 'prorata_this_month', v_prorata,
    'unpaid_posted_net', v_unpaid, 'salary_advance_taken', v_adv,
    'suggested_supplemental_amount', greatest(v_prorata, 0),
    'note_bn', 'অনুমোদিত হলে "সম্পূরক বেতন-রান" (v1_payroll_correction, supplemental) দিয়ে পোস্ট ও পরিশোধ করুন; অগ্রিম সমন্বয় আলাদা খরচ-অনুরোধে।');
end $$;

-- ================================================================ F154-147 dealer return authorisation
create table sales.return_authorization (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  invoice_id   uuid not null,
  lines        jsonb not null,               -- [{product_id, qty}]
  reason       text not null check (length(btrim(reason)) > 0),
  status       text not null default 'requested' check (status in ('requested','approved','rejected','used')),
  requested_by uuid not null references core.person(id),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  created_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  check (decided_by is null or decided_by <> requested_by),
  foreign key (invoice_id, company_id) references sales.invoice (id, company_id)
);
create function sales.fn_rma_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status in ('rejected','used') or (old.status = 'approved' and new.status <> 'used')
     or (to_jsonb(old) - array['status','decided_by','decided_at']) <> (to_jsonb(new) - array['status','decided_by','decided_at']) then
    raise exception 'E_IMMUTABLE: a return authorisation is decided and used once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_rma_guard before update on sales.return_authorization for each row execute function sales.fn_rma_guard();
create trigger trg_rma_nodel before delete on sales.return_authorization for each row execute function core.fn_deny_delete();
create trigger trg_rma_audit after insert or update on sales.return_authorization for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'return_authorization');

create function api.v1_return_authorization_request(p_invoice_id uuid, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('sales.return.create', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.invoice i where i.id = p_invoice_id and i.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'invoice'); end if;
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.return_authorization (company_id, invoice_id, lines, reason, requested_by) values (me.company_id, p_invoice_id, p_lines, btrim(p_reason), me.person_id)
  returning id into v_id;
  return jsonb_build_object('rma_id', v_id, 'status', 'requested');
end $$;

create function api.v1_return_authorization_decide(p_rma_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.return_authorization%rowtype;
begin
  select * into me from iam.fn_require('sales.order.approve', iam.fn_my_company_resource(), true);
  select * into r from sales.return_authorization where id = p_rma_id and company_id = me.company_id for update;
  if not found or r.status <> 'requested' then perform core.fn_raise('E_NOT_FOUND', 'requested return authorisation'); end if;
  if r.requested_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'return authorisation decided'), true);
  update sales.return_authorization set status = case when p_approve then 'approved' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp() where id = r.id;
  return jsonb_build_object('rma_id', r.id, 'status', case when p_approve then 'approved' else 'rejected' end);
end $$;

-- When the setting is on, a sales return needs an approved authorisation covering it (the authorisation is used up).
-- Courier returns (invoices sent through a courier shipment) follow the courier flow and are not asked again.
create function sales.fn_rma_required() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare r sales.return_authorization%rowtype; l jsonb; v_auth numeric;
begin
  if not coalesce(config.fn_get_bool(new.company_id, 'sales.return.requires_authorization'), false) then return new; end if;
  if exists (select 1 from sales.shipment s where s.invoice_id = new.invoice_id) then return new; end if;
  select * into r from sales.return_authorization x where x.invoice_id = new.invoice_id and x.status = 'approved' order by x.created_at limit 1 for update;
  if not found then raise exception 'E_RMA_REQUIRED: an approved return authorisation is needed' using errcode = 'P0001'; end if;
  for l in select * from jsonb_array_elements(new.lines) loop
    v_auth := coalesce((select sum((x ->> 'qty')::numeric) from jsonb_array_elements(r.lines) x where x ->> 'product_id' = l ->> 'product_id'), 0);
    if (l ->> 'qty')::numeric > v_auth then raise exception 'E_RMA_REQUIRED: more than authorised' using errcode = 'P0001'; end if;
  end loop;
  update sales.return_authorization set status = 'used' where id = r.id;
  return new;
end $$;
create trigger trg_sales_return_rma before insert on sales.sales_return for each row execute function sales.fn_rma_required();

-- ================================================================ F154-164 one day's movement trail
create function api.v1_location_trail(p_person_id uuid, p_day date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_wing uuid; v_ok boolean; d date := coalesce(p_day, current_date);
begin
  select * into me from iam.fn_context(false);
  select x.home_wing_id into v_wing from iam.position_assignment x join iam.company_membership m on m.id = x.membership_id
   where m.person_id = p_person_id and x.company_id = me.company_id and x.status = 'active' limit 1;
  select a.allowed into v_ok from iam.fn_authorize('location.live.read', iam.fn_resource(me.company_id, v_wing), false) a;
  if not coalesce(v_ok, false) and p_person_id is distinct from me.person_id then perform core.fn_raise('E_FORBIDDEN', 'location.live.read'); end if;
  return jsonb_build_object('person_id', p_person_id, 'day', d,
    'points', coalesce((select jsonb_agg(jsonb_build_object('lat', pp.latitude, 'lon', pp.longitude, 'accuracy_m', pp.accuracy_m, 'at', pp.recorded_at) order by pp.recorded_at)
                          from location.position_ping pp
                         where pp.company_id = me.company_id and pp.person_id = p_person_id
                           and (pp.recorded_at at time zone 'Asia/Dhaka')::date = d), '[]'::jsonb),
    'note_bn', 'শুধু সম্মতি থাকা অবস্থার অবস্থান; পুরোনো তথ্য ধারণকাল-সেটিং অনুযায়ী মুছে যায়।');
end $$;

-- ================================================================ F154-175/176/177 deterministic alert board (on demand, no alert engine)
create function api.v1_alerts_board() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_days integer; v_stock boolean; v_fin boolean; v_route boolean;
begin
  select * into me from iam.fn_context(false);
  v_days := coalesce(config.fn_get_int(me.company_id, 'notify.payment_mismatch.days'), 3);
  select a.allowed into v_stock from iam.fn_authorize('inventory.stock.read', iam.fn_my_company_resource(), false) a;
  select a.allowed into v_fin from iam.fn_authorize('finance.ledger.read', iam.fn_my_company_resource(), false) a;
  select a.allowed into v_route from iam.fn_authorize('crm.dealer.read', iam.fn_my_company_resource(), false) a;
  return jsonb_build_object(
    'low_stock', case when coalesce(v_stock, false) then coalesce((select jsonb_agg(jsonb_build_object('product', p.sku || ' · ' || p.name_bn, 'min_stock', rp.min_stock,
                         'on_hand', coalesce((select sum(b.qty) from inventory.stock_balance b where b.product_id = p.id and b.company_id = me.company_id), 0)) order by p.sku)
                       from inventory.raw_profile rp join inventory.product p on p.id = rp.product_id
                      where rp.company_id = me.company_id and rp.min_stock > 0
                        and coalesce((select sum(b.qty) from inventory.stock_balance b where b.product_id = p.id and b.company_id = me.company_id), 0) < rp.min_stock), '[]'::jsonb) end,
    'payment_mismatch', case when coalesce(v_fin, false) then jsonb_build_object(
        'collections_waiting', (select count(*) from sales.collection c where c.company_id = me.company_id and c.status = 'recorded'
                                  and c.collected_at < clock_timestamp() - make_interval(days => v_days)),
        'bank_lines_unmatched', (select count(*) from finance.bank_statement_line b where b.company_id = me.company_id and b.matched_line_id is null
                                   and b.txn_date < current_date - v_days),
        'courier_unallocated', coalesce((select sum(r.amount - coalesce((select sum(a.amount) from sales.remittance_allocation a where a.remittance_id = r.id), 0))
                                           from sales.courier_remittance r where r.company_id = me.company_id and r.status = 'POSTED'), 0)) end,
    'route_exceptions', case when coalesce(v_route, false) then coalesce((select jsonb_agg(jsonb_build_object('dealer', d.name_bn, 'planned', v.planned_date, 'status', v.status) order by v.planned_date)
                       from sales.dealer_visit v join sales.dealer d on d.id = v.dealer_id
                      where v.company_id = me.company_id and (v.status = 'missed' or (v.status = 'planned' and v.planned_date < current_date))
                        and v.planned_date >= current_date - 7), '[]'::jsonb) end,
    'note_bn', 'নির্দিষ্ট নিয়মে হিসাব করা তালিকা; কোনো কাজ নিজে থেকে হয় না।');
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_time_window_set(text, text, integer[], time, time, text)', 'api.v1_time_window_revoke(uuid, text)',
      'api.v1_approval_ceiling_set(text, text, numeric, text)', 'api.v1_screen_policy()', 'api.v1_org_chart_as_of(date)',
      'api.v1_product_declaration_set(uuid, text, text[], text)', 'api.v1_product_declaration(uuid)', 'api.v1_final_settlement_preview(uuid, date)',
      'api.v1_return_authorization_request(uuid, jsonb, text)', 'api.v1_return_authorization_decide(uuid, boolean, text)', 'api.v1_location_trail(uuid, date)',
      'api.v1_alerts_board()'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

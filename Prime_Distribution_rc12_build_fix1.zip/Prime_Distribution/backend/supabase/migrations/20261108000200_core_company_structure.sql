-- 20261108000200_core_company_structure.sql
-- Company-only organisation model (no Group, OWN-01/OWN-06), wings, departments, locations.
-- Every child row carries company_id and references its parent through (id, company_id) composite keys,
-- so a row can never point into another company (OWN-08). Rows are never deleted (status only).
-- Positions -> iam (S06); warehouses -> inv (S27). STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table core.company (
  id             uuid primary key default gen_random_uuid(),
  code           text not null unique check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn        text not null check (length(btrim(name_bn)) > 0),
  name_en        text,
  legal_name     text,
  status         text not null default 'provisioning' check (status in ('provisioning','active','suspended','closed')),
  status_epoch   integer not null default 0,
  base_currency  text not null default 'BDT' check (base_currency ~ '^[A-Z]{3}$'),
  timezone       text not null default 'Asia/Dhaka',
  created_at     timestamptz not null default clock_timestamp(),
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1
);

create function core.fn_company_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.id is distinct from old.id or new.code is distinct from old.code then
    raise exception 'E_IMMUTABLE: company id/code cannot change' using errcode = 'P0001';
  end if;
  if old.status = 'closed' and new.status is distinct from 'closed' then
    raise exception 'E_COMPANY_CLOSED: a closed company cannot be reopened' using errcode = 'P0001';
  end if;
  if new.status is distinct from old.status then
    new.status_epoch := old.status_epoch + 1;
  end if;
  return new;
end $$;

-- Shared guard for company-scoped master rows: id, company_id and code are fixed once created.
create function core.fn_scoped_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.id is distinct from old.id or new.company_id is distinct from old.company_id or new.code is distinct from old.code then
    raise exception 'E_IMMUTABLE: %.% id/company_id/code cannot change', tg_table_schema, tg_table_name using errcode = 'P0001';
  end if;
  return new;
end $$;

create trigger trg_company_guard  before update on core.company for each row execute function core.fn_company_guard();
create trigger trg_company_touch  before update on core.company for each row execute function core.fn_touch_row();
create trigger trg_company_nodel  before delete on core.company for each row execute function core.fn_deny_delete();

create table core.wing (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn     text not null check (length(btrim(name_bn)) > 0),
  name_en     text,
  wing_kind   text not null default 'other'
              check (wing_kind in ('manufacturing','trading','distribution','service','corporate','other')),
  sort_order  integer not null default 0,
  status      text not null default 'active' check (status in ('active','inactive')),
  created_at  timestamptz not null default clock_timestamp(),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id),
  unique (company_id, code)
);
create trigger trg_wing_guard before update on core.wing for each row execute function core.fn_scoped_guard();
create trigger trg_wing_touch before update on core.wing for each row execute function core.fn_touch_row();
create trigger trg_wing_nodel before delete on core.wing for each row execute function core.fn_deny_delete();

create table core.department (
  id                   uuid primary key default gen_random_uuid(),
  company_id           uuid not null references core.company(id),
  wing_id              uuid not null,
  parent_department_id uuid,
  code                 text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn              text not null check (length(btrim(name_bn)) > 0),
  name_en              text,
  sort_order           integer not null default 0,
  status               text not null default 'active' check (status in ('active','inactive')),
  created_at           timestamptz not null default clock_timestamp(),
  updated_at           timestamptz not null default clock_timestamp(),
  row_version          integer not null default 1,
  unique (id, company_id),
  unique (company_id, code),
  check (parent_department_id is null or parent_department_id <> id),
  foreign key (wing_id, company_id) references core.wing (id, company_id),
  foreign key (parent_department_id, company_id) references core.department (id, company_id)
);

-- No cycles in the department tree (also bounded depth 32).
create function core.fn_department_no_cycle() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_cur uuid := new.parent_department_id; v_depth integer := 0;
begin
  while v_cur is not null loop
    if v_cur = new.id then
      raise exception 'E_DEPARTMENT_CYCLE: department tree would contain a cycle' using errcode = 'P0001';
    end if;
    v_depth := v_depth + 1;
    if v_depth > 32 then
      raise exception 'E_DEPARTMENT_DEPTH: department tree deeper than 32' using errcode = 'P0001';
    end if;
    select d.parent_department_id into v_cur from core.department d where d.id = v_cur;
  end loop;
  return new;
end $$;
create trigger trg_department_cycle before insert or update of parent_department_id on core.department
  for each row execute function core.fn_department_no_cycle();
create trigger trg_department_guard before update on core.department for each row execute function core.fn_scoped_guard();
create trigger trg_department_touch before update on core.department for each row execute function core.fn_touch_row();
create trigger trg_department_nodel before delete on core.department for each row execute function core.fn_deny_delete();

create table core.location (
  id                uuid primary key default gen_random_uuid(),
  company_id        uuid not null references core.company(id),
  wing_id           uuid,
  code              text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn           text not null check (length(btrim(name_bn)) > 0),
  location_kind     text not null check (location_kind in ('factory','office','warehouse_site','depot','showroom','gate','other')),
  address_bn        text,
  latitude          numeric(9,6) check (latitude  between -90  and 90),
  longitude         numeric(9,6) check (longitude between -180 and 180),
  geofence_radius_m integer check (geofence_radius_m > 0),
  status            text not null default 'active' check (status in ('active','inactive')),
  created_at        timestamptz not null default clock_timestamp(),
  updated_at        timestamptz not null default clock_timestamp(),
  row_version       integer not null default 1,
  unique (id, company_id),
  unique (company_id, code),
  check ((latitude is null) = (longitude is null)),
  foreign key (wing_id, company_id) references core.wing (id, company_id)
);
create trigger trg_location_guard before update on core.location for each row execute function core.fn_scoped_guard();
create trigger trg_location_touch before update on core.location for each row execute function core.fn_touch_row();
create trigger trg_location_nodel before delete on core.location for each row execute function core.fn_deny_delete();

reset role;

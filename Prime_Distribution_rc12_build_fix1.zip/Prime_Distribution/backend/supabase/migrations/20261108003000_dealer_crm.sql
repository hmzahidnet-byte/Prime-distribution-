-- 20261108003000_dealer_crm.sql  (S40)
-- Dealer CRM (blueprint DEALER_CRM MOS-F153-121..130):
--   121 dealers: company-scoped code, territory, officer, credit limit/days, contacts
--   122 retailers: tied to one dealer and ALWAYS in the dealer's territory (no cross-territory leakage)
--   123 dealer ledger: append-only (invoice debit, collection/return credit); adjustments only through approval
--   124 credit: limit + approved, time-boxed exceptions; sales.fn_credit_check() is what new orders must call
--   125 visits: plan / outcome; location kept only with the officer's recorded consent; field staff see their own dealers
--   126 communication: call / WhatsApp / SMS links only for authorised contact numbers; every contact logged
--   127 statements: opening, entries, closing and FIFO aging from posted entries only
--   128 dealer QR: signed identity label; lookup never records or proves a payment
--   129 suspension: blocks new credit sales; history and balances untouched; collections still accepted
--   130 reassignment of territory / officer with an effective date and history
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table sales.territory (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn     text not null,
  wing_id     uuid,
  admin_area_codes text[] not null default array[]::text[],
  status      text not null default 'active' check (status in ('active','inactive')),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (wing_id, company_id) references core.wing (id, company_id)
);
create trigger trg_territory_guard before update on sales.territory for each row execute function core.fn_scoped_guard();
create trigger trg_territory_touch before update on sales.territory for each row execute function core.fn_touch_row();
create trigger trg_territory_nodel before delete on sales.territory for each row execute function core.fn_deny_delete();
create trigger trg_territory_audit after insert or update on sales.territory for each row execute function audit.fn_row_change();

create table sales.dealer (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references core.company(id),
  code             text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn          text not null check (length(btrim(name_bn)) > 0),
  owner_name_bn    text,
  phone            text,
  address_bn       text,
  admin_area_code  text references location.admin_area(code),
  latitude         numeric(9,6), longitude numeric(9,6),
  territory_id     uuid not null,
  officer_id       uuid references core.person(id),
  credit_limit     numeric(14,2) not null default 0 check (credit_limit >= 0),
  credit_days      integer not null default 0 check (credit_days between 0 and 180),
  status           text not null default 'active' check (status in ('active','suspended','closed')),
  suspended_reason text,
  created_at       timestamptz not null default clock_timestamp(),
  updated_at       timestamptz not null default clock_timestamp(),
  row_version      integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (territory_id, company_id) references sales.territory (id, company_id)
);
create trigger trg_dealer_guard before update on sales.dealer for each row execute function core.fn_scoped_guard();
create trigger trg_dealer_touch before update on sales.dealer for each row execute function core.fn_touch_row();
create trigger trg_dealer_nodel before delete on sales.dealer for each row execute function core.fn_deny_delete();
create trigger trg_dealer_audit after insert or update on sales.dealer for each row execute function audit.fn_row_change();

create table sales.dealer_contact (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  dealer_id   uuid not null,
  name_bn     text not null,
  role        text,
  phone       text not null check (phone ~ '^\+8801[3-9][0-9]{8}$'),
  authorized  boolean not null default false,
  status      text not null default 'active' check (status in ('active','inactive')),
  created_at  timestamptz not null default clock_timestamp(),
  unique (dealer_id, phone),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_dealer_contact_nodel before delete on sales.dealer_contact for each row execute function core.fn_deny_delete();
create trigger trg_dealer_contact_audit after insert or update on sales.dealer_contact for each row execute function audit.fn_row_change();

create table sales.retailer (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null,
  code             text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn          text not null,
  phone            text,
  dealer_id        uuid not null,
  territory_id     uuid not null,
  admin_area_code  text references location.admin_area(code),
  latitude         numeric(9,6), longitude numeric(9,6),
  status           text not null default 'active' check (status in ('active','inactive')),
  updated_at       timestamptz not null default clock_timestamp(),
  row_version      integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id),
  foreign key (territory_id, company_id) references sales.territory (id, company_id)
);
-- F122: a retailer always sits in its dealer's territory.
create function sales.fn_retailer_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.territory_id is distinct from (select d.territory_id from sales.dealer d where d.id = new.dealer_id) then
    raise exception 'E_TERRITORY_MISMATCH: a retailer belongs to its dealer''s territory' using errcode = 'P0001';
  end if;
  if tg_op = 'UPDATE' and new.code <> old.code then raise exception 'E_IMMUTABLE: retailer code' using errcode = 'P0001'; end if;
  return new;
end $$;
create trigger trg_retailer_guard before insert or update on sales.retailer for each row execute function sales.fn_retailer_guard();
create trigger trg_retailer_touch before update on sales.retailer for each row execute function core.fn_touch_row();
create trigger trg_retailer_nodel before delete on sales.retailer for each row execute function core.fn_deny_delete();
create trigger trg_retailer_audit after insert or update on sales.retailer for each row execute function audit.fn_row_change();

-- F123: append-only dealer ledger; each source document posts once.
create table sales.dealer_ledger (
  id           bigint generated always as identity primary key,
  company_id   uuid not null,
  dealer_id    uuid not null,
  entry_date   date not null,
  kind         text not null check (kind in ('opening','invoice','collection','return','credit_note','debit_note','adjustment')),
  amount       numeric(16,2) not null check (amount <> 0),          -- + increases what the dealer owes, − reduces it
  due_date     date,
  source_type  text not null,
  source_id    uuid not null,
  memo         text,
  posted_by    uuid,
  posted_at    timestamptz not null default clock_timestamp(),
  unique (source_type, source_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create index dealer_ledger_dealer on sales.dealer_ledger (dealer_id, entry_date, id);
create trigger trg_dealer_ledger_no_mutation before update or delete on sales.dealer_ledger for each row execute function core.fn_deny_mutation();
create trigger trg_dealer_ledger_audit after insert on sales.dealer_ledger for each row execute function audit.fn_row_change();

create table sales.dealer_adjustment (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  dealer_id           uuid not null,
  amount              numeric(16,2) not null check (amount <> 0),
  reason              text not null check (length(btrim(reason)) > 0),
  status              text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  posted_at           timestamptz,
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_dealer_adjustment_guard before update on sales.dealer_adjustment for each row execute function procurement.fn_doc_status_guard();
create trigger trg_dealer_adjustment_nodel before delete on sales.dealer_adjustment for each row execute function core.fn_deny_delete();
create trigger trg_dealer_adjustment_audit after insert or update on sales.dealer_adjustment for each row execute function audit.fn_row_change();

create table sales.credit_exception (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  dealer_id           uuid not null,
  amount              numeric(14,2) not null check (amount > 0),
  valid_until         date not null,
  reason              text not null check (length(btrim(reason)) > 0),
  status              text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  posted_at           timestamptz,
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_credit_exception_guard before update on sales.credit_exception for each row execute function procurement.fn_doc_status_guard();
create trigger trg_credit_exception_nodel before delete on sales.credit_exception for each row execute function core.fn_deny_delete();
create trigger trg_credit_exception_audit after insert or update on sales.credit_exception for each row execute function audit.fn_row_change();

create table sales.location_consent (
  person_id   uuid primary key references core.person(id),
  granted_at  timestamptz not null default clock_timestamp(),
  revoked_at  timestamptz,
  note        text
);
create trigger trg_location_consent_audit after insert or update on sales.location_consent for each row execute function audit.fn_row_change();

create table sales.dealer_visit (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  dealer_id     uuid,
  retailer_id   uuid,
  officer_id    uuid not null references core.person(id),
  planned_date  date not null,
  status        text not null default 'planned' check (status in ('planned','done','missed','cancelled')),
  outcome       text check (outcome is null or outcome in ('order','collection','complaint','no_order','closed_shop','other')),
  notes         text,
  latitude      numeric(9,6), longitude numeric(9,6),
  checked_in_at timestamptz,
  created_at    timestamptz not null default clock_timestamp(),
  check ((dealer_id is null) <> (retailer_id is null)),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id),
  foreign key (retailer_id, company_id) references sales.retailer (id, company_id)
);
create trigger trg_dealer_visit_nodel before delete on sales.dealer_visit for each row execute function core.fn_deny_delete();
create trigger trg_dealer_visit_audit after insert or update on sales.dealer_visit for each row execute function audit.fn_row_change();

create table sales.comm_log (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  dealer_id   uuid not null,
  contact_id  uuid not null references sales.dealer_contact(id),
  channel     text not null check (channel in ('call','whatsapp','sms')),
  note        text,
  person_id   uuid not null references core.person(id),
  at          timestamptz not null default clock_timestamp(),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_comm_log_no_mutation before update or delete on sales.comm_log for each row execute function core.fn_deny_mutation();

create table sales.dealer_assignment (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  dealer_id       uuid not null,
  territory_id    uuid not null,
  officer_id      uuid references core.person(id),
  effective_from  date not null,
  status          text not null default 'scheduled' check (status in ('scheduled','applied','cancelled')),
  reason          text not null check (length(btrim(reason)) > 0),
  set_by          uuid references core.person(id),
  set_at          timestamptz not null default clock_timestamp(),
  applied_at      timestamptz,
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id),
  foreign key (territory_id, company_id) references sales.territory (id, company_id)
);
create trigger trg_dealer_assignment_nodel before delete on sales.dealer_assignment for each row execute function core.fn_deny_delete();
create trigger trg_dealer_assignment_audit after insert or update on sales.dealer_assignment for each row execute function audit.fn_row_change();

select core.fn_apply_rls('sales', 'territory');
select core.fn_apply_rls('sales', 'dealer');
select core.fn_apply_rls('sales', 'dealer_contact');
select core.fn_apply_rls('sales', 'retailer');
select core.fn_apply_rls('sales', 'dealer_ledger');
select core.fn_apply_rls('sales', 'dealer_adjustment');
select core.fn_apply_rls('sales', 'credit_exception');
select core.fn_apply_rls('sales', 'location_consent');
select core.fn_apply_rls('sales', 'dealer_visit');
select core.fn_apply_rls('sales', 'comm_log');
select core.fn_apply_rls('sales', 'dealer_assignment');

-- ================================================================ permissions, modules
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('crm.dealer.manage', 'crm', 'ডিলার/রিটেইলার/এলাকা সম্পাদনা', 'write', true, false, array['COMPANY','WING'], 'active', 1605),
  ('crm.ledger.adjust', 'crm', 'ডিলার-খাতা সমন্বয় প্রস্তাব', 'write', true, false, array['COMPANY'], 'active', 1606),
  ('crm.credit.request', 'crm', 'ক্রেডিট-ব্যতিক্রম অনুরোধ', 'write', true, false, array['COMPANY','WING','ASSIGNED'], 'active', 1607);
update iam.permission_catalog set status = 'active' where code in ('crm.dealer.read','crm.visit.record','sales.credit.override');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', z from (values ('SALES_MANAGER','crm.dealer.read','COMPANY'), ('SALES_MANAGER','crm.dealer.manage','COMPANY'), ('SALES_MANAGER','crm.credit.request','COMPANY'),
  ('SALES_MANAGER','crm.visit.record','ASSIGNED'), ('FIELD_SALES','crm.dealer.read','ASSIGNED'), ('FIELD_SALES','crm.visit.record','ASSIGNED'),
  ('FIELD_SALES','crm.credit.request','ASSIGNED'), ('MD','crm.dealer.read','COMPANY'), ('MD','sales.credit.override','COMPANY'),
  ('FIN_MANAGER','crm.dealer.read','COMPANY'), ('FIN_MANAGER','crm.ledger.adjust','COMPANY'), ('ACCOUNTANT','crm.dealer.read','COMPANY'),
  ('AUDITOR','crm.dealer.read','COMPANY')) v(x, y, z)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('crm');
select config.fn_make_module_available('sales');

insert into finance.coa_template (code, name_bn, type, parent, postable) values ('5600','ডিলার-সমন্বয় (ছাড়/বাট্টা)','expense','5000',true) on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values ('sales.adjustment','5600','ডিলার-খাতা সমন্বয়') on conflict do nothing;

-- ================================================================ engine
create function sales.fn_dealer_resource(d sales.dealer) returns iam.resource
language sql stable security definer set search_path = pg_catalog as $$
  select iam.fn_resource(d.company_id, (select t.wing_id from sales.territory t where t.id = d.territory_id), null, null, null, null, d.officer_id)
$$;

create function sales.fn_dealer_balance(p_dealer uuid, p_as_of date default null) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(l.amount), 0) from sales.dealer_ledger l where l.dealer_id = p_dealer and (p_as_of is null or l.entry_date <= p_as_of)
$$;

-- F124 / F129: what a NEW credit order may add. Suspended / closed dealers get nothing; exposure counts the ledger
-- balance plus open orders (sales module adds them through p_open_orders).
create function sales.fn_credit_check(p_dealer uuid, p_new_amount numeric, p_open_orders numeric default 0) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare d sales.dealer%rowtype; v_bal numeric; v_ex numeric; v_avail numeric;
begin
  select * into d from sales.dealer where id = p_dealer;
  if d.id is null then return jsonb_build_object('allowed', false, 'reason', 'unknown dealer'); end if;
  if d.status <> 'active' then return jsonb_build_object('allowed', false, 'reason', 'dealer ' || d.status); end if;
  v_bal := sales.fn_dealer_balance(d.id);
  v_ex := coalesce((select sum(e.amount) from sales.credit_exception e where e.dealer_id = d.id and e.status = 'posted' and e.valid_until >= current_date), 0);
  v_avail := d.credit_limit + v_ex - v_bal - coalesce(p_open_orders, 0);
  return jsonb_build_object('allowed', coalesce(p_new_amount, 0) <= v_avail, 'available', v_avail, 'balance', v_bal, 'limit', d.credit_limit, 'exceptions', v_ex,
                            'reason', case when coalesce(p_new_amount, 0) > v_avail then 'credit limit exceeded' end);
end $$;

-- Ledger posting used by sales / collection modules and approved adjustments (idempotent per source).
create function sales.fn_post_ledger(p_company uuid, p_dealer uuid, p_kind text, p_amount numeric, p_date date, p_due date, p_source_type text, p_source_id uuid, p_memo text) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  insert into sales.dealer_ledger (company_id, dealer_id, entry_date, kind, amount, due_date, source_type, source_id, memo, posted_by)
  values (p_company, p_dealer, coalesce(p_date, current_date), p_kind, round(p_amount, 2), p_due, p_source_type, p_source_id, p_memo, iam.fn_current_person())
  on conflict (source_type, source_id) do nothing;
end $$;

create function sales.fn_on_approved(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare a sales.dealer_adjustment%rowtype;
begin
  if r.document_type = 'sales.credit_exception' then
    update sales.credit_exception set status = 'posted', posted_at = clock_timestamp() where id = r.document_id and status = 'pending_approval';
  elsif r.document_type = 'sales.dealer_adjustment' then
    select * into a from sales.dealer_adjustment where id = r.document_id for update;
    if a.status <> 'pending_approval' then return; end if;
    perform sales.fn_post_ledger(a.company_id, a.dealer_id, 'adjustment', a.amount, current_date, null, 'sales.dealer_adjustment', a.id, a.reason);
    perform finance.fn_emit(a.company_id, 'dealer_adj:' || a.id, 'ডিলার-খাতা সমন্বয়', jsonb_build_array(
      jsonb_build_object('key', 'sales.ar', 'dr', greatest(a.amount, 0), 'cr', greatest(-a.amount, 0)),
      jsonb_build_object('key', 'sales.adjustment', 'dr', greatest(-a.amount, 0), 'cr', greatest(a.amount, 0))));
    update sales.dealer_adjustment set status = 'posted', posted_at = clock_timestamp() where id = a.id;
  end if;
end $$;

-- Signed dealer label: MOS1|D|<company>|<dealer>|<sig> (company secret from S29).
create function sales.fn_dealer_qr(p_dealer uuid) returns text
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare d record; v_body text;
begin
  select dl.code dcode, c.code ccode, dl.company_id into d from sales.dealer dl join core.company c on c.id = dl.company_id where dl.id = p_dealer;
  if d.dcode is null then return null; end if;
  v_body := 'MOS1|D|' || d.ccode || '|' || d.dcode;
  return v_body || '|' || left(encode(hmac(convert_to(v_body, 'UTF8'), inventory.fn_qr_secret(d.company_id), 'sha256'), 'hex'), 16);
end $$;

-- Applies due reassignments (also run on each read path below and by the platform scheduler).
create function sales.fn_apply_reassignments(p_company uuid) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare a record; n integer := 0;
begin
  for a in select * from sales.dealer_assignment x where (p_company is null or x.company_id = p_company) and x.status = 'scheduled' and x.effective_from <= current_date
            order by x.effective_from, x.set_at for update loop
    perform set_config('mohona.change_reason', 'reassignment ' || a.reason, true);
    update sales.dealer set territory_id = a.territory_id, officer_id = a.officer_id where id = a.dealer_id;
    update sales.retailer set territory_id = a.territory_id where dealer_id = a.dealer_id;
    update sales.dealer_assignment set status = 'applied', applied_at = clock_timestamp() where id = a.id;
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'design.layout_publish' then perform design.fn_publish_layout_version(r.company_id, r.payload ->> 'screen_key', (r.payload ->> 'version')::integer);
    when r.document_type = 'inventory.transfer' then perform inventory.fn_post_transfer(r.document_id);
    when r.document_type = 'finance.journal' then perform finance.fn_post_journal(r.document_id, false);
    when r.document_type like 'sales.%' then perform sales.fn_on_approved(r);
    when r.document_type like 'procurement.%' then perform procurement.fn_on_approved(r);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- ================================================================ API: master data (F121, F122)
create function api.v1_territory_save(p_id uuid, p_code text, p_name_bn text, p_wing_id uuid, p_admin_area_codes text[], p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t sales.territory%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', iam.fn_resource(iam.fn_context_company(), p_wing_id), true);
  if exists (select 1 from unnest(coalesce(p_admin_area_codes, array[]::text[])) c where not exists (select 1 from location.admin_area a where a.code = c)) then
    perform core.fn_raise('E_NOT_FOUND', 'administrative area');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.territory (company_id, code, name_bn, wing_id, admin_area_codes) values (me.company_id, upper(p_code), p_name_bn, p_wing_id, coalesce(p_admin_area_codes, array[]::text[]))
    returning * into t;
  else
    select * into t from sales.territory where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'territory'); end if;
    if t.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    if coalesce(p_status, t.status) = 'inactive' and exists (select 1 from sales.dealer d where d.territory_id = t.id and d.status <> 'closed') then
      perform core.fn_raise('E_STRUCTURE_IN_USE', 'territory has dealers');
    end if;
    update sales.territory set name_bn = coalesce(p_name_bn, name_bn), wing_id = p_wing_id, admin_area_codes = coalesce(p_admin_area_codes, admin_area_codes),
           status = coalesce(p_status, status) where id = t.id returning * into t;
  end if;
  return jsonb_build_object('territory_id', t.id, 'row_version', t.row_version);
end $$;

-- Create / edit a dealer. Territory and officer change only through reassignment (F130); raising the credit limit
-- needs the credit-override right (F124).
create function api.v1_dealer_save(p_id uuid, p_code text, p_name_bn text, p_owner_name_bn text, p_phone text, p_address_bn text, p_admin_area_code text,
                                   p_territory_id uuid, p_officer_id uuid, p_credit_limit numeric, p_credit_days integer, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v_override boolean;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', iam.fn_my_company_resource(), true);
  select coalesce(x.allowed, false) into v_override from iam.fn_authorize('sales.credit.override', iam.fn_resource(me.company_id), false) x;
  if p_officer_id is not null and not exists (select 1 from iam.company_membership m where m.company_id = me.company_id and m.person_id = p_officer_id and m.status = 'active') then
    perform core.fn_raise('E_NOT_FOUND', 'officer');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    if coalesce(p_credit_limit, 0) > 0 and not v_override then perform core.fn_raise('E_FORBIDDEN', 'credit limit needs the credit-override right'); end if;
    insert into sales.dealer (company_id, code, name_bn, owner_name_bn, phone, address_bn, admin_area_code, territory_id, officer_id, credit_limit, credit_days)
    values (me.company_id, upper(p_code), p_name_bn, p_owner_name_bn, core.fn_phone_canonical(p_phone), p_address_bn, p_admin_area_code, p_territory_id, p_officer_id,
            coalesce(p_credit_limit, 0), coalesce(p_credit_days, 0)) returning * into d;
  else
    select * into d from sales.dealer where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
    if d.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    if p_territory_id is distinct from d.territory_id or p_officer_id is distinct from d.officer_id then
      perform core.fn_raise('E_INVALID_ACTION', 'territory / officer change through reassignment with an effective date');
    end if;
    if coalesce(p_credit_limit, d.credit_limit) > d.credit_limit and not v_override then perform core.fn_raise('E_FORBIDDEN', 'raising the credit limit needs the credit-override right'); end if;
    update sales.dealer set name_bn = coalesce(p_name_bn, name_bn), owner_name_bn = p_owner_name_bn, phone = core.fn_phone_canonical(p_phone), address_bn = p_address_bn,
           admin_area_code = p_admin_area_code, credit_limit = coalesce(p_credit_limit, credit_limit), credit_days = coalesce(p_credit_days, credit_days)
     where id = d.id returning * into d;
  end if;
  return jsonb_build_object('dealer_id', d.id, 'row_version', d.row_version, 'qr', sales.fn_dealer_qr(d.id));
end $$;

create function api.v1_dealer_contact_save(p_dealer_id uuid, p_id uuid, p_name_bn text, p_role text, p_phone text, p_authorized boolean, p_status text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; v_phone text := core.fn_phone_canonical(p_phone);
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.dealer d where d.id = p_dealer_id and d.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  if v_phone is null then perform core.fn_raise('E_INVALID_ACTION', 'Bangladesh mobile number'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.dealer_contact (company_id, dealer_id, name_bn, role, phone, authorized) values (me.company_id, p_dealer_id, p_name_bn, p_role, v_phone, coalesce(p_authorized, false))
    returning id into v_id;
  else
    update sales.dealer_contact set name_bn = coalesce(p_name_bn, name_bn), role = p_role, phone = v_phone, authorized = coalesce(p_authorized, authorized), status = coalesce(p_status, status)
     where id = p_id and dealer_id = p_dealer_id returning id into v_id;
    if v_id is null then perform core.fn_raise('E_NOT_FOUND', 'contact'); end if;
  end if;
  return jsonb_build_object('contact_id', v_id);
end $$;

create function api.v1_retailer_save(p_id uuid, p_code text, p_name_bn text, p_phone text, p_dealer_id uuid, p_admin_area_code text, p_latitude numeric, p_longitude numeric,
                                     p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; r sales.retailer%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', iam.fn_my_company_resource(), true);
  select * into d from sales.dealer where id = p_dealer_id and company_id = me.company_id;
  if not found or d.status = 'closed' then perform core.fn_raise('E_NOT_FOUND', 'open dealer'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.retailer (company_id, code, name_bn, phone, dealer_id, territory_id, admin_area_code, latitude, longitude)
    values (me.company_id, upper(p_code), p_name_bn, core.fn_phone_canonical(p_phone), d.id, d.territory_id, p_admin_area_code, p_latitude, p_longitude) returning * into r;
  else
    select * into r from sales.retailer where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'retailer'); end if;
    if r.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    update sales.retailer set name_bn = coalesce(p_name_bn, name_bn), phone = core.fn_phone_canonical(p_phone), dealer_id = d.id, territory_id = d.territory_id,
           admin_area_code = p_admin_area_code, latitude = p_latitude, longitude = p_longitude, status = coalesce(p_status, status) where id = r.id returning * into r;
  end if;
  return jsonb_build_object('retailer_id', r.id, 'row_version', r.row_version);
end $$;

-- Dealers the caller may see (field staff: only their own), with balance and credit position.
create function api.v1_dealers(p_text text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  perform sales.fn_apply_reassignments(me.company_id);
  return coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'code', d.code, 'name_bn', d.name_bn, 'territory', t.code, 'officer_id', d.officer_id, 'status', d.status,
           'balance', sales.fn_dealer_balance(d.id), 'credit_limit', d.credit_limit, 'row_version', d.row_version) order by d.code)
     from sales.dealer d join sales.territory t on t.id = d.territory_id
    where d.company_id = me.company_id and (p_text is null or d.name_bn ilike '%' || p_text || '%' or d.code ilike '%' || p_text || '%')
      and (select x.allowed from iam.fn_authorize('crm.dealer.read', sales.fn_dealer_resource(d), false) x)), '[]'::jsonb);
end $$;

create function api.v1_dealer_get(p_dealer_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), false);
  return to_jsonb(d) - 'company_id' || jsonb_build_object('qr', sales.fn_dealer_qr(d.id), 'balance', sales.fn_dealer_balance(d.id), 'credit', sales.fn_credit_check(d.id, 0),
    'contacts', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name_bn', c.name_bn, 'role', c.role, 'authorized', c.authorized, 'status', c.status,
                 'phone', case when c.authorized then c.phone else '••••' || right(c.phone, 3) end)) from sales.dealer_contact c where c.dealer_id = d.id), '[]'::jsonb),
    'retailers', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code, 'name_bn', r.name_bn, 'status', r.status) order by r.code)
                 from sales.retailer r where r.dealer_id = d.id), '[]'::jsonb),
    'assignments', coalesce((select jsonb_agg(jsonb_build_object('territory_id', a.territory_id, 'officer_id', a.officer_id, 'effective_from', a.effective_from, 'status', a.status,
                 'reason', a.reason) order by a.effective_from) from sales.dealer_assignment a where a.dealer_id = d.id), '[]'::jsonb));
end $$;

-- ================================================================ API: ledger, credit, suspension, reassignment (F123, F124, F129, F130)
create function api.v1_dealer_opening(p_dealer_id uuid, p_amount numeric, p_date date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.ledger.adjust', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.dealer d where d.id = p_dealer_id and d.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  if exists (select 1 from sales.dealer_ledger l where l.dealer_id = p_dealer_id) then perform core.fn_raise('E_INVALID_ACTION', 'opening balance only before any entry'); end if;
  if coalesce(p_amount, 0) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'amount'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform sales.fn_post_ledger(me.company_id, p_dealer_id, 'opening', p_amount, coalesce(p_date, current_date), coalesce(p_date, current_date), 'sales.dealer_opening', p_dealer_id, p_reason);
  return jsonb_build_object('dealer_id', p_dealer_id, 'balance', sales.fn_dealer_balance(p_dealer_id));
end $$;

-- No silent due adjustment (F123): every change of what a dealer owes outside sales/collection goes through approval.
create function api.v1_dealer_adjust(p_dealer_id uuid, p_amount numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.ledger.adjust', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.dealer d where d.id = p_dealer_id and d.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  if coalesce(p_amount, 0) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'amount'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.dealer_adjustment (id, company_id, dealer_id, amount, reason, created_by) values (v_id, me.company_id, p_dealer_id, p_amount, p_reason, me.person_id);
  j := core.fn_approval_submit(me.company_id, 'sales.dealer_adjustment', v_id, abs(p_amount), iam.fn_resource(me.company_id), jsonb_build_object('dealer_id', p_dealer_id));
  update sales.dealer_adjustment set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  if j ->> 'status' = 'approved' then perform sales.fn_on_approved((select r from core.approval_request r where r.id = (j ->> 'request_id')::uuid)); end if;
  return jsonb_build_object('adjustment_id', v_id, 'status', (select a.status from sales.dealer_adjustment a where a.id = v_id));
end $$;

create function api.v1_credit_exception_request(p_dealer_id uuid, p_amount numeric, p_valid_until date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v_id uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.credit.request', sales.fn_dealer_resource(d), true);
  if d.status <> 'active' then perform core.fn_raise('E_DEALER_SUSPENDED', d.status); end if;
  if coalesce(p_amount, 0) <= 0 or p_valid_until is null or p_valid_until < current_date or p_valid_until > current_date + 90 then
    perform core.fn_raise('E_INVALID_ACTION', 'amount and a validity within 90 days');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.credit_exception (id, company_id, dealer_id, amount, valid_until, reason, created_by) values (v_id, d.company_id, d.id, p_amount, p_valid_until, p_reason, me.person_id);
  j := core.fn_approval_submit(d.company_id, 'sales.credit_exception', v_id, p_amount, sales.fn_dealer_resource(d), jsonb_build_object('dealer_id', d.id));
  update sales.credit_exception set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  if j ->> 'status' = 'approved' then perform sales.fn_on_approved((select r from core.approval_request r where r.id = (j ->> 'request_id')::uuid)); end if;
  return jsonb_build_object('exception_id', v_id, 'status', (select e.status from sales.credit_exception e where e.id = v_id));
end $$;

create function api.v1_credit_check(p_dealer_id uuid, p_amount numeric) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), false);
  return sales.fn_credit_check(d.id, p_amount);
end $$;

-- suspend | reactivate | close (F129). History and balances stay; reactivation needs the credit-override right.
create function api.v1_dealer_status(p_dealer_id uuid, p_action text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require(case when p_action = 'reactivate' then 'sales.credit.override' else 'crm.dealer.manage' end, iam.fn_my_company_resource(), true);
  select * into d from sales.dealer where id = p_dealer_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  if d.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  if not ((p_action = 'suspend' and d.status = 'active') or (p_action = 'reactivate' and d.status = 'suspended') or (p_action = 'close' and d.status <> 'closed')) then
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || d.status);
  end if;
  if p_action = 'close' and sales.fn_dealer_balance(d.id) <> 0 then perform core.fn_raise('E_INVALID_ACTION', 'settle the balance before closing'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update sales.dealer set status = case p_action when 'suspend' then 'suspended' when 'reactivate' then 'active' else 'closed' end,
         suspended_reason = case when p_action = 'suspend' then p_reason end where id = d.id returning * into d;
  return jsonb_build_object('dealer_id', d.id, 'status', d.status, 'row_version', d.row_version);
end $$;

-- Reassignment (F130): effective today -> applied now; future -> scheduled; the history stays.
create function api.v1_dealer_reassign(p_dealer_id uuid, p_territory_id uuid, p_officer_id uuid, p_effective_from date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.dealer d where d.id = p_dealer_id and d.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  if not exists (select 1 from sales.territory t where t.id = p_territory_id and t.company_id = me.company_id and t.status = 'active') then perform core.fn_raise('E_NOT_FOUND', 'territory'); end if;
  if p_officer_id is not null and not exists (select 1 from iam.company_membership m where m.company_id = me.company_id and m.person_id = p_officer_id and m.status = 'active') then
    perform core.fn_raise('E_NOT_FOUND', 'officer');
  end if;
  if p_effective_from is null or p_effective_from < current_date then perform core.fn_raise('E_INVALID_ACTION', 'effective date from today'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.dealer_assignment (company_id, dealer_id, territory_id, officer_id, effective_from, reason, set_by)
  values (me.company_id, p_dealer_id, p_territory_id, p_officer_id, p_effective_from, p_reason, me.person_id) returning id into v_id;
  perform sales.fn_apply_reassignments(me.company_id);
  return jsonb_build_object('assignment_id', v_id, 'status', (select a.status from sales.dealer_assignment a where a.id = v_id));
end $$;

-- ================================================================ API: visits, consent, communication (F125, F126)
create function api.v1_location_consent(p_grant boolean, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  perform set_config('mohona.change_reason', 'location consent', true);
  insert into sales.location_consent (person_id, granted_at, revoked_at, note) values (me.person_id, clock_timestamp(), case when p_grant then null else clock_timestamp() end, p_note)
  on conflict (person_id) do update set granted_at = case when p_grant then clock_timestamp() else sales.location_consent.granted_at end,
                                        revoked_at = case when p_grant then null else clock_timestamp() end, note = excluded.note;
  return jsonb_build_object('location_consent', p_grant);
end $$;

create function api.v1_visit_plan(p_dealer_id uuid, p_retailer_id uuid, p_planned_date date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v_id uuid;
begin
  select * into d from sales.dealer where id = coalesce(p_dealer_id, (select r.dealer_id from sales.retailer r where r.id = p_retailer_id)) and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.visit.record', sales.fn_dealer_resource(d), true);
  perform set_config('mohona.change_reason', 'visit plan', true);
  insert into sales.dealer_visit (company_id, dealer_id, retailer_id, officer_id, planned_date)
  values (d.company_id, case when p_retailer_id is null then d.id end, p_retailer_id, me.person_id, coalesce(p_planned_date, current_date)) returning id into v_id;
  return jsonb_build_object('visit_id', v_id);
end $$;

-- Outcome by the visiting officer; coordinates are stored only with that officer's active consent.
create function api.v1_visit_record(p_visit_id uuid, p_outcome text, p_notes text, p_latitude numeric, p_longitude numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype; v_consent boolean;
begin
  select * into me from iam.fn_context(true);
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = me.company_id for update;
  if not found or v.officer_id <> me.person_id or v.status <> 'planned' then perform core.fn_raise('E_NOT_FOUND', 'your planned visit'); end if;
  v_consent := exists (select 1 from sales.location_consent c where c.person_id = me.person_id and c.revoked_at is null);
  perform set_config('mohona.change_reason', 'visit outcome', true);
  update sales.dealer_visit set status = 'done', outcome = p_outcome, notes = p_notes, checked_in_at = clock_timestamp(),
         latitude = case when v_consent then p_latitude end, longitude = case when v_consent then p_longitude end where id = v.id;
  return jsonb_build_object('visit_id', v.id, 'status', 'done', 'location_saved', v_consent and p_latitude is not null);
end $$;

-- Only authorised contacts get a dial / WhatsApp / SMS link; every contact attempt is logged (F126).
create function api.v1_dealer_contact_link(p_contact_id uuid, p_channel text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c sales.dealer_contact%rowtype; d sales.dealer%rowtype;
begin
  select * into c from sales.dealer_contact where id = p_contact_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'contact'); end if;
  select * into d from sales.dealer where id = c.dealer_id;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), false);
  if not c.authorized or c.status <> 'active' then perform core.fn_raise('E_CONTACT_NOT_AUTHORIZED'); end if;
  if coalesce(p_channel, '') not in ('call','whatsapp','sms') then perform core.fn_raise('E_INVALID_ACTION', 'channel'); end if;
  insert into sales.comm_log (company_id, dealer_id, contact_id, channel, note, person_id) values (c.company_id, d.id, c.id, p_channel, left(p_note, 500), me.person_id);
  return jsonb_build_object('channel', p_channel, 'link', case p_channel when 'call' then 'tel:' || c.phone when 'sms' then 'sms:' || c.phone
                                                                     else 'https://wa.me/' || ltrim(c.phone, '+') end);
end $$;

-- ================================================================ API: statement + QR (F127, F128)
create function api.v1_dealer_statement(p_dealer_id uuid, p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
        v_credit numeric; r record; v_left numeric; aging jsonb := jsonb_build_object('current', 0, 'd1_30', 0, 'd31_60', 0, 'd61_90', 0, 'd90_plus', 0); k text; v_due date;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), false);
  -- FIFO aging as of t: credits settle the oldest debits first
  v_credit := coalesce((select -sum(l.amount) from sales.dealer_ledger l where l.dealer_id = d.id and l.amount < 0 and l.entry_date <= t), 0);
  for r in select * from sales.dealer_ledger l where l.dealer_id = d.id and l.amount > 0 and l.entry_date <= t order by l.entry_date, l.id loop
    v_left := greatest(r.amount - v_credit, 0); v_credit := greatest(v_credit - r.amount, 0);
    continue when v_left = 0;
    v_due := coalesce(r.due_date, r.entry_date + d.credit_days);
    k := case when t <= v_due then 'current' when t - v_due <= 30 then 'd1_30' when t - v_due <= 60 then 'd31_60' when t - v_due <= 90 then 'd61_90' else 'd90_plus' end;
    aging := jsonb_set(aging, array[k], to_jsonb((aging ->> k)::numeric + v_left));
  end loop;
  return jsonb_build_object('dealer_id', d.id, 'dealer', d.name_bn, 'from', f, 'to', t, 'opening', sales.fn_dealer_balance(d.id, f - 1),
    'entries', coalesce((select jsonb_agg(jsonb_build_object('date', l.entry_date, 'kind', l.kind, 'amount', l.amount, 'due_date', l.due_date, 'memo', l.memo,
                                                             'source', l.source_type) order by l.entry_date, l.id)
                           from sales.dealer_ledger l where l.dealer_id = d.id and l.entry_date between f and t), '[]'::jsonb),
    'closing', sales.fn_dealer_balance(d.id, t), 'aging', aging);
end $$;

-- Identity lookup from a signed dealer label. Never records, approves or proves any payment (F128).
create function api.v1_dealer_qr_lookup(p_payload text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); d sales.dealer%rowtype; v_read boolean;
begin
  select * into me from iam.fn_context(false);
  if cardinality(parts) <> 5 or parts[1] <> 'MOS1' or parts[2] <> 'D' or parts[3] is distinct from (select c.code from core.company c where c.id = me.company_id) then
    perform core.fn_raise('E_QR_INVALID');
  end if;
  select * into d from sales.dealer where company_id = me.company_id and code = parts[4];
  if d.id is null or sales.fn_dealer_qr(d.id) <> p_payload then perform core.fn_raise('E_QR_INVALID'); end if;
  select x.allowed into v_read from iam.fn_authorize('crm.dealer.read', sales.fn_dealer_resource(d), false) x;
  return jsonb_build_object('dealer_id', d.id, 'code', d.code, 'name_bn', d.name_bn, 'status', d.status,
                            'balance', case when v_read then sales.fn_dealer_balance(d.id) end,
                            'note_bn', 'এই QR শুধু পরিচয় দেখায়; এটি কোনো পরিশোধের প্রমাণ নয়।');
end $$;

create function svc.v1_dealer_apply_reassignments() returns integer
language plpgsql security definer set search_path = '' as $$
begin
  perform set_config('mohona.company_scope', '', true);
  return sales.fn_apply_reassignments(null);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_territory_save(uuid, text, text, uuid, text[], text, integer, text)',
      'api.v1_dealer_save(uuid, text, text, text, text, text, text, uuid, uuid, numeric, integer, integer, text)',
      'api.v1_dealer_contact_save(uuid, uuid, text, text, text, boolean, text, text)',
      'api.v1_retailer_save(uuid, text, text, text, uuid, text, numeric, numeric, text, integer, text)', 'api.v1_dealers(text)', 'api.v1_dealer_get(uuid)',
      'api.v1_dealer_opening(uuid, numeric, date, text)', 'api.v1_dealer_adjust(uuid, numeric, text)', 'api.v1_credit_exception_request(uuid, numeric, date, text)',
      'api.v1_credit_check(uuid, numeric)', 'api.v1_dealer_status(uuid, text, integer, text)', 'api.v1_dealer_reassign(uuid, uuid, uuid, date, text)',
      'api.v1_location_consent(boolean, text)', 'api.v1_visit_plan(uuid, uuid, date)', 'api.v1_visit_record(uuid, text, text, numeric, numeric)',
      'api.v1_dealer_contact_link(uuid, text, text)', 'api.v1_dealer_statement(uuid, date, date)', 'api.v1_dealer_qr_lookup(text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_dealer_apply_reassignments() to service_role';
  end if;
end $$;

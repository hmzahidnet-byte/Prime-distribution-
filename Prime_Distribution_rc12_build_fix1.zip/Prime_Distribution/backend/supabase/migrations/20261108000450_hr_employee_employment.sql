-- 20261108000450_hr_employee_employment.sql  (S10)
-- Canonical HR identity chain (blueprint canonical objects hr.employee / hr.employment): every company membership has an
-- employee record and an employment lifecycle. ADR cross-cutting rule: "active employee and live assignment checked for
-- every privileged write" -> iam.fn_context checks hr.fn_employment_active when setting hr.require_active_employment.
-- Membership changes mirror into employment automatically; the HR module (S45) adds the full employee master.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table hr.employee (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  person_id      uuid not null references core.person(id),
  membership_id  uuid not null,
  employee_code  text,
  created_at     timestamptz not null default clock_timestamp(),
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1,
  unique (id, company_id),
  unique (membership_id),
  foreign key (membership_id, company_id) references iam.company_membership (id, company_id)
);
create unique index employee_code_uq on hr.employee (company_id, employee_code) where employee_code is not null;
create trigger trg_employee_touch before update on hr.employee for each row execute function core.fn_touch_row();
create trigger trg_employee_nodel before delete on hr.employee for each row execute function core.fn_deny_delete();
create trigger trg_employee_audit after insert or update on hr.employee for each row execute function audit.fn_row_change();

create table hr.employment (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  employee_id     uuid not null,
  status          text not null default 'active' check (status in ('active','suspended','terminated')),
  effective_from  date not null default current_date,
  effective_to    date,
  reason          text,
  created_at      timestamptz not null default clock_timestamp(),
  updated_at      timestamptz not null default clock_timestamp(),
  row_version     integer not null default 1,
  unique (id, company_id),
  check ((status = 'terminated') = (effective_to is not null)),
  check (effective_to is null or effective_to >= effective_from),
  foreign key (employee_id, company_id) references hr.employee (id, company_id)
);
create unique index employment_one_open on hr.employment (employee_id) where status <> 'terminated';

create function hr.fn_employment_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.id <> old.id or new.company_id <> old.company_id or new.employee_id <> old.employee_id or new.effective_from <> old.effective_from then
    raise exception 'E_IMMUTABLE: employment identity cannot change' using errcode = 'P0001';
  end if;
  if old.status = 'terminated' then
    raise exception 'E_IMMUTABLE: terminated employment cannot change; start a new employment' using errcode = 'P0001';
  end if;
  if new.status is distinct from old.status then
    update core.person set authz_epoch = authz_epoch + 1 where id = (select e.person_id from hr.employee e where e.id = new.employee_id);
  end if;
  return new;
end $$;
create trigger trg_employment_guard before update on hr.employment for each row execute function hr.fn_employment_guard();
create trigger trg_employment_touch before update on hr.employment for each row execute function core.fn_touch_row();
create trigger trg_employment_nodel before delete on hr.employment for each row execute function core.fn_deny_delete();
create trigger trg_employment_audit after insert or update on hr.employment for each row execute function audit.fn_row_change();

-- Membership -> employee + employment (created with the membership; status mirrored).
create function hr.fn_membership_to_employee() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v_emp uuid;
begin
  insert into hr.employee (company_id, person_id, membership_id, employee_code)
  values (new.company_id, new.person_id, new.id, new.employee_no) returning id into v_emp;
  insert into hr.employment (company_id, employee_id, status, effective_from)
  values (new.company_id, v_emp, case when new.status = 'active' then 'active' else 'suspended' end, new.started_on);
  return null;
end $$;
create trigger trg_membership_to_employee after insert on iam.company_membership for each row execute function hr.fn_membership_to_employee();

create function hr.fn_membership_mirror_employment() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if new.status is distinct from old.status then
    update hr.employment em
       set status = case new.status when 'active' then 'active' when 'ended' then 'terminated' else 'suspended' end,
           effective_to = case when new.status = 'ended' then greatest(coalesce(new.ended_on, current_date), em.effective_from) else null end,
           reason = case when new.status = 'ended' then coalesce(new.end_reason, 'membership ended') else em.reason end
     where em.status <> 'terminated'
       and em.employee_id = (select e.id from hr.employee e where e.membership_id = new.id);
  end if;
  return null;
end $$;
create trigger trg_membership_mirror_employment after update of status on iam.company_membership for each row execute function hr.fn_membership_mirror_employment();

create function hr.fn_employment_active(p_company uuid, p_person uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from hr.employee e join hr.employment em on em.employee_id = e.id
                  where e.company_id = p_company and e.person_id = p_person and em.status = 'active'
                    and em.effective_from <= current_date and (em.effective_to is null or em.effective_to >= current_date))
$$;

reset role;

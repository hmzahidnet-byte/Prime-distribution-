-- 20261108004300_consolidated_closure.sql  (ধাপ ১ / S63 — 02_CONSOLIDATED_DESIGN + 14_TRACEABILITY line by line; see docs/V180_CONSOLIDATED_AUDIT_BN.md)
-- Gaps found and closed here:
--   05/13 FIN-002  COGS at transfer of control: dealer delivery is the default; between dispatch and delivery the cost sits in
--                  "goods in transit" (1240). Setting sales.cogs.timing = delivery (default) | dispatch. Control passes at the first of:
--                  delivery confirmation, courier release/partial release, or a sales return (a return presupposes it).
--   04/10          warehouse transfers with in-transit control: approved -> dispatched (stock in the company's TRANSIT warehouse,
--                  cost carried) -> received at the destination; a shortage is written off only by another person with adjust approval.
--                  Setting inventory.transfer.in_transit (default true; false = the old one-step transfer).
--   02/03 MFG-003  spare parts issued from stock to a machine (FEFO, average cost) -> maintenance expense; machine cost report.
--   08/12          periodic access review: every active position in the company is reviewed (keep / revoke) by someone other than
--                  the holder; the review closes only when every line is decided.
--   05             weekly dealer due (Tuesday close / 50 %): configurable and DISABLED by default.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('sales.cogs.timing', 'sales', 'text', '"delivery"', null, null, '["delivery","dispatch"]', 'বিক্রীত পণ্যের খরচ কখন: ডেলিভারিতে / প্রেরণে', 'FIN-002', true, 2520),
  ('inventory.transfer.in_transit', 'inventory', 'bool', 'true', null, null, null, 'গুদাম-স্থানান্তরে "পথে" ধাপ (পাঠানো → গ্রহণ)', '04 / 10', false, 2521),
  ('sales.weekly_due.enabled', 'sales', 'bool', 'false', null, null, null, 'সাপ্তাহিক ডিলার-বকেয়া নীতি চালু', '05 (ডিফল্ট বন্ধ)', false, 2522),
  ('sales.weekly_due.weekday', 'sales', 'int', '2', '0', '6', null, 'সাপ্তাহিক হিসাব বন্ধের দিন (০ রবি … ২ মঙ্গল … ৬ শনি)', '05', false, 2523),
  ('sales.weekly_due.pct', 'sales', 'numeric', '50', '1', '100', null, 'সাপ্তাহিক পরিশোধযোগ্য অংশ (%)', '05', false, 2524)
on conflict (key) do nothing;

insert into finance.coa_template (code, name_bn, type, parent, postable) values
  ('1240', 'পথে থাকা বিক্রীত পণ্য (ডেলিভারির আগে)', 'asset', '1000', true),
  ('5820', 'যন্ত্র রক্ষণাবেক্ষণ ও যন্ত্রাংশ', 'expense', '5000', true) on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values
  ('inv.transit', '1240', 'পথে থাকা বিক্রীত পণ্য'), ('mfg.maintenance', '5820', 'যন্ত্র রক্ষণাবেক্ষণ ও যন্ত্রাংশ') on conflict do nothing;

-- ================================================================ FIN-002 COGS at transfer of control
create table sales.cogs_recognition (
  dispatch_id    uuid primary key references sales.dispatch(id),
  company_id     uuid not null,
  mode           text not null check (mode in ('delivery','dispatch')),
  amount         numeric(16,4) not null check (amount >= 0),
  recognized_at  timestamptz,
  trigger_event  text check (trigger_event is null or trigger_event in ('dispatch','delivery','courier_release','return')),
  created_at     timestamptz not null default clock_timestamp()
);
create function sales.fn_cogs_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.recognized_at is not null or new.dispatch_id <> old.dispatch_id or new.mode <> old.mode or new.amount <> old.amount then
    raise exception 'E_IMMUTABLE: cost of sales is recognised once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_cogs_recognition_guard before update on sales.cogs_recognition for each row execute function sales.fn_cogs_guard();
create trigger trg_cogs_recognition_nodel before delete on sales.cogs_recognition for each row execute function core.fn_deny_delete();
create trigger trg_cogs_recognition_audit after insert or update on sales.cogs_recognition for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'cogs_recognition');

-- Moves the dispatch cost from goods-in-transit to COGS, once (idempotent: a second call does nothing).
create function sales.fn_recognize_cogs(p_dispatch uuid, p_event text) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare c sales.cogs_recognition%rowtype; v_no text;
begin
  select * into c from sales.cogs_recognition where dispatch_id = p_dispatch for update;
  if not found or c.recognized_at is not null then return; end if;
  select d.number into v_no from sales.dispatch d where d.id = p_dispatch;
  if c.amount > 0 then
    perform finance.fn_emit(c.company_id, 'cogs:' || p_dispatch, 'বিক্রীত পণ্যের খরচ (মালিকানা হস্তান্তর) ' || coalesce(v_no, ''), jsonb_build_array(
      jsonb_build_object('key', 'sales.cogs', 'dr', c.amount), jsonb_build_object('key', 'inv.transit', 'cr', c.amount)));
  end if;
  update sales.cogs_recognition set recognized_at = clock_timestamp(), trigger_event = p_event where dispatch_id = p_dispatch;
end $$;

create or replace function api.v1_dispatch_post(p_order_id uuid, p_vehicle text, p_driver text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype; l jsonb; a jsonb; v_id uuid := gen_random_uuid(); n integer := 0; v_cost numeric; v_lines jsonb := '[]'::jsonb; v_cogs numeric := 0; rs uuid;
        v_mode text;
begin
  select * into o from sales.sales_order where id = p_order_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'order'); end if;
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_resource(o.company_id, null, null, null, o.warehouse_id), true);
  if o.status <> 'allocated' then perform core.fn_raise('E_INVALID_ACTION', 'dispatch only an allocated (approved) order'); end if;
  perform set_config('mohona.change_reason', 'dispatch ' || o.number, true);
  for l in select * from jsonb_array_elements(o.lines) loop
    select r.id into rs from inventory.reservation r where r.company_id = o.company_id and r.batch_ref = 'SO:' || o.number and r.product_id = (l ->> 'product_id')::uuid and r.status = 'active' for update;
    update inventory.reservation set status = 'consumed', consumed_qty = qty where id = rs;
    for a in select * from jsonb_array_elements(inventory.fn_fefo(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
      n := n + 1;
      v_cost := inventory.fn_post_move(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'sale', -((a ->> 'qty')::numeric), null,
                                       'sales.dispatch', v_id, n, 'dispatch ' || o.number);
      v_lines := v_lines || jsonb_build_array(jsonb_build_object('product_id', l ->> 'product_id', 'lot_id', a ->> 'lot_id', 'qty', (a ->> 'qty')::numeric, 'unit_cost', round(v_cost, 6)));
      v_cogs := v_cogs + round((a ->> 'qty')::numeric * v_cost, 4);
    end loop;
  end loop;
  insert into sales.dispatch (id, company_id, number, order_id, vehicle, driver_name, lines, cogs, dispatched_by)
  values (v_id, o.company_id, core.fn_next_number(o.company_id, 'sales.dispatch', v_id), o.id, p_vehicle, p_driver, v_lines, v_cogs, me.person_id);
  update sales.sales_order set status = 'dispatched' where id = o.id;
  v_mode := coalesce(config.fn_get_text(o.company_id, 'sales.cogs.timing'), 'delivery');
  insert into sales.cogs_recognition (dispatch_id, company_id, mode, amount, recognized_at, trigger_event)
  values (v_id, o.company_id, v_mode, v_cogs, case when v_mode = 'dispatch' then clock_timestamp() end, case when v_mode = 'dispatch' then 'dispatch' end);
  perform finance.fn_emit(o.company_id, 'dispatch:' || v_id, case when v_mode = 'dispatch' then 'বিক্রীত পণ্যের খরচ ' else 'পথে থাকা বিক্রীত পণ্য ' end || o.number, jsonb_build_array(
    jsonb_build_object('key', case when v_mode = 'dispatch' then 'sales.cogs' else 'inv.transit' end, 'dr', v_cogs), jsonb_build_object('key', 'inv.fg', 'cr', v_cogs)));
  return jsonb_build_object('dispatch_id', v_id, 'lines', v_lines, 'cogs_timing', v_mode);
end $$;

-- delivery confirmed -> control passed
create function sales.fn_on_dispatch_delivered() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if old.delivered_at is null and new.delivered_at is not null then perform sales.fn_recognize_cogs(new.id, 'delivery'); end if;
  return null;
end $$;
create trigger trg_dispatch_cogs after update on sales.dispatch for each row execute function sales.fn_on_dispatch_delivered();

-- courier released (fully or partly) to the dealer -> control passed for that invoice's dispatch
create function sales.fn_on_shipment_released() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare d uuid;
begin
  if new.status is distinct from old.status and new.status in ('PARTIAL_RELEASED','RELEASED') then
    select ds.id into d from sales.invoice i join sales.dispatch ds on ds.order_id = i.order_id where i.id = new.invoice_id;
    if d is not null then perform sales.fn_recognize_cogs(d, 'courier_release'); end if;
  end if;
  return null;
end $$;
create trigger trg_shipment_cogs after update on sales.shipment for each row execute function sales.fn_on_shipment_released();

-- a sales return reverses COGS, so COGS must have been recognised first (refused goods: recognise + reverse = net zero)
create function sales.fn_on_return_cogs() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare d uuid;
begin
  select ds.id into d from sales.invoice i join sales.dispatch ds on ds.order_id = i.order_id where i.id = new.invoice_id;
  if d is not null then perform sales.fn_recognize_cogs(d, 'return'); end if;
  return new;
end $$;
create trigger trg_sales_return_cogs before insert on sales.sales_return for each row execute function sales.fn_on_return_cogs();

create function api.v1_goods_in_transit() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object('total', coalesce((select sum(c.amount) from sales.cogs_recognition c where c.company_id = me.company_id and c.recognized_at is null), 0),
    'dispatches', coalesce((select jsonb_agg(jsonb_build_object('dispatch', d.number, 'order', o.number, 'dealer', dl.name_bn, 'cost', c.amount, 'dispatched_at', d.dispatched_at)
                                              order by d.dispatched_at)
                              from sales.cogs_recognition c join sales.dispatch d on d.id = c.dispatch_id join sales.sales_order o on o.id = d.order_id
                              join sales.dealer dl on dl.id = o.dealer_id
                             where c.company_id = me.company_id and c.recognized_at is null), '[]'::jsonb));
end $$;

-- ================================================================ warehouse transfers with in-transit control
alter table inventory.transfer drop constraint if exists transfer_status_check;
alter table inventory.transfer add constraint transfer_status_check
  check (status in ('pending_approval','posted','rejected','cancelled','in_transit','received','received_short'));
alter table inventory.transfer add column transit_warehouse uuid references inventory.warehouse(id);
alter table inventory.transfer add column received_lines jsonb;
alter table inventory.transfer add column received_by uuid references core.person(id);
alter table inventory.transfer add column received_at timestamptz;
alter table inventory.transfer add column shortage_note text;
alter table inventory.transfer add column shortage_decided_by uuid references core.person(id);
alter table inventory.transfer add column shortage_decided_at timestamptz;

create or replace function inventory.fn_transfer_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_free text[];
begin
  v_free := case
    when old.status = 'pending_approval' then array['status','posted_lines','posted_at','approval_request_id','transit_warehouse']
    when old.status in ('in_transit','received_short') then array['status','received_lines','received_by','received_at','shortage_note','shortage_decided_by','shortage_decided_at']
    else null end;
  if v_free is null or (to_jsonb(old) - v_free) <> (to_jsonb(new) - v_free) then
    raise exception 'E_IMMUTABLE: a transfer is decided once; dispatched goods are only received or written off' using errcode = 'P0001';
  end if;
  return new;
end $$;

-- The company's TRANSIT warehouse (created on first use; stock there is "on the road", not available anywhere).
create function inventory.fn_transit_warehouse(p_company uuid) returns uuid
language plpgsql security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  perform pg_advisory_xact_lock(hashtext('transit_wh' || p_company::text));
  select w.id into v from inventory.warehouse w where w.company_id = p_company and w.kind = 'transit' and w.status = 'active' order by w.created_at limit 1;
  if v is null then
    insert into inventory.warehouse (company_id, code, name_bn, kind) values (p_company, 'TRANSIT', 'পথে থাকা মাল', 'transit') returning id into v;
  end if;
  return v;
end $$;

create or replace function inventory.fn_post_transfer(p_id uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare t inventory.transfer%rowtype; l jsonb; a jsonb; n integer := 0; v_cost numeric; posted jsonb := '[]'::jsonb; v_tw uuid; v_two boolean;
begin
  select * into t from inventory.transfer where id = p_id for update;
  if t.status <> 'pending_approval' then return; end if;
  v_two := coalesce(config.fn_get_bool(t.company_id, 'inventory.transfer.in_transit'), true);
  if v_two then v_tw := inventory.fn_transit_warehouse(t.company_id); end if;
  for l in select * from jsonb_array_elements(t.lines) loop
    if not inventory.fn_product_usable(t.company_id, (l ->> 'product_id')::uuid) then raise exception 'E_PRODUCT_ARCHIVED' using errcode = 'P0001'; end if;
    for a in select * from jsonb_array_elements(inventory.fn_fefo(t.company_id, t.from_warehouse, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
      n := n + 1;
      v_cost := inventory.fn_post_move(t.company_id, t.from_warehouse, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'transfer_out', -((a ->> 'qty')::numeric), null,
                                       'inventory.transfer', t.id, n, t.reason);
      perform inventory.fn_post_move(t.company_id, coalesce(v_tw, t.to_warehouse), (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'transfer_in', (a ->> 'qty')::numeric, v_cost,
                                     'inventory.transfer', t.id, 10000 + n, t.reason);
      posted := posted || jsonb_build_array(jsonb_build_object('product_id', l ->> 'product_id', 'lot_id', a ->> 'lot_id', 'qty', (a ->> 'qty')::numeric, 'unit_cost', round(v_cost, 6)));
    end loop;
  end loop;
  update inventory.transfer set status = case when v_two then 'in_transit' else 'posted' end, posted_lines = posted, posted_at = clock_timestamp(), transit_warehouse = v_tw
   where id = t.id;
end $$;

-- Destination receives what physically arrived: lines [{lot_id, qty}]. What is missing becomes a shortage that waits for an
-- independent decision (found later / write off). Stock in transit is never available for sale or issue.
create function api.v1_transfer_receive(p_transfer_id uuid, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t inventory.transfer%rowtype; l jsonb; v_got numeric; v_short numeric := 0; n integer := 20000; v_cost numeric; v_rec jsonb := '[]'::jsonb;
begin
  select * into t from inventory.transfer where id = p_transfer_id and company_id = iam.fn_context_company() for update;
  if not found or t.status <> 'in_transit' then perform core.fn_raise('E_NOT_FOUND', 'transfer on the road'); end if;
  select * into me from iam.fn_require('inventory.receipt.post', iam.fn_resource(t.company_id, null, null, null, t.to_warehouse), true);
  if jsonb_typeof(coalesce(p_lines, '[]'::jsonb)) <> 'array' then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(coalesce(p_lines, '[]'::jsonb)) loop
    if not exists (select 1 from jsonb_array_elements(t.posted_lines) x where x ->> 'lot_id' = l ->> 'lot_id') then perform core.fn_raise('E_INVALID_ACTION', 'lot not on this transfer'); end if;
  end loop;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'transfer received'), true);
  for l in select * from jsonb_array_elements(t.posted_lines) loop
    v_got := coalesce((select sum((x ->> 'qty')::numeric) from jsonb_array_elements(coalesce(p_lines, '[]'::jsonb)) x where x ->> 'lot_id' = l ->> 'lot_id'), 0);
    if v_got < 0 or v_got > (l ->> 'qty')::numeric then perform core.fn_raise('E_INVALID_ACTION', 'received more than was sent'); end if;
    if v_got > 0 then
      n := n + 1;
      v_cost := inventory.fn_post_move(t.company_id, t.transit_warehouse, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, 'transfer_out', -v_got, null, 'inventory.transfer', t.id, n, 'received');
      n := n + 1;
      perform inventory.fn_post_move(t.company_id, t.to_warehouse, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, 'transfer_in', v_got, v_cost, 'inventory.transfer', t.id, n, 'received');
    end if;
    v_short := v_short + ((l ->> 'qty')::numeric - v_got);
    v_rec := v_rec || jsonb_build_array(jsonb_build_object('product_id', l ->> 'product_id', 'lot_id', l ->> 'lot_id', 'sent', (l ->> 'qty')::numeric, 'received', v_got,
                                                           'short', (l ->> 'qty')::numeric - v_got));
  end loop;
  if v_short > 0 and length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'a shortage needs the reason'); end if;
  update inventory.transfer set status = case when v_short > 0 then 'received_short' else 'received' end, received_lines = v_rec, received_by = me.person_id,
         received_at = clock_timestamp(), shortage_note = case when v_short > 0 then btrim(p_reason) end
   where id = t.id;
  return jsonb_build_object('transfer_id', t.id, 'status', case when v_short > 0 then 'received_short' else 'received' end, 'short_qty', v_short, 'lines', v_rec);
end $$;

-- Shortage decision (another person with adjustment approval): 'found' moves the given lots on to the destination, 'write_off'
-- takes what is still missing out of the transit warehouse as an inventory loss (journal through the stock-move trigger).
create function api.v1_transfer_shortage_decide(p_transfer_id uuid, p_decision text, p_found jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t inventory.transfer%rowtype; l jsonb; v_left numeric; v_found numeric; v_cost numeric; n integer := 30000; v_rec jsonb := '[]'::jsonb; v_rest numeric := 0;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into t from inventory.transfer where id = p_transfer_id and company_id = iam.fn_context_company() for update;
  if not found or t.status <> 'received_short' then perform core.fn_raise('E_NOT_FOUND', 'transfer with a shortage'); end if;
  select * into me from iam.fn_require('inventory.adjust.approve', iam.fn_resource(t.company_id, null, null, null, t.to_warehouse), true);
  if me.person_id = t.received_by then perform core.fn_raise('E_SELF_APPROVAL', 'the receiver does not decide the shortage'); end if;
  if coalesce(p_decision, '') not in ('found','write_off') then perform core.fn_raise('E_INVALID_ACTION', 'decision'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  n := n + coalesce((select count(*)::integer from inventory.stock_move s where s.doc_type = 'inventory.transfer' and s.doc_id = t.id), 0);
  for l in select * from jsonb_array_elements(t.received_lines) loop
    v_left := (l ->> 'short')::numeric;
    v_found := case when p_decision = 'found'
                    then least(v_left, coalesce((select sum((x ->> 'qty')::numeric) from jsonb_array_elements(coalesce(p_found, '[]'::jsonb)) x where x ->> 'lot_id' = l ->> 'lot_id'), 0))
                    else 0 end;
    if v_found > 0 then
      n := n + 1;
      v_cost := inventory.fn_post_move(t.company_id, t.transit_warehouse, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, 'transfer_out', -v_found, null, 'inventory.transfer', t.id, n, 'found');
      n := n + 1;
      perform inventory.fn_post_move(t.company_id, t.to_warehouse, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, 'transfer_in', v_found, v_cost, 'inventory.transfer', t.id, n, 'found');
    end if;
    if p_decision = 'write_off' and v_left > 0 then
      n := n + 1;
      perform inventory.fn_post_move(t.company_id, t.transit_warehouse, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, 'adjust_out', -v_left, null, 'inventory.transfer', t.id, n,
                                     'transfer shortage written off: ' || p_reason);
    end if;
    v_rest := v_rest + case when p_decision = 'write_off' then 0 else v_left - v_found end;
    v_rec := v_rec || jsonb_build_array(l || jsonb_build_object('received', (l ->> 'received')::numeric + v_found,
                                                                'short', case when p_decision = 'write_off' then 0 else v_left - v_found end,
                                                                'written_off', case when p_decision = 'write_off' then v_left else 0 end + coalesce((l ->> 'written_off')::numeric, 0)));
  end loop;
  update inventory.transfer set received_lines = v_rec, status = case when v_rest > 0 then 'received_short' else 'received' end,
         shortage_decided_by = me.person_id, shortage_decided_at = clock_timestamp(), shortage_note = coalesce(shortage_note, '') || ' | ' || p_reason
   where id = t.id;
  return jsonb_build_object('transfer_id', t.id, 'status', case when v_rest > 0 then 'received_short' else 'received' end, 'still_short', v_rest, 'lines', v_rec);
end $$;

create function api.v1_transfers_on_road() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('transfer_id', t.id, 'number', t.number, 'from', wf.name_bn, 'to', wt.name_bn, 'status', t.status,
                                                        'dispatched_at', t.posted_at, 'lines', coalesce(t.received_lines, t.posted_lines),
                                                        'value', (select sum((x ->> 'qty')::numeric * (x ->> 'unit_cost')::numeric) from jsonb_array_elements(t.posted_lines) x))
                                     order by t.posted_at)
                     from inventory.transfer t join inventory.warehouse wf on wf.id = t.from_warehouse join inventory.warehouse wt on wt.id = t.to_warehouse
                    where t.company_id = me.company_id and t.status in ('in_transit','received_short')), '[]'::jsonb);
end $$;

-- ================================================================ MFG-003 spare parts issued to a machine
create table mfg.spare_usage (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  machine_id   uuid not null,
  warehouse_id uuid not null,
  product_id   uuid not null,
  qty          numeric(18,4) not null check (qty > 0),
  value        numeric(16,4) not null check (value >= 0),
  lots         jsonb not null,                       -- [{lot_id, qty, unit_cost}] FEFO
  reason       text not null check (length(btrim(reason)) > 0),
  used_by      uuid not null references core.person(id),
  used_at      timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (machine_id, company_id) references mfg.machine (id, company_id),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id),
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);
create trigger trg_spare_usage_no_mutation before update or delete on mfg.spare_usage for each row execute function core.fn_deny_mutation();
create trigger trg_spare_usage_audit after insert on mfg.spare_usage for each row execute function audit.fn_row_change();
select core.fn_apply_rls('mfg', 'spare_usage');

create function api.v1_spare_issue(p_machine_id uuid, p_warehouse_id uuid, p_product_id uuid, p_qty numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); a jsonb; n integer := 0; v_cost numeric; v_val numeric := 0; v_lots jsonb := '[]'::jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.machine.manage', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if not exists (select 1 from mfg.machine m where m.id = p_machine_id and m.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'machine'); end if;
  if coalesce(p_qty, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'quantity'); end if;
  if not inventory.fn_product_usable(me.company_id, p_product_id) then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  for a in select * from jsonb_array_elements(inventory.fn_fefo(me.company_id, p_warehouse_id, p_product_id, p_qty)) loop
    n := n + 1;
    v_cost := inventory.fn_post_move(me.company_id, p_warehouse_id, p_product_id, (a ->> 'lot_id')::uuid, 'issue', -((a ->> 'qty')::numeric), null, 'mfg.spare_usage', v_id, n, p_reason);
    v_val := v_val + round((a ->> 'qty')::numeric * v_cost, 4);
    v_lots := v_lots || jsonb_build_array(jsonb_build_object('lot_id', a ->> 'lot_id', 'qty', (a ->> 'qty')::numeric, 'unit_cost', round(v_cost, 6)));
  end loop;
  insert into mfg.spare_usage (id, company_id, machine_id, warehouse_id, product_id, qty, value, lots, reason, used_by)
  values (v_id, me.company_id, p_machine_id, p_warehouse_id, p_product_id, p_qty, v_val, v_lots, btrim(p_reason), me.person_id);
  if v_val > 0 then
    perform finance.fn_emit(me.company_id, 'spare:' || v_id, 'যন্ত্রাংশ ব্যবহার', jsonb_build_array(
      jsonb_build_object('key', 'mfg.maintenance', 'dr', v_val), jsonb_build_object('key', finance.fn_inv_key(p_product_id), 'cr', v_val, 'product_id', p_product_id)));
  end if;
  return jsonb_build_object('usage_id', v_id, 'value', v_val, 'lots', v_lots);
end $$;

create function api.v1_machine_costs(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('mfg.bom.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('machine_id', m.id, 'machine', m.code || ' · ' || m.name_bn,
           'spares', coalesce((select sum(u.value) from mfg.spare_usage u where u.machine_id = m.id and u.used_at::date between f and t), 0),
           'maintenance_requests', coalesce((select sum(r.amount) from mfg.machine_maintenance x join finance.money_request r on r.id = x.money_request_id
                                              where x.machine_id = m.id and r.status = 'POSTED' and x.done_at::date between f and t), 0),
           'breakdowns', (select count(*) from mfg.machine_maintenance x where x.machine_id = m.id and x.kind = 'breakdown' and x.done_at::date between f and t),
           'downtime_minutes', coalesce((select sum(x.downtime_minutes) from mfg.machine_maintenance x where x.machine_id = m.id and x.done_at::date between f and t), 0))
           order by m.code) from mfg.machine m where m.company_id = me.company_id), '[]'::jsonb);
end $$;

-- ================================================================ access review (08 / 12)
create table iam.access_review (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  title       text not null check (length(btrim(title)) > 0),
  status      text not null default 'open' check (status in ('open','closed')),
  started_by  uuid not null references core.person(id),
  started_at  timestamptz not null default clock_timestamp(),
  closed_by   uuid references core.person(id),
  closed_at   timestamptz,
  unique (id, company_id)
);
create table iam.access_review_item (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  review_id      uuid not null,
  assignment_id  uuid not null references iam.position_assignment(id),
  person_id      uuid not null references core.person(id),
  position_code  text not null,
  grants         jsonb not null,                    -- explicit assignment rules at review time (snapshot)
  decision       text check (decision is null or decision in ('keep','revoke')),
  reason         text,
  decided_by     uuid references core.person(id),
  decided_at     timestamptz,
  unique (review_id, assignment_id),
  check (decision is null or (length(btrim(coalesce(reason, ''))) > 0 and decided_by is not null)),
  check (decided_by is null or decided_by <> person_id),
  foreign key (review_id, company_id) references iam.access_review (id, company_id)
);
create function iam.fn_access_review_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if tg_table_name = 'access_review' then
    if old.status = 'closed' or (to_jsonb(old) - array['status','closed_by','closed_at']) <> (to_jsonb(new) - array['status','closed_by','closed_at']) then
      raise exception 'E_IMMUTABLE: a closed access review never changes' using errcode = 'P0001';
    end if;
  elsif old.decision is not null or (to_jsonb(old) - array['decision','reason','decided_by','decided_at']) <> (to_jsonb(new) - array['decision','reason','decided_by','decided_at']) then
    raise exception 'E_IMMUTABLE: a review line is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_access_review_guard before update on iam.access_review for each row execute function iam.fn_access_review_guard();
create trigger trg_access_review_item_guard before update on iam.access_review_item for each row execute function iam.fn_access_review_guard();
create trigger trg_access_review_nodel before delete on iam.access_review for each row execute function core.fn_deny_delete();
create trigger trg_access_review_item_nodel before delete on iam.access_review_item for each row execute function core.fn_deny_delete();
create trigger trg_access_review_audit after insert or update on iam.access_review for each row execute function audit.fn_row_change();
create trigger trg_access_review_item_audit after insert or update on iam.access_review_item for each row execute function audit.fn_row_change();
select core.fn_apply_rls('iam', 'access_review');
select core.fn_apply_rls('iam', 'access_review_item');

create function api.v1_access_review_start(p_title text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_title, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'title'); end if;
  if exists (select 1 from iam.access_review r where r.company_id = me.company_id and r.status = 'open') then
    perform core.fn_raise('E_INVALID_ACTION', 'close the open review first');
  end if;
  perform set_config('mohona.change_reason', 'access review: ' || p_title, true);
  insert into iam.access_review (company_id, title, started_by) values (me.company_id, btrim(p_title), me.person_id) returning id into v_id;
  insert into iam.access_review_item (company_id, review_id, assignment_id, person_id, position_code, grants)
  select me.company_id, v_id, pa.id, m.person_id, pa.position_code,
         coalesce((select jsonb_agg(jsonb_build_object('permission', r.permission_code, 'effect', r.effect, 'scope', r.scope_kind) order by r.permission_code)
                     from iam.assignment_permission_rule r where r.assignment_id = pa.id and r.status = 'active'), '[]'::jsonb)
    from iam.position_assignment pa join iam.company_membership m on m.id = pa.membership_id
    join iam.position_catalog pc on pc.company_id = pa.company_id and pc.code = pa.position_code
   where pa.company_id = me.company_id and pa.status = 'active' and not pc.is_supreme;     -- the Chairman seat is governed by succession, not by review
  return jsonb_build_object('review_id', v_id, 'lines', (select count(*) from iam.access_review_item i where i.review_id = v_id));
end $$;

create function api.v1_access_review_decide(p_item_id uuid, p_decision text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; i iam.access_review_item%rowtype;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  select * into i from iam.access_review_item x where x.id = p_item_id and x.company_id = me.company_id for update;
  if not found or i.decision is not null or (select r.status from iam.access_review r where r.id = i.review_id) <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open review line'); end if;
  if i.person_id = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'nobody reviews their own access'); end if;
  if coalesce(p_decision, '') not in ('keep','revoke') then perform core.fn_raise('E_INVALID_ACTION', 'decision'); end if;
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.access_review_item set decision = p_decision, reason = btrim(p_reason), decided_by = me.person_id, decided_at = clock_timestamp() where id = i.id;
  return jsonb_build_object('item_id', i.id, 'decision', p_decision);
end $$;

-- Closing needs every line decided. 'revoke' lines are returned as the to-do list (ending a position goes through the normal IAM
-- functions, which keep their own approvals and audit — the review never changes access by itself).
create function api.v1_access_review_close(p_review_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r iam.access_review%rowtype;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  select * into r from iam.access_review x where x.id = p_review_id and x.company_id = me.company_id for update;
  if not found or r.status <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open review'); end if;
  if exists (select 1 from iam.access_review_item i where i.review_id = r.id and i.decision is null) then perform core.fn_raise('E_INVALID_ACTION', 'every line needs a decision'); end if;
  perform set_config('mohona.change_reason', 'access review closed', true);
  update iam.access_review set status = 'closed', closed_by = me.person_id, closed_at = clock_timestamp() where id = r.id;
  return jsonb_build_object('review_id', r.id, 'status', 'closed',
    'to_revoke', coalesce((select jsonb_agg(jsonb_build_object('assignment_id', i.assignment_id, 'person', p.full_name_bn, 'position', i.position_code, 'reason', i.reason))
                             from iam.access_review_item i join core.person p on p.id = i.person_id where i.review_id = r.id and i.decision = 'revoke'), '[]'::jsonb));
end $$;

create function api.v1_access_review_get(p_review_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; r iam.access_review%rowtype;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  select * into r from iam.access_review x where x.company_id = me.company_id and (x.id = p_review_id or (p_review_id is null and x.status = 'open'))
   order by x.started_at desc limit 1;
  if not found then return jsonb_build_object('review', null); end if;
  return jsonb_build_object('review_id', r.id, 'title', r.title, 'status', r.status, 'started_at', r.started_at, 'closed_at', r.closed_at,
    'lines', coalesce((select jsonb_agg(jsonb_build_object('item_id', i.id, 'person', p.full_name_bn, 'position', i.position_code, 'grants', i.grants,
                                                           'decision', i.decision, 'reason', i.reason) order by p.full_name_bn, i.position_code)
                         from iam.access_review_item i join core.person p on p.id = i.person_id where i.review_id = r.id), '[]'::jsonb));
end $$;

-- ================================================================ weekly dealer due (05) — disabled by default
-- Week closes on the configured weekday; the dealer must pay pct % of what was owed at that close during the following week.
create function api.v1_weekly_due(p_close_date date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_close date; v_pct numeric; v_wd integer;
begin
  select * into me from iam.fn_require('sales.weekly_summary.read', iam.fn_my_company_resource(), false);
  if not coalesce(config.fn_get_bool(me.company_id, 'sales.weekly_due.enabled'), false) then
    return jsonb_build_object('enabled', false, 'note', 'সাপ্তাহিক বকেয়া-নীতি বন্ধ (চেয়ারম্যান সেটিং থেকে চালু করা যায়)');
  end if;
  v_wd := coalesce(config.fn_get_int(me.company_id, 'sales.weekly_due.weekday'), 2);
  v_pct := coalesce(config.fn_get_numeric(me.company_id, 'sales.weekly_due.pct'), 50);
  v_close := coalesce(p_close_date, current_date);
  v_close := v_close - ((extract(dow from v_close)::integer - v_wd + 7) % 7);          -- last configured weekday on or before the date
  return jsonb_build_object('enabled', true, 'close_date', v_close, 'pay_by', v_close + 7, 'pct', v_pct,
    'dealers', coalesce((select jsonb_agg(x order by x ->> 'dealer') from (
       select jsonb_build_object('dealer_id', d.id, 'dealer', d.code || ' · ' || d.name_bn,
                'owed_at_close', sales.fn_dealer_balance(d.id, v_close),
                'due_this_week', round(greatest(sales.fn_dealer_balance(d.id, v_close), 0) * v_pct / 100, 2),
                'paid_since', -coalesce((select sum(l.amount) from sales.dealer_ledger l where l.dealer_id = d.id and l.kind = 'collection'
                                          and l.entry_date > v_close and l.entry_date <= v_close + 7), 0),
                'remaining', greatest(round(greatest(sales.fn_dealer_balance(d.id, v_close), 0) * v_pct / 100, 2)
                                      + coalesce((select sum(l.amount) from sales.dealer_ledger l where l.dealer_id = d.id and l.kind = 'collection'
                                                   and l.entry_date > v_close and l.entry_date <= v_close + 7), 0), 0)) x
         from sales.dealer d where d.company_id = me.company_id and d.status = 'active' and sales.fn_dealer_balance(d.id, v_close) > 0) q), '[]'::jsonb));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_goods_in_transit()', 'api.v1_transfer_receive(uuid, jsonb, text)', 'api.v1_transfer_shortage_decide(uuid, text, jsonb, text)',
      'api.v1_transfers_on_road()', 'api.v1_spare_issue(uuid, uuid, uuid, numeric, text)', 'api.v1_machine_costs(date, date)',
      'api.v1_access_review_start(text)', 'api.v1_access_review_decide(uuid, text, text)', 'api.v1_access_review_close(uuid)', 'api.v1_access_review_get(uuid)',
      'api.v1_weekly_due(date)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

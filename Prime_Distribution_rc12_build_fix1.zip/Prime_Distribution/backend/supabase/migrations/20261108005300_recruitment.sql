-- 20261108005300_recruitment.sql  (S69 — Master Closure §4 HR domain "Recruitment, assignment, attendance, leave, payroll, succession":
-- the recruitment part was the one missing piece; see docs/V180_AZ_STATUS_BN.md)
-- vacancy (position, wing, headcount, approved by another person) -> applicants -> interviews with a score and a written note ->
-- offer (salary stays inside HR, approved by MD / Chairman, never by its maker) -> accepted offer becomes a hire through the existing
-- api.v1_hr_hire (membership + position + onboarding checklist). Rejections keep a reason; nothing is deleted. STATUS: WRITTEN.
set role erp_owner;

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('hr.recruit.manage',  'hr', 'নিয়োগ: পদ-খালি, আবেদন, সাক্ষাৎকার', 'write', true, true, array['COMPANY','WING'], 'active', 2700),
  ('hr.recruit.approve', 'hr', 'নিয়োগ: পদ-খালি ও অফার অনুমোদন', 'approve', true, false, array['COMPANY','WING'], 'active', 2701);
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('HR_OFFICER','hr.recruit.manage','allow','COMPANY'), ('MD','hr.recruit.manage','allow','COMPANY'), ('MD','hr.recruit.approve','allow','COMPANY'),
  ('MD','iam.onboarding.manage','allow','COMPANY')
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

create table hr.vacancy (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  position_code  text not null,
  home_wing_id   uuid,
  title_bn       text not null check (length(btrim(title_bn)) > 0),
  headcount      integer not null check (headcount between 1 and 500),
  description_bn text,
  status         text not null default 'draft' check (status in ('draft','open','filled','closed')),
  created_by     uuid not null references core.person(id),
  approved_by    uuid references core.person(id),
  closed_reason  text,
  created_at     timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  check (approved_by is null or approved_by <> created_by),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create trigger trg_vacancy_nodel before delete on hr.vacancy for each row execute function core.fn_deny_delete();
create trigger trg_vacancy_audit after insert or update on hr.vacancy for each row execute function audit.fn_row_change();
select core.fn_apply_rls('hr', 'vacancy');

create table hr.applicant (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  vacancy_id   uuid not null,
  full_name_bn text not null check (length(btrim(full_name_bn)) > 0),
  phone        text not null,
  cv_path      text,
  source       text,
  status       text not null default 'applied' check (status in ('applied','shortlisted','interviewed','offered','hired','rejected','withdrawn')),
  reject_reason text,
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (vacancy_id, company_id) references hr.vacancy (id, company_id),
  check (status <> 'rejected' or length(btrim(coalesce(reject_reason, ''))) > 0)
);
create unique index ux_applicant_phone on hr.applicant (vacancy_id, phone);
create trigger trg_applicant_nodel before delete on hr.applicant for each row execute function core.fn_deny_delete();
create trigger trg_applicant_audit after insert or update on hr.applicant for each row execute function audit.fn_row_change();
select core.fn_apply_rls('hr', 'applicant');

create table hr.interview (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  applicant_id uuid not null,
  round        integer not null check (round between 1 and 5),
  interviewer  uuid not null references core.person(id),
  score        integer not null check (score between 0 and 100),
  note_bn      text not null check (length(btrim(note_bn)) > 0),
  held_at      timestamptz not null default clock_timestamp(),
  unique (applicant_id, round),
  foreign key (applicant_id, company_id) references hr.applicant (id, company_id)
);
create trigger trg_interview_no_mutation before update or delete on hr.interview for each row execute function core.fn_deny_mutation();
select core.fn_apply_rls('hr', 'interview');

create table hr.offer (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  applicant_id uuid not null,
  salary       numeric(14,2) not null check (salary > 0),
  join_date    date not null,
  status       text not null default 'pending' check (status in ('pending','approved','rejected','accepted','declined')),
  created_by   uuid not null references core.person(id),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  reason       text,
  membership_id uuid,
  unique (id, company_id),
  check (decided_by is null or decided_by <> created_by),
  foreign key (applicant_id, company_id) references hr.applicant (id, company_id)
);
create unique index ux_offer_open on hr.offer (applicant_id) where status in ('pending','approved');
create trigger trg_offer_nodel before delete on hr.offer for each row execute function core.fn_deny_delete();
create trigger trg_offer_audit after insert or update on hr.offer for each row execute function audit.fn_row_change();
select core.fn_apply_rls('hr', 'offer');

-- ================================================================ API
create function api.v1_vacancy_save(p_position_code text, p_home_wing uuid, p_title_bn text, p_headcount integer, p_description_bn text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v uuid;
begin
  select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(iam.fn_context_company(), p_home_wing), true);
  if not exists (select 1 from iam.position_catalog c where c.company_id = me.company_id and c.code = p_position_code and c.is_enabled and not c.is_supreme) then
    perform core.fn_raise('E_INVALID_ACTION', 'an enabled, non-Chairman position');
  end if;
  perform set_config('mohona.change_reason', 'vacancy', true);
  insert into hr.vacancy (company_id, position_code, home_wing_id, title_bn, headcount, description_bn, created_by)
  values (me.company_id, p_position_code, p_home_wing, btrim(p_title_bn), coalesce(p_headcount, 1), p_description_bn, me.person_id) returning id into v;
  return jsonb_build_object('vacancy_id', v, 'status', 'draft');
end $$;

create function api.v1_vacancy_action(p_vacancy_id uuid, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; x hr.vacancy%rowtype;
begin
  select * into x from hr.vacancy where id = p_vacancy_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'vacancy'); end if;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'vacancy ' || p_action), true);
  if p_action = 'open' and x.status = 'draft' then
    select * into me from iam.fn_require('hr.recruit.approve', iam.fn_resource(x.company_id, x.home_wing_id), true);
    if x.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
    update hr.vacancy set status = 'open', approved_by = me.person_id where id = x.id;
  elsif p_action = 'close' and x.status in ('draft','open') then
    select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
    if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
    update hr.vacancy set status = 'closed', closed_reason = btrim(p_reason) where id = x.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || x.status);
  end if;
  return jsonb_build_object('vacancy_id', x.id, 'action', p_action);
end $$;

create function api.v1_applicant_add(p_vacancy_id uuid, p_full_name_bn text, p_phone text, p_cv_path text, p_source text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; x hr.vacancy%rowtype; v uuid; v_phone text := core.fn_phone_canonical(p_phone);
begin
  select * into x from hr.vacancy where id = p_vacancy_id and company_id = iam.fn_context_company();
  if not found or x.status <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open vacancy'); end if;
  select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
  if v_phone is null then perform core.fn_raise('E_CONTACT_REQUIRED'); end if;
  if exists (select 1 from hr.applicant a where a.vacancy_id = x.id and a.phone = v_phone) then perform core.fn_raise('E_DUPLICATE', 'this phone already applied'); end if;
  perform set_config('mohona.change_reason', 'applicant', true);
  insert into hr.applicant (company_id, vacancy_id, full_name_bn, phone, cv_path, source, created_by)
  values (x.company_id, x.id, btrim(p_full_name_bn), v_phone, p_cv_path, p_source, me.person_id) returning id into v;
  return jsonb_build_object('applicant_id', v, 'status', 'applied');
end $$;

-- shortlist | reject | withdraw
create function api.v1_applicant_action(p_applicant_id uuid, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a hr.applicant%rowtype; x hr.vacancy%rowtype;
begin
  select * into a from hr.applicant where id = p_applicant_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'applicant'); end if;
  select * into x from hr.vacancy where id = a.vacancy_id;
  select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'applicant ' || p_action), true);
  if p_action = 'shortlist' and a.status = 'applied' then update hr.applicant set status = 'shortlisted' where id = a.id;
  elsif p_action in ('reject','withdraw') and a.status not in ('hired','rejected','withdrawn') then
    if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
    update hr.applicant set status = case p_action when 'reject' then 'rejected' else 'withdrawn' end, reject_reason = btrim(p_reason) where id = a.id;
    update hr.offer set status = 'declined', reason = btrim(p_reason), decided_at = clock_timestamp() where applicant_id = a.id and status in ('pending','approved');
  else perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || a.status);
  end if;
  return jsonb_build_object('applicant_id', a.id, 'action', p_action);
end $$;

create function api.v1_interview_record(p_applicant_id uuid, p_round integer, p_score integer, p_note_bn text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a hr.applicant%rowtype; x hr.vacancy%rowtype;
begin
  select * into a from hr.applicant where id = p_applicant_id and company_id = iam.fn_context_company() for update;
  if not found or a.status not in ('shortlisted','interviewed') then perform core.fn_raise('E_NOT_FOUND', 'shortlisted applicant'); end if;
  select * into x from hr.vacancy where id = a.vacancy_id;
  select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
  if p_score is null or p_score not between 0 and 100 or length(btrim(coalesce(p_note_bn, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'score 0–100 and a note'); end if;
  perform set_config('mohona.change_reason', 'interview', true);
  insert into hr.interview (company_id, applicant_id, round, interviewer, score, note_bn) values (a.company_id, a.id, coalesce(p_round, 1), me.person_id, p_score, btrim(p_note_bn));
  update hr.applicant set status = 'interviewed' where id = a.id and status = 'shortlisted';
  return jsonb_build_object('applicant_id', a.id, 'round', coalesce(p_round, 1), 'score', p_score);
end $$;

create function api.v1_offer_make(p_applicant_id uuid, p_salary numeric, p_join_date date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a hr.applicant%rowtype; x hr.vacancy%rowtype; v uuid;
begin
  select * into a from hr.applicant where id = p_applicant_id and company_id = iam.fn_context_company() for update;
  if not found or a.status <> 'interviewed' then perform core.fn_raise('E_NOT_FOUND', 'interviewed applicant'); end if;
  select * into x from hr.vacancy where id = a.vacancy_id;
  select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
  if coalesce(p_salary, 0) <= 0 or p_join_date is null or p_join_date < current_date then perform core.fn_raise('E_INVALID_ACTION', 'salary and a join date today or later'); end if;
  perform set_config('mohona.change_reason', 'offer', true);
  insert into hr.offer (company_id, applicant_id, salary, join_date, created_by) values (a.company_id, a.id, round(p_salary, 2), p_join_date, me.person_id) returning id into v;
  update hr.applicant set status = 'offered' where id = a.id;
  return jsonb_build_object('offer_id', v, 'status', 'pending');
end $$;

-- approve | reject (MD / Chairman, never the maker) ; accepted (candidate said yes -> hire) ; declined
create function api.v1_offer_decide(p_offer_id uuid, p_action text, p_employee_no text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o hr.offer%rowtype; a hr.applicant%rowtype; x hr.vacancy%rowtype; j jsonb; v_hired integer;
begin
  select * into o from hr.offer where id = p_offer_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'offer'); end if;
  select * into a from hr.applicant where id = o.applicant_id for update;
  select * into x from hr.vacancy where id = a.vacancy_id for update;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'offer ' || p_action), true);
  if p_action in ('approve','reject') and o.status = 'pending' then
    select * into me from iam.fn_require('hr.recruit.approve', iam.fn_resource(x.company_id, x.home_wing_id), true);
    if o.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
    if p_action = 'reject' and length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
    update hr.offer set status = case p_action when 'approve' then 'approved' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp(), reason = p_reason where id = o.id;
    if p_action = 'reject' then update hr.applicant set status = 'interviewed' where id = a.id; end if;
    return jsonb_build_object('offer_id', o.id, 'status', case p_action when 'approve' then 'approved' else 'rejected' end);
  elsif p_action = 'accepted' and o.status = 'approved' then
    select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
    select count(*) into v_hired from hr.applicant h where h.vacancy_id = x.id and h.status = 'hired';
    if v_hired >= x.headcount then perform core.fn_raise('E_INVALID_ACTION', 'vacancy already filled'); end if;
    j := api.v1_hr_hire(a.full_name_bn, a.phone, null, p_employee_no, x.position_code, x.home_wing_id, null, null, 'hired from vacancy ' || x.title_bn);
    update hr.offer set status = 'accepted', membership_id = (j ->> 'membership_id')::uuid where id = o.id;
    update hr.applicant set status = 'hired' where id = a.id;
    if v_hired + 1 >= x.headcount then update hr.vacancy set status = 'filled' where id = x.id; end if;
    return jsonb_build_object('offer_id', o.id, 'status', 'accepted', 'hire', j);
  elsif p_action = 'declined' and o.status in ('pending','approved') then
    select * into me from iam.fn_require('hr.recruit.manage', iam.fn_resource(x.company_id, x.home_wing_id), true);
    update hr.offer set status = 'declined', decided_at = clock_timestamp(), reason = p_reason where id = o.id;
    update hr.applicant set status = 'withdrawn', reject_reason = coalesce(nullif(btrim(p_reason), ''), 'offer declined') where id = a.id;
    return jsonb_build_object('offer_id', o.id, 'status', 'declined');
  end if;
  perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || o.status);
end $$;

create function api.v1_recruitment_board(p_vacancy_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('hr.recruit.manage', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('vacancy_id', x.id, 'title', x.title_bn, 'position', x.position_code, 'headcount', x.headcount, 'status', x.status,
           'applicants', coalesce((select jsonb_agg(jsonb_build_object('applicant_id', a.id, 'name', a.full_name_bn, 'status', a.status,
                                     'best_score', (select max(i.score) from hr.interview i where i.applicant_id = a.id)) order by a.created_at)
                                   from hr.applicant a where a.vacancy_id = x.id), '[]'::jsonb)) order by x.created_at desc)
     from hr.vacancy x where x.company_id = me.company_id and (p_vacancy_id is null or x.id = p_vacancy_id)), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_vacancy_save(text, uuid, text, integer, text)', 'api.v1_vacancy_action(uuid, text, text)',
      'api.v1_applicant_add(uuid, text, text, text, text)', 'api.v1_applicant_action(uuid, text, text)', 'api.v1_interview_record(uuid, integer, integer, text)',
      'api.v1_offer_make(uuid, numeric, date)', 'api.v1_offer_decide(uuid, text, text, text)', 'api.v1_recruitment_board(uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

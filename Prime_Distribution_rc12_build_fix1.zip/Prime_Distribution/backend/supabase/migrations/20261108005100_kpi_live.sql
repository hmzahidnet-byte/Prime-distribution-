-- 20261108005100_kpi_live.sql  (S68 — Chairman panel KPI and graphs from REAL data; docs/V180_AZ_STATUS_BN.md)
-- Before: 9 KPIs, 5 of them "stored" (typed in by hand) and none wired to the sales / stock / factory / GL tables built later.
-- Now: 41 live KPIs computed on the server from the authoritative tables (invoice, collection, dealer ledger, stock balance, lots,
-- batches, waste, shipments, posted GL, payroll, bills, visits, attendance), plus
--   api.v1_kpi_series  — one value per day / week / month for line, bar and sparkline charts (<= 36 points)
--   api.v1_kpi_split   — one value per territory / dealer / product / warehouse / account for donut and bar charts (area-wise graphs)
-- Same rules as S20: visibility per position, permission at company / wing, factory P&L only for its positions, unknown != zero
-- (a measure with no data source returns null, never 0), Chairman sees all. The old hand-entered KPIs stay for custom figures and are
-- renamed "(হাতে লেখা)". STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

alter table report.kpi_catalog drop constraint if exists kpi_catalog_measure_check;
alter table report.kpi_catalog add constraint kpi_catalog_measure_check check (measure is null or measure ~ '^[a-z][a-z0-9_]{2,40}$');

update report.kpi_catalog set name_bn = name_bn || ' (হাতে লেখা)'
 where company_id is null and source = 'stored' and code in ('sales.amount','cash.position','stock.value','sales.gross_margin','mfg.factory_pnl');

insert into report.kpi_catalog (code, name_bn, formula_bn, unit, source, measure, agg, required_permission, owner_position, default_positions, is_factory_pnl, has_products, refresh_seconds, sort_order) values
  -- DMS / sales
  ('dms.sales',             'বিক্রয় (ইনভয়েস)',        'সময়-পরিসরে ইনভয়েসের মোট টাকা',                         'money',   'live', 'dms_sales',            'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER','WING_HEAD'], false, false, 300, 100),
  ('dms.invoices',          'ইনভয়েস সংখ্যা',           'সময়-পরিসরে ইনভয়েস',                                     'count',   'live', 'dms_invoices',         'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 300, 101),
  ('dms.avg_invoice',       'গড় ইনভয়েস',             'মোট বিক্রয় ÷ ইনভয়েস সংখ্যা',                            'money',   'live', 'dms_avg_invoice',      'avg',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 300, 102),
  ('dms.returns',           'বিক্রয়-ফেরত',             'ফেরতের ক্রেডিট টাকা',                                   'money',   'live', 'dms_returns',          'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER'], false, false, 300, 103),
  ('dms.return_rate',       'ফেরতের হার',             'ফেরত ÷ বিক্রয় × ১০০',                                  'percent', 'live', 'dms_return_rate',      'avg',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 300, 104),
  ('dms.orders_new',        'নতুন অর্ডার',              'সময়-পরিসরে তৈরি অর্ডার',                                'count',   'live', 'dms_orders_new',       'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','STOREKEEPER'], false, false, 300, 105),
  ('dms.orders_open',       'চলমান অর্ডার',             'অনুমোদন / বরাদ্দের অপেক্ষায় অর্ডার (এখন)',               'count',   'live', 'dms_orders_open',      'last', 'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','STOREKEEPER'], false, false, 120, 106),
  ('dms.dispatches',        'প্রেরণ',                  'সময়-পরিসরে পাঠানো চালান',                                'count',   'live', 'dms_dispatches',       'sum',  'kpi.dashboard.read', 'STOREKEEPER', array['MD','SALES_MANAGER','STOREKEEPER'], false, false, 300, 107),
  ('dms.undelivered',       'পৌঁছানো বাকি',             'পাঠানো কিন্তু এখনো গ্রহণ-নিশ্চিত নয়',                      'count',   'live', 'dms_undelivered',      'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','SALES_MANAGER','STOREKEEPER'], false, false, 120, 108),
  ('dms.collected',         'আদায় (যাচাইকৃত)',         'যাচাই হওয়া আদায়ের টাকা',                                 'money',   'live', 'dms_collected',        'sum',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER','CASHIER'], false, false, 300, 109),
  ('dms.collection_pending','যাচাই বাকি আদায়',         'জমা হয়েছে, যাচাই হয়নি (এখন)',                             'money',   'live', 'dms_collection_pending','last','kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER','CASHIER'], false, false, 120, 110),
  ('dms.collection_rate',   'আদায়ের হার',             'যাচাইকৃত আদায় ÷ বিক্রয় × ১০০',                           'percent', 'live', 'dms_collection_rate',  'avg',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER'], false, false, 300, 111),
  ('dms.receivable',        'ডিলারের মোট বকেয়া',        'সময়-শেষে ডিলার-খাতার জের',                               'money',   'live', 'dms_receivable',       'last', 'kpi.dashboard.read', 'FIN_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER'], false, false, 300, 112),
  ('dms.overdue',           'মেয়াদোত্তীর্ণ বকেয়া',      'শেষ তারিখ পার হওয়া খোলা ইনভয়েস (এখন)',                    'money',   'live', 'dms_overdue',          'last', 'kpi.dashboard.read', 'FIN_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER'], false, false, 300, 113),
  -- CRM
  ('crm.dealers_active',    'সক্রিয় ডিলার',            'এখন সক্রিয় ডিলার',                                       'count',   'live', 'crm_dealers_active',   'last', 'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 600, 120),
  ('crm.dealers_new',       'নতুন ডিলার',               'সময়-পরিসরে যুক্ত ডিলার',                                 'count',   'live', 'crm_dealers_new',      'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 600, 121),
  ('crm.retailers',         'সক্রিয় রিটেইলার',          'এখন সক্রিয় রিটেইলার',                                    'count',   'live', 'crm_retailers',        'last', 'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 600, 122),
  ('crm.visits_done',       'সম্পন্ন ভিজিট',            'সময়-পরিসরে সম্পন্ন ভিজিট',                                'count',   'live', 'crm_visits_done',      'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','FIELD_SALES'], false, false, 300, 123),
  ('crm.visit_rate',        'ভিজিট সম্পন্নের হার',       'সম্পন্ন ÷ পরিকল্পিত × ১০০',                               'percent', 'live', 'crm_visit_rate',       'avg',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER'], false, false, 300, 124),
  -- courier
  ('courier.freight_company','কুরিয়ার ভাড়া (কোম্পানির)', 'সময়-পরিসরে কোম্পানির ভাগের ভাড়া',                         'money',   'live', 'courier_freight',      'sum',  'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','FIN_MANAGER'], false, false, 300, 130),
  ('courier.in_transit',    'কুরিয়ারে চলমান চালান',     'কুরিয়ারের হেফাজতে / ফেরত-পথে (এখন)',                     'count',   'live', 'courier_in_transit',   'last', 'kpi.dashboard.read', 'SALES_MANAGER', array['MD','SALES_MANAGER','STOREKEEPER'], false, false, 120, 131),
  -- stock
  ('stock.total_value',     'মোট মজুদ-মূল্য',           'সব গুদামের মজুদ × গড় খরচ (এখন)',                         'money',   'live', 'stock_value_total',    'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','FIN_MANAGER','STOREKEEPER'], false, false, 300, 140),
  ('stock.fg_value',        'তৈরি পণ্যের মজুদ-মূল্য',   'তৈরি-পণ্য গুদাম (এখন)',                                   'money',   'live', 'stock_value_fg',       'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','FIN_MANAGER','STOREKEEPER'], false, false, 300, 141),
  ('stock.raw_value',       'কাঁচামালের মজুদ-মূল্য',     'কাঁচামাল গুদাম (এখন)',                                     'money',   'live', 'stock_value_raw',      'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','FIN_MANAGER','STOREKEEPER','PROD_SUPERVISOR'], false, false, 300, 142),
  ('stock.low_items',       'ন্যূনতমের নিচে কাঁচামাল',   'মজুদ < ন্যূনতম সীমা (এখন)',                                'count',   'live', 'stock_low_items',      'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','STOREKEEPER','PURCHASE_OFFICER','PROD_SUPERVISOR'], false, false, 300, 143),
  ('stock.expiring',        '৩০ দিনে মেয়াদ শেষ লট',     'মজুদ আছে, ৩০ দিনের মধ্যে মেয়াদ শেষ (এখন)',                 'count',   'live', 'stock_expiring',       'last', 'kpi.dashboard.read', 'STOREKEEPER', array['MD','STOREKEEPER','QC_OFFICER'], false, false, 600, 144),
  -- factory
  ('mfg.batches_done',      'সম্পন্ন ব্যাচ',             'সময়-পরিসরে সম্পন্ন উৎপাদন-ব্যাচ',                         'count',   'live', 'mfg_batches_done',     'sum',  'kpi.dashboard.read', 'PROD_SUPERVISOR', array['MD','PROD_SUPERVISOR'], false, false, 300, 150),
  ('mfg.fg_output',         'তৈরি পণ্য (পলি)',          'সম্পন্ন ব্যাচের পলি',                                      'qty',     'live', 'mfg_fg_output',        'sum',  'kpi.dashboard.read', 'PROD_SUPERVISOR', array['MD','PROD_SUPERVISOR','STOREKEEPER'], false, false, 300, 151),
  ('mfg.waste',             'অপচয় (পলি)',              'রেকর্ড / পোস্ট হওয়া অপচয় (বাতিল বাদে)',                    'qty',     'live', 'mfg_waste',            'sum',  'kpi.dashboard.read', 'PROD_SUPERVISOR', array['MD','PROD_SUPERVISOR','QC_OFFICER'], false, false, 300, 152),
  ('mfg.waste_rate',        'অপচয়ের হার',              'অপচয় ÷ (উৎপাদন + অপচয়) × ১০০',                           'percent', 'live', 'mfg_waste_rate',       'avg',  'kpi.dashboard.read', 'PROD_SUPERVISOR', array['MD','PROD_SUPERVISOR'], false, false, 300, 153),
  ('mfg.unit_cost',         'গড় খরচ / পলি',            'সম্পন্ন ব্যাচের গড় একক-খরচ',                               'money',   'live', 'mfg_unit_cost',        'avg',  'kpi.dashboard.read', 'MD', null, true, false, 600, 154),
  ('mfg.factory_profit',    'কারখানার লাভ-ক্ষতি',        'বিক্রয় − বিক্রীত খরচ − উৎপাদন-অপচয়/পার্থক্য − কারখানা-খরচ (পোস্ট হওয়া GL)', 'money', 'live', 'mfg_factory_profit', 'sum', 'kpi.dashboard.read', 'MD', null, true, false, 600, 155),
  -- finance (posted GL only)
  ('fin.revenue',           'আয় (GL)',                 'আয়-হিসাবের নিট ক্রেডিট',                                   'money',   'live', 'fin_revenue',          'sum',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 600, 160),
  ('fin.cogs',              'বিক্রীত পণ্যের খরচ',       'হিসাব ৫১০০ (নিট ডেবিট)',                                    'money',   'live', 'fin_cogs',             'sum',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 600, 161),
  ('fin.gross_margin',      'মোট মুনাফার হার (GL)',     '(বিক্রয় − ফেরত − বিক্রীত খরচ) ÷ (বিক্রয় − ফেরত) × ১০০',     'percent', 'live', 'fin_gross_margin',     'avg',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 600, 162),
  ('fin.expenses',          'মোট ব্যয় (GL)',            'ব্যয়-হিসাবের নিট ডেবিট',                                    'money',   'live', 'fin_expenses',         'sum',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 600, 163),
  ('fin.net_profit',        'নিট লাভ-ক্ষতি',            'আয় − ব্যয় (পোস্ট হওয়া GL)',                                 'money',   'live', 'fin_net_profit',       'sum',  'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER'], false, false, 600, 164),
  ('fin.cash',              'নগদ + ব্যাংক',             'হিসাব ১১xx-এর জের (সময়-শেষে)',                              'money',   'live', 'fin_cash',             'last', 'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER','CASHIER'], false, false, 300, 165),
  ('fin.payable',           'সাপ্লায়ার-দেনা',           'হিসাব ২১০০-এর জের (সময়-শেষে)',                              'money',   'live', 'fin_payable',          'last', 'kpi.dashboard.read', 'FIN_MANAGER', array['MD','FIN_MANAGER','PURCHASE_OFFICER'], false, false, 300, 166),
  ('proc.purchases',        'ক্রয় (বিল)',               'পোস্ট হওয়া সাপ্লায়ার-বিল',                                  'money',   'live', 'proc_purchases',       'sum',  'kpi.dashboard.read', 'PURCHASE_OFFICER', array['MD','FIN_MANAGER','PURCHASE_OFFICER'], false, false, 600, 167),
  -- HR
  ('hr.payroll_net',        'নিট বেতন',               'পোস্ট হওয়া বেতন-রানের নিট (মাস)',                            'money',   'live', 'hr_payroll_net',       'sum',  'kpi.dashboard.read', 'HR_OFFICER', array['MD','FIN_MANAGER','HR_OFFICER','PAYROLL_OFFICER'], false, false, 3600, 170),
  ('hr.present',            'উপস্থিত কর্মী',            'সময়-পরিসরে হাজিরা দেওয়া ভিন্ন কর্মী',                       'count',   'live', 'hr_present',           'sum',  'kpi.dashboard.read', 'HR_OFFICER', array['MD','HR_OFFICER','WING_HEAD'], false, false, 300, 171)
on conflict do nothing;

-- ================================================================ GL helpers (posted and reversed journals both count: a reversal posts the opposite lines)
create function report.fn_gl_net(p_company uuid, p_like text[], d_from date, d_to date) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(l.debit - l.credit), 0)
    from finance.journal_line l join finance.journal j on j.id = l.journal_id join finance.account a on a.id = l.account_id
   where l.company_id = p_company and j.status in ('posted','reversed') and j.journal_date between d_from and d_to and a.code like any (p_like)
$$;
create function report.fn_gl_type_net(p_company uuid, p_type text, d_from date, d_to date) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(l.debit - l.credit), 0)
    from finance.journal_line l join finance.journal j on j.id = l.journal_id join finance.account a on a.id = l.account_id
   where l.company_id = p_company and j.status in ('posted','reversed') and j.journal_date between d_from and d_to and a.type = p_type
$$;

-- Snapshot measures ("now" / as of the end date) do not get a previous-period comparison.
create function report.fn_kpi_is_snapshot(p_measure text) returns boolean
language sql immutable set search_path = pg_catalog as $$
  select p_measure in ('approvals_pending','headcount','dms_orders_open','dms_undelivered','dms_collection_pending','dms_receivable','dms_overdue',
                       'crm_dealers_active','crm_retailers','courier_in_transit','stock_value_total','stock_value_fg','stock_value_raw','stock_low_items',
                       'stock_expiring','fin_cash','fin_payable')
$$;

-- ================================================================ compute (S20 body + live measures)
create or replace function report.fn_kpi_compute(p_company uuid, k report.kpi_catalog, d_from date, d_to date, p_wing uuid) returns numeric
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v numeric; va numeric; vb numeric;
begin
  if k.source = 'live' then
    case k.measure
      when 'approvals_pending' then
        select count(*) into v from core.approval_request r
         where r.company_id = p_company and r.status = 'pending' and (p_wing is null or (r.resource ->> 'wing_id')::uuid = p_wing);
      when 'forms_submitted' then
        select count(*) into v from config.form_submission s
         where s.company_id = p_company and s.status in ('submitted','pending_approval','approved')
           and s.submitted_at::date between d_from and d_to and (p_wing is null or s.wing_id = p_wing);
      when 'headcount' then
        select count(distinct m.id) into v from iam.company_membership m
         where m.company_id = p_company and m.status = 'active' and m.member_kind = 'staff'
           and (p_wing is null or exists (select 1 from iam.position_assignment a where a.membership_id = m.id and a.status = 'active' and a.home_wing_id = p_wing));
      when 'logins_failed' then
        select count(*) into v from iam.login_attempt a
         where a.kind = 'pin_login' and a.outcome in ('failed','locked') and a.occurred_at::date between d_from and d_to
           and a.person_id in (select m.person_id from iam.company_membership m where m.company_id = p_company);
      -- ---------------------------------------------------------------- DMS (wing = the dealer's territory wing)
      when 'dms_sales' then
        select coalesce(sum(i.total), 0) into v from sales.invoice i join sales.dealer d on d.id = i.dealer_id join sales.territory t on t.id = d.territory_id
         where i.company_id = p_company and i.invoice_date between d_from and d_to and (p_wing is null or t.wing_id = p_wing);
      when 'dms_invoices' then
        select count(*) into v from sales.invoice i join sales.dealer d on d.id = i.dealer_id join sales.territory t on t.id = d.territory_id
         where i.company_id = p_company and i.invoice_date between d_from and d_to and (p_wing is null or t.wing_id = p_wing);
      when 'dms_avg_invoice' then
        select round(avg(i.total), 2) into v from sales.invoice i join sales.dealer d on d.id = i.dealer_id join sales.territory t on t.id = d.territory_id
         where i.company_id = p_company and i.invoice_date between d_from and d_to and (p_wing is null or t.wing_id = p_wing);
      when 'dms_returns' then
        select coalesce(sum(r.credit_amount), 0) into v from sales.sales_return r
         where r.company_id = p_company and r.created_at::date between d_from and d_to;
      when 'dms_return_rate' then
        select coalesce(sum(r.credit_amount), 0) into va from sales.sales_return r where r.company_id = p_company and r.created_at::date between d_from and d_to;
        select sum(i.total) into vb from sales.invoice i where i.company_id = p_company and i.invoice_date between d_from and d_to;
        v := case when coalesce(vb, 0) > 0 then round(va * 100 / vb, 2) end;
      when 'dms_orders_new' then
        select count(*) into v from sales.sales_order o where o.company_id = p_company and o.created_at::date between d_from and d_to and o.status <> 'split';
      when 'dms_orders_open' then
        select count(*) into v from sales.sales_order o where o.company_id = p_company and o.status in ('pending_approval','approved','allocated');
      when 'dms_dispatches' then
        select count(*) into v from sales.dispatch x where x.company_id = p_company and x.dispatched_at::date between d_from and d_to;
      when 'dms_undelivered' then
        select count(*) into v from sales.dispatch x where x.company_id = p_company and x.delivered_at is null;
      when 'dms_collected' then
        select coalesce(sum(c.amount), 0) into v from sales.collection c
         where c.company_id = p_company and c.status = 'verified' and c.verified_at::date between d_from and d_to;
      when 'dms_collection_pending' then
        select coalesce(sum(c.amount), 0) into v from sales.collection c where c.company_id = p_company and c.status = 'recorded';
      when 'dms_collection_rate' then
        select coalesce(sum(c.amount), 0) into va from sales.collection c where c.company_id = p_company and c.status = 'verified' and c.verified_at::date between d_from and d_to;
        select sum(i.total) into vb from sales.invoice i where i.company_id = p_company and i.invoice_date between d_from and d_to;
        v := case when coalesce(vb, 0) > 0 then round(va * 100 / vb, 2) end;
      when 'dms_receivable' then
        select coalesce(sum(sales.fn_dealer_balance(d.id, d_to)), 0) into v from sales.dealer d join sales.territory t on t.id = d.territory_id
         where d.company_id = p_company and (p_wing is null or t.wing_id = p_wing);
      when 'dms_overdue' then
        select coalesce(sum(sales.fn_invoice_open(i.id)), 0) into v from sales.invoice i where i.company_id = p_company and i.due_date < current_date;
      -- ---------------------------------------------------------------- CRM
      when 'crm_dealers_active' then
        select count(*) into v from sales.dealer d join sales.territory t on t.id = d.territory_id
         where d.company_id = p_company and d.status = 'active' and (p_wing is null or t.wing_id = p_wing);
      when 'crm_dealers_new' then
        select count(*) into v from sales.dealer d where d.company_id = p_company and d.created_at::date between d_from and d_to;
      when 'crm_retailers' then
        select count(*) into v from sales.retailer r where r.company_id = p_company and r.status = 'active';
      when 'crm_visits_done' then
        select count(*) into v from sales.dealer_visit x where x.company_id = p_company and x.status = 'done' and x.planned_date between d_from and d_to;
      when 'crm_visit_rate' then
        select count(*) filter (where x.status = 'done'), count(*) filter (where x.status <> 'cancelled') into va, vb
          from sales.dealer_visit x where x.company_id = p_company and x.planned_date between d_from and d_to;
        v := case when vb > 0 then round(va * 100 / vb, 2) end;
      -- ---------------------------------------------------------------- courier
      when 'courier_freight' then
        select coalesce(sum(s.company_share), 0) into v from sales.shipment s where s.company_id = p_company and s.dispatched_at::date between d_from and d_to;
      when 'courier_in_transit' then
        select count(*) into v from sales.shipment s where s.company_id = p_company and s.status in ('DISPATCHED','IN_COURIER','RETURN_IN_TRANSIT');
      -- ---------------------------------------------------------------- stock
      when 'stock_value_total' then
        select coalesce(sum(b2.value), 0) into v from inventory.stock_balance b2 where b2.company_id = p_company;
      when 'stock_value_fg' then
        select coalesce(sum(b2.value), 0) into v from inventory.stock_balance b2 join inventory.warehouse w on w.id = b2.warehouse_id
         where b2.company_id = p_company and w.kind = 'finished_goods';
      when 'stock_value_raw' then
        select coalesce(sum(b2.value), 0) into v from inventory.stock_balance b2 join inventory.warehouse w on w.id = b2.warehouse_id
         where b2.company_id = p_company and w.kind = 'raw_material';
      when 'stock_low_items' then
        select count(*) into v from inventory.raw_profile r
         where r.company_id = p_company and r.min_stock > 0
           and coalesce((select sum(b2.qty) from inventory.stock_balance b2 where b2.company_id = p_company and b2.product_id = r.product_id), 0) < r.min_stock;
      when 'stock_expiring' then
        select count(distinct l.id) into v from inventory.lot l join inventory.lot_balance lb on lb.lot_id = l.id
         where l.company_id = p_company and lb.qty > 0 and l.expiry_date between current_date and current_date + 30;
      -- ---------------------------------------------------------------- factory
      when 'mfg_batches_done' then
        select count(*) into v from mfg.batch x where x.company_id = p_company and x.completed_at::date between d_from and d_to;
      when 'mfg_fg_output' then
        select coalesce(sum(x.fg_poly), 0) into v from mfg.batch x where x.company_id = p_company and x.completed_at::date between d_from and d_to;
      when 'mfg_waste' then
        select coalesce(sum(w.qty_poly), 0) into v from mfg.batch_waste w where w.company_id = p_company and w.status <> 'rejected' and w.created_at::date between d_from and d_to;
      when 'mfg_waste_rate' then
        select coalesce(sum(w.qty_poly), 0) into va from mfg.batch_waste w where w.company_id = p_company and w.status <> 'rejected' and w.created_at::date between d_from and d_to;
        select coalesce(sum(x.fg_poly), 0) into vb from mfg.batch x where x.company_id = p_company and x.completed_at::date between d_from and d_to;
        v := case when va + vb > 0 then round(va * 100 / (va + vb), 2) end;
      when 'mfg_unit_cost' then
        select round(avg(x.fg_unit_cost), 2) into v from mfg.batch x where x.company_id = p_company and x.completed_at::date between d_from and d_to and x.fg_unit_cost is not null;
      when 'mfg_factory_profit' then
        v := - report.fn_gl_net(p_company, array['41%'], d_from, d_to)                                     -- revenue less returns (credit)
             - report.fn_gl_net(p_company, array['5100%','53%','5910%','5820%'], d_from, d_to);              -- COGS, waste/variance, factory & machine cost
      -- ---------------------------------------------------------------- finance (posted GL)
      when 'fin_revenue' then v := - report.fn_gl_type_net(p_company, 'income', d_from, d_to);
      when 'fin_cogs' then v := report.fn_gl_net(p_company, array['5100%'], d_from, d_to);
      when 'fin_gross_margin' then
        va := - report.fn_gl_net(p_company, array['41%'], d_from, d_to); vb := report.fn_gl_net(p_company, array['5100%'], d_from, d_to);
        v := case when va > 0 then round((va - vb) * 100 / va, 2) end;
      when 'fin_expenses' then v := report.fn_gl_type_net(p_company, 'expense', d_from, d_to);
      when 'fin_net_profit' then v := - report.fn_gl_type_net(p_company, 'income', d_from, d_to) - report.fn_gl_type_net(p_company, 'expense', d_from, d_to);
      when 'fin_cash' then v := report.fn_gl_net(p_company, array['11%'], date '1900-01-01', d_to);
      when 'fin_payable' then v := - report.fn_gl_net(p_company, array['2100%'], date '1900-01-01', d_to);
      when 'proc_purchases' then
        select coalesce(sum(x.total), 0) into v from procurement.bill x where x.company_id = p_company and x.status = 'posted' and x.invoice_date between d_from and d_to;
      -- ---------------------------------------------------------------- HR
      when 'hr_payroll_net' then
        select coalesce(sum(r.net_total), 0) into v from hr.payroll_run r
         where r.company_id = p_company and r.status = 'posted' and r.period between date_trunc('month', d_from)::date and d_to;
      when 'hr_present' then
        select count(distinct e.employee_id) into v from hr.attendance_event e
         where e.company_id = p_company and e.status = 'posted' and e.event_at::date between d_from and d_to;
      else v := null;
    end case;
    return v;
  end if;
  if k.agg = 'last' then
    select sum(x.value) into v from report.kpi_value x
     where x.company_id = p_company and x.kpi_code = k.code and (p_wing is null or x.wing_id = p_wing)
       and x.period_date = (select max(y.period_date) from report.kpi_value y where y.company_id = p_company and y.kpi_code = k.code
                              and y.period_date between d_from and d_to and (p_wing is null or y.wing_id = p_wing));
  elsif k.agg = 'avg' then
    select avg(x.value) into v from report.kpi_value x
     where x.company_id = p_company and x.kpi_code = k.code and x.period_date between d_from and d_to and (p_wing is null or x.wing_id = p_wing);
  else
    select coalesce(sum(x.value), 0) into v from report.kpi_value x
     where x.company_id = p_company and x.kpi_code = k.code and x.period_date between d_from and d_to and (p_wing is null or x.wing_id = p_wing);
  end if;
  return round(v, 4);
end $$;

-- previous-period comparison for every non-snapshot KPI (S20 compared only stored + two live ones)
create or replace function report.fn_kpi_result(p_company uuid, p_person uuid, p_position text, p_supreme boolean, p_code text, p_period jsonb, p_wing uuid) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare k report.kpi_catalog; v_epoch integer; v_key text; c report.kpi_cache%rowtype; f date := (p_period ->> 'from')::date; t date := (p_period ->> 'to')::date;
        cur numeric; prev numeric; payload jsonb; v_style jsonb;
begin
  k := report.fn_kpi_row(p_company, p_code);
  if k.code is null then return jsonb_build_object('code', p_code, 'error', 'unknown'); end if;
  if not report.fn_kpi_allowed(p_company, k, p_position, p_supreme, p_wing) then
    return jsonb_build_object('code', p_code, 'name_bn', k.name_bn, 'restricted', true);
  end if;
  select coalesce(s.style, report.fn_style_default()) into v_style from (select 1) one
    left join report.kpi_style s on s.company_id = p_company and s.kpi_code = k.code and s.status = 'active';
  select p.authz_epoch into v_epoch from core.person p where p.id = p_person;
  v_key := md5(f::text || '|' || t::text || '|' || coalesce(p_wing::text, '-'));
  select * into c from report.kpi_cache x
   where x.company_id = p_company and x.kpi_code = k.code and x.cache_key = v_key and x.person_id = p_person;
  if found and c.authz_epoch = v_epoch and c.computed_at > clock_timestamp() - make_interval(secs => k.refresh_seconds) then
    return c.payload || jsonb_build_object('cached', true, 'style', v_style);
  end if;
  cur := report.fn_kpi_compute(p_company, k, f, t, p_wing);
  if k.source = 'stored' or not report.fn_kpi_is_snapshot(k.measure) then
    prev := report.fn_kpi_compute(p_company, k, f - (t - f + 1), f - 1, p_wing);
  end if;
  payload := jsonb_build_object('code', k.code, 'name_bn', k.name_bn, 'unit', k.unit, 'formula_bn', k.formula_bn, 'owner_position', k.owner_position,
                                'value', cur, 'previous', prev, 'from', f, 'to', t, 'wing_id', p_wing, 'computed_at', clock_timestamp(),
                                'refresh_seconds', k.refresh_seconds, 'has_products', k.has_products, 'restricted', false,
                                'value_bn', case when k.unit = 'money' then core.fn_taka_bn(cur) end);
  insert into report.kpi_cache (company_id, kpi_code, cache_key, person_id, authz_epoch, payload)
  values (p_company, k.code, v_key, p_person, v_epoch, payload)
  on conflict (company_id, kpi_code, cache_key, person_id) do update set authz_epoch = excluded.authz_epoch, payload = excluded.payload, computed_at = clock_timestamp();
  return payload || jsonb_build_object('cached', false, 'style', v_style);
end $$;

-- catalog now also returns the active style version (the Chairman's graph studio saves with optimistic versioning)
create or replace function api.v1_kpi_catalog() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', k.code, 'name_bn', k.name_bn, 'formula_bn', k.formula_bn, 'unit', k.unit, 'source', k.source,
           'owner_position', k.owner_position, 'has_products', k.has_products, 'refresh_seconds', k.refresh_seconds, 'custom', k.company_id is not null,
           'style', coalesce((select s.style from report.kpi_style s where s.company_id = me.company_id and s.kpi_code = k.code and s.status = 'active'), report.fn_style_default()),
           'style_version', coalesce((select s.version from report.kpi_style s where s.company_id = me.company_id and s.kpi_code = k.code and s.status = 'active'), 0))
           order by k.sort_order, k.code)
     from report.kpi_catalog k
    where (k.company_id = me.company_id or (k.company_id is null and not exists (select 1 from report.kpi_catalog o where o.company_id = me.company_id and o.code = k.code)))
      and report.fn_kpi_visible(me.company_id, k, me.position_code, me.is_supreme)), '[]'::jsonb);
end $$;

-- ================================================================ series (line / bar / sparkline)
create function api.v1_kpi_series(p_code text, p_grain text, p_from date, p_to date, p_wing uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; k report.kpi_catalog; t date := coalesce(p_to, current_date); f date; b date; e date; n integer := 0; pts jsonb := '[]'::jsonb; step interval;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_resource(iam.fn_context_company(), p_wing), false);
  k := report.fn_kpi_row(me.company_id, p_code);
  if k.code is null or not report.fn_kpi_allowed(me.company_id, k, me.position_code, me.is_supreme, p_wing) then perform core.fn_raise('E_FORBIDDEN', p_code); end if;
  if coalesce(p_grain, '') not in ('day','week','month') then perform core.fn_raise('E_INVALID_ACTION', 'grain day / week / month'); end if;
  step := case p_grain when 'day' then interval '1 day' when 'week' then interval '7 days' else interval '1 month' end;
  f := coalesce(p_from, case p_grain when 'day' then t - 13 when 'week' then t - 7 * 11 else (date_trunc('month', t) - interval '11 months')::date end);
  if p_grain = 'month' then f := date_trunc('month', f)::date; end if;
  if f > t then perform core.fn_raise('E_INVALID_ACTION', 'dates'); end if;
  b := f;
  while b <= t loop
    n := n + 1;
    if n > 36 then perform core.fn_raise('E_INVALID_ACTION', 'at most 36 points — choose a larger grain'); end if;
    e := least((b + step)::date - 1, t);
    pts := pts || jsonb_build_array(jsonb_build_object('from', b, 'to', e,
             'label', case p_grain when 'month' then to_char(b, 'YYYY-MM') else to_char(b, 'MM-DD') end,
             'value', report.fn_kpi_compute(me.company_id, k, b, e, p_wing)));
    b := (b + step)::date;
  end loop;
  return jsonb_build_object('code', k.code, 'name_bn', k.name_bn, 'unit', k.unit, 'grain', p_grain, 'snapshot', report.fn_kpi_is_snapshot(k.measure), 'points', pts);
end $$;

-- ================================================================ split (donut / bar by area, dealer, product, warehouse, account)
create function api.v1_kpi_split(p_code text, p_by text, p_from date, p_to date, p_limit integer default 12) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; k report.kpi_catalog; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
        n integer := least(greatest(coalesce(p_limit, 12), 3), 30); v_rows jsonb;
begin
  select * into me from iam.fn_require('kpi.dashboard.read', iam.fn_my_company_resource(), false);
  k := report.fn_kpi_row(me.company_id, p_code);
  if k.code is null or not report.fn_kpi_allowed(me.company_id, k, me.position_code, me.is_supreme, null) then perform core.fn_raise('E_FORBIDDEN', p_code); end if;
  if k.measure in ('dms_sales','dms_collected','dms_receivable') and p_by in ('territory','dealer') then
    select jsonb_agg(jsonb_build_object('key', g.gk, 'label', g.gl, 'value', g.gv) order by g.gv desc) into v_rows from (
      select case p_by when 'territory' then t2.id else d.id end gk,
             case p_by when 'territory' then t2.name_bn else d.code || ' · ' || d.name_bn end gl,
             sum(case k.measure
                   when 'dms_sales' then (select coalesce(sum(i.total), 0) from sales.invoice i where i.dealer_id = d.id and i.invoice_date between f and t)
                   when 'dms_collected' then (select coalesce(sum(c.amount), 0) from sales.collection c where c.dealer_id = d.id and c.status = 'verified' and c.verified_at::date between f and t)
                   else sales.fn_dealer_balance(d.id, t) end) gv
        from sales.dealer d join sales.territory t2 on t2.id = d.territory_id
       where d.company_id = me.company_id
       group by 1, 2 having sum(case k.measure
                   when 'dms_sales' then (select coalesce(sum(i.total), 0) from sales.invoice i where i.dealer_id = d.id and i.invoice_date between f and t)
                   when 'dms_collected' then (select coalesce(sum(c.amount), 0) from sales.collection c where c.dealer_id = d.id and c.status = 'verified' and c.verified_at::date between f and t)
                   else sales.fn_dealer_balance(d.id, t) end) <> 0
       order by 3 desc limit n) g;
  elsif k.measure = 'dms_sales' and p_by = 'product' then
    select jsonb_agg(jsonb_build_object('key', g.gk, 'label', g.gl, 'value', g.gv) order by g.gv desc) into v_rows from (
      select p.id gk, p.sku || ' · ' || p.name_bn gl, sum(round((ln ->> 'qty')::numeric * (ln ->> 'price')::numeric, 2)) gv
        from sales.invoice i cross join jsonb_array_elements(i.lines) ln join inventory.product p on p.id = (ln ->> 'product_id')::uuid
       where i.company_id = me.company_id and i.invoice_date between f and t
       group by p.id, p.sku, p.name_bn order by 3 desc limit n) g;
  elsif k.measure in ('stock_value_total','stock_value_fg','stock_value_raw') and p_by in ('warehouse','product') then
    select jsonb_agg(jsonb_build_object('key', g.gk, 'label', g.gl, 'value', g.gv) order by g.gv desc) into v_rows from (
      select case p_by when 'warehouse' then w.id else p.id end gk,
             case p_by when 'warehouse' then w.name_bn else p.sku || ' · ' || p.name_bn end gl, sum(b2.value) gv
        from inventory.stock_balance b2 join inventory.warehouse w on w.id = b2.warehouse_id join inventory.product p on p.id = b2.product_id
       where b2.company_id = me.company_id and b2.value <> 0
         and (k.measure = 'stock_value_total' or (k.measure = 'stock_value_fg' and w.kind = 'finished_goods') or (k.measure = 'stock_value_raw' and w.kind = 'raw_material'))
       group by 1, 2 order by 3 desc limit n) g;
  elsif k.measure = 'mfg_fg_output' and p_by = 'product' then
    select jsonb_agg(jsonb_build_object('key', g.gk, 'label', g.gl, 'value', g.gv) order by g.gv desc) into v_rows from (
      select p.id gk, p.sku || ' · ' || p.name_bn gl, sum(b.fg_poly) gv
        from mfg.batch b join inventory.product p on p.id = b.product_id
       where b.company_id = me.company_id and b.completed_at::date between f and t
       group by p.id, p.sku, p.name_bn order by 3 desc limit n) g;
  elsif k.measure = 'mfg_waste' and p_by = 'product' then
    select jsonb_agg(jsonb_build_object('key', g.gk, 'label', g.gl, 'value', g.gv) order by g.gv desc) into v_rows from (
      select p.id gk, p.sku || ' · ' || p.name_bn gl, sum(w.qty_poly) gv
        from mfg.batch_waste w join mfg.batch b on b.id = w.batch_id join inventory.product p on p.id = b.product_id
       where w.company_id = me.company_id and w.status <> 'rejected' and w.created_at::date between f and t
       group by p.id, p.sku, p.name_bn order by 3 desc limit n) g;
  elsif k.measure in ('fin_expenses','fin_revenue') and p_by = 'account' then
    select jsonb_agg(jsonb_build_object('key', g.gk, 'label', g.gl, 'value', g.gv) order by g.gv desc) into v_rows from (
      select a.code gk, a.code || ' · ' || a.name_bn gl,
             sum(case k.measure when 'fin_expenses' then l.debit - l.credit else l.credit - l.debit end) gv
        from finance.journal_line l join finance.journal j on j.id = l.journal_id join finance.account a on a.id = l.account_id
       where l.company_id = me.company_id and j.status in ('posted','reversed') and j.journal_date between f and t
         and a.type = case k.measure when 'fin_expenses' then 'expense' else 'income' end
       group by a.code, a.name_bn order by 3 desc limit n) g;
  else
    perform core.fn_raise('E_INVALID_ACTION', 'this KPI cannot be split by ' || coalesce(p_by, '?'));
  end if;
  return jsonb_build_object('code', k.code, 'name_bn', k.name_bn, 'unit', k.unit, 'by', p_by, 'from', f, 'to', t, 'rows', coalesce(v_rows, '[]'::jsonb));
end $$;

reset role;
do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_kpi_series(text, text, date, date, uuid)', 'api.v1_kpi_split(text, text, date, date, integer)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

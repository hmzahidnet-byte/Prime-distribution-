-- 20261108003700_prime_v180_courier.sql  (S56 — blueprint v180 + Prime Distribution Architect 1)
-- Sources: docs/blueprint/v180/06_V180_COURIER_CONDITION_EXTENSION (courier, condition, freight, settlement) and
-- docs/blueprint/v180/PRIME_DISTRIBUTION_ARCHITECT_1 (carton QR, factory "sent" vs warehouse "received", Chairman-only
-- final financial approval). Owner defaults applied where the blueprint leaves a choice: docs/PRIME_V180_DECISIONS_BN.md.
--   Courier: providers, dated destination rates (old shipments keep their snapshot), shipments per invoice (many per order),
--     per-line quantities (accepted / returning / received back / damaged / lost — never inferred), versioned condition slips
--     (original amount kept; every change proposed by one person and approved by the Chairman), collections held by the
--     courier (NOT company cash: dealer AR -> courier receivable), remittances (bank-verified, Chairman-approved, allocated,
--     never over-allocated), freight payer company / dealer / split, fee deducted or paid separately (never twice), shortfall
--     = dealer due + approved concession, returns enter stock only when the warehouse receives them, courier statement.
--   Carton QR (optional): unique signed carton labels tied to product / batch; one carton is never allocated twice.
--   FG handover: a completed batch is "sent"; stock becomes sellable only after the warehouse manager receives it.
--   Chairman-only: final approval of financial documents (setting approval.financial.chairman_only, default on).
-- Money stays NUMERIC taka with exactly 2 decimals (ADR-09) = integer poisha; see the decisions file.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ Chairman-only final financial approval
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('approval.financial.chairman_only', 'approval', 'bool', 'true', null, null, null, 'আর্থিক নথির চূড়ান্ত অনুমোদন শুধু চেয়ারম্যান', 'Prime 08: আর্থিক অনুরোধ → Chairman অনুমোদন', true, 2400),
  ('mfg.fg.requires_warehouse_receipt', 'mfg', 'bool', 'true', null, null, null, 'তৈরি-পণ্য গুদাম বুঝে নেওয়ার পর বিক্রয়যোগ্য', 'Prime 01/02', true, 2410);

create function core.fn_financial_approval_guard() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if new.status = 'approved' and old.status = 'pending'
     and new.document_type in ('procurement.payment','procurement.debit_note','procurement.bill_variance','sales.dealer_adjustment','sales.credit_exception','finance.journal')
     and config.fn_get_bool(new.company_id, 'approval.financial.chairman_only')
     and not coalesce((select c.is_supreme from iam.fn_context(false) c), false) then
    raise exception 'E_CHAIRMAN_ONLY: the final approval of a financial document belongs to the Chairman' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_financial_approval_guard before update on core.approval_request for each row execute function core.fn_financial_approval_guard();

-- Helper for the new money documents: the caller must be the company Chairman and must not be the maker.
create function core.fn_require_chairman(p_maker uuid) returns uuid
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare me record;
begin
  select * into me from iam.fn_context(true);
  if not coalesce(me.is_supreme, false) then raise exception 'E_CHAIRMAN_ONLY: only the Chairman approves money' using errcode = 'P0001'; end if;
  if p_maker is not null and p_maker = me.person_id then raise exception 'E_SELF_APPROVAL: another authorised person must prepare the Chairman''s own request' using errcode = 'P0001'; end if;
  return me.person_id;
end $$;

-- ================================================================ courier master
create table sales.courier_provider (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn     text not null check (length(btrim(name_bn)) > 0),
  phone       text,
  status      text not null default 'active' check (status in ('active','inactive')),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id), unique (company_id, code)
);
create trigger trg_courier_provider_guard before update on sales.courier_provider for each row execute function core.fn_scoped_guard();
create trigger trg_courier_provider_touch before update on sales.courier_provider for each row execute function core.fn_touch_row();
create trigger trg_courier_provider_nodel before delete on sales.courier_provider for each row execute function core.fn_deny_delete();
create trigger trg_courier_provider_audit after insert or update on sales.courier_provider for each row execute function audit.fn_row_change();

create table sales.courier_rate (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  provider_id  uuid not null,
  destination  text not null check (length(btrim(destination)) > 0),
  service      text not null default 'standard',
  basis        text not null default 'parcel' check (basis in ('parcel','poly','kg')),
  amount       numeric(14,2) not null check (amount >= 0),
  valid_from   date not null,
  set_by       uuid references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  unique (provider_id, destination, service, valid_from),
  foreign key (provider_id, company_id) references sales.courier_provider (id, company_id)
);
create trigger trg_courier_rate_no_mutation before update or delete on sales.courier_rate for each row execute function core.fn_deny_mutation();
create trigger trg_courier_rate_audit after insert on sales.courier_rate for each row execute function audit.fn_row_change();

-- ================================================================ shipments
create table sales.shipment (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  number          text not null,
  invoice_id      uuid not null,
  dealer_id       uuid not null,
  provider_id     uuid not null,
  destination     text not null,
  status          text not null default 'DISPATCHED'
                   check (status in ('DISPATCHED','IN_COURIER','PARTIAL_RELEASED','RELEASED','REFUSED','RETURN_IN_TRANSIT','PARTIAL_RETURN','CLOSED')),
  rate_snapshot   jsonb not null,                       -- the rate that applied on the dispatch day (never recalculated)
  freight_quoted  numeric(14,2) not null check (freight_quoted >= 0),
  freight_final   numeric(14,2) not null check (freight_final >= 0),
  freight_payer   text not null check (freight_payer in ('company','dealer','split')),
  company_share   numeric(14,2) not null check (company_share >= 0),
  dealer_share    numeric(14,2) not null check (dealer_share >= 0),
  deduction_mode  text not null check (deduction_mode in ('deducted','separate')),
  override_reason text,
  note            text,
  created_by      uuid not null references core.person(id),
  dispatched_at   timestamptz not null default clock_timestamp(),
  closed_at       timestamptz,
  unique (id, company_id), unique (company_id, number),
  check (company_share + dealer_share = freight_final),
  check (freight_final = freight_quoted or length(btrim(coalesce(override_reason, ''))) > 0),
  foreign key (invoice_id, company_id) references sales.invoice (id, company_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id),
  foreign key (provider_id, company_id) references sales.courier_provider (id, company_id)
);
create function sales.fn_shipment_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','closed_at','note']) <> (to_jsonb(new) - array['status','closed_at','note']) or old.status = 'CLOSED' then
    raise exception 'E_IMMUTABLE: a shipment keeps its invoice, freight and rate snapshot (corrections are new documents)' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_shipment_guard before update on sales.shipment for each row execute function sales.fn_shipment_guard();
create trigger trg_shipment_nodel before delete on sales.shipment for each row execute function core.fn_deny_delete();
create trigger trg_shipment_audit after insert or update on sales.shipment for each row execute function audit.fn_row_change();

create table sales.shipment_line (
  id                     uuid primary key default gen_random_uuid(),
  company_id             uuid not null,
  shipment_id            uuid not null,
  product_id             uuid not null,
  lot_id                 uuid not null,
  unit_cost              numeric(18,6) not null,
  unit_price             numeric(14,4) not null,
  dispatched_qty         numeric(18,4) not null check (dispatched_qty > 0),
  accepted_qty           numeric(18,4) not null default 0 check (accepted_qty >= 0),
  return_in_transit_qty  numeric(18,4) not null default 0 check (return_in_transit_qty >= 0),
  returned_received_qty  numeric(18,4) not null default 0 check (returned_received_qty >= 0),
  damaged_qty            numeric(18,4) not null default 0 check (damaged_qty >= 0),
  lost_qty               numeric(18,4) not null default 0 check (lost_qty >= 0),
  unique (shipment_id, lot_id),
  check (accepted_qty + return_in_transit_qty + returned_received_qty + damaged_qty + lost_qty <= dispatched_qty),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create trigger trg_shipment_line_nodel before delete on sales.shipment_line for each row execute function core.fn_deny_delete();
create trigger trg_shipment_line_audit after insert or update on sales.shipment_line for each row execute function audit.fn_row_change();

-- ================================================================ condition slips (v180 §4)
create table sales.condition_slip (
  id                 uuid primary key default gen_random_uuid(),
  company_id         uuid not null,
  shipment_id        uuid not null,
  slip_number        text,
  version            integer not null check (version >= 1),
  original_amount    numeric(14,2) not null check (original_amount >= 0),
  effective_amount   numeric(14,2) not null check (effective_amount >= 0),
  state              text not null default 'ACTIVE' check (state in ('ACTIVE','SUPERSEDED','CLOSED')),
  external_reference text,
  evidence_ref       text,
  created_at         timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (shipment_id, version),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create unique index condition_slip_one_active on sales.condition_slip (shipment_id) where state = 'ACTIVE';
create function sales.fn_slip_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['state','slip_number','external_reference','evidence_ref']) <> (to_jsonb(new) - array['state','slip_number','external_reference','evidence_ref'])
     or (old.slip_number is not null and new.slip_number is distinct from old.slip_number) or old.state <> 'ACTIVE' then
    raise exception 'E_IMMUTABLE: a slip version never changes; a new version is added' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_slip_guard before update on sales.condition_slip for each row execute function sales.fn_slip_guard();
create trigger trg_slip_nodel before delete on sales.condition_slip for each row execute function core.fn_deny_delete();
create trigger trg_slip_audit after insert or update on sales.condition_slip for each row execute function audit.fn_row_change();

create table sales.condition_change (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  shipment_id     uuid not null,
  old_amount      numeric(14,2) not null,
  proposed_amount numeric(14,2) not null check (proposed_amount >= 0),
  reason          text not null check (length(btrim(reason)) > 0),
  evidence_ref    text,
  maker_id        uuid not null references core.person(id),
  approver_id     uuid references core.person(id),
  approval_time   timestamptz,
  state           text not null default 'REQUESTED' check (state in ('REQUESTED','APPROVED','REJECTED')),
  created_at      timestamptz not null default clock_timestamp(),
  check (approver_id is null or approver_id <> maker_id),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create unique index condition_change_one_open on sales.condition_change (shipment_id) where state = 'REQUESTED';
create trigger trg_condition_change_nodel before delete on sales.condition_change for each row execute function core.fn_deny_delete();
create trigger trg_condition_change_audit after insert or update on sales.condition_change for each row execute function audit.fn_row_change();

-- ================================================================ money held by the courier
create table sales.courier_collection (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null,
  shipment_id      uuid not null,
  slip_id          uuid not null,
  collected_amount numeric(14,2) not null check (collected_amount > 0),
  collected_at     timestamptz not null,
  evidence_ref     text,
  event_key        text not null check (length(event_key) between 4 and 80),
  status           text not null default 'REPORTED' check (status in ('REPORTED','VERIFIED','REVERSED')),
  reported_by      uuid not null references core.person(id),
  verified_by      uuid references core.person(id),
  unique (id, company_id), unique (company_id, event_key),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id),
  foreign key (slip_id, company_id) references sales.condition_slip (id, company_id)
);
create trigger trg_courier_collection_nodel before delete on sales.courier_collection for each row execute function core.fn_deny_delete();
create trigger trg_courier_collection_audit after insert or update on sales.courier_collection for each row execute function audit.fn_row_change();

create table sales.courier_remittance (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null,
  provider_id      uuid not null,
  amount           numeric(14,2) not null check (amount > 0),
  method           text not null check (method in ('bank','cash')),
  reference        text,
  event_key        text not null check (length(event_key) between 4 and 80),
  status           text not null default 'REPORTED' check (status in ('REPORTED','BANK_VERIFIED','POSTED','REJECTED')),
  missing_evidence boolean not null default false,
  evidence_ref     text,
  reason           text,
  reported_by      uuid not null references core.person(id),
  verified_by      uuid references core.person(id),
  verified_at      timestamptz,
  approved_by      uuid references core.person(id),
  posted_at        timestamptz,
  unique (id, company_id), unique (company_id, event_key),
  check (not missing_evidence or length(btrim(coalesce(reason, ''))) > 0),
  foreign key (provider_id, company_id) references sales.courier_provider (id, company_id)
);
create function sales.fn_remittance_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.amount <> old.amount or new.provider_id <> old.provider_id or new.event_key <> old.event_key or new.method <> old.method
     or (old.status = 'POSTED' and (to_jsonb(old) - array['evidence_ref','missing_evidence']) <> (to_jsonb(new) - array['evidence_ref','missing_evidence'])) then
    raise exception 'E_IMMUTABLE: a remittance amount never changes; evidence may be attached later' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_remittance_guard before update on sales.courier_remittance for each row execute function sales.fn_remittance_guard();
create trigger trg_remittance_nodel before delete on sales.courier_remittance for each row execute function core.fn_deny_delete();
create trigger trg_remittance_audit after insert or update on sales.courier_remittance for each row execute function audit.fn_row_change();

create table sales.remittance_allocation (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  remittance_id  uuid not null,
  collection_id  uuid not null,
  amount         numeric(14,2) not null check (amount > 0),
  unique (remittance_id, collection_id),
  foreign key (remittance_id, company_id) references sales.courier_remittance (id, company_id),
  foreign key (collection_id, company_id) references sales.courier_collection (id, company_id)
);
create trigger trg_remittance_allocation_no_mutation before update or delete on sales.remittance_allocation for each row execute function core.fn_deny_mutation();

-- Approved money decisions on a shipment: dealer due / concession (shortfall), fee deducted / fee paid.
create table sales.courier_settlement (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  shipment_id  uuid not null,
  kind         text not null check (kind in ('dealer_due','concession','fee_deduction','fee_payment')),
  amount       numeric(14,2) not null check (amount > 0),
  reason       text not null check (length(btrim(reason)) > 0),
  pay_method   text check (pay_method is null or pay_method in ('bank','cash')),
  status       text not null default 'REQUESTED' check (status in ('REQUESTED','POSTED','REJECTED')),
  maker_id     uuid not null references core.person(id),
  approved_by  uuid references core.person(id),
  posted_at    timestamptz,
  created_at   timestamptz not null default clock_timestamp(),
  check (approved_by is null or approved_by <> maker_id),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create trigger trg_courier_settlement_nodel before delete on sales.courier_settlement for each row execute function core.fn_deny_delete();
create trigger trg_courier_settlement_audit after insert or update on sales.courier_settlement for each row execute function audit.fn_row_change();

-- ================================================================ cartons (Prime 01, 08) + FG handover (Prime 01, 02)
create table inventory.carton (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  code          text not null check (code ~ '^[A-Z0-9-]{6,40}$'),
  product_id    uuid not null,
  lot_id        uuid not null,
  batch_id      uuid,
  poly_qty      numeric(18,4) not null check (poly_qty > 0),
  status        text not null default 'packed' check (status in ('packed','in_warehouse','allocated','shipped','delivered','returned','damaged','lost')),
  warehouse_id  uuid,
  shipment_id   uuid,
  created_at    timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, code),
  foreign key (lot_id, company_id) references inventory.lot (id, company_id)
);
create table inventory.carton_event (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  carton_id   uuid not null references inventory.carton(id),
  action      text not null,
  from_status text, to_status text,
  ref         text,
  person_id   uuid,
  at          timestamptz not null default clock_timestamp()
);
create trigger trg_carton_event_no_mutation before update or delete on inventory.carton_event for each row execute function core.fn_deny_mutation();
create trigger trg_carton_nodel before delete on inventory.carton for each row execute function core.fn_deny_delete();

create table mfg.fg_handover (
  batch_id       uuid primary key,
  company_id     uuid not null,
  sent_poly      numeric(18,4) not null,
  sent_at        timestamptz not null default clock_timestamp(),
  received_poly  numeric(18,4),
  received_by    uuid references core.person(id),
  received_at    timestamptz,
  note           text,
  status         text not null default 'sent' check (status in ('sent','received','received_short')),
  foreign key (batch_id, company_id) references mfg.batch (id, company_id)
);
create trigger trg_fg_handover_nodel before delete on mfg.fg_handover for each row execute function core.fn_deny_delete();
create trigger trg_fg_handover_audit after insert or update on mfg.fg_handover for each row execute function audit.fn_row_change();

-- A completed batch is only "sent": its FG lot stays blocked until the warehouse manager receives it.
create function mfg.fn_batch_sent() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if new.status = 'completed' and old.status <> 'completed' and new.fg_lot_id is not null and config.fn_get_bool(new.company_id, 'mfg.fg.requires_warehouse_receipt') then
    update inventory.lot set status = 'blocked' where id = new.fg_lot_id;
    insert into mfg.fg_handover (batch_id, company_id, sent_poly) values (new.id, new.company_id, new.fg_poly) on conflict do nothing;
  end if;
  return null;
end $$;
create trigger trg_batch_sent after update on mfg.batch for each row execute function mfg.fn_batch_sent();

select core.fn_apply_rls('sales', 'courier_provider');
select core.fn_apply_rls('sales', 'courier_rate');
select core.fn_apply_rls('sales', 'shipment');
select core.fn_apply_rls('sales', 'shipment_line');
select core.fn_apply_rls('sales', 'condition_slip');
select core.fn_apply_rls('sales', 'condition_change');
select core.fn_apply_rls('sales', 'courier_collection');
select core.fn_apply_rls('sales', 'courier_remittance');
select core.fn_apply_rls('sales', 'remittance_allocation');
select core.fn_apply_rls('sales', 'courier_settlement');
select core.fn_apply_rls('inventory', 'carton');
select core.fn_apply_rls('inventory', 'carton_event');
select core.fn_apply_rls('mfg', 'fg_handover');

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('courier.read',   'courier', 'কুরিয়ার-খাতা ও চালান দেখা', 'read', true, false, array['COMPANY'], 'active', 2500),
  ('courier.manage', 'courier', 'কুরিয়ার ও ভাড়ার হার', 'admin', true, false, array['COMPANY'], 'active', 2501),
  ('courier.record', 'courier', 'চালান, স্লিপ, আদায় ও জমার তথ্য লেখা', 'write', true, false, array['COMPANY'], 'active', 2502),
  ('courier.verify', 'courier', 'কুরিয়ার-আদায় ও ব্যাংক-জমা যাচাই', 'approve', true, false, array['COMPANY'], 'active', 2503),
  ('inventory.carton.manage', 'inventory', 'কার্টন-QR তৈরি ও স্ক্যান', 'write', false, true, array['COMPANY','WAREHOUSE'], 'active', 2504);
update config.module_catalog set permission_modules = permission_modules || array['courier'] where code = 'sales' and not ('courier' = any (permission_modules));
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', 'COMPANY' from (values ('MD','courier.read'), ('FIN_MANAGER','courier.read'), ('ACCOUNTANT','courier.read'), ('SALES_MANAGER','courier.read'), ('AUDITOR','courier.read'),
  ('STOREKEEPER','courier.read'), ('SALES_MANAGER','courier.manage'), ('SALES_MANAGER','courier.record'), ('STOREKEEPER','courier.record'), ('ACCOUNTANT','courier.record'),
  ('ACCOUNTANT','courier.verify'), ('FIN_MANAGER','courier.verify'), ('STOREKEEPER','inventory.carton.manage'), ('PROD_SUPERVISOR','inventory.carton.manage')) v(x, y)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

insert into finance.coa_template (code, name_bn, type, parent, postable) values
  ('1350','কুরিয়ারের কাছে পাওনা','asset','1000',true), ('2300','কুরিয়ার-ভাড়া দেনা','liability','2000',true),
  ('5800','কুরিয়ার-ভাড়া','expense','5000',true), ('5610','ছাড় ও মওকুফ','expense','5000',true) on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values ('courier.receivable','1350','কুরিয়ারের কাছে পাওনা'), ('courier.freight_payable','2300','কুরিয়ার-ভাড়া দেনা'),
  ('courier.freight_expense','5800','কুরিয়ার-ভাড়া'), ('sales.concession','5610','ছাড় ও মওকুফ') on conflict do nothing;

-- ================================================================ engine
create function sales.fn_courier_rate(p_provider uuid, p_destination text, p_service text, p_day date) returns sales.courier_rate
language sql stable security definer set search_path = pg_catalog as $$
  select r from sales.courier_rate r where r.provider_id = p_provider and r.destination = p_destination and r.service = coalesce(p_service, 'standard') and r.valid_from <= p_day
   order by r.valid_from desc limit 1
$$;

-- What the dealer still has to settle on a shipment's condition: effective condition − verified collections − approved dispositions.
create function sales.fn_condition_shortfall(p_shipment uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((select s.effective_amount from sales.condition_slip s where s.shipment_id = p_shipment and s.state = 'ACTIVE'), 0)
       - coalesce((select sum(c.collected_amount) from sales.courier_collection c where c.shipment_id = p_shipment and c.status = 'VERIFIED'), 0)
       - coalesce((select sum(x.amount) from sales.courier_settlement x where x.shipment_id = p_shipment and x.status = 'POSTED' and x.kind in ('dealer_due','concession')), 0)
$$;

-- Money the courier holds for the company: verified collections − posted remittances − posted fee deductions.
create function sales.fn_courier_receivable(p_company uuid, p_provider uuid, p_as_of timestamptz default null) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((select sum(c.collected_amount) from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                    where s.company_id = p_company and s.provider_id = p_provider and c.status = 'VERIFIED' and (p_as_of is null or c.collected_at <= p_as_of)), 0)
       - coalesce((select sum(r.amount) from sales.courier_remittance r where r.company_id = p_company and r.provider_id = p_provider and r.status = 'POSTED'
                    and (p_as_of is null or r.posted_at <= p_as_of)), 0)
       - coalesce((select sum(x.amount) from sales.courier_settlement x join sales.shipment s on s.id = x.shipment_id
                    where s.company_id = p_company and s.provider_id = p_provider and x.status = 'POSTED' and x.kind = 'fee_deduction' and (p_as_of is null or x.posted_at <= p_as_of)), 0)
$$;

create function sales.fn_collection_outstanding(p_collection uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select c.collected_amount - coalesce((select sum(a.amount) from sales.remittance_allocation a where a.collection_id = c.id), 0)
    from sales.courier_collection c where c.id = p_collection and c.status = 'VERIFIED'
$$;

-- Sellable = available − quantity sitting in blocked lots (FG sent by the factory but not yet received by the warehouse).
create function inventory.fn_sellable(p_company uuid, p_warehouse uuid, p_product uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select inventory.fn_available(p_company, p_warehouse, p_product)
       - coalesce((select sum(lb.qty) from inventory.lot_balance lb join inventory.lot l on l.id = lb.lot_id
                    where lb.company_id = p_company and lb.warehouse_id = p_warehouse and l.product_id = p_product and l.status = 'blocked'), 0)
$$;

create or replace function sales.fn_allocate(p_order uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare o sales.sales_order%rowtype; l jsonb;
begin
  select * into o from sales.sales_order where id = p_order for update;
  if o.status <> 'approved' then return; end if;
  for l in select * from jsonb_array_elements(o.lines) loop
    perform pg_advisory_xact_lock(hashtext(o.warehouse_id::text || (l ->> 'product_id')));
    if (l ->> 'qty')::numeric > inventory.fn_sellable(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid) then
      raise exception 'E_INSUFFICIENT_STOCK: % not available (stock not yet received by the warehouse is not sellable)', l ->> 'product_id' using errcode = 'P0001';
    end if;
    insert into inventory.reservation (company_id, warehouse_id, product_id, batch_ref, qty, created_by, reason)
    values (o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, 'SO:' || o.number, (l ->> 'qty')::numeric, o.created_by, 'sales order ' || o.number);
  end loop;
  update sales.sales_order set status = 'allocated' where id = o.id;
end $$;

-- ================================================================ API: FG handover + cartons
create function api.v1_fg_receive(p_batch_id uuid, p_received_poly numeric, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; h mfg.fg_handover%rowtype; v_adj uuid;
begin
  select * into b from mfg.batch where id = p_batch_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'batch'); end if;
  select * into me from iam.fn_require('inventory.receipt.post', iam.fn_resource(b.company_id, null, null, null, b.fg_warehouse), true);
  select * into h from mfg.fg_handover where batch_id = b.id for update;
  if not found or h.status <> 'sent' then perform core.fn_raise('E_INVALID_ACTION', 'nothing waiting to be received'); end if;
  if p_received_poly is null or p_received_poly < 0 or p_received_poly > h.sent_poly then perform core.fn_raise('E_INVALID_ACTION', 'received quantity'); end if;
  if p_received_poly < h.sent_poly and length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'shortage note'); end if;
  perform set_config('mohona.change_reason', coalesce(p_note, 'FG received by warehouse'), true);
  update inventory.lot set status = 'available' where id = b.fg_lot_id;
  if p_received_poly < h.sent_poly then                     -- the difference is never silently dropped: a pending adjustment another person decides
    v_adj := gen_random_uuid();
    insert into inventory.adjustment (id, company_id, number, warehouse_id, source, lines, reason, created_by)
    values (v_adj, b.company_id, core.fn_next_number(b.company_id, 'inventory.adjustment', v_adj), b.fg_warehouse, 'manual',
            jsonb_build_array(jsonb_build_object('product_id', b.product_id, 'lot_id', b.fg_lot_id, 'delta', p_received_poly - h.sent_poly)), 'FG handover shortage: ' || p_note, me.person_id);
  end if;
  update mfg.fg_handover set received_poly = p_received_poly, received_by = me.person_id, received_at = clock_timestamp(), note = p_note,
         status = case when p_received_poly < h.sent_poly then 'received_short' else 'received' end where batch_id = b.id;
  return jsonb_build_object('batch_id', b.id, 'received', p_received_poly, 'sent', h.sent_poly, 'shortage_adjustment_id', v_adj);
end $$;

create function api.v1_carton_create(p_batch_id uuid, p_count integer, p_poly_per_carton numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; v_used numeric; v_seq integer; i integer; v_code text; out jsonb := '[]'::jsonb; v_cc text;
begin
  select * into me from iam.fn_require('inventory.carton.manage', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id and status = 'completed';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'completed batch'); end if;
  if coalesce(p_count, 0) not between 1 and 2000 or coalesce(p_poly_per_carton, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'count / POLY per carton'); end if;
  perform pg_advisory_xact_lock(hashtext('carton' || b.id::text));
  select coalesce(sum(c.poly_qty), 0), count(*) into v_used, v_seq from inventory.carton c where c.batch_id = b.id;
  if v_used + p_count * p_poly_per_carton > b.fg_poly then perform core.fn_raise('E_INVALID_ACTION', 'cartons would hold more POLY than the batch produced'); end if;
  select c.code into v_cc from core.company c where c.id = me.company_id;
  for i in 1 .. p_count loop
    v_code := upper(regexp_replace(b.number, '[^A-Za-z0-9-]', '-', 'g')) || '-C' || lpad((v_seq + i)::text, 4, '0');
    insert into inventory.carton (company_id, code, product_id, lot_id, batch_id, poly_qty) values (me.company_id, v_code, b.product_id, b.fg_lot_id, b.id, p_poly_per_carton);
    out := out || jsonb_build_array(jsonb_build_object('code', v_code, 'qr', sales.fn_signed(me.company_id, 'MOS1|K|' || v_cc || '|' || v_code)));
  end loop;
  return jsonb_build_object('batch_id', b.id, 'cartons', out);
end $$;

-- Scan = movement of ONE carton. It never posts stock or money (Prime 01). A carton can be allocated only once.
create function api.v1_carton_scan(p_payload text, p_action text, p_ref uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); c inventory.carton%rowtype; v_cc text; v_to text;
begin
  select * into me from iam.fn_require('inventory.carton.manage', iam.fn_my_company_resource(), true);
  select x.code into v_cc from core.company x where x.id = me.company_id;
  if cardinality(parts) <> 5 or parts[2] <> 'K' or parts[3] is distinct from v_cc or sales.fn_signed(me.company_id, array_to_string(parts[1:4], '|')) <> p_payload then
    perform core.fn_raise('E_QR_INVALID');
  end if;
  select * into c from inventory.carton where company_id = me.company_id and code = parts[4] for update;
  if not found then perform core.fn_raise('E_QR_INVALID'); end if;
  v_to := case when p_action = 'receive' and c.status in ('packed','returned') then 'in_warehouse'
               when p_action = 'allocate' and c.status = 'in_warehouse' then 'allocated'
               when p_action = 'ship' and c.status = 'allocated' then 'shipped'
               when p_action = 'deliver' and c.status = 'shipped' then 'delivered'
               when p_action = 'return' and c.status in ('shipped','delivered') then 'returned'
               when p_action = 'damage' and c.status not in ('lost','damaged') then 'damaged'
               when p_action = 'lost' and c.status not in ('lost','delivered') then 'lost' end;
  if v_to is null then perform core.fn_raise('E_CARTON_STATE', p_action || ' from ' || c.status); end if;
  update inventory.carton set status = v_to, warehouse_id = case when p_action = 'receive' then p_ref else warehouse_id end,
         shipment_id = case when p_action = 'allocate' then p_ref when p_action = 'receive' then null else shipment_id end where id = c.id;
  insert into inventory.carton_event (company_id, carton_id, action, from_status, to_status, ref, person_id) values (me.company_id, c.id, p_action, c.status, v_to, p_ref::text, me.person_id);
  return jsonb_build_object('code', c.code, 'status', v_to);
end $$;

create function api.v1_carton_lookup(p_payload text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); c inventory.carton%rowtype; v_cc text;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  select x.code into v_cc from core.company x where x.id = me.company_id;
  if cardinality(parts) <> 5 or parts[2] <> 'K' or parts[3] is distinct from v_cc or sales.fn_signed(me.company_id, array_to_string(parts[1:4], '|')) <> p_payload then
    perform core.fn_raise('E_QR_INVALID');
  end if;
  select * into c from inventory.carton where company_id = me.company_id and code = parts[4];
  if not found then perform core.fn_raise('E_QR_INVALID'); end if;
  return jsonb_build_object('code', c.code, 'status', c.status, 'poly_qty', c.poly_qty, 'sku', (select p.sku from inventory.product p where p.id = c.product_id),
    'batch', (select b.number from mfg.batch b where b.id = c.batch_id), 'lot_no', (select l.lot_no from inventory.lot l where l.id = c.lot_id),
    'warehouse_id', c.warehouse_id, 'shipment_id', c.shipment_id,
    'history', coalesce((select jsonb_agg(jsonb_build_object('action', e.action, 'to', e.to_status, 'at', e.at) order by e.id) from inventory.carton_event e where e.carton_id = c.id), '[]'::jsonb));
end $$;

-- ================================================================ API: courier master + shipments
create function api.v1_courier_provider_save(p_id uuid, p_code text, p_name_bn text, p_phone text, p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c sales.courier_provider%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('courier.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.courier_provider (company_id, code, name_bn, phone) values (me.company_id, upper(p_code), p_name_bn, p_phone) returning * into c;
  else
    update sales.courier_provider set name_bn = coalesce(p_name_bn, name_bn), phone = p_phone, status = coalesce(p_status, status)
     where id = p_id and company_id = me.company_id and row_version = p_expected_row_version returning * into c;
    if c.id is null then perform core.fn_raise('E_STALE_VERSION'); end if;
  end if;
  return jsonb_build_object('provider_id', c.id, 'row_version', c.row_version);
end $$;

create function api.v1_courier_rate_set(p_provider_id uuid, p_destination text, p_service text, p_basis text, p_amount numeric, p_valid_from date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('courier.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.courier_provider c where c.id = p_provider_id and c.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'courier'); end if;
  if p_valid_from is null or p_valid_from < current_date then perform core.fn_raise('E_INVALID_ACTION', 'a rate starts today or later (old shipments keep their rate)'); end if;
  perform set_config('mohona.change_reason', 'courier rate', true);
  insert into sales.courier_rate (company_id, provider_id, destination, service, basis, amount, valid_from, set_by)
  values (me.company_id, p_provider_id, btrim(p_destination), coalesce(p_service, 'standard'), coalesce(p_basis, 'parcel'), p_amount, p_valid_from, me.person_id) returning id into v_id;
  return jsonb_build_object('rate_id', v_id);
end $$;

-- The compact courier part of an invoice (v180 §2). lines: [{lot_id, qty}] from that invoice's dispatch; one invoice may go in several shipments.
create function api.v1_shipment_create(p_invoice_id uuid, p_provider_id uuid, p_destination text, p_service text, p_lines jsonb, p_freight_final numeric, p_override_reason text,
                                       p_freight_payer text, p_company_share numeric, p_deduction_mode text, p_condition_amount numeric, p_slip_number text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; i sales.invoice%rowtype; ds sales.dispatch%rowtype; r sales.courier_rate; v_id uuid := gen_random_uuid(); l jsonb; dl jsonb; v_done numeric; v_price numeric;
        v_quote numeric; v_final numeric; v_cs numeric; v_ds numeric; v_no text;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select * into i from sales.invoice where id = p_invoice_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'invoice'); end if;
  if not exists (select 1 from sales.courier_provider c where c.id = p_provider_id and c.company_id = me.company_id and c.status = 'active') then perform core.fn_raise('E_NOT_FOUND', 'active courier'); end if;
  select * into ds from sales.dispatch where order_id = i.order_id;
  r := sales.fn_courier_rate(p_provider_id, btrim(p_destination), p_service, current_date);
  v_quote := coalesce(r.amount, 0); v_final := coalesce(p_freight_final, v_quote);
  if v_final <> v_quote and length(btrim(coalesce(p_override_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'freight differs from the rate'); end if;
  if coalesce(p_freight_payer, '') not in ('company','dealer','split') or coalesce(p_deduction_mode, 'deducted') not in ('deducted','separate') or coalesce(p_condition_amount, -1) < 0 then
    perform core.fn_raise('E_INVALID_ACTION', 'payer / deduction mode / condition');
  end if;
  v_cs := case p_freight_payer when 'company' then v_final when 'dealer' then 0 else coalesce(p_company_share, -1) end; v_ds := v_final - v_cs;
  if v_cs < 0 or v_ds < 0 then perform core.fn_raise('E_INVALID_ACTION', 'freight shares must be non-negative and add up to the freight'); end if;
  if p_condition_amount > sales.fn_invoice_open(i.id) then perform core.fn_raise('E_OVERPAYMENT', 'condition above the open invoice amount'); end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  v_no := core.fn_next_number(me.company_id, 'sales.shipment', v_id);
  perform set_config('mohona.change_reason', 'courier shipment', true);
  perform pg_advisory_xact_lock(hashtext('shipment' || i.id::text));
  insert into sales.shipment (id, company_id, number, invoice_id, dealer_id, provider_id, destination, rate_snapshot, freight_quoted, freight_final, freight_payer, company_share,
                              dealer_share, deduction_mode, override_reason, note, created_by)
  values (v_id, me.company_id, v_no, i.id, i.dealer_id, p_provider_id, btrim(p_destination), coalesce(to_jsonb(r), '{}'::jsonb), v_quote, v_final, p_freight_payer, v_cs, v_ds,
          coalesce(p_deduction_mode, 'deducted'), p_override_reason, p_note, me.person_id);
  for l in select * from jsonb_array_elements(p_lines) loop
    select x into dl from jsonb_array_elements(ds.lines) x where x ->> 'lot_id' = l ->> 'lot_id' limit 1;
    if dl is null then perform core.fn_raise('E_INVALID_ACTION', 'lot was not dispatched on this invoice'); end if;
    v_done := coalesce((select sum(sl.dispatched_qty) from sales.shipment_line sl join sales.shipment s on s.id = sl.shipment_id where s.invoice_id = i.id and sl.lot_id = (l ->> 'lot_id')::uuid), 0);
    if coalesce((l ->> 'qty')::numeric, 0) <= 0 or v_done + (l ->> 'qty')::numeric > (dl ->> 'qty')::numeric then perform core.fn_raise('E_INVALID_ACTION', 'more than dispatched on the invoice'); end if;
    select (z ->> 'price')::numeric into v_price from jsonb_array_elements(i.lines) z where z ->> 'product_id' = dl ->> 'product_id' limit 1;
    insert into sales.shipment_line (company_id, shipment_id, product_id, lot_id, unit_cost, unit_price, dispatched_qty)
    values (me.company_id, v_id, (dl ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, (dl ->> 'unit_cost')::numeric, v_price, (l ->> 'qty')::numeric);
  end loop;
  insert into sales.condition_slip (company_id, shipment_id, slip_number, version, original_amount, effective_amount) values (me.company_id, v_id, p_slip_number, 1, p_condition_amount, p_condition_amount);
  if v_cs > 0 then                                           -- company-borne freight only; dealer-borne freight never becomes a company expense
    perform finance.fn_emit(me.company_id, 'freight:' || v_id, 'কুরিয়ার-ভাড়া ' || v_no, jsonb_build_array(
      jsonb_build_object('key', 'courier.freight_expense', 'dr', v_cs), jsonb_build_object('key', 'courier.freight_payable', 'cr', v_cs)));
  end if;
  return jsonb_build_object('shipment_id', v_id, 'number', v_no, 'freight_quoted', v_quote, 'freight_final', v_final, 'company_share', v_cs, 'dealer_share', v_ds);
end $$;

-- Courier-side facts for a line (never inferred from dispatch) and the shipment status.
create function api.v1_shipment_update(p_shipment_id uuid, p_status text, p_lot_id uuid, p_accepted numeric, p_return_in_transit numeric, p_damaged numeric, p_lost numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s sales.shipment%rowtype;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select * into s from sales.shipment where id = p_shipment_id and company_id = me.company_id for update;
  if not found or s.status = 'CLOSED' then perform core.fn_raise('E_NOT_FOUND', 'open shipment'); end if;
  perform set_config('mohona.change_reason', 'courier update', true);
  if p_lot_id is not null then
    update sales.shipment_line set accepted_qty = coalesce(p_accepted, accepted_qty), return_in_transit_qty = coalesce(p_return_in_transit, return_in_transit_qty),
           damaged_qty = coalesce(p_damaged, damaged_qty), lost_qty = coalesce(p_lost, lost_qty) where shipment_id = s.id and lot_id = p_lot_id;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'shipment line'); end if;
  end if;
  if p_status is not null then
    if p_status = 'CLOSED' or p_status not in ('IN_COURIER','PARTIAL_RELEASED','RELEASED','REFUSED','RETURN_IN_TRANSIT','PARTIAL_RETURN') then perform core.fn_raise('E_INVALID_ACTION', p_status); end if;
    update sales.shipment set status = p_status where id = s.id;
  end if;
  return jsonb_build_object('shipment_id', s.id, 'status', coalesce(p_status, s.status));
end $$;

create function api.v1_slip_set(p_shipment_id uuid, p_slip_number text, p_external_reference text, p_evidence_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'slip details', true);
  update sales.condition_slip set slip_number = coalesce(slip_number, p_slip_number), external_reference = coalesce(p_external_reference, external_reference),
         evidence_ref = coalesce(p_evidence_ref, evidence_ref) where shipment_id = p_shipment_id and company_id = me.company_id and state = 'ACTIVE';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'active slip'); end if;
  return jsonb_build_object('shipment_id', p_shipment_id);
end $$;

-- Condition change (v180 §4): proposal by one person, effective only after the Chairman approves; the original amount stays.
create function api.v1_condition_change_request(p_shipment_id uuid, p_proposed_amount numeric, p_reason text, p_evidence_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s sales.condition_slip%rowtype; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select * into s from sales.condition_slip where shipment_id = p_shipment_id and company_id = me.company_id and state = 'ACTIVE';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'active slip'); end if;
  if coalesce(p_proposed_amount, -1) < 0 or p_proposed_amount = s.effective_amount then perform core.fn_raise('E_INVALID_ACTION', 'a different, non-negative amount'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.condition_change (company_id, shipment_id, old_amount, proposed_amount, reason, evidence_ref, maker_id)
  values (me.company_id, p_shipment_id, s.effective_amount, p_proposed_amount, p_reason, p_evidence_ref, me.person_id) returning id into v_id;
  return jsonb_build_object('change_id', v_id, 'state', 'REQUESTED');
end $$;

create function api.v1_condition_change_decide(p_change_id uuid, p_approve boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; c sales.condition_change%rowtype; s sales.condition_slip%rowtype;
begin
  select * into c from sales.condition_change where id = p_change_id and company_id = iam.fn_context_company() for update;
  if not found or c.state <> 'REQUESTED' then perform core.fn_raise('E_NOT_FOUND', 'requested change'); end if;
  v_ch := core.fn_require_chairman(c.maker_id);
  perform set_config('mohona.change_reason', c.reason, true);
  if p_approve then
    select * into s from sales.condition_slip where shipment_id = c.shipment_id and state = 'ACTIVE' for update;
    update sales.condition_slip set state = 'SUPERSEDED' where id = s.id;
    insert into sales.condition_slip (company_id, shipment_id, slip_number, version, original_amount, effective_amount, external_reference)
    values (s.company_id, s.shipment_id, null, s.version + 1, s.original_amount, c.proposed_amount, s.external_reference);
  end if;
  update sales.condition_change set state = case when p_approve then 'APPROVED' else 'REJECTED' end, approver_id = v_ch, approval_time = clock_timestamp() where id = c.id;
  return jsonb_build_object('change_id', c.id, 'state', case when p_approve then 'APPROVED' else 'REJECTED' end);
end $$;

-- ================================================================ API: collections held by the courier (v180 §6)
create function api.v1_courier_collection_report(p_shipment_id uuid, p_amount numeric, p_collected_at timestamptz, p_evidence_ref text, p_event_key text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s sales.condition_slip%rowtype; v_id uuid; v_sum numeric;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select c.id into v_id from sales.courier_collection c where c.company_id = me.company_id and c.event_key = p_event_key;
  if v_id is not null then return jsonb_build_object('collection_id', v_id, 'duplicate', true); end if;          -- the same event never posts twice
  select * into s from sales.condition_slip where shipment_id = p_shipment_id and company_id = me.company_id and state = 'ACTIVE';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'active slip'); end if;
  select coalesce(sum(c.collected_amount), 0) into v_sum from sales.courier_collection c where c.shipment_id = p_shipment_id and c.status <> 'REVERSED';
  if coalesce(p_amount, 0) <= 0 or v_sum + p_amount > s.effective_amount then perform core.fn_raise('E_OVERPAYMENT', 'above the approved condition'); end if;
  perform set_config('mohona.change_reason', 'courier collection reported', true);
  insert into sales.courier_collection (company_id, shipment_id, slip_id, collected_amount, collected_at, evidence_ref, event_key, reported_by)
  values (me.company_id, p_shipment_id, s.id, p_amount, coalesce(p_collected_at, clock_timestamp()), p_evidence_ref, p_event_key, me.person_id) returning id into v_id;
  return jsonb_build_object('collection_id', v_id, 'status', 'REPORTED');
end $$;

-- Verified by another person: the dealer's due goes down and the COURIER owes the company — company cash does not move.
create function api.v1_courier_collection_verify(p_collection_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c sales.courier_collection%rowtype; sh sales.shipment%rowtype;
begin
  select * into me from iam.fn_require('courier.verify', iam.fn_my_company_resource(), true);
  select * into c from sales.courier_collection where id = p_collection_id and company_id = me.company_id for update;
  if not found or c.status <> 'REPORTED' then perform core.fn_raise('E_NOT_FOUND', 'reported collection'); end if;
  if c.reported_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  select * into sh from sales.shipment where id = c.shipment_id;
  perform set_config('mohona.change_reason', 'courier collection verified', true);
  update sales.courier_collection set status = 'VERIFIED', verified_by = me.person_id where id = c.id;
  perform sales.fn_post_ledger(c.company_id, sh.dealer_id, 'collection', -c.collected_amount, c.collected_at::date, null, 'sales.courier_collection', c.id, 'কুরিয়ার কন্ডিশন ' || sh.number);
  perform finance.fn_emit(c.company_id, 'courier_coll:' || c.id, 'কুরিয়ারের হাতে আদায় ' || sh.number, jsonb_build_array(
    jsonb_build_object('key', 'courier.receivable', 'dr', c.collected_amount), jsonb_build_object('key', 'sales.ar', 'cr', c.collected_amount)));
  return jsonb_build_object('collection_id', c.id, 'status', 'VERIFIED', 'courier_receivable', sales.fn_courier_receivable(c.company_id, sh.provider_id));
end $$;

-- ================================================================ API: remittances (REPORTED -> BANK_VERIFIED -> Chairman POSTED + allocation)
create function api.v1_courier_remittance_report(p_provider_id uuid, p_amount numeric, p_method text, p_reference text, p_evidence_ref text, p_event_key text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select r.id into v_id from sales.courier_remittance r where r.company_id = me.company_id and r.event_key = p_event_key;
  if v_id is not null then return jsonb_build_object('remittance_id', v_id, 'duplicate', true); end if;
  if not exists (select 1 from sales.courier_provider c where c.id = p_provider_id and c.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'courier'); end if;
  perform set_config('mohona.change_reason', 'courier remittance reported', true);
  insert into sales.courier_remittance (company_id, provider_id, amount, method, reference, evidence_ref, event_key, reported_by)
  values (me.company_id, p_provider_id, p_amount, p_method, p_reference, p_evidence_ref, p_event_key, me.person_id) returning id into v_id;
  return jsonb_build_object('remittance_id', v_id, 'status', 'REPORTED');
end $$;

create function api.v1_courier_remittance_verify(p_remittance_id uuid, p_bank_line_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.courier_remittance%rowtype; bl record;
begin
  select * into me from iam.fn_require('courier.verify', iam.fn_my_company_resource(), true);
  select * into r from sales.courier_remittance where id = p_remittance_id and company_id = me.company_id for update;
  if not found or r.status <> 'REPORTED' then perform core.fn_raise('E_NOT_FOUND', 'reported remittance'); end if;
  if r.reported_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  if r.method = 'bank' then
    select * into bl from finance.bank_statement_line x where x.id = p_bank_line_id and x.company_id = me.company_id;
    if bl.id is null or bl.amount <> r.amount then perform core.fn_raise('E_UNVERIFIED_PAYMENT', 'a bank statement line with the same amount is required'); end if;
  end if;
  perform set_config('mohona.change_reason', 'remittance verified', true);
  update sales.courier_remittance set status = 'BANK_VERIFIED', verified_by = me.person_id, verified_at = clock_timestamp() where id = r.id;
  return jsonb_build_object('remittance_id', r.id, 'status', 'BANK_VERIFIED');
end $$;

-- Chairman posting. allocations: [{collection_id, amount}] — never above the remittance or a collection's outstanding amount;
-- what is not allocated stays visible as unallocated. Without bank proof the Chairman must write the reason (flag stays).
create function api.v1_courier_remittance_approve(p_remittance_id uuid, p_allocations jsonb, p_missing_evidence_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; r sales.courier_remittance%rowtype; a jsonb; v_sum numeric := 0; v_missing boolean := false;
begin
  select * into r from sales.courier_remittance where id = p_remittance_id and company_id = iam.fn_context_company() for update;
  if not found or r.status not in ('REPORTED','BANK_VERIFIED') then perform core.fn_raise('E_NOT_FOUND', 'remittance waiting for approval'); end if;
  v_ch := core.fn_require_chairman(r.reported_by);
  if r.status = 'REPORTED' then
    if length(btrim(coalesce(p_missing_evidence_reason, ''))) = 0 then perform core.fn_raise('E_UNVERIFIED_PAYMENT', 'not bank-verified: write the reason to approve without proof'); end if;
    v_missing := true;
  end if;
  for a in select * from jsonb_array_elements(coalesce(p_allocations, '[]'::jsonb)) loop
    perform 1 from sales.courier_collection c where c.id = (a ->> 'collection_id')::uuid for update;
    if not exists (select 1 from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                    where c.id = (a ->> 'collection_id')::uuid and c.company_id = r.company_id and s.provider_id = r.provider_id and c.status = 'VERIFIED')
       or coalesce((a ->> 'amount')::numeric, 0) <= 0 or (a ->> 'amount')::numeric > sales.fn_collection_outstanding((a ->> 'collection_id')::uuid) then
      perform core.fn_raise('E_OVERPAYMENT', 'allocation above the collection''s outstanding amount');
    end if;
    v_sum := v_sum + (a ->> 'amount')::numeric;
    insert into sales.remittance_allocation (company_id, remittance_id, collection_id, amount) values (r.company_id, r.id, (a ->> 'collection_id')::uuid, (a ->> 'amount')::numeric);
  end loop;
  if v_sum > r.amount then perform core.fn_raise('E_OVERPAYMENT', 'allocations above the remittance'); end if;
  perform set_config('mohona.change_reason', coalesce(p_missing_evidence_reason, 'remittance approved'), true);
  update sales.courier_remittance set status = 'POSTED', approved_by = v_ch, posted_at = clock_timestamp(), missing_evidence = v_missing,
         reason = coalesce(p_missing_evidence_reason, reason) where id = r.id;
  perform finance.fn_emit(r.company_id, 'courier_remit:' || r.id, 'কুরিয়ার জমা', jsonb_build_array(
    jsonb_build_object('key', case when r.method = 'cash' then 'fin.cash' else 'fin.bank' end, 'dr', r.amount), jsonb_build_object('key', 'courier.receivable', 'cr', r.amount)));
  return jsonb_build_object('remittance_id', r.id, 'status', 'POSTED', 'allocated', v_sum, 'unallocated', r.amount - v_sum, 'missing_evidence', v_missing,
                            'courier_receivable', sales.fn_courier_receivable(r.company_id, r.provider_id));
end $$;

create function api.v1_courier_remittance_attach(p_remittance_id uuid, p_evidence_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'evidence attached later', true);
  update sales.courier_remittance set evidence_ref = p_evidence_ref where id = p_remittance_id and company_id = me.company_id;      -- amount and the flag stay
  if not found then perform core.fn_raise('E_NOT_FOUND', 'remittance'); end if;
  return jsonb_build_object('remittance_id', p_remittance_id, 'evidence_ref', p_evidence_ref);
end $$;

-- ================================================================ API: settlements (shortfall disposition, freight fee) — Chairman only
create function api.v1_courier_settlement_request(p_shipment_id uuid, p_kind text, p_amount numeric, p_reason text, p_pay_method text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  if not exists (select 1 from sales.shipment s where s.id = p_shipment_id and s.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'shipment'); end if;
  if coalesce(p_kind, '') not in ('dealer_due','concession','fee_deduction','fee_payment') or coalesce(p_amount, 0) <= 0
     or (p_kind = 'fee_payment' and coalesce(p_pay_method, '') not in ('bank','cash')) then perform core.fn_raise('E_INVALID_ACTION', 'kind / amount / payment method'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.courier_settlement (company_id, shipment_id, kind, amount, reason, pay_method, maker_id)
  values (me.company_id, p_shipment_id, p_kind, p_amount, p_reason, case when p_kind = 'fee_payment' then p_pay_method end, me.person_id) returning id into v_id;
  return jsonb_build_object('settlement_id', v_id, 'status', 'REQUESTED');
end $$;

create function api.v1_courier_settlement_decide(p_settlement_id uuid, p_approve boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; x sales.courier_settlement%rowtype; sh sales.shipment%rowtype; v_fee_done numeric;
begin
  select * into x from sales.courier_settlement where id = p_settlement_id and company_id = iam.fn_context_company() for update;
  if not found or x.status <> 'REQUESTED' then perform core.fn_raise('E_NOT_FOUND', 'requested settlement'); end if;
  v_ch := core.fn_require_chairman(x.maker_id);
  select * into sh from sales.shipment where id = x.shipment_id for update;
  perform set_config('mohona.change_reason', x.reason, true);
  if not p_approve then
    update sales.courier_settlement set status = 'REJECTED', approved_by = v_ch where id = x.id;
    return jsonb_build_object('settlement_id', x.id, 'status', 'REJECTED');
  end if;
  if x.kind in ('fee_deduction','fee_payment') then
    if (x.kind = 'fee_deduction') <> (sh.deduction_mode = 'deducted') then perform core.fn_raise('E_INVALID_ACTION', 'this shipment''s fee is ' || sh.deduction_mode); end if;
    select coalesce(sum(y.amount), 0) into v_fee_done from sales.courier_settlement y where y.shipment_id = sh.id and y.status = 'POSTED' and y.kind in ('fee_deduction','fee_payment');
    if v_fee_done + x.amount > sh.company_share then perform core.fn_raise('E_OVERPAYMENT', 'the company''s freight share is already settled (never twice)'); end if;
    if x.kind = 'fee_deduction' and x.amount > sales.fn_courier_receivable(sh.company_id, sh.provider_id) then perform core.fn_raise('E_OVERPAYMENT', 'nothing collected to deduct from'); end if;
    perform finance.fn_emit(sh.company_id, 'courier_fee:' || x.id, 'কুরিয়ার-ভাড়া নিষ্পত্তি ' || sh.number, jsonb_build_array(
      jsonb_build_object('key', 'courier.freight_payable', 'dr', x.amount),
      jsonb_build_object('key', case when x.kind = 'fee_deduction' then 'courier.receivable' when x.pay_method = 'cash' then 'fin.cash' else 'fin.bank' end, 'cr', x.amount)));
  else
    if x.amount > sales.fn_condition_shortfall(sh.id) then perform core.fn_raise('E_OVERPAYMENT', 'above the unclassified shortfall'); end if;
    if x.kind = 'concession' then                             -- waiver / discount: the dealer owes less; dealer_due leaves the receivable as it is
      perform sales.fn_post_ledger(sh.company_id, sh.dealer_id, 'credit_note', -x.amount, current_date, null, 'sales.courier_concession', x.id, x.reason);
      perform finance.fn_emit(sh.company_id, 'courier_concession:' || x.id, 'ছাড়/মওকুফ ' || sh.number, jsonb_build_array(
        jsonb_build_object('key', 'sales.concession', 'dr', x.amount), jsonb_build_object('key', 'sales.ar', 'cr', x.amount)));
    end if;
  end if;
  update sales.courier_settlement set status = 'POSTED', approved_by = v_ch, posted_at = clock_timestamp() where id = x.id;
  return jsonb_build_object('settlement_id', x.id, 'status', 'POSTED', 'shortfall_left', sales.fn_condition_shortfall(sh.id),
                            'courier_receivable', sales.fn_courier_receivable(sh.company_id, sh.provider_id));
end $$;

-- Close: no unclassified shortfall, nothing still on its way back (v180 scenario 8).
create function api.v1_shipment_close(p_shipment_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s sales.shipment%rowtype;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select * into s from sales.shipment where id = p_shipment_id and company_id = me.company_id for update;
  if not found or s.status = 'CLOSED' then perform core.fn_raise('E_NOT_FOUND', 'open shipment'); end if;
  if sales.fn_condition_shortfall(s.id) <> 0 then perform core.fn_raise('E_SHORTFALL_UNCLASSIFIED', sales.fn_condition_shortfall(s.id)::text); end if;
  if exists (select 1 from sales.shipment_line l where l.shipment_id = s.id and l.return_in_transit_qty > 0) then perform core.fn_raise('E_INVALID_ACTION', 'returns are still on their way'); end if;
  if exists (select 1 from sales.condition_change c where c.shipment_id = s.id and c.state = 'REQUESTED')
     or exists (select 1 from sales.courier_settlement x where x.shipment_id = s.id and x.status = 'REQUESTED') then perform core.fn_raise('E_INVALID_ACTION', 'requests are waiting for the Chairman'); end if;
  perform set_config('mohona.change_reason', 'shipment closed', true);
  update sales.condition_slip set state = 'CLOSED' where shipment_id = s.id and state = 'ACTIVE';
  update sales.shipment set status = 'CLOSED', closed_at = clock_timestamp() where id = s.id;
  return jsonb_build_object('shipment_id', s.id, 'status', 'CLOSED');
end $$;

-- Return received by the warehouse (v180 §5): only now does stock rise — into a quarantine warehouse, at the original cost;
-- the dealer gets a credit note for exactly the received quantity.
create function api.v1_courier_return_receive(p_shipment_id uuid, p_lot_id uuid, p_qty numeric, p_warehouse_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s sales.shipment%rowtype; l sales.shipment_line%rowtype; v_id uuid := gen_random_uuid(); v_credit numeric; v_cost numeric;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.receipt.post', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  select * into s from sales.shipment where id = p_shipment_id and company_id = me.company_id for update;
  if not found or s.status = 'CLOSED' then perform core.fn_raise('E_NOT_FOUND', 'open shipment'); end if;
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse_id and w.company_id = me.company_id and w.kind = 'quarantine') then
    perform core.fn_raise('E_INVALID_ACTION', 'returns are received into a quarantine warehouse (QC before restock)');
  end if;
  select * into l from sales.shipment_line where shipment_id = s.id and lot_id = p_lot_id for update;
  if not found or coalesce(p_qty, 0) <= 0 or p_qty > l.return_in_transit_qty then perform core.fn_raise('E_INVALID_ACTION', 'more than the courier reported as returning'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform inventory.fn_post_move(me.company_id, p_warehouse_id, l.product_id, l.lot_id, 'sales_return', p_qty, l.unit_cost, 'sales.return', v_id, 1, p_reason);
  update sales.shipment_line set return_in_transit_qty = return_in_transit_qty - p_qty, returned_received_qty = returned_received_qty + p_qty where id = l.id;
  v_credit := round(p_qty * l.unit_price, 2); v_cost := round(p_qty * l.unit_cost, 4);
  insert into sales.sales_return (id, company_id, number, invoice_id, warehouse_id, lines, credit_amount, cost_amount, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'sales.return', v_id), s.invoice_id, p_warehouse_id,
          jsonb_build_array(jsonb_build_object('product_id', l.product_id, 'lot_id', l.lot_id, 'qty', p_qty, 'unit_cost', l.unit_cost, 'price', l.unit_price, 'shipment_id', s.id)),
          v_credit, v_cost, p_reason, me.person_id);
  perform sales.fn_post_ledger(me.company_id, s.dealer_id, 'return', -v_credit, current_date, null, 'sales.return', v_id, 'courier return ' || s.number);
  perform finance.fn_emit(me.company_id, 'sales_return:' || v_id, 'কুরিয়ার-ফেরত ' || s.number, jsonb_build_array(
    jsonb_build_object('key', 'sales.returns', 'dr', v_credit), jsonb_build_object('key', 'sales.ar', 'cr', v_credit),
    jsonb_build_object('key', 'inv.fg', 'dr', v_cost), jsonb_build_object('key', 'sales.cogs', 'cr', v_cost)));
  return jsonb_build_object('return_id', v_id, 'credit', v_credit, 'received', p_qty);
end $$;

-- ================================================================ API: reading
create function api.v1_shipments(p_status text default null, p_provider_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('courier.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'number', s.number, 'courier', c.name_bn, 'dealer', d.name_bn, 'destination', s.destination, 'status', s.status,
           'freight', s.freight_final, 'payer', s.freight_payer, 'condition', (select x.effective_amount from sales.condition_slip x where x.shipment_id = s.id and x.state in ('ACTIVE','CLOSED') order by x.version desc limit 1),
           'collected', coalesce((select sum(k.collected_amount) from sales.courier_collection k where k.shipment_id = s.id and k.status = 'VERIFIED'), 0),
           'shortfall', sales.fn_condition_shortfall(s.id), 'dispatched_at', s.dispatched_at) order by s.dispatched_at desc)
     from sales.shipment s join sales.courier_provider c on c.id = s.provider_id join sales.dealer d on d.id = s.dealer_id
    where s.company_id = me.company_id and (p_status is null or s.status = p_status) and (p_provider_id is null or s.provider_id = p_provider_id)), '[]'::jsonb);
end $$;

create function api.v1_shipment_get(p_shipment_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; s sales.shipment%rowtype;
begin
  select * into me from iam.fn_require('courier.read', iam.fn_my_company_resource(), false);
  select * into s from sales.shipment where id = p_shipment_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'shipment'); end if;
  return to_jsonb(s) - 'company_id' || jsonb_build_object(
    'lines', (select jsonb_agg(to_jsonb(l) - 'company_id' - 'unit_cost') from sales.shipment_line l where l.shipment_id = s.id),
    'slips', (select jsonb_agg(jsonb_build_object('version', x.version, 'slip_number', x.slip_number, 'original', x.original_amount, 'effective', x.effective_amount, 'state', x.state) order by x.version)
                from sales.condition_slip x where x.shipment_id = s.id),
    'changes', (select jsonb_agg(jsonb_build_object('id', c.id, 'old', c.old_amount, 'proposed', c.proposed_amount, 'reason', c.reason, 'state', c.state) order by c.created_at)
                  from sales.condition_change c where c.shipment_id = s.id),
    'collections', (select jsonb_agg(jsonb_build_object('id', k.id, 'amount', k.collected_amount, 'status', k.status, 'outstanding', sales.fn_collection_outstanding(k.id)) order by k.collected_at)
                      from sales.courier_collection k where k.shipment_id = s.id),
    'settlements', (select jsonb_agg(jsonb_build_object('id', y.id, 'kind', y.kind, 'amount', y.amount, 'status', y.status, 'reason', y.reason) order by y.created_at)
                      from sales.courier_settlement y where y.shipment_id = s.id),
    'shortfall', sales.fn_condition_shortfall(s.id));
end $$;

-- Bank-style statement per courier (v180 §8): opening + verified collections − fee deductions − remittances = closing.
create function api.v1_courier_statement(p_provider_id uuid, p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('courier.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object('provider_id', p_provider_id, 'from', f, 'to', t,
    'opening', sales.fn_courier_receivable(me.company_id, p_provider_id, f::timestamptz),
    'collections', coalesce((select sum(c.collected_amount) from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                              where s.company_id = me.company_id and s.provider_id = p_provider_id and c.status = 'VERIFIED' and c.collected_at >= f and c.collected_at < t + 1), 0),
    'fee_deductions', coalesce((select sum(x.amount) from sales.courier_settlement x join sales.shipment s on s.id = x.shipment_id
                              where s.company_id = me.company_id and s.provider_id = p_provider_id and x.status = 'POSTED' and x.kind = 'fee_deduction' and x.posted_at >= f and x.posted_at < t + 1), 0),
    'remittances', coalesce((select sum(r.amount) from sales.courier_remittance r where r.company_id = me.company_id and r.provider_id = p_provider_id and r.status = 'POSTED'
                              and r.posted_at >= f and r.posted_at < t + 1), 0),
    'closing', sales.fn_courier_receivable(me.company_id, p_provider_id, (t + 1)::timestamptz),
    'unallocated_remittance', coalesce((select sum(r.amount - coalesce((select sum(a.amount) from sales.remittance_allocation a where a.remittance_id = r.id), 0))
                              from sales.courier_remittance r where r.company_id = me.company_id and r.provider_id = p_provider_id and r.status = 'POSTED'), 0),
    'reported_not_remitted', coalesce((select sum(sales.fn_collection_outstanding(c.id)) from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                              where s.company_id = me.company_id and s.provider_id = p_provider_id and c.status = 'VERIFIED'), 0),
    'open_cases', coalesce((select jsonb_agg(jsonb_build_object('shipment', s.number, 'status', s.status, 'shortfall', sales.fn_condition_shortfall(s.id)))
                              from sales.shipment s where s.company_id = me.company_id and s.provider_id = p_provider_id and s.status <> 'CLOSED'), '[]'::jsonb));
end $$;

select core.fn_assert_rls_everywhere();
reset role;
do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_fg_receive(uuid, numeric, text)', 'api.v1_carton_create(uuid, integer, numeric)', 'api.v1_carton_scan(text, text, uuid)', 'api.v1_carton_lookup(text)',
      'api.v1_courier_provider_save(uuid, text, text, text, text, integer, text)', 'api.v1_courier_rate_set(uuid, text, text, text, numeric, date)',
      'api.v1_shipment_create(uuid, uuid, text, text, jsonb, numeric, text, text, numeric, text, numeric, text, text)',
      'api.v1_shipment_update(uuid, text, uuid, numeric, numeric, numeric, numeric)', 'api.v1_slip_set(uuid, text, text, text)',
      'api.v1_condition_change_request(uuid, numeric, text, text)', 'api.v1_condition_change_decide(uuid, boolean)',
      'api.v1_courier_collection_report(uuid, numeric, timestamptz, text, text)', 'api.v1_courier_collection_verify(uuid)',
      'api.v1_courier_remittance_report(uuid, numeric, text, text, text, text)', 'api.v1_courier_remittance_verify(uuid, uuid)',
      'api.v1_courier_remittance_approve(uuid, jsonb, text)', 'api.v1_courier_remittance_attach(uuid, text)',
      'api.v1_courier_settlement_request(uuid, text, numeric, text, text)', 'api.v1_courier_settlement_decide(uuid, boolean)', 'api.v1_shipment_close(uuid)',
      'api.v1_courier_return_receive(uuid, uuid, numeric, uuid, text)', 'api.v1_shipments(text, uuid)', 'api.v1_shipment_get(uuid)', 'api.v1_courier_statement(uuid, date, date)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

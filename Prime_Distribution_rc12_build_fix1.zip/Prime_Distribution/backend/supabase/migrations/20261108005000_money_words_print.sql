-- 20261108005000_money_words_print.sql  (S68 — owner decision on money, invoice print content; docs/V180_AZ_STATUS_BN.md)
-- OWNER DECISION (14 Nov 2026): money is kept and shown in taka and paisa, 2 decimals (e.g. ৳ ১,১২,৯৫০.৬৬), and every printed money
-- document carries the amount in Bengali words ("এক লক্ষ বারো হাজার নয় শত পঞ্চাশ টাকা ছেষট্টি পয়সা মাত্র").
--   * stored money columns are numeric(…,2); every GL line is rounded to paisa (finance.fn_round, ADR-09 rounding account)
--   * internal unit costs (moving average, per-poly cost) keep up to 4–6 decimals for accuracy; any posted or printed AMOUNT is paisa
--   * core.fn_taka_words_bn / core.fn_taka_bn: one server rule, mirrored in the app (data/Format.kt) and tested on both sides
-- Print payload: invoice = company name / address / phone, line names, amount, total, paid, open, words, signed QR;
-- receipt = amount + words + verification banner. Company profile lives in settings (Chairman-editable, versioned, audited).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ number words (0–99 are irregular in Bengali)
create function core.fn_bn_words_0_99(n integer) returns text
language sql immutable set search_path = pg_catalog as $$
  select (array['শূন্য','এক','দুই','তিন','চার','পাঁচ','ছয়','সাত','আট','নয়',
                'দশ','এগারো','বারো','তেরো','চৌদ্দ','পনেরো','ষোলো','সতেরো','আঠারো','উনিশ',
                'বিশ','একুশ','বাইশ','তেইশ','চব্বিশ','পঁচিশ','ছাব্বিশ','সাতাশ','আঠাশ','ঊনত্রিশ',
                'ত্রিশ','একত্রিশ','বত্রিশ','তেত্রিশ','চৌত্রিশ','পঁয়ত্রিশ','ছত্রিশ','সাঁইত্রিশ','আটত্রিশ','ঊনচল্লিশ',
                'চল্লিশ','একচল্লিশ','বিয়াল্লিশ','তেতাল্লিশ','চুয়াল্লিশ','পঁয়তাল্লিশ','ছেচল্লিশ','সাতচল্লিশ','আটচল্লিশ','ঊনপঞ্চাশ',
                'পঞ্চাশ','একান্ন','বায়ান্ন','তিপ্পান্ন','চুয়ান্ন','পঞ্চান্ন','ছাপ্পান্ন','সাতান্ন','আটান্ন','ঊনষাট',
                'ষাট','একষট্টি','বাষট্টি','তেষট্টি','চৌষট্টি','পঁয়ষট্টি','ছেষট্টি','সাতষট্টি','আটষট্টি','ঊনসত্তর',
                'সত্তর','একাত্তর','বাহাত্তর','তিয়াত্তর','চুয়াত্তর','পঁচাত্তর','ছিয়াত্তর','সাতাত্তর','আটাত্তর','ঊনআশি',
                'আশি','একাশি','বিরাশি','তিরাশি','চুরাশি','পঁচাশি','ছিয়াশি','সাতাশি','আটাশি','ঊননব্বই',
                'নব্বই','একানব্বই','বিরানব্বই','তিরানব্বই','চুরানব্বই','পঁচানব্বই','ছিয়ানব্বই','সাতানব্বই','আটানব্বই','নিরানব্বই'])[n + 1]
$$;

-- Whole number in the Indian/Bangladeshi system: কোটি, লক্ষ, হাজার, শত (crore above 99 recurses: "এক শত পঞ্চাশ কোটি").
create function core.fn_bn_words_int(p bigint) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare n bigint := p; parts text[] := array[]::text[]; k bigint; l integer; h integer; t integer; s integer;
begin
  if p < 0 then raise exception 'E_INVALID_ACTION: negative' using errcode = 'P0001'; end if;
  if p = 0 then return 'শূন্য'; end if;
  k := n / 10000000; n := n % 10000000;
  if k > 0 then parts := parts || (core.fn_bn_words_int(k) || ' কোটি'); end if;
  l := (n / 100000)::integer; n := n % 100000;
  if l > 0 then parts := parts || (core.fn_bn_words_0_99(l) || ' লক্ষ'); end if;
  t := (n / 1000)::integer; n := n % 1000;
  if t > 0 then parts := parts || (core.fn_bn_words_0_99(t) || ' হাজার'); end if;
  h := (n / 100)::integer; s := (n % 100)::integer;
  if h > 0 then parts := parts || (core.fn_bn_words_0_99(h) || ' শত'); end if;
  if s > 0 then parts := parts || core.fn_bn_words_0_99(s); end if;
  return array_to_string(parts, ' ');
end $$;

-- 112950.66 -> "এক লক্ষ বারো হাজার নয় শত পঞ্চাশ টাকা ছেষট্টি পয়সা মাত্র" (rounded to paisa first, half up)
create function core.fn_taka_words_bn(p numeric) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare v numeric; taka bigint; paisa integer; out text;
begin
  if p is null then return null; end if;
  v := round(abs(p), 2); taka := trunc(v)::bigint; paisa := ((v - trunc(v)) * 100)::integer;
  out := core.fn_bn_words_int(taka) || ' টাকা';
  if paisa > 0 then out := out || ' ' || core.fn_bn_words_0_99(paisa) || ' পয়সা'; end if;
  return case when p < 0 then 'ঋণাত্মক ' else '' end || out || ' মাত্র';
end $$;

create function core.fn_bn_digits(p text) returns text
language sql immutable set search_path = pg_catalog as $$ select translate(p, '0123456789', '০১২৩৪৫৬৭৮৯') $$;

-- 112950.66 -> "৳ ১,১২,৯৫০.৬৬" (South-Asian grouping, always two decimals)
create function core.fn_taka_bn(p numeric) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare v numeric; ip text; fp text; g text; head text;
begin
  if p is null then return null; end if;
  v := round(abs(p), 2); ip := trunc(v)::text; fp := lpad(((v - trunc(v)) * 100)::integer::text, 2, '0');
  if length(ip) > 3 then
    g := right(ip, 3); head := left(ip, length(ip) - 3);
    while length(head) > 2 loop g := right(head, 2) || ',' || g; head := left(head, length(head) - 2); end loop;
    g := head || ',' || g;
  else g := ip; end if;
  return case when p < 0 then '-' else '' end || '৳ ' || core.fn_bn_digits(g || '.' || fp);
end $$;

-- ================================================================ company profile for printed documents (Chairman settings)
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('company.print.address_bn', 'company', 'text', '""', null, null, null, 'ছাপা নথিতে কোম্পানির ঠিকানা', 'ইনভয়েস/রসিদের মাথায়', false, 30),
  ('company.print.phone',      'company', 'text', '""', null, null, null, 'ছাপা নথিতে ফোন', 'ইনভয়েস/রসিদের মাথায়', false, 31),
  ('company.print.note_bn',    'company', 'text', '""', null, null, null, 'ইনভয়েসের নিচের নোট', 'শর্ত/ধন্যবাদ বাক্য (ঐচ্ছিক)', false, 32),
  ('company.print.logo_path',  'company', 'text', '""', null, null, null, 'লোগোর ছবি (Storage পথ)', 'ইনভয়েসের লোগো', false, 33)
on conflict (key) do nothing;

create function core.fn_print_company(p_company uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog as $$
  select jsonb_build_object('name_bn', c.name_bn, 'code', c.code,
                            'address_bn', nullif(config.fn_get_text(c.id, 'company.print.address_bn'), ''),
                            'phone', nullif(config.fn_get_text(c.id, 'company.print.phone'), ''),
                            'note_bn', nullif(config.fn_get_text(c.id, 'company.print.note_bn'), ''),
                            'logo_path', nullif(config.fn_get_text(c.id, 'company.print.logo_path'), ''))
    from core.company c where c.id = p_company
$$;

-- ================================================================ print payload (replaces the S48 body; same signature and checks)
create or replace function api.v1_print_authorize(p_doc_type text, p_doc_ref text, p_format text, p_device_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_data jsonb; v_wm text; i sales.invoice%rowtype; c sales.collection%rowtype; v_open numeric; v_lines jsonb;
begin
  select * into me from iam.fn_context(false);
  if coalesce(p_format, '') not in ('pdf','image','pos_bt','pos_usb','network','share') then perform core.fn_raise('E_INVALID_ACTION', 'format'); end if;
  if p_format in ('pos_bt','pos_usb','network')
     and not hardware.fn_device_usable(me.company_id, p_device_id, case p_format when 'pos_bt' then 'bt_printer' when 'pos_usb' then 'usb_printer' else 'network_printer' end) then
    perform core.fn_raise('E_PRINTER_NOT_REGISTERED');
  end if;
  case p_doc_type
    when 'sales.invoice' then
      select * into i from sales.invoice where company_id = me.company_id and number = p_doc_ref;
      if i.id is null then perform core.fn_raise('E_NOT_FOUND', 'invoice'); end if;
      perform iam.fn_require('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = i.dealer_id)), false);
      v_open := sales.fn_invoice_open(i.id);
      select coalesce(jsonb_agg(jsonb_build_object('line', coalesce((l ->> 'line')::integer, o.n::integer), 'sku', p.sku, 'name_bn', p.name_bn,
                                                   'qty', (l ->> 'qty')::numeric, 'price', (l ->> 'price')::numeric,
                                                   'amount', round((l ->> 'qty')::numeric * (l ->> 'price')::numeric, 2)) order by o.n), '[]'::jsonb)
        into v_lines
        from jsonb_array_elements(i.lines) with ordinality o(l, n) left join inventory.product p on p.id = (l ->> 'product_id')::uuid;
      v_data := jsonb_build_object('company', core.fn_print_company(me.company_id),
                                   'number', i.number, 'date', i.invoice_date, 'due_date', i.due_date,
                                   'dealer', (select d.name_bn from sales.dealer d where d.id = i.dealer_id),
                                   'dealer_code', (select d.code from sales.dealer d where d.id = i.dealer_id),
                                   'lines', v_lines, 'total', i.total, 'paid', i.total - v_open, 'open', v_open,
                                   'total_bn', core.fn_taka_bn(i.total), 'open_bn', core.fn_taka_bn(v_open), 'total_words', core.fn_taka_words_bn(i.total),
                                   'design_code', i.design_code,
                                   'qr', sales.fn_signed(me.company_id, 'MOS1|I|' || (select x.code from core.company x where x.id = me.company_id) || '|' || i.number));
    when 'sales.receipt' then
      select * into c from sales.collection where company_id = me.company_id and number = p_doc_ref;
      if c.id is null then perform core.fn_raise('E_NOT_FOUND', 'receipt'); end if;
      perform iam.fn_require('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = c.dealer_id)), false);
      v_data := jsonb_build_object('company', core.fn_print_company(me.company_id),
                                   'number', c.number, 'amount', c.amount, 'amount_bn', core.fn_taka_bn(c.amount), 'amount_words', core.fn_taka_words_bn(c.amount),
                                   'method', c.method, 'reference', c.reference, 'status', c.status,
                                   'dealer', (select d.name_bn from sales.dealer d where d.id = c.dealer_id),
                                   'unverified_banner', case when c.status <> 'verified' then 'যাচাই হয়নি — এটি পরিশোধের প্রমাণ নয়' end,
                                   'qr', case when c.status = 'verified' then sales.fn_signed(me.company_id, 'MOS1|R|' || (select x.code from core.company x where x.id = me.company_id) || '|' || c.number) end);
    when 'inventory.stock' then
      v_data := api.v1_stock_report((nullif(p_doc_ref, ''))::uuid, null);
    when 'finance.ledger' then
      perform iam.fn_require('finance.ledger.read', iam.fn_my_company_resource(), false);
      v_data := api.v1_trial_balance(null);
    when 'hr.payslip' then
      v_data := api.v1_payslip((split_part(p_doc_ref, ':', 1))::uuid, nullif(split_part(p_doc_ref, ':', 2), '')::uuid);
      v_data := v_data || jsonb_build_object('net_words', core.fn_taka_words_bn((v_data ->> 'net')::numeric));
    else
      perform core.fn_raise('E_INVALID_ACTION', 'unknown document type');
  end case;
  v_wm := core.fn_watermark(me.company_id);
  insert into core.print_log (company_id, person_id, doc_type, doc_ref, format, device_id, watermark) values (me.company_id, me.person_id, p_doc_type, p_doc_ref, p_format, p_device_id, v_wm);
  return jsonb_build_object('doc_type', p_doc_type, 'data', v_data, 'watermark', v_wm);
end $$;

-- Gallery preview: the 50 designs with a sample invoice (sample figures only, clearly marked; nothing is logged or printed).
create function api.v1_invoice_design_preview() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object('company', core.fn_print_company(me.company_id),
    'sample', jsonb_build_object('number', 'নমুনা-০০০১', 'date', current_date, 'due_date', current_date + 30, 'dealer', 'নমুনা ডিলার', 'dealer_code', 'D000',
       'lines', jsonb_build_array(jsonb_build_object('line', 1, 'sku', 'NDL-1', 'name_bn', 'নুডলস ৮০ গ্রাম', 'qty', 120, 'price', 640.55, 'amount', 76866.00),
                                  jsonb_build_object('line', 2, 'sku', 'CHP-2', 'name_bn', 'চিপস ২৫ গ্রাম', 'qty', 75, 'price', 480.11, 'amount', 36008.25)),
       'total', 112874.25, 'paid', 0, 'open', 112874.25, 'total_bn', core.fn_taka_bn(112874.25), 'open_bn', core.fn_taka_bn(112874.25),
       'total_words', core.fn_taka_words_bn(112874.25), 'qr', 'MOS1|SAMPLE', 'sample', true),
    'designs', (select jsonb_agg(jsonb_build_object('code', x.code, 'name_bn', x.name_bn, 'spec', x.spec) order by x.code) from sales.invoice_design x));
end $$;

reset role;
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    grant execute on function api.v1_invoice_design_preview() to authenticated;
  end if;
end $$;

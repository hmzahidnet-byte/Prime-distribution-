-- 20261108004000_v180_closure.sql  (S59 — v180 line-by-line closure; see docs/V180_TRACE_BN.md)
-- Gaps found when the v180 courier extension and Prime Distribution Architect 1 were read line by line against S56–S58:
--   Prime 02  partial dispatch: "অর্ডার ছিল কিন্তু পাঠানো হয়নি, আংশিক পাঠানো" — an allocated order can be split into a part that goes now and
--             a backorder (order lines stay immutable: the parent becomes 'split', two child orders carry the lines). Fill-rate report.
--   v180 §3   unallocated remittance stays in a visible bucket and can be allocated LATER to collections (never silently matched);
--             a collection whose money fully arrived is marked reconciled (REPORTED -> VERIFIED -> RECONCILED).
--   v180 §2   loss / damage / amount disputes on a shipment: open -> resolved, never deleted; list of unresolved events
--             (Prime 06 "অমীমাংসিত ঘটনার তালিকা").
--   v180 sc.14 an unauthorised monetary approval is rejected AND logged (server log, survives the rollback).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('inventory.dispatch.overdue_days', 'inventory', 'int', '2', '0', '60', null, 'কত দিনের বেশি না-পাঠানো অর্ডার "দেরি"', 'Prime 02', false, 2501),
  ('sales.courier_issue.stale_days', 'sales', 'int', '7', '1', '90', null, 'কত দিনের বেশি খোলা চালান "অমীমাংসিত"', 'Prime 06', false, 2510)
on conflict (key) do nothing;

-- ================================================================ unauthorised money approval: logged (v180 scenario 14)
create or replace function core.fn_require_chairman(p_maker uuid) returns uuid
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare me record;
begin
  select * into me from iam.fn_context(true);
  if not coalesce(me.is_supreme, false) then
    raise log 'MOHONA_SECURITY_DENIED person=% company=% permission=chairman.money reason=not_chairman request=%',
      me.person_id, me.company_id, current_setting('request.jwt.claims', true);
    raise exception 'E_CHAIRMAN_ONLY: only the Chairman approves money' using errcode = 'P0001';
  end if;
  if p_maker is not null and p_maker = me.person_id then
    raise log 'MOHONA_SECURITY_DENIED person=% company=% permission=chairman.money reason=self_approval', me.person_id, me.company_id;
    raise exception 'E_SELF_APPROVAL: another authorised person must prepare the Chairman''s own request' using errcode = 'P0001';
  end if;
  return me.person_id;
end $$;

-- ================================================================ order split / backorder (Prime 02)
alter table sales.sales_order add column parent_order_id uuid references sales.sales_order(id);
alter table sales.sales_order add column root_order_id uuid references sales.sales_order(id);
alter table sales.sales_order drop constraint if exists sales_order_status_check;
alter table sales.sales_order add constraint sales_order_status_check
  check (status in ('pending_approval','approved','allocated','dispatched','delivered','invoiced','cancelled','rejected','split'));
create index if not exists ix_sales_order_root on sales.sales_order (root_order_id) where root_order_id is not null;

create or replace function sales.fn_order_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.lines is distinct from old.lines or new.total <> old.total or new.dealer_id <> old.dealer_id or new.created_by <> old.created_by
     or new.parent_order_id is distinct from old.parent_order_id or new.root_order_id is distinct from old.root_order_id then
    raise exception 'E_IMMUTABLE: an order''s lines and prices never change (cancel and re-order, or split)' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'pending_approval' and new.status in ('approved','rejected','cancelled'))
       or (old.status = 'approved' and new.status in ('allocated','cancelled')) or (old.status = 'allocated' and new.status in ('dispatched','cancelled','split'))
       or (old.status = 'dispatched' and new.status in ('delivered','invoiced')) or (old.status = 'delivered' and new.status = 'invoiced')) then
    raise exception 'E_INVALID_ACTION: order % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;

-- p_now: [{product_id, qty}] — what leaves now; the rest becomes a backorder. Approval carries over (same prices, same dealer, no new money).
create function api.v1_order_split(p_order_id uuid, p_now jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype; l jsonb; v_now numeric; v_q numeric; v_a jsonb := '[]'::jsonb; v_b jsonb := '[]'::jsonb;
        v_ta numeric := 0; v_tb numeric := 0; v_ida uuid := gen_random_uuid(); v_idb uuid := gen_random_uuid(); v_root uuid; v_alloc boolean := true;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into o from sales.sales_order where id = p_order_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'order'); end if;
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_resource(o.company_id, null, null, null, o.warehouse_id), true);
  if o.status <> 'allocated' then perform core.fn_raise('E_INVALID_ACTION', 'only an allocated order is split'); end if;
  if exists (select 1 from sales.order_fulfilment f where f.order_id = o.id) then perform core.fn_raise('E_INVALID_ACTION', 'already picked: dispatch it or cancel the pick first'); end if;
  if jsonb_typeof(p_now) is distinct from 'array' then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(p_now) loop
    if not exists (select 1 from jsonb_array_elements(o.lines) x where x ->> 'product_id' = l ->> 'product_id') then
      perform core.fn_raise('E_INVALID_ACTION', 'product not on the order');
    end if;
  end loop;
  for l in select * from jsonb_array_elements(o.lines) loop
    v_q := (l ->> 'qty')::numeric;
    v_now := coalesce((select sum((x ->> 'qty')::numeric) from jsonb_array_elements(p_now) x where x ->> 'product_id' = l ->> 'product_id'), 0);
    if v_now < 0 or v_now > v_q then perform core.fn_raise('E_INVALID_ACTION', 'quantity now must be between 0 and the ordered quantity'); end if;
    if v_now > 0 then v_a := v_a || jsonb_build_array(l || jsonb_build_object('qty', v_now)); v_ta := v_ta + round(v_now * (l ->> 'price')::numeric, 2); end if;
    if v_q - v_now > 0 then v_b := v_b || jsonb_build_array(l || jsonb_build_object('qty', v_q - v_now)); v_tb := v_tb + round((v_q - v_now) * (l ->> 'price')::numeric, 2); end if;
  end loop;
  if jsonb_array_length(v_a) = 0 or jsonb_array_length(v_b) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'a split needs something now and something later'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  v_root := coalesce(o.root_order_id, o.id);
  update inventory.reservation set status = 'released', reason = 'split: ' || p_reason
   where company_id = o.company_id and batch_ref = 'SO:' || o.number and status = 'active';
  update sales.sales_order set status = 'split' where id = o.id;
  insert into sales.sales_order (id, company_id, number, dealer_id, warehouse_id, quotation_id, price_list_id, lines, total, status, approval_request_id, created_by,
                                 parent_order_id, root_order_id)
  values (v_ida, o.company_id, core.fn_next_number(o.company_id, 'sales.order', v_ida), o.dealer_id, o.warehouse_id, o.quotation_id, o.price_list_id, v_a, v_ta,
          'approved', o.approval_request_id, me.person_id, o.id, v_root),
         (v_idb, o.company_id, core.fn_next_number(o.company_id, 'sales.order', v_idb), o.dealer_id, o.warehouse_id, o.quotation_id, o.price_list_id, v_b, v_tb,
          'approved', o.approval_request_id, me.person_id, o.id, v_root);
  perform sales.fn_allocate(v_ida);                                -- the part that leaves now had stock reserved a moment ago
  begin
    perform sales.fn_allocate(v_idb);                              -- the backorder waits (status approved) when stock is short
  exception when others then v_alloc := false;
  end;
  return jsonb_build_object('order_id', o.id, 'status', 'split', 'now_order_id', v_ida, 'backorder_id', v_idb,
                            'backorder_status', case when v_alloc then 'allocated' else 'approved' end);
end $$;

create function api.v1_backorder_allocate(p_order_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype;
begin
  select * into o from sales.sales_order where id = p_order_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'order'); end if;
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_resource(o.company_id, null, null, null, o.warehouse_id), true);
  if o.status <> 'approved' then perform core.fn_raise('E_INVALID_ACTION', 'only an approved order waiting for stock'); end if;
  perform set_config('mohona.change_reason', 'backorder allocation', true);
  perform sales.fn_allocate(o.id);                                 -- E_INSUFFICIENT_STOCK when stock is still short
  return jsonb_build_object('order_id', o.id, 'status', 'allocated');
end $$;

-- Fill rate (Prime 02): per original order — ordered vs dispatched (all its split parts), partial, not sent, overdue.
create function api.v1_dispatch_fill_report(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date); v_days integer;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  v_days := config.fn_get_int(me.company_id, 'inventory.dispatch.overdue_days');
  return (with roots as (
            select o.id, o.number, o.created_at, o.status, d.name_bn dealer,
                   (select sum((x ->> 'qty')::numeric) from jsonb_array_elements(o.lines) x) ordered
              from sales.sales_order o join sales.dealer d on d.id = o.dealer_id
             where o.company_id = me.company_id and o.root_order_id is null and o.created_at::date between f and t
               and o.status not in ('rejected','pending_approval')),
          sent as (
            select r.id, coalesce(sum((y ->> 'qty')::numeric), 0) dispatched, max(ds.dispatched_at) last_at
              from roots r join sales.sales_order o on o.id = r.id or o.root_order_id = r.id
              left join sales.dispatch ds on ds.order_id = o.id left join lateral jsonb_array_elements(ds.lines) y on true
             group by r.id),
          agg_rows as (
            select r.*, s.dispatched, s.last_at,
                   case when r.status = 'cancelled' and s.dispatched = 0 then 'cancelled' when s.dispatched >= r.ordered then 'full'
                        when s.dispatched > 0 then 'partial' else 'not_sent' end state
              from roots r join sent s on s.id = r.id)
          select jsonb_build_object('from', f, 'to', t,
            'orders', count(*) filter (where state <> 'cancelled'),
            'ordered_qty', coalesce(sum(ordered) filter (where state <> 'cancelled'), 0),
            'dispatched_qty', coalesce(sum(dispatched) filter (where state <> 'cancelled'), 0),
            'fill_rate_pct', case when coalesce(sum(ordered) filter (where state <> 'cancelled'), 0) = 0 then null
                                  else round(100.0 * sum(least(dispatched, ordered)) filter (where state <> 'cancelled') / sum(ordered) filter (where state <> 'cancelled'), 1) end,
            'full', count(*) filter (where state = 'full'), 'partial', count(*) filter (where state = 'partial'), 'not_sent', count(*) filter (where state = 'not_sent'),
            'overdue', coalesce(jsonb_agg(jsonb_build_object('order', number, 'dealer', dealer, 'ordered', ordered, 'dispatched', dispatched, 'state', state,
                                                              'ordered_at', created_at) order by created_at)
                                filter (where state in ('partial','not_sent') and created_at < clock_timestamp() - make_interval(days => v_days)), '[]'::jsonb),
            'backorders', coalesce((select jsonb_agg(jsonb_build_object('order_id', b.id, 'number', b.number, 'status', b.status, 'total', b.total) order by b.created_at)
                                      from sales.sales_order b where b.company_id = me.company_id and b.parent_order_id is not null and b.status in ('approved','allocated')
                                       and not exists (select 1 from sales.dispatch z where z.order_id = b.id)), '[]'::jsonb))
          from agg_rows);
end $$;

-- ================================================================ remittance: later allocation + reconciled collections (v180 invariant 3)
alter table sales.courier_collection add column reconciled_at timestamptz;
-- a collection may be matched in several parts from the same remittance (approval now, the rest later); the outstanding checks prevent over-allocation
alter table sales.remittance_allocation drop constraint if exists remittance_allocation_remittance_id_collection_id_key;

create function sales.fn_mark_reconciled(p_collection uuid) returns void
language sql security definer set search_path = pg_catalog as $$
  update sales.courier_collection set reconciled_at = clock_timestamp()
   where id = p_collection and reconciled_at is null and sales.fn_collection_outstanding(id) = 0
$$;

create function sales.fn_alloc_mark() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform sales.fn_mark_reconciled(new.collection_id);
  return new;
end $$;
create trigger trg_remittance_allocation_mark after insert on sales.remittance_allocation for each row execute function sales.fn_alloc_mark();

create function api.v1_courier_remittance_allocate(p_remittance_id uuid, p_allocations jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.courier_remittance%rowtype; a jsonb; v_sum numeric := 0; v_left numeric;
begin
  select * into me from iam.fn_require('courier.verify', iam.fn_my_company_resource(), true);
  select * into r from sales.courier_remittance where id = p_remittance_id and company_id = me.company_id for update;
  if not found or r.status <> 'POSTED' then perform core.fn_raise('E_NOT_FOUND', 'posted remittance'); end if;
  v_left := r.amount - coalesce((select sum(x.amount) from sales.remittance_allocation x where x.remittance_id = r.id), 0);
  if jsonb_typeof(p_allocations) is distinct from 'array' or jsonb_array_length(p_allocations) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'allocations'); end if;
  perform set_config('mohona.change_reason', 'remittance matched to collections', true);
  for a in select * from jsonb_array_elements(p_allocations) loop
    perform 1 from sales.courier_collection c where c.id = (a ->> 'collection_id')::uuid for update;
    if not exists (select 1 from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                    where c.id = (a ->> 'collection_id')::uuid and c.company_id = r.company_id and s.provider_id = r.provider_id and c.status = 'VERIFIED')
       or coalesce((a ->> 'amount')::numeric, 0) <= 0 or (a ->> 'amount')::numeric > sales.fn_collection_outstanding((a ->> 'collection_id')::uuid) then
      perform core.fn_raise('E_OVERPAYMENT', 'allocation above the collection''s outstanding amount');
    end if;
    v_sum := v_sum + (a ->> 'amount')::numeric;
    if v_sum > v_left then perform core.fn_raise('E_OVERPAYMENT', 'allocations above the unallocated remittance'); end if;
    insert into sales.remittance_allocation (company_id, remittance_id, collection_id, amount) values (r.company_id, r.id, (a ->> 'collection_id')::uuid, (a ->> 'amount')::numeric);
  end loop;
  -- matching only: the money was already posted (bank Dr / courier receivable Cr) when the Chairman approved; no second journal.
  return jsonb_build_object('remittance_id', r.id, 'allocated_now', v_sum, 'unallocated', v_left - v_sum);
end $$;

-- ================================================================ shipment disputes (v180 state branches; Prime 06)
create table sales.shipment_dispute (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  shipment_id   uuid not null,
  kind          text not null check (kind in ('lost','damaged','amount','short_remittance','other')),
  lot_id        uuid,
  qty           numeric(18,4) check (qty is null or qty > 0),
  amount        numeric(14,2) check (amount is null or amount > 0),
  reason        text not null check (length(btrim(reason)) > 0),
  evidence_ref  text,
  status        text not null default 'OPEN' check (status in ('OPEN','RESOLVED')),
  resolution    text,
  settlement_id uuid references sales.courier_settlement(id),
  opened_by     uuid not null references core.person(id),
  opened_at     timestamptz not null default clock_timestamp(),
  resolved_by   uuid references core.person(id),
  resolved_at   timestamptz,
  unique (id, company_id),
  check (status = 'OPEN' or (length(btrim(coalesce(resolution, ''))) > 0 and resolved_by is not null)),
  check (resolved_by is null or resolved_by <> opened_by),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create function sales.fn_dispute_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status = 'RESOLVED' or new.shipment_id <> old.shipment_id or new.kind <> old.kind or new.qty is distinct from old.qty
     or new.amount is distinct from old.amount or new.reason <> old.reason or new.opened_by <> old.opened_by then
    raise exception 'E_IMMUTABLE: a dispute is resolved once; its facts never change' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_shipment_dispute_guard before update on sales.shipment_dispute for each row execute function sales.fn_dispute_guard();
create trigger trg_shipment_dispute_nodel before delete on sales.shipment_dispute for each row execute function core.fn_deny_delete();
create trigger trg_shipment_dispute_audit after insert or update on sales.shipment_dispute for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'shipment_dispute');

create function api.v1_shipment_dispute_open(p_shipment_id uuid, p_kind text, p_lot_id uuid, p_qty numeric, p_amount numeric, p_reason text, p_evidence_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s sales.shipment%rowtype; v_id uuid;
begin
  select * into me from iam.fn_require('courier.record', iam.fn_my_company_resource(), true);
  select * into s from sales.shipment where id = p_shipment_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'shipment'); end if;
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if coalesce(p_kind, '') not in ('lost','damaged','amount','short_remittance','other') then perform core.fn_raise('E_INVALID_ACTION', 'kind'); end if;
  if p_kind in ('lost','damaged') and (p_lot_id is null or coalesce(p_qty, 0) <= 0
       or not exists (select 1 from sales.shipment_line sl where sl.shipment_id = s.id and sl.lot_id = p_lot_id and sl.dispatched_qty >= p_qty)) then
    perform core.fn_raise('E_INVALID_ACTION', 'lot and quantity from this shipment');
  end if;
  if p_kind in ('amount','short_remittance') and coalesce(p_amount, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'amount'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.shipment_dispute (company_id, shipment_id, kind, lot_id, qty, amount, reason, evidence_ref, opened_by)
  values (me.company_id, s.id, p_kind, p_lot_id, p_qty, p_amount, btrim(p_reason), p_evidence_ref, me.person_id) returning id into v_id;
  return jsonb_build_object('dispute_id', v_id, 'status', 'OPEN');
end $$;

-- Resolving records the outcome only. Money (dealer due / concession / fee) goes through a Chairman settlement, linked here.
create function api.v1_shipment_dispute_resolve(p_dispute_id uuid, p_resolution text, p_settlement_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.shipment_dispute%rowtype;
begin
  select * into me from iam.fn_require('courier.verify', iam.fn_my_company_resource(), true);
  select * into d from sales.shipment_dispute where id = p_dispute_id and company_id = me.company_id for update;
  if not found or d.status <> 'OPEN' then perform core.fn_raise('E_NOT_FOUND', 'open dispute'); end if;
  if d.opened_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'the person who opened it does not close it'); end if;
  if length(btrim(coalesce(p_resolution, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_settlement_id is not null and not exists (select 1 from sales.courier_settlement x where x.id = p_settlement_id and x.shipment_id = d.shipment_id and x.status = 'POSTED') then
    perform core.fn_raise('E_INVALID_ACTION', 'the linked settlement must be a posted settlement of the same shipment');
  end if;
  perform set_config('mohona.change_reason', p_resolution, true);
  update sales.shipment_dispute set status = 'RESOLVED', resolution = btrim(p_resolution), settlement_id = p_settlement_id, resolved_by = me.person_id, resolved_at = clock_timestamp()
   where id = d.id;
  return jsonb_build_object('dispute_id', d.id, 'status', 'RESOLVED');
end $$;

-- Unresolved events (Prime 06): open disputes, remittances without proof or not fully matched, collections not verified,
-- shipments open longer than the setting, and courier money reported but not remitted.
create function api.v1_courier_open_issues(p_provider_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_days integer;
begin
  select * into me from iam.fn_require('courier.read', iam.fn_my_company_resource(), false);
  v_days := config.fn_get_int(me.company_id, 'sales.courier_issue.stale_days');
  return jsonb_build_object(
    'disputes', coalesce((select jsonb_agg(jsonb_build_object('dispute_id', d.id, 'shipment', s.number, 'kind', d.kind, 'qty', d.qty, 'amount', d.amount, 'reason', d.reason,
                                                              'opened_at', d.opened_at) order by d.opened_at)
                            from sales.shipment_dispute d join sales.shipment s on s.id = d.shipment_id
                           where d.company_id = me.company_id and d.status = 'OPEN' and (p_provider_id is null or s.provider_id = p_provider_id)), '[]'::jsonb),
    'missing_evidence', coalesce((select jsonb_agg(jsonb_build_object('remittance_id', r.id, 'amount', r.amount, 'reason', r.reason, 'posted_at', r.posted_at) order by r.posted_at)
                            from sales.courier_remittance r where r.company_id = me.company_id and r.missing_evidence and r.evidence_ref is null
                             and (p_provider_id is null or r.provider_id = p_provider_id)), '[]'::jsonb),
    'unallocated', coalesce((select jsonb_agg(jsonb_build_object('remittance_id', q.id, 'amount', q.amount, 'unallocated', q.left_amt) order by q.posted_at) from (
                            select r.id, r.amount, r.posted_at, r.amount - coalesce((select sum(a.amount) from sales.remittance_allocation a where a.remittance_id = r.id), 0) left_amt
                              from sales.courier_remittance r where r.company_id = me.company_id and r.status = 'POSTED' and (p_provider_id is null or r.provider_id = p_provider_id)) q
                           where q.left_amt > 0), '[]'::jsonb),
    'unverified_collections', coalesce((select jsonb_agg(jsonb_build_object('collection_id', c.id, 'shipment', s.number, 'amount', c.collected_amount, 'at', c.collected_at) order by c.collected_at)
                            from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                           where c.company_id = me.company_id and c.status = 'REPORTED' and (p_provider_id is null or s.provider_id = p_provider_id)), '[]'::jsonb),
    'stale_shipments', coalesce((select jsonb_agg(jsonb_build_object('shipment_id', s.id, 'shipment', s.number, 'status', s.status, 'dispatched_at', s.dispatched_at,
                                                              'shortfall', sales.fn_condition_shortfall(s.id)) order by s.dispatched_at)
                            from sales.shipment s where s.company_id = me.company_id and s.status <> 'CLOSED' and s.dispatched_at < clock_timestamp() - make_interval(days => v_days)
                             and (p_provider_id is null or s.provider_id = p_provider_id)), '[]'::jsonb),
    'collected_not_remitted', coalesce((select sum(sales.fn_collection_outstanding(c.id)) from sales.courier_collection c join sales.shipment s on s.id = c.shipment_id
                           where c.company_id = me.company_id and c.status = 'VERIFIED' and (p_provider_id is null or s.provider_id = p_provider_id)), 0));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_order_split(uuid, jsonb, text)', 'api.v1_backorder_allocate(uuid)', 'api.v1_dispatch_fill_report(date, date)',
      'api.v1_courier_remittance_allocate(uuid, jsonb)', 'api.v1_shipment_dispute_open(uuid, text, uuid, numeric, numeric, text, text)',
      'api.v1_shipment_dispute_resolve(uuid, text, uuid)', 'api.v1_courier_open_issues(uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

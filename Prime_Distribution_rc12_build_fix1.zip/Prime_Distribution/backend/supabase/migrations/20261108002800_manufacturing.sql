-- 20261108002800_manufacturing.sql  (S32–S35 in one step)
-- Manufacturing (blueprint MANUFACTURING MOS-F153-101..110) + ADR-11 residual cost allocation + ADR-12 batch snapshot +
-- OI-39 (issues only for approved batches):
--   101 BOM versions per finished good: approved by another person, immutable once approved, pinned by every batch
--   102 production plan (daily POLY targets) — never issues or reserves stock
--   103 batch: unique number per company, pinned BOM, production line; approval snapshots the POLY spec and reserves materials
--   104 material issue (S25 engine) only against an approved batch's reservations; never beyond available
--   105 in-process / final QC by someone other than the batch creator; a failed final QC blocks FG posting
--   106 waste: normal (absorbed) / abnormal and scrap (approved, taken out of WIP and classified apart) / rework
--   107 WIP = materials + labour + overhead actuals; nothing reaches P&L before completion
--   108 FG completion: POLY yield; WIP capitalised to FG with the deterministic remainder on the last unit (ADR-11); low
--       yield needs approval and the exceptional part goes to a variance; WIP is cleared to exactly zero
--   109 repackaging / rework batches from returned FG after QC; output never exceeds input (no silent new FG)
--   110 traceability: raw lot <-> batch <-> FG lot (and supplier) in one call either direction
-- Ledger journals (WIP / FG / variance accounts) arrive with FINANCE_LEDGER (S36–S39) from mfg.wip_entry.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ BOM (F101)
create table mfg.bom (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  product_id    uuid not null,
  variant_id    uuid,
  version       integer not null check (version >= 1),
  output_qty    numeric(18,4) not null check (output_qty > 0),        -- POLY produced by the quantities below
  status        text not null default 'pending' check (status in ('pending','approved','rejected','retired')),
  reason        text not null check (length(btrim(reason)) > 0),
  created_by    uuid not null references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  approved_by   uuid references core.person(id),
  approved_at   timestamptz,
  used_at       timestamptz,
  unique (id, company_id),
  check (approved_by is null or approved_by <> created_by),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  foreign key (variant_id, company_id) references inventory.product_variant (id, company_id)
);
create unique index bom_version on mfg.bom (product_id, variant_id, version) nulls not distinct;
create table mfg.bom_line (
  bom_id       uuid not null,
  company_id   uuid not null,
  line_no      integer not null check (line_no >= 1),
  material_id  uuid not null,
  qty          numeric(18,6) not null check (qty > 0),                -- base units per output_qty POLY
  normal_loss_pct numeric(5,2) not null default 0 check (normal_loss_pct between 0 and 50),
  primary key (bom_id, line_no),
  foreign key (bom_id, company_id) references mfg.bom (id, company_id),
  foreign key (material_id, company_id) references inventory.product (id, company_id)
);
create function mfg.fn_bom_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','approved_by','approved_at','used_at']) <> (to_jsonb(new) - array['status','approved_by','approved_at','used_at'])
     or not ((old.status = 'pending' and new.status in ('approved','rejected')) or (old.status = 'approved' and new.status in ('approved','retired')) or new.status = old.status)
     or (old.used_at is not null and new.used_at is distinct from old.used_at) then
    raise exception 'E_IMMUTABLE: an approved BOM never changes; create a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_bom_guard before update on mfg.bom for each row execute function mfg.fn_bom_guard();
create trigger trg_bom_nodel before delete on mfg.bom for each row execute function core.fn_deny_delete();
create trigger trg_bom_audit after insert or update on mfg.bom for each row execute function audit.fn_row_change();
create function mfg.fn_bom_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if tg_op <> 'INSERT' or (select b.status from mfg.bom b where b.id = new.bom_id) <> 'pending' then
    raise exception 'E_IMMUTABLE: BOM lines are written once with a pending version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_bom_line_guard before insert or update or delete on mfg.bom_line for each row execute function mfg.fn_bom_line_guard();
create trigger trg_bom_line_audit after insert on mfg.bom_line for each row execute function audit.fn_row_change();

-- ================================================================ plan (F102) — no stock fields at all
create table mfg.plan (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  plan_date   date not null,
  wing_id     uuid,
  lines       jsonb not null,                 -- [{line_no, product_id, variant_id, target_poly}]
  status      text not null default 'draft' check (status in ('draft','approved','cancelled')),
  reason      text not null,
  created_by  uuid not null references core.person(id),
  approved_by uuid references core.person(id),
  created_at  timestamptz not null default clock_timestamp(),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id),
  check (approved_by is null or approved_by <> created_by)
);
create trigger trg_plan_touch before update on mfg.plan for each row execute function core.fn_touch_row();
create trigger trg_plan_nodel before delete on mfg.plan for each row execute function core.fn_deny_delete();
create trigger trg_plan_audit after insert or update on mfg.plan for each row execute function audit.fn_row_change();

-- ================================================================ batch (F103) + WIP ledger (F107)
create table mfg.batch (
  id                uuid primary key default gen_random_uuid(),
  company_id        uuid not null,
  number            text not null,
  kind              text not null default 'production' check (kind in ('production','rework')),
  plan_id           uuid,
  plan_line         integer,
  product_id        uuid not null,
  variant_id        uuid,
  bom_id            uuid,
  production_line   text,
  planned_poly      numeric(18,4) not null check (planned_poly > 0),
  raw_warehouse     uuid not null,
  fg_warehouse      uuid not null,
  pack_spec         jsonb,                    -- ADR-12 snapshot taken at approval
  status            text not null default 'draft' check (status in ('draft','approved','in_progress','completion_pending','completed','cancelled')),
  fg_poly           numeric(18,4),
  fg_lot_id         uuid,
  fg_unit_cost      numeric(18,6),
  pending_completion jsonb,
  rework_source     jsonb,                    -- {warehouse_id, lot_id, poly}
  reason            text not null,
  created_by        uuid not null references core.person(id),
  created_at        timestamptz not null default clock_timestamp(),
  approved_by       uuid references core.person(id),
  approved_at       timestamptz,
  completed_at      timestamptz,
  updated_at        timestamptz not null default clock_timestamp(),
  row_version       integer not null default 1,
  unique (id, company_id), unique (company_id, number),
  check (approved_by is null or approved_by <> created_by),
  check ((kind = 'production') = (bom_id is not null)),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  foreign key (bom_id, company_id) references mfg.bom (id, company_id),
  foreign key (raw_warehouse, company_id) references inventory.warehouse (id, company_id),
  foreign key (fg_warehouse, company_id) references inventory.warehouse (id, company_id),
  foreign key (plan_id, company_id) references mfg.plan (id, company_id)
);
create function mfg.fn_batch_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.number <> old.number or new.product_id <> old.product_id or new.bom_id is distinct from old.bom_id or new.kind <> old.kind or new.created_by <> old.created_by
     or (old.pack_spec is not null and new.pack_spec is distinct from old.pack_spec) or new.planned_poly <> old.planned_poly and old.status <> 'draft' then
    raise exception 'E_IMMUTABLE: batch identity, BOM and POLY snapshot are fixed' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('approved','cancelled')) or (old.status = 'approved' and new.status in ('in_progress','cancelled'))
       or (old.status = 'in_progress' and new.status in ('completion_pending','completed')) or (old.status = 'completion_pending' and new.status in ('completed','in_progress'))) then
    raise exception 'E_INVALID_ACTION: batch % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_batch_guard before update on mfg.batch for each row execute function mfg.fn_batch_guard();
create trigger trg_batch_touch before update on mfg.batch for each row execute function core.fn_touch_row();
create trigger trg_batch_nodel before delete on mfg.batch for each row execute function core.fn_deny_delete();
create trigger trg_batch_audit after insert or update on mfg.batch for each row execute function audit.fn_row_change();

-- Every WIP amount of a batch; at completion the entries sum to exactly zero (ADR-11).
create table mfg.wip_entry (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  batch_id    uuid not null,
  kind        text not null check (kind in ('material','rework_input','labor','overhead','abnormal','scrap','variance','fg')),
  amount      numeric(18,4) not null,
  note        text,
  person_id   uuid,
  at          timestamptz not null default clock_timestamp(),
  foreign key (batch_id, company_id) references mfg.batch (id, company_id)
);
create trigger trg_wip_entry_no_mutation before update or delete on mfg.wip_entry for each row execute function core.fn_deny_mutation();
create trigger trg_wip_entry_audit after insert on mfg.wip_entry for each row execute function audit.fn_row_change();

-- ================================================================ QC (F105) + waste (F106)
create table mfg.qc_inspection (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  batch_id    uuid not null,
  stage       text not null check (stage in ('in_process','final')),
  result      text not null check (result in ('pass','fail')),
  parameters  jsonb not null default '{}'::jsonb,
  notes       text,
  inspector   uuid not null references core.person(id),
  at          timestamptz not null default clock_timestamp(),
  foreign key (batch_id, company_id) references mfg.batch (id, company_id)
);
create trigger trg_qc_no_mutation before update or delete on mfg.qc_inspection for each row execute function core.fn_deny_mutation();
create trigger trg_qc_audit after insert on mfg.qc_inspection for each row execute function audit.fn_row_change();

create table mfg.batch_waste (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  batch_id     uuid not null,
  kind         text not null check (kind in ('normal','abnormal','scrap','rework')),
  qty_poly     numeric(18,4) not null check (qty_poly > 0),
  value        numeric(18,4) not null default 0 check (value >= 0),
  status       text not null default 'recorded' check (status in ('recorded','pending','posted','rejected')),
  reason       text not null check (length(btrim(reason)) > 0),
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  check (decided_by is null or decided_by <> created_by),
  foreign key (batch_id, company_id) references mfg.batch (id, company_id)
);
create function mfg.fn_waste_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','decided_by','decided_at','value']) <> (to_jsonb(new) - array['status','decided_by','decided_at','value']) or old.status <> 'pending' then
    raise exception 'E_IMMUTABLE: waste is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_waste_guard before update on mfg.batch_waste for each row execute function mfg.fn_waste_guard();
create trigger trg_waste_nodel before delete on mfg.batch_waste for each row execute function core.fn_deny_delete();
create trigger trg_waste_audit after insert or update on mfg.batch_waste for each row execute function audit.fn_row_change();

select core.fn_apply_rls('mfg', 'bom');
select core.fn_apply_rls('mfg', 'bom_line');
select core.fn_apply_rls('mfg', 'plan');
select core.fn_apply_rls('mfg', 'batch');
select core.fn_apply_rls('mfg', 'wip_entry');
select core.fn_apply_rls('mfg', 'qc_inspection');
select core.fn_apply_rls('mfg', 'batch_waste');

-- ================================================================ permissions + settings
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('mfg.bom.approve',   'mfg', 'রেসিপি (BOM) অনুমোদন', 'approve', true, false, array['COMPANY','WING'], 'active', 905),
  ('mfg.batch.approve', 'mfg', 'উৎপাদন-পরিকল্পনা ও ব্যাচ অনুমোদন', 'approve', true, false, array['COMPANY','WING'], 'active', 906);
update iam.permission_catalog set status = 'active'
 where code in ('mfg.plan.create','mfg.batch.start','mfg.qc.inspect','mfg.fg.receive','mfg.cost.read','mfg.rework.approve');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', 'COMPANY' from (values ('PROD_SUPERVISOR','mfg.plan.create'), ('PROD_SUPERVISOR','mfg.batch.start'), ('PROD_SUPERVISOR','mfg.fg.receive'),
  ('QC_OFFICER','mfg.qc.inspect'), ('MD','mfg.bom.approve'), ('MD','mfg.batch.approve'), ('MD','mfg.rework.approve'), ('MD','mfg.cost.read'),
  ('FIN_MANAGER','mfg.cost.read'), ('FIN_MANAGER','mfg.rework.approve'), ('MD','mfg.bom.read'), ('FIN_MANAGER','mfg.bom.read')) v(x, y)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('mfg.yield.min_pct',        'mfg', 'int',  '95', 50, 100, null, 'এর কম উৎপাদন-হারে সমাপ্তিতে অনুমোদন লাগবে (%)', 'MOS-F153-108 / ADR-11', true, 1400),
  ('mfg.qc.final_required',    'mfg', 'bool', 'true', null, null, null, 'চূড়ান্ত QC পাস ছাড়া FG পোস্ট নয়', 'MOS-F153-105', true, 1410);

-- ================================================================ engine
-- Material cost in a batch = issued value − returned value (from the stock ledger of the batch's issues).
create function mfg.fn_material_cost(p_batch uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((select -sum(m.value) from inventory.stock_move m join inventory.material_issue mi on mi.id = m.doc_id
                    where m.doc_type = 'inventory.issue' and mi.company_id = b.company_id and mi.batch_ref = b.number), 0)
       - coalesce((select sum(m.value) from inventory.stock_move m join inventory.material_return r on r.id = m.doc_id join inventory.material_issue mi on mi.id = r.issue_id
                    where m.doc_type = 'inventory.return' and mi.company_id = b.company_id and mi.batch_ref = b.number), 0)
    from mfg.batch b where b.id = p_batch
$$;

-- Current WIP before completion: materials (live) + every non-material WIP entry (labour, overhead, rework input, −abnormal, −scrap).
create function mfg.fn_wip(p_batch uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select mfg.fn_material_cost(p_batch) + coalesce((select sum(e.amount) from mfg.wip_entry e where e.batch_id = p_batch and e.kind <> 'material'), 0)
$$;

-- OI-39: an issue against a production batch's reservation needs that batch approved / in progress; returns stop at completion.
create function mfg.fn_issue_batch_guard() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare b mfg.batch%rowtype; v_ref text;
begin
  if tg_table_name = 'material_issue' then
    v_ref := new.batch_ref;
  else
    select mi.batch_ref into v_ref from inventory.material_issue mi where mi.id = new.issue_id;
  end if;
  select * into b from mfg.batch where company_id = new.company_id and number = v_ref for update;
  if found then
    if b.status not in ('approved','in_progress') then
      raise exception 'E_BATCH_NOT_APPROVED: batch % is %', b.number, b.status using errcode = 'P0001';
    end if;
    if b.status = 'approved' then update mfg.batch set status = 'in_progress' where id = b.id; end if;
  end if;
  return new;
end $$;
create trigger trg_issue_batch_guard before insert on inventory.material_issue for each row execute function mfg.fn_issue_batch_guard();
create trigger trg_return_batch_guard before insert on inventory.material_return for each row execute function mfg.fn_issue_batch_guard();

-- FG posting (F108, ADR-11): capitalised = WIP (or WIP × yield share when an exceptional low yield was approved);
-- (n−1) POLY at the floored unit cost + the last POLY with the remainder, so FG value = capitalised exactly; WIP → 0.
create function mfg.fn_post_fg(p_batch uuid, p_fg_poly numeric, p_lot_no text, p_expiry date, p_with_variance boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = pg_catalog as $$
declare b mfg.batch%rowtype; v_mat numeric; v_wip numeric; v_cap numeric; v_var numeric := 0; v_unit numeric; v_last numeric; v_lot uuid; v_sum numeric;
begin
  select * into b from mfg.batch where id = p_batch for update;
  v_mat := round(mfg.fn_material_cost(b.id), 4);
  insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (b.company_id, b.id, 'material', v_mat, 'materials issued − returned', iam.fn_current_person());
  select coalesce(sum(e.amount), 0) into v_wip from mfg.wip_entry e where e.batch_id = b.id;
  if v_wip < 0 then raise exception 'E_INVALID_ACTION: WIP below zero' using errcode = 'P0001'; end if;
  v_cap := case when p_with_variance then least(round(v_wip * p_fg_poly / b.planned_poly, 4), v_wip) else v_wip end;
  v_var := v_wip - v_cap;                                         -- only an APPROVED exceptional yield difference; rounding stays in FG
  insert into inventory.lot (company_id, product_id, lot_no, mfg_date, expiry_date)
  values (b.company_id, b.product_id, coalesce(p_lot_no, b.number), current_date, p_expiry) returning id into v_lot;
  if p_fg_poly = 1 then
    perform inventory.fn_post_move(b.company_id, b.fg_warehouse, b.product_id, v_lot, 'fg_receipt', 1, v_cap, 'mfg.batch', b.id, 1, p_reason);
    v_unit := v_cap;
  else
    v_unit := trunc(v_cap / p_fg_poly, 4);
    v_last := v_cap - v_unit * (p_fg_poly - 1);                   -- the last POLY carries the deterministic remainder
    perform inventory.fn_post_move(b.company_id, b.fg_warehouse, b.product_id, v_lot, 'fg_receipt', p_fg_poly - 1, v_unit, 'mfg.batch', b.id, 1, p_reason);
    perform inventory.fn_post_move(b.company_id, b.fg_warehouse, b.product_id, v_lot, 'fg_receipt', 1, v_last, 'mfg.batch', b.id, 2, p_reason);
  end if;
  insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (b.company_id, b.id, 'fg', -v_cap, 'capitalised to FG', iam.fn_current_person());
  if v_var <> 0 then
    insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id)
    values (b.company_id, b.id, 'variance', -v_var, 'approved yield variance', iam.fn_current_person());
  end if;
  select coalesce(sum(e.amount), 0) into v_sum from mfg.wip_entry e where e.batch_id = b.id;
  if v_sum <> 0 then raise exception 'E_WIP_UNBALANCED: % left in WIP', v_sum using errcode = 'P0001'; end if;
  update inventory.reservation set status = 'released', reason = 'batch completed' where company_id = b.company_id and batch_ref = b.number and status = 'active';
  update mfg.batch set status = 'completed', fg_poly = p_fg_poly, fg_lot_id = v_lot, fg_unit_cost = round(v_cap / p_fg_poly, 6), pending_completion = null,
                       completed_at = clock_timestamp() where id = b.id;
  return jsonb_build_object('batch_id', b.id, 'fg_lot_id', v_lot, 'fg_poly', p_fg_poly, 'capitalised', v_cap, 'variance', v_var, 'wip_before', v_wip);
end $$;

-- ================================================================ API: BOM (F101)
create function api.v1_bom_propose(p_product_id uuid, p_variant_id uuid, p_output_qty numeric, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); v integer; l jsonb; n integer := 0;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.bom.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from inventory.product p where p.id = p_product_id and p.company_id = me.company_id and p.kind = 'finished_good' and p.status <> 'archived') then
    perform core.fn_raise('E_NOT_FOUND', 'finished good');
  end if;
  if coalesce(p_output_qty, 0) <= 0 or jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then
    perform core.fn_raise('E_INVALID_ACTION', 'output quantity / lines');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform pg_advisory_xact_lock(hashtext(p_product_id::text || coalesce(p_variant_id::text, '-')));
  v := coalesce((select max(b.version) from mfg.bom b where b.product_id = p_product_id and b.variant_id is not distinct from p_variant_id), 0) + 1;
  insert into mfg.bom (id, company_id, product_id, variant_id, version, output_qty, reason, created_by)
  values (v_id, me.company_id, p_product_id, p_variant_id, v, p_output_qty, p_reason, me.person_id);
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    if not exists (select 1 from inventory.product p where p.id = (l ->> 'material_id')::uuid and p.company_id = me.company_id and p.kind in ('raw_material','packaging')) then
      perform core.fn_raise('E_NOT_FOUND', 'material ' || (l ->> 'material_id'));
    end if;
    insert into mfg.bom_line (bom_id, company_id, line_no, material_id, qty, normal_loss_pct)
    values (v_id, me.company_id, n, (l ->> 'material_id')::uuid, (l ->> 'qty')::numeric, coalesce((l ->> 'normal_loss_pct')::numeric, 0));
  end loop;
  return jsonb_build_object('bom_id', v_id, 'version', v, 'status', 'pending');
end $$;

create function api.v1_bom_decide(p_bom_id uuid, p_approve boolean, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.bom%rowtype;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.bom.approve', iam.fn_my_company_resource(), true);
  select * into b from mfg.bom where id = p_bom_id and company_id = me.company_id for update;
  if not found or b.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending BOM'); end if;
  if b.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  update mfg.bom set status = case when p_approve then 'approved' else 'rejected' end, approved_by = case when p_approve then me.person_id end,
                     approved_at = case when p_approve then clock_timestamp() end where id = b.id;
  return jsonb_build_object('bom_id', b.id, 'status', case when p_approve then 'approved' else 'rejected' end);
end $$;

create function api.v1_boms(p_product_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('mfg.bom.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'version', b.version, 'variant_id', b.variant_id, 'output_qty', b.output_qty, 'status', b.status,
           'used', b.used_at is not null, 'lines', (select jsonb_agg(jsonb_build_object('line_no', l.line_no, 'material_id', l.material_id, 'sku', p.sku, 'qty', l.qty,
                                                    'normal_loss_pct', l.normal_loss_pct) order by l.line_no)
                                     from mfg.bom_line l join inventory.product p on p.id = l.material_id where l.bom_id = b.id)) order by b.version desc)
     from mfg.bom b where b.product_id = p_product_id and b.company_id = me.company_id), '[]'::jsonb);
end $$;

-- ================================================================ API: plan (F102)
create function api.v1_plan_save(p_id uuid, p_plan_date date, p_wing_id uuid, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.plan.create', iam.fn_resource(iam.fn_context_company(), p_wing_id), true);
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100
     or exists (select 1 from jsonb_array_elements(p_lines) x where coalesce((x ->> 'target_poly')::numeric, 0) <= 0
                   or not exists (select 1 from inventory.product p where p.id = (x ->> 'product_id')::uuid and p.company_id = me.company_id and p.kind = 'finished_good')) then
    perform core.fn_raise('E_INVALID_ACTION', 'lines: finished goods with positive POLY targets');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into mfg.plan (company_id, plan_date, wing_id, lines, reason, created_by)
    values (me.company_id, p_plan_date, p_wing_id, (select jsonb_agg(x || jsonb_build_object('line_no', o)) from jsonb_array_elements(p_lines) with ordinality t(x, o)), p_reason, me.person_id)
    returning id into v_id;
  else
    update mfg.plan set plan_date = p_plan_date, lines = (select jsonb_agg(x || jsonb_build_object('line_no', o)) from jsonb_array_elements(p_lines) with ordinality t(x, o)), reason = p_reason
     where id = p_id and company_id = me.company_id and status = 'draft' returning id into v_id;
    if v_id is null then perform core.fn_raise('E_INVALID_ACTION', 'only a draft plan is edited'); end if;
  end if;
  return jsonb_build_object('plan_id', v_id);
end $$;

create function api.v1_plan_approve(p_plan_id uuid, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p mfg.plan%rowtype;
begin
  select * into me from iam.fn_require('mfg.batch.approve', iam.fn_my_company_resource(), true);
  select * into p from mfg.plan where id = p_plan_id and company_id = me.company_id for update;
  if not found or p.status <> 'draft' then perform core.fn_raise('E_NOT_FOUND', 'draft plan'); end if;
  if p.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', coalesce(p_note, 'plan approved'), true);
  update mfg.plan set status = 'approved', approved_by = me.person_id where id = p.id;     -- a plan never touches stock (F102)
  return jsonb_build_object('plan_id', p.id, 'status', 'approved');
end $$;

-- ================================================================ API: batches (F103, F104, F109)
create function api.v1_batch_create(p_product_id uuid, p_variant_id uuid, p_bom_id uuid, p_planned_poly numeric, p_raw_warehouse uuid, p_fg_warehouse uuid,
                                    p_production_line text, p_plan_id uuid, p_plan_line integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_bom uuid := p_bom_id; v_id uuid := gen_random_uuid();
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.batch.start', iam.fn_my_company_resource(), true);
  if not inventory.fn_product_usable(me.company_id, p_product_id, p_variant_id) then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
  if v_bom is null then
    select b.id into v_bom from mfg.bom b where b.product_id = p_product_id and b.variant_id is not distinct from p_variant_id and b.status = 'approved'
     order by b.version desc limit 1;
  end if;
  if not exists (select 1 from mfg.bom b where b.id = v_bom and b.company_id = me.company_id and b.product_id = p_product_id and b.status = 'approved') then
    perform core.fn_raise('E_BOM_NOT_APPROVED');
  end if;
  if coalesce(p_planned_poly, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'planned POLY'); end if;
  if p_plan_id is not null and not exists (select 1 from mfg.plan p where p.id = p_plan_id and p.company_id = me.company_id and p.status = 'approved') then
    perform core.fn_raise('E_INVALID_ACTION', 'plan is not approved');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into mfg.batch (id, company_id, number, product_id, variant_id, bom_id, production_line, planned_poly, raw_warehouse, fg_warehouse, plan_id, plan_line, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'mfg.batch', v_id), p_product_id, p_variant_id, v_bom, p_production_line, p_planned_poly,
          p_raw_warehouse, p_fg_warehouse, p_plan_id, p_plan_line, p_reason, me.person_id);
  return jsonb_build_object('batch_id', v_id, 'number', (select b.number from mfg.batch b where b.id = v_id), 'bom_id', v_bom, 'status', 'draft');
end $$;

-- Rework / repackaging (F109): returned FG from one lot is reworked into the SAME product; output can never exceed input.
create function api.v1_rework_create(p_product_id uuid, p_source_warehouse uuid, p_lot_id uuid, p_input_poly numeric, p_fg_warehouse uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid();
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.batch.start', iam.fn_my_company_resource(), true);
  if not exists (select 1 from inventory.lot l where l.id = p_lot_id and l.company_id = me.company_id and l.product_id = p_product_id) then perform core.fn_raise('E_NOT_FOUND', 'lot of this product'); end if;
  if coalesce(p_input_poly, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'input POLY'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into mfg.batch (id, company_id, number, kind, product_id, planned_poly, raw_warehouse, fg_warehouse, rework_source, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'mfg.batch', v_id), 'rework', p_product_id, p_input_poly, p_source_warehouse, p_fg_warehouse,
          jsonb_build_object('warehouse_id', p_source_warehouse, 'lot_id', p_lot_id, 'poly', p_input_poly), p_reason, me.person_id);
  return jsonb_build_object('batch_id', v_id, 'number', (select b.number from mfg.batch b where b.id = v_id), 'status', 'draft');
end $$;

-- Approval (another person): POLY spec snapshot (ADR-12); production: BOM pinned + materials reserved (never above available);
-- rework: the returned lot is taken into WIP at its current cost.
create function api.v1_batch_approve(p_batch_id uuid, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; bm mfg.bom%rowtype; l record; v_qty numeric; v_avail numeric; v_cost numeric;
begin
  select * into me from iam.fn_require('mfg.batch.approve', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id for update;
  if not found or b.status <> 'draft' then perform core.fn_raise('E_NOT_FOUND', 'draft batch'); end if;
  if b.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', coalesce(p_note, 'batch approved'), true);
  update mfg.batch set pack_spec = inventory.fn_pack_spec_snapshot(b.product_id, b.variant_id, clock_timestamp()), status = 'approved',
                       approved_by = me.person_id, approved_at = clock_timestamp() where id = b.id;
  if b.kind = 'production' then
    select * into bm from mfg.bom where id = b.bom_id for update;
    if bm.status <> 'approved' then perform core.fn_raise('E_BOM_NOT_APPROVED'); end if;
    if bm.used_at is null then update mfg.bom set used_at = clock_timestamp() where id = bm.id; end if;
    for l in select * from mfg.bom_line x where x.bom_id = bm.id order by x.line_no loop
      v_qty := round(l.qty * b.planned_poly / bm.output_qty * (1 + l.normal_loss_pct / 100), 4);
      perform pg_advisory_xact_lock(hashtext(b.raw_warehouse::text || l.material_id::text));
      v_avail := inventory.fn_available(b.company_id, b.raw_warehouse, l.material_id);
      if v_qty > v_avail then perform core.fn_raise('E_INSUFFICIENT_STOCK', (select p.sku from inventory.product p where p.id = l.material_id) || ': ' || v_avail); end if;
      insert into inventory.reservation (company_id, warehouse_id, product_id, batch_ref, qty, created_by, reason)
      values (b.company_id, b.raw_warehouse, l.material_id, b.number, v_qty, me.person_id, 'batch ' || b.number);
    end loop;
  else
    v_cost := inventory.fn_post_move(b.company_id, b.raw_warehouse, b.product_id, (b.rework_source ->> 'lot_id')::uuid, 'issue', -((b.rework_source ->> 'poly')::numeric), null,
                                     'mfg.rework_input', b.id, 1, 'rework input');
    insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id)
    values (b.company_id, b.id, 'rework_input', round(v_cost * (b.rework_source ->> 'poly')::numeric, 4), 'returned FG taken into rework', me.person_id);
    update mfg.batch set status = 'in_progress' where id = b.id;
  end if;
  return jsonb_build_object('batch_id', b.id, 'status', (select x.status from mfg.batch x where x.id = b.id), 'pack_spec', (select x.pack_spec from mfg.batch x where x.id = b.id));
end $$;

-- Labour / overhead actuals (F107): only while the batch runs; they stay in WIP until completion.
create function api.v1_batch_cost(p_batch_id uuid, p_kind text, p_amount numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.batch.start', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id;
  if not found or b.status not in ('approved','in_progress') then perform core.fn_raise('E_INVALID_ACTION', 'costs are added while the batch runs'); end if;
  if coalesce(p_kind, '') not in ('labor','overhead') or coalesce(p_amount, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'kind / amount'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (b.company_id, b.id, p_kind, round(p_amount, 4), p_reason, me.person_id);
  return jsonb_build_object('batch_id', b.id, 'wip', mfg.fn_wip(b.id));
end $$;

-- QC (F105): never by the batch creator.
create function api.v1_batch_qc(p_batch_id uuid, p_stage text, p_result text, p_parameters jsonb, p_notes text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; v_id uuid;
begin
  select * into me from iam.fn_require('mfg.qc.inspect', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id;
  if not found or b.status not in ('approved','in_progress','completion_pending') then perform core.fn_raise('E_NOT_FOUND', 'running batch'); end if;
  if b.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'the batch creator does not inspect it'); end if;
  if coalesce(p_stage, '') not in ('in_process','final') or coalesce(p_result, '') not in ('pass','fail') then perform core.fn_raise('E_INVALID_ACTION', 'stage / result'); end if;
  perform set_config('mohona.change_reason', 'QC ' || p_stage, true);
  insert into mfg.qc_inspection (company_id, batch_id, stage, result, parameters, notes, inspector)
  values (b.company_id, b.id, p_stage, p_result, coalesce(p_parameters, '{}'::jsonb), p_notes, me.person_id) returning id into v_id;
  return jsonb_build_object('inspection_id', v_id, 'result', p_result);
end $$;

-- Waste (F106): normal and rework are recorded (normal stays in FG cost); abnormal and scrap wait for approval.
create function api.v1_batch_waste(p_batch_id uuid, p_kind text, p_qty_poly numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.waste.submit', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id;
  if not found or b.status <> 'in_progress' then perform core.fn_raise('E_INVALID_ACTION', 'waste is recorded on a running batch'); end if;
  if coalesce(p_kind, '') not in ('normal','abnormal','scrap','rework') or coalesce(p_qty_poly, 0) <= 0 or p_qty_poly > b.planned_poly then
    perform core.fn_raise('E_INVALID_ACTION', 'kind / quantity');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into mfg.batch_waste (company_id, batch_id, kind, qty_poly, status, reason, created_by)
  values (b.company_id, b.id, p_kind, p_qty_poly, case when p_kind in ('abnormal','scrap') then 'pending' else 'recorded' end, p_reason, me.person_id) returning id into v_id;
  return jsonb_build_object('waste_id', v_id, 'status', case when p_kind in ('abnormal','scrap') then 'pending' else 'recorded' end);
end $$;

create function api.v1_batch_waste_decide(p_waste_id uuid, p_approve boolean, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; w mfg.batch_waste%rowtype; b mfg.batch%rowtype; v_value numeric := 0;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.rework.approve', iam.fn_my_company_resource(), true);
  select * into w from mfg.batch_waste where id = p_waste_id and company_id = me.company_id for update;
  if not found or w.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending waste'); end if;
  if w.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  select * into b from mfg.batch where id = w.batch_id for update;
  if b.status <> 'in_progress' then perform core.fn_raise('E_INVALID_ACTION', 'batch is not running'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  if p_approve then
    v_value := least(round(mfg.fn_wip(b.id) * w.qty_poly / b.planned_poly, 4), greatest(mfg.fn_wip(b.id), 0));
    insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (b.company_id, b.id, w.kind, -v_value, w.reason, me.person_id);
  end if;
  update mfg.batch_waste set status = case when p_approve then 'posted' else 'rejected' end, value = v_value, decided_by = me.person_id, decided_at = clock_timestamp() where id = w.id;
  return jsonb_build_object('waste_id', w.id, 'value', v_value, 'status', case when p_approve then 'posted' else 'rejected' end);
end $$;

-- ================================================================ API: completion (F108, ADR-11)
create function api.v1_batch_complete(p_batch_id uuid, p_fg_poly numeric, p_lot_no text, p_expiry_date date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; v_last text; v_yield numeric; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.fg.receive', iam.fn_resource(iam.fn_context_company(), null, null, null, null), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id for update;
  if not found or b.status <> 'in_progress' then perform core.fn_raise('E_INVALID_ACTION', 'only a running batch is completed'); end if;
  if coalesce(p_fg_poly, 0) <= 0 or p_fg_poly <> trunc(p_fg_poly) then perform core.fn_raise('E_INVALID_ACTION', 'finished POLY must be a positive whole number'); end if;
  if b.kind = 'rework' and p_fg_poly > b.planned_poly then perform core.fn_raise('E_REWORK_EXCEEDS', 'output ' || p_fg_poly || ' > input ' || b.planned_poly); end if;
  if config.fn_get_bool(me.company_id, 'mfg.qc.final_required') then
    select q.result into v_last from mfg.qc_inspection q where q.batch_id = b.id and q.stage = 'final' order by q.at desc limit 1;
    if v_last is distinct from 'pass' then perform core.fn_raise('E_QC_FAILED', coalesce(v_last, 'no final inspection')); end if;
  end if;
  if exists (select 1 from mfg.batch_waste w where w.batch_id = b.id and w.status = 'pending') then perform core.fn_raise('E_INVALID_ACTION', 'decide pending waste first'); end if;
  v_yield := round(100 * p_fg_poly / b.planned_poly, 2);
  perform set_config('mohona.change_reason', p_reason, true);
  if v_yield >= config.fn_get_int(me.company_id, 'mfg.yield.min_pct') or b.kind = 'rework' then
    j := mfg.fn_post_fg(b.id, p_fg_poly, p_lot_no, p_expiry_date, false, p_reason);
    return j || jsonb_build_object('yield_pct', v_yield, 'status', 'completed');
  end if;
  update mfg.batch set status = 'completion_pending',
         pending_completion = jsonb_build_object('fg_poly', p_fg_poly, 'lot_no', p_lot_no, 'expiry_date', p_expiry_date, 'yield_pct', v_yield,
                                                 'requested_by', me.person_id, 'reason', p_reason) where id = b.id;
  return jsonb_build_object('batch_id', b.id, 'status', 'completion_pending', 'yield_pct', v_yield);
end $$;

-- Low-yield completion: approved by someone other than the requester; the exceptional part goes to the variance (ADR-11).
create function api.v1_batch_completion_decide(p_batch_id uuid, p_approve boolean, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; pc jsonb;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.batch.approve', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id for update;
  if not found or b.status <> 'completion_pending' then perform core.fn_raise('E_NOT_FOUND', 'pending completion'); end if;
  pc := b.pending_completion;
  if (pc ->> 'requested_by')::uuid = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  if not p_approve then
    update mfg.batch set status = 'in_progress', pending_completion = null where id = b.id;
    return jsonb_build_object('batch_id', b.id, 'status', 'in_progress');
  end if;
  update mfg.batch set status = 'in_progress' where id = b.id;                -- fn_post_fg completes from in_progress
  return mfg.fn_post_fg(b.id, (pc ->> 'fg_poly')::numeric, pc ->> 'lot_no', (pc ->> 'expiry_date')::date, true, p_note) || jsonb_build_object('status', 'completed');
end $$;

create function api.v1_batch_get(p_batch_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype; v_cost boolean;
begin
  select * into me from iam.fn_require('mfg.bom.read', iam.fn_my_company_resource(), false);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'batch'); end if;
  select d.allowed into v_cost from iam.fn_authorize('mfg.cost.read', iam.fn_resource(me.company_id), false) d;
  return to_jsonb(b) - 'company_id' - (case when coalesce(v_cost, false) then '' else 'fg_unit_cost' end) || jsonb_build_object(
    'wip', case when v_cost then case when b.status = 'completed' then 0 else mfg.fn_wip(b.id) end end,
    'wip_entries', case when v_cost then (select jsonb_agg(jsonb_build_object('kind', e.kind, 'amount', e.amount, 'note', e.note, 'at', e.at) order by e.id)
                                            from mfg.wip_entry e where e.batch_id = b.id) end,
    'reservations', (select jsonb_agg(jsonb_build_object('product_id', r.product_id, 'qty', r.qty, 'consumed', r.consumed_qty, 'status', r.status))
                       from inventory.reservation r where r.company_id = b.company_id and r.batch_ref = b.number),
    'qc', (select jsonb_agg(jsonb_build_object('stage', q.stage, 'result', q.result, 'at', q.at) order by q.at) from mfg.qc_inspection q where q.batch_id = b.id),
    'waste', (select jsonb_agg(jsonb_build_object('kind', w.kind, 'qty_poly', w.qty_poly, 'status', w.status, 'value', case when v_cost then w.value end)) from mfg.batch_waste w where w.batch_id = b.id));
end $$;

create function api.v1_batches(p_status text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('mfg.bom.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'number', b.number, 'kind', b.kind, 'product_id', b.product_id, 'sku', p.sku, 'name_bn', p.name_bn,
           'planned_poly', b.planned_poly, 'fg_poly', b.fg_poly, 'status', b.status, 'production_line', b.production_line, 'created_at', b.created_at) order by b.created_at desc)
     from mfg.batch b join inventory.product p on p.id = b.product_id
    where b.company_id = me.company_id and (p_status is null or b.status = p_status)), '[]'::jsonb);
end $$;

-- ================================================================ API: traceability (F110)
-- Backward: FG lot -> batch -> raw lots issued (with supplier from the GRN that received each lot) [+ rework input lot].
create function api.v1_trace_backward(p_fg_lot_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  select * into b from mfg.batch where fg_lot_id = p_fg_lot_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'batch of this lot'); end if;
  return jsonb_build_object('fg_lot_id', p_fg_lot_id, 'batch_id', b.id, 'batch', b.number, 'kind', b.kind, 'product_id', b.product_id, 'completed_at', b.completed_at,
    'rework_source', b.rework_source,
    'materials', coalesce((select jsonb_agg(jsonb_build_object('lot_id', x ->> 'lot_id', 'lot_no', l.lot_no, 'product_id', x ->> 'product_id', 'sku', p.sku, 'qty', (x ->> 'qty')::numeric,
                     'expiry_date', l.expiry_date,
                     'supplier', (select s.name_bn from inventory.receipt rc join procurement.grn_line gl on gl.receipt_id = rc.id join procurement.grn g on g.id = gl.grn_id
                                    join procurement.po po on po.id = g.po_id join procurement.supplier s on s.id = po.supplier_id where rc.lot_id = l.id limit 1)))
            from inventory.material_issue mi cross join jsonb_array_elements(mi.lines) x join inventory.lot l on l.id = (x ->> 'lot_id')::uuid join inventory.product p on p.id = l.product_id
           where mi.company_id = me.company_id and mi.batch_ref = b.number), '[]'::jsonb));
end $$;

-- Forward: raw (or returned FG) lot -> every batch that consumed it -> their FG lots.
create function api.v1_trace_forward(p_lot_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  if not exists (select 1 from inventory.lot l where l.id = p_lot_id and l.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'lot'); end if;
  return jsonb_build_object('lot_id', p_lot_id, 'batches', coalesce((select jsonb_agg(distinct jsonb_build_object('batch_id', b.id, 'batch', b.number, 'status', b.status,
           'fg_lot_id', b.fg_lot_id, 'fg_lot_no', (select l.lot_no from inventory.lot l where l.id = b.fg_lot_id), 'fg_poly', b.fg_poly))
     from mfg.batch b
    where b.company_id = me.company_id
      and (exists (select 1 from inventory.material_issue mi cross join jsonb_array_elements(mi.lines) x
                    where mi.company_id = b.company_id and mi.batch_ref = b.number and x ->> 'lot_id' = p_lot_id::text)
           or b.rework_source ->> 'lot_id' = p_lot_id::text)), '[]'::jsonb));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_bom_propose(uuid, uuid, numeric, jsonb, text)', 'api.v1_bom_decide(uuid, boolean, text)', 'api.v1_boms(uuid)',
      'api.v1_plan_save(uuid, date, uuid, jsonb, text)', 'api.v1_plan_approve(uuid, text)',
      'api.v1_batch_create(uuid, uuid, uuid, numeric, uuid, uuid, text, uuid, integer, text)', 'api.v1_rework_create(uuid, uuid, uuid, numeric, uuid, text)',
      'api.v1_batch_approve(uuid, text)', 'api.v1_batch_cost(uuid, text, numeric, text)', 'api.v1_batch_qc(uuid, text, text, jsonb, text)',
      'api.v1_batch_waste(uuid, text, numeric, text)', 'api.v1_batch_waste_decide(uuid, boolean, text)', 'api.v1_batch_complete(uuid, numeric, text, date, text)',
      'api.v1_batch_completion_decide(uuid, boolean, text)', 'api.v1_batch_get(uuid)', 'api.v1_batches(text)', 'api.v1_trace_backward(uuid)', 'api.v1_trace_forward(uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

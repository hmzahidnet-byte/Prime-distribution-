-- 20261108003300_payroll.sql  (S47–S48, final phase)
-- Payroll (PAYROLL MOS-F153-171..180):
--   171 effective-dated salary structures (grade, base, allowances, deductions)   172 eligibility: active in the month; terminated
--       employees only up to their last day   173 attendance import from POSTED events / approved leave / approved overtime only
--   174 deterministic calculation with a reproducibility hash and one rounding point (ADR-09)   175 review by another HR officer,
--       approval by MD — nobody approves own work   176 posting: balanced salary journal, lines frozen   177 payslip: own only
--       (others need the payroll right)   178 disbursement (bank / mobile / cash) with proof, never above net; reconciliation
--   179 corrections only as supplemental or reversal runs (posted runs never edited)   180 access: payroll rights are COMPANY-level,
--       granted only to HR / finance / MD by default; salary figures never enter audit text, approvals or notifications
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table hr.salary_structure (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  employee_id     uuid not null,
  effective_from  date not null,
  grade           text,
  base            numeric(14,2) not null check (base >= 0),
  allowances      jsonb not null default '[]'::jsonb,      -- [{code, name_bn, amount}]
  deductions      jsonb not null default '[]'::jsonb,      -- [{code, name_bn, amount}]
  set_by          uuid references core.person(id),
  set_at          timestamptz not null default clock_timestamp(),
  reason          text not null check (length(btrim(reason)) > 0),
  unique (employee_id, effective_from),
  foreign key (employee_id, company_id) references hr.employee (id, company_id)
);
create trigger trg_salary_structure_no_mutation before update or delete on hr.salary_structure for each row execute function core.fn_deny_mutation();
-- audit row without amounts (F180): who changed whose structure, when, why
create function hr.fn_salary_audit() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform audit.fn_append(new.company_id, 'hr.salary_structure.set', 'hr.salary_structure', new.id, 'success',
                          jsonb_build_object('employee_id', new.employee_id, 'effective_from', new.effective_from), new.reason);
  return null;
end $$;
create trigger trg_salary_structure_audit after insert on hr.salary_structure for each row execute function hr.fn_salary_audit();

create table hr.payroll_run (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  number        text,
  period        date not null check (period = date_trunc('month', period)::date),
  kind          text not null default 'regular' check (kind in ('regular','supplemental','reversal')),
  reversal_of   uuid references hr.payroll_run(id),
  status        text not null default 'calculated' check (status in ('calculated','reviewed','approved','posted','cancelled')),
  gross_total   numeric(16,2) not null default 0,
  deduction_total numeric(16,2) not null default 0,
  net_total     numeric(16,2) not null default 0,
  calc_hash     text,
  created_by    uuid not null references core.person(id),
  reviewed_by   uuid references core.person(id),
  approved_by   uuid references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  posted_at     timestamptz,
  note          text,
  unique (id, company_id),
  check (reviewed_by is null or reviewed_by <> created_by),
  check (approved_by is null or (approved_by <> created_by and approved_by is distinct from reviewed_by))
);
create unique index payroll_one_regular on hr.payroll_run (company_id, period) where kind = 'regular' and status <> 'cancelled';
create function hr.fn_payroll_run_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status = 'posted' or old.status = 'cancelled' then raise exception 'E_IMMUTABLE: a posted payroll is never edited (use a supplemental or reversal run)' using errcode = 'P0001'; end if;
  if new.status <> old.status and not ((old.status = 'calculated' and new.status in ('reviewed','cancelled')) or (old.status = 'reviewed' and new.status in ('approved','cancelled'))
                                       or (old.status = 'approved' and new.status = 'posted')) then
    raise exception 'E_INVALID_ACTION: payroll % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  if (new.gross_total <> old.gross_total or new.net_total <> old.net_total or new.calc_hash is distinct from old.calc_hash or new.period <> old.period)
     and not (old.calc_hash is null and old.status = 'calculated') then
    raise exception 'E_IMMUTABLE: payroll figures are fixed after calculation (cancel and recalculate)' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_payroll_run_guard before update on hr.payroll_run for each row execute function hr.fn_payroll_run_guard();
create trigger trg_payroll_run_nodel before delete on hr.payroll_run for each row execute function core.fn_deny_delete();
create trigger trg_payroll_run_audit after insert or update on hr.payroll_run for each row execute function audit.fn_row_change();

create table hr.payroll_line (
  id                 uuid primary key default gen_random_uuid(),
  company_id         uuid not null,
  run_id             uuid not null,
  employee_id        uuid not null,
  days_in_month      integer not null,
  days_employed      integer not null,
  absent_days        integer not null default 0,
  leave_days         integer not null default 0,
  late_deduction_days numeric(5,2) not null default 0,
  overtime_hours     numeric(6,1) not null default 0,
  earnings           jsonb not null,
  deductions         jsonb not null,
  gross              numeric(14,2) not null,
  deduction_total    numeric(14,2) not null,
  net                numeric(14,2) not null,
  calc_hash          text not null,
  unique (run_id, employee_id),
  foreign key (run_id, company_id) references hr.payroll_run (id, company_id),
  foreign key (employee_id, company_id) references hr.employee (id, company_id)
);
create trigger trg_payroll_line_no_mutation before update or delete on hr.payroll_line for each row execute function core.fn_deny_mutation();

create table hr.payroll_payment (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  run_id       uuid not null,
  employee_id  uuid not null,
  method       text not null check (method in ('bank','mobile','cash')),
  amount       numeric(14,2) not null check (amount > 0),
  reference    text,
  proof_path   text,
  paid_by      uuid not null references core.person(id),
  paid_at      timestamptz not null default clock_timestamp(),
  check (method = 'cash' or length(btrim(coalesce(reference, ''))) > 0),
  foreign key (run_id, company_id) references hr.payroll_run (id, company_id)
);
create unique index payroll_payment_ref on hr.payroll_payment (company_id, method, reference) where reference is not null;
create trigger trg_payroll_payment_no_mutation before update or delete on hr.payroll_payment for each row execute function core.fn_deny_mutation();

select core.fn_apply_rls('hr', 'salary_structure');
select core.fn_apply_rls('hr', 'payroll_run');
select core.fn_apply_rls('hr', 'payroll_line');
select core.fn_apply_rls('hr', 'payroll_payment');

update iam.permission_catalog set status = 'active'
 where code in ('hr.payroll.read','hr.payroll.calculate','hr.payroll.approve','hr.payroll.pay','hr.payslip.read_self');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'hr.payslip.read_self', 'allow', 'SELF' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN')
union all select x, y, 'allow', 'COMPANY' from (values ('HR_OFFICER','hr.payroll.read'), ('HR_OFFICER','hr.payroll.calculate'), ('MD','hr.payroll.read'), ('MD','hr.payroll.approve'),
  ('FIN_MANAGER','hr.payroll.read'), ('FIN_MANAGER','hr.payroll.pay')) v(x, y)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('hr.payroll.overtime_rate_pct', 'hr', 'int', '200', 100, 300, null, 'ওভারটাইম-হার (মূল ঘণ্টাপ্রতি বেতনের %)', 'MOS-F153-174', true, 1900),
  ('hr.payroll.hours_per_month',   'hr', 'int', '208', 160, 240, null, 'ঘণ্টাপ্রতি বেতন হিসাবের মাসিক ঘণ্টা', 'MOS-F153-174', true, 1910);
insert into finance.coa_template (code, name_bn, type, parent, postable) values
  ('2200','বেতন-দেনা','liability','2000',true), ('2210','বেতন-কর্তন দেনা','liability','2000',true), ('5700','বেতন ও ভাতা','expense','5000',true) on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values ('hr.salary_expense','5700','বেতন ও ভাতা'), ('hr.salary_payable','2200','বেতন-দেনা'),
  ('hr.deductions_payable','2210','বেতন-কর্তন দেনা') on conflict do nothing;

-- ================================================================ engine
create function hr.fn_structure_at(p_employee uuid, p_day date) returns hr.salary_structure
language sql stable security definer set search_path = pg_catalog as $$
  select s from hr.salary_structure s where s.employee_id = p_employee and s.effective_from <= p_day order by s.effective_from desc limit 1
$$;

-- One employee for one month (F172–F174). Inputs: structure at month end, posted attendance days, posted leave, posted overtime,
-- late deductions from the policy. All amounts kept exact until the single rounding of each money figure.
create function hr.fn_payroll_calc(p_company uuid, p_employee uuid, p_period date) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare s hr.salary_structure; d date; v_end date := (p_period + interval '1 month' - interval '1 day')::date; v_dim integer; v_emp_days integer := 0;
        v_absent integer := 0; v_leave integer := 0; r jsonb; v_lates integer := 0; pol hr.late_policy; v_late_days numeric := 0; v_ot numeric;
        v_daily numeric; v_hourly numeric; v_earn jsonb; v_ded jsonb; v_gross numeric; v_dedt numeric; e hr.employment; v_from date; v_to date; a jsonb;
begin
  v_dim := extract(day from v_end)::integer;
  select * into e from hr.employment x where x.employee_id = p_employee order by x.effective_from desc limit 1;
  v_from := greatest(p_period, coalesce(e.effective_from, p_period)); v_to := least(v_end, coalesce(e.effective_to, v_end));
  if e.id is null or v_to < v_from or e.status = 'suspended' then return null; end if;                       -- F172
  s := hr.fn_structure_at(p_employee, v_end);
  if s.id is null then return null; end if;
  for d in select generate_series(v_from, v_to, interval '1 day')::date loop
    v_emp_days := v_emp_days + 1;
    r := hr.fn_day_row(p_company, p_employee, d);
    if r ->> 'status' = 'absent' then v_absent := v_absent + 1; elsif r ->> 'status' = 'leave' then v_leave := v_leave + 1;
    elsif r ->> 'status' = 'late' then v_lates := v_lates + 1; end if;
  end loop;
  select * into pol from hr.late_policy p where p.company_id = p_company and p.effective_from <= v_end order by p.effective_from desc limit 1;
  if pol.id is not null then v_late_days := floor(v_lates::numeric / pol.lates_per_deduction) * pol.deduction_days; end if;
  select coalesce(sum(o.hours), 0) into v_ot from hr.overtime_request o where o.employee_id = p_employee and o.status = 'posted' and o.work_date between v_from and v_to;
  v_daily := s.base / v_dim; v_hourly := s.base / config.fn_get_int(p_company, 'hr.payroll.hours_per_month');
  v_earn := jsonb_build_array(jsonb_build_object('code', 'BASE', 'amount', round(s.base * v_emp_days / v_dim, 2)));
  for a in select * from jsonb_array_elements(s.allowances) loop
    v_earn := v_earn || jsonb_build_array(jsonb_build_object('code', a ->> 'code', 'amount', round((a ->> 'amount')::numeric * v_emp_days / v_dim, 2)));
  end loop;
  if v_ot > 0 then v_earn := v_earn || jsonb_build_array(jsonb_build_object('code', 'OT', 'amount',
                       round(v_hourly * v_ot * config.fn_get_int(p_company, 'hr.payroll.overtime_rate_pct') / 100, 2))); end if;
  v_ded := '[]'::jsonb;
  if v_absent > 0 then v_ded := v_ded || jsonb_build_array(jsonb_build_object('code', 'ABSENT', 'amount', round(v_daily * v_absent, 2))); end if;
  if v_late_days > 0 then v_ded := v_ded || jsonb_build_array(jsonb_build_object('code', 'LATE', 'amount', round(v_daily * v_late_days, 2))); end if;
  for a in select * from jsonb_array_elements(s.deductions) loop
    v_ded := v_ded || jsonb_build_array(jsonb_build_object('code', a ->> 'code', 'amount', round((a ->> 'amount')::numeric, 2)));
  end loop;
  select coalesce(sum((x ->> 'amount')::numeric), 0) into v_gross from jsonb_array_elements(v_earn) x;
  select coalesce(sum((x ->> 'amount')::numeric), 0) into v_dedt from jsonb_array_elements(v_ded) x;
  v_dedt := least(v_dedt, v_gross);                                                         -- never a negative net
  return jsonb_build_object('employee_id', p_employee, 'days_in_month', v_dim, 'days_employed', v_emp_days, 'absent_days', v_absent, 'leave_days', v_leave,
    'late_deduction_days', v_late_days, 'overtime_hours', v_ot, 'earnings', v_earn, 'deductions', v_ded, 'gross', v_gross, 'deduction_total', v_dedt,
    'net', v_gross - v_dedt, 'structure_id', s.id);
end $$;

create function hr.fn_payroll_post(p_run uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare r hr.payroll_run%rowtype;
begin
  select * into r from hr.payroll_run where id = p_run for update;
  perform finance.fn_emit(r.company_id, 'payroll:' || r.id, 'বেতন ' || to_char(r.period, 'YYYY-MM') || ' (' || r.kind || ')', jsonb_build_array(
    jsonb_build_object('key', 'hr.salary_expense', 'dr', greatest(r.gross_total, 0), 'cr', greatest(-r.gross_total, 0)),
    jsonb_build_object('key', 'hr.salary_payable', 'cr', greatest(r.net_total, 0), 'dr', greatest(-r.net_total, 0)),
    jsonb_build_object('key', 'hr.deductions_payable', 'cr', greatest(r.deduction_total, 0), 'dr', greatest(-r.deduction_total, 0))));
  update hr.payroll_run set status = 'posted', posted_at = clock_timestamp() where id = r.id;
end $$;

-- ================================================================ API
create function api.v1_salary_set(p_employee_id uuid, p_effective_from date, p_grade text, p_base numeric, p_allowances jsonb, p_deductions jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.payroll.calculate', iam.fn_my_company_resource(), true);
  if not exists (select 1 from hr.employee e where e.id = p_employee_id and e.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'employee'); end if;
  if exists (select 1 from hr.payroll_run r join hr.payroll_line l on l.run_id = r.id where l.employee_id = p_employee_id and r.status = 'posted'
              and (r.period + interval '1 month' - interval '1 day')::date >= p_effective_from) then
    perform core.fn_raise('E_PERIOD_CLOSED', 'a posted payroll already covers that date (use a supplemental run)');
  end if;
  if coalesce(p_base, -1) < 0 then perform core.fn_raise('E_INVALID_ACTION', 'base'); end if;
  insert into hr.salary_structure (company_id, employee_id, effective_from, grade, base, allowances, deductions, set_by, reason)
  values (me.company_id, p_employee_id, p_effective_from, p_grade, p_base, coalesce(p_allowances, '[]'::jsonb), coalesce(p_deductions, '[]'::jsonb), me.person_id, p_reason)
  returning id into v_id;
  return jsonb_build_object('structure_id', v_id);
end $$;

-- Calculate a regular month (F172–F174); repeating with the same inputs gives the same hash.
create function api.v1_payroll_calculate(p_period date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); e record; c jsonb; v_hashes text := ''; v_n integer := 0;
begin
  select * into me from iam.fn_require('hr.payroll.calculate', iam.fn_my_company_resource(), true);
  if p_period is null or p_period <> date_trunc('month', p_period)::date or p_period > date_trunc('month', current_date)::date then
    perform core.fn_raise('E_INVALID_ACTION', 'first day of a month that has started');
  end if;
  perform set_config('mohona.change_reason', 'payroll calculation', true);
  insert into hr.payroll_run (id, company_id, number, period, created_by) values (v_id, me.company_id, core.fn_next_number(me.company_id, 'hr.payroll', v_id), p_period, me.person_id);
  for e in select x.id from hr.employee x where x.company_id = me.company_id order by x.id loop
    c := hr.fn_payroll_calc(me.company_id, e.id, p_period);
    continue when c is null;
    insert into hr.payroll_line (company_id, run_id, employee_id, days_in_month, days_employed, absent_days, leave_days, late_deduction_days, overtime_hours,
                                 earnings, deductions, gross, deduction_total, net, calc_hash)
    values (me.company_id, v_id, e.id, (c ->> 'days_in_month')::integer, (c ->> 'days_employed')::integer, (c ->> 'absent_days')::integer, (c ->> 'leave_days')::integer,
            (c ->> 'late_deduction_days')::numeric, (c ->> 'overtime_hours')::numeric, c -> 'earnings', c -> 'deductions', (c ->> 'gross')::numeric,
            (c ->> 'deduction_total')::numeric, (c ->> 'net')::numeric, md5(c::text));
    v_hashes := v_hashes || md5(c::text); v_n := v_n + 1;
  end loop;
  -- totals are written once (calc_hash still null); the guard freezes them afterwards
  update hr.payroll_run r set gross_total = t.g, deduction_total = t.d, net_total = t.n, calc_hash = md5(v_hashes)
    from (select coalesce(sum(l.gross), 0) g, coalesce(sum(l.deduction_total), 0) d, coalesce(sum(l.net), 0) n from hr.payroll_line l where l.run_id = v_id) t where r.id = v_id;
  return jsonb_build_object('run_id', v_id, 'employees', v_n, 'calc_hash', (select r.calc_hash from hr.payroll_run r where r.id = v_id));
end $$;

-- review (another HR officer) -> approve (MD; neither creator nor reviewer) -> post (journal). F175, F176.
create function api.v1_payroll_action(p_run_id uuid, p_action text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r hr.payroll_run%rowtype;
begin
  select * into r from hr.payroll_run where id = p_run_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'payroll'); end if;
  select * into me from iam.fn_require(case p_action when 'review' then 'hr.payroll.calculate' when 'cancel' then 'hr.payroll.calculate' else 'hr.payroll.approve' end,
                                       iam.fn_my_company_resource(), true);
  if p_action in ('review','approve','post') and (me.person_id = r.created_by or (p_action <> 'review' and me.person_id = r.reviewed_by)) then
    perform core.fn_raise('E_SELF_APPROVAL', 'payroll needs different people for calculation, review and approval');
  end if;
  perform set_config('mohona.change_reason', coalesce(p_note, p_action), true);
  if p_action = 'review' and r.status = 'calculated' then update hr.payroll_run set status = 'reviewed', reviewed_by = me.person_id where id = r.id;
  elsif p_action = 'approve' and r.status = 'reviewed' then update hr.payroll_run set status = 'approved', approved_by = me.person_id where id = r.id;
  elsif p_action = 'post' and r.status = 'approved' then perform hr.fn_payroll_post(r.id);
  elsif p_action = 'cancel' and r.status in ('calculated','reviewed') then update hr.payroll_run set status = 'cancelled' where id = r.id;
  else perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || r.status);
  end if;
  return jsonb_build_object('run_id', r.id, 'status', (select x.status from hr.payroll_run x where x.id = r.id));
end $$;

-- Corrections (F179): supplemental (listed employees, explicit amounts) or full reversal of a posted run.
create function api.v1_payroll_correction(p_kind text, p_period date, p_reversal_of uuid, p_lines jsonb, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); l jsonb; o hr.payroll_run%rowtype;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.payroll.calculate', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_note, true);
  if p_kind = 'reversal' then
    select * into o from hr.payroll_run where id = p_reversal_of and company_id = me.company_id and status = 'posted';
    if not found then perform core.fn_raise('E_NOT_FOUND', 'posted payroll'); end if;
    if exists (select 1 from hr.payroll_run x where x.reversal_of = o.id and x.status <> 'cancelled') then perform core.fn_raise('E_DUPLICATE', 'already reversed'); end if;
    insert into hr.payroll_run (id, company_id, number, period, kind, reversal_of, created_by, note)
    values (v_id, me.company_id, core.fn_next_number(me.company_id, 'hr.payroll', v_id), o.period, 'reversal', o.id, me.person_id, p_note);
    insert into hr.payroll_line (company_id, run_id, employee_id, days_in_month, days_employed, earnings, deductions, gross, deduction_total, net, calc_hash)
    select me.company_id, v_id, l2.employee_id, l2.days_in_month, 0, l2.earnings, l2.deductions, -l2.gross, -l2.deduction_total, -l2.net, md5('reversal' || l2.calc_hash)
      from hr.payroll_line l2 where l2.run_id = o.id;
  elsif p_kind = 'supplemental' then
    insert into hr.payroll_run (id, company_id, number, period, kind, created_by, note)
    values (v_id, me.company_id, core.fn_next_number(me.company_id, 'hr.payroll', v_id), date_trunc('month', p_period)::date, 'supplemental', me.person_id, p_note);
    for l in select * from jsonb_array_elements(coalesce(p_lines, '[]'::jsonb)) loop
      insert into hr.payroll_line (company_id, run_id, employee_id, days_in_month, days_employed, earnings, deductions, gross, deduction_total, net, calc_hash)
      values (me.company_id, v_id, (l ->> 'employee_id')::uuid, 0, 0, jsonb_build_array(jsonb_build_object('code', 'SUPP', 'amount', (l ->> 'amount')::numeric)), '[]'::jsonb,
              round((l ->> 'amount')::numeric, 2), 0, round((l ->> 'amount')::numeric, 2), md5(l::text));
    end loop;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_kind);
  end if;
  update hr.payroll_run r set gross_total = t.g, deduction_total = t.d, net_total = t.n, calc_hash = t.h
    from (select coalesce(sum(x.gross), 0) g, coalesce(sum(x.deduction_total), 0) d, coalesce(sum(x.net), 0) n, md5(string_agg(x.calc_hash, '' order by x.employee_id)) h
            from hr.payroll_line x where x.run_id = v_id) t where r.id = v_id;
  return jsonb_build_object('run_id', v_id, 'kind', p_kind);
end $$;

-- Payslip (F177): one's own with the self right; anybody else's only with the payroll right.
create function api.v1_payslip(p_run_id uuid, p_employee_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_emp uuid; l hr.payroll_line%rowtype; r hr.payroll_run%rowtype; v_person uuid;
begin
  select * into me from iam.fn_context(false);
  v_emp := coalesce(p_employee_id, hr.fn_employee_of(me.company_id, me.person_id));
  select e.person_id into v_person from hr.employee e where e.id = v_emp and e.company_id = me.company_id;
  if v_person = me.person_id then
    perform iam.fn_require('hr.payslip.read_self', iam.fn_resource(me.company_id, null, null, null, null, me.person_id), false);
  else
    perform iam.fn_require('hr.payroll.read', iam.fn_my_company_resource(), false);
  end if;
  select * into r from hr.payroll_run where id = p_run_id and company_id = me.company_id and status = 'posted';
  select * into l from hr.payroll_line where run_id = p_run_id and employee_id = v_emp;
  if r.id is null or l.id is null then perform core.fn_raise('E_NOT_FOUND', 'posted payslip'); end if;
  return jsonb_build_object('run', r.number, 'period', r.period, 'kind', r.kind, 'employee', (select p.full_name_bn from core.person p where p.id = v_person),
    'days_employed', l.days_employed, 'absent_days', l.absent_days, 'leave_days', l.leave_days, 'overtime_hours', l.overtime_hours,
    'earnings', l.earnings, 'deductions', l.deductions, 'gross', l.gross, 'deduction_total', l.deduction_total, 'net', l.net,
    'paid', coalesce((select sum(x.amount) from hr.payroll_payment x where x.run_id = r.id and x.employee_id = v_emp), 0));
end $$;

-- Disbursement (F178): proof per payment, never above net; journal clears the payable.
create function api.v1_payroll_pay(p_run_id uuid, p_employee_id uuid, p_method text, p_amount numeric, p_reference text, p_proof_path text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; l hr.payroll_line%rowtype; v_paid numeric; v_id uuid;
begin
  select * into me from iam.fn_require('hr.payroll.pay', iam.fn_my_company_resource(), true);
  select pl.* into l from hr.payroll_line pl join hr.payroll_run r on r.id = pl.run_id
   where pl.run_id = p_run_id and pl.employee_id = p_employee_id and r.company_id = me.company_id and r.status = 'posted';
  if l.id is null then perform core.fn_raise('E_NOT_FOUND', 'posted salary line'); end if;
  perform pg_advisory_xact_lock(hashtext(p_run_id::text || p_employee_id::text));
  select coalesce(sum(x.amount), 0) into v_paid from hr.payroll_payment x where x.run_id = p_run_id and x.employee_id = p_employee_id;
  if coalesce(p_amount, 0) <= 0 or v_paid + p_amount > l.net then perform core.fn_raise('E_OVERPAYMENT', 'above the net salary'); end if;
  insert into hr.payroll_payment (company_id, run_id, employee_id, method, amount, reference, proof_path, paid_by)
  values (me.company_id, p_run_id, p_employee_id, p_method, p_amount, p_reference, p_proof_path, me.person_id) returning id into v_id;
  perform finance.fn_emit(me.company_id, 'salary_pay:' || v_id, 'বেতন পরিশোধ', jsonb_build_array(
    jsonb_build_object('key', 'hr.salary_payable', 'dr', p_amount), jsonb_build_object('key', case when p_method = 'cash' then 'fin.cash' else 'fin.bank' end, 'cr', p_amount)));
  return jsonb_build_object('payment_id', v_id, 'paid_total', v_paid + p_amount, 'net', l.net);
end $$;

create function api.v1_payroll_reconcile(p_run_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('hr.payroll.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('employee_id', l.employee_id, 'net', l.net,
           'paid', coalesce((select sum(x.amount) from hr.payroll_payment x where x.run_id = l.run_id and x.employee_id = l.employee_id), 0),
           'unpaid', l.net - coalesce((select sum(x.amount) from hr.payroll_payment x where x.run_id = l.run_id and x.employee_id = l.employee_id), 0)))
     from hr.payroll_line l join hr.payroll_run r on r.id = l.run_id where l.run_id = p_run_id and r.company_id = me.company_id), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;
do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_salary_set(uuid, date, text, numeric, jsonb, jsonb, text)', 'api.v1_payroll_calculate(date)', 'api.v1_payroll_action(uuid, text, text)',
      'api.v1_payroll_correction(text, date, uuid, jsonb, text)', 'api.v1_payslip(uuid, uuid)', 'api.v1_payroll_pay(uuid, uuid, text, numeric, text, text)',
      'api.v1_payroll_reconcile(uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

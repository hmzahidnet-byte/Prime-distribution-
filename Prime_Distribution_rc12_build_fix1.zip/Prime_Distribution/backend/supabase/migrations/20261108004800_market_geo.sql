-- 20261108004800_market_geo.sql  (ধাপ ৪খ / S67 — V161/V162 domains 03, 10, 11, 12, 13; see docs/V180_FEATURE_AUDIT_BN.md)
--   03/13 markets: a market (bazar) belongs to a territory, may carry a map boundary (polygon, versioned, validated: closed ring inside
--         Bangladesh, no self-intersection), point-in-market lookup, overlap review. Dealer <-> market assignment: request -> approval by
--         another person -> active on its effective date; transfer ends the previous holder on the same date; exclusive by default
--         (setting), expiry date, suspension, rollback; hand-over checklist; coverage report.
--   11    Bangladesh admin data below union: thana / ward / postcode / locality (versioned, source-attributed), platform import with a diff report
--   12    offline map packages: catalogue of region tile packages (version, sha256, size, licence, attribution, zoom range); the app downloads,
--         verifies the checksum, keeps a disk quota and falls back to online tiles (the map itself: osmdroid, see the Android project)
--   10    design emergency disable: the Chairman switches the company back to the built-in safe theme at once (themes stay, history stays)
-- No PostGIS (not an approved dependency): geometry is a small jsonb ring checked in PL/pgSQL. STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('crm.market.exclusive', 'crm', 'bool', 'true', null, null, null, 'একটি বাজারে একসাথে একজনই ডিলার', 'V162-03 overlap policy', false, 2610),
  ('maps.offline.quota_mb', 'maps', 'int', '512', '50', '4096', null, 'অফলাইন ম্যাপের সর্বোচ্চ জায়গা (MB)', 'V162-12', false, 2611)
on conflict (key) do nothing;
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('crm.market.manage',  'crm', 'বাজার ও বাজার-সীমানা সম্পাদনা', 'write', false, true, array['COMPANY','WING'], 'active', 2620),
  ('crm.market.approve', 'crm', 'বাজারে ডিলার-নিয়োগ অনুমোদন', 'approve', true, false, array['COMPANY','WING'], 'active', 2621);
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('SALES_MANAGER','crm.market.manage','allow','COMPANY'), ('MD','crm.market.approve','allow','COMPANY'), ('SALES_MANAGER','crm.market.approve','allow','COMPANY')
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

-- ================================================================ geometry helpers (lat, lon pairs; Bangladesh bounding box)
create function location.fn_ring_valid(p jsonb) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare n integer; i integer; j integer; a numeric[]; b numeric[]; c numeric[]; d numeric[]; d1 numeric; d2 numeric; d3 numeric; d4 numeric;
begin
  if jsonb_typeof(p) <> 'array' then return 'not a list'; end if;
  n := jsonb_array_length(p);
  if n < 3 or n > 500 then return 'needs 3–500 points'; end if;
  for i in 0 .. n - 1 loop
    if jsonb_typeof(p -> i) <> 'array' or jsonb_array_length(p -> i) <> 2 then return 'each point is [lat, lon]'; end if;
    if (p -> i ->> 0)::numeric not between 20.5 and 26.8 or (p -> i ->> 1)::numeric not between 88.0 and 92.8 then return 'point outside Bangladesh'; end if;
  end loop;
  -- no two non-adjacent edges cross (proper intersection test)
  for i in 0 .. n - 1 loop
    a := array[(p -> i ->> 0)::numeric, (p -> i ->> 1)::numeric]; b := array[(p -> ((i + 1) % n) ->> 0)::numeric, (p -> ((i + 1) % n) ->> 1)::numeric];
    for j in i + 2 .. n - 1 loop
      if i = 0 and j = n - 1 then continue; end if;
      c := array[(p -> j ->> 0)::numeric, (p -> j ->> 1)::numeric]; d := array[(p -> ((j + 1) % n) ->> 0)::numeric, (p -> ((j + 1) % n) ->> 1)::numeric];
      d1 := (d[1] - c[1]) * (a[2] - c[2]) - (d[2] - c[2]) * (a[1] - c[1]);
      d2 := (d[1] - c[1]) * (b[2] - c[2]) - (d[2] - c[2]) * (b[1] - c[1]);
      d3 := (b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1]);
      d4 := (b[1] - a[1]) * (d[2] - a[2]) - (b[2] - a[2]) * (d[1] - a[1]);
      if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)) then return 'boundary crosses itself'; end if;
    end loop;
  end loop;
  return null;
end $$;

-- ray casting; a point on the boundary counts as inside for practical use
create function location.fn_point_in_ring(p_lat numeric, p_lon numeric, p jsonb) returns boolean
language plpgsql immutable set search_path = pg_catalog as $$
declare n integer := jsonb_array_length(p); i integer; j integer; xi numeric; yi numeric; xj numeric; yj numeric; inside boolean := false;
begin
  j := n - 1;
  for i in 0 .. n - 1 loop
    yi := (p -> i ->> 0)::numeric; xi := (p -> i ->> 1)::numeric; yj := (p -> j ->> 0)::numeric; xj := (p -> j ->> 1)::numeric;
    if ((yi > p_lat) <> (yj > p_lat)) and (p_lon < (xj - xi) * (p_lat - yi) / nullif(yj - yi, 0) + xi) then inside := not inside; end if;
    j := i;
  end loop;
  return inside;
end $$;

create function location.fn_rings_overlap(p jsonb, q jsonb) returns boolean
language sql immutable set search_path = pg_catalog as $$
  select exists (select 1 from jsonb_array_elements(p) x where location.fn_point_in_ring((x ->> 0)::numeric, (x ->> 1)::numeric, q))
      or exists (select 1 from jsonb_array_elements(q) x where location.fn_point_in_ring((x ->> 0)::numeric, (x ->> 1)::numeric, p))
$$;

-- ================================================================ markets
create table sales.market (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  code            text not null check (code ~ '^[A-Z0-9_-]{2,30}$'),
  name_bn         text not null check (length(btrim(name_bn)) > 0),
  territory_id    uuid not null,
  admin_area_code text references location.admin_area(code),
  boundary        jsonb,                     -- [[lat, lon], ...] ring, null = no map boundary
  boundary_version integer not null default 0,
  status          text not null default 'active' check (status in ('active','inactive')),
  row_version     integer not null default 1,
  updated_at      timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, code),
  foreign key (territory_id, company_id) references sales.territory (id, company_id)
);
create trigger trg_market_touch before update on sales.market for each row execute function core.fn_touch_row();
create trigger trg_market_nodel before delete on sales.market for each row execute function core.fn_deny_delete();
create trigger trg_market_audit after insert or update on sales.market for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'market');

create table sales.market_boundary_version (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  market_id   uuid not null,
  version     integer not null,
  boundary    jsonb not null,
  reason      text not null,
  set_by      uuid not null references core.person(id),
  set_at      timestamptz not null default clock_timestamp(),
  unique (market_id, version),
  foreign key (market_id, company_id) references sales.market (id, company_id)
);
create trigger trg_market_boundary_version_no_mutation before update or delete on sales.market_boundary_version for each row execute function core.fn_deny_mutation();
select core.fn_apply_rls('sales', 'market_boundary_version');

create function api.v1_market_save(p_id uuid, p_code text, p_name_bn text, p_territory_id uuid, p_admin_area_code text, p_status text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('crm.market.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if not exists (select 1 from sales.territory t where t.id = p_territory_id and t.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'territory'); end if;
  if p_admin_area_code is not null and not exists (select 1 from location.admin_area a where a.code = p_admin_area_code) then perform core.fn_raise('E_NOT_FOUND', 'admin area'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.market (company_id, code, name_bn, territory_id, admin_area_code) values (me.company_id, upper(btrim(p_code)), btrim(p_name_bn), p_territory_id, p_admin_area_code)
    returning id into v_id;
  else
    update sales.market set name_bn = coalesce(nullif(btrim(p_name_bn), ''), name_bn), territory_id = p_territory_id, admin_area_code = p_admin_area_code,
           status = coalesce(p_status, status) where id = p_id and company_id = me.company_id returning id into v_id;
    if v_id is null then perform core.fn_raise('E_NOT_FOUND', 'market'); end if;
  end if;
  return jsonb_build_object('market_id', v_id);
end $$;

-- New boundary = new version (old ones kept). Overlaps with other active markets are returned for review, not silently accepted:
-- with the exclusive policy an overlap needs p_accept_overlap = true and is written into the reason trail.
create function api.v1_market_boundary_set(p_market_id uuid, p_boundary jsonb, p_accept_overlap boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; m sales.market%rowtype; v_err text; v_over jsonb;
begin
  select * into me from iam.fn_require('crm.market.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into m from sales.market where id = p_market_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'market'); end if;
  v_err := location.fn_ring_valid(p_boundary);
  if v_err is not null then perform core.fn_raise('E_INVALID_ACTION', 'boundary: ' || v_err); end if;
  v_over := coalesce((select jsonb_agg(jsonb_build_object('market_id', x.id, 'market', x.code || ' · ' || x.name_bn))
                        from sales.market x where x.company_id = me.company_id and x.id <> m.id and x.status = 'active' and x.boundary is not null
                         and location.fn_rings_overlap(p_boundary, x.boundary)), '[]'::jsonb);
  if jsonb_array_length(v_over) > 0 and not coalesce(p_accept_overlap, false) then
    return jsonb_build_object('market_id', m.id, 'saved', false, 'overlaps', v_over, 'note_bn', 'অন্য বাজারের সীমানার সাথে মিলে যায় — দেখে নিশ্চিত করে আবার পাঠান');
  end if;
  perform set_config('mohona.change_reason', p_reason || case when jsonb_array_length(v_over) > 0 then ' (overlap accepted)' else '' end, true);
  update sales.market set boundary = p_boundary, boundary_version = m.boundary_version + 1 where id = m.id;
  insert into sales.market_boundary_version (company_id, market_id, version, boundary, reason, set_by)
  values (me.company_id, m.id, m.boundary_version + 1, p_boundary, btrim(p_reason) || case when jsonb_array_length(v_over) > 0 then ' [overlap accepted]' else '' end, me.person_id);
  return jsonb_build_object('market_id', m.id, 'saved', true, 'version', m.boundary_version + 1, 'overlaps', v_over);
end $$;

create function api.v1_market_at(p_lat numeric, p_lon numeric) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('crm.dealer.read', iam.fn_my_company_resource(), false);
  if p_lat is null or p_lon is null or p_lat not between 20.5 and 26.8 or p_lon not between 88.0 and 92.8 then perform core.fn_raise('E_INVALID_ACTION', 'coordinates'); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('market_id', m.id, 'market', m.code || ' · ' || m.name_bn, 'territory_id', m.territory_id))
                     from sales.market m where m.company_id = me.company_id and m.status = 'active' and m.boundary is not null
                      and location.fn_point_in_ring(p_lat, p_lon, m.boundary)), '[]'::jsonb);
end $$;

-- ================================================================ dealer <-> market assignment
create table sales.market_assignment (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  market_id     uuid not null,
  dealer_id     uuid not null,
  valid_from    date not null,
  valid_to      date,
  status        text not null default 'requested' check (status in ('requested','rejected','approved','suspended','ended','rolled_back')),
  replaces_id   uuid references sales.market_assignment(id),
  handover      jsonb not null default '[]'::jsonb,     -- [{item, done}] e.g. retailer list, pending dues, display material
  reason        text not null check (length(btrim(reason)) > 0),
  requested_by  uuid not null references core.person(id),
  decided_by    uuid references core.person(id),
  decided_at    timestamptz,
  created_at    timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  check (valid_to is null or valid_to >= valid_from),
  check (decided_by is null or decided_by <> requested_by),
  foreign key (market_id, company_id) references sales.market (id, company_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_market_assignment_nodel before delete on sales.market_assignment for each row execute function core.fn_deny_delete();
create trigger trg_market_assignment_audit after insert or update on sales.market_assignment for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'market_assignment');

-- Who holds a market on a day (approved, inside its dates, not suspended).
create function sales.fn_market_holders(p_market uuid, p_day date) returns setof uuid
language sql stable security definer set search_path = pg_catalog as $$
  select a.dealer_id from sales.market_assignment a
   where a.market_id = p_market and a.status = 'approved' and a.valid_from <= p_day and (a.valid_to is null or a.valid_to >= p_day)
$$;

create function api.v1_market_assign_request(p_market_id uuid, p_dealer_id uuid, p_valid_from date, p_valid_to date, p_handover jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; v_prev uuid;
begin
  select * into me from iam.fn_require('crm.market.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if not exists (select 1 from sales.market m where m.id = p_market_id and m.company_id = me.company_id and m.status = 'active') then perform core.fn_raise('E_NOT_FOUND', 'active market'); end if;
  if not exists (select 1 from sales.dealer d where d.id = p_dealer_id and d.company_id = me.company_id and d.status = 'active') then perform core.fn_raise('E_NOT_FOUND', 'active dealer'); end if;
  if coalesce(p_valid_from, current_date) < current_date then perform core.fn_raise('E_INVALID_ACTION', 'a market assignment starts today or later'); end if;
  if exists (select 1 from sales.market_assignment a where a.market_id = p_market_id and a.dealer_id = p_dealer_id and a.status in ('requested','approved')
              and (a.valid_to is null or a.valid_to >= coalesce(p_valid_from, current_date))) then
    perform core.fn_raise('E_DUPLICATE', 'this dealer already holds or asked for the market');
  end if;
  select a.id into v_prev from sales.market_assignment a where a.market_id = p_market_id and a.status = 'approved'
     and (a.valid_to is null or a.valid_to >= coalesce(p_valid_from, current_date)) order by a.valid_from desc limit 1;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.market_assignment (company_id, market_id, dealer_id, valid_from, valid_to, replaces_id, handover, reason, requested_by)
  values (me.company_id, p_market_id, p_dealer_id, coalesce(p_valid_from, current_date), p_valid_to,
          case when coalesce(config.fn_get_bool(me.company_id, 'crm.market.exclusive'), true) then v_prev end, coalesce(p_handover, '[]'::jsonb), btrim(p_reason), me.person_id)
  returning id into v_id;
  return jsonb_build_object('assignment_id', v_id, 'status', 'requested', 'replaces', v_prev);
end $$;

-- Approval (another person). Exclusive policy: the previous holder ends the day before; every hand-over item must be done first.
create function api.v1_market_assign_decide(p_assignment_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a sales.market_assignment%rowtype; v_excl boolean;
begin
  select * into me from iam.fn_require('crm.market.approve', iam.fn_my_company_resource(), true);
  select * into a from sales.market_assignment where id = p_assignment_id and company_id = me.company_id for update;
  if not found or a.status <> 'requested' then perform core.fn_raise('E_NOT_FOUND', 'requested assignment'); end if;
  if a.requested_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'market assignment decided'), true);
  if not p_approve then
    update sales.market_assignment set status = 'rejected', decided_by = me.person_id, decided_at = clock_timestamp() where id = a.id;
    return jsonb_build_object('assignment_id', a.id, 'status', 'rejected');
  end if;
  if exists (select 1 from jsonb_array_elements(a.handover) h where not coalesce((h ->> 'done')::boolean, false)) then
    perform core.fn_raise('E_INVALID_ACTION', 'finish the hand-over checklist first');
  end if;
  v_excl := coalesce(config.fn_get_bool(me.company_id, 'crm.market.exclusive'), true);
  perform 1 from sales.market where id = a.market_id for update;                                 -- one decision per market at a time
  if v_excl then
    update sales.market_assignment set valid_to = a.valid_from - 1                 -- the previous holder keeps the market until the day before
     where market_id = a.market_id and status = 'approved' and id <> a.id and (valid_to is null or valid_to >= a.valid_from) and valid_from < a.valid_from;
    if exists (select 1 from sales.market_assignment x where x.market_id = a.market_id and x.status = 'approved' and x.id <> a.id
                and (x.valid_to is null or x.valid_to >= a.valid_from)) then
      perform core.fn_raise('E_CONFLICT', 'another dealer holds this market on that date');
    end if;
  end if;
  update sales.market_assignment set status = 'approved', decided_by = me.person_id, decided_at = clock_timestamp() where id = a.id;
  return jsonb_build_object('assignment_id', a.id, 'status', 'approved', 'valid_from', a.valid_from);
end $$;

create function api.v1_market_handover_tick(p_assignment_id uuid, p_item text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a sales.market_assignment%rowtype;
begin
  select * into me from iam.fn_require('crm.market.manage', iam.fn_my_company_resource(), true);
  select * into a from sales.market_assignment where id = p_assignment_id and company_id = me.company_id for update;
  if not found or a.status <> 'requested' then perform core.fn_raise('E_NOT_FOUND', 'requested assignment'); end if;
  if not exists (select 1 from jsonb_array_elements(a.handover) h where h ->> 'item' = p_item) then perform core.fn_raise('E_NOT_FOUND', 'checklist item'); end if;
  perform set_config('mohona.change_reason', 'hand-over: ' || p_item, true);
  update sales.market_assignment set handover = (select jsonb_agg(case when h ->> 'item' = p_item then h || '{"done": true}'::jsonb else h end) from jsonb_array_elements(a.handover) h)
   where id = a.id;
  return jsonb_build_object('assignment_id', a.id, 'item', p_item, 'done', true);
end $$;

-- suspend / reactivate / end / rollback (rollback: a just-approved transfer is undone and the previous holder restored)
create function api.v1_market_assign_action(p_assignment_id uuid, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a sales.market_assignment%rowtype;
begin
  select * into me from iam.fn_require('crm.market.approve', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into a from sales.market_assignment where id = p_assignment_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'suspend' and a.status = 'approved' then update sales.market_assignment set status = 'suspended' where id = a.id;
  elsif p_action = 'reactivate' and a.status = 'suspended' then update sales.market_assignment set status = 'approved' where id = a.id;
  elsif p_action = 'end' and a.status in ('approved','suspended') then
    update sales.market_assignment set status = 'ended', valid_to = greatest(a.valid_from, current_date) where id = a.id;
  elsif p_action = 'rollback' and a.status = 'approved' and a.valid_from >= current_date then
    update sales.market_assignment set status = 'rolled_back' where id = a.id;
    if a.replaces_id is not null then
      update sales.market_assignment set valid_to = null where id = a.replaces_id and status = 'approved' and valid_to = a.valid_from - 1;
    end if;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' not possible in state ' || a.status);
  end if;
  return jsonb_build_object('assignment_id', a.id, 'action', p_action);
end $$;

create function api.v1_market_coverage(p_territory_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('crm.dealer.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('market_id', m.id, 'market', m.code || ' · ' || m.name_bn, 'has_boundary', m.boundary is not null,
           'dealers', coalesce((select jsonb_agg(d.code || ' · ' || d.name_bn) from sales.dealer d where d.id in (select sales.fn_market_holders(m.id, current_date))), '[]'::jsonb),
           'pending_requests', (select count(*) from sales.market_assignment a where a.market_id = m.id and a.status = 'requested'),
           'expiring_in_30_days', exists (select 1 from sales.market_assignment a where a.market_id = m.id and a.status = 'approved'
                                           and a.valid_to between current_date and current_date + 30)) order by m.code)
     from sales.market m where m.company_id = me.company_id and m.status = 'active' and (p_territory_id is null or m.territory_id = p_territory_id)), '[]'::jsonb);
end $$;

-- ================================================================ 11 admin places below union (platform data, no company)
create table location.admin_place (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null check (kind in ('thana','ward','postcode','locality')),
  code         text not null check (code ~ '^[A-Z0-9._-]{2,40}$'),
  name_bn      text not null check (length(btrim(name_bn)) > 0),
  search_key   text not null,
  parent_code  text not null references location.admin_area(code),
  version      integer not null default 1,
  source       text not null check (length(btrim(source)) > 0),
  status       text not null default 'active' check (status in ('active','retired')),
  updated_at   timestamptz not null default clock_timestamp(),
  unique (kind, code)
);
create trigger trg_admin_place_nodel before delete on location.admin_place for each row execute function core.fn_deny_delete();
create trigger trg_admin_place_audit after insert or update on location.admin_place for each row execute function audit.fn_row_change();
select core.fn_apply_rls('location', 'admin_place');

create table location.admin_import (
  id          uuid primary key default gen_random_uuid(),
  kind        text not null,
  source      text not null,
  added       integer not null, renamed integer not null, moved integer not null, retired integer not null, unchanged integer not null,
  diff        jsonb not null,
  imported_at timestamptz not null default clock_timestamp()
);
create trigger trg_admin_import_no_mutation before update or delete on location.admin_import for each row execute function core.fn_deny_mutation();
select core.fn_apply_rls('location', 'admin_import');

-- Platform import (service role only). rows: [{code, name_bn, parent_code}]. Missing codes are retired, never deleted;
-- a rename keeps the old name as an alias so old addresses are still found.
create function svc.v1_admin_place_import(p_kind text, p_rows jsonb, p_source text, p_retire_missing boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare r jsonb; x location.admin_place%rowtype; v_add integer := 0; v_ren integer := 0; v_mov integer := 0; v_ret integer := 0; v_same integer := 0; v_diff jsonb := '[]'::jsonb;
begin
  if coalesce(p_kind, '') not in ('thana','ward','postcode','locality') or length(btrim(coalesce(p_source, ''))) = 0 or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'E_INVALID_ACTION: kind / source / rows' using errcode = 'P0001';
  end if;
  perform set_config('mohona.change_reason', 'admin import ' || p_kind || ' from ' || p_source, true);
  for r in select * from jsonb_array_elements(p_rows) loop
    if not exists (select 1 from location.admin_area a where a.code = r ->> 'parent_code') then
      v_diff := v_diff || jsonb_build_array(jsonb_build_object('code', r ->> 'code', 'problem', 'unknown parent ' || coalesce(r ->> 'parent_code', '?'))); continue;
    end if;
    select * into x from location.admin_place p where p.kind = p_kind and p.code = r ->> 'code';
    if x.id is null then
      insert into location.admin_place (kind, code, name_bn, search_key, parent_code, source) values (p_kind, r ->> 'code', btrim(r ->> 'name_bn'), lower(btrim(r ->> 'name_bn')), r ->> 'parent_code', p_source);
      v_add := v_add + 1;
    elsif x.name_bn <> btrim(r ->> 'name_bn') or x.parent_code <> r ->> 'parent_code' or x.status <> 'active' then
      if x.name_bn <> btrim(r ->> 'name_bn') then v_ren := v_ren + 1; v_diff := v_diff || jsonb_build_array(jsonb_build_object('code', x.code, 'old_name', x.name_bn, 'new_name', r ->> 'name_bn')); end if;
      if x.parent_code <> r ->> 'parent_code' then v_mov := v_mov + 1; v_diff := v_diff || jsonb_build_array(jsonb_build_object('code', x.code, 'old_parent', x.parent_code, 'new_parent', r ->> 'parent_code')); end if;
      update location.admin_place set name_bn = btrim(r ->> 'name_bn'), search_key = lower(btrim(r ->> 'name_bn')) || ' ' || x.search_key, parent_code = r ->> 'parent_code',
             version = x.version + 1, source = p_source, status = 'active', updated_at = clock_timestamp() where id = x.id;
    else
      v_same := v_same + 1;
    end if;
    x := null;
  end loop;
  if coalesce(p_retire_missing, false) then
    update location.admin_place p set status = 'retired', updated_at = clock_timestamp()
     where p.kind = p_kind and p.status = 'active' and not exists (select 1 from jsonb_array_elements(p_rows) rr where rr ->> 'code' = p.code);
    get diagnostics v_ret = row_count;
  end if;
  insert into location.admin_import (kind, source, added, renamed, moved, retired, unchanged, diff) values (p_kind, p_source, v_add, v_ren, v_mov, v_ret, v_same, v_diff);
  return jsonb_build_object('kind', p_kind, 'added', v_add, 'renamed', v_ren, 'moved', v_mov, 'retired', v_ret, 'unchanged', v_same, 'diff', v_diff);
end $$;

create function api.v1_admin_places(p_parent_code text, p_kind text, p_text text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('kind', p.kind, 'code', p.code, 'name_bn', p.name_bn, 'parent_code', p.parent_code, 'version', p.version, 'source', p.source)
                                     order by p.kind, p.name_bn)
                     from (select * from location.admin_place x where x.status = 'active' and (p_parent_code is null or x.parent_code = p_parent_code)
                            and (p_kind is null or x.kind = p_kind) and (p_text is null or x.search_key like '%' || lower(btrim(p_text)) || '%') limit 200) p), '[]'::jsonb);
end $$;

-- ================================================================ 12 offline map packages
create table location.map_package (
  id           uuid primary key default gen_random_uuid(),
  region_code  text not null references location.admin_area(code),
  name_bn      text not null,
  version      integer not null check (version >= 1),
  url          text not null check (url ~ '^https://'),
  sha256       text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  size_bytes   bigint not null check (size_bytes > 0),
  min_zoom     integer not null check (min_zoom between 0 and 20),
  max_zoom     integer not null check (max_zoom between 0 and 20),
  format       text not null default 'osmdroid-sqlite' check (format in ('osmdroid-sqlite','mbtiles')),
  licence      text not null check (length(btrim(licence)) > 0),
  attribution  text not null check (length(btrim(attribution)) > 0),
  status       text not null default 'active' check (status in ('active','retired')),
  published_at timestamptz not null default clock_timestamp(),
  unique (region_code, version),
  check (max_zoom >= min_zoom)
);
create trigger trg_map_package_nodel before delete on location.map_package for each row execute function core.fn_deny_delete();
create trigger trg_map_package_audit after insert or update on location.map_package for each row execute function audit.fn_row_change();
select core.fn_apply_rls('location', 'map_package');

create function svc.v1_map_package_publish(p_region_code text, p_name_bn text, p_url text, p_sha256 text, p_size_bytes bigint, p_min_zoom integer, p_max_zoom integer,
                                           p_format text, p_licence text, p_attribution text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v integer; v_id uuid;
begin
  perform set_config('mohona.change_reason', 'map package ' || p_region_code, true);
  v := coalesce((select max(m.version) from location.map_package m where m.region_code = p_region_code), 0) + 1;
  update location.map_package set status = 'retired' where region_code = p_region_code and status = 'active';
  insert into location.map_package (region_code, name_bn, version, url, sha256, size_bytes, min_zoom, max_zoom, format, licence, attribution)
  values (p_region_code, p_name_bn, v, p_url, lower(p_sha256), p_size_bytes, p_min_zoom, p_max_zoom, coalesce(p_format, 'osmdroid-sqlite'), p_licence, p_attribution)
  returning id into v_id;
  return jsonb_build_object('package_id', v_id, 'version', v);
end $$;

-- The catalogue + the company's disk quota for the app. Previous versions stay listed (rollback = install the older one).
create function api.v1_map_packages() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object('quota_mb', coalesce(config.fn_get_int(me.company_id, 'maps.offline.quota_mb'), 512),
    'packages', coalesce((select jsonb_agg(jsonb_build_object('package_id', m.id, 'region_code', m.region_code, 'name_bn', m.name_bn, 'version', m.version, 'url', m.url,
                                                              'sha256', m.sha256, 'size_bytes', m.size_bytes, 'min_zoom', m.min_zoom, 'max_zoom', m.max_zoom, 'format', m.format,
                                                              'licence', m.licence, 'attribution', m.attribution, 'current', m.status = 'active', 'published_at', m.published_at)
                                           order by m.region_code, m.version desc)
                            from location.map_package m), '[]'::jsonb));
end $$;

-- ================================================================ 10 design emergency disable
create function api.v1_design_emergency_disable(p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_theme uuid;
begin
  select * into me from iam.fn_context(true);
  if not coalesce(me.is_supreme, false) then perform core.fn_raise('E_CHAIRMAN_ONLY', 'only the Chairman pulls the design emergency switch'); end if;
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', 'design emergency: ' || p_reason, true);
  update design.theme set is_active = false where company_id = me.company_id and is_active returning id into v_theme;
  return jsonb_build_object('disabled_theme_id', v_theme, 'note_bn', 'অ্যাপ এখন নিরাপদ মূল নকশায়; আগের থিম আবার প্রকাশ করলেই ফিরবে।');
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_market_save(uuid, text, text, uuid, text, text, text)', 'api.v1_market_boundary_set(uuid, jsonb, boolean, text)', 'api.v1_market_at(numeric, numeric)',
      'api.v1_market_assign_request(uuid, uuid, date, date, jsonb, text)', 'api.v1_market_assign_decide(uuid, boolean, text)', 'api.v1_market_handover_tick(uuid, text)',
      'api.v1_market_assign_action(uuid, text, text)', 'api.v1_market_coverage(uuid)', 'api.v1_admin_places(text, text, text)', 'api.v1_map_packages()',
      'api.v1_design_emergency_disable(text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function svc.v1_admin_place_import(text, jsonb, text, boolean) to service_role;
    grant execute on function svc.v1_map_package_publish(text, text, text, text, bigint, integer, integer, text, text, text) to service_role;
  end if;
end $$;

-- 20261108000100_foundation.sql
-- Mohona Enterprise OS v1 baseline (step S02). Owner role, all domain schemas, privilege baseline, shared helpers.
-- Decisions: DECISION_REGISTER OWN-01 (company Chairman supreme), OWN-06 (no VAT/CCTV/AI/Group Chairman), OWN-08 (companies isolated).
-- API model: app users reach ONLY schema `api` (SECURITY DEFINER functions, empty search_path). No table is ever granted to an API role.
-- STATUS: WRITTEN, NOT EXECUTED.

create extension if not exists pgcrypto;

do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'erp_owner') then
    create role erp_owner nologin nobypassrls;
  end if;
end $$;

grant erp_owner to current_user;

create schema if not exists core    authorization erp_owner;   -- company structure, documents, sequences
create schema if not exists iam     authorization erp_owner;   -- person, login link, membership, positions, permissions
create schema if not exists config  authorization erp_owner;   -- Chairman settings registry, module lifecycle, rules, forms
create schema if not exists design  authorization erp_owner;   -- Chairman design studio, themes, layouts, KPI visuals
create schema if not exists audit   authorization erp_owner;   -- append-only hash-chained audit
create schema if not exists finance authorization erp_owner;
create schema if not exists inventory authorization erp_owner;
create schema if not exists mfg     authorization erp_owner;
create schema if not exists procurement authorization erp_owner;
create schema if not exists sales   authorization erp_owner;
create schema if not exists hr      authorization erp_owner;
create schema if not exists report  authorization erp_owner;
create schema if not exists notify  authorization erp_owner;
create schema if not exists location authorization erp_owner;
create schema if not exists hardware authorization erp_owner;
create schema if not exists api     authorization erp_owner;
create schema if not exists svc     authorization erp_owner;

revoke all on schema core, iam, config, design, audit, finance, inventory, mfg, procurement, sales, hr, report, notify, location, hardware, svc from public;
revoke all on schema api from public;

alter default privileges for role erp_owner revoke execute on functions from public;
alter default privileges for role erp_owner in schema core, iam, config, design, audit, finance, inventory, mfg, procurement, sales, hr, report, notify, location, hardware, api, svc
  revoke all on tables from public;
alter default privileges for role erp_owner in schema core, iam, config, design, audit, finance, inventory, mfg, procurement, sales, hr, report, notify, location, hardware, api, svc
  revoke all on sequences from public;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    grant usage on schema api to authenticated;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant usage on schema svc to service_role;
  end if;
end $$;

do $$ begin if exists (select 1 from pg_namespace where nspname = 'extensions') then grant usage on schema extensions to erp_owner; end if; end $$;
do $$ begin if exists (select 1 from pg_namespace where nspname = 'auth') then grant usage on schema auth to erp_owner; end if; end $$;

set role erp_owner;

-- Uniform error: message always starts with a stable code (E_*) that the Android client maps to Bengali text.
create function core.fn_raise(p_code text, p_detail text default null) returns void
language plpgsql set search_path = pg_catalog as $$
begin
  if p_code !~ '^E_[A-Z0-9_]+$' then
    raise exception 'E_INTERNAL: bad error code %', p_code using errcode = 'P0001';
  end if;
  raise exception '%', p_code || coalesce(': ' || p_detail, '') using errcode = 'P0001';
end $$;

create function core.fn_deny_mutation() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  raise exception 'E_APPEND_ONLY: % on %.% is not allowed', tg_op, tg_table_schema, tg_table_name using errcode = 'P0001';
end $$;

create function core.fn_deny_delete() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  raise exception 'E_NO_DELETE: %.% rows are never deleted; change status instead', tg_table_schema, tg_table_name using errcode = 'P0001';
end $$;

-- Maintains updated_at / row_version (optimistic concurrency for every editable master row).
create function core.fn_touch_row() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  new.updated_at  := clock_timestamp();
  new.row_version := old.row_version + 1;
  return new;
end $$;

-- Caller identity from the Supabase JWT (request.jwt.claims). NULL when absent or malformed; never raises.
create function core.fn_jwt_sub() returns uuid
language plpgsql stable set search_path = pg_catalog as $$
declare v text;
begin
  v := nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub';
  if v ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then
    return v::uuid;
  end if;
  return null;
exception when others then
  return null;
end $$;

reset role;

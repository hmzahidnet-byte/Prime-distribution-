-- 20261108001400_iam_hierarchy_sod.sql  (S15)
-- IAM remainder (blueprint IAM_PERMISSION MOS-F153-021..030) + employee structure (EMPLOYEE_HIERARCHY MOS-F153-031..040):
--   023 access preview: effective privileges of any assignment (no business records), dependency gaps, SoD conflicts
--   024 permission dependencies: a child capability needs its parent ("<module>.<entity>.read") — orphan grants and
--       orphaning revocations are refused
--   025 segregation of duties: Chairman-managed conflicting pairs (block / warn) checked on every grant + a live report
--   029 masking applied to salary/grade (hierarchy + history), export-safe; salaries never enter audit/approval payloads
--   030 permission audit: who granted / revoked / delegated what, when and why (from the immutable audit chain)
--   032 reporting chain per employee (cycles refused) · 033 hiring checklist (no login before onboarding approval)
--   034/035/036/037 promotion, transfer, suspension, reinstatement, termination: effective-dated, optionally approved,
--       history preserved (old assignment ended, new one created — never edited)
--   039 substitution: acting holder for a bounded window and a written duty (built on S09 delegation: live, revocable)
--   040 hierarchy preview: positions, holders, reporting lines; salaries masked unless authorised
--   028 multi-company: separate memberships (S05..S09) — proven by S15 tests; 021/022/026/027/031/036/037/038 completed
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ permission dependencies (F024)
create table iam.permission_dependency (
  permission_code text not null references iam.permission_catalog(code),
  requires_code   text not null references iam.permission_catalog(code),
  primary key (permission_code, requires_code),
  check (permission_code <> requires_code)
);
create trigger trg_permission_dependency_nodel before delete on iam.permission_dependency for each row execute function core.fn_deny_delete();

-- Platform vocabulary: every 3-part capability needs its entity's read right when one exists (x.y.manage -> x.y.read).
-- Two-part codes (audit.verify) are independent capabilities by design.
create function iam.fn_seed_permission_dependencies() returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare n integer;
begin
  insert into iam.permission_dependency (permission_code, requires_code)
  select c.code, r.code
    from iam.permission_catalog c
    join iam.permission_catalog r on r.code = regexp_replace(c.code, '\.[a-z_]+$', '.read')
   where c.code ~ '^[a-z_]+\.[a-z_]+\.[a-z_]+$' and c.code <> r.code
  on conflict do nothing;
  get diagnostics n = row_count;
  return n;
end $$;

-- ================================================================ segregation of duties (F025)
create table iam.sod_rule (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  permission_a  text not null references iam.permission_catalog(code),
  permission_b  text not null references iam.permission_catalog(code),
  mode          text not null default 'block' check (mode in ('block','warn')),
  status        text not null default 'active' check (status in ('active','retired')),
  reason        text not null check (length(btrim(reason)) > 0),
  created_by    uuid references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  retired_at    timestamptz,
  check (permission_a < permission_b),
  check ((status = 'retired') = (retired_at is not null))
);
create unique index sod_rule_one_active on iam.sod_rule (company_id, permission_a, permission_b) where status = 'active';
create function iam.fn_sod_rule_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','retired_at']) <> (to_jsonb(new) - array['status','retired_at']) or old.status <> 'active' or new.status <> 'retired' then
    raise exception 'E_IMMUTABLE: an SoD rule is only retired, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_sod_rule_guard before update on iam.sod_rule for each row execute function iam.fn_sod_rule_guard();
create trigger trg_sod_rule_nodel before delete on iam.sod_rule for each row execute function core.fn_deny_delete();
create trigger trg_sod_rule_audit after insert or update on iam.sod_rule for each row execute function audit.fn_row_change();

-- Default conflicting pairs (maker vs checker / payer), mode from the Chairman setting iam.sod.default_mode.
create function iam.fn_seed_sod(p_company uuid) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare n integer;
begin
  insert into iam.sod_rule (company_id, permission_a, permission_b, mode, reason)
  select p_company, least(x.a, x.b), greatest(x.a, x.b), config.fn_get_text(p_company, 'iam.sod.default_mode'), 'default (blueprint SoD)'
    from (values ('procurement.po.create','procurement.po.approve'), ('sales.order.create','sales.order.approve'),
                 ('finance.journal.create','finance.journal.post'), ('inventory.transfer.create','inventory.transfer.approve'),
                 ('inventory.count.record','inventory.adjust.approve'), ('hr.payroll.calculate','hr.payroll.approve'),
                 ('hr.payroll.approve','hr.payroll.pay')) x(a, b)
   where exists (select 1 from iam.permission_catalog c where c.code = x.a) and exists (select 1 from iam.permission_catalog c where c.code = x.b)
     and not exists (select 1 from iam.sod_rule s where s.company_id = p_company and s.permission_a = least(x.a, x.b) and s.permission_b = greatest(x.a, x.b));
  get diagnostics n = row_count;
  return n;
end $$;

create function iam.fn_company_seed_sod() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform iam.fn_seed_sod(new.id);
  return null;
end $$;

-- Does a target (position, or one assignment = its own rules + its position's rules) hold an active ALLOW of p?
create function iam.fn_target_holds(p_company uuid, p_position text, p_assignment uuid, p_permission text, p_except_rule uuid default null)
returns boolean language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from iam.position_permission_rule r
                  where r.company_id = p_company and r.position_code = p_position and r.permission_code = p_permission
                    and r.effect = 'allow' and r.status = 'active' and r.id is distinct from p_except_rule)
      or (p_assignment is not null and exists (select 1 from iam.assignment_permission_rule r
                  where r.assignment_id = p_assignment and r.permission_code = p_permission and r.effect = 'allow' and r.status = 'active'
                    and (r.valid_until is null or r.valid_until > clock_timestamp()) and r.id is distinct from p_except_rule))
$$;

-- Grant-time checks on both rule tables (template / delegation / break-glass origins are platform paths and exempt):
-- dependency (no orphan grant, no orphaning revoke) and SoD (block = refused).
create function iam.fn_rule_grant_checks() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v_row jsonb := to_jsonb(new); v_pos text; v_asg uuid; v_req text; v_child text; s record;
begin
  if (v_row ->> 'origin') in ('template','delegation','breakglass') or new.effect <> 'allow' then return new; end if;
  if tg_table_name = 'position_permission_rule' then
    v_pos := v_row ->> 'position_code'; v_asg := null;
  else
    v_asg := (v_row ->> 'assignment_id')::uuid;
    select a.position_code into v_pos from iam.position_assignment a where a.id = v_asg;
  end if;
  if exists (select 1 from iam.position_catalog pc where pc.company_id = new.company_id and pc.code = v_pos and pc.is_supreme) then return new; end if;
  if tg_op = 'INSERT' and new.status = 'active' then
    if config.fn_get_bool(new.company_id, 'iam.permission.dependency_check') then
      for v_req in select d.requires_code from iam.permission_dependency d where d.permission_code = new.permission_code loop
        if not iam.fn_target_holds(new.company_id, v_pos, v_asg, v_req) then
          raise exception 'E_PERMISSION_DEPENDENCY: % needs % first', new.permission_code, v_req using errcode = 'P0001';
        end if;
      end loop;
    end if;
    for s in select * from iam.sod_rule x where x.company_id = new.company_id and x.status = 'active' and x.mode = 'block'
                and new.permission_code in (x.permission_a, x.permission_b) loop
      if iam.fn_target_holds(new.company_id, v_pos, v_asg, case when s.permission_a = new.permission_code then s.permission_b else s.permission_a end) then
        raise exception 'E_SOD_CONFLICT: % conflicts with % (segregation of duties)', s.permission_a, s.permission_b using errcode = 'P0001';
      end if;
    end loop;
  elsif tg_op = 'UPDATE' and old.status = 'active' and new.status = 'revoked' and config.fn_get_bool(new.company_id, 'iam.permission.dependency_check') then
    if not iam.fn_target_holds(new.company_id, v_pos, v_asg, new.permission_code, new.id) then
      for v_child in select d.permission_code from iam.permission_dependency d where d.requires_code = new.permission_code loop
        if iam.fn_target_holds(new.company_id, v_pos, v_asg, v_child, new.id) then
          raise exception 'E_PERMISSION_DEPENDENCY: % still needs %; revoke it first', v_child, new.permission_code using errcode = 'P0001';
        end if;
      end loop;
    end if;
  end if;
  return new;
end $$;
create trigger trg_position_rule_checks before insert or update on iam.position_permission_rule for each row execute function iam.fn_rule_grant_checks();
create trigger trg_assignment_rule_checks before insert or update on iam.assignment_permission_rule for each row execute function iam.fn_rule_grant_checks();

-- ================================================================ settings, permissions, seeds
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('iam.sod.default_mode',              'iam', 'text', '"block"', null, null, '["block","warn"]', 'দায়িত্ব-বিভাজনের ডিফল্ট: আটকানো / সতর্ক', 'MOS-F153-025', true, 700),
  ('iam.permission.dependency_check',   'iam', 'bool', 'true', null, null, null, 'অনুমতি-নির্ভরতা যাচাই (মূল অনুমতি ছাড়া শাখা-অনুমতি নয়)', 'MOS-F153-024', true, 710),
  ('hr.onboarding.block_login',         'hr',  'bool', 'true', null, null, null, 'নিয়োগ-চেকলিস্ট অনুমোদনের আগে লগইন বন্ধ', 'MOS-F153-033', true, 720),
  ('hr.onboarding.default_tasks',       'hr',  'json',
     '[{"key":"documents","title_bn":"কাগজপত্র যাচাই","required":true},{"key":"contract","title_bn":"নিয়োগপত্র স্বাক্ষর","required":true},{"key":"orientation","title_bn":"পরিচিতি-সভা","required":false}]',
     null, null, null, 'ডিফল্ট নিয়োগ-চেকলিস্ট', 'MOS-F153-033', false, 730),
  ('hr.employment_change.requires_approval', 'hr', 'bool', 'false', null, null, null, 'পদোন্নতি/বদলি/স্থগিত/অব্যাহতিতে অনুমোদন', 'MOS-F153-034..037', true, 740),
  ('hr.substitution.max_days',          'hr',  'int', '30', 1, 365, null, 'বিকল্প-দায়িত্বের সর্বোচ্চ মেয়াদ (দিন)', 'MOS-F153-039', true, 750);

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('iam.hierarchy.read',   'iam', 'সংগঠন-কাঠামো ও রিপোর্টিং দেখা', 'read', false, true, array['COMPANY'], 'active', 90),
  ('iam.employee.change',  'iam', 'পদোন্নতি, বদলি, স্থগিত, অব্যাহতি, রিপোর্টিং-লাইন', 'admin', true, false, array['COMPANY','WING','DEPARTMENT'], 'active', 91),
  ('iam.onboarding.manage','iam', 'নিয়োগ ও নিয়োগ-চেকলিস্ট', 'admin', true, false, array['COMPANY','WING','DEPARTMENT'], 'active', 92),
  ('iam.sod.manage',       'iam', 'দায়িত্ব-বিভাজন (SoD) নিয়ম', 'admin', true, false, array['COMPANY'], 'active', 93),
  ('iam.salary.read',      'iam', 'বেতন ও গ্রেড দেখা', 'read', true, false, array['COMPANY'], 'active', 94);
select iam.fn_seed_permission_dependencies();
insert into iam.permission_dependency (permission_code, requires_code) values
  ('iam.employee.change', 'iam.hierarchy.read'), ('iam.onboarding.manage', 'iam.hierarchy.read'), ('iam.sod.manage', 'iam.permission.read'),
  ('iam.salary.read', 'iam.hierarchy.read')
on conflict do nothing;

insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('MD', 'iam.hierarchy.read', 'allow', 'COMPANY'), ('AUDITOR', 'iam.hierarchy.read', 'allow', 'COMPANY'),
  ('HR_OFFICER', 'iam.hierarchy.read', 'allow', 'COMPANY'), ('HR_OFFICER', 'iam.onboarding.manage', 'allow', 'COMPANY'),
  ('WING_HEAD', 'iam.hierarchy.read', 'allow', 'COMPANY');
select iam.fn_backfill_template_rules(null);

create trigger trg_company_seed_sod after insert on core.company for each row execute function iam.fn_company_seed_sod();
do $$ declare c record; begin for c in select id from core.company loop perform iam.fn_seed_sod(c.id); end loop; end $$;

-- ================================================================ reporting chain (F032)
create table hr.reporting_line (
  id                   uuid primary key default gen_random_uuid(),
  company_id           uuid not null,
  employee_id          uuid not null,
  manager_employee_id  uuid not null,
  status               text not null default 'active' check (status in ('active','ended')),
  valid_from           timestamptz not null default clock_timestamp(),
  ended_at             timestamptz,
  reason               text not null check (length(btrim(reason)) > 0),
  created_by           uuid references core.person(id),
  check (employee_id <> manager_employee_id),
  check ((status = 'ended') = (ended_at is not null)),
  foreign key (employee_id, company_id) references hr.employee (id, company_id),
  foreign key (manager_employee_id, company_id) references hr.employee (id, company_id)
);
create unique index reporting_line_one_active on hr.reporting_line (employee_id) where status = 'active';
create function hr.fn_reporting_line_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','ended_at']) <> (to_jsonb(new) - array['status','ended_at']) or old.status <> 'active' or new.status <> 'ended' then
    raise exception 'E_IMMUTABLE: a reporting line is only ended, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_reporting_line_guard before update on hr.reporting_line for each row execute function hr.fn_reporting_line_guard();
create trigger trg_reporting_line_nodel before delete on hr.reporting_line for each row execute function core.fn_deny_delete();
create trigger trg_reporting_line_audit after insert or update on hr.reporting_line for each row execute function audit.fn_row_change();

-- True when p_manager reports (directly or indirectly) to p_employee — making p_manager the boss would close a cycle.
create function hr.fn_reports_to(p_manager uuid, p_employee uuid) returns boolean
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v_cur uuid := p_manager; v_depth integer := 0;
begin
  while v_cur is not null and v_depth <= 64 loop
    if v_cur = p_employee then return true; end if;
    select r.manager_employee_id into v_cur from hr.reporting_line r where r.employee_id = v_cur and r.status = 'active';
    if not found then v_cur := null; end if;
    v_depth := v_depth + 1;
  end loop;
  return v_depth > 64;
end $$;

-- ================================================================ hiring checklist (F033)
create table hr.onboarding_template (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  position_code  text,
  tasks          jsonb not null check (jsonb_typeof(tasks) = 'array' and jsonb_array_length(tasks) between 1 and 50),
  version        integer not null check (version >= 1),
  status         text not null default 'active' check (status in ('active','superseded')),
  reason         text not null check (length(btrim(reason)) > 0),
  set_by         uuid references core.person(id),
  set_at         timestamptz not null default clock_timestamp(),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index onboarding_template_one_active on hr.onboarding_template (company_id, position_code) nulls not distinct where status = 'active';
create trigger trg_onboarding_template_guard before update on hr.onboarding_template for each row execute function config.fn_history_only_supersede();
create trigger trg_onboarding_template_nodel before delete on hr.onboarding_template for each row execute function core.fn_deny_delete();
create trigger trg_onboarding_template_audit after insert or update on hr.onboarding_template for each row execute function audit.fn_row_change();

create table hr.onboarding (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  membership_id  uuid not null,
  assignment_id  uuid,
  position_code  text not null,
  tasks          jsonb not null check (jsonb_typeof(tasks) = 'array'),
  status         text not null default 'open' check (status in ('open','approved','cancelled')),
  blocks_login   boolean not null,
  created_by     uuid references core.person(id),
  created_at     timestamptz not null default clock_timestamp(),
  approved_by    uuid references core.person(id),
  approved_at    timestamptz,
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1,
  unique (id, company_id),
  check ((status = 'approved') = (approved_at is not null)),
  foreign key (membership_id, company_id) references iam.company_membership (id, company_id),
  foreign key (assignment_id, company_id) references iam.position_assignment (id, company_id)
);
create unique index onboarding_one_open on hr.onboarding (membership_id) where status = 'open';
create function hr.fn_onboarding_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.company_id <> old.company_id or new.membership_id <> old.membership_id or new.position_code <> old.position_code
     or new.blocks_login <> old.blocks_login or old.status <> 'open' then
    raise exception 'E_IMMUTABLE: onboarding identity is fixed; a closed checklist never changes' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_onboarding_guard before update on hr.onboarding for each row execute function hr.fn_onboarding_guard();
create trigger trg_onboarding_touch before update on hr.onboarding for each row execute function core.fn_touch_row();
create trigger trg_onboarding_nodel before delete on hr.onboarding for each row execute function core.fn_deny_delete();
create trigger trg_onboarding_audit after insert or update on hr.onboarding for each row execute function audit.fn_row_change();

-- An assignment is usable only when the person's onboarding (if any, and blocking) is approved: no login before approval.
create or replace function iam.fn_assignment_usable(p_person uuid, p_assignment uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (
    select 1
      from iam.position_assignment a
      join iam.company_membership m on m.id = a.membership_id and m.company_id = a.company_id
      join core.company c on c.id = a.company_id
      join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
     where a.id = p_assignment and m.person_id = p_person
       and c.status = 'active' and m.status = 'active' and a.status = 'active' and pc.is_enabled
       and a.valid_from <= clock_timestamp() and (a.valid_until is null or a.valid_until > clock_timestamp())
       and not exists (select 1 from hr.onboarding o where o.membership_id = m.id and o.status = 'open' and o.blocks_login))
$$;

-- ================================================================ employment changes (F034..F037)
create table hr.employment_change (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  membership_id       uuid not null,
  assignment_id       uuid not null,
  kind                text not null check (kind in ('promotion','transfer','suspension','reinstatement','termination')),
  to_position_code    text,
  to_wing_id          uuid,
  to_department_id    uuid,
  to_location_id      uuid,
  grade               text check (grade is null or grade ~ '^[A-Za-z0-9 _./-]{1,20}$'),
  salary              numeric(14,2) check (salary is null or salary >= 0),
  effective_on        date not null,
  status              text not null default 'scheduled' check (status in ('pending_approval','scheduled','applied','cancelled','rejected')),
  reason              text not null check (length(btrim(reason)) > 0),
  created_by          uuid references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  applied_at          timestamptz,
  new_assignment_id   uuid,
  approval_request_id uuid,
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id),
  check ((status = 'applied') = (applied_at is not null)),
  foreign key (membership_id, company_id) references iam.company_membership (id, company_id),
  foreign key (assignment_id, company_id) references iam.position_assignment (id, company_id),
  foreign key (new_assignment_id, company_id) references iam.position_assignment (id, company_id),
  foreign key (company_id, to_position_code) references iam.position_catalog (company_id, code),
  foreign key (to_wing_id, company_id) references core.wing (id, company_id),
  foreign key (to_department_id, company_id) references core.department (id, company_id),
  foreign key (to_location_id, company_id) references core.location (id, company_id)
);
create index employment_change_due on hr.employment_change (effective_on) where status = 'scheduled';
create function hr.fn_employment_change_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','applied_at','new_assignment_id','approval_request_id','updated_at','row_version'])
     <> (to_jsonb(new) - array['status','applied_at','new_assignment_id','approval_request_id','updated_at','row_version']) then
    raise exception 'E_IMMUTABLE: an employment change is never edited; cancel it and create a new one' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'pending_approval' and new.status in ('scheduled','applied','cancelled','rejected'))
                                       or (old.status = 'scheduled' and new.status in ('applied','cancelled'))
                                       -- the submit step right after creation: a new change goes to approval once
                                       or (old.status = 'scheduled' and new.status = 'pending_approval' and old.approval_request_id is null
                                           and new.approval_request_id is not null and old.applied_at is null)) then
    raise exception 'E_INVALID_ACTION: change % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_employment_change_guard before update on hr.employment_change for each row execute function hr.fn_employment_change_guard();
create trigger trg_employment_change_touch before update on hr.employment_change for each row execute function core.fn_touch_row();
create trigger trg_employment_change_nodel before delete on hr.employment_change for each row execute function core.fn_deny_delete();

-- Redacted audit: salary is never copied into audit.event (only whether it changed).
create function hr.fn_employment_change_audit() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform audit.fn_append(new.company_id, 'hr.employment_change.' || lower(tg_op), 'hr.employment_change', new.id, 'success',
                          jsonb_build_object('kind', new.kind, 'membership_id', new.membership_id, 'assignment_id', new.assignment_id,
                                             'to_position_code', new.to_position_code, 'to_wing_id', new.to_wing_id, 'to_department_id', new.to_department_id,
                                             'to_location_id', new.to_location_id, 'grade_set', new.grade is not null, 'salary_set', new.salary is not null,
                                             'effective_on', new.effective_on, 'status', new.status, 'new_assignment_id', new.new_assignment_id),
                          new.reason);
  return null;
end $$;
create trigger trg_employment_change_audit after insert or update on hr.employment_change for each row execute function hr.fn_employment_change_audit();

-- ================================================================ substitution (F039)
create table hr.substitution (
  id                     uuid primary key default gen_random_uuid(),
  company_id             uuid not null,
  delegation_id          uuid not null,
  absent_assignment      uuid not null,
  substitute_assignment  uuid not null,
  duty_bn                text not null check (length(btrim(duty_bn)) between 3 and 500),
  valid_from             timestamptz not null,
  valid_until            timestamptz not null,
  created_by             uuid references core.person(id),
  created_at             timestamptz not null default clock_timestamp(),
  unique (delegation_id),
  check (valid_until > valid_from),
  foreign key (delegation_id, company_id) references iam.delegation (id, company_id),
  foreign key (absent_assignment, company_id) references iam.position_assignment (id, company_id),
  foreign key (substitute_assignment, company_id) references iam.position_assignment (id, company_id)
);
create trigger trg_substitution_no_mutation before update or delete on hr.substitution for each row execute function core.fn_deny_mutation();
create trigger trg_substitution_audit after insert on hr.substitution for each row execute function audit.fn_row_change();

select core.fn_apply_rls('iam', 'permission_dependency');
select core.fn_apply_rls('iam', 'sod_rule');
select core.fn_apply_rls('hr', 'reporting_line');
select core.fn_apply_rls('hr', 'onboarding_template');
select core.fn_apply_rls('hr', 'onboarding');
select core.fn_apply_rls('hr', 'employment_change');
select core.fn_apply_rls('hr', 'substitution');

-- ================================================================ change engine
-- Applies one change. History is preserved: the old assignment is ENDED and a new one created (promotion / transfer);
-- employment status moves for suspension / reinstatement; termination ends the membership (cascade: assignments end,
-- sessions revoked, employment terminated — S06/S09/S10 triggers).
create function hr.fn_apply_employment_change(p_change uuid) returns uuid
language plpgsql security definer set search_path = pg_catalog as $$
declare c hr.employment_change%rowtype; a iam.position_assignment%rowtype; v_new uuid; v_keep boolean;
begin
  select * into c from hr.employment_change where id = p_change for update;
  if c.status not in ('scheduled','pending_approval') then raise exception 'E_INVALID_ACTION: change is %', c.status using errcode = 'P0001'; end if;
  select * into a from iam.position_assignment where id = c.assignment_id and company_id = c.company_id for update;
  perform set_config('mohona.change_reason', c.kind || ': ' || c.reason, true);
  if c.kind in ('promotion','transfer') then
    if a.status = 'ended' then raise exception 'E_ASSIGNMENT_ENDED: the assignment ended before the change took effect' using errcode = 'P0001'; end if;
    v_keep := c.to_wing_id is null and c.to_department_id is null and c.to_location_id is null;
    if c.to_position_code is not null and c.to_position_code <> a.position_code or not v_keep then
      update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = c.kind || ': ' || c.reason where id = a.id;
      insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind, home_wing_id, home_department_id, home_location_id)
      values (a.company_id, a.membership_id, coalesce(c.to_position_code, a.position_code), 'regular',
              case when v_keep then a.home_wing_id else c.to_wing_id end,
              case when v_keep then a.home_department_id else c.to_department_id end,
              case when v_keep then a.home_location_id else c.to_location_id end)
      returning id into v_new;
    end if;                                                   -- otherwise: grade / salary change only
  elsif c.kind = 'suspension' then
    update hr.employment em set status = 'suspended', reason = c.reason
     where em.status = 'active' and em.employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id);
    if not found then raise exception 'E_INVALID_ACTION: employment is not active' using errcode = 'P0001'; end if;
  elsif c.kind = 'reinstatement' then
    update hr.employment em set status = 'active', reason = c.reason
     where em.status = 'suspended' and em.employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id);
    if not found then raise exception 'E_INVALID_ACTION: employment is not suspended' using errcode = 'P0001'; end if;
  else
    update iam.company_membership set status = 'ended', ended_on = greatest(c.effective_on, started_on), end_reason = c.reason
     where id = c.membership_id and status <> 'ended';
    update hr.reporting_line set status = 'ended', ended_at = clock_timestamp()
     where company_id = c.company_id and status = 'active'
       and (employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id)
            or manager_employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id));
  end if;
  update hr.employment_change set status = 'applied', applied_at = clock_timestamp(), new_assignment_id = v_new where id = c.id;
  return v_new;
end $$;

-- Approved change: apply now when due, else wait for the scheduler.
create function hr.fn_employment_change_approved(p_change uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare c hr.employment_change%rowtype;
begin
  select * into c from hr.employment_change where id = p_change;
  if c.status <> 'pending_approval' then return; end if;
  if c.effective_on <= current_date then perform hr.fn_apply_employment_change(c.id);
  else update hr.employment_change set status = 'scheduled' where id = c.id;
  end if;
end $$;

-- Generic approval handlers: S13 + S14 cases + S15 employment change.
create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- Scheduler entry (platform cron): applies every due scheduled change. Failures are isolated per change.
create function svc.v1_hr_apply_due_changes() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare c record; ok integer := 0; failed jsonb := '[]'::jsonb;
begin
  perform set_config('mohona.company_scope', '', true);
  for c in select x.id from hr.employment_change x where x.status = 'scheduled' and x.effective_on <= current_date order by x.effective_on, x.created_at loop
    begin
      perform hr.fn_apply_employment_change(c.id);
      ok := ok + 1;
    exception when others then
      failed := failed || jsonb_build_array(jsonb_build_object('change_id', c.id, 'error', left(sqlerrm, 200)));
    end;
  end loop;
  return jsonb_build_object('applied', ok, 'failed', failed);
end $$;

-- Current grade / salary of a membership (latest applied change that set them).
create function hr.fn_current_pay(p_membership uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog as $$
  select jsonb_build_object(
    'grade', (select c.grade from hr.employment_change c where c.membership_id = p_membership and c.status = 'applied' and c.grade is not null
               order by c.applied_at desc limit 1),
    'salary', (select c.salary from hr.employment_change c where c.membership_id = p_membership and c.status = 'applied' and c.salary is not null
               order by c.applied_at desc limit 1))
$$;

-- Salary as this reader may see it: supreme or iam.salary.read -> generic mask policy (hr.employment.salary) applies;
-- otherwise always fully masked. Export callers pass p_export.
create function hr.fn_salary_view(p_salary numeric, p_can_read boolean, p_export boolean default false) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog as $$
begin
  if p_salary is null then return null; end if;
  if not p_can_read then return to_jsonb('••••••'::text); end if;
  return config.fn_mask_apply('hr.employment.salary', to_jsonb(p_salary), p_export);
end $$;

-- ================================================================ API: access preview, SoD, dependencies, audit (F023..F030)
create function api.v1_iam_access_preview(p_assignment_id uuid, p_wing_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; a iam.position_assignment%rowtype; v_person uuid; v_res iam.resource; v_supreme boolean; d record; p record; s record;
        perms jsonb := '[]'::jsonb; allowed text[] := array[]::text[]; gaps jsonb := '[]'::jsonb; conflicts jsonb := '[]'::jsonb;
begin
  select * into me from iam.fn_require('iam.permission.read', iam.fn_my_company_resource(), false);
  select * into a from iam.position_assignment where id = p_assignment_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  select m.person_id into v_person from iam.company_membership m where m.id = a.membership_id;
  if not me.is_supreme and v_person <> me.person_id and iam.fn_rank_of(me.company_id, a.position_code) >= iam.fn_rank_of(me.company_id, me.position_code) then
    perform core.fn_raise('E_RANK_TOO_HIGH', a.position_code);
  end if;
  if p_wing_id is not null and not exists (select 1 from core.wing w where w.id = p_wing_id and w.company_id = me.company_id) then
    perform core.fn_raise('E_WRONG_COMPANY', 'wing');
  end if;
  select pc.is_supreme into v_supreme from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = a.position_code;
  v_res := iam.fn_resource(me.company_id, coalesce(p_wing_id, a.home_wing_id), case when p_wing_id is null then a.home_department_id end,
                           case when p_wing_id is null then a.home_location_id end, null, v_person);
  for p in select * from iam.permission_catalog c where c.status = 'active' order by c.module, c.sort_order loop
    select * into d from iam.fn_decide(me.company_id, a.id, a.position_code, coalesce(v_supreme, false), v_person,
                                       a.home_wing_id, a.home_department_id, a.home_location_id, p.code, v_res, true);
    continue when not d.allowed;
    allowed := allowed || p.code;
    perms := perms || jsonb_build_array(jsonb_build_object('code', p.code, 'module', p.module, 'name_bn', p.name_bn, 'action_kind', p.action_kind,
                                                           'is_sensitive', p.is_sensitive, 'via', d.reason));
  end loop;
  for p in select x.permission_code, x.requires_code from iam.permission_dependency x
            where x.permission_code = any (allowed) and not (x.requires_code = any (allowed)) loop
    gaps := gaps || jsonb_build_array(jsonb_build_object('permission', p.permission_code, 'requires', p.requires_code));
  end loop;
  for s in select * from iam.sod_rule x where x.company_id = me.company_id and x.status = 'active'
              and x.permission_a = any (allowed) and x.permission_b = any (allowed) loop
    conflicts := conflicts || jsonb_build_array(jsonb_build_object('permission_a', s.permission_a, 'permission_b', s.permission_b, 'mode', s.mode));
  end loop;
  return jsonb_build_object('assignment_id', a.id, 'position_code', a.position_code, 'person_id', v_person, 'wing_id', (v_res).wing_id,
                            'is_supreme', coalesce(v_supreme, false), 'permissions', perms, 'dependency_gaps', gaps, 'sod_conflicts', conflicts);
end $$;

create function api.v1_iam_sod_rules() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.permission.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'permission_a', s.permission_a, 'permission_b', s.permission_b, 'mode', s.mode,
                                                       'reason', s.reason, 'created_at', s.created_at) order by s.permission_a, s.permission_b)
                     from iam.sod_rule s where s.company_id = me.company_id and s.status = 'active'), '[]'::jsonb);
end $$;

-- Sets (or with p_mode 'off' retires) the rule for a pair. Existing holders of both are not stripped: see the report.
create function api.v1_iam_sod_set(p_permission_a text, p_permission_b text, p_mode text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_a text := least(p_permission_a, p_permission_b); v_b text := greatest(p_permission_a, p_permission_b); v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.sod.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_mode, '') not in ('block','warn','off') or v_a = v_b then perform core.fn_raise('E_INVALID_ACTION', 'mode / pair'); end if;
  if (select count(*) from iam.permission_catalog c where c.code in (v_a, v_b)) <> 2 then perform core.fn_raise('E_NOT_FOUND', 'permission'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.sod_rule set status = 'retired', retired_at = clock_timestamp()
   where company_id = me.company_id and permission_a = v_a and permission_b = v_b and status = 'active';
  if p_mode <> 'off' then
    insert into iam.sod_rule (company_id, permission_a, permission_b, mode, reason, created_by)
    values (me.company_id, v_a, v_b, p_mode, p_reason, me.person_id) returning id into v_id;
  end if;
  return jsonb_build_object('rule_id', v_id, 'permission_a', v_a, 'permission_b', v_b, 'mode', p_mode);
end $$;

-- Live report: every active assignment that currently holds both sides of an active SoD pair (company-wide check).
create function api.v1_iam_sod_report() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; s record; x record; out jsonb := '[]'::jsonb; da boolean; db boolean;
begin
  select * into me from iam.fn_require('iam.permission.read', iam.fn_my_company_resource(), false);
  for s in select * from iam.sod_rule r where r.company_id = me.company_id and r.status = 'active' loop
    for x in select a.*, m.person_id, pc.is_supreme from iam.position_assignment a
               join iam.company_membership m on m.id = a.membership_id
               join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
              where a.company_id = me.company_id and a.status = 'active' and not pc.is_supreme loop
      select d.allowed into da from iam.fn_decide(me.company_id, x.id, x.position_code, false, x.person_id, x.home_wing_id, x.home_department_id,
                                                  x.home_location_id, s.permission_a, iam.fn_resource(me.company_id, x.home_wing_id), true) d;
      continue when not da;
      select d.allowed into db from iam.fn_decide(me.company_id, x.id, x.position_code, false, x.person_id, x.home_wing_id, x.home_department_id,
                                                  x.home_location_id, s.permission_b, iam.fn_resource(me.company_id, x.home_wing_id), true) d;
      continue when not db;
      out := out || jsonb_build_array(jsonb_build_object('assignment_id', x.id, 'person_id', x.person_id, 'position_code', x.position_code,
                                                         'permission_a', s.permission_a, 'permission_b', s.permission_b, 'mode', s.mode));
    end loop;
  end loop;
  return out;
end $$;

create function api.v1_iam_permission_dependencies() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.permission.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('permission', d.permission_code, 'requires', d.requires_code) order by d.permission_code)
                     from iam.permission_dependency d), '[]'::jsonb);
end $$;

-- Who granted / revoked / delegated / assigned what, when, why — from the hash-chained audit log (F030).
create function api.v1_iam_permission_audit(p_since timestamptz default null, p_limit integer default 200) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(x order by (x ->> 'seq')::bigint desc) from (
    select jsonb_build_object('seq', e.seq, 'at', e.occurred_at, 'action', e.action, 'table', e.entity_table, 'entity_id', e.entity_id,
             'actor_person_id', e.actor_person_id, 'actor_name_bn', (select p.full_name_bn from core.person p where p.id = e.actor_person_id),
             'reason', e.reason, 'outcome', e.outcome,
             'permission_code', coalesce(e.detail -> 'new' ->> 'permission_code', e.detail -> 'new' ->> 'permission_a'),
             'effect', e.detail -> 'new' ->> 'effect', 'position_code', e.detail -> 'new' ->> 'position_code',
             'assignment_id', coalesce(e.detail -> 'new' ->> 'assignment_id', e.detail -> 'new' ->> 'delegate_assignment'),
             'status_from', e.detail -> 'old' ->> 'status', 'status_to', e.detail -> 'new' ->> 'status',
             'permissions', e.detail -> 'new' -> 'permission_codes') x
      from audit.event e
     where e.company_id = me.company_id
       and e.entity_table in ('iam.position_permission_rule','iam.assignment_permission_rule','iam.delegation','iam.position_assignment',
                              'iam.sod_rule','iam.breakglass_grant','iam.company_membership')
       and (p_since is null or e.occurred_at >= p_since)
     order by e.seq desc
     limit greatest(1, least(coalesce(p_limit, 200), 2000))) q), '[]'::jsonb);
end $$;

-- ================================================================ API: employee structure (F031..F040)
-- Reporting line: sets (or clears with null) an employee's manager. Cycles refused.
create function api.v1_hr_set_manager(p_employee_id uuid, p_manager_employee_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_line uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.employee.change', iam.fn_my_company_resource(), true);
  if not exists (select 1 from hr.employee e where e.id = p_employee_id and e.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'employee'); end if;
  if p_manager_employee_id is not null then
    if not exists (select 1 from hr.employee e where e.id = p_manager_employee_id and e.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'manager'); end if;
    if p_manager_employee_id = p_employee_id or hr.fn_reports_to(p_manager_employee_id, p_employee_id) then
      perform core.fn_raise('E_REPORTING_CYCLE');
    end if;
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update hr.reporting_line set status = 'ended', ended_at = clock_timestamp() where employee_id = p_employee_id and status = 'active';
  if p_manager_employee_id is not null then
    insert into hr.reporting_line (company_id, employee_id, manager_employee_id, reason, created_by)
    values (me.company_id, p_employee_id, p_manager_employee_id, p_reason, me.person_id) returning id into v_line;
  end if;
  return jsonb_build_object('reporting_line_id', v_line, 'employee_id', p_employee_id, 'manager_employee_id', p_manager_employee_id);
end $$;

-- Organisation tree: positions (reporting codes), holders, managers, grade, salary (masked unless authorised).
create function api.v1_hr_org_tree() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_can_salary boolean;
begin
  select * into me from iam.fn_require('iam.hierarchy.read', iam.fn_my_company_resource(), false);
  select d.allowed into v_can_salary from iam.fn_authorize('iam.salary.read', iam.fn_resource(me.company_id), false) d;
  return coalesce((select jsonb_agg(jsonb_build_object('code', pc.code, 'name_bn', pc.name_bn, 'rank', pc.rank, 'reports_to_code', pc.reports_to_code,
           'is_supreme', pc.is_supreme, 'is_enabled', pc.is_enabled,
           'holders', coalesce((select jsonb_agg(jsonb_build_object('assignment_id', a.id, 'assignment_kind', a.assignment_kind, 'status', a.status,
                                  'person_id', m.person_id, 'name_bn', p.full_name_bn, 'membership_id', m.id, 'employee_id', e.id,
                                  'home_wing_id', a.home_wing_id, 'home_department_id', a.home_department_id, 'home_location_id', a.home_location_id,
                                  'manager_employee_id', (select r.manager_employee_id from hr.reporting_line r where r.employee_id = e.id and r.status = 'active'),
                                  'employment_status', (select em.status from hr.employment em where em.employee_id = e.id and em.status <> 'terminated' limit 1),
                                  'grade', case when me.is_supreme or v_can_salary then hr.fn_current_pay(m.id) -> 'grade' end,
                                  'salary', hr.fn_salary_view((hr.fn_current_pay(m.id) ->> 'salary')::numeric, me.is_supreme or v_can_salary),
                                  'onboarding_open', exists (select 1 from hr.onboarding o where o.membership_id = m.id and o.status = 'open'))
                                  order by p.full_name_bn)
                                from iam.position_assignment a
                                join iam.company_membership m on m.id = a.membership_id
                                join core.person p on p.id = m.person_id
                                left join hr.employee e on e.membership_id = m.id
                               where a.company_id = me.company_id and a.position_code = pc.code and a.status <> 'ended'), '[]'::jsonb))
           order by pc.rank desc, pc.code)
     from iam.position_catalog pc where pc.company_id = me.company_id), '[]'::jsonb);
end $$;

-- Employment history of one member: every assignment (ended ones too) and every change; salary masked as above.
create function api.v1_hr_employment_history(p_membership_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_can_salary boolean; v_person uuid;
begin
  select * into me from iam.fn_require('iam.hierarchy.read', iam.fn_my_company_resource(), false);
  select m.person_id into v_person from iam.company_membership m where m.id = p_membership_id and m.company_id = me.company_id;
  if v_person is null then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
  select d.allowed into v_can_salary from iam.fn_authorize('iam.salary.read', iam.fn_resource(me.company_id), false) d;
  v_can_salary := me.is_supreme or v_can_salary or v_person = me.person_id;          -- everyone sees their own pay
  return jsonb_build_object('membership_id', p_membership_id, 'person_id', v_person,
    'assignments', coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'position_code', a.position_code, 'kind', a.assignment_kind, 'status', a.status,
                                 'valid_from', a.valid_from, 'ended_at', a.ended_at, 'end_reason', a.end_reason, 'home_wing_id', a.home_wing_id,
                                 'home_department_id', a.home_department_id) order by a.valid_from)
                               from iam.position_assignment a where a.membership_id = p_membership_id and a.company_id = me.company_id), '[]'::jsonb),
    'changes', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'kind', c.kind, 'status', c.status, 'effective_on', c.effective_on,
                             'to_position_code', c.to_position_code, 'to_wing_id', c.to_wing_id, 'to_department_id', c.to_department_id,
                             'grade', case when v_can_salary then c.grade end, 'salary', hr.fn_salary_view(c.salary, v_can_salary),
                             'reason', c.reason, 'applied_at', c.applied_at, 'new_assignment_id', c.new_assignment_id, 'row_version', c.row_version)
                             order by c.created_at)
                           from hr.employment_change c where c.membership_id = p_membership_id and c.company_id = me.company_id), '[]'::jsonb));
end $$;

-- promotion | transfer | suspension | reinstatement | termination — effective-dated; optional approval (Chairman setting).
create function api.v1_hr_employment_change(p_kind text, p_assignment_id uuid, p_to_position_code text, p_to_wing_id uuid, p_to_department_id uuid,
                                            p_to_location_id uuid, p_grade text, p_salary numeric, p_effective_on date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a iam.position_assignment%rowtype; v_person uuid; v_id uuid; v_new uuid; j jsonb; v_status text; v_can_salary boolean;
        v_eff date := coalesce(p_effective_on, current_date);
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if coalesce(p_kind, '') not in ('promotion','transfer','suspension','reinstatement','termination') then perform core.fn_raise('E_INVALID_ACTION', p_kind); end if;
  select * into a from iam.position_assignment where id = p_assignment_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  if a.status = 'ended' then perform core.fn_raise('E_ASSIGNMENT_ENDED'); end if;
  select * into me from iam.fn_require('iam.employee.change', iam.fn_resource(a.company_id, a.home_wing_id, a.home_department_id, a.home_location_id), true);
  select m.person_id into v_person from iam.company_membership m where m.id = a.membership_id for no key update;
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, a.position_code, v_person);
  if p_kind = 'promotion' then
    if p_to_position_code is not null then
      perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, p_to_position_code, v_person);
    elsif p_grade is null and p_salary is null and p_to_wing_id is null and p_to_department_id is null and p_to_location_id is null then
      perform core.fn_raise('E_INVALID_ACTION', 'promotion needs a new position, grade or salary');
    end if;
  elsif p_kind = 'transfer' then
    if p_to_wing_id is null and p_to_department_id is null and p_to_location_id is null then perform core.fn_raise('E_INVALID_ACTION', 'transfer needs a unit'); end if;
    if p_to_position_code is not null then perform core.fn_raise('E_INVALID_ACTION', 'a transfer keeps the position; use promotion'); end if;
    -- the manager must also be allowed to manage the destination unit
    perform iam.fn_require('iam.employee.change', iam.fn_resource(me.company_id, p_to_wing_id, p_to_department_id, p_to_location_id), false);
  elsif p_to_position_code is not null or p_to_wing_id is not null or p_to_department_id is not null or p_to_location_id is not null then
    perform core.fn_raise('E_INVALID_ACTION', p_kind || ' changes no position or unit');
  end if;
  if p_salary is not null or p_grade is not null then
    select d.allowed into v_can_salary from iam.fn_authorize('iam.salary.read', iam.fn_resource(me.company_id), false) d;
    if not (me.is_supreme or v_can_salary) then perform core.fn_raise('E_FORBIDDEN', 'iam.salary.read'); end if;
    if p_kind not in ('promotion','transfer') then perform core.fn_raise('E_INVALID_ACTION', 'pay changes go with promotion or transfer'); end if;
  end if;
  if exists (select 1 from hr.employment_change c where c.membership_id = a.membership_id and c.status in ('scheduled','pending_approval')
              and c.kind in ('termination') ) then
    perform core.fn_raise('E_DUPLICATE', 'a termination is already scheduled');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.employment_change (company_id, membership_id, assignment_id, kind, to_position_code, to_wing_id, to_department_id, to_location_id,
                                    grade, salary, effective_on, reason, created_by)
  values (me.company_id, a.membership_id, a.id, p_kind, p_to_position_code, p_to_wing_id, p_to_department_id, p_to_location_id,
          p_grade, p_salary, v_eff, p_reason, me.person_id) returning id into v_id;
  if config.fn_get_bool(me.company_id, 'hr.employment_change.requires_approval') then
    -- amount 0: pay never enters the approval payload / audit
    j := core.fn_approval_submit(me.company_id, 'hr.employment_change', v_id, 0,
                                 iam.fn_resource(me.company_id, a.home_wing_id, a.home_department_id, a.home_location_id, null, v_person),
                                 jsonb_build_object('change_id', v_id, 'kind', p_kind));
    if j ->> 'status' <> 'approved' then
      update hr.employment_change set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
      return jsonb_build_object('change_id', v_id, 'status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
    update hr.employment_change set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  end if;
  if v_eff <= current_date then
    v_new := hr.fn_apply_employment_change(v_id);
  end if;
  select c.status into v_status from hr.employment_change c where c.id = v_id;
  return jsonb_build_object('change_id', v_id, 'status', v_status, 'new_assignment_id', v_new, 'effective_on', v_eff);
end $$;

create function api.v1_hr_change_cancel(p_change_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c hr.employment_change%rowtype; a iam.position_assignment%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into c from hr.employment_change where id = p_change_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'change'); end if;
  select * into a from iam.position_assignment where id = c.assignment_id;
  select * into me from iam.fn_require('iam.employee.change', iam.fn_resource(a.company_id, a.home_wing_id, a.home_department_id, a.home_location_id), true);
  select * into c from hr.employment_change where id = p_change_id for update;
  if c.status not in ('scheduled','pending_approval') then perform core.fn_raise('E_INVALID_ACTION', 'change is ' || c.status); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if c.status = 'pending_approval' then
    update core.approval_request set status = 'cancelled', decided_at = clock_timestamp()
     where id = c.approval_request_id and company_id = c.company_id and status = 'pending';
  end if;
  update hr.employment_change set status = 'cancelled' where id = c.id;
  return jsonb_build_object('change_id', c.id, 'status', 'cancelled');
end $$;

-- Hiring checklist templates: per position (null = company default). Returns the new version.
create function api.v1_hr_onboarding_template_set(p_position_code text, p_tasks jsonb, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; t jsonb; v_keys text[] := array[]::text[]; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.onboarding.manage', iam.fn_my_company_resource(), true);
  if jsonb_typeof(p_tasks) is distinct from 'array' or jsonb_array_length(p_tasks) not between 1 and 50 then perform core.fn_raise('E_INVALID_ACTION', 'tasks'); end if;
  for t in select * from jsonb_array_elements(p_tasks) loop
    if coalesce(t ->> 'key', '') !~ '^[a-z][a-z0-9_]{0,40}$' or (t ->> 'key') = any (v_keys) or length(btrim(coalesce(t ->> 'title_bn', ''))) = 0
       or jsonb_typeof(coalesce(t -> 'required', 'true'::jsonb)) <> 'boolean'
       or exists (select 1 from jsonb_object_keys(t) k where k not in ('key','title_bn','required')) then
      perform core.fn_raise('E_INVALID_ACTION', 'task ' || coalesce(t ->> 'key', '?'));
    end if;
    v_keys := v_keys || (t ->> 'key');
  end loop;
  if p_position_code is not null and not exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code) then
    perform core.fn_raise('E_NOT_FOUND', 'position');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update hr.onboarding_template set status = 'superseded'
   where company_id = me.company_id and position_code is not distinct from p_position_code and status = 'active';
  v_next := coalesce((select max(x.version) from hr.onboarding_template x where x.company_id = me.company_id and x.position_code is not distinct from p_position_code), 0) + 1;
  insert into hr.onboarding_template (company_id, position_code, tasks, version, reason, set_by)
  values (me.company_id, p_position_code, p_tasks, v_next, p_reason, me.person_id);
  return v_next;
end $$;

-- Hire: member + position + checklist. With hr.onboarding.block_login the new person cannot work until approval.
create function api.v1_hr_hire(p_full_name_bn text, p_phone text, p_email text, p_employee_no text, p_position_code text,
                               p_home_wing uuid, p_home_department uuid, p_home_location uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; j jsonb; v_asg uuid; v_tasks jsonb; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.onboarding.manage',
           iam.fn_resource(iam.fn_context_company(), p_home_wing, p_home_department, p_home_location), true);
  j := api.v1_iam_add_member(p_full_name_bn, p_phone, p_email, p_employee_no, p_reason);
  v_asg := api.v1_iam_assign_position((j ->> 'membership_id')::uuid, p_position_code, null, null, 'regular', p_home_wing, p_home_department, p_home_location, p_reason);
  select t.tasks into v_tasks from hr.onboarding_template t
   where t.company_id = me.company_id and t.status = 'active' and (t.position_code = p_position_code or t.position_code is null)
   order by (t.position_code is null) limit 1;
  v_tasks := coalesce(v_tasks, config.fn_get(me.company_id, 'hr.onboarding.default_tasks'));
  select coalesce(jsonb_agg(x || jsonb_build_object('required', coalesce((x ->> 'required')::boolean, true), 'done', false)), '[]'::jsonb) into v_tasks
    from jsonb_array_elements(v_tasks) x;
  insert into hr.onboarding (company_id, membership_id, assignment_id, position_code, tasks, blocks_login, created_by)
  values (me.company_id, (j ->> 'membership_id')::uuid,
          case when exists (select 1 from iam.position_assignment pa where pa.id = v_asg) then v_asg end,
          p_position_code, v_tasks, config.fn_get_bool(me.company_id, 'hr.onboarding.block_login'), me.person_id)
  returning id into v_id;
  return j || jsonb_build_object('assignment_id', v_asg, 'onboarding_id', v_id, 'tasks', v_tasks);
end $$;

-- Tick / untick one task.
create function api.v1_hr_onboarding_task(p_onboarding_id uuid, p_task_key text, p_done boolean, p_expected_row_version integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o hr.onboarding%rowtype; v_tasks jsonb;
begin
  select * into me from iam.fn_require('iam.onboarding.manage', iam.fn_my_company_resource(), true);
  select * into o from hr.onboarding where id = p_onboarding_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'onboarding'); end if;
  if o.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  if o.status <> 'open' then perform core.fn_raise('E_INVALID_ACTION', 'checklist is ' || o.status); end if;
  if not exists (select 1 from jsonb_array_elements(o.tasks) x where x ->> 'key' = p_task_key) then perform core.fn_raise('E_NOT_FOUND', 'task'); end if;
  select jsonb_agg(case when x ->> 'key' = p_task_key
                        then x || jsonb_build_object('done', coalesce(p_done, false), 'done_by', me.person_id, 'done_at', clock_timestamp())
                        else x end order by ord) into v_tasks
    from jsonb_array_elements(o.tasks) with ordinality t(x, ord);
  perform set_config('mohona.change_reason', 'onboarding task ' || p_task_key, true);
  update hr.onboarding set tasks = v_tasks where id = o.id returning * into o;
  return jsonb_build_object('onboarding_id', o.id, 'tasks', o.tasks, 'row_version', o.row_version);
end $$;

-- approve (all required tasks done; never by the new person) | cancel
create function api.v1_hr_onboarding_decide(p_onboarding_id uuid, p_action text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o hr.onboarding%rowtype; v_person uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.onboarding.manage', iam.fn_my_company_resource(), true);
  select * into o from hr.onboarding where id = p_onboarding_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'onboarding'); end if;
  if o.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  if o.status <> 'open' then perform core.fn_raise('E_INVALID_ACTION', 'checklist is ' || o.status); end if;
  select m.person_id into v_person from iam.company_membership m where m.id = o.membership_id;
  if v_person = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'approve' then
    if exists (select 1 from jsonb_array_elements(o.tasks) x where coalesce((x ->> 'required')::boolean, true) and not coalesce((x ->> 'done')::boolean, false)) then
      perform core.fn_raise('E_ONBOARDING_INCOMPLETE');
    end if;
    update hr.onboarding set status = 'approved', approved_by = me.person_id, approved_at = clock_timestamp() where id = o.id;
  elsif p_action = 'cancel' then
    update hr.onboarding set status = 'cancelled' where id = o.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action);
  end if;
  return jsonb_build_object('onboarding_id', o.id, 'status', (select x.status from hr.onboarding x where x.id = o.id));
end $$;

create function api.v1_hr_onboardings(p_status text default 'open') returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.hierarchy.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', o.id, 'membership_id', o.membership_id, 'assignment_id', o.assignment_id,
                                                       'name_bn', p.full_name_bn, 'position_code', o.position_code, 'tasks', o.tasks, 'status', o.status,
                                                       'blocks_login', o.blocks_login, 'created_at', o.created_at, 'row_version', o.row_version)
                                    order by o.created_at desc)
                     from hr.onboarding o join iam.company_membership m on m.id = o.membership_id join core.person p on p.id = m.person_id
                    where o.company_id = me.company_id and (p_status is null or o.status = p_status)), '[]'::jsonb);
end $$;

-- Substitution: a manager appoints an acting holder for an absent colleague's duties (bounded window + written duty).
-- Built on S09 delegation, so it is live-checked (the absent holder must still hold each right) and revocable at once.
create function api.v1_hr_substitute(p_absent_assignment uuid, p_substitute_assignment uuid, p_permissions text[], p_scope_kind text, p_scope_id uuid,
                                     p_valid_from timestamptz, p_valid_until timestamptz, p_duty_bn text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; ab record; sb record; v_from timestamptz := coalesce(p_valid_from, clock_timestamp()); v_perm text; v_pc iam.permission_catalog%rowtype;
        v_res iam.resource; d record; v_del uuid; v_id uuid; v_max integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if length(btrim(coalesce(p_duty_bn, ''))) < 3 then perform core.fn_raise('E_DELEGATION_INVALID', 'duty required'); end if;
  if coalesce(p_scope_kind, '') not in ('COMPANY','WING','DEPARTMENT','LOCATION') or ((p_scope_kind = 'COMPANY') <> (p_scope_id is null)) then
    perform core.fn_raise('E_DELEGATION_INVALID', 'explicit scope required');
  end if;
  if coalesce(cardinality(p_permissions), 0) = 0 then perform core.fn_raise('E_DELEGATION_INVALID', 'permissions required'); end if;
  select * into me from iam.fn_require('iam.delegation.manage', iam.fn_my_company_resource(), true);
  select a.*, m.person_id, pc.is_supreme into ab from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
    join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
   where a.id = p_absent_assignment and a.company_id = me.company_id and a.status = 'active';
  if ab.id is null then perform core.fn_raise('E_NOT_FOUND', 'absent assignment'); end if;
  select a.*, m.person_id into sb from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
   where a.id = p_substitute_assignment and a.company_id = me.company_id and a.status = 'active';
  if sb.id is null then perform core.fn_raise('E_NOT_FOUND', 'substitute assignment'); end if;
  if ab.person_id = sb.person_id then perform core.fn_raise('E_DELEGATION_INVALID', 'substitute must be another person'); end if;
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, ab.position_code, ab.person_id);
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, sb.position_code, sb.person_id);
  v_max := config.fn_get_int(me.company_id, 'hr.substitution.max_days');
  if p_valid_until is null or p_valid_until <= v_from then perform core.fn_raise('E_DELEGATION_INVALID', 'end time required'); end if;
  if p_valid_until > v_from + make_interval(days => v_max) then perform core.fn_raise('E_DELEGATION_TOO_LONG', v_max || ' days'); end if;
  v_res := iam.fn_resource(me.company_id, case when p_scope_kind = 'WING' then p_scope_id end, case when p_scope_kind = 'DEPARTMENT' then p_scope_id end,
                           case when p_scope_kind = 'LOCATION' then p_scope_id end);
  foreach v_perm in array p_permissions loop
    select * into v_pc from iam.permission_catalog where code = v_perm;
    if not found or v_pc.status <> 'active' then perform core.fn_raise('E_NOT_FOUND', v_perm); end if;
    if not v_pc.is_delegable then perform core.fn_raise('E_NOT_DELEGABLE', v_perm); end if;
    if not (p_scope_kind = any (v_pc.allowed_scopes)) then perform core.fn_raise('E_SCOPE_NOT_ALLOWED', v_perm); end if;
    select * into d from iam.fn_decide(me.company_id, ab.id, ab.position_code, coalesce(ab.is_supreme, false), ab.person_id,
                                       ab.home_wing_id, ab.home_department_id, ab.home_location_id, v_perm, v_res, false);
    if not d.allowed then perform core.fn_raise('E_DELEGATION_INVALID', 'the absent holder does not hold ' || v_perm); end if;
  end loop;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.delegation (company_id, delegator_assignment, delegate_assignment, permission_codes, scope_kind, scope_id, valid_from, valid_until, reason, created_by)
  values (me.company_id, ab.id, sb.id, p_permissions, p_scope_kind, p_scope_id, v_from, p_valid_until, 'substitution: ' || p_duty_bn || ' — ' || p_reason, me.person_id)
  returning id into v_del;
  insert into iam.assignment_permission_rule (company_id, assignment_id, permission_code, effect, scope_kind, scope_id, valid_until, origin, created_by, reason, delegation_id)
  select me.company_id, sb.id, x, 'allow', p_scope_kind, p_scope_id, p_valid_until, 'delegation', me.person_id, 'substitution: ' || p_reason, v_del
    from unnest(p_permissions) as x;
  insert into hr.substitution (company_id, delegation_id, absent_assignment, substitute_assignment, duty_bn, valid_from, valid_until, created_by)
  values (me.company_id, v_del, ab.id, sb.id, p_duty_bn, v_from, p_valid_until, me.person_id) returning id into v_id;
  return jsonb_build_object('substitution_id', v_id, 'delegation_id', v_del, 'valid_until', p_valid_until);
end $$;

create function api.v1_hr_substitutions() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.hierarchy.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'delegation_id', s.delegation_id, 'absent_assignment', s.absent_assignment,
                                                       'substitute_assignment', s.substitute_assignment, 'duty_bn', s.duty_bn, 'valid_from', s.valid_from,
                                                       'valid_until', s.valid_until, 'permissions', d.permission_codes,
                                                       'live', d.status = 'active' and s.valid_from <= clock_timestamp() and s.valid_until > clock_timestamp())
                                    order by s.valid_from desc)
                     from hr.substitution s join iam.delegation d on d.id = s.delegation_id where s.company_id = me.company_id), '[]'::jsonb);
end $$;

-- Ends a substitution early (the appointing manager's right; the S09 revoke stays open to the two parties and the Chairman).
create function api.v1_hr_end_substitution(p_substitution_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare me record; s hr.substitution%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.delegation.manage', iam.fn_my_company_resource(), true);
  select * into s from hr.substitution where id = p_substitution_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'substitution'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.delegation set status = 'revoked', revoked_at = clock_timestamp(), revoked_by = me.person_id, revoke_reason = p_reason
   where id = s.delegation_id and status = 'active';
  if not found then perform core.fn_raise('E_INVALID_ACTION', 'substitution already ended'); end if;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_iam_access_preview(uuid, uuid)', 'api.v1_iam_sod_rules()', 'api.v1_iam_sod_set(text, text, text, text)',
      'api.v1_iam_sod_report()', 'api.v1_iam_permission_dependencies()', 'api.v1_iam_permission_audit(timestamptz, integer)',
      'api.v1_hr_set_manager(uuid, uuid, text)', 'api.v1_hr_org_tree()', 'api.v1_hr_employment_history(uuid)',
      'api.v1_hr_employment_change(text, uuid, text, uuid, uuid, uuid, text, numeric, date, text)', 'api.v1_hr_change_cancel(uuid, text)',
      'api.v1_hr_onboarding_template_set(text, jsonb, text)', 'api.v1_hr_hire(text, text, text, text, text, uuid, uuid, uuid, text)',
      'api.v1_hr_onboarding_task(uuid, text, boolean, integer)', 'api.v1_hr_onboarding_decide(uuid, text, integer, text)',
      'api.v1_hr_onboardings(text)', 'api.v1_hr_substitute(uuid, uuid, text[], text, uuid, timestamptz, timestamptz, text, text)',
      'api.v1_hr_substitutions()', 'api.v1_hr_end_substitution(uuid, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

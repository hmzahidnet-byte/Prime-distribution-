-- 20261108000350_config_settings_registry.sql  (S10)
-- Chairman settings registry: EVERY configurable behaviour of the system is a typed, versioned, company-scoped setting
-- with a best-practice default (owner rule: all options exist in the app; the Chairman chooses; nothing is hard-coded).
-- Definitions are platform vocabulary (added by migrations); values are per company, append-only history, audited.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table config.setting_definition (
  key            text primary key check (key ~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$'),
  module         text not null check (module ~ '^[a-z][a-z0-9_]*$'),
  value_type     text not null check (value_type in ('int','numeric','bool','text','text_array','json')),
  default_value  jsonb not null,
  min_value      numeric,
  max_value      numeric,
  allowed_values jsonb check (allowed_values is null or jsonb_typeof(allowed_values) = 'array'),
  name_bn        text not null,
  description_bn text,
  is_sensitive   boolean not null default false,
  requires_aal2  boolean not null default false,
  status         text not null default 'active' check (status in ('active','registered','retired')),
  sort_order     integer not null default 0,
  check (split_part(key, '.', 1) = module),
  check (min_value is null or max_value is null or min_value <= max_value)
);
create trigger trg_setting_definition_nodel before delete on config.setting_definition for each row execute function core.fn_deny_delete();

create table config.setting_value (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  key         text not null references config.setting_definition(key),
  value       jsonb not null,
  version     integer not null check (version >= 1),
  status      text not null default 'active' check (status in ('active','superseded')),
  is_reset    boolean not null default false,
  set_by      uuid,
  set_at      timestamptz not null default clock_timestamp(),
  reason      text not null check (length(btrim(reason)) > 0),
  unique (company_id, key, version)
);
create unique index setting_value_one_active on config.setting_value (company_id, key) where status = 'active';

-- Values are history: only active -> superseded is allowed.
create function config.fn_setting_value_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - 'status') <> (to_jsonb(new) - 'status') or old.status <> 'active' or new.status <> 'superseded' then
    raise exception 'E_IMMUTABLE: setting history is append-only' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_setting_value_guard before update on config.setting_value for each row execute function config.fn_setting_value_guard();
create trigger trg_setting_value_nodel before delete on config.setting_value for each row execute function core.fn_deny_delete();
create trigger trg_setting_value_audit after insert or update on config.setting_value for each row execute function audit.fn_row_change();

-- Validates a candidate value against its definition; raises E_SETTING_INVALID with the reason.
create function config.fn_validate(p_key text, p_value jsonb) returns void
language plpgsql stable set search_path = pg_catalog as $$
declare d config.setting_definition%rowtype; v_num numeric; x jsonb;
begin
  select * into d from config.setting_definition where key = p_key;
  if not found or d.status = 'retired' then
    raise exception 'E_SETTING_UNKNOWN: %', p_key using errcode = 'P0001';
  end if;
  if p_value is null or jsonb_typeof(p_value) = 'null' then
    raise exception 'E_SETTING_INVALID: % value required', p_key using errcode = 'P0001';
  end if;
  case d.value_type
    when 'int', 'numeric' then
      if jsonb_typeof(p_value) <> 'number' then raise exception 'E_SETTING_INVALID: % must be a number', p_key using errcode = 'P0001'; end if;
      v_num := (p_value #>> '{}')::numeric;
      if d.value_type = 'int' and v_num <> trunc(v_num) then raise exception 'E_SETTING_INVALID: % must be a whole number', p_key using errcode = 'P0001'; end if;
      if (d.min_value is not null and v_num < d.min_value) or (d.max_value is not null and v_num > d.max_value) then
        raise exception 'E_SETTING_INVALID: % must be between % and %', p_key, d.min_value, d.max_value using errcode = 'P0001';
      end if;
    when 'bool' then
      if jsonb_typeof(p_value) <> 'boolean' then raise exception 'E_SETTING_INVALID: % must be true/false', p_key using errcode = 'P0001'; end if;
    when 'text' then
      if jsonb_typeof(p_value) <> 'string' then raise exception 'E_SETTING_INVALID: % must be text', p_key using errcode = 'P0001'; end if;
      if length(p_value #>> '{}') > 2000 then raise exception 'E_SETTING_INVALID: % too long', p_key using errcode = 'P0001'; end if;
    when 'text_array' then
      if jsonb_typeof(p_value) <> 'array' then raise exception 'E_SETTING_INVALID: % must be a list', p_key using errcode = 'P0001'; end if;
      for x in select * from jsonb_array_elements(p_value) loop
        if jsonb_typeof(x) <> 'string' then raise exception 'E_SETTING_INVALID: % list items must be text', p_key using errcode = 'P0001'; end if;
      end loop;
    when 'json' then
      if jsonb_typeof(p_value) not in ('object','array') then raise exception 'E_SETTING_INVALID: % must be an object/list', p_key using errcode = 'P0001'; end if;
  end case;
  if d.allowed_values is not null then
    if d.value_type = 'text_array' then
      for x in select * from jsonb_array_elements(p_value) loop
        if not (d.allowed_values @> jsonb_build_array(x)) then raise exception 'E_SETTING_INVALID: % not allowed for %', x, p_key using errcode = 'P0001'; end if;
      end loop;
    elsif not (d.allowed_values @> jsonb_build_array(p_value)) then
      raise exception 'E_SETTING_INVALID: % is not an allowed value for %', p_value, p_key using errcode = 'P0001';
    end if;
  end if;
end $$;

-- Effective value: the company's active value, else the platform default. Unknown key = error (no silent default).
create function config.fn_get(p_company uuid, p_key text) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v jsonb;
begin
  select sv.value into v from config.setting_value sv where sv.company_id = p_company and sv.key = p_key and sv.status = 'active';
  if v is not null then return v; end if;
  select d.default_value into v from config.setting_definition d where d.key = p_key and d.status <> 'retired';
  if v is null then raise exception 'E_SETTING_UNKNOWN: %', p_key using errcode = 'P0001'; end if;
  return v;
end $$;

create function config.fn_get_int(p_company uuid, p_key text) returns integer
language sql stable security definer set search_path = pg_catalog as $$ select (config.fn_get(p_company, p_key) #>> '{}')::integer $$;
create function config.fn_get_numeric(p_company uuid, p_key text) returns numeric
language sql stable security definer set search_path = pg_catalog as $$ select (config.fn_get(p_company, p_key) #>> '{}')::numeric $$;
create function config.fn_get_bool(p_company uuid, p_key text) returns boolean
language sql stable security definer set search_path = pg_catalog as $$ select (config.fn_get(p_company, p_key) #>> '{}')::boolean $$;
create function config.fn_get_text(p_company uuid, p_key text) returns text
language sql stable security definer set search_path = pg_catalog as $$ select config.fn_get(p_company, p_key) #>> '{}' $$;
create function config.fn_get_text_array(p_company uuid, p_key text) returns text[]
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(array_agg(x), array[]::text[]) from jsonb_array_elements_text(config.fn_get(p_company, p_key)) as x
$$;

-- Defaults = best practice / locked blueprint V179 ADR-01..13 where it speaks; every one is Chairman-changeable.
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('iam.delegation.max_days',              'iam', 'int',  '30', 1, 365, null, 'ক্ষমতা-অর্পণের সর্বোচ্চ মেয়াদ (দিন)', 'ADR-05', true, 10),
  ('iam.session.max_concurrent',           'iam', 'int',  '1', 0, 20, null, 'একজনের একসাথে সর্বোচ্চ সেশন (০ = সীমাহীন)', 'ADR-08', true, 20),
  ('iam.mfa.required_positions',           'iam', 'text_array', '["CHAIRMAN","MD"]', null, null, null, 'যেসব পদে MFA বাধ্যতামূলক', 'ADR-08', true, 30),
  ('iam.md_appointment.requires_review',   'iam', 'bool', 'false', null, null, null, 'MD নিয়োগে দ্বিতীয় পর্যালোচনা', 'ADR-06 (Chairman-configurable)', true, 40),
  ('iam.md.max_active_primary',            'iam', 'int',  '1', 1, 10, null, 'একসাথে সক্রিয় প্রধান MD-এর সংখ্যা', 'ADR-06', true, 50),
  ('approval.chairman_self_approval.allowed','approval','bool','false', null, null, null, 'চেয়ারম্যান নিজের লেনদেন নিজে অনুমোদন করতে পারবেন', 'ADR-02 default: independent approver', true, 60),
  ('approval.maker_checker.enabled',       'approval','bool','true', null, null, null, 'মেকার-চেকার চালু', null, true, 70),
  ('breakglass.enabled',                   'breakglass','bool','false', null, null, null, 'জরুরি-প্রবেশ (Break-glass) চালু', 'ADR-03', true, 80),
  ('breakglass.custodians_required',       'breakglass','int','2', 1, 3, null, 'জরুরি-প্রবেশে প্রয়োজনীয় রক্ষক', 'ADR-03', true, 90),
  ('breakglass.max_minutes',               'breakglass','int','30', 5, 1440, null, 'জরুরি-প্রবেশের সর্বোচ্চ মেয়াদ (মিনিট)', 'ADR-03', true, 100),
  ('numbering.mode',                       'numbering','text','"GAPS_ALLOWED"', null, null, '["GAPS_ALLOWED","GAPLESS"]', 'ডকুমেন্ট-নম্বরিং পদ্ধতি', 'ADR-01', false, 110),
  ('finance.money.scale',                  'finance','int','2', 2, 2, null, 'টাকার দশমিক ঘর (পয়সা — স্থির ২, মালিকের সিদ্ধান্ত ১৪-১১-২০২৬)', 'ADR-09', true, 120),
  ('finance.rounding.mode',                'finance','text','"HALF_UP"', null, null, '["HALF_UP","HALF_EVEN","UP","DOWN"]', 'রাউন্ডিং পদ্ধতি', 'ADR-09', true, 130),
  ('finance.unit_cost.scale',              'finance','int','4', 4, 10, null, 'একক-খরচের দশমিক ঘর', 'ADR-09', true, 140),
  ('finance.backdate.max_days',            'finance','int','7', 0, 366, null, 'সর্বোচ্চ পেছনের তারিখ (দিন)', null, true, 150),
  ('finance.posting.requires_reviewed_coa','finance','bool','true', null, null, null, 'পোস্টিংয়ের আগে COA-পর্যালোচনা বাধ্যতামূলক', 'ADR-07', true, 160),
  ('inventory.negative_stock.allowed',     'inventory','bool','false', null, null, null, 'ঋণাত্মক স্টক অনুমতি', null, true, 170),
  ('inventory.return.valuation',           'inventory','text','"ORIGINAL_COST_ELSE_WAC_REVIEW"', null, null, '["ORIGINAL_COST_ELSE_WAC_REVIEW","CURRENT_WAC","ORIGINAL_COST_ONLY"]', 'ফেরত-মালের মূল্যায়ন', 'ADR-10', true, 180),
  ('mfg.residual.allocation',              'mfg','text','"LAST_ELIGIBLE_LINE"', null, null, '["LAST_ELIGIBLE_LINE","LARGEST_LINE","VARIANCE_ACCOUNT"]', 'অবশিষ্ট-খরচ বণ্টন', 'ADR-11', true, 190),
  ('company.intercompany.enabled',         'company','bool','false', null, null, null, 'আন্তঃকোম্পানি লেনদেন', null, true, 200),
  ('company.chairman_consolidated_view',   'company','bool','true', null, null, null, 'চেয়ারম্যানের সব কোম্পানির একীভূত ড্যাশবোর্ড', null, false, 210),
  ('hr.require_active_employment',         'hr','bool','true', null, null, null, 'প্রতিটি কাজে সক্রিয় কর্মসংস্থান যাচাই', 'ADR cross-cutting', true, 220),
  ('access.factory_pnl.positions',         'access','text_array','["CHAIRMAN","MD"]', null, null, null, 'ফ্যাক্টরি লাভ-ক্ষতি দেখার পদ (ডিফল্ট)', 'OWN-02', true, 230),
  ('ui.theme.primary',                     'ui','text','"#1456A0"', null, null, null, 'প্রধান রং', 'blueprint default', false, 240),
  ('ui.nav.bottom_tabs',                   'ui','text_array','["home","tasks","reports","more"]', null, null, null, 'নিচের নেভিগেশন-ট্যাব', 'blueprint default', false, 250),
  ('ui.language',                          'ui','text','"bn"', null, null, '["bn"]', 'ভাষা', 'Bengali only', false, 260),
  ('recycle.retention_days',               'recycle','int','90', 1, 3650, null, 'রিসাইকেল-বিনে রাখার মেয়াদ (দিন)', null, false, 270),
  ('audit.retention_years',                'audit','int','10', 1, 50, null, 'অডিট-লগ সংরক্ষণ (বছর)', 'never deletable inside retention', true, 280);

reset role;

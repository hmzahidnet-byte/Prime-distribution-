-- 20261108002200_master_structure.sql  (S23)
-- Master structure (step plan S23; no blueprint feature id of its own — it is the base of PRODUCT_MASTER, INVENTORY,
-- MAPS_LOCATION and every WAREHOUSE-scoped right):
--   * structure API: wings, departments (tree, no cycles), locations and warehouses — create / edit / deactivate with
--     reason, version check and audit; codes never change; a unit still in use cannot be deactivated
--   * inventory.warehouse + the WAREHOUSE permission scope (rules now name a warehouse of the same company)
--   * Bangladesh administrative areas (division > district > upazila > union) imported from the owner-supplied file
--     (docs/blueprint/geo, source labels preserved, anomalies recorded, aliases separate) — seed in 20261108002300
--   * locations may point to an administrative area; geo lookups are open to every member (public reference data)
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ administrative areas (platform reference data)
create table location.admin_area (
  code         text primary key check (code ~ '^[0-9]{2}(\.[0-9]{2}(\.[0-9]{3}(\.[0-9]{3})?)?)?$'),
  kind         text not null check (kind in ('division','district','upazila','union')),
  name_bn      text not null check (length(btrim(name_bn)) > 0),
  search_key   text not null,
  parent_code  text references location.admin_area(code),
  source       text not null default 'bd-dd-ui-bn',
  sort_order   integer not null default 0,
  check ((kind = 'division') = (parent_code is null)),
  check (kind <> 'division' or code ~ '^[0-9]{2}$'),
  check (kind <> 'district' or code ~ '^[0-9]{2}\.[0-9]{2}$'),
  check (kind <> 'upazila'  or code ~ '^[0-9]{2}\.[0-9]{2}\.[0-9]{3}$'),
  check (kind <> 'union'    or code ~ '^[0-9]{2}\.[0-9]{2}\.[0-9]{3}\.[0-9]{3}$')
);
create index admin_area_parent on location.admin_area (parent_code, sort_order);
create index admin_area_search on location.admin_area (search_key);
create trigger trg_admin_area_nodel before delete on location.admin_area for each row execute function core.fn_deny_delete();

create table location.admin_area_alias (
  id         uuid primary key default gen_random_uuid(),
  area_code  text not null references location.admin_area(code),
  alias_bn   text not null check (length(btrim(alias_bn)) between 1 and 120),
  search_key text not null,
  added_by   uuid references core.person(id),
  added_at   timestamptz not null default clock_timestamp(),
  reason     text not null check (length(btrim(reason)) > 0),
  unique (area_code, search_key)
);
create trigger trg_admin_area_alias_nodel before delete on location.admin_area_alias for each row execute function core.fn_deny_delete();
create trigger trg_admin_area_alias_audit after insert on location.admin_area_alias for each row execute function audit.fn_row_change();

create table location.admin_area_anomaly (
  id          bigint generated always as identity primary key,
  area_code   text,
  kind        text not null,
  label       text not null,
  note        text
);

-- Search key: Unicode NFC, collapsed spaces, the generic suffixes removed (উপজেলা / ইউনিয়ন / জেলা / বিভাগ / সদর stays).
create function location.fn_search_key(p text) returns text
language sql immutable set search_path = pg_catalog as $$
  select btrim(regexp_replace(regexp_replace(normalize(coalesce(p, ''), NFC), normalize('\s*(উপজেলা|ইউনিয়ন|জেলা|বিভাগ)\s*$', NFC), ''), '\s+', ' ', 'g'))
$$;

select core.fn_apply_rls('location', 'admin_area');
select core.fn_apply_rls('location', 'admin_area_alias');
select core.fn_apply_rls('location', 'admin_area_anomaly');

alter table core.location add column admin_area_code text references location.admin_area(code);

-- ================================================================ warehouses
create table inventory.warehouse (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  wing_id      uuid,
  location_id  uuid,
  code         text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn      text not null check (length(btrim(name_bn)) > 0),
  kind         text not null check (kind in ('raw_material','finished_goods','general','transit','quarantine','scrap')),
  status       text not null default 'active' check (status in ('active','inactive')),
  created_at   timestamptz not null default clock_timestamp(),
  updated_at   timestamptz not null default clock_timestamp(),
  row_version  integer not null default 1,
  unique (id, company_id),
  unique (company_id, code),
  foreign key (wing_id, company_id) references core.wing (id, company_id),
  foreign key (location_id, company_id) references core.location (id, company_id)
);
create trigger trg_warehouse_guard before update on inventory.warehouse for each row execute function core.fn_scoped_guard();
create trigger trg_warehouse_touch before update on inventory.warehouse for each row execute function core.fn_touch_row();
create trigger trg_warehouse_nodel before delete on inventory.warehouse for each row execute function core.fn_deny_delete();
create trigger trg_warehouse_audit after insert or update on inventory.warehouse for each row execute function audit.fn_row_change();
select core.fn_apply_rls('inventory', 'warehouse');

-- WAREHOUSE scope is now available (S07 kept it closed until this master existed).
create or replace function iam.fn_permission_rule_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_row jsonb := to_jsonb(new); v_scopes text[]; v_scope_id uuid := (v_row ->> 'scope_id')::uuid; v_ok boolean;
begin
  if tg_op = 'UPDATE' then
    if old.status = 'revoked' then
      raise exception 'E_IMMUTABLE: a revoked rule cannot change' using errcode = 'P0001';
    end if;
    if (to_jsonb(old) - array['status','revoked_at','revoked_by','reason']) <> (v_row - array['status','revoked_at','revoked_by','reason']) then
      raise exception 'E_IMMUTABLE: only revoking a rule is allowed; create a new rule instead' using errcode = 'P0001';
    end if;
  else
    select allowed_scopes into v_scopes from iam.permission_catalog where code = new.permission_code;
    if not (new.scope_kind = any (v_scopes)) then
      raise exception 'E_SCOPE_NOT_ALLOWED: % cannot be granted with scope %', new.permission_code, new.scope_kind using errcode = 'P0001';
    end if;
    if new.scope_kind = 'WAREHOUSE' and v_scope_id is null then
      raise exception 'E_SCOPE_NOT_ALLOWED: a warehouse rule names its warehouse' using errcode = 'P0001';
    end if;
    if v_scope_id is not null then
      v_ok := case new.scope_kind
        when 'WING'       then exists (select 1 from core.wing       where id = v_scope_id and company_id = new.company_id)
        when 'DEPARTMENT' then exists (select 1 from core.department where id = v_scope_id and company_id = new.company_id)
        when 'LOCATION'   then exists (select 1 from core.location   where id = v_scope_id and company_id = new.company_id)
        when 'WAREHOUSE'  then exists (select 1 from inventory.warehouse where id = v_scope_id and company_id = new.company_id)
        else false end;
      if not v_ok then
        raise exception 'E_WRONG_COMPANY: scope unit does not belong to this company' using errcode = 'P0001';
      end if;
    end if;
  end if;
  if tg_table_name = 'position_permission_rule' then
    update core.person p set authz_epoch = p.authz_epoch + 1
     where p.id in (select m.person_id from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                     where a.company_id = new.company_id and a.position_code = (v_row ->> 'position_code') and a.status = 'active');
  else
    update core.person p set authz_epoch = p.authz_epoch + 1
     where p.id = (select m.person_id from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                    where a.id = (v_row ->> 'assignment_id')::uuid);
  end if;
  return new;
end $$;

update iam.permission_catalog set status = 'active' where code = 'core.structure.manage';
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values ('MD', 'core.structure.read', 'allow', 'COMPANY')
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

-- "বিভাগ › জেলা › উপজেলা › ইউনিয়ন" for an area code (null when unknown).
create function location.fn_area_path(p_code text) returns text
language sql stable security definer set search_path = pg_catalog as $$
  with recursive up(code, name_bn, parent_code, depth) as (
    select a.code, a.name_bn, a.parent_code, 0 from location.admin_area a where a.code = p_code
    union all select a.code, a.name_bn, a.parent_code, up.depth + 1 from location.admin_area a join up on a.code = up.parent_code where up.depth < 4)
  select string_agg(name_bn, ' › ' order by depth desc) from up
$$;

-- ================================================================ structure API
create function api.v1_structure_tree() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('core.structure.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'wings', coalesce((select jsonb_agg(jsonb_build_object('id', w.id, 'code', w.code, 'name_bn', w.name_bn, 'name_en', w.name_en, 'kind', w.wing_kind,
               'status', w.status, 'row_version', w.row_version,
               'departments', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'code', d.code, 'name_bn', d.name_bn, 'parent_id', d.parent_department_id,
                                                                            'status', d.status, 'row_version', d.row_version) order by d.sort_order, d.code)
                                          from core.department d where d.wing_id = w.id and d.company_id = me.company_id), '[]'::jsonb))
               order by w.sort_order, w.code) from core.wing w where w.company_id = me.company_id), '[]'::jsonb),
    'locations', coalesce((select jsonb_agg(jsonb_build_object('id', l.id, 'code', l.code, 'name_bn', l.name_bn, 'wing_id', l.wing_id, 'kind', l.location_kind,
               'address_bn', l.address_bn, 'admin_area_code', l.admin_area_code,
               'admin_area', (select location.fn_area_path(l.admin_area_code)), 'latitude', l.latitude, 'longitude', l.longitude,
               'geofence_radius_m', l.geofence_radius_m, 'status', l.status, 'row_version', l.row_version) order by l.code)
             from core.location l where l.company_id = me.company_id), '[]'::jsonb),
    'warehouses', coalesce((select jsonb_agg(jsonb_build_object('id', h.id, 'code', h.code, 'name_bn', h.name_bn, 'wing_id', h.wing_id, 'location_id', h.location_id,
               'kind', h.kind, 'status', h.status, 'row_version', h.row_version) order by h.code)
             from inventory.warehouse h where h.company_id = me.company_id), '[]'::jsonb));
end $$;

-- Units in use (home of an active assignment / a warehouse / a department) are never deactivated (E_STRUCTURE_IN_USE).
create function core.fn_unit_in_use(p_kind text, p_id uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select case p_kind
    when 'wing' then exists (select 1 from iam.position_assignment a where a.home_wing_id = p_id and a.status <> 'ended')
                  or exists (select 1 from core.department d where d.wing_id = p_id and d.status = 'active')
                  or exists (select 1 from inventory.warehouse h where h.wing_id = p_id and h.status = 'active')
    when 'department' then exists (select 1 from iam.position_assignment a where a.home_department_id = p_id and a.status <> 'ended')
                        or exists (select 1 from core.department d where d.parent_department_id = p_id and d.status = 'active')
    when 'location' then exists (select 1 from iam.position_assignment a where a.home_location_id = p_id and a.status <> 'ended')
                      or exists (select 1 from inventory.warehouse h where h.location_id = p_id and h.status = 'active')
    else false end
$$;

-- One save function per unit kind: p_id null = create (code given), else edit (code fixed). Returns {id, row_version}.
create function api.v1_structure_save_wing(p_id uuid, p_code text, p_name_bn text, p_name_en text, p_kind text, p_sort integer, p_status text,
                                           p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; w core.wing%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.structure.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into core.wing (company_id, code, name_bn, name_en, wing_kind, sort_order)
    values (me.company_id, upper(p_code), p_name_bn, p_name_en, coalesce(p_kind, 'other'), coalesce(p_sort, 0)) returning * into w;
  else
    select * into w from core.wing where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'wing'); end if;
    if w.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    if coalesce(p_status, w.status) = 'inactive' and w.status = 'active' and core.fn_unit_in_use('wing', w.id) then perform core.fn_raise('E_STRUCTURE_IN_USE', 'wing'); end if;
    update core.wing set name_bn = coalesce(p_name_bn, name_bn), name_en = p_name_en, wing_kind = coalesce(p_kind, wing_kind),
                         sort_order = coalesce(p_sort, sort_order), status = coalesce(p_status, status) where id = w.id returning * into w;
  end if;
  return jsonb_build_object('id', w.id, 'row_version', w.row_version);
end $$;

create function api.v1_structure_save_department(p_id uuid, p_wing_id uuid, p_parent_id uuid, p_code text, p_name_bn text, p_name_en text, p_sort integer,
                                                 p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d core.department%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.structure.manage', iam.fn_my_company_resource(), true);
  if p_parent_id is not null and not exists (select 1 from core.department x where x.id = p_parent_id and x.company_id = me.company_id and x.wing_id = p_wing_id) then
    perform core.fn_raise('E_INVALID_ACTION', 'parent department must be in the same wing');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into core.department (company_id, wing_id, parent_department_id, code, name_bn, name_en, sort_order)
    values (me.company_id, p_wing_id, p_parent_id, upper(p_code), p_name_bn, p_name_en, coalesce(p_sort, 0)) returning * into d;
  else
    select * into d from core.department where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'department'); end if;
    if d.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    if d.wing_id <> p_wing_id then perform core.fn_raise('E_INVALID_ACTION', 'a department does not change wing; create a new one'); end if;
    if coalesce(p_status, d.status) = 'inactive' and d.status = 'active' and core.fn_unit_in_use('department', d.id) then perform core.fn_raise('E_STRUCTURE_IN_USE', 'department'); end if;
    update core.department set parent_department_id = p_parent_id, name_bn = coalesce(p_name_bn, name_bn), name_en = p_name_en,
                               sort_order = coalesce(p_sort, sort_order), status = coalesce(p_status, status) where id = d.id returning * into d;
  end if;
  return jsonb_build_object('id', d.id, 'row_version', d.row_version);
end $$;

create function api.v1_structure_save_location(p_id uuid, p_wing_id uuid, p_code text, p_name_bn text, p_kind text, p_address_bn text, p_admin_area_code text,
                                               p_latitude numeric, p_longitude numeric, p_geofence_m integer, p_status text,
                                               p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; l core.location%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.structure.manage', iam.fn_my_company_resource(), true);
  if p_admin_area_code is not null and not exists (select 1 from location.admin_area a where a.code = p_admin_area_code) then
    perform core.fn_raise('E_NOT_FOUND', 'administrative area');
  end if;
  if p_latitude is not null and (p_latitude not between 20.3 and 26.8 or p_longitude not between 88.0 and 92.8) then
    perform core.fn_raise('E_INVALID_ACTION', 'coordinates outside Bangladesh');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into core.location (company_id, wing_id, code, name_bn, location_kind, address_bn, admin_area_code, latitude, longitude, geofence_radius_m)
    values (me.company_id, p_wing_id, upper(p_code), p_name_bn, p_kind, p_address_bn, p_admin_area_code, p_latitude, p_longitude, p_geofence_m) returning * into l;
  else
    select * into l from core.location where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'location'); end if;
    if l.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    if coalesce(p_status, l.status) = 'inactive' and l.status = 'active' and core.fn_unit_in_use('location', l.id) then perform core.fn_raise('E_STRUCTURE_IN_USE', 'location'); end if;
    update core.location set wing_id = p_wing_id, name_bn = coalesce(p_name_bn, name_bn), location_kind = coalesce(p_kind, location_kind), address_bn = p_address_bn,
                             admin_area_code = p_admin_area_code, latitude = p_latitude, longitude = p_longitude, geofence_radius_m = p_geofence_m,
                             status = coalesce(p_status, status) where id = l.id returning * into l;
  end if;
  return jsonb_build_object('id', l.id, 'row_version', l.row_version);
end $$;

create function api.v1_structure_save_warehouse(p_id uuid, p_wing_id uuid, p_location_id uuid, p_code text, p_name_bn text, p_kind text, p_status text,
                                                p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; h inventory.warehouse%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.structure.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into inventory.warehouse (company_id, wing_id, location_id, code, name_bn, kind)
    values (me.company_id, p_wing_id, p_location_id, upper(p_code), p_name_bn, coalesce(p_kind, 'general')) returning * into h;
  else
    select * into h from inventory.warehouse where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'warehouse'); end if;
    if h.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    if coalesce(p_status, h.status) = 'inactive' and h.status = 'active'
       and exists (select 1 from iam.position_permission_rule r where r.company_id = me.company_id and r.scope_kind = 'WAREHOUSE' and r.scope_id = h.id and r.status = 'active'
                   union all select 1 from iam.assignment_permission_rule r where r.company_id = me.company_id and r.scope_kind = 'WAREHOUSE' and r.scope_id = h.id and r.status = 'active') then
      perform core.fn_raise('E_STRUCTURE_IN_USE', 'warehouse still named by permission rules');
    end if;
    update inventory.warehouse set wing_id = p_wing_id, location_id = p_location_id, name_bn = coalesce(p_name_bn, name_bn), kind = coalesce(p_kind, kind),
                                   status = coalesce(p_status, status) where id = h.id returning * into h;
  end if;
  return jsonb_build_object('id', h.id, 'row_version', h.row_version);
end $$;

-- ================================================================ geo API (public reference data: any member)
create function api.v1_geo_children(p_parent_code text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', a.code, 'kind', a.kind, 'name_bn', a.name_bn) order by a.sort_order, a.code)
                     from location.admin_area a where a.parent_code is not distinct from p_parent_code), '[]'::jsonb);
end $$;

-- Search by name or alias (NFC, suffix-insensitive); each hit carries its full path.
create function api.v1_geo_search(p_text text, p_kind text default null, p_limit integer default 30) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; k text := location.fn_search_key(p_text);
begin
  select * into me from iam.fn_context(false);
  if char_length(k) < 2 then return '[]'::jsonb; end if;
  return coalesce((select jsonb_agg(x) from (
    select jsonb_build_object('code', a.code, 'kind', a.kind, 'name_bn', a.name_bn, 'path', location.fn_area_path(a.code)) x
      from location.admin_area a
     where (p_kind is null or a.kind = p_kind)
       and (a.search_key like k || '%' or exists (select 1 from location.admin_area_alias al where al.area_code = a.code and al.search_key like k || '%'))
     order by (a.search_key = k) desc, a.kind, a.code limit greatest(1, least(coalesce(p_limit, 30), 100))) q), '[]'::jsonb);
end $$;

create function api.v1_geo_add_alias(p_code text, p_alias_bn text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('core.structure.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from location.admin_area a where a.code = p_code) then perform core.fn_raise('E_NOT_FOUND', 'administrative area'); end if;
  if config.fn_form_text_unsafe(p_alias_bn) then perform core.fn_raise('E_INVALID_ACTION', 'alias text'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into location.admin_area_alias (area_code, alias_bn, search_key, added_by, reason)
  values (p_code, btrim(p_alias_bn), location.fn_search_key(p_alias_bn), me.person_id, p_reason) on conflict do nothing;
  return jsonb_build_object('code', p_code, 'alias_bn', p_alias_bn);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_structure_tree()',
      'api.v1_structure_save_wing(uuid, text, text, text, text, integer, text, integer, text)',
      'api.v1_structure_save_department(uuid, uuid, uuid, text, text, text, integer, text, integer, text)',
      'api.v1_structure_save_location(uuid, uuid, text, text, text, text, text, numeric, numeric, integer, text, integer, text)',
      'api.v1_structure_save_warehouse(uuid, uuid, uuid, text, text, text, text, integer, text)',
      'api.v1_geo_children(text)', 'api.v1_geo_search(text, text, integer)', 'api.v1_geo_add_alias(text, text, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- 20261108000900_config_settings_api.sql  (S10)
-- Chairman settings API: read every setting with its effective value; change / reset with optimistic version, reason,
-- MFA where the definition demands it, append-only history and audit. Permission: config.settings.read / .manage.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create function api.v1_config_settings(p_module text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'key', d.key, 'module', d.module, 'value_type', d.value_type, 'name_bn', d.name_bn, 'description_bn', d.description_bn,
             'default_value', d.default_value, 'min_value', d.min_value, 'max_value', d.max_value, 'allowed_values', d.allowed_values,
             'is_sensitive', d.is_sensitive, 'requires_aal2', d.requires_aal2,
             'value', coalesce(v.value, d.default_value), 'is_default', v.id is null or v.is_reset,
             'version', coalesce(v.version, 0), 'set_at', v.set_at, 'reason', v.reason)
           order by d.module, d.sort_order, d.key)
      from config.setting_definition d
      left join config.setting_value v on v.key = d.key and v.company_id = me.company_id and v.status = 'active'
     where d.status = 'active' and (p_module is null or d.module = p_module)), '[]'::jsonb);
end $$;

-- p_expected_version: the version the editor showed (0 = never changed). Stale -> E_STALE_VERSION.
create function api.v1_config_set(p_key text, p_value jsonb, p_expected_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; d config.setting_definition%rowtype; cur config.setting_value%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.settings.manage', iam.fn_my_company_resource(), true);
  select * into d from config.setting_definition where key = p_key and status = 'active';
  if not found then perform core.fn_raise('E_SETTING_UNKNOWN', p_key); end if;
  if d.requires_aal2 and core.fn_jwt_claim('aal') is distinct from 'aal2' then perform core.fn_raise('E_MFA_REQUIRED'); end if;
  perform config.fn_validate(p_key, p_value);
  select * into cur from config.setting_value where company_id = me.company_id and key = p_key and status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then
    perform core.fn_raise('E_STALE_VERSION', 'setting ' || p_key || ' is at version ' || coalesce(cur.version, 0));
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then
    update config.setting_value set status = 'superseded' where id = cur.id;
  end if;
  v_next := coalesce((select max(version) from config.setting_value where company_id = me.company_id and key = p_key), 0) + 1;
  insert into config.setting_value (company_id, key, value, version, set_by, reason)
  values (me.company_id, p_key, p_value, v_next, me.person_id, p_reason);
  if d.module in ('iam','access','ui') then                 -- clients re-read context/UI on epoch change
    update core.person p set authz_epoch = p.authz_epoch + 1
     where p.id in (select m.person_id from iam.company_membership m where m.company_id = me.company_id and m.status <> 'ended');
  end if;
  return v_next;
end $$;

create function api.v1_config_reset(p_key text, p_expected_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare d config.setting_definition%rowtype; me record; cur config.setting_value%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.settings.manage', iam.fn_my_company_resource(), true);
  select * into d from config.setting_definition where key = p_key and status = 'active';
  if not found then perform core.fn_raise('E_SETTING_UNKNOWN', p_key); end if;
  if d.requires_aal2 and core.fn_jwt_claim('aal') is distinct from 'aal2' then perform core.fn_raise('E_MFA_REQUIRED'); end if;
  select * into cur from config.setting_value where company_id = me.company_id and key = p_key and status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  if cur.id is null or cur.is_reset then return coalesce(cur.version, 0); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update config.setting_value set status = 'superseded' where id = cur.id;
  v_next := cur.version + 1;
  insert into config.setting_value (company_id, key, value, version, is_reset, set_by, reason)
  values (me.company_id, p_key, d.default_value, v_next, true, me.person_id, p_reason);
  return v_next;
end $$;

create function api.v1_config_history(p_key text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('version', v.version, 'value', v.value, 'status', v.status, 'is_reset', v.is_reset,
                                                       'set_by', v.set_by, 'set_at', v.set_at, 'reason', v.reason) order by v.version desc)
                     from config.setting_value v where v.company_id = me.company_id and v.key = p_key), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'grant execute on function api.v1_config_settings(text) to authenticated';
    execute 'grant execute on function api.v1_config_set(text, jsonb, integer, text) to authenticated';
    execute 'grant execute on function api.v1_config_reset(text, integer, text) to authenticated';
    execute 'grant execute on function api.v1_config_history(text) to authenticated';
  end if;
end $$;

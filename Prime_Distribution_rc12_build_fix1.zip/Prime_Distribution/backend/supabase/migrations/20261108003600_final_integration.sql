-- 20261108003600_final_integration.sql  (S55, final phase)
-- Final integration:
--   * module switches now gate route / report / hardware / backup permissions like every other module
--   * AUDIT_GOVERNANCE 267: expired delegations are closed by the scheduler (authorisation already ignores them);
--     268: at most one live Chairman seat per company is now also a database constraint (no group chairman)
--   * QUALITY_RELEASE 271: requirement registry filled for all 300 features (status "written" until CI marks them passed);
--     272: the canonical IAM objects must exist or this migration stops; 275: a deny-by-default probe for API roles
--   * 273/274/276–280 are CI workflows + runbooks in the repository (docs/RELEASE_RUNBOOK_BN.md); nothing here claims they passed
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ---------------------------------------------------------------- F272: canonical IAM objects (migration stops if one is missing)
do $$
declare t text; missing text := '';
begin
  foreach t in array array['core.person','iam.person_auth_link','iam.company_membership','iam.position_catalog','iam.position_assignment',
                           'iam.permission_catalog','iam.position_permission_rule','iam.assignment_permission_rule'] loop
    if to_regclass(t) is null then missing := missing || ' ' || t; end if;
  end loop;
  if missing <> '' then raise exception 'E_SCHEMA_INCOMPATIBLE: canonical IAM objects missing:%', missing; end if;
end $$;

-- ---------------------------------------------------------------- module gates for the modules built in the last phases
update config.module_catalog set permission_modules = array['route'] where code = 'route';
update config.module_catalog set permission_modules = array['reports','report'] where code = 'report';
update config.module_catalog set permission_modules = array['device','hardware'] where code = 'hardware';
update config.module_catalog set permission_modules = array['backup','ops'] where code = 'backup';
select config.fn_make_module_available('route');
select config.fn_make_module_available('report');
select config.fn_make_module_available('hardware');
select config.fn_make_module_available('backup');
select config.fn_make_module_available('qr');
select config.fn_make_module_available('location');

-- ---------------------------------------------------------------- F268: one live Chairman seat per company
create unique index if not exists position_assignment_one_chairman on iam.position_assignment (company_id) where position_code = 'CHAIRMAN' and status <> 'ended';

-- ---------------------------------------------------------------- F267: scheduler closes expired delegations
create function svc.v1_delegations_expire() returns integer
language plpgsql security definer set search_path = '' as $$
declare n integer;
begin
  perform set_config('mohona.company_scope', '', true);
  perform set_config('mohona.change_reason', 'delegation expired', true);
  update iam.delegation set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'expired' where status = 'active' and valid_until < clock_timestamp();
  get diagnostics n = row_count;
  return n;
end $$;

-- Governance self-check for the Chairman / auditor: seats, live delegations, anything that needs attention.
create function api.v1_governance_check() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'chairman_seats', (select count(*) from iam.position_assignment a where a.company_id = me.company_id and a.position_code = 'CHAIRMAN' and a.status <> 'ended'),
    'delegations_active', (select count(*) from iam.delegation d where d.company_id = me.company_id and d.status = 'active' and d.valid_until >= clock_timestamp()),
    'delegations_expired_open', (select count(*) from iam.delegation d where d.company_id = me.company_id and d.status = 'active' and d.valid_until < clock_timestamp()),
    'gl_events_waiting', (select count(*) from finance.gl_event e where e.company_id = me.company_id and e.status in ('pending','error')),
    'approvals_pending', (select count(*) from core.approval_request r where r.company_id = me.company_id and r.status = 'pending'));
end $$;

-- ---------------------------------------------------------------- F271: requirement registry
create function svc.v1_requirement_mark(p_feature_id text, p_kind text, p_ref text, p_status text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  insert into core.requirement_evidence (feature_id, kind, ref, status) values (p_feature_id, p_kind, p_ref, p_status)
  on conflict (feature_id, kind, ref) do update set status = excluded.status, recorded_at = clock_timestamp();
end $$;

create function api.v1_requirement_registry(p_status text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'features', (select count(distinct e.feature_id) from core.requirement_evidence e),
    'passed', (select count(distinct e.feature_id) from core.requirement_evidence e where e.status = 'passed'),
    'failed', (select count(distinct e.feature_id) from core.requirement_evidence e where e.status = 'failed'),
    'rows', coalesce((select jsonb_agg(jsonb_build_object('feature_id', e.feature_id, 'kind', e.kind, 'ref', e.ref, 'status', e.status) order by e.feature_id, e.kind)
                        from core.requirement_evidence e where p_status is null or e.status = p_status), '[]'::jsonb));
end $$;

insert into core.requirement_evidence (feature_id, kind, ref) values
  ('MOS-F153-001','migration','S04;S18'), ('MOS-F153-002','migration','S18'), ('MOS-F153-003','migration','S18'), ('MOS-F153-004','migration','S18'),
  ('MOS-F153-005','migration','S18'), ('MOS-F153-006','migration','S19'), ('MOS-F153-007','migration','S19'), ('MOS-F153-008','migration','S19'),
  ('MOS-F153-009','migration','S19'), ('MOS-F153-010','migration','S19'), ('MOS-F153-011','migration','S13'), ('MOS-F153-012','migration','S13'),
  ('MOS-F153-013','migration','S13'), ('MOS-F153-014','migration','S13'), ('MOS-F153-015','migration','S13'), ('MOS-F153-016','migration','S13'),
  ('MOS-F153-017','migration','S13'), ('MOS-F153-018','migration','S13'), ('MOS-F153-019','migration','S13'), ('MOS-F153-020','migration','S13'),
  ('MOS-F153-021','migration','S07;S15'), ('MOS-F153-022','migration','S06;S09;S15'), ('MOS-F153-023','migration','S15'), ('MOS-F153-024','migration','S15'),
  ('MOS-F153-025','migration','S15'), ('MOS-F153-026','migration','S09;S15'), ('MOS-F153-027','migration','S09;S15'), ('MOS-F153-028','migration','S15'),
  ('MOS-F153-029','migration','S14;S15'), ('MOS-F153-030','migration','S15'), ('MOS-F153-031','migration','S06;S15'), ('MOS-F153-032','migration','S15'),
  ('MOS-F153-033','migration','S15'), ('MOS-F153-034','migration','S15'), ('MOS-F153-035','migration','S15'), ('MOS-F153-036','migration','S09;S15'),
  ('MOS-F153-037','migration','S09;S15'), ('MOS-F153-038','migration','S06;S15'), ('MOS-F153-039','migration','S15'), ('MOS-F153-040','migration','S15'),
  ('MOS-F153-041','migration','S14'), ('MOS-F153-042','migration','S14'), ('MOS-F153-043','migration','S14'), ('MOS-F153-044','migration','S14'),
  ('MOS-F153-045','migration','S14'), ('MOS-F153-046','migration','S14'), ('MOS-F153-047','migration','S14'), ('MOS-F153-048','migration','S14'),
  ('MOS-F153-049','migration','S14'), ('MOS-F153-050','migration','S14'), ('MOS-F153-051','migration','S20'), ('MOS-F153-052','migration','S20'),
  ('MOS-F153-053','migration','S20'), ('MOS-F153-054','migration','S20'), ('MOS-F153-055','migration','S20'), ('MOS-F153-056','migration','S20'),
  ('MOS-F153-057','migration','S20'), ('MOS-F153-058','migration','S20'), ('MOS-F153-059','migration','S20'), ('MOS-F153-060','migration','S20'),
  ('MOS-F153-061','migration','S24'), ('MOS-F153-062','migration','S24'), ('MOS-F153-063','migration','S24'), ('MOS-F153-064','migration','S24'),
  ('MOS-F153-065','migration','S24'), ('MOS-F153-066','migration','S24'), ('MOS-F153-067','migration','S24'), ('MOS-F153-068','migration','S24'),
  ('MOS-F153-069','migration','S24'), ('MOS-F153-070','migration','S24'), ('MOS-F153-071','migration','S25'), ('MOS-F153-072','migration','S26-28'),
  ('MOS-F153-073','migration','S25'), ('MOS-F153-074','migration','S25'), ('MOS-F153-075','migration','S25'), ('MOS-F153-076','migration','S25'),
  ('MOS-F153-077','migration','S25'), ('MOS-F153-078','migration','S25'), ('MOS-F153-079','migration','S25'), ('MOS-F153-080','migration','S25'),
  ('MOS-F153-081','migration','S26-28'), ('MOS-F153-082','migration','S26-28'), ('MOS-F153-083','migration','S26-28'), ('MOS-F153-084','migration','S26-28'),
  ('MOS-F153-085','migration','S26-28'), ('MOS-F153-086','migration','S26-28'), ('MOS-F153-087','migration','S26-28'), ('MOS-F153-088','migration','S26-28'),
  ('MOS-F153-089','migration','S26-28'), ('MOS-F153-090','migration','S26-28'), ('MOS-F153-091','migration','S29-31'), ('MOS-F153-092','migration','S29-31'),
  ('MOS-F153-093','migration','S29-31'), ('MOS-F153-094','migration','S29-31'), ('MOS-F153-095','migration','S29-31'), ('MOS-F153-096','migration','S29-31'),
  ('MOS-F153-097','migration','S29-31'), ('MOS-F153-098','migration','S29-31'), ('MOS-F153-099','migration','S29-31'), ('MOS-F153-100','migration','S29-31'),
  ('MOS-F153-101','migration','S32-35'), ('MOS-F153-102','migration','S32-35'), ('MOS-F153-103','migration','S32-35'), ('MOS-F153-104','migration','S32-35'),
  ('MOS-F153-105','migration','S32-35'), ('MOS-F153-106','migration','S32-35'), ('MOS-F153-107','migration','S32-35'), ('MOS-F153-108','migration','S32-35'),
  ('MOS-F153-109','migration','S32-35'), ('MOS-F153-110','migration','S32-35'), ('MOS-F153-111','migration','S36-39'), ('MOS-F153-112','migration','S36-39'),
  ('MOS-F153-113','migration','S36-39'), ('MOS-F153-114','migration','S36-39'), ('MOS-F153-115','migration','S36-39'), ('MOS-F153-116','migration','S36-39'),
  ('MOS-F153-117','migration','S36-39'), ('MOS-F153-118','migration','S36-39'), ('MOS-F153-119','migration','S36-39'), ('MOS-F153-120','migration','S36-39'),
  ('MOS-F153-121','migration','S40'), ('MOS-F153-122','migration','S40'), ('MOS-F153-123','migration','S40'), ('MOS-F153-124','migration','S40'),
  ('MOS-F153-125','migration','S40'), ('MOS-F153-126','migration','S40'), ('MOS-F153-127','migration','S40'), ('MOS-F153-128','migration','S40'),
  ('MOS-F153-129','migration','S40'), ('MOS-F153-130','migration','S40'), ('MOS-F153-131','migration','S41-43'), ('MOS-F153-132','migration','S41-43'),
  ('MOS-F153-133','migration','S41-43'), ('MOS-F153-134','migration','S41-43'), ('MOS-F153-135','migration','S41-43'), ('MOS-F153-136','migration','S41-43'),
  ('MOS-F153-137','migration','S41-43'), ('MOS-F153-138','migration','S41-43'), ('MOS-F153-139','migration','S41-43'), ('MOS-F153-140','migration','S41-43'),
  ('MOS-F153-141','migration','S41-43'), ('MOS-F153-142','migration','S41-43'), ('MOS-F153-143','migration','S41-43'), ('MOS-F153-144','migration','S41-43'),
  ('MOS-F153-145','migration','S41-43'), ('MOS-F153-146','migration','S41-43'), ('MOS-F153-147','migration','S41-43'), ('MOS-F153-148','migration','S41-43'),
  ('MOS-F153-149','migration','S41-43'), ('MOS-F153-150','migration','S41-43'), ('MOS-F153-151','migration','S44-46'), ('MOS-F153-152','migration','S44-46'),
  ('MOS-F153-153','migration','S44-46'), ('MOS-F153-154','migration','S44-46'), ('MOS-F153-155','migration','S44-46'), ('MOS-F153-156','migration','S44-46'),
  ('MOS-F153-157','migration','S44-46'), ('MOS-F153-158','migration','S44-46'), ('MOS-F153-159','migration','S44-46'), ('MOS-F153-160','migration','S44-46'),
  ('MOS-F153-161','migration','S44-46'), ('MOS-F153-162','migration','S44-46'), ('MOS-F153-163','migration','S44-46'), ('MOS-F153-164','migration','S44-46'),
  ('MOS-F153-165','migration','S44-46'), ('MOS-F153-166','migration','S44-46'), ('MOS-F153-167','migration','S44-46'), ('MOS-F153-168','migration','S44-46'),
  ('MOS-F153-169','migration','S44-46'), ('MOS-F153-170','migration','S44-46'), ('MOS-F153-171','migration','S47-48'), ('MOS-F153-172','migration','S47-48'),
  ('MOS-F153-173','migration','S47-48'), ('MOS-F153-174','migration','S47-48'), ('MOS-F153-175','migration','S47-48'), ('MOS-F153-176','migration','S47-48'),
  ('MOS-F153-177','migration','S47-48'), ('MOS-F153-178','migration','S47-48'), ('MOS-F153-179','migration','S47-48'), ('MOS-F153-180','migration','S47-48'),
  ('MOS-F153-181','migration','S49'), ('MOS-F153-182','migration','S49'), ('MOS-F153-183','migration','S49'), ('MOS-F153-184','migration','S49'),
  ('MOS-F153-185','migration','S49'), ('MOS-F153-186','migration','S49'), ('MOS-F153-187','migration','S49'), ('MOS-F153-188','migration','S49'),
  ('MOS-F153-189','migration','S49'), ('MOS-F153-190','migration','S49'), ('MOS-F153-191','migration','S21'), ('MOS-F153-192','migration','S21'),
  ('MOS-F153-193','migration','S21'), ('MOS-F153-194','migration','S21'), ('MOS-F153-195','migration','S21'), ('MOS-F153-196','migration','S21'),
  ('MOS-F153-197','migration','S21'), ('MOS-F153-198','migration','S21'), ('MOS-F153-199','migration','S21'), ('MOS-F153-200','migration','S21'),
  ('MOS-F153-201','migration','S16'), ('MOS-F153-202','migration','S16'), ('MOS-F153-203','migration','S16'), ('MOS-F153-204','migration','S16'),
  ('MOS-F153-205','migration','S16'), ('MOS-F153-206','migration','S16'), ('MOS-F153-207','migration','S16'), ('MOS-F153-208','migration','S16'),
  ('MOS-F153-209','migration','S06;S16'), ('MOS-F153-210','migration','S16'), ('MOS-F153-211','migration','S22'), ('MOS-F153-212','migration','S22'),
  ('MOS-F153-213','migration','S22'), ('MOS-F153-214','migration','S22'), ('MOS-F153-215','migration','S22'), ('MOS-F153-216','migration','S22'),
  ('MOS-F153-217','migration','S22'), ('MOS-F153-218','migration','S22'), ('MOS-F153-219','migration','S22'), ('MOS-F153-220','migration','S22'),
  ('MOS-F153-221','migration','S49'), ('MOS-F153-222','migration','S49'), ('MOS-F153-223','migration','S49'), ('MOS-F153-224','migration','S49'),
  ('MOS-F153-225','migration','S49'), ('MOS-F153-226','migration','S49'), ('MOS-F153-227','migration','S49'), ('MOS-F153-228','migration','S49'),
  ('MOS-F153-229','migration','S49'), ('MOS-F153-230','migration','S49'), ('MOS-F153-231','migration','S50'), ('MOS-F153-232','migration','S50'),
  ('MOS-F153-233','migration','S50'), ('MOS-F153-234','migration','S50'), ('MOS-F153-235','migration','S50'), ('MOS-F153-236','migration','S50'),
  ('MOS-F153-237','migration','S50'), ('MOS-F153-238','migration','S50'), ('MOS-F153-239','migration','S50'), ('MOS-F153-240','migration','S50'),
  ('MOS-F153-241','migration','S51'), ('MOS-F153-242','migration','S51'), ('MOS-F153-243','migration','S51'), ('MOS-F153-244','migration','S51'),
  ('MOS-F153-245','migration','S51'), ('MOS-F153-246','migration','S51'), ('MOS-F153-247','migration','S51'), ('MOS-F153-248','migration','S51'),
  ('MOS-F153-249','migration','S51'), ('MOS-F153-250','migration','S51'), ('MOS-F153-251','migration','S53'), ('MOS-F153-252','migration','S53'),
  ('MOS-F153-253','migration','S53'), ('MOS-F153-254','migration','S53'), ('MOS-F153-255','migration','S53'), ('MOS-F153-256','migration','S53'),
  ('MOS-F153-257','migration','S53'), ('MOS-F153-258','migration','S53'), ('MOS-F153-259','migration','S53'), ('MOS-F153-260','migration','S53'),
  ('MOS-F153-261','migration','S02;S05;S22'), ('MOS-F153-262','migration','S12'), ('MOS-F153-263','migration','S12'), ('MOS-F153-264','migration','S12'),
  ('MOS-F153-265','migration','S12'), ('MOS-F153-266','migration','S22'), ('MOS-F153-267','migration','S09;S22;S55'), ('MOS-F153-268','migration','S09;S22;S55'),
  ('MOS-F153-269','migration','S22'), ('MOS-F153-270','migration','S22'), ('MOS-F153-271','migration','S54-55'), ('MOS-F153-272','migration','S54-55'),
  ('MOS-F153-273','migration','S54-55'), ('MOS-F153-274','migration','S54-55'), ('MOS-F153-275','migration','S54-55'), ('MOS-F153-276','migration','S54-55'),
  ('MOS-F153-277','migration','S54-55'), ('MOS-F153-278','migration','S54-55'), ('MOS-F153-279','migration','S54-55'), ('MOS-F153-280','migration','S54-55'),
  ('MOS-F153-281','migration','S11'), ('MOS-F153-282','migration','S11'), ('MOS-F153-283','migration','S11'), ('MOS-F153-284','migration','S11'),
  ('MOS-F153-285','migration','S11'), ('MOS-F153-286','migration','S11'), ('MOS-F153-287','migration','S11'), ('MOS-F153-288','migration','S11'),
  ('MOS-F153-289','migration','S11'), ('MOS-F153-290','migration','S11'), ('MOS-F153-291','migration','S52'), ('MOS-F153-292','migration','S52'),
  ('MOS-F153-293','migration','S52'), ('MOS-F153-294','migration','S52'), ('MOS-F153-295','migration','S52'), ('MOS-F153-296','migration','S52'),
  ('MOS-F153-297','migration','S52'), ('MOS-F153-298','migration','S52'), ('MOS-F153-299','migration','S52'), ('MOS-F153-300','migration','S52') on conflict do nothing;

-- ---------------------------------------------------------------- F275: deny-by-default probe
-- RLS is forced on every table and no API role has a policy, so rows are never visible directly. This probe additionally reports
-- any direct table privilege of an API role (it records a FAILED evidence row and warns; the release gate reads that row).
do $$
declare v text;
begin
  select string_agg(n.nspname || '.' || c.relname, ', ') into v
    from pg_class c join pg_namespace n on n.oid = c.relnamespace join pg_roles r on r.rolname in ('authenticated','anon')
   where c.relkind = 'r' and n.nspname in ('core','iam','config','design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify','location','hardware')
     and has_table_privilege(r.oid, c.oid, 'select');
  insert into core.requirement_evidence (feature_id, kind, ref, status)
  values ('MOS-F153-275', 'ci', 'no direct table privilege for API roles', case when v is null then 'passed' else 'failed' end)
  on conflict (feature_id, kind, ref) do update set status = excluded.status, recorded_at = clock_timestamp();
  if v is not null then raise warning 'API roles hold direct table privileges (rows stay hidden by RLS, but revoke them): %', left(v, 400); end if;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'grant execute on function api.v1_governance_check() to authenticated';
    execute 'grant execute on function api.v1_requirement_registry(text) to authenticated';
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_delegations_expire() to service_role';
    execute 'grant execute on function svc.v1_requirement_mark(text, text, text, text) to service_role';
  end if;
end $$;

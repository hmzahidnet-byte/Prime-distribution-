-- 20261108001600_ui_shell.sql  (S17)
-- Android shell bootstrap: one read for everything the app frame needs for the CURRENT position — bottom tabs
-- (Chairman setting ui.nav.bottom_tabs, now restricted to known tab keys), theme colour, language, enabled modules
-- (company + wing), feature flags, MFA positions and offline-draft limits. Every member with an active position may
-- read it (unlike the settings editor, which needs config.settings.read). Values are hints for the UI; the server
-- re-authorises every action.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

update config.setting_definition
   set allowed_values = '["home","tasks","reports","search","scan","forms","more"]'::jsonb,
       description_bn = 'নিচের নেভিগেশন-ট্যাব (সর্বোচ্চ ৫টি দেখানো হয়; "more" সবসময় শেষে থাকে)'
 where key = 'ui.nav.bottom_tabs';

create function api.v1_ui_config() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object(
    'company_id', me.company_id, 'position_code', me.position_code, 'is_supreme', me.is_supreme,
    'tabs', config.fn_get(me.company_id, 'ui.nav.bottom_tabs'),
    'theme_primary', config.fn_get(me.company_id, 'ui.theme.primary'),
    'language', config.fn_get(me.company_id, 'ui.language'),
    'modules', coalesce((select jsonb_agg(m.module_code order by m.module_code) from config.company_module m
                          where m.company_id = me.company_id and m.status = 'enabled'
                            and (m.wing_ids is null or me.home_wing_id = any (m.wing_ids))), '[]'::jsonb),
    'flags', coalesce((select jsonb_object_agg(d.key, config.fn_flag(me.company_id, d.key, me.home_wing_id))
                         from config.feature_flag_definition d where d.status = 'active'), '{}'::jsonb),
    'mfa_positions', config.fn_get(me.company_id, 'iam.mfa.required_positions'),
    'offline', jsonb_build_object('draft_ttl_days', config.fn_get_int(me.company_id, 'forms.offline.draft_ttl_days'),
                                  'max_drafts', config.fn_get_int(me.company_id, 'forms.offline.max_drafts')));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'grant execute on function api.v1_ui_config() to authenticated';
  end if;
end $$;

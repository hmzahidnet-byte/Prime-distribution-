-- 20261108001500_auth_login_identity.sql  (S16)
-- Login & identity (blueprint LOGIN_IDENTITY, MOS-F153-201..210):
--   201 mobile onboarding: only an invited, OTP-verified mobile number becomes a login (self sign-up stays disabled)
--   202 PIN enrollment after a fresh OTP; bcrypt verifier only (never plaintext, never logged)
--   203 PIN login through the Edge Function `auth-pin-login` (service role) -> svc.v1_auth_pin_verify: rate limit per
--       number, lockout per person, generic failures (no account enumeration)
--   204 OTP recovery resets the PIN; an OTP session is aal1 and never satisfies MFA
--   205 Chairman MFA: CHAIRMAN can never be removed from iam.mfa.required_positions; PIN sessions can never claim aal2
--   206 devices: registration (bounded per person), revoke = that device's sessions die at the next request
--   207 PIN sessions: short access token minted by the Edge Function, rotating device-bound refresh token, reuse
--       detection, per-RPC liveness check (iam.fn_require_person) — termination / revocation is immediate
--   208 multi-company selector (authorised memberships only) · 209 position selector (S06 api.v1_iam_my_positions)
--   210 login security audit: every attempt recorded (never PIN/OTP), lockout + manager unlock
-- Closes OI-11 (server-side sign-out for PIN sessions; native sessions via Edge Function) and OI-12 (invitation claim).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ helpers
-- Canonical mobile number: +8801XXXXXXXXX for Bangladesh; other numbers +<digits>. Null when not a phone number.
create function core.fn_phone_canonical(p text) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare d text := regexp_replace(coalesce(p, ''), '[^0-9]', '', 'g');
begin
  if d ~ '^8801[3-9][0-9]{8}$' then return '+' || d; end if;
  if d ~ '^01[3-9][0-9]{8}$' then return '+88' || d; end if;
  if length(d) between 8 and 15 then return '+' || d; end if;
  return null;
end $$;
create index person_phone_canonical on core.person (core.fn_phone_canonical(phone)) where phone is not null;

create function iam.fn_sha256(p text) returns text
language sql immutable set search_path = pg_catalog, public, extensions as $$
  select encode(digest(coalesce(p, ''), 'sha256'), 'hex')
$$;

-- Login policy for a person = the STRICTEST value across the companies they belong to (defaults when none).
create function iam.fn_auth_int(p_person uuid, p_key text, p_pick text) returns integer
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v integer;
begin
  select case when p_pick = 'max' then max(config.fn_get_int(m.company_id, p_key)) else min(config.fn_get_int(m.company_id, p_key)) end into v
    from iam.company_membership m where m.person_id = p_person and m.status in ('invited','active','suspended');
  if v is null then select (d.default_value #>> '{}')::integer into v from config.setting_definition d where d.key = p_key; end if;
  return v;
end $$;

-- Is there a fresh OTP proof in this JWT? (Supabase amr: [{"method":"otp","timestamp":<epoch>}])
create function iam.fn_otp_fresh(p_minutes integer) returns boolean
language plpgsql stable set search_path = pg_catalog as $$
declare v_amr jsonb;
begin
  v_amr := nullif(current_setting('request.jwt.claims', true), '')::jsonb -> 'amr';
  if jsonb_typeof(v_amr) <> 'array' then return false; end if;
  return exists (select 1 from jsonb_array_elements(v_amr) x
                  where x ->> 'method' in ('otp','sms','phone')
                    and (x ->> 'timestamp')::numeric >= extract(epoch from clock_timestamp()) - p_minutes * 60);
exception when others then return false;
end $$;

-- PIN policy: digits only, exact length, not trivially guessable.
create function iam.fn_pin_policy_error(p_pin text, p_len integer) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare i integer; asc_ok boolean := true; desc_ok boolean := true;
begin
  if p_pin is null or p_pin !~ '^[0-9]+$' then return 'digits'; end if;
  if length(p_pin) <> p_len then return 'length'; end if;
  if p_pin ~ '^(.)\1+$' then return 'repeated'; end if;
  for i in 2..length(p_pin) loop
    if (substr(p_pin, i, 1)::integer - substr(p_pin, i - 1, 1)::integer + 10) % 10 <> 1 then asc_ok := false; end if;
    if (substr(p_pin, i - 1, 1)::integer - substr(p_pin, i, 1)::integer + 10) % 10 <> 1 then desc_ok := false; end if;
  end loop;
  if asc_ok or desc_ok then return 'sequence'; end if;
  if p_pin in ('121212','123123','112233','101010','696969','007007','131313','202020','212121') then return 'common'; end if;
  return null;
end $$;

-- ================================================================ tables
create table iam.login_invitation (
  id                   uuid primary key default gen_random_uuid(),
  company_id           uuid not null references core.company(id),
  membership_id        uuid not null,
  person_id            uuid not null references core.person(id),
  phone_canonical      text not null check (phone_canonical ~ '^\+[0-9]{8,15}$'),
  status               text not null default 'open' check (status in ('open','claimed','revoked')),
  expires_at           timestamptz not null,
  reason               text not null check (length(btrim(reason)) > 0),
  created_by           uuid references core.person(id),
  created_at           timestamptz not null default clock_timestamp(),
  claimed_at           timestamptz,
  claimed_auth_user_id uuid,
  check ((status = 'claimed') = (claimed_at is not null)),
  foreign key (membership_id, company_id) references iam.company_membership (id, company_id)
);
create index login_invitation_open on iam.login_invitation (phone_canonical) where status = 'open';
create trigger trg_login_invitation_nodel before delete on iam.login_invitation for each row execute function core.fn_deny_delete();
create trigger trg_login_invitation_audit after insert or update on iam.login_invitation for each row execute function audit.fn_row_change();

create table iam.login_pin (
  person_id      uuid primary key references core.person(id),
  pin_hash       text not null,
  set_via        text not null check (set_via in ('enroll','otp_reset','change')),
  set_at         timestamptz not null default clock_timestamp(),
  failed_count   integer not null default 0 check (failed_count >= 0),
  locked_until   timestamptz,
  last_failed_at timestamptz,
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1
);
create trigger trg_login_pin_touch before update on iam.login_pin for each row execute function core.fn_touch_row();
create trigger trg_login_pin_nodel before delete on iam.login_pin for each row execute function core.fn_deny_delete();

create table iam.device (
  id             uuid primary key default gen_random_uuid(),
  person_id      uuid not null references core.person(id),
  device_hash    text not null check (device_hash ~ '^[0-9a-f]{64}$'),
  name           text not null default 'ডিভাইস' check (length(name) between 1 and 80),
  platform       text not null default 'android' check (platform in ('android','ios','web')),
  status         text not null default 'active' check (status in ('active','revoked')),
  registered_at  timestamptz not null default clock_timestamp(),
  last_seen_at   timestamptz not null default clock_timestamp(),
  revoked_at     timestamptz,
  revoke_reason  text,
  check ((status = 'revoked') = (revoked_at is not null))
);
create unique index device_one_active on iam.device (person_id, device_hash) where status = 'active';
create trigger trg_device_nodel before delete on iam.device for each row execute function core.fn_deny_delete();

create table iam.auth_session (
  id                 uuid primary key default gen_random_uuid(),
  person_id          uuid not null references core.person(id),
  auth_user_id       uuid not null,
  device_id          uuid not null references iam.device(id),
  refresh_hash       text not null unique,
  prev_refresh_hash  text,
  rotation           integer not null default 0,
  status             text not null default 'active' check (status in ('active','revoked')),
  created_at         timestamptz not null default clock_timestamp(),
  last_refreshed_at  timestamptz,
  refresh_expires_at timestamptz not null,
  revoked_at         timestamptz,
  revoke_reason      text,
  check ((status = 'revoked') = (revoked_at is not null))
);
create index auth_session_person on iam.auth_session (person_id) where status = 'active';
create index auth_session_prev on iam.auth_session (prev_refresh_hash) where prev_refresh_hash is not null;
create trigger trg_auth_session_nodel before delete on iam.auth_session for each row execute function core.fn_deny_delete();

-- Every login-related attempt (F210). Never contains a PIN, an OTP or a refresh token; numbers only as SHA-256.
create table iam.login_attempt (
  id            bigint generated always as identity primary key,
  occurred_at   timestamptz not null default clock_timestamp(),
  kind          text not null check (kind in ('pin_login','refresh','otp_start','otp_claim','pin_set','pin_change','device','sign_out','unlock')),
  outcome       text not null check (outcome in ('success','failed','locked','denied')),
  reason        text,
  phone_hash    text,
  person_id     uuid,
  device_hash   text,
  session_id    uuid
);
create index login_attempt_phone on iam.login_attempt (phone_hash, occurred_at desc);
create index login_attempt_person on iam.login_attempt (person_id, occurred_at desc);
create trigger trg_login_attempt_no_mutation before update or delete on iam.login_attempt for each row execute function core.fn_deny_mutation();

-- Person-level security changes go to the GLOBAL audit chain (no company), with secrets removed.
create function iam.fn_auth_audit_global() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v jsonb := to_jsonb(new) - array['pin_hash','refresh_hash','prev_refresh_hash'];
begin
  perform audit.fn_append_global(lower(tg_op) || ':iam.' || tg_table_name, 'iam.' || tg_table_name,
                                 coalesce((v ->> 'id')::uuid, (v ->> 'person_id')::uuid), 'success', v,
                                 nullif(current_setting('mohona.change_reason', true), ''), (v ->> 'person_id')::uuid);
  return null;
end $$;
create trigger trg_login_pin_audit after insert or update on iam.login_pin for each row execute function iam.fn_auth_audit_global();
create trigger trg_device_audit after insert or update on iam.device for each row execute function iam.fn_auth_audit_global();
create trigger trg_auth_session_audit after insert or update of status on iam.auth_session for each row execute function iam.fn_auth_audit_global();

select core.fn_apply_rls('iam', 'login_invitation');
select core.fn_apply_rls('iam', 'login_pin');
select core.fn_apply_rls('iam', 'device');
select core.fn_apply_rls('iam', 'auth_session');
select core.fn_apply_rls('iam', 'login_attempt');

create function iam.fn_login_log(p_kind text, p_outcome text, p_reason text, p_phone text, p_person uuid, p_device_hash text, p_session uuid default null)
returns void language plpgsql security definer set search_path = pg_catalog as $$
begin
  insert into iam.login_attempt (kind, outcome, reason, phone_hash, person_id, device_hash, session_id)
  values (p_kind, p_outcome, left(p_reason, 100), case when p_phone is null then null else iam.fn_sha256(core.fn_phone_canonical(p_phone)) end,
          p_person, p_device_hash, p_session);
end $$;

-- ================================================================ settings
insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('auth.pin.length',               'auth', 'int', '6', 4, 8, null, 'PIN-এর দৈর্ঘ্য', 'MOS-F153-202', true, 800),
  ('auth.pin.max_failures',         'auth', 'int', '5', 3, 20, null, 'কতবার ভুল PIN-এ লক', 'MOS-F153-203', true, 810),
  ('auth.pin.lock_minutes',         'auth', 'int', '15', 1, 1440, null, 'লকের মেয়াদ (মিনিট)', 'MOS-F153-203', true, 820),
  ('auth.pin.rate_window_minutes',  'auth', 'int', '15', 1, 1440, null, 'নম্বরপ্রতি চেষ্টার সময়-জানালা (মিনিট)', 'MOS-F153-203', true, 830),
  ('auth.pin.rate_max_attempts',    'auth', 'int', '10', 3, 100, null, 'জানালায় নম্বরপ্রতি সর্বোচ্চ চেষ্টা', 'MOS-F153-203', true, 840),
  ('auth.otp.fresh_minutes',        'auth', 'int', '10', 1, 60, null, 'OTP-যাচাই কত মিনিট বৈধ (PIN সেট/রিসেট)', 'MOS-F153-204', true, 850),
  ('auth.session.access_minutes',   'auth', 'int', '15', 5, 60, null, 'অ্যাক্সেস-টোকেনের মেয়াদ (মিনিট)', 'MOS-F153-207', true, 860),
  ('auth.session.refresh_days',     'auth', 'int', '30', 1, 180, null, 'ডিভাইসে লগইন টিকে থাকার মেয়াদ (দিন)', 'MOS-F153-207', true, 870),
  ('auth.device.max_per_person',    'auth', 'int', '3', 1, 10, null, 'একজনের সর্বোচ্চ সক্রিয় ডিভাইস', 'MOS-F153-206', true, 880),
  ('auth.invitation.valid_days',    'auth', 'int', '7', 1, 60, null, 'লগইন-আমন্ত্রণের মেয়াদ (দিন)', 'MOS-F153-201', true, 890);

-- F205: the Chairman can never be removed from the MFA list (no downgrade from any editor).
create function config.fn_mfa_list_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.key = 'iam.mfa.required_positions' and new.status = 'active' and not (new.value @> '["CHAIRMAN"]'::jsonb) then
    raise exception 'E_SETTING_INVALID: CHAIRMAN always requires MFA' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_setting_value_mfa_guard before insert on config.setting_value for each row execute function config.fn_mfa_list_guard();

-- ================================================================ per-request session liveness (F206/F207, OI-11)
-- A PIN session (minted by the Edge Function, id = JWT session_id) must still be active and unexpired, and can never
-- claim MFA. Native Supabase sessions have no row here and keep their GoTrue lifecycle.
create function iam.fn_assert_session_live() returns void
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v_sid text := core.fn_jwt_claim('session_id'); s iam.auth_session%rowtype;
begin
  if v_sid is null or v_sid !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then return; end if;
  select * into s from iam.auth_session where id = v_sid::uuid;
  if not found then return; end if;
  if s.status <> 'active' or s.refresh_expires_at <= clock_timestamp() then
    perform core.fn_raise('E_SESSION_REVOKED', 'device session ended');
  end if;
  if s.auth_user_id <> core.fn_jwt_sub() then perform core.fn_raise('E_AUTH', 'session does not belong to this login'); end if;
  if core.fn_jwt_claim('aal') is distinct from 'aal1' then perform core.fn_raise('E_AUTH', 'a PIN session is never MFA'); end if;
end $$;

create or replace function iam.fn_require_person() returns uuid
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  perform set_config('mohona.company_scope', '', true);
  v := iam.fn_current_person();
  if v is null then perform core.fn_raise('E_AUTH', 'no active person for this login'); end if;
  perform iam.fn_assert_session_live();
  return v;
end $$;

-- ================================================================ service functions (Edge Functions only; service_role)
-- Called before an OTP is sent: only invited or already-linked numbers get one (self sign-up stays closed); rate-limited.
create function svc.v1_auth_otp_allowed(p_phone text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_phone text := core.fn_phone_canonical(p_phone); v_n integer; v_ok boolean;
begin
  if v_phone is null then return jsonb_build_object('allowed', false); end if;
  select count(*) into v_n from iam.login_attempt a
   where a.phone_hash = iam.fn_sha256(v_phone) and a.kind = 'otp_start' and a.occurred_at > clock_timestamp() - interval '15 minutes';
  if v_n >= 5 then
    perform iam.fn_login_log('otp_start', 'locked', 'rate', v_phone, null, null);
    return jsonb_build_object('allowed', false, 'retry_after_seconds', 900);
  end if;
  v_ok := exists (select 1 from iam.login_invitation i where i.phone_canonical = v_phone and i.status = 'open' and i.expires_at > clock_timestamp())
       or exists (select 1 from core.person p join iam.person_auth_link l on l.person_id = p.id and l.status = 'active'
                   where core.fn_phone_canonical(p.phone) = v_phone and p.status = 'active');
  perform iam.fn_login_log('otp_start', case when v_ok then 'success' else 'denied' end, case when v_ok then null else 'not invited' end, v_phone, null, null);
  return jsonb_build_object('allowed', v_ok, 'phone', case when v_ok then v_phone end);
end $$;

-- Registers (or touches) a device for a person. A revoked device id never comes back through PIN login (needs OTP).
create function iam.fn_device_upsert(p_person uuid, p_device_hash text, p_name text, p_platform text, p_allow_revoked boolean) returns uuid
language plpgsql security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  select d.id into v from iam.device d where d.person_id = p_person and d.device_hash = p_device_hash and d.status = 'active';
  if v is not null then
    update iam.device set last_seen_at = clock_timestamp() where id = v;
    return v;
  end if;
  if not p_allow_revoked and exists (select 1 from iam.device d where d.person_id = p_person and d.device_hash = p_device_hash and d.status = 'revoked') then
    raise exception 'E_DEVICE_REVOKED: this device was revoked; verify by OTP to register it again' using errcode = 'P0001';
  end if;
  if (select count(*) from iam.device d where d.person_id = p_person and d.status = 'active') >= iam.fn_auth_int(p_person, 'auth.device.max_per_person', 'min') then
    raise exception 'E_DEVICE_LIMIT: remove an old device first' using errcode = 'P0001';
  end if;
  insert into iam.device (person_id, device_hash, name, platform)
  values (p_person, p_device_hash, coalesce(nullif(btrim(left(p_name, 80)), ''), 'ডিভাইস'), coalesce(p_platform, 'android'))
  returning id into v;
  return v;
end $$;

create function iam.fn_new_session(p_person uuid, p_auth_user uuid, p_device uuid) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_token text := encode(gen_random_bytes(32), 'hex'); v_id uuid; v_exp timestamptz;
begin
  v_exp := clock_timestamp() + make_interval(days => iam.fn_auth_int(p_person, 'auth.session.refresh_days', 'min'));
  insert into iam.auth_session (person_id, auth_user_id, device_id, refresh_hash, refresh_expires_at)
  values (p_person, p_auth_user, p_device, iam.fn_sha256(v_token), v_exp) returning id into v_id;
  return jsonb_build_object('session_id', v_id, 'refresh_token', v_token, 'refresh_expires_at', v_exp,
                            'access_minutes', iam.fn_auth_int(p_person, 'auth.session.access_minutes', 'min'));
end $$;

-- PIN login (F203). Every failure looks the same to the caller; details go to iam.login_attempt only.
create function svc.v1_auth_pin_verify(p_phone text, p_pin text, p_device_id text, p_device_name text, p_platform text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_phone text := core.fn_phone_canonical(p_phone); v_dev text; v_n integer; v_person uuid; v_user uuid; pin iam.login_pin%rowtype;
        v_device uuid; j jsonb; v_max integer;
begin
  perform set_config('mohona.company_scope', '', true);
  if v_phone is null or coalesce(p_device_id, '') !~ '^[A-Za-z0-9_-]{16,128}$' then
    perform iam.fn_login_log('pin_login', 'failed', 'bad input', p_phone, null, null);
    return jsonb_build_object('ok', false, 'error', 'E_AUTH_FAILED');
  end if;
  v_dev := iam.fn_sha256(p_device_id);
  select count(*) into v_n from iam.login_attempt a
   where a.phone_hash = iam.fn_sha256(v_phone) and a.kind = 'pin_login' and a.outcome <> 'success'
     and a.occurred_at > clock_timestamp() - make_interval(mins => (select (d.default_value #>> '{}')::integer from config.setting_definition d where d.key = 'auth.pin.rate_window_minutes'));
  if v_n >= (select (d.default_value #>> '{}')::integer from config.setting_definition d where d.key = 'auth.pin.rate_max_attempts') then
    perform iam.fn_login_log('pin_login', 'locked', 'rate limit', v_phone, null, v_dev);
    return jsonb_build_object('ok', false, 'error', 'E_AUTH_LOCKED');
  end if;
  select p.id into v_person from core.person p where core.fn_phone_canonical(p.phone) = v_phone and p.status = 'active';
  select l.auth_user_id into v_user from iam.person_auth_link l where l.person_id = v_person and l.status = 'active';
  select * into pin from iam.login_pin where person_id = v_person for update;
  if v_person is null or v_user is null or pin.person_id is null
     or not exists (select 1 from iam.company_membership m join core.company c on c.id = m.company_id
                     where m.person_id = v_person and m.status = 'active' and c.status = 'active') then
    perform iam.fn_login_log('pin_login', 'failed', case when v_person is null then 'unknown number' when pin.person_id is null then 'no pin' else 'no active membership' end,
                             v_phone, v_person, v_dev);
    return jsonb_build_object('ok', false, 'error', 'E_AUTH_FAILED');
  end if;
  if pin.locked_until is not null and pin.locked_until > clock_timestamp() then
    perform iam.fn_login_log('pin_login', 'locked', 'person locked', v_phone, v_person, v_dev);
    return jsonb_build_object('ok', false, 'error', 'E_AUTH_LOCKED', 'locked_until', pin.locked_until);
  end if;
  if crypt(coalesce(p_pin, ''), pin.pin_hash) <> pin.pin_hash then
    v_max := iam.fn_auth_int(v_person, 'auth.pin.max_failures', 'min');
    update iam.login_pin set failed_count = pin.failed_count + 1, last_failed_at = clock_timestamp(),
           locked_until = case when pin.failed_count + 1 >= v_max then clock_timestamp() + make_interval(mins => iam.fn_auth_int(v_person, 'auth.pin.lock_minutes', 'max')) end
     where person_id = v_person;
    perform iam.fn_login_log('pin_login', case when pin.failed_count + 1 >= v_max then 'locked' else 'failed' end, 'wrong pin', v_phone, v_person, v_dev);
    return jsonb_build_object('ok', false, 'error', case when pin.failed_count + 1 >= v_max then 'E_AUTH_LOCKED' else 'E_AUTH_FAILED' end);
  end if;
  begin
    v_device := iam.fn_device_upsert(v_person, v_dev, p_device_name, p_platform, false);
  exception when others then
    perform iam.fn_login_log('pin_login', 'denied', split_part(sqlerrm, ':', 1), v_phone, v_person, v_dev);
    return jsonb_build_object('ok', false, 'error', split_part(sqlerrm, ':', 1));
  end;
  update iam.login_pin set failed_count = 0, locked_until = null where person_id = v_person;
  j := iam.fn_new_session(v_person, v_user, v_device);
  perform iam.fn_login_log('pin_login', 'success', null, v_phone, v_person, v_dev, (j ->> 'session_id')::uuid);
  return j || jsonb_build_object('ok', true, 'auth_user_id', v_user, 'person_id', v_person, 'device_id', v_device);
end $$;

-- Refresh with rotation (F207). Reusing an already-rotated token = theft signal: the whole session is revoked.
create function svc.v1_auth_refresh(p_refresh_token text, p_device_id text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare s iam.auth_session%rowtype; v_hash text := iam.fn_sha256(p_refresh_token); v_token text := encode(gen_random_bytes(32), 'hex'); d iam.device%rowtype;
begin
  perform set_config('mohona.company_scope', '', true);
  select * into s from iam.auth_session where refresh_hash = v_hash for update;
  if not found then
    select * into s from iam.auth_session where prev_refresh_hash = v_hash for update;
    if found and s.status = 'active' then
      perform set_config('mohona.change_reason', 'refresh token reuse', true);
      update iam.auth_session set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'refresh token reuse' where id = s.id;
      perform iam.fn_login_log('refresh', 'denied', 'token reuse', null, s.person_id, null, s.id);
    else
      perform iam.fn_login_log('refresh', 'failed', 'unknown token', null, null, null);
    end if;
    return jsonb_build_object('ok', false, 'error', 'E_SESSION_REVOKED');
  end if;
  select * into d from iam.device where id = s.device_id;
  if s.status <> 'active' or s.refresh_expires_at <= clock_timestamp() or d.status <> 'active' or d.device_hash <> iam.fn_sha256(p_device_id)
     or not exists (select 1 from iam.person_auth_link l where l.person_id = s.person_id and l.auth_user_id = s.auth_user_id and l.status = 'active')
     or not exists (select 1 from iam.company_membership m where m.person_id = s.person_id and m.status = 'active') then
    if s.status = 'active' then
      perform set_config('mohona.change_reason', 'refresh refused', true);
      update iam.auth_session set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'refresh refused' where id = s.id;
    end if;
    perform iam.fn_login_log('refresh', 'denied', 'session not usable', null, s.person_id, d.device_hash, s.id);
    return jsonb_build_object('ok', false, 'error', 'E_SESSION_REVOKED');
  end if;
  update iam.auth_session set prev_refresh_hash = s.refresh_hash, refresh_hash = iam.fn_sha256(v_token), rotation = s.rotation + 1,
         last_refreshed_at = clock_timestamp() where id = s.id;
  update iam.device set last_seen_at = clock_timestamp() where id = s.device_id;
  perform iam.fn_login_log('refresh', 'success', null, null, s.person_id, d.device_hash, s.id);
  return jsonb_build_object('ok', true, 'session_id', s.id, 'auth_user_id', s.auth_user_id, 'person_id', s.person_id, 'refresh_token', v_token,
                            'access_minutes', iam.fn_auth_int(s.person_id, 'auth.session.access_minutes', 'min'), 'refresh_expires_at', s.refresh_expires_at);
end $$;

-- Native (GoTrue) sessions of a login: deleted when the platform allows it (best-effort; PIN sessions are revoked in iam).
create function svc.v1_auth_kill_native_sessions(p_auth_user uuid) returns integer
language plpgsql security definer set search_path = '' as $$
declare n integer := 0;
begin
  if to_regclass('auth.sessions') is null then return 0; end if;
  execute 'delete from auth.sessions where user_id = $1' using p_auth_user;
  get diagnostics n = row_count;
  return n;
exception when insufficient_privilege then
  return -1;
end $$;

-- ================================================================ app API (authenticated)
-- F201 / OI-12: an OTP-verified phone claims its open invitation -> the login is linked to the person.
create function api.v1_auth_claim_invitation() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_user uuid := core.fn_jwt_sub(); v_phone text := core.fn_phone_canonical(core.fn_jwt_claim('phone')); i iam.login_invitation%rowtype;
begin
  if v_user is null then perform core.fn_raise('E_AUTH'); end if;
  if v_phone is null or not iam.fn_otp_fresh(10) then
    perform iam.fn_login_log('otp_claim', 'denied', 'no fresh otp', v_phone, null, null);
    perform core.fn_raise('E_OTP_REQUIRED');
  end if;
  select * into i from iam.login_invitation x
   where x.phone_canonical = v_phone and x.status = 'open' and x.expires_at > clock_timestamp()
   order by x.created_at desc limit 1 for update;
  if not found then
    perform iam.fn_login_log('otp_claim', 'denied', 'no invitation', v_phone, null, null);
    perform core.fn_raise('E_NOT_INVITED');
  end if;
  perform set_config('mohona.change_reason', 'invitation claimed', true);
  update iam.person_auth_link set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'replaced by invitation'
   where status = 'active' and (person_id = i.person_id or auth_user_id = v_user) and not (person_id = i.person_id and auth_user_id = v_user);
  if not exists (select 1 from iam.person_auth_link l where l.person_id = i.person_id and l.auth_user_id = v_user and l.status = 'active') then
    insert into iam.person_auth_link (person_id, auth_user_id) values (i.person_id, v_user);
  end if;
  update iam.login_invitation set status = 'claimed', claimed_at = clock_timestamp(), claimed_auth_user_id = v_user
   where person_id = i.person_id and status = 'open' and phone_canonical = v_phone;
  update iam.company_membership set status = 'active' where person_id = i.person_id and status = 'invited';
  perform iam.fn_login_log('otp_claim', 'success', null, v_phone, i.person_id, null);
  return jsonb_build_object('person_id', i.person_id, 'needs_pin', not exists (select 1 from iam.login_pin p where p.person_id = i.person_id));
end $$;

-- F202 / F204: set (enroll) or reset (recovery) the PIN — always behind a fresh OTP. Reset ends every other PIN session.
create function api.v1_auth_set_pin(p_pin text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_person uuid := iam.fn_require_person(); v_err text; v_exists boolean;
begin
  if not iam.fn_otp_fresh(iam.fn_auth_int(v_person, 'auth.otp.fresh_minutes', 'min')) then
    perform iam.fn_login_log('pin_set', 'denied', 'no fresh otp', null, v_person, null);
    perform core.fn_raise('E_OTP_REQUIRED');
  end if;
  v_err := iam.fn_pin_policy_error(p_pin, iam.fn_auth_int(v_person, 'auth.pin.length', 'max'));
  if v_err is not null then perform core.fn_raise('E_PIN_WEAK', v_err); end if;
  v_exists := exists (select 1 from iam.login_pin p where p.person_id = v_person);
  perform set_config('mohona.change_reason', case when v_exists then 'pin reset by otp' else 'pin enrolled' end, true);
  insert into iam.login_pin (person_id, pin_hash, set_via) values (v_person, crypt(p_pin, gen_salt('bf', 10)), 'enroll')
  on conflict (person_id) do update set pin_hash = excluded.pin_hash, set_via = 'otp_reset', set_at = clock_timestamp(),
                                        failed_count = 0, locked_until = null;
  if v_exists then
    update iam.auth_session set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'pin reset'
     where person_id = v_person and status = 'active';
  end if;
  perform iam.fn_login_log('pin_set', 'success', case when v_exists then 'reset' else 'enroll' end, null, v_person, null);
  return jsonb_build_object('status', case when v_exists then 'reset' else 'enrolled' end);
end $$;

-- Change PIN while signed in (old PIN required; wrong old PIN counts as a failure).
create function api.v1_auth_change_pin(p_old_pin text, p_new_pin text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_person uuid := iam.fn_require_person(); pin iam.login_pin%rowtype; v_err text; v_max integer;
begin
  select * into pin from iam.login_pin where person_id = v_person for update;
  if not found then perform core.fn_raise('E_OTP_REQUIRED', 'enroll a PIN first'); end if;
  if pin.locked_until is not null and pin.locked_until > clock_timestamp() then perform core.fn_raise('E_AUTH_LOCKED'); end if;
  if crypt(coalesce(p_old_pin, ''), pin.pin_hash) <> pin.pin_hash then
    v_max := iam.fn_auth_int(v_person, 'auth.pin.max_failures', 'min');
    update iam.login_pin set failed_count = pin.failed_count + 1, last_failed_at = clock_timestamp(),
           locked_until = case when pin.failed_count + 1 >= v_max then clock_timestamp() + make_interval(mins => iam.fn_auth_int(v_person, 'auth.pin.lock_minutes', 'max')) end
     where person_id = v_person;
    perform iam.fn_login_log('pin_change', 'failed', 'wrong old pin', null, v_person, null);
    return jsonb_build_object('status', 'wrong_pin');              -- returned, not raised: the failure count must persist
  end if;
  v_err := iam.fn_pin_policy_error(p_new_pin, iam.fn_auth_int(v_person, 'auth.pin.length', 'max'));
  if v_err is not null then perform core.fn_raise('E_PIN_WEAK', v_err); end if;
  if crypt(p_new_pin, pin.pin_hash) = pin.pin_hash then perform core.fn_raise('E_PIN_WEAK', 'same as before'); end if;
  perform set_config('mohona.change_reason', 'pin changed', true);
  update iam.login_pin set pin_hash = crypt(p_new_pin, gen_salt('bf', 10)), set_via = 'change', set_at = clock_timestamp(), failed_count = 0, locked_until = null
   where person_id = v_person;
  perform iam.fn_login_log('pin_change', 'success', null, null, v_person, null);
  return jsonb_build_object('status', 'changed');
end $$;

-- F206: register this device after an OTP (also brings back a previously revoked device).
create function api.v1_auth_register_device(p_device_id text, p_name text, p_platform text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); v uuid;
begin
  if coalesce(p_device_id, '') !~ '^[A-Za-z0-9_-]{16,128}$' or coalesce(p_platform, 'android') not in ('android','ios','web') then
    perform core.fn_raise('E_INVALID_ACTION', 'device');
  end if;
  if not iam.fn_otp_fresh(iam.fn_auth_int(v_person, 'auth.otp.fresh_minutes', 'min')) then perform core.fn_raise('E_OTP_REQUIRED'); end if;
  perform set_config('mohona.change_reason', 'device registered', true);
  v := iam.fn_device_upsert(v_person, iam.fn_sha256(p_device_id), p_name, p_platform, true);
  perform iam.fn_login_log('device', 'success', 'register', null, v_person, iam.fn_sha256(p_device_id));
  return jsonb_build_object('device_id', v);
end $$;

create function api.v1_auth_my_devices() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); v_sid text := core.fn_jwt_claim('session_id');
begin
  return coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'name', d.name, 'platform', d.platform, 'status', d.status,
                                                       'registered_at', d.registered_at, 'last_seen_at', d.last_seen_at,
                                                       'this_device', exists (select 1 from iam.auth_session s where s.device_id = d.id and s.id::text = v_sid))
                                    order by d.status, d.last_seen_at desc)
                     from iam.device d where d.person_id = v_person), '[]'::jsonb);
end $$;

-- Revoke one of MY devices, or (p_person_id) a member's device as a manager with iam.session.revoke in a shared company.
create function api.v1_auth_revoke_device(p_device_id uuid, p_person_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_me uuid := iam.fn_require_person(); v_person uuid := coalesce(p_person_id, v_me); me record; n integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if v_person <> v_me then
    select * into me from iam.fn_require('iam.session.revoke', iam.fn_my_company_resource(), true);
    if not exists (select 1 from iam.company_membership m where m.person_id = v_person and m.company_id = me.company_id) then
      perform core.fn_raise('E_WRONG_COMPANY', 'not a member of this company');
    end if;
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.device set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = p_reason
   where id = p_device_id and person_id = v_person and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'device'); end if;
  update iam.auth_session set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'device revoked: ' || p_reason
   where device_id = p_device_id and status = 'active';
  get diagnostics n = row_count;
  perform iam.fn_login_log('device', 'success', 'revoke', null, v_person, null);
  return jsonb_build_object('device_id', p_device_id, 'sessions_ended', n);
end $$;

-- OI-11: sign out this session (or everywhere). PIN sessions end in the database at once; the selected position of the
-- ended sessions is forgotten. Native GoTrue sessions additionally go through the Edge Function `auth-sign-out`.
create function api.v1_auth_sign_out(p_everywhere boolean default false) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); v_sid text := core.fn_jwt_claim('session_id'); n integer;
begin
  perform set_config('mohona.change_reason', case when p_everywhere then 'sign out everywhere' else 'sign out' end, true);
  update iam.auth_session set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = 'signed out'
   where person_id = v_person and status = 'active' and (coalesce(p_everywhere, false) or id::text = v_sid);
  get diagnostics n = row_count;
  delete from iam.session_context where person_id = v_person and (coalesce(p_everywhere, false) or session_key = iam.fn_session_key());
  if coalesce(p_everywhere, false) then
    insert into iam.session_revocation (company_id, person_id, revoked_before, reason)
    select m.company_id, v_person, clock_timestamp(), 'signed out everywhere' from iam.company_membership m where m.person_id = v_person and m.status <> 'ended';
  end if;
  perform iam.fn_login_log('sign_out', 'success', case when p_everywhere then 'everywhere' else 'this session' end, null, v_person, null);
  return jsonb_build_object('pin_sessions_ended', n, 'everywhere', coalesce(p_everywhere, false));
end $$;

-- F208: companies this login may enter (active memberships of active companies) + whether MFA is needed per position.
create function api.v1_auth_my_companies() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person();
begin
  return coalesce((select jsonb_agg(jsonb_build_object('company_id', c.id, 'code', c.code, 'name_bn', c.name_bn, 'membership_id', m.id,
           'positions', coalesce((select jsonb_agg(jsonb_build_object('assignment_id', a.id, 'position_code', a.position_code, 'name_bn', pc.name_bn,
                                    'usable', iam.fn_assignment_usable(v_person, a.id),
                                    'mfa_required', a.position_code = any (config.fn_get_text_array(c.id, 'iam.mfa.required_positions')))
                                    order by pc.rank desc)
                                  from iam.position_assignment a join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
                                 where a.membership_id = m.id and a.status = 'active'), '[]'::jsonb))
           order by c.code)
     from iam.company_membership m join core.company c on c.id = m.company_id
    where m.person_id = v_person and m.status = 'active' and c.status = 'active'), '[]'::jsonb);
end $$;

-- F201: invite a member's mobile number to log in (replaces older open invitations of that person).
create function api.v1_auth_invite(p_membership_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; m iam.company_membership%rowtype; v_phone text; v_id uuid; v_exp timestamptz;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.membership.manage', iam.fn_my_company_resource(), true);
  select * into m from iam.company_membership where id = p_membership_id and company_id = me.company_id;
  if not found or m.status = 'ended' then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
  select core.fn_phone_canonical(p.phone) into v_phone from core.person p where p.id = m.person_id;
  if v_phone is null then perform core.fn_raise('E_CONTACT_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.login_invitation set status = 'revoked' where person_id = m.person_id and status = 'open';
  v_exp := clock_timestamp() + make_interval(days => config.fn_get_int(me.company_id, 'auth.invitation.valid_days'));
  insert into iam.login_invitation (company_id, membership_id, person_id, phone_canonical, expires_at, reason, created_by)
  values (me.company_id, m.id, m.person_id, v_phone, v_exp, p_reason, me.person_id) returning id into v_id;
  return jsonb_build_object('invitation_id', v_id, 'expires_at', v_exp);
end $$;

-- F210: a manager clears a lockout (after confirming identity off-line).
create function api.v1_auth_unlock(p_person_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('iam.session.revoke', iam.fn_my_company_resource(), true);
  if not exists (select 1 from iam.company_membership m where m.person_id = p_person_id and m.company_id = me.company_id) then
    perform core.fn_raise('E_WRONG_COMPANY', 'not a member of this company');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.login_pin set failed_count = 0, locked_until = null where person_id = p_person_id;
  perform iam.fn_login_log('unlock', 'success', left(p_reason, 100), null, p_person_id, null);
end $$;

-- F210: login security log of my company's members (no phone numbers, PINs or OTPs exist in it).
create function api.v1_auth_login_audit(p_since timestamptz default null, p_limit integer default 200) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(x order by (x ->> 'id')::bigint desc) from (
    select jsonb_build_object('id', a.id, 'at', a.occurred_at, 'kind', a.kind, 'outcome', a.outcome, 'reason', a.reason, 'person_id', a.person_id,
                              'name_bn', p.full_name_bn, 'session_id', a.session_id) x
      from iam.login_attempt a join core.person p on p.id = a.person_id
     where a.person_id in (select m.person_id from iam.company_membership m where m.company_id = me.company_id)
       and (p_since is null or a.occurred_at >= p_since)
     order by a.id desc limit greatest(1, least(coalesce(p_limit, 200), 2000))) q), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_auth_claim_invitation()', 'api.v1_auth_set_pin(text)', 'api.v1_auth_change_pin(text, text)',
      'api.v1_auth_register_device(text, text, text)', 'api.v1_auth_my_devices()', 'api.v1_auth_revoke_device(uuid, uuid, text)',
      'api.v1_auth_sign_out(boolean)', 'api.v1_auth_my_companies()', 'api.v1_auth_invite(uuid, text)', 'api.v1_auth_unlock(uuid, text)',
      'api.v1_auth_login_audit(timestamptz, integer)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    foreach f in array array['svc.v1_auth_otp_allowed(text)', 'svc.v1_auth_pin_verify(text, text, text, text, text)',
      'svc.v1_auth_refresh(text, text)', 'svc.v1_auth_kill_native_sessions(uuid)',
      'svc.v1_hr_apply_due_changes()'] loop                                     -- S15 scheduler entry was missing its grant
      execute format('grant execute on function %s to service_role', f);
    end loop;
  end if;
end $$;

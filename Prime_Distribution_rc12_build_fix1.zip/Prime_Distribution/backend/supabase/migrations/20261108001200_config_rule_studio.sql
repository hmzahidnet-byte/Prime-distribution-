-- 20261108001200_config_rule_studio.sql  (S13)
-- Rule Studio + workflow designer (blueprint CHAIRMAN_RULES, MOS-F153-011..020): versioned business rules per event,
-- a safe JSON condition language (no SQL, bounded depth), actions (block / approvals / approver permission / force
-- approval / notify positions), simulation, publish (optionally through the approval engine), suspend, rollback,
-- wing scoping, conflict analysis and change-impact on real history. Published rules drive core.fn_approval_submit.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table config.rule (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  code            text not null check (code ~ '^[A-Z][A-Z0-9_]{2,40}$'),
  name_bn         text not null check (length(btrim(name_bn)) > 0),
  event_type      text not null check (event_type ~ '^[a-z][a-z0-9_.]{1,60}$'),
  wing_id         uuid,
  priority        integer not null default 100 check (priority between 1 and 1000),
  status          text not null default 'draft' check (status in ('draft','published','suspended','retired')),
  published_version integer,
  created_by      uuid,
  created_at      timestamptz not null default clock_timestamp(),
  updated_at      timestamptz not null default clock_timestamp(),
  row_version     integer not null default 1,
  unique (id, company_id),
  unique (company_id, code),
  foreign key (wing_id, company_id) references core.wing (id, company_id)
);
create trigger trg_rule_touch before update on config.rule for each row execute function core.fn_touch_row();
create trigger trg_rule_nodel before delete on config.rule for each row execute function core.fn_deny_delete();
create trigger trg_rule_audit after insert or update on config.rule for each row execute function audit.fn_row_change();

create table config.rule_version (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  rule_id       uuid not null,
  version       integer not null check (version >= 1),
  condition     jsonb not null,
  actions       jsonb not null,
  status        text not null default 'draft' check (status in ('draft','pending_approval','published','superseded','rejected')),
  created_by    uuid,
  created_at    timestamptz not null default clock_timestamp(),
  published_at  timestamptz,
  approval_request_id uuid,
  reason        text not null check (length(btrim(reason)) > 0),
  unique (rule_id, version),
  foreign key (rule_id, company_id) references config.rule (id, company_id)
);
create function config.fn_rule_version_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.condition is distinct from old.condition or new.actions is distinct from old.actions or new.version <> old.version or new.rule_id <> old.rule_id then
    raise exception 'E_IMMUTABLE: a rule version never changes; create a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_rule_version_guard before update on config.rule_version for each row execute function config.fn_rule_version_guard();
create trigger trg_rule_version_nodel before delete on config.rule_version for each row execute function core.fn_deny_delete();
create trigger trg_rule_version_audit after insert or update on config.rule_version for each row execute function audit.fn_row_change();

select core.fn_apply_rls('config', 'rule');
select core.fn_apply_rls('config', 'rule_version');

-- ---------------------------------------------------------------- condition language
-- {"op":"and"|"or","args":[...]} · {"op":"not","arg":{...}} · {"op":"="|"!="|">"|">="|"<"|"<="|"in"|"contains"|"is_null"|"always",
--  "field":"amount","value":...}. Fields are fact names (^[a-z][a-z0-9_]{0,40}$). Depth <= 10, nodes <= 100.
create function config.fn_rule_validate(p jsonb, p_depth integer default 0) returns integer
language plpgsql immutable set search_path = pg_catalog as $$
declare v_op text := p ->> 'op'; n integer := 1; x jsonb;
begin
  if p_depth > 10 then raise exception 'E_RULE_INVALID: condition deeper than 10' using errcode = 'P0001'; end if;
  if jsonb_typeof(p) <> 'object' or v_op is null then raise exception 'E_RULE_INVALID: node must be an object with op' using errcode = 'P0001'; end if;
  if v_op in ('and','or') then
    if jsonb_typeof(p -> 'args') <> 'array' or jsonb_array_length(p -> 'args') = 0 then raise exception 'E_RULE_INVALID: % needs args', v_op using errcode = 'P0001'; end if;
    for x in select * from jsonb_array_elements(p -> 'args') loop n := n + config.fn_rule_validate(x, p_depth + 1); end loop;
  elsif v_op = 'not' then
    n := n + config.fn_rule_validate(p -> 'arg', p_depth + 1);
  elsif v_op = 'always' then
    null;
  elsif v_op in ('=','!=','>','>=','<','<=','in','contains','is_null') then
    if coalesce(p ->> 'field', '') !~ '^[a-z][a-z0-9_]{0,40}$' then raise exception 'E_RULE_INVALID: bad field' using errcode = 'P0001'; end if;
    if v_op in ('>','>=','<','<=') and jsonb_typeof(p -> 'value') <> 'number' then raise exception 'E_RULE_INVALID: % needs a number', v_op using errcode = 'P0001'; end if;
    if v_op = 'in' and jsonb_typeof(p -> 'value') <> 'array' then raise exception 'E_RULE_INVALID: in needs a list' using errcode = 'P0001'; end if;
  else
    raise exception 'E_RULE_INVALID: unknown op %', v_op using errcode = 'P0001';
  end if;
  if n > 100 then raise exception 'E_RULE_INVALID: too many nodes' using errcode = 'P0001'; end if;
  return n;
end $$;

create function config.fn_rule_eval(p jsonb, f jsonb) returns boolean
language plpgsql immutable set search_path = pg_catalog as $$
declare v_op text := p ->> 'op'; v jsonb := f -> (p ->> 'field'); x jsonb;
begin
  case v_op
    when 'always' then return true;
    when 'and' then for x in select * from jsonb_array_elements(p -> 'args') loop if not config.fn_rule_eval(x, f) then return false; end if; end loop; return true;
    when 'or'  then for x in select * from jsonb_array_elements(p -> 'args') loop if config.fn_rule_eval(x, f) then return true; end if; end loop; return false;
    when 'not' then return not config.fn_rule_eval(p -> 'arg', f);
    when 'is_null' then return v is null or jsonb_typeof(v) = 'null';
    when '=' then return v is not null and v = p -> 'value';
    when '!=' then return v is null or v <> p -> 'value';
    when 'in' then return v is not null and (p -> 'value') @> jsonb_build_array(v);
    when 'contains' then return v is not null and jsonb_typeof(v) = 'array' and v @> jsonb_build_array(p -> 'value');
    else
      if v is null or jsonb_typeof(v) <> 'number' then return false; end if;
      return case v_op when '>' then (v #>> '{}')::numeric > (p ->> 'value')::numeric
                       when '>=' then (v #>> '{}')::numeric >= (p ->> 'value')::numeric
                       when '<' then (v #>> '{}')::numeric < (p ->> 'value')::numeric
                       when '<=' then (v #>> '{}')::numeric <= (p ->> 'value')::numeric end;
  end case;
end $$;

-- Actions: {"block": {"message_bn": "..."}} | {"require_approvals": 2} | {"approver_permission": "finance.journal.post"} |
--          {"force_approval": true} | {"notify_positions": ["MD"]}
create function config.fn_rule_validate_actions(p jsonb) returns void
language plpgsql stable set search_path = pg_catalog as $$
declare k text;
begin
  if jsonb_typeof(p) <> 'object' or p = '{}'::jsonb then raise exception 'E_RULE_INVALID: actions required' using errcode = 'P0001'; end if;
  for k in select jsonb_object_keys(p) loop
    if k not in ('block','require_approvals','approver_permission','force_approval','notify_positions') then
      raise exception 'E_RULE_INVALID: unknown action %', k using errcode = 'P0001';
    end if;
  end loop;
  if p ? 'require_approvals' and (jsonb_typeof(p -> 'require_approvals') <> 'number' or (p ->> 'require_approvals')::integer not between 1 and 10) then
    raise exception 'E_RULE_INVALID: require_approvals 1..10' using errcode = 'P0001';
  end if;
  if p ? 'approver_permission' and not exists (select 1 from iam.permission_catalog where code = p ->> 'approver_permission') then
    raise exception 'E_RULE_INVALID: unknown permission' using errcode = 'P0001';
  end if;
  if p ? 'block' and length(btrim(coalesce(p -> 'block' ->> 'message_bn', ''))) = 0 then
    raise exception 'E_RULE_INVALID: block needs message_bn' using errcode = 'P0001';
  end if;
end $$;

-- Merge of every published rule matching the event (company-wide + the wing's), in priority order.
create function config.fn_rules_evaluate(p_company uuid, p_event text, p_wing uuid, p_facts jsonb,
                                         p_override_rule uuid default null, p_override_version jsonb default null) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare x record; v_cond jsonb; v_act jsonb; v_out jsonb := jsonb_build_object('blocked', false, 'matched', '[]'::jsonb, 'notify_positions', '[]'::jsonb);
begin
  for x in select r.id, r.code, r.priority, rv.condition, rv.actions
             from config.rule r left join config.rule_version rv on rv.rule_id = r.id and rv.version = r.published_version
            where r.company_id = p_company and r.event_type = p_event and (r.wing_id is null or r.wing_id = p_wing)
              and (r.status = 'published' or r.id = p_override_rule)
            order by r.priority, r.code loop
    v_cond := case when x.id = p_override_rule then p_override_version -> 'condition' else x.condition end;
    v_act  := case when x.id = p_override_rule then p_override_version -> 'actions' else x.actions end;
    continue when v_cond is null or not config.fn_rule_eval(v_cond, p_facts);
    v_out := jsonb_set(v_out, '{matched}', (v_out -> 'matched') || jsonb_build_array(x.code));
    if v_act ? 'block' and not (v_out ->> 'blocked')::boolean then
      v_out := v_out || jsonb_build_object('blocked', true, 'message_bn', v_act -> 'block' ->> 'message_bn', 'blocked_by', x.code);
    end if;
    if v_act ? 'require_approvals' then
      v_out := v_out || jsonb_build_object('required_approvals', greatest(coalesce((v_out ->> 'required_approvals')::integer, 0), (v_act ->> 'require_approvals')::integer));
    end if;
    if v_act ? 'approver_permission' and not v_out ? 'approver_permission' then
      v_out := v_out || jsonb_build_object('approver_permission', v_act ->> 'approver_permission');
    end if;
    if coalesce((v_act ->> 'force_approval')::boolean, false) then v_out := v_out || jsonb_build_object('force_approval', true); end if;
    if v_act ? 'notify_positions' then
      v_out := jsonb_set(v_out, '{notify_positions}', (select coalesce(jsonb_agg(distinct e), '[]'::jsonb)
                                                         from jsonb_array_elements((v_out -> 'notify_positions') || (v_act -> 'notify_positions')) e));
    end if;
  end loop;
  return v_out;
end $$;

-- publish a version (direct or from an approved request)
create function config.fn_publish_rule_version(p_company uuid, p_rule uuid, p_version integer) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  update config.rule_version set status = 'superseded' where rule_id = p_rule and status = 'published';
  update config.rule_version set status = 'published', published_at = clock_timestamp() where rule_id = p_rule and version = p_version;
  update config.rule set status = 'published', published_version = p_version where id = p_rule and company_id = p_company;
end $$;

-- Generic approval handlers (extended by later steps with create or replace).
create function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case r.document_type
    when 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    else null;
  end case;
end $$;

create or replace function core.fn_approval_submit(p_company uuid, p_document_type text, p_document_id uuid, p_amount numeric,
                                        p_resource iam.resource, p_payload jsonb default null, p_module_version text default null)
returns jsonb language plpgsql security definer set search_path = pg_catalog as $$
declare c record; pol config.approval_policy%rowtype; v_id uuid; v_status text := 'pending'; v_rules jsonb; v_required integer; v_perm text;
begin
  select * into c from iam.fn_context(true);
  if c.company_id <> p_company then raise exception 'E_WRONG_COMPANY' using errcode = 'P0001'; end if;
  select * into pol from config.approval_policy
   where company_id = p_company and document_type = p_document_type and status = 'active' and min_amount <= coalesce(p_amount, 0)
   order by min_amount desc limit 1;
  -- Rule Studio (S13): published rules for this event can block, raise the approval count or demand a permission
  v_rules := config.fn_rules_evaluate(p_company, p_document_type, (p_resource).wing_id,
               jsonb_build_object('amount', coalesce(p_amount, 0), 'wing_id', (p_resource).wing_id, 'department_id', (p_resource).department_id,
                                  'location_id', (p_resource).location_id, 'maker_position', c.position_code) || coalesce(p_payload -> 'facts', '{}'::jsonb));
  if (v_rules ->> 'blocked')::boolean then
    raise exception 'E_RULE_BLOCKED: %', v_rules ->> 'message_bn' using errcode = 'P0001';
  end if;
  v_required := greatest(coalesce(pol.required_approvals, 1), coalesce((v_rules ->> 'required_approvals')::integer, 0));
  v_perm := coalesce(v_rules ->> 'approver_permission', pol.approver_permission);
  if not config.fn_get_bool(p_company, 'approval.maker_checker.enabled') and not coalesce((v_rules ->> 'force_approval')::boolean, false) then v_status := 'approved'; end if;
  insert into core.approval_request (company_id, document_type, document_id, amount, resource, payload, maker_person_id, maker_assignment_id,
                                     maker_is_supreme, required_approvals, approver_permission, policy_snapshot, module_version, status, decided_at)
  values (p_company, p_document_type, p_document_id, coalesce(p_amount, 0),
          jsonb_build_object('wing_id', (p_resource).wing_id, 'department_id', (p_resource).department_id, 'location_id', (p_resource).location_id,
                             'warehouse_id', (p_resource).warehouse_id, 'owner_person_id', (p_resource).owner_person_id),
          p_payload, c.person_id, c.assignment_id, c.is_supreme, v_required, v_perm,
          coalesce(to_jsonb(pol), jsonb_build_object('default', true, 'required_approvals', 1)) || jsonb_build_object('rules', v_rules), p_module_version, v_status,
          case when v_status = 'approved' then clock_timestamp() end)
  returning id into v_id;
  return jsonb_build_object('request_id', v_id, 'status', v_status, 'required_approvals', v_required, 'rules', v_rules);
end $$;

create or replace function api.v1_approval_decide(p_request_id uuid, p_decision text, p_expected_row_version integer, p_reason text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare c record; r core.approval_request%rowtype; v_err text; v_ok integer; v_status text;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_decision not in ('approve','reject') then perform core.fn_raise('E_INVALID_ACTION', p_decision); end if;
  select * into c from iam.fn_context(true);
  select * into r from core.approval_request where id = p_request_id and company_id = c.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'approval request'); end if;
  if r.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  v_err := core.fn_approval_can_decide(r, c.person_id, c.is_supreme);
  if v_err is not null then perform core.fn_raise(v_err, 'approval'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into core.approval_decision (company_id, request_id, decider_person_id, decider_assignment_id, decision, reason)
  values (c.company_id, r.id, c.person_id, c.assignment_id, p_decision, p_reason);
  select count(*) into v_ok from core.approval_decision where request_id = r.id and decision = 'approve';
  v_status := case when p_decision = 'reject' then 'rejected' when v_ok >= r.required_approvals then 'approved' else 'pending' end;
  if v_status <> 'pending' then
    update core.approval_request set status = v_status, decided_at = clock_timestamp() where id = r.id;
    if v_status = 'approved' then
      perform core.fn_approval_apply(r);
    end if;
  else
    update core.approval_request set updated_at = clock_timestamp() where id = r.id;
  end if;
  return jsonb_build_object('status', v_status, 'approvals', v_ok, 'required', r.required_approvals);
end $$;

-- ---------------------------------------------------------------- permissions, module, settings
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('config.rule.read',   'config', 'নিয়ম দেখা ও সিমুলেশন', 'read', false, true, array['COMPANY'], 'active', 196),
  ('config.rule.manage', 'config', 'নিয়ম তৈরি/প্রকাশ/স্থগিত/রোলব্যাক', 'admin', true, false, array['COMPANY'], 'active', 197);
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values ('MD', 'config.rule.read', 'allow', 'COMPANY');
select iam.fn_backfill_template_rules(null);
update config.module_catalog set permission_modules = array[]::text[] where code = 'rules';
select config.fn_make_module_available('rules');
insert into config.setting_definition (key, module, value_type, default_value, name_bn, description_bn, is_sensitive, sort_order) values
  ('rules.publish.requires_approval', 'rules', 'bool', 'false', 'নিয়ম প্রকাশে অনুমোদন লাগবে', 'CHAIRMAN_RULES', true, 400);

-- ---------------------------------------------------------------- API
create function api.v1_rules_list(p_event text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.rule.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'code', r.code, 'name_bn', r.name_bn, 'event_type', r.event_type, 'wing_id', r.wing_id,
                         'priority', r.priority, 'status', r.status, 'published_version', r.published_version, 'row_version', r.row_version,
                         'versions', (select jsonb_agg(jsonb_build_object('version', v.version, 'status', v.status, 'condition', v.condition, 'actions', v.actions,
                                         'reason', v.reason, 'created_at', v.created_at) order by v.version desc) from config.rule_version v where v.rule_id = r.id))
                         order by r.event_type, r.priority, r.code)
                     from config.rule r where r.company_id = me.company_id and (p_event is null or r.event_type = p_event)), '[]'::jsonb);
end $$;

-- Creates the rule (first call) or adds a new draft version (later calls). Returns {rule_id, version}.
create function api.v1_rules_save_draft(p_code text, p_name_bn text, p_event text, p_wing_id uuid, p_priority integer,
                                        p_condition jsonb, p_actions jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r config.rule%rowtype; v integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.rule.manage', iam.fn_my_company_resource(), true);
  perform config.fn_rule_validate(p_condition);
  perform config.fn_rule_validate_actions(p_actions);
  perform set_config('mohona.change_reason', p_reason, true);
  select * into r from config.rule where company_id = me.company_id and code = p_code for update;
  if not found then
    insert into config.rule (company_id, code, name_bn, event_type, wing_id, priority, created_by)
    values (me.company_id, p_code, p_name_bn, p_event, p_wing_id, coalesce(p_priority, 100), me.person_id) returning * into r;
  else
    if r.status = 'retired' then perform core.fn_raise('E_INVALID_ACTION', 'retired rule'); end if;
    if r.event_type <> p_event then perform core.fn_raise('E_IMMUTABLE', 'event type of a rule is fixed'); end if;
    update config.rule set name_bn = p_name_bn, wing_id = p_wing_id, priority = coalesce(p_priority, r.priority) where id = r.id;
  end if;
  v := coalesce((select max(version) from config.rule_version where rule_id = r.id), 0) + 1;
  insert into config.rule_version (company_id, rule_id, version, condition, actions, created_by, reason)
  values (me.company_id, r.id, v, p_condition, p_actions, me.person_id, p_reason);
  return jsonb_build_object('rule_id', r.id, 'version', v);
end $$;

-- Simulation: evaluate with given facts, using the rule's draft version in place of its published one.
create function api.v1_rules_simulate(p_event text, p_wing_id uuid, p_facts jsonb, p_rule_id uuid default null, p_version integer default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v jsonb;
begin
  select * into me from iam.fn_require('config.rule.read', iam.fn_my_company_resource(), false);
  if p_rule_id is not null then
    select jsonb_build_object('condition', rv.condition, 'actions', rv.actions) into v from config.rule_version rv
     where rv.rule_id = p_rule_id and rv.company_id = me.company_id and rv.version = p_version;
    if v is null then perform core.fn_raise('E_NOT_FOUND', 'rule version'); end if;
  end if;
  return config.fn_rules_evaluate(me.company_id, p_event, p_wing_id, coalesce(p_facts, '{}'::jsonb), p_rule_id, v);
end $$;

-- publish | suspend | resume | retire | rollback (p_version = the version to publish / roll back to)
create function api.v1_rules_action(p_rule_id uuid, p_action text, p_version integer, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r config.rule%rowtype; v config.rule_version%rowtype; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.rule.manage', iam.fn_my_company_resource(), true);
  select * into r from config.rule where id = p_rule_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'rule'); end if;
  if r.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action in ('publish','rollback') then
    select * into v from config.rule_version where rule_id = r.id and version = p_version;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'version'); end if;
    if r.status = 'retired' then perform core.fn_raise('E_INVALID_ACTION', 'retired'); end if;
    if p_action = 'rollback' and (r.published_version is null or p_version >= r.published_version or v.status not in ('superseded','published')) then
      perform core.fn_raise('E_INVALID_ACTION', 'rollback goes to an earlier published version');
    end if;
    if p_action = 'publish' and v.status <> 'draft' then perform core.fn_raise('E_INVALID_ACTION', 'only a draft is published'); end if;
    if p_action = 'publish' and config.fn_get_bool(me.company_id, 'rules.publish.requires_approval') then
      j := core.fn_approval_submit(me.company_id, 'config.rule_publish', v.id, 0, iam.fn_resource(me.company_id),
                                   jsonb_build_object('rule_id', r.id, 'version', v.version));
      if j ->> 'status' = 'approved' then
        perform config.fn_publish_rule_version(me.company_id, r.id, v.version);
        return jsonb_build_object('status', 'published', 'version', v.version);
      end if;
      update config.rule_version set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = v.id;
      return jsonb_build_object('status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
    perform config.fn_publish_rule_version(me.company_id, r.id, v.version);
    return jsonb_build_object('status', 'published', 'version', v.version);
  elsif p_action = 'suspend' and r.status = 'published' then
    update config.rule set status = 'suspended' where id = r.id;
  elsif p_action = 'resume' and r.status = 'suspended' then
    update config.rule set status = 'published' where id = r.id;
  elsif p_action = 'retire' and r.status in ('draft','suspended','published') then
    update config.rule set status = 'retired' where id = r.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || r.status);
  end if;
  return jsonb_build_object('status', (select status from config.rule where id = r.id));
end $$;

-- Conflict analysis for an event: duplicates, same-priority overlaps, block-vs-approve contradictions on sample facts.
create function api.v1_rules_conflicts(p_event text, p_samples jsonb) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; out jsonb := '[]'::jsonb; a record; b record; s jsonb; both_match integer;
begin
  select * into me from iam.fn_require('config.rule.read', iam.fn_my_company_resource(), false);
  for a in select r.*, rv.condition, rv.actions from config.rule r join config.rule_version rv on rv.rule_id = r.id and rv.version = r.published_version
            where r.company_id = me.company_id and r.event_type = p_event and r.status = 'published' loop
    for b in select r.*, rv.condition, rv.actions from config.rule r join config.rule_version rv on rv.rule_id = r.id and rv.version = r.published_version
              where r.company_id = me.company_id and r.event_type = p_event and r.status = 'published' and r.code > a.code
                and (r.wing_id is null or a.wing_id is null or r.wing_id = a.wing_id) loop
      if a.condition = b.condition then
        out := out || jsonb_build_array(jsonb_build_object('kind', 'duplicate_condition', 'rules', jsonb_build_array(a.code, b.code)));
      end if;
      both_match := 0;
      for s in select * from jsonb_array_elements(coalesce(p_samples, '[]'::jsonb)) loop
        if config.fn_rule_eval(a.condition, s) and config.fn_rule_eval(b.condition, s) then both_match := both_match + 1; end if;
      end loop;
      if both_match > 0 and a.priority = b.priority then
        out := out || jsonb_build_array(jsonb_build_object('kind', 'same_priority_overlap', 'rules', jsonb_build_array(a.code, b.code), 'samples', both_match));
      end if;
      if both_match > 0 and ((a.actions ? 'block') <> (b.actions ? 'block')) then
        out := out || jsonb_build_array(jsonb_build_object('kind', 'block_vs_allow', 'rules', jsonb_build_array(a.code, b.code), 'samples', both_match));
      end if;
    end loop;
  end loop;
  return out;
end $$;

-- Change impact: replays the last N real approval requests of the event with current vs candidate version.
create function api.v1_rules_impact(p_rule_id uuid, p_version integer, p_limit integer default 500) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; r config.rule%rowtype; cand jsonb; q record; f jsonb; before jsonb; after jsonb; n integer := 0; changed integer := 0; newly_blocked integer := 0;
begin
  select * into me from iam.fn_require('config.rule.read', iam.fn_my_company_resource(), false);
  select * into r from config.rule where id = p_rule_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'rule'); end if;
  select jsonb_build_object('condition', condition, 'actions', actions) into cand from config.rule_version where rule_id = r.id and version = p_version;
  if cand is null then perform core.fn_raise('E_NOT_FOUND', 'version'); end if;
  for q in select * from core.approval_request where company_id = me.company_id and document_type = r.event_type order by created_at desc limit least(coalesce(p_limit, 500), 5000) loop
    f := jsonb_build_object('amount', q.amount, 'wing_id', q.resource -> 'wing_id', 'department_id', q.resource -> 'department_id') || coalesce(q.payload -> 'facts', '{}'::jsonb);
    before := config.fn_rules_evaluate(me.company_id, r.event_type, (q.resource ->> 'wing_id')::uuid, f);
    after := config.fn_rules_evaluate(me.company_id, r.event_type, (q.resource ->> 'wing_id')::uuid, f, r.id, cand);
    n := n + 1;
    if (before - 'matched') <> (after - 'matched') then changed := changed + 1; end if;
    if (after ->> 'blocked')::boolean and not (before ->> 'blocked')::boolean then newly_blocked := newly_blocked + 1; end if;
  end loop;
  return jsonb_build_object('replayed', n, 'outcome_changed', changed, 'newly_blocked', newly_blocked);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_rules_list(text)', 'api.v1_rules_save_draft(text, text, text, uuid, integer, jsonb, jsonb, text)',
      'api.v1_rules_simulate(text, uuid, jsonb, uuid, integer)', 'api.v1_rules_action(uuid, text, integer, integer, text)',
      'api.v1_rules_conflicts(text, jsonb)', 'api.v1_rules_impact(uuid, integer, integer)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

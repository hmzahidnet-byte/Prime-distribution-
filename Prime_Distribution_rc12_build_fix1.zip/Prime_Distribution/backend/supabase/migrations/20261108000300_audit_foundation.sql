-- 20261108000300_audit_foundation.sql
-- Append-only, per-company SHA-256 hash-chained audit (port of v0.3 0500, company model) + row-change capture
-- for all master tables. Every Chairman/user change is traceable (DECISION_REGISTER: "every Chairman change audited").
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table audit.chain_head (
  company_id uuid primary key references core.company(id),
  last_seq   bigint not null default 0,
  last_hash  bytea  not null default '\x00'::bytea
);

create table audit.event (
  company_id         uuid        not null references core.company(id),
  seq                bigint      not null,
  occurred_at        timestamptz not null,
  actor_auth_user_id uuid,
  actor_person_id    uuid,                -- filled from S05 onward (core.person)
  action             text        not null check (action ~ '^[a-z0-9_.:]+$'),
  entity_table       text,
  entity_id          uuid,
  outcome            text        not null default 'success' check (outcome in ('success','denied','failed')),
  reason             text,
  detail             jsonb       not null default '{}'::jsonb,
  request_id         text,
  prev_hash          bytea       not null,
  row_hash           bytea       not null,
  primary key (company_id, seq)
);
create index event_entity on audit.event (company_id, entity_table, entity_id);
create index event_time   on audit.event (company_id, occurred_at);
create trigger trg_event_no_mutation before update or delete on audit.event for each row execute function core.fn_deny_mutation();
create trigger trg_event_no_truncate before truncate on audit.event for each statement execute function core.fn_deny_mutation();

create function audit.fn_digest(p_prev bytea, p_company uuid, p_seq bigint, p_ts timestamptz, p_actor uuid, p_person uuid,
                                p_action text, p_table text, p_eid uuid, p_outcome text, p_reason text, p_detail jsonb)
returns bytea language sql immutable set search_path = pg_catalog, public, extensions as $$
  select digest(
    p_prev || convert_to(concat_ws('|', p_company::text, p_seq::text,
      to_char(p_ts at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.US'),
      coalesce(p_actor::text, ''), coalesce(p_person::text, ''), p_action, coalesce(p_table, ''),
      coalesce(p_eid::text, ''), p_outcome, coalesce(p_reason, ''), p_detail::text), 'UTF8'),
    'sha256')
$$;

-- The ONLY writer. Serialises per company through the chain-head row (always the last lock taken in a transaction).
create function audit.fn_append(p_company uuid, p_action text, p_entity_table text default null, p_entity_id uuid default null,
                                p_outcome text default 'success', p_detail jsonb default '{}'::jsonb, p_reason text default null,
                                p_person uuid default null, p_request_id text default null)
returns bigint language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_head audit.chain_head%rowtype; v_seq bigint; v_ts timestamptz := clock_timestamp(); v_hash bytea; v_actor uuid := core.fn_jwt_sub();
begin
  if p_company is null then
    perform core.fn_raise('E_AUDIT_COMPANY_REQUIRED');
  end if;
  insert into audit.chain_head (company_id) values (p_company) on conflict do nothing;
  select * into v_head from audit.chain_head where company_id = p_company for update;
  v_seq  := v_head.last_seq + 1;
  v_hash := audit.fn_digest(v_head.last_hash, p_company, v_seq, v_ts, v_actor, p_person, p_action, p_entity_table,
                            p_entity_id, p_outcome, p_reason, coalesce(p_detail, '{}'::jsonb));
  insert into audit.event (company_id, seq, occurred_at, actor_auth_user_id, actor_person_id, action, entity_table, entity_id,
                           outcome, reason, detail, request_id, prev_hash, row_hash)
  values (p_company, v_seq, v_ts, v_actor, p_person, p_action, p_entity_table, p_entity_id,
          p_outcome, p_reason, coalesce(p_detail, '{}'::jsonb), p_request_id, v_head.last_hash, v_hash);
  update audit.chain_head set last_seq = v_seq, last_hash = v_hash where company_id = p_company;
  return v_seq;
end $$;

-- Returns the first broken sequence number, or NULL when the whole chain is intact.
create function audit.fn_verify_chain(p_company uuid) returns bigint
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare r audit.event%rowtype; v_prev bytea := '\x00'::bytea; v_expect bytea; v_n bigint := 0;
begin
  for r in select * from audit.event where company_id = p_company order by seq loop
    v_n := v_n + 1;
    if r.seq <> v_n or r.prev_hash <> v_prev then return r.seq; end if;
    v_expect := audit.fn_digest(v_prev, r.company_id, r.seq, r.occurred_at, r.actor_auth_user_id, r.actor_person_id,
                                r.action, r.entity_table, r.entity_id, r.outcome, r.reason, r.detail);
    if v_expect <> r.row_hash then return r.seq; end if;
    v_prev := r.row_hash;
  end loop;
  if exists (select 1 from audit.chain_head h where h.company_id = p_company and (h.last_seq <> v_n or h.last_hash <> v_prev)) then
    return v_n + 1;
  end if;
  return null;
end $$;

-- Generic row-change capture. Reason comes from the transaction setting mohona.change_reason (set by api writers).
create function audit.fn_row_change() returns trigger
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_company uuid; v_detail jsonb; v_raw_id text := to_jsonb(new) ->> 'id'; v_id uuid;
begin
  -- ledger-style tables use bigint identities: the entity id is then null and the row id stays in the detail
  v_id := case when v_raw_id ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then v_raw_id::uuid end;
  v_company := case when tg_table_schema = 'core' and tg_table_name = 'company' then v_id else (to_jsonb(new) ->> 'company_id')::uuid end;
  v_detail := case when tg_op = 'INSERT' then jsonb_build_object('new', to_jsonb(new))
                   else jsonb_build_object('old', to_jsonb(old), 'new', to_jsonb(new)) end;
  perform audit.fn_append(v_company, lower(tg_op) || ':' || tg_table_schema || '.' || tg_table_name, tg_table_schema || '.' || tg_table_name,
                          v_id, 'success', v_detail, nullif(current_setting('mohona.change_reason', true), ''));
  return null;
end $$;

create trigger trg_company_audit    after insert or update on core.company    for each row execute function audit.fn_row_change();
create trigger trg_wing_audit       after insert or update on core.wing       for each row execute function audit.fn_row_change();
create trigger trg_department_audit after insert or update on core.department for each row execute function audit.fn_row_change();
create trigger trg_location_audit   after insert or update on core.location   for each row execute function audit.fn_row_change();

-- Security events that may have no company (failed sign-in before membership is known). Append-only.
create table audit.security_event (
  id                 bigint generated always as identity primary key,
  company_id         uuid references core.company(id),
  occurred_at        timestamptz not null default clock_timestamp(),
  actor_auth_user_id uuid,
  event_kind         text not null check (event_kind ~ '^[a-z0-9_.]+$'),
  outcome            text not null check (outcome in ('success','denied','failed')),
  detail             jsonb not null default '{}'::jsonb
);
create trigger trg_security_event_no_mutation before update or delete on audit.security_event for each row execute function core.fn_deny_mutation();
create trigger trg_security_event_no_truncate before truncate on audit.security_event for each statement execute function core.fn_deny_mutation();

reset role;

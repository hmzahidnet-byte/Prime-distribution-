-- 20261108004600_dealer_portal.sql  (ধাপ ৪ক / S66 — V161/V162 dealer-facing features; see docs/V180_FEATURE_AUDIT_BN.md)
-- V162 domains 01–08: the dealer signs in to the same app with a DEALER_PORTAL position and sees ONLY the own dealer record:
--   01 identity: staff invite a dealer owner / representative (PIN login like staff), suspend / reactivate / end, sessions follow the position
--   02 dashboard: due, available credit, recent orders, dispatch timeline, open invoices, notices and offers, product availability (no quantities)
--   04 ordering: the dealer sends an order REQUEST; sales staff turn it into a normal order (price list, credit check and approval stay staff-side)
--   05 DO: the dealer acknowledges a delivery and reports short / damaged goods (control passes -> COGS, see S63)
--   06 ledger: own running statement only, read-only
--   07 payment: the dealer reports a bKash / Nagad / bank / cash payment with its reference; it reduces nothing until staff verify it
--   08 notices / offers: draft -> published by another person -> withdrawn; target all / territories / dealers; JPG / PNG / GIF + Bengali alt text;
--      effective window; read acknowledgement
-- The dealer is identified from the session, never from a parameter. STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into iam.position_template (code, name_bn, name_en, rank, max_holders, is_supreme, is_protected, enabled_by_default, description_bn) values
  ('DEALER_PORTAL', 'ডিলার (নিজস্ব অ্যাপ)', 'Dealer self-service', 50, null, false, true, true, 'ডিলার শুধু নিজের তথ্য, অর্ডার-অনুরোধ, পরিশোধ-তথ্য ও নোটিশ দেখেন')
on conflict do nothing;
select iam.fn_seed_company_positions(c.id) from core.company c;

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('dealer.portal.read',  'dealer', 'ডিলার-অ্যাপ: নিজের তথ্য দেখা', 'read', false, false, array['SELF'], 'active', 2600),
  ('dealer.portal.order', 'dealer', 'ডিলার-অ্যাপ: অর্ডার-অনুরোধ', 'write', false, false, array['SELF'], 'active', 2601),
  ('dealer.portal.pay',   'dealer', 'ডিলার-অ্যাপ: পরিশোধের তথ্য', 'write', false, false, array['SELF'], 'active', 2602),
  ('dealer.notice.manage','dealer', 'ডিলার-নোটিশ ও অফার', 'write', false, true, array['COMPANY'], 'active', 2603);
select iam.fn_seed_permission_dependencies();
update config.module_catalog set permission_modules = permission_modules || array['dealer'] where code = 'crm' and not ('dealer' = any (permission_modules));
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('DEALER_PORTAL','dealer.portal.read','allow','SELF'), ('DEALER_PORTAL','dealer.portal.order','allow','SELF'), ('DEALER_PORTAL','dealer.portal.pay','allow','SELF'),
  ('SALES_MANAGER','dealer.notice.manage','allow','COMPANY'), ('MD','dealer.notice.manage','allow','COMPANY')
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

alter table iam.company_membership add column member_kind text not null default 'staff' check (member_kind in ('staff','dealer'));

create table sales.dealer_user (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  dealer_id   uuid not null,
  person_id   uuid not null references core.person(id),
  assignment_id uuid not null references iam.position_assignment(id),
  role        text not null check (role in ('owner','representative')),
  status      text not null default 'active' check (status in ('active','suspended','ended')),
  created_by  uuid not null references core.person(id),
  created_at  timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create unique index ux_dealer_user_person on sales.dealer_user (company_id, person_id) where status <> 'ended';
create trigger trg_dealer_user_nodel before delete on sales.dealer_user for each row execute function core.fn_deny_delete();
create trigger trg_dealer_user_audit after insert or update on sales.dealer_user for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'dealer_user');

-- The caller's own dealer (permission + active link). Raises when the caller is not an active dealer user.
create function sales.fn_my_dealer(p_permission text) returns uuid
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare me record; v uuid;
begin
  select * into me from iam.fn_require(p_permission, iam.fn_resource(iam.fn_context_company(), null, null, null, null, (select c.person_id from iam.fn_context(false) c)), false);
  select u.dealer_id into v from sales.dealer_user u where u.company_id = me.company_id and u.person_id = me.person_id and u.status = 'active'
     and u.assignment_id = me.assignment_id;
  if v is null then raise exception 'E_FORBIDDEN: not an active dealer user' using errcode = 'P0001'; end if;
  return v;
end $$;

-- ================================================================ 01 identity
create function api.v1_dealer_portal_invite(p_dealer_id uuid, p_full_name_bn text, p_phone text, p_role text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v_person uuid; v_m uuid; v_a uuid; v_u uuid; v_phone text; v_inv uuid; v_exp timestamptz;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found or d.status <> 'active' then perform core.fn_raise('E_NOT_FOUND', 'active dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  if coalesce(p_role, '') not in ('owner','representative') then perform core.fn_raise('E_INVALID_ACTION', 'role'); end if;
  v_phone := core.fn_phone_canonical(p_phone);
  if v_phone is null then perform core.fn_raise('E_CONTACT_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  select p.id into v_person from core.person p where core.fn_phone_canonical(p.phone) = v_phone order by p.created_at limit 1;
  if v_person is null then
    insert into core.person (full_name_bn, phone) values (btrim(p_full_name_bn), p_phone) returning id into v_person;
  end if;
  if exists (select 1 from iam.company_membership m where m.person_id = v_person and m.company_id = me.company_id and m.status <> 'ended' and m.member_kind = 'staff') then
    perform core.fn_raise('E_DUPLICATE', 'this phone belongs to a staff member of the company');
  end if;
  if exists (select 1 from sales.dealer_user u where u.company_id = me.company_id and u.person_id = v_person and u.status <> 'ended') then
    perform core.fn_raise('E_DUPLICATE', 'already a dealer user');
  end if;
  select m.id into v_m from iam.company_membership m where m.person_id = v_person and m.company_id = me.company_id and m.status <> 'ended';
  if v_m is null then
    insert into iam.company_membership (person_id, company_id, status, member_kind) values (v_person, me.company_id, 'active', 'dealer') returning id into v_m;
  end if;
  insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind) values (me.company_id, v_m, 'DEALER_PORTAL', 'regular') returning id into v_a;
  insert into sales.dealer_user (company_id, dealer_id, person_id, assignment_id, role, created_by) values (me.company_id, d.id, v_person, v_a, p_role, me.person_id)
  returning id into v_u;
  update iam.login_invitation set status = 'revoked' where person_id = v_person and status = 'open';
  v_exp := clock_timestamp() + make_interval(days => coalesce(config.fn_get_int(me.company_id, 'auth.invitation.valid_days'), 7));
  insert into iam.login_invitation (company_id, membership_id, person_id, phone_canonical, expires_at, reason, created_by)
  values (me.company_id, v_m, v_person, v_phone, v_exp, p_reason, me.person_id) returning id into v_inv;
  return jsonb_build_object('dealer_user_id', v_u, 'person_id', v_person, 'invitation_id', v_inv, 'expires_at', v_exp);
end $$;

create function api.v1_dealer_portal_user_action(p_dealer_user_id uuid, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; u sales.dealer_user%rowtype; d sales.dealer%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into u from sales.dealer_user where id = p_dealer_user_id and company_id = iam.fn_context_company() for update;
  if not found or u.status = 'ended' then perform core.fn_raise('E_NOT_FOUND', 'dealer user'); end if;
  select * into d from sales.dealer where id = u.dealer_id;
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  if coalesce(p_action, '') not in ('suspend','reactivate','end') then perform core.fn_raise('E_INVALID_ACTION', p_action); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'suspend' and u.status = 'active' then
    update sales.dealer_user set status = 'suspended' where id = u.id;
    update iam.position_assignment set status = 'suspended' where id = u.assignment_id and status = 'active';
  elsif p_action = 'reactivate' and u.status = 'suspended' then
    update sales.dealer_user set status = 'active' where id = u.id;
    update iam.position_assignment set status = 'active' where id = u.assignment_id and status = 'suspended';
  elsif p_action = 'end' then
    update sales.dealer_user set status = 'ended' where id = u.id;
    update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = p_reason where id = u.assignment_id and status <> 'ended';
  else
    perform core.fn_raise('E_INVALID_ACTION', 'the user is not in a state for ' || p_action);
  end if;
  return jsonb_build_object('dealer_user_id', u.id, 'action', p_action);
end $$;

create function api.v1_dealer_portal_users(p_dealer_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), false);
  return coalesce((select jsonb_agg(jsonb_build_object('dealer_user_id', u.id, 'name', p.full_name_bn, 'role', u.role, 'status', u.status, 'since', u.created_at) order by u.created_at)
                     from sales.dealer_user u join core.person p on p.id = u.person_id where u.dealer_id = d.id), '[]'::jsonb);
end $$;

-- ================================================================ 08 notices and offers (staff side)
create table sales.dealer_notice (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  kind          text not null check (kind in ('notice','offer')),
  title_bn      text not null check (length(btrim(title_bn)) > 0),
  body_bn       text not null,
  media_path    text,
  media_mime    text check (media_mime is null or media_mime in ('image/jpeg','image/png','image/gif')),
  alt_text_bn   text,
  segment       jsonb not null default '{"all": true}'::jsonb,       -- {"all":true} | {"territory_ids":[..]} | {"dealer_ids":[..]} | {"market_ids":[..]} (S70)
  eligibility   jsonb,                                               -- offers: {"min_order_amount": n, "product_ids": [..]} (display only; prices stay server-side)
  valid_from    date not null,
  valid_to      date not null,
  status        text not null default 'draft' check (status in ('draft','published','withdrawn')),
  created_by    uuid not null references core.person(id),
  published_by  uuid references core.person(id),
  published_at  timestamptz,
  withdrawn_reason text,
  created_at    timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  check (valid_to >= valid_from),
  check (media_path is null or length(btrim(coalesce(alt_text_bn, ''))) > 0),
  check (published_by is null or published_by <> created_by)
);
create function sales.fn_dealer_notice_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status = 'withdrawn' or (old.status = 'published' and (new.status <> 'withdrawn'
       or (to_jsonb(old) - array['status','withdrawn_reason']) <> (to_jsonb(new) - array['status','withdrawn_reason']))) then
    raise exception 'E_IMMUTABLE: a published notice is only withdrawn, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dealer_notice_guard before update on sales.dealer_notice for each row execute function sales.fn_dealer_notice_guard();
create trigger trg_dealer_notice_nodel before delete on sales.dealer_notice for each row execute function core.fn_deny_delete();
create trigger trg_dealer_notice_audit after insert or update on sales.dealer_notice for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'dealer_notice');

create table sales.dealer_notice_read (
  notice_id   uuid not null references sales.dealer_notice(id),
  company_id  uuid not null,
  dealer_id   uuid not null,
  person_id   uuid not null references core.person(id),
  read_at     timestamptz not null default clock_timestamp(),
  primary key (notice_id, person_id)
);
create trigger trg_dealer_notice_read_no_mutation before update or delete on sales.dealer_notice_read for each row execute function core.fn_deny_mutation();
select core.fn_apply_rls('sales', 'dealer_notice_read');

create function sales.fn_notice_targets(n sales.dealer_notice, p_dealer uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((n.segment ->> 'all')::boolean, false)
      or (n.segment ? 'dealer_ids' and n.segment -> 'dealer_ids' ? p_dealer::text)
      or (n.segment ? 'territory_ids' and n.segment -> 'territory_ids' ? (select d.territory_id::text from sales.dealer d where d.id = p_dealer))
$$;

create function api.v1_dealer_notice_save(p_kind text, p_title_bn text, p_body_bn text, p_media_path text, p_media_mime text, p_alt_text_bn text,
                                          p_segment jsonb, p_eligibility jsonb, p_valid_from date, p_valid_to date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('dealer.notice.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_kind, '') not in ('notice','offer') then perform core.fn_raise('E_INVALID_ACTION', 'kind'); end if;
  if p_media_mime is not null and p_media_mime not in ('image/jpeg','image/png','image/gif') then perform core.fn_raise('E_INVALID_ACTION', 'JPG / PNG / GIF only'); end if;
  if p_media_path is not null and length(btrim(coalesce(p_alt_text_bn, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'a picture needs a Bengali description'); end if;
  if coalesce(p_valid_to, current_date) < coalesce(p_valid_from, current_date) then perform core.fn_raise('E_INVALID_ACTION', 'dates'); end if;
  if p_segment is not null and not (p_segment ? 'all' or p_segment ? 'territory_ids' or p_segment ? 'dealer_ids' or p_segment ? 'market_ids') then perform core.fn_raise('E_INVALID_ACTION', 'segment'); end if;
  perform set_config('mohona.change_reason', 'dealer notice draft', true);
  insert into sales.dealer_notice (company_id, kind, title_bn, body_bn, media_path, media_mime, alt_text_bn, segment, eligibility, valid_from, valid_to, created_by)
  values (me.company_id, p_kind, btrim(p_title_bn), coalesce(p_body_bn, ''), p_media_path, p_media_mime, p_alt_text_bn, coalesce(p_segment, '{"all": true}'::jsonb),
          p_eligibility, coalesce(p_valid_from, current_date), coalesce(p_valid_to, current_date + 30), me.person_id) returning id into v_id;
  return jsonb_build_object('notice_id', v_id, 'status', 'draft');
end $$;

create function api.v1_dealer_notice_publish(p_notice_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; n sales.dealer_notice%rowtype;
begin
  select * into me from iam.fn_require('dealer.notice.manage', iam.fn_my_company_resource(), true);
  select * into n from sales.dealer_notice where id = p_notice_id and company_id = me.company_id for update;
  if not found or n.status <> 'draft' then perform core.fn_raise('E_NOT_FOUND', 'draft notice'); end if;
  if n.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'another person publishes'); end if;
  perform set_config('mohona.change_reason', 'dealer notice published', true);
  update sales.dealer_notice set status = 'published', published_by = me.person_id, published_at = clock_timestamp() where id = n.id;
  return jsonb_build_object('notice_id', n.id, 'status', 'published');
end $$;

create function api.v1_dealer_notice_withdraw(p_notice_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('dealer.notice.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update sales.dealer_notice set status = 'withdrawn', withdrawn_reason = btrim(p_reason) where id = p_notice_id and company_id = me.company_id and status = 'published';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'published notice'); end if;
  return jsonb_build_object('notice_id', p_notice_id, 'status', 'withdrawn',
    'read_by', (select count(*) from sales.dealer_notice_read r where r.notice_id = p_notice_id));
end $$;

-- ================================================================ 04 ordering (request -> staff turn it into an order)
create table sales.dealer_order_request (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  dealer_id   uuid not null,
  lines       jsonb not null,                -- [{product_id, qty}]
  note        text,
  status      text not null default 'submitted' check (status in ('submitted','accepted','rejected','cancelled')),
  order_id    uuid references sales.sales_order(id),
  requested_by uuid not null references core.person(id),
  decided_by  uuid references core.person(id),
  decided_at  timestamptz,
  reason      text,
  idem_key    text not null,
  created_at  timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, dealer_id, idem_key),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create function sales.fn_dealer_request_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status <> 'submitted' or new.lines is distinct from old.lines or new.dealer_id <> old.dealer_id then
    raise exception 'E_IMMUTABLE: an order request is decided once and its lines never change' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dealer_request_guard before update on sales.dealer_order_request for each row execute function sales.fn_dealer_request_guard();
create trigger trg_dealer_request_nodel before delete on sales.dealer_order_request for each row execute function core.fn_deny_delete();
create trigger trg_dealer_request_audit after insert or update on sales.dealer_order_request for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'dealer_order_request');

create function api.v1_dealer_order_request(p_lines jsonb, p_note text, p_idem_key text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; me record; v_id uuid; l jsonb;
begin
  v_d := sales.fn_my_dealer('dealer.portal.order');
  select * into me from iam.fn_context(true);
  if coalesce(p_idem_key, '') !~ '^[A-Za-z0-9_-]{8,80}$' then perform core.fn_raise('E_INVALID_ACTION', 'request key'); end if;
  select r.id into v_id from sales.dealer_order_request r where r.company_id = me.company_id and r.dealer_id = v_d and r.idem_key = p_idem_key;
  if v_id is not null then return jsonb_build_object('request_id', v_id, 'duplicate', true); end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    if coalesce((l ->> 'qty')::numeric, 0) <= 0 or not exists (select 1 from inventory.product p where p.id = (l ->> 'product_id')::uuid and p.company_id = me.company_id
                                                                   and p.kind = 'finished_good' and p.status = 'active') then
      perform core.fn_raise('E_INVALID_ACTION', 'product / quantity');
    end if;
  end loop;
  perform set_config('mohona.change_reason', 'dealer order request', true);
  insert into sales.dealer_order_request (company_id, dealer_id, lines, note, requested_by, idem_key) values (me.company_id, v_d, p_lines, nullif(btrim(p_note), ''), me.person_id, p_idem_key)
  returning id into v_id;
  return jsonb_build_object('request_id', v_id, 'status', 'submitted');
end $$;

create function api.v1_dealer_order_request_cancel(p_order_request_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid;
begin
  v_d := sales.fn_my_dealer('dealer.portal.order');
  perform set_config('mohona.change_reason', 'cancelled by the dealer', true);
  update sales.dealer_order_request set status = 'cancelled', decided_at = clock_timestamp() where id = p_order_request_id and dealer_id = v_d and status = 'submitted';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'open request'); end if;
  return jsonb_build_object('request_id', p_order_request_id, 'status', 'cancelled');
end $$;

-- Staff: accept (creates a normal order: list price, credit check, approval) or reject with a reason.
create function api.v1_dealer_order_request_decide(p_order_request_id uuid, p_accept boolean, p_warehouse_id uuid, p_price_list_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.dealer_order_request%rowtype; o jsonb;
begin
  select * into r from sales.dealer_order_request where id = p_order_request_id and company_id = iam.fn_context_company() for update;
  if not found or r.status <> 'submitted' then perform core.fn_raise('E_NOT_FOUND', 'submitted request'); end if;
  select * into me from iam.fn_require('sales.order.create', sales.fn_dealer_resource((select d from sales.dealer d where d.id = r.dealer_id)), true);
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'dealer request decided'), true);
  if not p_accept then
    if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'tell the dealer why'); end if;
    update sales.dealer_order_request set status = 'rejected', decided_by = me.person_id, decided_at = clock_timestamp(), reason = btrim(p_reason) where id = r.id;
    return jsonb_build_object('request_id', r.id, 'status', 'rejected');
  end if;
  o := api.v1_order_create(r.dealer_id, p_warehouse_id, p_price_list_id, (select jsonb_agg(jsonb_build_object('product_id', x ->> 'product_id', 'qty', (x ->> 'qty')::numeric))
                                                                           from jsonb_array_elements(r.lines) x), null);
  update sales.dealer_order_request set status = 'accepted', order_id = (o ->> 'order_id')::uuid, decided_by = me.person_id, decided_at = clock_timestamp() where id = r.id;
  return jsonb_build_object('request_id', r.id, 'status', 'accepted', 'order', o);
end $$;

-- ================================================================ 02 dashboard / 06 ledger (dealer side)
create function api.v1_dealer_home() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare v_d uuid; d sales.dealer%rowtype; cc jsonb;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into d from sales.dealer where id = v_d;
  cc := sales.fn_credit_check(d.id, 0, sales.fn_open_orders(d.id));
  return jsonb_build_object('dealer', d.code || ' · ' || d.name_bn, 'due', sales.fn_dealer_balance(d.id), 'available_credit', cc -> 'available',
    'recent_orders', coalesce((select jsonb_agg(jsonb_build_object('number', o.number, 'total', o.total, 'status', o.status, 'at', o.created_at) order by o.created_at desc)
                                 from (select * from sales.sales_order o where o.dealer_id = d.id and o.status <> 'split' order by o.created_at desc limit 5) o), '[]'::jsonb),
    'order_requests', coalesce((select jsonb_agg(jsonb_build_object('request_id', r.id, 'status', r.status, 'at', r.created_at) order by r.created_at desc)
                                 from (select * from sales.dealer_order_request r where r.dealer_id = d.id order by r.created_at desc limit 5) r), '[]'::jsonb),
    'dispatches', coalesce((select jsonb_agg(jsonb_build_object('dispatch_id', x.id, 'number', x.number, 'order', o.number, 'vehicle', x.vehicle, 'dispatched_at', x.dispatched_at,
                                                                'delivered_at', x.delivered_at) order by x.dispatched_at desc)
                              from sales.dispatch x join sales.sales_order o on o.id = x.order_id where o.dealer_id = d.id and x.dispatched_at > clock_timestamp() - interval '30 days'), '[]'::jsonb),
    'open_invoices', coalesce((select jsonb_agg(jsonb_build_object('number', i.number, 'date', i.invoice_date, 'due_date', i.due_date, 'open', sales.fn_invoice_open(i.id)) order by i.due_date)
                                 from sales.invoice i where i.dealer_id = d.id and sales.fn_invoice_open(i.id) > 0), '[]'::jsonb),
    'notices', coalesce((select jsonb_agg(jsonb_build_object('notice_id', n.id, 'kind', n.kind, 'title', n.title_bn, 'body', n.body_bn, 'media_path', n.media_path,
                                                             'alt_text', n.alt_text_bn, 'eligibility', n.eligibility, 'valid_to', n.valid_to,
                                                             'read', exists (select 1 from sales.dealer_notice_read r where r.notice_id = n.id and r.dealer_id = d.id)) order by n.published_at desc)
                           from sales.dealer_notice n where n.company_id = d.company_id and n.status = 'published' and current_date between n.valid_from and n.valid_to
                            and sales.fn_notice_targets(n, d.id)), '[]'::jsonb),
    'products', coalesce((select jsonb_agg(jsonb_build_object('product', p.sku || ' · ' || p.name_bn, 'image_path', p.image_path,
                                                              'available', exists (select 1 from inventory.stock_balance b join inventory.warehouse w on w.id = b.warehouse_id
                                                                                    where b.product_id = p.id and w.kind = 'finished_goods' and b.qty > 0)) order by p.sku)
                            from inventory.product p where p.company_id = d.company_id and p.kind = 'finished_good' and p.status = 'active'), '[]'::jsonb));
end $$;

create function api.v1_dealer_my_ledger(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare v_d uuid; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  return jsonb_build_object('from', f, 'to', t, 'opening', sales.fn_dealer_balance(v_d, f - 1),
    'entries', coalesce((select jsonb_agg(jsonb_build_object('date', q.entry_date, 'kind', q.kind, 'amount', q.amount, 'memo', q.memo, 'balance', q.bal) order by q.id)
                           from (select l.*, sales.fn_dealer_balance(v_d, f - 1) + sum(l.amount) over (order by l.entry_date, l.id) bal
                                   from sales.dealer_ledger l where l.dealer_id = v_d and l.entry_date between f and t) q), '[]'::jsonb),
    'closing', sales.fn_dealer_balance(v_d, t));
end $$;

create function api.v1_dealer_notice_read(p_notice_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; n sales.dealer_notice%rowtype; me record;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into me from iam.fn_context(false);
  select * into n from sales.dealer_notice where id = p_notice_id and company_id = me.company_id and status = 'published';
  if not found or not sales.fn_notice_targets(n, v_d) then perform core.fn_raise('E_NOT_FOUND', 'notice'); end if;
  insert into sales.dealer_notice_read (notice_id, company_id, dealer_id, person_id) values (n.id, me.company_id, v_d, me.person_id) on conflict do nothing;
  return jsonb_build_object('notice_id', n.id, 'read', true);
end $$;

-- ================================================================ 05 delivery acknowledgement + short / damaged report
create table sales.delivery_issue (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  dispatch_id  uuid not null,
  kind         text not null check (kind in ('short','damaged')),
  product_id   uuid not null,
  qty          numeric(18,4) not null check (qty > 0),
  note         text not null check (length(btrim(note)) > 0),
  evidence_path text,
  reported_by  uuid not null references core.person(id),
  reported_at  timestamptz not null default clock_timestamp(),
  status       text not null default 'open' check (status in ('open','settled')),
  foreign key (dispatch_id, company_id) references sales.dispatch (id, company_id)
);
create trigger trg_delivery_issue_nodel before delete on sales.delivery_issue for each row execute function core.fn_deny_delete();
create trigger trg_delivery_issue_audit after insert or update on sales.delivery_issue for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'delivery_issue');

-- The dealer confirms receipt (control passes; COGS through the S63 trigger). Issues are reported, not corrected here:
-- a short / damaged report is settled by staff through the normal return / credit-note route.
create function api.v1_dealer_delivery_ack(p_dispatch_id uuid, p_issues jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; me record; x sales.dispatch%rowtype; l jsonb; v_name text;
begin
  v_d := sales.fn_my_dealer('dealer.portal.order');
  select * into me from iam.fn_context(true);
  select ds.* into x from sales.dispatch ds join sales.sales_order o on o.id = ds.order_id where ds.id = p_dispatch_id and o.dealer_id = v_d for update of ds;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dispatch of this dealer'); end if;
  perform set_config('mohona.change_reason', 'received by the dealer', true);
  for l in select * from jsonb_array_elements(coalesce(p_issues, '[]'::jsonb)) loop
    if coalesce(l ->> 'kind', '') not in ('short','damaged') or coalesce((l ->> 'qty')::numeric, 0) <= 0 or length(btrim(coalesce(l ->> 'note', ''))) = 0
       or not exists (select 1 from jsonb_array_elements(x.lines) y where y ->> 'product_id' = l ->> 'product_id') then
      perform core.fn_raise('E_INVALID_ACTION', 'issue: kind, product of this dispatch, quantity and note');
    end if;
    insert into sales.delivery_issue (company_id, dispatch_id, kind, product_id, qty, note, evidence_path, reported_by)
    values (me.company_id, x.id, l ->> 'kind', (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric, btrim(l ->> 'note'), l ->> 'evidence_path', me.person_id);
  end loop;
  if x.delivered_at is null then
    select p.full_name_bn into v_name from core.person p where p.id = me.person_id;
    update sales.dispatch set delivered_at = clock_timestamp(), recipient_name = v_name, delivery_by = me.person_id where id = x.id;
    update sales.sales_order set status = 'delivered' where id = x.order_id and status = 'dispatched';
  end if;
  return jsonb_build_object('dispatch_id', x.id, 'delivered', true, 'issues', jsonb_array_length(coalesce(p_issues, '[]'::jsonb)));
end $$;

-- ================================================================ 07 payment information from the dealer (verified by staff)
create function api.v1_dealer_payment_report(p_method text, p_amount numeric, p_reference text, p_evidence_path text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; me record; v_id uuid := gen_random_uuid(); d sales.dealer%rowtype;
begin
  v_d := sales.fn_my_dealer('dealer.portal.pay');
  select * into me from iam.fn_context(true);
  select * into d from sales.dealer where id = v_d;
  if coalesce(p_method, '') not in ('cash','bank','bkash','nagad') or coalesce(p_amount, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'method / amount'); end if;
  if p_method <> 'cash' and coalesce(p_reference, '') !~ '^[A-Za-z0-9/_-]{4,40}$' then perform core.fn_raise('E_INVALID_ACTION', 'transaction reference'); end if;
  if p_method <> 'cash' and exists (select 1 from sales.collection c where c.company_id = d.company_id and c.method = p_method and c.reference = p_reference
                                                                     and c.status in ('recorded','verified')) then
    perform core.fn_raise('E_DUPLICATE', 'this reference was already reported');
  end if;
  perform set_config('mohona.change_reason', 'payment reported by the dealer', true);
  insert into sales.collection (id, company_id, number, dealer_id, method, amount, reference, evidence_path, allocations, collected_by)
  values (v_id, d.company_id, core.fn_next_number(d.company_id, 'sales.collection', v_id), d.id, p_method, p_amount, p_reference, p_evidence_path, '[]'::jsonb, me.person_id);
  return jsonb_build_object('collection_id', v_id, 'status', 'recorded', 'note_bn', 'যাচাইয়ের পর বকেয়া কমবে।');
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_dealer_portal_invite(uuid, text, text, text, text)', 'api.v1_dealer_portal_user_action(uuid, text, text)', 'api.v1_dealer_portal_users(uuid)',
      'api.v1_dealer_notice_save(text, text, text, text, text, text, jsonb, jsonb, date, date)', 'api.v1_dealer_notice_publish(uuid)', 'api.v1_dealer_notice_withdraw(uuid, text)',
      'api.v1_dealer_home()', 'api.v1_dealer_my_ledger(date, date)', 'api.v1_dealer_notice_read(uuid)', 'api.v1_dealer_order_request(jsonb, text, text)',
      'api.v1_dealer_order_request_cancel(uuid)', 'api.v1_dealer_order_request_decide(uuid, boolean, uuid, uuid, text)', 'api.v1_dealer_delivery_ack(uuid, jsonb)',
      'api.v1_dealer_payment_report(text, numeric, text, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

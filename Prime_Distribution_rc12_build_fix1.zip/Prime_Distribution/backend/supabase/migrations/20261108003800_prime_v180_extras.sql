-- 20261108003800_prime_v180_extras.sql  (S57 — Prime Distribution Architect 1, remaining department needs)
--   Money requests (one Chairman-approved document for): department expenses (factory / warehouse / DMS / office / courier,
--     optional batch or shipment link, the same receipt never twice), supplier advance / refund / application to a bill
--     (supplier-owes-company kept apart from company-owes-supplier), salary advance, investor money in / out (investors are
--     not employees and never get a salary).
--   Party registry (CRM): dealer / retailer / wholesaler / customer / other in ONE registry; a party may hold several classes
--     but has one identity and one receivable; complaints and feedback.
--   Dealer appointment application (staff-initiated -> verified -> approved creates the dealer).
--   Invoice designs: 50 designs; a company picks one from a date; every invoice keeps the design it was issued with.
--   Sales targets vs actual; machines + maintenance; department view of the one central HR; Chairman chain KPI
--     (purchases -> production -> sales -> returns / courier / expenses), unknown figures shown as null, never as profit.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table finance.investor (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  name_bn     text not null check (length(btrim(name_bn)) > 0),
  phone       text,
  agreement_ref text,
  created_at  timestamptz not null default clock_timestamp(),
  unique (id, company_id)
);
create trigger trg_investor_nodel before delete on finance.investor for each row execute function core.fn_deny_delete();
create trigger trg_investor_audit after insert or update on finance.investor for each row execute function audit.fn_row_change();

create table finance.money_request (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references core.company(id),
  number           text not null,
  kind             text not null check (kind in ('expense','supplier_advance','supplier_refund','supplier_advance_apply','salary_advance','investor_in','investor_out')),
  department       text check (department is null or department in ('factory','warehouse','dms','office','courier')),
  category         text,
  amount           numeric(14,2) not null check (amount > 0),
  pay_method       text check (pay_method is null or pay_method in ('bank','cash')),
  supplier_id      uuid, bill_id uuid, employee_id uuid, investor_id uuid, batch_id uuid, shipment_id uuid,
  receipt_ref      text,
  missing_evidence boolean not null default false,
  reason           text not null check (length(btrim(reason)) > 0),
  status           text not null default 'REQUESTED' check (status in ('REQUESTED','POSTED','REJECTED')),
  maker_id         uuid not null references core.person(id),
  approved_by      uuid references core.person(id),
  created_at       timestamptz not null default clock_timestamp(),
  posted_at        timestamptz,
  unique (id, company_id), unique (company_id, number),
  check (approved_by is null or approved_by <> maker_id),
  check (kind <> 'expense' or (department is not null and category is not null)),
  check (kind not like 'supplier%' or supplier_id is not null),
  check (kind <> 'supplier_advance_apply' or bill_id is not null),
  check (kind <> 'salary_advance' or employee_id is not null),
  check (kind not like 'investor%' or investor_id is not null),
  check (kind = 'supplier_advance_apply' or pay_method is not null),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id),
  foreign key (bill_id, company_id) references procurement.bill (id, company_id),
  foreign key (employee_id, company_id) references hr.employee (id, company_id),
  foreign key (investor_id, company_id) references finance.investor (id, company_id),
  foreign key (batch_id, company_id) references mfg.batch (id, company_id),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create unique index money_request_receipt_once on finance.money_request (company_id, kind, receipt_ref) where receipt_ref is not null and status <> 'REJECTED';
create function finance.fn_money_request_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status <> 'REQUESTED' and (to_jsonb(old) - array['receipt_ref']) <> (to_jsonb(new) - array['receipt_ref']) then
    raise exception 'E_IMMUTABLE: a decided money request never changes (evidence may be attached later)' using errcode = 'P0001';
  end if;
  if new.amount <> old.amount or new.kind <> old.kind or new.maker_id <> old.maker_id then raise exception 'E_IMMUTABLE: money request identity' using errcode = 'P0001'; end if;
  return new;
end $$;
create trigger trg_money_request_guard before update on finance.money_request for each row execute function finance.fn_money_request_guard();
create trigger trg_money_request_nodel before delete on finance.money_request for each row execute function core.fn_deny_delete();
create trigger trg_money_request_audit after insert or update on finance.money_request for each row execute function audit.fn_row_change();

-- ================================================================ party registry + complaints (Prime 04)
create table sales.party (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  code         text not null check (code ~ '^[A-Z0-9_-]{2,24}$'),
  name_bn      text not null check (length(btrim(name_bn)) > 0),
  classes      text[] not null check (cardinality(classes) >= 1 and classes <@ array['dealer','retailer','wholesaler','customer','other']),
  phone        text,
  address_bn   text,
  market       text,
  territory_id uuid,
  latitude     numeric(9,6), longitude numeric(9,6),
  dealer_id    uuid,                       -- the party's ONE receivable lives in the dealer ledger when it buys on credit
  retailer_id  uuid,
  officer_id   uuid references core.person(id),
  status       text not null default 'active' check (status in ('active','inactive')),
  updated_at   timestamptz not null default clock_timestamp(),
  row_version  integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id),
  foreign key (retailer_id, company_id) references sales.retailer (id, company_id)
);
create unique index party_one_per_dealer on sales.party (dealer_id) where dealer_id is not null;
create unique index party_one_per_retailer on sales.party (retailer_id) where retailer_id is not null;
create unique index party_one_per_phone on sales.party (company_id, phone) where phone is not null;
create trigger trg_party_guard before update on sales.party for each row execute function core.fn_scoped_guard();
create trigger trg_party_touch before update on sales.party for each row execute function core.fn_touch_row();
create trigger trg_party_nodel before delete on sales.party for each row execute function core.fn_deny_delete();
create trigger trg_party_audit after insert or update on sales.party for each row execute function audit.fn_row_change();

create table sales.party_feedback (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  party_id    uuid not null,
  kind        text not null check (kind in ('complaint','feedback','market_condition','damage')),
  product_id  uuid,
  body        text not null check (length(btrim(body)) > 0),
  status      text not null default 'open' check (status in ('open','resolved')),
  resolution  text,
  created_by  uuid not null references core.person(id),
  created_at  timestamptz not null default clock_timestamp(),
  resolved_by uuid references core.person(id),
  foreign key (party_id, company_id) references sales.party (id, company_id)
);
create trigger trg_party_feedback_nodel before delete on sales.party_feedback for each row execute function core.fn_deny_delete();
create trigger trg_party_feedback_audit after insert or update on sales.party_feedback for each row execute function audit.fn_row_change();

-- ================================================================ dealer application (Prime 03)
create table sales.dealer_application (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  name_bn       text not null check (length(btrim(name_bn)) > 0),
  owner_name_bn text,
  phone         text,
  address_bn    text,
  territory_id  uuid not null,
  bank_info     text,
  mobile_wallet text,
  status        text not null default 'applied' check (status in ('applied','verified','approved','rejected')),
  applied_by    uuid not null references core.person(id),
  verified_by   uuid references core.person(id),
  decided_by    uuid references core.person(id),
  dealer_id     uuid,
  note          text,
  created_at    timestamptz not null default clock_timestamp(),
  check (verified_by is null or verified_by <> applied_by),
  foreign key (territory_id, company_id) references sales.territory (id, company_id)
);
create trigger trg_dealer_application_nodel before delete on sales.dealer_application for each row execute function core.fn_deny_delete();
create trigger trg_dealer_application_audit after insert or update on sales.dealer_application for each row execute function audit.fn_row_change();

-- ================================================================ invoice designs (Prime 07, gate 8)
create table sales.invoice_design (
  code     text primary key check (code ~ '^D[0-9]{2}$'),
  name_bn  text not null,
  spec     jsonb not null                  -- layout parameters only, never data or rights (see the seed below)
);
-- 50 named designs = 10 layout families × 5 colour/paper/QR/footer variants (no two alike: unique index on spec).
-- spec keys: family, accent, paper (a4|a5|pos80), table (lines|grid|stripes|plain), logo (none|left|center), qr (top_right|bottom_right|bottom_left),
-- footer (signature|terms|both|thanks), font_scale, words (amount in Bengali words, always true). Layout only — never data or rights.
insert into sales.invoice_design (code, name_bn, spec) values
  ('D01', 'ক্লাসিক · নীল', jsonb_build_object('family','classic','accent','#1456A0','paper','a4','table','lines','logo','left','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D02', 'ক্লাসিক · কমলা', jsonb_build_object('family','classic','accent','#B45309','paper','a4','table','lines','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D03', 'ক্লাসিক · লাল', jsonb_build_object('family','classic','accent','#B91C1C','paper','a4','table','lines','logo','left','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D04', 'ক্লাসিক · গাঢ় নীল · A5', jsonb_build_object('family','classic','accent','#1E3A8A','paper','a5','table','lines','logo','left','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D05', 'ক্লাসিক · মেরুন', jsonb_build_object('family','classic','accent','#9D174D','paper','a4','table','lines','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D06', 'ব্যানার · বেগুনি', jsonb_build_object('family','banner','accent','#6D28D9','paper','a4','table','lines','logo','none','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D07', 'ব্যানার · টিল', jsonb_build_object('family','banner','accent','#0F766E','paper','a4','table','lines','logo','none','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D08', 'ব্যানার · জলপাই', jsonb_build_object('family','banner','accent','#4D7C0F','paper','a4','table','lines','logo','none','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D09', 'ব্যানার · স্লেট · A5', jsonb_build_object('family','banner','accent','#334155','paper','a5','table','lines','logo','none','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D10', 'ব্যানার · সবুজ', jsonb_build_object('family','banner','accent','#0A7D4F','paper','a4','table','lines','logo','none','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D11', 'মাঝখানে শিরোনাম · গাঢ় নীল', jsonb_build_object('family','centered','accent','#1E3A8A','paper','a4','table','grid','logo','center','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D12', 'মাঝখানে শিরোনাম · মেরুন', jsonb_build_object('family','centered','accent','#9D174D','paper','a4','table','grid','logo','center','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D13', 'মাঝখানে শিরোনাম · নীল', jsonb_build_object('family','centered','accent','#1456A0','paper','a4','table','grid','logo','center','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D14', 'মাঝখানে শিরোনাম · কমলা · A5', jsonb_build_object('family','centered','accent','#B45309','paper','a5','table','grid','logo','center','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D15', 'মাঝখানে শিরোনাম · লাল', jsonb_build_object('family','centered','accent','#B91C1C','paper','a4','table','grid','logo','center','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D16', 'লেটারহেড · স্লেট', jsonb_build_object('family','letterhead','accent','#334155','paper','a4','table','lines','logo','center','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D17', 'লেটারহেড · সবুজ', jsonb_build_object('family','letterhead','accent','#0A7D4F','paper','a4','table','lines','logo','center','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D18', 'লেটারহেড · বেগুনি', jsonb_build_object('family','letterhead','accent','#6D28D9','paper','a4','table','lines','logo','center','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D19', 'লেটারহেড · টিল · A5', jsonb_build_object('family','letterhead','accent','#0F766E','paper','a5','table','lines','logo','center','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D20', 'লেটারহেড · জলপাই', jsonb_build_object('family','letterhead','accent','#4D7C0F','paper','a4','table','lines','logo','center','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D21', 'পাশের রঙিন ফিতা · কমলা', jsonb_build_object('family','sidebar','accent','#B45309','paper','a4','table','stripes','logo','left','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D22', 'পাশের রঙিন ফিতা · লাল', jsonb_build_object('family','sidebar','accent','#B91C1C','paper','a4','table','stripes','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D23', 'পাশের রঙিন ফিতা · গাঢ় নীল', jsonb_build_object('family','sidebar','accent','#1E3A8A','paper','a4','table','stripes','logo','left','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D24', 'পাশের রঙিন ফিতা · মেরুন · A5', jsonb_build_object('family','sidebar','accent','#9D174D','paper','a5','table','stripes','logo','left','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D25', 'পাশের রঙিন ফিতা · নীল', jsonb_build_object('family','sidebar','accent','#1456A0','paper','a4','table','stripes','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D26', 'সাদামাটা · টিল', jsonb_build_object('family','minimal','accent','#0F766E','paper','a4','table','plain','logo','none','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D27', 'সাদামাটা · জলপাই', jsonb_build_object('family','minimal','accent','#4D7C0F','paper','a4','table','plain','logo','none','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D28', 'সাদামাটা · স্লেট', jsonb_build_object('family','minimal','accent','#334155','paper','a4','table','plain','logo','none','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D29', 'সাদামাটা · সবুজ · A5', jsonb_build_object('family','minimal','accent','#0A7D4F','paper','a5','table','plain','logo','none','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D30', 'সাদামাটা · বেগুনি', jsonb_build_object('family','minimal','accent','#6D28D9','paper','a4','table','plain','logo','none','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D31', 'বাক্সবন্দি · মেরুন', jsonb_build_object('family','boxed','accent','#9D174D','paper','a4','table','grid','logo','left','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D32', 'বাক্সবন্দি · নীল', jsonb_build_object('family','boxed','accent','#1456A0','paper','a4','table','grid','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D33', 'বাক্সবন্দি · কমলা', jsonb_build_object('family','boxed','accent','#B45309','paper','a4','table','grid','logo','left','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D34', 'বাক্সবন্দি · লাল · A5', jsonb_build_object('family','boxed','accent','#B91C1C','paper','a5','table','grid','logo','left','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D35', 'বাক্সবন্দি · গাঢ় নীল', jsonb_build_object('family','boxed','accent','#1E3A8A','paper','a4','table','grid','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D36', 'ডোরাকাটা সারি · সবুজ', jsonb_build_object('family','striped','accent','#0A7D4F','paper','a4','table','stripes','logo','left','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D37', 'ডোরাকাটা সারি · বেগুনি', jsonb_build_object('family','striped','accent','#6D28D9','paper','a4','table','stripes','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D38', 'ডোরাকাটা সারি · টিল', jsonb_build_object('family','striped','accent','#0F766E','paper','a4','table','stripes','logo','left','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D39', 'ডোরাকাটা সারি · জলপাই · A5', jsonb_build_object('family','striped','accent','#4D7C0F','paper','a5','table','stripes','logo','left','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D40', 'ডোরাকাটা সারি · স্লেট', jsonb_build_object('family','striped','accent','#334155','paper','a4','table','stripes','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D41', 'কর্পোরেট · লাল', jsonb_build_object('family','corporate','accent','#B91C1C','paper','a4','table','grid','logo','left','qr','top_right','footer','signature','font_scale',1.00,'words',true)),
  ('D42', 'কর্পোরেট · গাঢ় নীল', jsonb_build_object('family','corporate','accent','#1E3A8A','paper','a4','table','grid','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D43', 'কর্পোরেট · মেরুন', jsonb_build_object('family','corporate','accent','#9D174D','paper','a4','table','grid','logo','left','qr','bottom_left','footer','terms','font_scale',1.05,'words',true)),
  ('D44', 'কর্পোরেট · নীল · A5', jsonb_build_object('family','corporate','accent','#1456A0','paper','a5','table','grid','logo','left','qr','top_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D45', 'কর্পোরেট · কমলা', jsonb_build_object('family','corporate','accent','#B45309','paper','a4','table','grid','logo','left','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D46', 'রসিদ (POS) · জলপাই', jsonb_build_object('family','receipt','accent','#4D7C0F','paper','pos80','table','plain','logo','none','qr','bottom_right','footer','signature','font_scale',1.00,'words',true)),
  ('D47', 'রসিদ (POS) · স্লেট', jsonb_build_object('family','receipt','accent','#334155','paper','pos80','table','plain','logo','none','qr','bottom_right','footer','both','font_scale',0.95,'words',true)),
  ('D48', 'রসিদ (POS) · সবুজ', jsonb_build_object('family','receipt','accent','#0A7D4F','paper','pos80','table','plain','logo','none','qr','bottom_right','footer','terms','font_scale',1.05,'words',true)),
  ('D49', 'রসিদ (POS) · বেগুনি', jsonb_build_object('family','receipt','accent','#6D28D9','paper','pos80','table','plain','logo','none','qr','bottom_right','footer','thanks','font_scale',1.00,'words',true)),
  ('D50', 'রসিদ (POS) · টিল', jsonb_build_object('family','receipt','accent','#0F766E','paper','pos80','table','plain','logo','none','qr','bottom_right','footer','both','font_scale',0.95,'words',true));
create unique index invoice_design_spec_unique on sales.invoice_design ((spec::text));
create trigger trg_invoice_design_no_mutation before update or delete on sales.invoice_design for each row execute function core.fn_deny_mutation();

create table sales.company_invoice_design (
  company_id     uuid not null references core.company(id),
  effective_from date not null,
  design_code    text not null references sales.invoice_design(code),
  set_by         uuid references core.person(id),
  set_at         timestamptz not null default clock_timestamp(),
  primary key (company_id, effective_from)
);
create trigger trg_company_invoice_design_no_mutation before update or delete on sales.company_invoice_design for each row execute function core.fn_deny_mutation();
create trigger trg_company_invoice_design_audit after insert on sales.company_invoice_design for each row execute function audit.fn_row_change();

alter table sales.invoice add column design_code text references sales.invoice_design(code);
-- Each invoice is stamped once, at insert, with the design in force on its date; later design changes never touch it.
create function sales.fn_invoice_design_stamp() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  new.design_code := coalesce((select d.design_code from sales.company_invoice_design d where d.company_id = new.company_id and d.effective_from <= new.invoice_date
                                order by d.effective_from desc limit 1), 'D01');
  return new;
end $$;
create trigger trg_invoice_design_stamp before insert on sales.invoice for each row execute function sales.fn_invoice_design_stamp();

-- ================================================================ targets, machines
create table sales.target (
  company_id   uuid not null references core.company(id),
  month        date not null check (month = date_trunc('month', month)::date),
  officer_id   uuid not null references core.person(id),
  amount       numeric(16,2) not null check (amount >= 0),
  set_by       uuid references core.person(id),
  primary key (company_id, month, officer_id)
);
create trigger trg_target_audit after insert or update on sales.target for each row execute function audit.fn_row_change();

create table mfg.machine (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn     text not null,
  status      text not null default 'running' check (status in ('running','down','retired')),
  unique (id, company_id), unique (company_id, code)
);
create trigger trg_machine_audit after insert or update on mfg.machine for each row execute function audit.fn_row_change();
create table mfg.machine_maintenance (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  machine_id  uuid not null,
  kind        text not null check (kind in ('preventive','breakdown','part_change')),
  part_name   text,
  note        text not null,
  downtime_minutes integer check (downtime_minutes is null or downtime_minutes >= 0),
  money_request_id uuid references finance.money_request(id),
  done_by     uuid references core.person(id),
  done_at     timestamptz not null default clock_timestamp(),
  foreign key (machine_id, company_id) references mfg.machine (id, company_id)
);
create trigger trg_machine_maintenance_no_mutation before update or delete on mfg.machine_maintenance for each row execute function core.fn_deny_mutation();

select core.fn_apply_rls('finance', 'investor');
select core.fn_apply_rls('finance', 'money_request');
select core.fn_apply_rls('sales', 'party');
select core.fn_apply_rls('sales', 'party_feedback');
select core.fn_apply_rls('sales', 'dealer_application');
select core.fn_apply_rls('sales', 'invoice_design');
select core.fn_apply_rls('sales', 'company_invoice_design');
select core.fn_apply_rls('sales', 'target');
select core.fn_apply_rls('mfg', 'machine');
select core.fn_apply_rls('mfg', 'machine_maintenance');

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('finance.money.request', 'finance', 'খরচ / অগ্রিম / বিনিয়োগ অনুরোধ লেখা', 'write', true, false, array['COMPANY'], 'active', 2600),
  ('finance.money.read',    'finance', 'খরচ / অগ্রিম / বিনিয়োগ দেখা', 'read', true, false, array['COMPANY'], 'active', 2601),
  ('crm.party.manage',      'crm', 'পার্টি-তালিকা ও অভিযোগ', 'write', false, true, array['COMPANY'], 'active', 2602),
  ('crm.dealer.apply',      'crm', 'ডিলার-নিয়োগের আবেদন', 'write', false, true, array['COMPANY'], 'active', 2603),
  ('mfg.machine.manage',    'mfg', 'যন্ত্র ও রক্ষণাবেক্ষণ', 'write', false, true, array['COMPANY'], 'active', 2604);
update iam.permission_catalog set status = 'active' where code = 'crm.target.manage';
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', 'COMPANY' from (values ('ACCOUNTANT','finance.money.request'), ('FIN_MANAGER','finance.money.request'), ('STOREKEEPER','finance.money.request'),
  ('PROD_SUPERVISOR','finance.money.request'), ('SALES_MANAGER','finance.money.request'), ('HR_OFFICER','finance.money.request'),
  ('MD','finance.money.read'), ('FIN_MANAGER','finance.money.read'), ('ACCOUNTANT','finance.money.read'), ('AUDITOR','finance.money.read'),
  ('SALES_MANAGER','crm.party.manage'), ('FIELD_SALES','crm.party.manage'), ('FIELD_SALES','crm.dealer.apply'), ('SALES_MANAGER','crm.dealer.apply'),
  ('SALES_MANAGER','crm.target.manage'), ('PROD_SUPERVISOR','mfg.machine.manage')) v(x, y)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

insert into finance.coa_template (code, name_bn, type, parent, postable) values
  ('1400','সাপ্লায়ারকে অগ্রিম','asset','1000',true), ('1410','কর্মীকে অগ্রিম','asset','1000',true), ('3300','বিনিয়োগকারীর অর্থ','equity','3000',true),
  ('5910','কারখানা-খরচ','expense','5000',true), ('5920','গুদাম-খরচ','expense','5000',true), ('5930','বিক্রয়/DMS-খরচ','expense','5000',true), ('5940','অফিস-খরচ','expense','5000',true)
  on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values ('proc.supplier_advance','1400','সাপ্লায়ারকে অগ্রিম'), ('hr.salary_advance','1410','কর্মীকে অগ্রিম'),
  ('fin.investor','3300','বিনিয়োগকারীর অর্থ'), ('expense.factory','5910','কারখানা-খরচ'), ('expense.warehouse','5920','গুদাম-খরচ'), ('expense.dms','5930','বিক্রয়/DMS-খরচ'),
  ('expense.office','5940','অফিস-খরচ'), ('expense.courier','5800','কুরিয়ার-খরচ') on conflict do nothing;

-- ================================================================ engine
-- Supplier advance still with the supplier (= what the supplier owes the company): advances − refunds − applied to bills.
create function procurement.fn_supplier_advance(p_supplier uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(case m.kind when 'supplier_advance' then m.amount else -m.amount end), 0) from finance.money_request m
   where m.supplier_id = p_supplier and m.status = 'POSTED' and m.kind in ('supplier_advance','supplier_refund','supplier_advance_apply')
$$;

create function hr.fn_salary_advance(p_employee uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(m.amount), 0) from finance.money_request m where m.employee_id = p_employee and m.status = 'POSTED' and m.kind = 'salary_advance'
$$;

-- Bills: an applied advance reduces what is payable, exactly like a posted payment.
create or replace function procurement.fn_bill_open(p_bill uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select b.total
       - coalesce((select sum((a ->> 'amount')::numeric) from procurement.payment p, jsonb_array_elements(p.allocations) a
                    where p.company_id = b.company_id and p.status = 'posted' and (a ->> 'bill_id')::uuid = b.id), 0)
       - coalesce((select sum(d.amount) from procurement.debit_note d where d.bill_id = b.id and d.status = 'posted'), 0)
       - coalesce((select sum(m.amount) from finance.money_request m where m.bill_id = b.id and m.kind = 'supplier_advance_apply' and m.status = 'POSTED'), 0)
    from procurement.bill b where b.id = p_bill
$$;

-- ================================================================ API: money requests (Chairman approval)
create function api.v1_money_request(p_kind text, p_department text, p_category text, p_amount numeric, p_pay_method text, p_supplier_id uuid, p_bill_id uuid, p_employee_id uuid,
                                     p_investor_id uuid, p_batch_id uuid, p_shipment_id uuid, p_receipt_ref text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); v_no text;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.money.request', iam.fn_my_company_resource(), true);
  if p_kind = 'supplier_refund' and p_amount > procurement.fn_supplier_advance(p_supplier_id) then perform core.fn_raise('E_OVERPAYMENT', 'refund above the advance with the supplier'); end if;
  if p_kind = 'supplier_advance_apply' then
    if not exists (select 1 from procurement.bill b where b.id = p_bill_id and b.company_id = me.company_id and b.supplier_id = p_supplier_id and b.status = 'posted') then
      perform core.fn_raise('E_NOT_FOUND', 'posted bill of this supplier');
    end if;
    if p_amount > least(procurement.fn_supplier_advance(p_supplier_id), procurement.fn_bill_open(p_bill_id)) then perform core.fn_raise('E_OVERPAYMENT', 'above the advance or the open bill'); end if;
  end if;
  v_no := core.fn_next_number(me.company_id, 'finance.money_request', v_id);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into finance.money_request (id, company_id, number, kind, department, category, amount, pay_method, supplier_id, bill_id, employee_id, investor_id, batch_id, shipment_id,
                                     receipt_ref, missing_evidence, reason, maker_id)
  values (v_id, me.company_id, v_no, p_kind, p_department, p_category, p_amount, case when p_kind = 'supplier_advance_apply' then null else p_pay_method end, p_supplier_id, p_bill_id,
          p_employee_id, p_investor_id, p_batch_id, p_shipment_id, nullif(btrim(coalesce(p_receipt_ref, '')), ''), nullif(btrim(coalesce(p_receipt_ref, '')), '') is null, p_reason, me.person_id);
  return jsonb_build_object('request_id', v_id, 'number', v_no, 'status', 'REQUESTED');
end $$;

create function api.v1_money_request_decide(p_request_id uuid, p_approve boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; m finance.money_request%rowtype; v_cash text; v_lines jsonb;
begin
  select * into m from finance.money_request where id = p_request_id and company_id = iam.fn_context_company() for update;
  if not found or m.status <> 'REQUESTED' then perform core.fn_raise('E_NOT_FOUND', 'requested money document'); end if;
  v_ch := core.fn_require_chairman(m.maker_id);
  perform set_config('mohona.change_reason', m.reason, true);
  if not p_approve then
    update finance.money_request set status = 'REJECTED', approved_by = v_ch where id = m.id;
    return jsonb_build_object('request_id', m.id, 'status', 'REJECTED');
  end if;
  v_cash := case when m.pay_method = 'cash' then 'fin.cash' else 'fin.bank' end;
  if m.kind = 'supplier_refund' and m.amount > procurement.fn_supplier_advance(m.supplier_id) then perform core.fn_raise('E_OVERPAYMENT'); end if;
  if m.kind = 'supplier_advance_apply' and m.amount > least(procurement.fn_supplier_advance(m.supplier_id), procurement.fn_bill_open(m.bill_id)) then perform core.fn_raise('E_OVERPAYMENT'); end if;
  v_lines := case m.kind
    when 'expense' then jsonb_build_array(jsonb_build_object('key', 'expense.' || m.department, 'dr', m.amount), jsonb_build_object('key', v_cash, 'cr', m.amount))
    when 'supplier_advance' then jsonb_build_array(jsonb_build_object('key', 'proc.supplier_advance', 'dr', m.amount), jsonb_build_object('key', v_cash, 'cr', m.amount))
    when 'supplier_refund' then jsonb_build_array(jsonb_build_object('key', v_cash, 'dr', m.amount), jsonb_build_object('key', 'proc.supplier_advance', 'cr', m.amount))
    when 'supplier_advance_apply' then jsonb_build_array(jsonb_build_object('key', 'proc.ap', 'dr', m.amount), jsonb_build_object('key', 'proc.supplier_advance', 'cr', m.amount))
    when 'salary_advance' then jsonb_build_array(jsonb_build_object('key', 'hr.salary_advance', 'dr', m.amount), jsonb_build_object('key', v_cash, 'cr', m.amount))
    when 'investor_in' then jsonb_build_array(jsonb_build_object('key', v_cash, 'dr', m.amount), jsonb_build_object('key', 'fin.investor', 'cr', m.amount))
    else jsonb_build_array(jsonb_build_object('key', 'fin.investor', 'dr', m.amount), jsonb_build_object('key', v_cash, 'cr', m.amount)) end;
  update finance.money_request set status = 'POSTED', approved_by = v_ch, posted_at = clock_timestamp() where id = m.id;
  perform finance.fn_emit(m.company_id, 'money:' || m.id, m.kind || ' ' || m.number, v_lines);
  -- an expense tied to a running batch is also absorbed into that batch's WIP (actual batch cost, Prime 01)
  if m.kind = 'expense' and m.batch_id is not null and exists (select 1 from mfg.batch b where b.id = m.batch_id and b.status in ('approved','in_progress')) then
    insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (m.company_id, m.batch_id, 'overhead', m.amount, 'expense ' || m.number, v_ch);
  end if;
  return jsonb_build_object('request_id', m.id, 'status', 'POSTED');
end $$;

create function api.v1_money_request_attach(p_request_id uuid, p_receipt_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.money.request', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'receipt attached later', true);
  update finance.money_request set receipt_ref = p_receipt_ref where id = p_request_id and company_id = me.company_id and receipt_ref is null;   -- the missing-evidence flag stays
  if not found then perform core.fn_raise('E_NOT_FOUND', 'request without a receipt'); end if;
  return jsonb_build_object('request_id', p_request_id);
end $$;

create function api.v1_money_requests(p_kind text default null, p_status text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('finance.money.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'number', m.number, 'kind', m.kind, 'department', m.department, 'category', m.category, 'amount', m.amount,
           'status', m.status, 'missing_evidence', m.missing_evidence, 'reason', m.reason, 'created_at', m.created_at) order by m.created_at desc)
     from finance.money_request m where m.company_id = me.company_id and (p_kind is null or m.kind = p_kind) and (p_status is null or m.status = p_status)), '[]'::jsonb);
end $$;

create function api.v1_investor_save(p_name_bn text, p_phone text, p_agreement_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; v_id uuid;
begin
  v_ch := core.fn_require_chairman(null);
  perform set_config('mohona.change_reason', 'investor record', true);
  insert into finance.investor (company_id, name_bn, phone, agreement_ref) values (iam.fn_context_company(), p_name_bn, p_phone, p_agreement_ref) returning id into v_id;
  return jsonb_build_object('investor_id', v_id);
end $$;

-- ================================================================ API: parties (one registry, one receivable)
create function api.v1_party_save(p_id uuid, p_code text, p_name_bn text, p_classes text[], p_phone text, p_address_bn text, p_market text, p_territory_id uuid,
                                  p_latitude numeric, p_longitude numeric, p_dealer_id uuid, p_retailer_id uuid, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p sales.party%rowtype; v_phone text := core.fn_phone_canonical(p_phone); v_dup uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('crm.party.manage', iam.fn_my_company_resource(), true);
  select x.id into v_dup from sales.party x where x.company_id = me.company_id and x.id is distinct from p_id
     and ((v_phone is not null and x.phone = v_phone) or (p_dealer_id is not null and x.dealer_id = p_dealer_id) or (p_retailer_id is not null and x.retailer_id = p_retailer_id)) limit 1;
  if v_dup is not null then perform core.fn_raise('E_DUPLICATE', 'this person / business is already a party: add the class there'); end if;
  if ('dealer' = any (p_classes)) <> (p_dealer_id is not null) then perform core.fn_raise('E_INVALID_ACTION', 'a dealer-class party is linked to its dealer record (one receivable)'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.party (company_id, code, name_bn, classes, phone, address_bn, market, territory_id, latitude, longitude, dealer_id, retailer_id, officer_id)
    values (me.company_id, upper(p_code), p_name_bn, p_classes, v_phone, p_address_bn, p_market, p_territory_id, p_latitude, p_longitude, p_dealer_id, p_retailer_id, me.person_id) returning * into p;
  else
    update sales.party set name_bn = coalesce(p_name_bn, name_bn), classes = coalesce(p_classes, classes), phone = v_phone, address_bn = p_address_bn, market = p_market,
           territory_id = p_territory_id, latitude = p_latitude, longitude = p_longitude, dealer_id = p_dealer_id, retailer_id = p_retailer_id
     where id = p_id and company_id = me.company_id and row_version = p_expected_row_version returning * into p;
    if p.id is null then perform core.fn_raise('E_STALE_VERSION'); end if;
  end if;
  return jsonb_build_object('party_id', p.id, 'row_version', p.row_version,
    'qr', case when p.dealer_id is not null then sales.fn_dealer_qr(p.dealer_id)                      -- the dealer keeps its old QR (no duplicate identity)
               else sales.fn_signed(me.company_id, 'MOS1|C|' || (select c.code from core.company c where c.id = me.company_id) || '|' || p.code) end);
end $$;

-- One party, figures only from real transactions; without a linked dealer ledger the money fields are null ("তথ্য নেই").
create function api.v1_party_get(p_party_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; p sales.party%rowtype; v_fin boolean := false;
begin
  select * into me from iam.fn_require('crm.party.manage', iam.fn_my_company_resource(), false);
  select * into p from sales.party where id = p_party_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'party'); end if;
  if p.dealer_id is not null then
    select coalesce(a.allowed, false) into v_fin from iam.fn_authorize('crm.dealer.read', sales.fn_dealer_resource((select d from sales.dealer d where d.id = p.dealer_id)), false) a;
  end if;
  return to_jsonb(p) - 'company_id' || jsonb_build_object(
    'balance', case when v_fin then sales.fn_dealer_balance(p.dealer_id) end,
    'sales_total', case when v_fin then (select sum(i.total) from sales.invoice i where i.dealer_id = p.dealer_id) end,
    'returns_total', case when v_fin then (select sum(r.credit_amount) from sales.sales_return r join sales.invoice i on i.id = r.invoice_id where i.dealer_id = p.dealer_id) end,
    'data_note_bn', case when p.dealer_id is null then 'এই পার্টির লেনদেনের তথ্য নেই' end,
    'maps_url', case when p.latitude is not null then 'https://www.google.com/maps/dir/?api=1&destination=' || p.latitude || ',' || p.longitude end,
    'feedback', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'kind', f.kind, 'body', f.body, 'status', f.status, 'at', f.created_at) order by f.created_at desc)
                            from sales.party_feedback f where f.party_id = p.id), '[]'::jsonb));
end $$;

create function api.v1_parties(p_class text default null, p_text text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('crm.party.manage', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'code', p.code, 'name_bn', p.name_bn, 'classes', to_jsonb(p.classes), 'market', p.market, 'status', p.status) order by p.code)
     from sales.party p where p.company_id = me.company_id and (p_class is null or p_class = any (p.classes)) and (p_text is null or p.name_bn ilike '%' || p_text || '%')), '[]'::jsonb);
end $$;

create function api.v1_party_feedback(p_party_id uuid, p_kind text, p_product_id uuid, p_body text, p_resolve_id uuid, p_resolution text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('crm.party.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'party feedback', true);
  if p_resolve_id is not null then
    update sales.party_feedback set status = 'resolved', resolution = p_resolution, resolved_by = me.person_id where id = p_resolve_id and company_id = me.company_id and status = 'open';
    if not found then perform core.fn_raise('E_NOT_FOUND', 'open feedback'); end if;
    return jsonb_build_object('feedback_id', p_resolve_id, 'status', 'resolved');
  end if;
  if not exists (select 1 from sales.party p where p.id = p_party_id and p.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'party'); end if;
  insert into sales.party_feedback (company_id, party_id, kind, product_id, body, created_by) values (me.company_id, p_party_id, p_kind, p_product_id, p_body, me.person_id) returning id into v_id;
  return jsonb_build_object('feedback_id', v_id, 'status', 'open');
end $$;

-- ================================================================ API: dealer application (apply -> verify -> approve)
create function api.v1_dealer_apply(p_name_bn text, p_owner_name_bn text, p_phone text, p_address_bn text, p_territory_id uuid, p_bank_info text, p_mobile_wallet text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('crm.dealer.apply', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'dealer application', true);
  insert into sales.dealer_application (company_id, name_bn, owner_name_bn, phone, address_bn, territory_id, bank_info, mobile_wallet, applied_by)
  values (me.company_id, p_name_bn, p_owner_name_bn, core.fn_phone_canonical(p_phone), p_address_bn, p_territory_id, p_bank_info, p_mobile_wallet, me.person_id) returning id into v_id;
  return jsonb_build_object('application_id', v_id, 'status', 'applied');
end $$;

-- verify (dealer manager, not the applicant) -> approve (credit-override holder, i.e. MD by default; creates the dealer + its party)
create function api.v1_dealer_application_action(p_application_id uuid, p_action text, p_dealer_code text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a sales.dealer_application%rowtype; v_dealer uuid;
begin
  select * into me from iam.fn_require(case when p_action = 'verify' then 'crm.dealer.manage' else 'sales.credit.override' end, iam.fn_my_company_resource(), true);
  select * into a from sales.dealer_application where id = p_application_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'application'); end if;
  if a.applied_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', coalesce(p_note, p_action), true);
  if p_action = 'verify' and a.status = 'applied' then
    update sales.dealer_application set status = 'verified', verified_by = me.person_id, note = p_note where id = a.id;
  elsif p_action = 'reject' and a.status in ('applied','verified') then
    update sales.dealer_application set status = 'rejected', decided_by = me.person_id, note = p_note where id = a.id;
  elsif p_action = 'approve' and a.status = 'verified' then
    insert into sales.dealer (company_id, code, name_bn, owner_name_bn, phone, address_bn, territory_id, officer_id)
    values (a.company_id, upper(p_dealer_code), a.name_bn, a.owner_name_bn, a.phone, a.address_bn, a.territory_id, a.applied_by) returning id into v_dealer;
    insert into sales.party (company_id, code, name_bn, classes, phone, address_bn, territory_id, dealer_id, officer_id)
    values (a.company_id, upper(p_dealer_code), a.name_bn, array['dealer'], a.phone, a.address_bn, a.territory_id, v_dealer, a.applied_by) on conflict do nothing;
    update sales.dealer_application set status = 'approved', decided_by = me.person_id, dealer_id = v_dealer, note = p_note where id = a.id;
  else perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || a.status);
  end if;
  return jsonb_build_object('application_id', a.id, 'status', (select x.status from sales.dealer_application x where x.id = a.id), 'dealer_id', v_dealer);
end $$;

-- ================================================================ API: invoice designs, targets, machines, HR view, Chairman chain
create function api.v1_invoice_designs() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object('current', (select d.design_code from sales.company_invoice_design d where d.company_id = me.company_id and d.effective_from <= current_date order by d.effective_from desc limit 1),
    'designs', (select jsonb_agg(jsonb_build_object('code', x.code, 'name_bn', x.name_bn, 'spec', x.spec) order by x.code) from sales.invoice_design x));
end $$;

create function api.v1_invoice_design_set(p_design_code text, p_effective_from date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid;
begin
  v_ch := core.fn_require_chairman(null);
  if p_effective_from is null or p_effective_from < current_date then perform core.fn_raise('E_INVALID_ACTION', 'a design starts today or later (issued invoices keep theirs)'); end if;
  perform set_config('mohona.change_reason', 'invoice design', true);
  insert into sales.company_invoice_design (company_id, effective_from, design_code, set_by) values (iam.fn_context_company(), p_effective_from, p_design_code, v_ch);
  return jsonb_build_object('design_code', p_design_code, 'effective_from', p_effective_from);
end $$;

create function api.v1_sales_target(p_month date, p_officer_id uuid, p_amount numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; m date := date_trunc('month', coalesce(p_month, current_date))::date;
begin
  select * into me from iam.fn_require('crm.target.manage', iam.fn_my_company_resource(), p_amount is not null);
  if p_amount is not null then
    perform set_config('mohona.change_reason', 'sales target', true);
    insert into sales.target (company_id, month, officer_id, amount, set_by) values (me.company_id, m, p_officer_id, p_amount, me.person_id)
    on conflict (company_id, month, officer_id) do update set amount = excluded.amount, set_by = excluded.set_by;
  end if;
  -- actual = invoices of the officer's dealers in the month; an officer without dealers shows null, never zero-as-fact
  return coalesce((select jsonb_agg(jsonb_build_object('officer_id', t.officer_id, 'target', t.amount,
           'actual', case when exists (select 1 from sales.dealer d where d.company_id = t.company_id and d.officer_id = t.officer_id)
                          then coalesce((select sum(i.total) from sales.invoice i join sales.dealer d on d.id = i.dealer_id
                                          where d.officer_id = t.officer_id and i.company_id = t.company_id and date_trunc('month', i.invoice_date) = t.month), 0) end))
     from sales.target t where t.company_id = me.company_id and t.month = m), '[]'::jsonb);
end $$;

create function api.v1_machine_log(p_machine_code text, p_name_bn text, p_status text, p_kind text, p_part_name text, p_note text, p_downtime_minutes integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_m uuid; v_log uuid;
begin
  select * into me from iam.fn_require('mfg.machine.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'machine', true);
  insert into mfg.machine (company_id, code, name_bn, status) values (me.company_id, upper(p_machine_code), coalesce(p_name_bn, upper(p_machine_code)), coalesce(p_status, 'running'))
  on conflict (company_id, code) do update set name_bn = coalesce(p_name_bn, mfg.machine.name_bn), status = coalesce(p_status, mfg.machine.status) returning id into v_m;
  if p_kind is not null then
    insert into mfg.machine_maintenance (company_id, machine_id, kind, part_name, note, downtime_minutes, done_by)
    values (me.company_id, v_m, p_kind, p_part_name, coalesce(p_note, p_kind), p_downtime_minutes, me.person_id) returning id into v_log;
  end if;
  return jsonb_build_object('machine_id', v_m, 'maintenance_id', v_log);
end $$;

-- Department HR view (factory / warehouse / DMS / office screens): the SAME central employees, each listed once.
create function api.v1_hr_view(p_wing_id uuid default null, p_department_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('hr.employee.read', iam.fn_resource(iam.fn_context_company(), p_wing_id, p_department_id), false);
  return coalesce((select jsonb_agg(jsonb_build_object('employee_id', e.id, 'name_bn', p.full_name_bn, 'employee_code', e.employee_code, 'active', hr.fn_employee_active(e.id),
           'positions', (select jsonb_agg(a.position_code) from iam.position_assignment a where a.membership_id = e.membership_id and a.status = 'active'),
           'salary_advance', hr.fn_salary_advance(e.id)) order by p.full_name_bn)
     from hr.employee e join core.person p on p.id = e.person_id
    where e.company_id = me.company_id
      and (p_wing_id is null and p_department_id is null or exists (select 1 from iam.position_assignment a where a.membership_id = e.membership_id and a.status = 'active'
             and (p_wing_id is null or a.home_wing_id = p_wing_id) and (p_department_id is null or a.home_department_id = p_department_id)))), '[]'::jsonb);
end $$;

-- Chairman chain (Prime 07): raw -> production -> sales -> returns / courier / expenses -> result, from POSTED figures only.
-- A missing link is null and then the result is null too: unknown data is never shown as profit.
create function api.v1_chairman_chain(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare v_ch uuid; c uuid := iam.fn_context_company(); f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
        v_sales numeric; v_cogs numeric; v_ret numeric; v_retcost numeric; v_freight numeric; v_exp numeric; v_conc numeric; v_pay numeric; v_buy numeric; v_fg numeric;
begin
  v_ch := core.fn_require_chairman(null);
  select sum(i.total) into v_sales from sales.invoice i where i.company_id = c and i.invoice_date between f and t;
  select sum(d.cogs) into v_cogs from sales.dispatch d join sales.invoice i on i.order_id = d.order_id where d.company_id = c and i.invoice_date between f and t;
  select sum(r.credit_amount), sum(r.cost_amount) into v_ret, v_retcost from sales.sales_return r where r.company_id = c and r.created_at::date between f and t;
  select sum(s.company_share) into v_freight from sales.shipment s where s.company_id = c and s.dispatched_at::date between f and t;
  select sum(m.amount) into v_exp from finance.money_request m where m.company_id = c and m.kind = 'expense' and m.status = 'POSTED' and m.posted_at::date between f and t;
  select sum(x.amount) into v_conc from sales.courier_settlement x where x.company_id = c and x.kind = 'concession' and x.status = 'POSTED' and x.posted_at::date between f and t;
  select sum(r.gross_total) into v_pay from hr.payroll_run r where r.company_id = c and r.status = 'posted' and r.period between date_trunc('month', f)::date and t;
  select sum(g.accepted_qty * g.unit_price) into v_buy from procurement.grn_line g join procurement.grn h on h.id = g.grn_id where g.company_id = c and h.received_at::date between f and t;
  select sum(e.amount) into v_fg from mfg.wip_entry e where e.company_id = c and e.kind = 'fg' and e.at::date between f and t;
  return jsonb_build_object('from', f, 'to', t, 'purchases', v_buy, 'production_cost', case when v_fg is not null then -v_fg end, 'sales', v_sales, 'cost_of_sales', v_cogs,
    'returns', v_ret, 'courier_freight', v_freight, 'expenses', v_exp, 'concessions', v_conc, 'payroll', v_pay,
    'result', case when v_sales is null or v_cogs is null then null
                   else v_sales - coalesce(v_ret, 0) - (v_cogs - coalesce(v_retcost, 0)) - coalesce(v_freight, 0) - coalesce(v_exp, 0) - coalesce(v_conc, 0) - coalesce(v_pay, 0) end,
    'note_bn', case when v_sales is null or v_cogs is null then 'বিক্রয় বা খরচের তথ্য নেই — লাভ-ক্ষতি দেখানো হলো না' end);
end $$;

select core.fn_assert_rls_everywhere();
reset role;
do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_money_request(text, text, text, numeric, text, uuid, uuid, uuid, uuid, uuid, uuid, text, text)', 'api.v1_money_request_decide(uuid, boolean)',
      'api.v1_money_request_attach(uuid, text)', 'api.v1_money_requests(text, text)', 'api.v1_investor_save(text, text, text)',
      'api.v1_party_save(uuid, text, text, text[], text, text, text, uuid, numeric, numeric, uuid, uuid, integer, text)', 'api.v1_party_get(uuid)', 'api.v1_parties(text, text)',
      'api.v1_party_feedback(uuid, text, uuid, text, uuid, text)', 'api.v1_dealer_apply(text, text, text, text, uuid, text, text)',
      'api.v1_dealer_application_action(uuid, text, text, text)', 'api.v1_invoice_designs()', 'api.v1_invoice_design_set(text, date)', 'api.v1_sales_target(date, uuid, numeric)',
      'api.v1_machine_log(text, text, text, text, text, text, integer)', 'api.v1_hr_view(uuid, uuid)', 'api.v1_chairman_chain(date, date)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

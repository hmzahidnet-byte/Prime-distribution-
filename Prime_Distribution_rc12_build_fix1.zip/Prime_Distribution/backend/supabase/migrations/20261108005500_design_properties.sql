-- 20261108005500_design_properties.sql  (S71 — Chairman micro-design: typed component property registry;
-- V161-08 "chairman micro design" (20), V162-09, V165-11/12, V166-05 marker customisation, V168-03 / V169-05 property registry)
-- Every visual property of a named component (payment tick colour / icon / size / stroke / motion / label, chip style, card radius,
-- row density, carousel motion, map markers, location badges, KPI cards, home tiles …) can be set by the Chairman per company and,
-- more specifically, per wing or per position (company < wing < position). Values are schema-checked typed JSON — never CSS/JS/SQL.
-- Draft -> publish (immutable revision with full snapshot) -> rollback by publishing an older snapshot as a new revision.
-- Cosmetics never change meaning: the payment tick is shown only when the server says the payment is verified and posted;
-- visibility here can only HIDE what the server already allows; colours keep contrast (>= 3.0 for marks, >= 4.5 for text).
-- STATUS: WRITTEN; executed with the SQL suite (t_s71_design_properties.sql).
set role erp_owner;

create table design.property_catalog (
  component_key text not null check (component_key ~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,3}$'),
  property      text not null check (property in ('color','background','icon','size_dp','stroke_dp','radius_dp','text_scale','animation','visible',
                                                  'density','style_variant','layout_variant','label_bn','interval_s')),
  name_bn       text not null,
  primary key (component_key, property)
);
create trigger trg_property_catalog_no_mutation before update or delete on design.property_catalog for each row execute function core.fn_deny_mutation();
select core.fn_apply_rls('design', 'property_catalog');
insert into design.property_catalog (component_key, property, name_bn) values
  ('payment.status.tick', 'color', 'পরিশোধ-যাচাই টিক চিহ্ন'),
  ('payment.status.tick', 'icon', 'পরিশোধ-যাচাই টিক চিহ্ন'),
  ('payment.status.tick', 'size_dp', 'পরিশোধ-যাচাই টিক চিহ্ন'),
  ('payment.status.tick', 'stroke_dp', 'পরিশোধ-যাচাই টিক চিহ্ন'),
  ('payment.status.tick', 'animation', 'পরিশোধ-যাচাই টিক চিহ্ন'),
  ('payment.status.tick', 'label_bn', 'পরিশোধ-যাচাই টিক চিহ্ন'),
  ('payment.status.pending', 'color', 'পরিশোধ অপেক্ষমাণ চিহ্ন'),
  ('payment.status.pending', 'icon', 'পরিশোধ অপেক্ষমাণ চিহ্ন'),
  ('payment.status.pending', 'label_bn', 'পরিশোধ অপেক্ষমাণ চিহ্ন'),
  ('dealer.due.amount', 'color', 'ডিলারের বকেয়া অঙ্ক'),
  ('dealer.due.amount', 'text_scale', 'ডিলারের বকেয়া অঙ্ক'),
  ('dealer.due.amount', 'visible', 'ডিলারের বকেয়া অঙ্ক'),
  ('dealer.header', 'background', 'ডিলার-অ্যাপের মাথা'),
  ('dealer.header', 'color', 'ডিলার-অ্যাপের মাথা'),
  ('dealer.header', 'layout_variant', 'ডিলার-অ্যাপের মাথা'),
  ('dealer.nav', 'style_variant', 'ডিলার-অ্যাপের নেভিগেশন'),
  ('dealer.nav', 'color', 'ডিলার-অ্যাপের নেভিগেশন'),
  ('order.card', 'radius_dp', 'অর্ডার কার্ড'),
  ('order.card', 'text_scale', 'অর্ডার কার্ড'),
  ('order.card', 'background', 'অর্ডার কার্ড'),
  ('order.card', 'density', 'অর্ডার কার্ড'),
  ('order.status.chip', 'radius_dp', 'অর্ডার/DO অবস্থার চিপ'),
  ('order.status.chip', 'style_variant', 'অর্ডার/DO অবস্থার চিপ'),
  ('approval.timeline', 'color', 'অনুমোদনের সময়রেখা'),
  ('approval.timeline', 'stroke_dp', 'অনুমোদনের সময়রেখা'),
  ('approval.timeline', 'style_variant', 'অনুমোদনের সময়রেখা'),
  ('ledger.row', 'density', 'খাতার সারি'),
  ('ledger.row', 'text_scale', 'খাতার সারি'),
  ('ledger.row', 'background', 'খাতার সারি'),
  ('offer.carousel', 'animation', 'অফার-ক্যারোসেল'),
  ('offer.carousel', 'radius_dp', 'অফার-ক্যারোসেল'),
  ('offer.carousel', 'interval_s', 'অফার-ক্যারোসেল'),
  ('notice.card', 'background', 'নোটিশ কার্ড'),
  ('notice.card', 'color', 'নোটিশ কার্ড'),
  ('notice.card', 'radius_dp', 'নোটিশ কার্ড'),
  ('notice.card', 'icon', 'নোটিশ কার্ড'),
  ('image.thumb', 'radius_dp', 'ছবির কোণ'),
  ('kpi.card', 'background', 'KPI কার্ড'),
  ('kpi.card', 'color', 'KPI কার্ড'),
  ('kpi.card', 'radius_dp', 'KPI কার্ড'),
  ('kpi.card', 'text_scale', 'KPI কার্ড'),
  ('home.icon.tile', 'background', 'হোমের আইকন-টাইল'),
  ('home.icon.tile', 'color', 'হোমের আইকন-টাইল'),
  ('home.icon.tile', 'radius_dp', 'হোমের আইকন-টাইল'),
  ('home.icon.tile', 'size_dp', 'হোমের আইকন-টাইল'),
  ('map.marker.dealer', 'color', 'ম্যাপে ডিলার-চিহ্ন'),
  ('map.marker.dealer', 'icon', 'ম্যাপে ডিলার-চিহ্ন'),
  ('map.marker.dealer', 'size_dp', 'ম্যাপে ডিলার-চিহ্ন'),
  ('map.marker.officer', 'color', 'ম্যাপে মাঠকর্মী-চিহ্ন'),
  ('map.marker.officer', 'icon', 'ম্যাপে মাঠকর্মী-চিহ্ন'),
  ('map.marker.officer', 'size_dp', 'ম্যাপে মাঠকর্মী-চিহ্ন'),
  ('map.marker.market', 'color', 'ম্যাপে বাজার-সীমানা'),
  ('map.marker.market', 'stroke_dp', 'ম্যাপে বাজার-সীমানা'),
  ('location.badge.unverified', 'color', 'অবস্থান: যাচাই হয়নি'),
  ('location.badge.unverified', 'icon', 'অবস্থান: যাচাই হয়নি'),
  ('location.badge.unverified', 'label_bn', 'অবস্থান: যাচাই হয়নি'),
  ('location.badge.approved', 'color', 'অবস্থান: অনুমোদিত'),
  ('location.badge.approved', 'icon', 'অবস্থান: অনুমোদিত'),
  ('location.badge.approved', 'label_bn', 'অবস্থান: অনুমোদিত'),
  ('button.primary', 'background', 'প্রধান বোতাম'),
  ('button.primary', 'radius_dp', 'প্রধান বোতাম');

create table design.property_value (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  scope_kind    text not null check (scope_kind in ('company','wing','territory','position')),
  scope_ref     text,                                          -- wing id / territory id (dealer app, per market area) / position code; null for company
  component_key text not null,
  property      text not null,
  value         jsonb not null,
  status        text not null default 'draft' check (status in ('draft','published','superseded','withdrawn')),
  revision      integer,
  set_by        uuid not null references core.person(id),
  reason        text not null check (length(btrim(reason)) > 0),
  created_at    timestamptz not null default clock_timestamp(),
  check ((scope_kind = 'company') = (scope_ref is null)),
  foreign key (component_key, property) references design.property_catalog (component_key, property)
);
create unique index ux_property_draft on design.property_value (company_id, scope_kind, coalesce(scope_ref, ''), component_key, property) where status = 'draft';
create unique index ux_property_published on design.property_value (company_id, scope_kind, coalesce(scope_ref, ''), component_key, property) where status = 'published';
create function design.fn_property_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status in ('published','superseded','withdrawn') and (new.value is distinct from old.value or new.component_key <> old.component_key or new.property <> old.property) then
    raise exception 'E_IMMUTABLE: a published property value never changes; publish a new revision' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_property_guard before update on design.property_value for each row execute function design.fn_property_guard();
create trigger trg_property_value_nodel before delete on design.property_value for each row execute function core.fn_deny_delete();
create trigger trg_property_value_audit after insert or update on design.property_value for each row execute function audit.fn_row_change();
select core.fn_apply_rls('design', 'property_value');

create table design.property_release (
  company_id   uuid not null references core.company(id),
  revision     integer not null check (revision >= 1),
  snapshot     jsonb not null,                                -- [{scope_kind, scope_ref, component_key, property, value}]
  published_by uuid not null references core.person(id),
  reason       text not null,
  rollback_of  integer,
  published_at timestamptz not null default clock_timestamp(),
  primary key (company_id, revision)
);
create trigger trg_property_release_no_mutation before update or delete on design.property_release for each row execute function core.fn_deny_mutation();
select core.fn_apply_rls('design', 'property_release');

-- One value checked against its property type. Returns null when fine, otherwise the Bengali-free technical reason.
create function design.fn_property_check(p_property text, v jsonb) returns text
language plpgsql stable set search_path = pg_catalog as $$
declare n numeric; s text := v #>> '{}';
begin
  case p_property
    when 'color', 'background' then
      if jsonb_typeof(v) <> 'string' or not design.fn_hex_ok(s) then return 'colour must be #RRGGBB'; end if;
      -- marks need 3.0 against the white surface; a background must keep dark text readable (4.5)
      if p_property = 'color' and design.fn_contrast(s, '#FFFFFF') < 3.0 then return 'colour too light on white (contrast < 3.0)'; end if;
      if p_property = 'background' and design.fn_contrast(s, '#1F2430') < 4.5 then return 'background too dark for text (contrast < 4.5)'; end if;
    when 'icon' then
      if jsonb_typeof(v) <> 'string' or not exists (select 1 from design.icon_catalog i where i.name = s) then return 'icon not in the icon catalogue'; end if;
    when 'size_dp' then n := case when jsonb_typeof(v) = 'number' then s::numeric end; if n is null or n not between 12 and 96 then return 'size 12–96 dp'; end if;
    when 'stroke_dp' then n := case when jsonb_typeof(v) = 'number' then s::numeric end; if n is null or n not between 0 and 8 then return 'stroke 0–8 dp'; end if;
    when 'radius_dp' then n := case when jsonb_typeof(v) = 'number' then s::numeric end; if n is null or n not between 0 and 32 then return 'radius 0–32 dp'; end if;
    when 'text_scale' then n := case when jsonb_typeof(v) = 'number' then s::numeric end; if n is null or n not between 0.85 and 1.30 then return 'text scale 0.85–1.30'; end if;
    when 'interval_s' then n := case when jsonb_typeof(v) = 'number' then s::numeric end; if n is null or n not between 3 and 30 then return 'interval 3–30 s'; end if;
    when 'animation' then if s not in ('none','subtle','standard') then return 'animation none / subtle / standard (reduced motion always respected)'; end if;
    when 'visible' then if jsonb_typeof(v) <> 'boolean' then return 'visible true / false'; end if;
    when 'density' then if s not in ('compact','regular','comfortable') then return 'density compact / regular / comfortable'; end if;
    when 'style_variant' then if s not in ('filled','outlined','tonal','text') then return 'style filled / outlined / tonal / text'; end if;
    when 'layout_variant' then if s not in ('compact','regular','expanded') then return 'layout compact / regular / expanded'; end if;
    when 'label_bn' then
      if jsonb_typeof(v) <> 'string' or length(btrim(s)) not between 1 and 40 or s ~ '[<>{}$;]' then return 'label 1–40 plain characters'; end if;
    else return 'unknown property';
  end case;
  return null;
end $$;

create function api.v1_design_property_catalog() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return jsonb_build_object(
    'catalog', (select jsonb_agg(jsonb_build_object('component', c.component_key, 'name_bn', c.name_bn, 'property', c.property) order by c.component_key, c.property) from design.property_catalog c),
    'values', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'scope_kind', v.scope_kind, 'scope_ref', v.scope_ref, 'component', v.component_key, 'property', v.property,
                                                           'value', v.value, 'status', v.status, 'revision', v.revision) order by v.component_key, v.property)
                         from design.property_value v where v.company_id = me.company_id and v.status in ('draft','published')), '[]'::jsonb),
    'revision', (select max(r.revision) from design.property_release r where r.company_id = me.company_id));
end $$;

-- Draft one value (replaces an earlier draft of the same key). p_value null = remove the override in the next release.
create function api.v1_design_property_set(p_scope_kind text, p_scope_ref text, p_component text, p_property text, p_value jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_err text; v uuid;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if coalesce(p_scope_kind, '') not in ('company','wing','territory','position') or ((p_scope_kind = 'company') <> (p_scope_ref is null)) then perform core.fn_raise('E_INVALID_ACTION', 'scope'); end if;
  if p_scope_kind = 'wing' and not exists (select 1 from core.wing w where w.id::text = p_scope_ref and w.company_id = me.company_id) then perform core.fn_raise('E_WRONG_COMPANY', 'wing'); end if;
  if p_scope_kind = 'territory' and not exists (select 1 from sales.territory t where t.id::text = p_scope_ref and t.company_id = me.company_id) then perform core.fn_raise('E_WRONG_COMPANY', 'territory'); end if;
  if p_scope_kind = 'position' and not exists (select 1 from iam.position_catalog c where c.company_id = me.company_id and c.code = p_scope_ref) then perform core.fn_raise('E_NOT_FOUND', 'position'); end if;
  if not exists (select 1 from design.property_catalog c where c.component_key = p_component and c.property = p_property) then perform core.fn_raise('E_NOT_FOUND', 'component property'); end if;
  if p_value is not null then
    v_err := design.fn_property_check(p_property, p_value);
    if v_err is not null then perform core.fn_raise('E_DESIGN_INVALID', p_component || '.' || p_property || ': ' || v_err); end if;
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update design.property_value set status = 'withdrawn' where company_id = me.company_id and scope_kind = p_scope_kind and coalesce(scope_ref, '') = coalesce(p_scope_ref, '')
     and component_key = p_component and property = p_property and status = 'draft';
  insert into design.property_value (company_id, scope_kind, scope_ref, component_key, property, value, set_by, reason)
  values (me.company_id, p_scope_kind, p_scope_ref, p_component, p_property, coalesce(p_value, 'null'::jsonb), me.person_id, btrim(p_reason)) returning id into v;
  return jsonb_build_object('value_id', v, 'status', 'draft');
end $$;

create function design.fn_property_snapshot(p_company uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(jsonb_agg(jsonb_build_object('scope_kind', v.scope_kind, 'scope_ref', v.scope_ref, 'component', v.component_key, 'property', v.property, 'value', v.value)
                            order by v.scope_kind, v.scope_ref, v.component_key, v.property), '[]'::jsonb)
    from design.property_value v where v.company_id = p_company and v.status = 'published'
$$;

-- Publish every draft as one new revision (Chairman; design-only, so no second reviewer — V168-03).
create function api.v1_design_property_publish(p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; c uuid := iam.fn_context_company(); v_rev integer; d record; n integer := 0;
begin
  v_ch := core.fn_require_chairman(null);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if not exists (select 1 from design.property_value v where v.company_id = c and v.status = 'draft') then perform core.fn_raise('E_INVALID_ACTION', 'nothing to publish'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  v_rev := coalesce((select max(r.revision) from design.property_release r where r.company_id = c), 0) + 1;
  for d in select * from design.property_value v where v.company_id = c and v.status = 'draft' loop
    update design.property_value set status = 'superseded' where company_id = c and scope_kind = d.scope_kind and coalesce(scope_ref, '') = coalesce(d.scope_ref, '')
       and component_key = d.component_key and property = d.property and status = 'published';
    update design.property_value set status = case when d.value = 'null'::jsonb then 'withdrawn' else 'published' end, revision = v_rev where id = d.id;
    n := n + 1;
  end loop;
  insert into design.property_release (company_id, revision, snapshot, published_by, reason) values (c, v_rev, design.fn_property_snapshot(c), v_ch, btrim(p_reason));
  return jsonb_build_object('revision', v_rev, 'changed', n);
end $$;

-- Roll back = publish the snapshot of an older revision as a NEW revision (history is never rewritten).
create function api.v1_design_property_rollback(p_revision integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; c uuid := iam.fn_context_company(); r design.property_release%rowtype; v_rev integer; x jsonb;
begin
  v_ch := core.fn_require_chairman(null);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into r from design.property_release where company_id = c and revision = p_revision;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'revision'); end if;
  perform set_config('mohona.change_reason', 'rollback to ' || p_revision || ': ' || p_reason, true);
  v_rev := (select max(x2.revision) from design.property_release x2 where x2.company_id = c) + 1;
  update design.property_value set status = 'withdrawn' where company_id = c and status = 'draft';
  update design.property_value set status = 'superseded' where company_id = c and status = 'published';
  for x in select * from jsonb_array_elements(r.snapshot) loop
    insert into design.property_value (company_id, scope_kind, scope_ref, component_key, property, value, status, revision, set_by, reason)
    values (c, x ->> 'scope_kind', x ->> 'scope_ref', x ->> 'component', x ->> 'property', x -> 'value', 'published', v_rev, v_ch, 'rollback to ' || p_revision);
  end loop;
  insert into design.property_release (company_id, revision, snapshot, published_by, reason, rollback_of) values (c, v_rev, design.fn_property_snapshot(c), v_ch, btrim(p_reason), p_revision);
  return jsonb_build_object('revision', v_rev, 'rollback_of', p_revision);
end $$;

-- Effective values for the current user (company < wing < position). p_preview_position: the Chairman previews another position.
create function api.v1_design_properties(p_preview_position text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_pos text; v_wing text; v_terr text;
begin
  select * into me from iam.fn_context(false);
  if p_preview_position is not null and not coalesce(me.is_supreme, false) then perform core.fn_raise('E_CHAIRMAN_ONLY', 'preview as another position'); end if;
  v_pos := coalesce(p_preview_position, me.position_code); v_wing := case when p_preview_position is null then me.home_wing_id::text end;
  -- dealer app: the dealer's territory gives a per-market-area look (V161 08-16)
  select d.territory_id::text into v_terr from sales.dealer_user u join sales.dealer d on d.id = u.dealer_id
   where p_preview_position is null and u.company_id = me.company_id and u.person_id = me.person_id and u.status = 'active' limit 1;
  return coalesce((select jsonb_object_agg(k, val) from (
      select distinct on (v.component_key, v.property) v.component_key || '.' || v.property k, v.value val
        from design.property_value v
       where v.company_id = me.company_id and v.status = 'published'
         and (v.scope_kind = 'company' or (v.scope_kind = 'wing' and v.scope_ref = v_wing) or (v.scope_kind = 'territory' and v.scope_ref = v_terr)
              or (v.scope_kind = 'position' and v.scope_ref = v_pos))
       order by v.component_key, v.property, case v.scope_kind when 'position' then 1 when 'territory' then 2 when 'wing' then 3 else 4 end) q), '{}'::jsonb);
end $$;

-- the active design now also carries the effective component properties for this user (S71)
create or replace function api.v1_design_active() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object(
    'theme', (select jsonb_build_object('theme_id', t.id, 'code', t.code, 'version', v.version, 'tokens', v.tokens)
                from design.theme t join design.theme_version v on v.theme_id = t.id and v.version = t.active_version
               where t.company_id = me.company_id and t.is_active),
    'icons', coalesce((select jsonb_agg(jsonb_build_object('target_key', b.target_key, 'icon', b.icon_name, 'permission', b.permission_code, 'version', b.version)
                                        order by b.target_key)
                         from design.icon_binding b where b.company_id = me.company_id and b.status = 'active'), '[]'::jsonb),
    'layouts', coalesce((select jsonb_object_agg(l.screen_key, jsonb_build_object('version', l.version, 'layout', l.layout))
                           from design.screen_layout l where l.company_id = me.company_id and l.status = 'published'), '{}'::jsonb),
    'motion', jsonb_build_object('duration_ms', config.fn_get_int(me.company_id, 'design.motion.duration_ms'),
                                 'easing', config.fn_get_text(me.company_id, 'design.motion.easing'),
                                 'reduced', config.fn_get_text(me.company_id, 'design.motion.reduced')),
    'ads', config.fn_flag(me.company_id, 'design.ad_slots', me.home_wing_id),
    'ads_visible_max', config.fn_get_int(me.company_id, 'design.ads.visible_max'),
    'props', api.v1_design_properties(null),
    'ad_media', case when config.fn_flag(me.company_id, 'design.ad_slots', me.home_wing_id) then
                  coalesce((select jsonb_agg(jsonb_build_object('slot', a.slot, 'title_bn', a.title_bn, 'image_path', a.image_path) order by a.slot)
                              from design.ad_media a where a.company_id = me.company_id and a.status = 'active'
                               and (a.valid_until is null or a.valid_until > clock_timestamp())), '[]'::jsonb) else '[]'::jsonb end);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_design_property_catalog()', 'api.v1_design_property_set(text, text, text, text, jsonb, text)', 'api.v1_design_property_publish(text)',
      'api.v1_design_property_rollback(integer, text)', 'api.v1_design_properties(text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- 20261108001800_design_studio_2.sql  (S19)
-- Design Studio 2 (blueprint CHAIRMAN_DESIGN MOS-F153-006..010):
--   006 layout grid: per-screen widget grids (snap to cells, no overlaps, inside the grid); when the company runs ad
--       slots (flag design.ad_slots) every published layout keeps the required number of ad slots
--   007 preset gallery: platform layout presets; a fork is a company draft. Layouts carry only widget bindings — no
--       grant, rule or permission field exists, so no preset can ever give data access (data RPCs still authorise)
--   008 motion: duration / easing / reduced-motion policy as Chairman settings; "ignore the system reduce-motion
--       setting" is not an option
--   009 responsive preview: phone / tablet / landscape breakpoints validated separately; approval controls must sit in
--       the first rows (never pushed off-screen) and keep a usable width
--   010 rollback: an earlier theme or layout version is published again — versions are immutable, business data is
--       never touched, every switch is audited
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create table design.layout_preset (
  code        text primary key check (code ~ '^[A-Z][A-Z0-9_]{2,30}$'),
  name_bn     text not null,
  screen_key  text not null,
  layout      jsonb not null,
  sort_order  integer not null default 0
);
create trigger trg_layout_preset_nodel before delete on design.layout_preset for each row execute function core.fn_deny_delete();

create table design.screen_layout (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null references core.company(id),
  screen_key          text not null check (screen_key ~ '^(home|wing\.[a-z_]{2,30}|dashboard\.[a-z_]{2,30}|module\.[a-z_]{2,30})$'),
  version             integer not null check (version >= 1),
  layout              jsonb not null,
  report              jsonb not null,
  status              text not null default 'draft' check (status in ('draft','pending_approval','published','superseded')),
  from_preset         text references design.layout_preset(code),
  reason              text not null check (length(btrim(reason)) > 0),
  created_by          uuid,
  created_at          timestamptz not null default clock_timestamp(),
  published_at        timestamptz,
  approval_request_id uuid,
  unique (company_id, screen_key, version)
);
create unique index screen_layout_one_published on design.screen_layout (company_id, screen_key) where status = 'published';
create function design.fn_screen_layout_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','published_at','approval_request_id']) <> (to_jsonb(new) - array['status','published_at','approval_request_id']) then
    raise exception 'E_IMMUTABLE: a layout version never changes; save a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_screen_layout_guard before update on design.screen_layout for each row execute function design.fn_screen_layout_guard();
create trigger trg_screen_layout_nodel before delete on design.screen_layout for each row execute function core.fn_deny_delete();
create trigger trg_screen_layout_audit after insert or update on design.screen_layout for each row execute function audit.fn_row_change();

select core.fn_apply_rls('design', 'layout_preset');
select core.fn_apply_rls('design', 'screen_layout');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('design.ads.min_slots',            'design', 'int',  '1', 0, 3, null, 'বিজ্ঞাপন চালু থাকলে প্রতি লেআউটে ন্যূনতম স্লট', 'MOS-F153-006', false, 910),
  ('design.layout.approval_max_row',  'design', 'int',  '4', 2, 10, null, 'অনুমোদন-বোতাম সর্বোচ্চ কোন সারি পর্যন্ত (পর্দার বাইরে নয়)', 'MOS-F153-009', false, 920),
  ('design.motion.duration_ms',       'design', 'int',  '200', 0, 600, null, 'অ্যানিমেশনের সময় (মিলিসেকেন্ড)', 'MOS-F153-008', false, 930),
  ('design.motion.easing',            'design', 'text', '"standard"', null, null, '["standard","emphasized","linear"]', 'অ্যানিমেশনের গতি-রেখা', 'MOS-F153-008', false, 940),
  ('design.motion.reduced',           'design', 'text', '"respect_system"', null, null, '["respect_system","always_reduce"]', 'কম-অ্যানিমেশন নীতি (ফোনের সেটিং সবসময় মানা হয়)', 'MOS-F153-008', false, 950);

-- ================================================================ layout validation
-- {"breakpoints":{"phone":{"columns":4,"widgets":[{"id","type","x","y","w","h","binding","title_bn"}]},"tablet":{...},"landscape":{...}}}
create function design.fn_layout_report(p jsonb, p_ads_required integer, p_approval_max_row integer) returns jsonb
language plpgsql stable set search_path = pg_catalog as $$
declare errs text[] := array[]::text[]; warns text[] := array[]::text[]; bp text; b jsonb; w jsonb; k text; cols integer; ids text[];
        cells text[]; cell text; i integer; j integer; n_ads integer; v_type text;
        c_types constant text[] := array['kpi','shortcut','list','chart','approval','ad_slot','text','calendar'];
begin
  if p is null or jsonb_typeof(p) <> 'object' then return jsonb_build_object('ok', false, 'errors', jsonb_build_array('layout must be an object'), 'warnings', '[]'::jsonb); end if;
  if config.fn_form_has_unsafe(p) then errs := errs || 'markup or script text is not allowed'::text; end if;
  for k in select jsonb_object_keys(p) loop
    if k <> 'breakpoints' then errs := errs || ('unknown key ' || k); end if;      -- no grant / permission / rule field can exist
  end loop;
  if jsonb_typeof(p -> 'breakpoints') is distinct from 'object' or not (p -> 'breakpoints') ? 'phone' then
    return jsonb_build_object('ok', false, 'errors', to_jsonb(errs || 'breakpoints.phone is required'::text), 'warnings', '[]'::jsonb);
  end if;
  for bp, b in select * from jsonb_each(p -> 'breakpoints') loop
    if bp not in ('phone','tablet','landscape') then errs := errs || ('unknown breakpoint ' || bp); continue; end if;
    if jsonb_typeof(b) <> 'object' or exists (select 1 from jsonb_object_keys(b) x where x not in ('columns','widgets')) then
      errs := errs || (bp || ': only columns and widgets'); continue;
    end if;
    cols := case when jsonb_typeof(b -> 'columns') = 'number' then (b ->> 'columns')::integer end;
    if cols is null or (bp = 'phone' and cols not between 2 and 6) or (bp <> 'phone' and cols not between 4 and 12) then
      errs := errs || (bp || ': columns out of range'); continue;
    end if;
    if jsonb_typeof(b -> 'widgets') is distinct from 'array' or jsonb_array_length(b -> 'widgets') not between 1 and 60 then
      errs := errs || (bp || ': 1..60 widgets'); continue;
    end if;
    ids := array[]::text[]; cells := array[]::text[]; n_ads := 0;
    for w in select * from jsonb_array_elements(b -> 'widgets') loop
      if jsonb_typeof(w) <> 'object' or exists (select 1 from jsonb_object_keys(w) x where x not in ('id','type','x','y','w','h','binding','title_bn')) then
        errs := errs || (bp || ': widget has unknown fields'); continue;
      end if;
      v_type := w ->> 'type';
      if coalesce(w ->> 'id', '') !~ '^[a-z][a-z0-9_]{0,30}$' or (w ->> 'id') = any (ids) then errs := errs || (bp || ': bad or duplicate widget id'); continue; end if;
      ids := ids || (w ->> 'id');
      if not (coalesce(v_type, '') = any (c_types)) then errs := errs || (bp || ': unknown widget type ' || coalesce(v_type, '?')); continue; end if;
      if jsonb_typeof(w -> 'x') <> 'number' or jsonb_typeof(w -> 'y') <> 'number' or jsonb_typeof(w -> 'w') <> 'number' or jsonb_typeof(w -> 'h') <> 'number'
         or (w ->> 'x')::numeric <> trunc((w ->> 'x')::numeric) or (w ->> 'y')::numeric <> trunc((w ->> 'y')::numeric)
         or (w ->> 'w')::numeric <> trunc((w ->> 'w')::numeric) or (w ->> 'h')::numeric <> trunc((w ->> 'h')::numeric) then
        errs := errs || (bp || ': ' || (w ->> 'id') || ' must snap to whole cells'); continue;
      end if;
      if (w ->> 'x')::integer < 0 or (w ->> 'y')::integer not between 0 and 100 or (w ->> 'w')::integer < 1 or (w ->> 'h')::integer not between 1 and 6
         or (w ->> 'x')::integer + (w ->> 'w')::integer > cols then
        errs := errs || (bp || ': ' || (w ->> 'id') || ' outside the grid'); continue;
      end if;
      if v_type in ('kpi','list','chart') and coalesce(w ->> 'binding', '') !~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,3}$' then
        errs := errs || (bp || ': ' || (w ->> 'id') || ' needs a data binding'); continue;
      end if;
      if v_type = 'ad_slot' then n_ads := n_ads + 1; end if;
      if v_type = 'approval' then
        if (w ->> 'y')::integer + (w ->> 'h')::integer > p_approval_max_row then
          errs := errs || (bp || ': approval controls must sit within the first ' || p_approval_max_row || ' rows');
        end if;
        if (w ->> 'w')::integer * 2 < cols then errs := errs || (bp || ': approval controls need at least half the width'); end if;
      end if;
      for i in 0 .. (w ->> 'w')::integer - 1 loop
        for j in 0 .. (w ->> 'h')::integer - 1 loop
          cell := ((w ->> 'x')::integer + i) || ':' || ((w ->> 'y')::integer + j);
          if cell = any (cells) then errs := errs || (bp || ': widgets overlap at ' || cell); exit; end if;
          cells := cells || cell;
        end loop;
      end loop;
    end loop;
    if n_ads < p_ads_required then errs := errs || (bp || ': ' || p_ads_required || ' advertisement slot(s) are mandatory'); end if;
  end loop;
  if not (p -> 'breakpoints') ? 'tablet' then warns := warns || 'no tablet layout: the phone layout is stretched'::text; end if;
  return jsonb_build_object('ok', cardinality(errs) = 0, 'errors', to_jsonb(errs), 'warnings', to_jsonb(warns));
end $$;

-- Limits of this company (ad slots only while the company runs them).
create function design.fn_layout_report_for(p_company uuid, p_layout jsonb) returns jsonb
language sql stable security definer set search_path = pg_catalog as $$
  select design.fn_layout_report(p_layout,
           case when config.fn_flag(p_company, 'design.ad_slots', null) then config.fn_get_int(p_company, 'design.ads.min_slots') else 0 end,
           config.fn_get_int(p_company, 'design.layout.approval_max_row'))
$$;

-- ================================================================ presets
create function design.fn_w(p_id text, p_type text, x integer, y integer, w integer, h integer, p_binding text default null) returns jsonb
language sql immutable set search_path = pg_catalog as $$
  select jsonb_strip_nulls(jsonb_build_object('id', p_id, 'type', p_type, 'x', x, 'y', y, 'w', w, 'h', h, 'binding', p_binding))
$$;
insert into design.layout_preset (code, name_bn, screen_key, layout, sort_order) values
  ('HOME_STANDARD', 'হোম — সাধারণ', 'home', jsonb_build_object('breakpoints', jsonb_build_object(
     'phone', jsonb_build_object('columns', 4, 'widgets', jsonb_build_array(
        design.fn_w('sales', 'kpi', 0, 0, 2, 1, 'kpi.dms.sales'), design.fn_w('cash', 'kpi', 2, 0, 2, 1, 'kpi.fin.cash'),
        design.fn_w('approvals', 'approval', 0, 1, 4, 1), design.fn_w('shortcuts', 'shortcut', 0, 2, 4, 2),
        design.fn_w('ad1', 'ad_slot', 0, 4, 4, 1), design.fn_w('tasks', 'list', 0, 5, 4, 2, 'list.my_tasks'))),
     'tablet', jsonb_build_object('columns', 8, 'widgets', jsonb_build_array(
        design.fn_w('sales', 'kpi', 0, 0, 2, 1, 'kpi.dms.sales'), design.fn_w('cash', 'kpi', 2, 0, 2, 1, 'kpi.fin.cash'),
        design.fn_w('approvals', 'approval', 4, 0, 4, 2), design.fn_w('shortcuts', 'shortcut', 0, 1, 4, 2),
        design.fn_w('ad1', 'ad_slot', 0, 3, 8, 1), design.fn_w('tasks', 'list', 0, 4, 8, 2, 'list.my_tasks'))))), 10),
  ('HOME_COMPACT', 'হোম — ঘন', 'home', jsonb_build_object('breakpoints', jsonb_build_object(
     'phone', jsonb_build_object('columns', 4, 'widgets', jsonb_build_array(
        design.fn_w('approvals', 'approval', 0, 0, 4, 1), design.fn_w('sales', 'kpi', 0, 1, 2, 1, 'kpi.dms.sales'),
        design.fn_w('stock', 'kpi', 2, 1, 2, 1, 'kpi.stock.total_value'), design.fn_w('ad1', 'ad_slot', 0, 2, 4, 1),
        design.fn_w('shortcuts', 'shortcut', 0, 3, 4, 2))))), 20),
  ('MD_DASHBOARD', 'এমডি ড্যাশবোর্ড', 'dashboard.md', jsonb_build_object('breakpoints', jsonb_build_object(
     'phone', jsonb_build_object('columns', 4, 'widgets', jsonb_build_array(
        design.fn_w('approvals', 'approval', 0, 0, 4, 1), design.fn_w('sales', 'chart', 0, 1, 4, 2, 'kpi.dms.collected'),
        design.fn_w('margin', 'kpi', 0, 3, 2, 1, 'kpi.fin.gross_margin'), design.fn_w('receivable', 'kpi', 2, 3, 2, 1, 'kpi.dms.receivable'),
        design.fn_w('ad1', 'ad_slot', 0, 4, 4, 1), design.fn_w('calendar', 'calendar', 0, 5, 4, 2))))), 30);

-- ================================================================ publish / rollback (layouts and themes) + approval handler
create function design.fn_publish_layout_version(p_company uuid, p_screen text, p_version integer) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  update design.screen_layout set status = 'superseded' where company_id = p_company and screen_key = p_screen and status = 'published';
  update design.screen_layout set status = 'published', published_at = clock_timestamp()
   where company_id = p_company and screen_key = p_screen and version = p_version;
end $$;

-- Rollback support: re-publishing a superseded theme version (S18 helper kept every earlier version immutable).
create or replace function design.fn_publish_theme_version(p_company uuid, p_theme uuid, p_version integer) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  update design.theme_version set status = 'superseded' where theme_id = p_theme and company_id = p_company and status = 'published' and version <> p_version;
  update design.theme_version set status = 'published', published_at = clock_timestamp() where theme_id = p_theme and company_id = p_company and version = p_version;
  update design.theme set is_active = false where company_id = p_company and is_active and id <> p_theme;
  update design.theme set is_active = true, active_version = p_version where id = p_theme and company_id = p_company;
end $$;

create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'design.layout_publish' then perform design.fn_publish_layout_version(r.company_id, r.payload ->> 'screen_key', (r.payload ->> 'version')::integer);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- ================================================================ API
create function api.v1_design_presets(p_screen_key text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', p.code, 'name_bn', p.name_bn, 'screen_key', p.screen_key, 'layout', p.layout,
                                                       'report', design.fn_layout_report_for(me.company_id, p.layout)) order by p.sort_order)
                     from design.layout_preset p where p_screen_key is null or p.screen_key = p_screen_key), '[]'::jsonb);
end $$;

-- Responsive preview: the report for every breakpoint under this company's limits (nothing stored).
create function api.v1_design_layout_validate(p_layout jsonb) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return design.fn_layout_report_for(me.company_id, p_layout);
end $$;

create function api.v1_design_layout_save(p_screen_key text, p_layout jsonb, p_from_preset text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_layout jsonb := p_layout; v integer; rep jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), true);
  if coalesce(p_screen_key, '') !~ '^(home|wing\.[a-z_]{2,30}|dashboard\.[a-z_]{2,30}|module\.[a-z_]{2,30})$' then
    perform core.fn_raise('E_DESIGN_LAYOUT', 'screen key');
  end if;
  if v_layout is null then
    select x.layout into v_layout from design.layout_preset x where x.code = p_from_preset;
    if v_layout is null then perform core.fn_raise('E_NOT_FOUND', 'preset'); end if;
  end if;
  if length(v_layout::text) > 65536 then perform core.fn_raise('E_DESIGN_LAYOUT', 'layout larger than 64 KB'); end if;
  rep := design.fn_layout_report_for(me.company_id, v_layout);
  perform set_config('mohona.change_reason', p_reason, true);
  perform pg_advisory_xact_lock(hashtext(me.company_id::text || p_screen_key));
  v := coalesce((select max(x.version) from design.screen_layout x where x.company_id = me.company_id and x.screen_key = p_screen_key), 0) + 1;
  insert into design.screen_layout (company_id, screen_key, version, layout, report, from_preset, reason, created_by)
  values (me.company_id, p_screen_key, v, v_layout, rep, p_from_preset, p_reason, me.person_id);
  return jsonb_build_object('screen_key', p_screen_key, 'version', v, 'report', rep);
end $$;

create function api.v1_design_layouts(p_screen_key text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('version', l.version, 'status', l.status, 'ok', (l.report ->> 'ok')::boolean, 'report', l.report,
                                                       'from_preset', l.from_preset, 'reason', l.reason, 'created_at', l.created_at,
                                                       'published_at', l.published_at, 'layout', l.layout) order by l.version desc)
                     from design.screen_layout l where l.company_id = me.company_id and l.screen_key = p_screen_key), '[]'::jsonb);
end $$;

-- publish (a draft) | rollback (an earlier superseded version). Re-validated under TODAY's rules either way.
create function api.v1_design_layout_publish(p_screen_key text, p_version integer, p_action text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; l design.screen_layout%rowtype; rep jsonb; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.publish', iam.fn_my_company_resource(), true);
  perform pg_advisory_xact_lock(hashtext(me.company_id::text || coalesce(p_screen_key, '')));
  select * into l from design.screen_layout where company_id = me.company_id and screen_key = p_screen_key and version = p_version;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'layout version'); end if;
  if not ((p_action = 'publish' and l.status = 'draft') or (p_action = 'rollback' and l.status = 'superseded')) then
    perform core.fn_raise('E_INVALID_ACTION', coalesce(p_action, '?') || ' from ' || l.status);
  end if;
  rep := design.fn_layout_report_for(me.company_id, l.layout);
  if not (rep ->> 'ok')::boolean then perform core.fn_raise('E_DESIGN_LAYOUT', coalesce(rep -> 'errors' ->> 0, 'validation failed')); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action = 'publish' and config.fn_get_bool(me.company_id, 'design.publish.requires_approval') then
    j := core.fn_approval_submit(me.company_id, 'design.layout_publish', l.id, 0, iam.fn_resource(me.company_id),
                                 jsonb_build_object('screen_key', l.screen_key, 'version', l.version));
    if j ->> 'status' <> 'approved' then
      update design.screen_layout set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = l.id;
      return jsonb_build_object('status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
  end if;
  perform design.fn_publish_layout_version(me.company_id, l.screen_key, l.version);
  return jsonb_build_object('status', 'published', 'screen_key', l.screen_key, 'version', l.version);
end $$;

-- Theme rollback (F010): an earlier version of a theme goes live again, if it still passes today's validation.
create function api.v1_design_theme_rollback(p_theme_id uuid, p_version integer, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t design.theme%rowtype; v design.theme_version%rowtype; rep jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.publish', iam.fn_my_company_resource(), true);
  select * into t from design.theme where id = p_theme_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'theme'); end if;
  if t.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  select * into v from design.theme_version where theme_id = t.id and version = p_version;
  if not found or v.status not in ('superseded','published') then perform core.fn_raise('E_INVALID_ACTION', 'only an earlier published version'); end if;
  rep := design.fn_tokens_report(v.tokens);
  if not (rep ->> 'ok')::boolean then perform core.fn_raise('E_DESIGN_CONTRAST', coalesce(rep -> 'errors' ->> 0, 'validation failed')); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform design.fn_publish_theme_version(me.company_id, t.id, v.version);
  return jsonb_build_object('status', 'published', 'theme_id', t.id, 'version', v.version);
end $$;

-- Everything the app frame applies (S18 + S19): theme, icons, published layouts and the motion policy.
create or replace function api.v1_design_active() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object(
    'theme', (select jsonb_build_object('theme_id', t.id, 'code', t.code, 'version', v.version, 'tokens', v.tokens)
                from design.theme t join design.theme_version v on v.theme_id = t.id and v.version = t.active_version
               where t.company_id = me.company_id and t.is_active),
    'icons', coalesce((select jsonb_agg(jsonb_build_object('target_key', b.target_key, 'icon', b.icon_name, 'permission', b.permission_code, 'version', b.version)
                                        order by b.target_key)
                         from design.icon_binding b where b.company_id = me.company_id and b.status = 'active'), '[]'::jsonb),
    'layouts', coalesce((select jsonb_object_agg(l.screen_key, jsonb_build_object('version', l.version, 'layout', l.layout))
                           from design.screen_layout l where l.company_id = me.company_id and l.status = 'published'), '{}'::jsonb),
    'motion', jsonb_build_object('duration_ms', config.fn_get_int(me.company_id, 'design.motion.duration_ms'),
                                 'easing', config.fn_get_text(me.company_id, 'design.motion.easing'),
                                 'reduced', config.fn_get_text(me.company_id, 'design.motion.reduced')),
    'ads', config.fn_flag(me.company_id, 'design.ad_slots', me.home_wing_id));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_design_presets(text)', 'api.v1_design_layout_validate(jsonb)', 'api.v1_design_layout_save(text, jsonb, text, text)',
      'api.v1_design_layouts(text)', 'api.v1_design_layout_publish(text, integer, text, text)',
      'api.v1_design_theme_rollback(uuid, integer, integer, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

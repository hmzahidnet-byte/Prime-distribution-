-- 20261108000600_iam_permissions_authorize.sql  (S07)
-- ONE permission vocabulary (iam.permission_catalog, platform-owned codes), Chairman-editable permission matrix per
-- company (position rules) + per-person overrides (assignment rules), and THE authorization resolver every business
-- RPC calls: iam.fn_authorize / iam.fn_require.
-- Decision order (blueprint 113/123/140): live person -> live single active position (S06) -> permission exists AND is
-- active -> resource belongs to the caller's company -> supreme Chairman (OWN-01) -> assignment rules (deny > allow)
-- -> position rules (deny > allow) -> default DENY. Scopes are matched against SERVER-resolved resource attributes.
-- No union across positions. Catalog status 'registered' = module not built yet => denied for everyone (incl. Chairman).
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ---------------------------------------------------------------- vocabulary
create table iam.permission_catalog (
  code            text primary key check (code ~ '^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,3}$'),
  module          text not null check (module ~ '^[a-z][a-z0-9_]*$'),
  name_bn         text not null,
  description_bn  text,
  action_kind     text not null check (action_kind in ('read','write','approve','post','admin','export')),
  is_sensitive    boolean not null default false,
  is_delegable    boolean not null default true,
  requires_aal2   boolean not null default false,
  allowed_scopes  text[] not null check (cardinality(allowed_scopes) > 0
                    and allowed_scopes <@ array['COMPANY','WING','DEPARTMENT','LOCATION','WAREHOUSE','ASSIGNED','SELF']),
  status          text not null default 'registered' check (status in ('registered','active','retired')),
  sort_order      integer not null default 0,
  check (split_part(code, '.', 1) = module)
);
-- Platform vocabulary: only migrations add/activate codes (a module becomes 'active' in the step that builds it).
create trigger trg_permission_catalog_no_delete before delete on iam.permission_catalog for each row execute function core.fn_deny_delete();

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('iam.self.read', 'iam', 'নিজের পরিচয় ও পদ দেখা', 'read', false, true, array['SELF'], 'active', 0),
  ('iam.position.read', 'iam', 'পদ-তালিকা ও ধারক দেখা', 'read', false, true, array['COMPANY'], 'active', 10),
  ('iam.position.manage', 'iam', 'পদ-তালিকা সম্পাদনা', 'admin', true, false, array['COMPANY'], 'active', 20),
  ('iam.assignment.manage', 'iam', 'পদে নিয়োগ/অব্যাহতি', 'admin', true, false, array['COMPANY','WING','DEPARTMENT'], 'active', 30),
  ('iam.membership.manage', 'iam', 'কোম্পানি-সদস্যপদ ব্যবস্থাপনা', 'admin', true, false, array['COMPANY'], 'active', 40),
  ('iam.permission.read', 'iam', 'অনুমতি-ম্যাট্রিক্স দেখা', 'read', false, true, array['COMPANY'], 'active', 50),
  ('iam.permission.manage', 'iam', 'অনুমতি-ম্যাট্রিক্স সম্পাদনা', 'admin', true, false, array['COMPANY'], 'active', 60),
  ('iam.delegation.manage', 'iam', 'ক্ষমতা-অর্পণ (Delegation)', 'admin', true, false, array['COMPANY'], 'active', 70),
  ('iam.session.revoke', 'iam', 'অন্যের সেশন বাতিল', 'admin', true, false, array['COMPANY'], 'active', 80),
  ('core.structure.read', 'core', 'কোম্পানি-কাঠামো দেখা', 'read', false, true, array['COMPANY','WING'], 'active', 90),
  ('core.structure.manage', 'core', 'উইং/বিভাগ/অবস্থান সম্পাদনা', 'admin', true, false, array['COMPANY','WING'], 'registered', 100),
  ('audit.read', 'audit', 'অডিট-লগ দেখা', 'read', true, false, array['COMPANY'], 'active', 110),
  ('audit.verify', 'audit', 'অডিট-চেইন যাচাই', 'read', false, false, array['COMPANY'], 'active', 120),
  ('audit.export', 'audit', 'অডিট রপ্তানি', 'export', true, false, array['COMPANY'], 'registered', 130),
  ('config.settings.read', 'config', 'সেটিং দেখা', 'read', false, true, array['COMPANY'], 'active', 140),
  ('config.settings.manage', 'config', 'নীতি-সেটিং পরিবর্তন', 'admin', true, false, array['COMPANY'], 'active', 150),
  ('config.ui.manage', 'config', 'মেনু/ফর্ম/KPI/চার্ট কাস্টমাইজ', 'admin', false, false, array['COMPANY'], 'registered', 160),
  ('config.approval_rule.manage', 'config', 'অনুমোদন-নিয়ম সম্পাদনা', 'admin', true, false, array['COMPANY'], 'registered', 170),
  ('config.notification_rule.manage', 'config', 'নোটিফিকেশন-নিয়ম সম্পাদনা', 'admin', false, false, array['COMPANY'], 'registered', 180),
  ('config.feature.toggle', 'config', 'ফিচার চালু/বন্ধ', 'admin', true, false, array['COMPANY'], 'registered', 190),
  ('design.studio.edit', 'design', 'Studio খসড়া সম্পাদনা', 'write', false, true, array['COMPANY'], 'registered', 200),
  ('design.studio.publish', 'design', 'Studio প্রকাশ/Rollback', 'admin', true, false, array['COMPANY'], 'registered', 210),
  ('design.ads.manage', 'design', 'বিজ্ঞাপন-মিডিয়া ব্যবস্থাপনা', 'admin', false, false, array['COMPANY'], 'registered', 220),
  ('approval.inbox.read', 'approval', 'অনুমোদন-ইনবক্স দেখা', 'read', false, true, array['ASSIGNED'], 'registered', 230),
  ('approval.decide', 'approval', 'অনুমোদন/প্রত্যাখ্যান', 'approve', false, true, array['ASSIGNED'], 'registered', 240),
  ('approval.override', 'approval', 'অনুমোদন-ওভাররাইড', 'approve', true, false, array['COMPANY'], 'registered', 250),
  ('approval.reassign', 'approval', 'অনুমোদন পুনঃবরাদ্দ', 'admin', true, false, array['COMPANY'], 'registered', 260),
  ('master.sku.read', 'master', 'পণ্য/কাঁচামাল দেখা', 'read', false, true, array['COMPANY','WING'], 'registered', 270),
  ('master.sku.manage', 'master', 'পণ্য/কাঁচামাল সম্পাদনা', 'write', false, true, array['COMPANY','WING'], 'registered', 280),
  ('master.warehouse.read', 'master', 'গুদাম দেখা', 'read', false, true, array['COMPANY','WING','WAREHOUSE'], 'registered', 290),
  ('master.warehouse.manage', 'master', 'গুদাম সম্পাদনা', 'admin', false, false, array['COMPANY','WING'], 'registered', 300),
  ('master.supplier.read', 'master', 'সাপ্লায়ার দেখা', 'read', false, true, array['COMPANY'], 'registered', 310),
  ('master.supplier.manage', 'master', 'সাপ্লায়ার সম্পাদনা', 'write', false, true, array['COMPANY'], 'registered', 320),
  ('master.party.read', 'master', 'ডিলার/গ্রাহক দেখা', 'read', false, true, array['COMPANY','WING','ASSIGNED'], 'registered', 330),
  ('master.party.manage', 'master', 'ডিলার/গ্রাহক সম্পাদনা', 'write', false, true, array['COMPANY','WING'], 'registered', 340),
  ('master.price.manage', 'master', 'মূল্য-তালিকা সম্পাদনা', 'admin', true, false, array['COMPANY','WING'], 'registered', 350),
  ('procurement.read', 'procurement', 'ক্রয়-নথি দেখা', 'read', false, true, array['COMPANY','WING'], 'registered', 360),
  ('procurement.pr.create', 'procurement', 'ক্রয়-অনুরোধ তৈরি', 'write', false, true, array['COMPANY','WING','DEPARTMENT'], 'registered', 370),
  ('procurement.po.create', 'procurement', 'ক্রয়-আদেশ তৈরি', 'write', false, true, array['COMPANY','WING'], 'registered', 380),
  ('procurement.po.approve', 'procurement', 'ক্রয়-আদেশ অনুমোদন', 'approve', false, true, array['COMPANY','WING'], 'registered', 390),
  ('procurement.grn.receive', 'procurement', 'মাল-গ্রহণ (GRN)', 'write', false, true, array['COMPANY','WAREHOUSE'], 'registered', 400),
  ('procurement.qc.inspect', 'procurement', 'GRN মান-পরীক্ষা', 'write', false, true, array['COMPANY','WING','WAREHOUSE'], 'registered', 410),
  ('procurement.bill.match', 'procurement', 'সাপ্লায়ার-বিল মিলানো', 'write', false, true, array['COMPANY'], 'registered', 420),
  ('inventory.stock.read', 'inventory', 'স্টক দেখা', 'read', false, true, array['COMPANY','WING','WAREHOUSE'], 'registered', 430),
  ('inventory.cost.read', 'inventory', 'স্টক-মূল্য দেখা', 'read', true, false, array['COMPANY','WING'], 'registered', 440),
  ('inventory.reserve', 'inventory', 'স্টক সংরক্ষণ', 'write', false, true, array['COMPANY','WAREHOUSE'], 'registered', 450),
  ('inventory.transfer.create', 'inventory', 'গুদাম-স্থানান্তর তৈরি', 'write', false, true, array['COMPANY','WAREHOUSE'], 'registered', 460),
  ('inventory.transfer.approve', 'inventory', 'গুদাম-স্থানান্তর অনুমোদন', 'approve', false, true, array['COMPANY','WING'], 'registered', 470),
  ('inventory.count.record', 'inventory', 'স্টক-গণনা', 'write', false, true, array['COMPANY','WAREHOUSE'], 'registered', 480),
  ('inventory.adjust.submit', 'inventory', 'স্টক-সমন্বয় প্রস্তাব', 'write', false, true, array['COMPANY','WAREHOUSE'], 'registered', 490),
  ('inventory.adjust.approve', 'inventory', 'স্টক-সমন্বয় অনুমোদন', 'approve', true, false, array['COMPANY','WING'], 'registered', 500),
  ('mfg.bom.read', 'mfg', 'BOM দেখা', 'read', false, true, array['COMPANY','WING'], 'registered', 510),
  ('mfg.bom.manage', 'mfg', 'BOM সম্পাদনা/অনুমোদন', 'admin', false, false, array['COMPANY','WING'], 'registered', 520),
  ('mfg.plan.create', 'mfg', 'উৎপাদন-পরিকল্পনা', 'write', false, true, array['COMPANY','WING'], 'registered', 530),
  ('mfg.batch.start', 'mfg', 'ব্যাচ শুরু', 'write', false, true, array['COMPANY','WING'], 'registered', 540),
  ('mfg.material.issue', 'mfg', 'কাঁচামাল ইস্যু', 'write', false, true, array['COMPANY','WING','WAREHOUSE'], 'registered', 550),
  ('mfg.material.return', 'mfg', 'কাঁচামাল ফেরত', 'write', false, true, array['COMPANY','WING','WAREHOUSE'], 'registered', 560),
  ('mfg.qc.inspect', 'mfg', 'উৎপাদন-QC', 'write', false, true, array['COMPANY','WING'], 'registered', 570),
  ('mfg.waste.submit', 'mfg', 'অপচয় দাখিল', 'write', false, true, array['COMPANY','WING'], 'registered', 580),
  ('mfg.rework.approve', 'mfg', 'রিওয়ার্ক অনুমোদন', 'approve', false, true, array['COMPANY','WING'], 'registered', 590),
  ('mfg.fg.receive', 'mfg', 'তৈরি-পণ্য গ্রহণ', 'write', false, true, array['COMPANY','WING','WAREHOUSE'], 'registered', 600),
  ('mfg.maintenance.write', 'mfg', 'রক্ষণাবেক্ষণ রেকর্ড', 'write', false, true, array['COMPANY','WING'], 'registered', 610),
  ('mfg.cost.read', 'mfg', 'উৎপাদন-খরচ দেখা', 'read', true, false, array['COMPANY','WING'], 'registered', 620),
  ('finance.coa.manage', 'finance', 'হিসাব-তালিকা (COA) সম্পাদনা', 'admin', true, false, array['COMPANY'], 'registered', 630),
  ('finance.ledger.read', 'finance', 'লেজার দেখা', 'read', true, true, array['COMPANY'], 'registered', 640),
  ('finance.journal.create', 'finance', 'জার্নাল খসড়া', 'write', false, true, array['COMPANY'], 'registered', 650),
  ('finance.journal.post', 'finance', 'জার্নাল পোস্ট', 'post', true, false, array['COMPANY'], 'registered', 660),
  ('finance.journal.reverse', 'finance', 'জার্নাল রিভার্সাল', 'post', true, false, array['COMPANY'], 'registered', 670),
  ('finance.period.lock', 'finance', 'পিরিয়ড বন্ধ', 'admin', true, false, array['COMPANY'], 'registered', 680),
  ('finance.period.reopen', 'finance', 'পিরিয়ড পুনরায় খোলা', 'admin', true, false, array['COMPANY'], 'registered', 690),
  ('finance.cash.read', 'finance', 'নগদ/ব্যাংক দেখা', 'read', false, true, array['COMPANY'], 'registered', 700),
  ('finance.cash.voucher', 'finance', 'নগদ/ব্যাংক ভাউচার', 'write', false, true, array['COMPANY'], 'registered', 710),
  ('finance.ap.pay', 'finance', 'সাপ্লায়ার-পরিশোধ', 'post', true, false, array['COMPANY'], 'registered', 720),
  ('finance.ar.receive', 'finance', 'গ্রাহক-প্রাপ্তি', 'post', false, true, array['COMPANY'], 'registered', 730),
  ('finance.bank.reconcile', 'finance', 'ব্যাংক-সমন্বয়', 'write', false, true, array['COMPANY'], 'registered', 740),
  ('finance.statement.read', 'finance', 'আর্থিক বিবরণী দেখা', 'read', true, false, array['COMPANY'], 'registered', 750),
  ('finance.factory_pnl.read', 'finance', 'ফ্যাক্টরি লাভ-ক্ষতি দেখা', 'read', true, false, array['COMPANY','WING'], 'registered', 760),
  ('sales.order.create', 'sales', 'বিক্রয়-আদেশ তৈরি', 'write', false, true, array['COMPANY','WING','ASSIGNED'], 'registered', 770),
  ('sales.order.approve', 'sales', 'বিক্রয়-আদেশ অনুমোদন', 'approve', false, true, array['COMPANY','WING'], 'registered', 780),
  ('sales.credit.override', 'sales', 'ক্রেডিট-সীমা ওভাররাইড', 'approve', true, false, array['COMPANY'], 'registered', 790),
  ('sales.dispatch.post', 'sales', 'ডেলিভারি পোস্ট', 'post', false, true, array['COMPANY','WAREHOUSE'], 'registered', 800),
  ('sales.invoice.post', 'sales', 'ইনভয়েস পোস্ট', 'post', false, true, array['COMPANY','ASSIGNED'], 'registered', 810),
  ('sales.collection.record', 'sales', 'কালেকশন রেকর্ড', 'write', false, true, array['COMPANY','ASSIGNED'], 'registered', 820),
  ('sales.collection.verify', 'sales', 'কালেকশন যাচাই', 'approve', false, true, array['COMPANY'], 'registered', 830),
  ('sales.return.create', 'sales', 'বিক্রয়-ফেরত', 'write', false, true, array['COMPANY','ASSIGNED'], 'registered', 840),
  ('sales.weekly_summary.read', 'sales', 'সাপ্তাহিক বিক্রয়-সারাংশ', 'read', false, true, array['COMPANY','WING','ASSIGNED'], 'registered', 850),
  ('sales.monthly_summary.read', 'sales', 'মাসিক বিক্রয়-সারাংশ', 'read', true, false, array['COMPANY','WING'], 'registered', 860),
  ('crm.dealer.read', 'crm', 'ডিলার-CRM দেখা', 'read', false, true, array['COMPANY','WING','ASSIGNED'], 'registered', 870),
  ('crm.visit.record', 'crm', 'ভিজিট রেকর্ড', 'write', false, true, array['COMPANY','WING','ASSIGNED','SELF'], 'registered', 880),
  ('crm.target.manage', 'crm', 'বিক্রয়-লক্ষ্য নির্ধারণ', 'admin', false, false, array['COMPANY','WING'], 'registered', 890),
  ('hr.employee.read', 'hr', 'কর্মী-তথ্য দেখা', 'read', true, true, array['COMPANY','WING','DEPARTMENT','SELF'], 'registered', 900),
  ('hr.employee.manage', 'hr', 'কর্মী-তথ্য সম্পাদনা', 'write', true, false, array['COMPANY','WING','DEPARTMENT'], 'registered', 910),
  ('hr.employee.terminate', 'hr', 'কর্মী অব্যাহতি', 'admin', true, false, array['COMPANY'], 'registered', 920),
  ('hr.attendance.scan', 'hr', 'উপস্থিতি স্ক্যান', 'write', false, false, array['SELF'], 'registered', 930),
  ('hr.attendance.read', 'hr', 'উপস্থিতি দেখা', 'read', false, true, array['COMPANY','WING','DEPARTMENT','SELF'], 'registered', 940),
  ('hr.attendance.correct', 'hr', 'উপস্থিতি সংশোধন', 'write', true, false, array['COMPANY','WING','DEPARTMENT'], 'registered', 950),
  ('hr.leave.request', 'hr', 'ছুটির আবেদন', 'write', false, false, array['SELF'], 'registered', 960),
  ('hr.leave.approve', 'hr', 'ছুটি অনুমোদন', 'approve', false, true, array['COMPANY','WING','DEPARTMENT'], 'registered', 970),
  ('hr.payroll.read', 'hr', 'বেতন-তথ্য দেখা', 'read', true, false, array['COMPANY'], 'registered', 980),
  ('hr.payroll.calculate', 'hr', 'বেতন হিসাব', 'write', true, false, array['COMPANY'], 'registered', 990),
  ('hr.payroll.approve', 'hr', 'বেতন অনুমোদন', 'approve', true, false, array['COMPANY'], 'registered', 1000),
  ('hr.payroll.pay', 'hr', 'বেতন প্রদান', 'post', true, false, array['COMPANY'], 'registered', 1010),
  ('hr.payslip.read_self', 'hr', 'নিজের পে-স্লিপ', 'read', false, false, array['SELF'], 'registered', 1020),
  ('reports.read', 'reports', 'রিপোর্ট দেখা', 'read', false, true, array['COMPANY','WING','DEPARTMENT','ASSIGNED'], 'registered', 1030),
  ('reports.export', 'reports', 'রিপোর্ট রপ্তানি (PDF/Excel)', 'export', true, false, array['COMPANY','WING'], 'registered', 1040),
  ('reports.print', 'reports', 'প্রিন্ট', 'export', false, true, array['COMPANY','WING'], 'registered', 1050),
  ('qr.issue', 'qr', 'QR তৈরি', 'write', false, true, array['COMPANY','WING'], 'registered', 1060),
  ('qr.revoke', 'qr', 'QR বাতিল', 'admin', false, false, array['COMPANY'], 'registered', 1070),
  ('qr.scan', 'qr', 'QR স্ক্যান', 'read', false, true, array['COMPANY','WING','SELF'], 'registered', 1080),
  ('notify.inbox.read', 'notify', 'নিজের নোটিফিকেশন', 'read', false, false, array['SELF'], 'registered', 1090),
  ('notify.broadcast.send', 'notify', 'ঘোষণা পাঠানো', 'admin', false, false, array['COMPANY','WING'], 'registered', 1100),
  ('location.dealer_map.read', 'location', 'ডিলার-মানচিত্র', 'read', false, true, array['COMPANY','WING','ASSIGNED'], 'registered', 1110),
  ('location.live.read', 'location', 'লাইভ-লোকেশন দেখা', 'read', true, false, array['COMPANY','WING'], 'registered', 1120),
  ('location.live.share', 'location', 'নিজের লাইভ-লোকেশন শেয়ার', 'write', false, false, array['SELF'], 'registered', 1130),
  ('device.manage', 'device', 'ডিভাইস নিবন্ধন/বাতিল', 'admin', true, false, array['COMPANY','LOCATION'], 'registered', 1140),
  ('device.pos.print', 'device', 'POS প্রিন্ট', 'write', false, true, array['COMPANY','LOCATION'], 'registered', 1150),
  ('technical.diagnostics.read', 'technical', 'প্রযুক্তিগত ডায়াগনস্টিক', 'read', false, false, array['COMPANY'], 'active', 1160);

-- ---------------------------------------------------------------- default matrix (templates; copied into each company)
create table iam.permission_template_rule (
  position_code   text not null references iam.position_template(code),
  permission_code text not null references iam.permission_catalog(code),
  effect          text not null check (effect in ('allow','deny')),
  scope_kind      text not null check (scope_kind in ('COMPANY','WING','DEPARTMENT','LOCATION','WAREHOUSE','ASSIGNED','SELF')),
  primary key (position_code, permission_code, effect, scope_kind)
);
create trigger trg_permission_template_no_update before update on iam.permission_template_rule for each row execute function core.fn_deny_mutation();

-- Defaults for modules that exist now. Each later module step inserts its own defaults (blueprint 24 matrix,
-- docs/plan/DEFAULT_PERMISSION_TEMPLATES.csv) and calls iam.fn_backfill_template_rules().
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'iam.self.read', 'allow', 'SELF' from iam.position_template t where not t.is_supreme
union all
select t.code, 'core.structure.read', 'allow', 'COMPANY' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN');
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('MD', 'iam.position.read', 'allow', 'COMPANY'), ('MD', 'iam.permission.read', 'allow', 'COMPANY'), ('MD', 'config.settings.read', 'allow', 'COMPANY'),
  ('MD', 'audit.read', 'allow', 'COMPANY'), ('MD', 'audit.verify', 'allow', 'COMPANY'),
  ('AUDITOR', 'iam.position.read', 'allow', 'COMPANY'), ('AUDITOR', 'iam.permission.read', 'allow', 'COMPANY'),
  ('AUDITOR', 'audit.read', 'allow', 'COMPANY'), ('AUDITOR', 'audit.verify', 'allow', 'COMPANY'),
  ('HR_OFFICER', 'iam.position.read', 'allow', 'COMPANY'),
  ('TECH_ADMIN', 'technical.diagnostics.read', 'allow', 'COMPANY');

-- ---------------------------------------------------------------- company matrix (Chairman-editable)
create table iam.position_permission_rule (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  position_code   text not null,
  permission_code text not null references iam.permission_catalog(code),
  effect          text not null check (effect in ('allow','deny')),
  scope_kind      text not null check (scope_kind in ('COMPANY','WING','DEPARTMENT','LOCATION','WAREHOUSE','ASSIGNED','SELF')),
  scope_id        uuid,               -- WING/DEPARTMENT/LOCATION: null = the holder's home unit; WAREHOUSE: required
  status          text not null default 'active' check (status in ('active','revoked')),
  origin          text not null default 'chairman' check (origin in ('template','chairman','manager')),
  created_at      timestamptz not null default clock_timestamp(),
  created_by      uuid references core.person(id),
  revoked_at      timestamptz,
  revoked_by      uuid references core.person(id),
  reason          text,
  unique (id, company_id),
  check ((status = 'revoked') = (revoked_at is not null)),
  check (scope_kind not in ('COMPANY','ASSIGNED','SELF') or scope_id is null),
  check (scope_kind <> 'WAREHOUSE' or scope_id is not null),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index position_permission_rule_active_uq on iam.position_permission_rule
  (company_id, position_code, permission_code, effect, scope_kind, scope_id) nulls not distinct where status = 'active';
create index position_permission_rule_lookup on iam.position_permission_rule (company_id, position_code, permission_code) where status = 'active';

create table iam.assignment_permission_rule (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  assignment_id   uuid not null,
  permission_code text not null references iam.permission_catalog(code),
  effect          text not null check (effect in ('allow','deny')),
  scope_kind      text not null check (scope_kind in ('COMPANY','WING','DEPARTMENT','LOCATION','WAREHOUSE','ASSIGNED','SELF')),
  scope_id        uuid,
  valid_until     timestamptz,
  status          text not null default 'active' check (status in ('active','revoked')),
  origin          text not null default 'chairman' check (origin in ('chairman','manager','delegation')),
  created_at      timestamptz not null default clock_timestamp(),
  created_by      uuid references core.person(id),
  revoked_at      timestamptz,
  revoked_by      uuid references core.person(id),
  reason          text not null check (length(btrim(reason)) > 0),
  unique (id, company_id),
  check ((status = 'revoked') = (revoked_at is not null)),
  check (scope_kind not in ('COMPANY','ASSIGNED','SELF') or scope_id is null),
  check (scope_kind <> 'WAREHOUSE' or scope_id is not null),
  check (valid_until is null or valid_until > created_at),
  foreign key (assignment_id, company_id) references iam.position_assignment (id, company_id)
);
create unique index assignment_permission_rule_active_uq on iam.assignment_permission_rule
  (assignment_id, permission_code, effect, scope_kind, scope_id) nulls not distinct where status = 'active';
create index assignment_permission_rule_lookup on iam.assignment_permission_rule (assignment_id, permission_code) where status = 'active';

-- Rule guard (both tables): allowed scope for this permission, scope unit belongs to the same company,
-- only active -> revoked transition, identity fields fixed; holders' authz_epoch bumped on every change.
create function iam.fn_permission_rule_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_row jsonb := to_jsonb(new); v_scopes text[]; v_scope_id uuid := (v_row ->> 'scope_id')::uuid; v_ok boolean;
begin
  if tg_op = 'UPDATE' then
    if old.status = 'revoked' then
      raise exception 'E_IMMUTABLE: a revoked rule cannot change' using errcode = 'P0001';
    end if;
    if (to_jsonb(old) - array['status','revoked_at','revoked_by','reason']) <> (v_row - array['status','revoked_at','revoked_by','reason']) then
      raise exception 'E_IMMUTABLE: only revoking a rule is allowed; create a new rule instead' using errcode = 'P0001';
    end if;
  else
    select allowed_scopes into v_scopes from iam.permission_catalog where code = new.permission_code;
    if not (new.scope_kind = any (v_scopes)) then
      raise exception 'E_SCOPE_NOT_ALLOWED: % cannot be granted with scope %', new.permission_code, new.scope_kind using errcode = 'P0001';
    end if;
    if new.scope_kind = 'WAREHOUSE' then
      raise exception 'E_SCOPE_NOT_AVAILABLE: warehouse scope arrives with the warehouse master (S27)' using errcode = 'P0001';
    end if;
    if v_scope_id is not null then
      v_ok := case new.scope_kind
        when 'WING'       then exists (select 1 from core.wing       where id = v_scope_id and company_id = new.company_id)
        when 'DEPARTMENT' then exists (select 1 from core.department where id = v_scope_id and company_id = new.company_id)
        when 'LOCATION'   then exists (select 1 from core.location   where id = v_scope_id and company_id = new.company_id)
        else false end;
      if not v_ok then
        raise exception 'E_WRONG_COMPANY: scope unit does not belong to this company' using errcode = 'P0001';
      end if;
    end if;
  end if;
  if tg_table_name = 'position_permission_rule' then
    update core.person p set authz_epoch = p.authz_epoch + 1
     where p.id in (select m.person_id from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                     where a.company_id = new.company_id and a.position_code = (v_row ->> 'position_code') and a.status = 'active');
  else
    update core.person p set authz_epoch = p.authz_epoch + 1
     where p.id = (select m.person_id from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                    where a.id = (v_row ->> 'assignment_id')::uuid);
  end if;
  return new;
end $$;
create trigger trg_position_rule_guard before insert or update on iam.position_permission_rule for each row execute function iam.fn_permission_rule_guard();
create trigger trg_assignment_rule_guard before insert or update on iam.assignment_permission_rule for each row execute function iam.fn_permission_rule_guard();
create trigger trg_position_rule_nodel before delete on iam.position_permission_rule for each row execute function core.fn_deny_delete();
create trigger trg_assignment_rule_nodel before delete on iam.assignment_permission_rule for each row execute function core.fn_deny_delete();
create trigger trg_position_rule_audit after insert or update on iam.position_permission_rule for each row execute function audit.fn_row_change();
create trigger trg_assignment_rule_audit after insert or update on iam.assignment_permission_rule for each row execute function audit.fn_row_change();

-- Copies template rules into companies. A template rule is NOT re-added where the same rule ever existed (a Chairman
-- revocation is respected forever). Idempotent; called at company creation and by each later module step.
create function iam.fn_backfill_template_rules(p_company uuid default null) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare n integer;
begin
  insert into iam.position_permission_rule (company_id, position_code, permission_code, effect, scope_kind, origin, reason)
  select pc.company_id, t.position_code, t.permission_code, t.effect, t.scope_kind, 'template', 'default matrix'
    from iam.permission_template_rule t
    join iam.position_catalog pc on pc.code = t.position_code
   where (p_company is null or pc.company_id = p_company)
     and not exists (select 1 from iam.position_permission_rule r
                      where r.company_id = pc.company_id and r.position_code = t.position_code and r.permission_code = t.permission_code
                        and r.effect = t.effect and r.scope_kind = t.scope_kind and r.scope_id is null);
  get diagnostics n = row_count;
  return n;
end $$;

-- Company creation: positions first, then the default matrix (one trigger => deterministic order).
create or replace function iam.fn_company_seed_positions() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform iam.fn_seed_company_positions(new.id);
  perform iam.fn_backfill_template_rules(new.id);
  return null;
end $$;

-- Existing companies (created before this migration) get the default matrix too.
select iam.fn_backfill_template_rules(null);

-- ---------------------------------------------------------------- resource reference + resolver
-- Built ONLY by server code from authoritative rows (never from client strings).
create type iam.resource as (
  company_id uuid, wing_id uuid, department_id uuid, location_id uuid, warehouse_id uuid,
  owner_person_id uuid, assignee_person_id uuid
);

create function iam.fn_resource(p_company uuid, p_wing uuid default null, p_department uuid default null, p_location uuid default null,
                                p_warehouse uuid default null, p_owner_person uuid default null, p_assignee_person uuid default null)
returns iam.resource language sql immutable set search_path = pg_catalog as $$
  select row(p_company, p_wing, p_department, p_location, p_warehouse, p_owner_person, p_assignee_person)::iam.resource
$$;

-- p_dept is p_ancestor or one of its descendants (bounded walk; cycles are impossible by S02 trigger).
create function core.fn_department_within(p_dept uuid, p_ancestor uuid) returns boolean
language plpgsql stable set search_path = pg_catalog as $$
declare v_cur uuid := p_dept; v_depth integer := 0;
begin
  if p_dept is null or p_ancestor is null then return false; end if;
  while v_cur is not null and v_depth <= 32 loop
    if v_cur = p_ancestor then return true; end if;
    select d.parent_department_id into v_cur from core.department d where d.id = v_cur;
    v_depth := v_depth + 1;
  end loop;
  return false;
end $$;

create function iam.fn_scope_match(p_kind text, p_scope_id uuid, r iam.resource, p_person uuid,
                                   p_home_wing uuid, p_home_department uuid, p_home_location uuid)
returns boolean language plpgsql stable set search_path = pg_catalog as $$
declare v_target uuid;
begin
  case p_kind
    when 'COMPANY' then return true;
    when 'WING' then
      v_target := coalesce(p_scope_id, p_home_wing);
      return v_target is not null and r.wing_id = v_target;
    when 'DEPARTMENT' then
      v_target := coalesce(p_scope_id, p_home_department);
      return v_target is not null and core.fn_department_within(r.department_id, v_target);
    when 'LOCATION' then
      v_target := coalesce(p_scope_id, p_home_location);
      return v_target is not null and r.location_id = v_target;
    when 'WAREHOUSE' then
      return p_scope_id is not null and r.warehouse_id = p_scope_id;
    when 'ASSIGNED' then
      return r.assignee_person_id is not null and r.assignee_person_id = p_person;
    when 'SELF' then
      return r.owner_person_id is not null and r.owner_person_id = p_person;
    else
      return false;
  end case;
end $$;

-- THE decision. Never raises for a denial (returns allowed=false + reason); raises only E_AUTH / E_NO_ACTIVE_POSITION.
create function iam.fn_authorize(p_permission text, p_resource iam.resource, p_lock boolean default false)
returns table (allowed boolean, reason text, rule_id uuid, person_id uuid, company_id uuid, assignment_id uuid,
               position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare c record; p iam.permission_catalog%rowtype; r iam.resource := p_resource; v_dw uuid; v_lw uuid; v_rule uuid; v_effect text;
begin
  select * into c from iam.fn_context(p_lock);

  select * into p from iam.permission_catalog pc where pc.code = p_permission;
  if not found then
    return query select false, 'unknown_permission', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if p.status <> 'active' then
    return query select false, 'permission_not_active', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.company_id is null or r.company_id <> c.company_id then
    return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;

  -- resource units must belong to the company; derive the wing from department/location; inconsistency => deny
  if r.wing_id is not null and not exists (select 1 from core.wing w where w.id = r.wing_id and w.company_id = r.company_id) then
    return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.department_id is not null then
    select d.wing_id into v_dw from core.department d where d.id = r.department_id and d.company_id = r.company_id;
    if v_dw is null or (r.wing_id is not null and r.wing_id <> v_dw) then
      return query select false, 'inconsistent_resource', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
    end if;
    r.wing_id := v_dw;
  end if;
  if r.location_id is not null then
    if not exists (select 1 from core.location l where l.id = r.location_id and l.company_id = r.company_id) then
      return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
    end if;
    select l.wing_id into v_lw from core.location l where l.id = r.location_id;
    if v_lw is not null then
      if r.wing_id is not null and r.wing_id <> v_lw then
        return query select false, 'inconsistent_resource', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
      end if;
      r.wing_id := v_lw;
    end if;
  end if;

  if p.requires_aal2 and core.fn_jwt_claim('aal') is distinct from 'aal2' then
    return query select false, 'mfa_required', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;

  if c.is_supreme then
    return query select true, 'supreme', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;

  -- personal overrides first (deny beats allow), then the position matrix (deny beats allow)
  select ar.id, ar.effect into v_rule, v_effect
    from iam.assignment_permission_rule ar
   where ar.assignment_id = c.assignment_id and ar.permission_code = p_permission and ar.status = 'active'
     and (ar.valid_until is null or ar.valid_until > clock_timestamp())
     and iam.fn_scope_match(ar.scope_kind, ar.scope_id, r, c.person_id, c.home_wing_id, c.home_department_id, c.home_location_id)
   order by (ar.effect = 'deny') desc
   limit 1;
  if v_rule is null then
    select pr.id, pr.effect into v_rule, v_effect
      from iam.position_permission_rule pr
     where pr.company_id = c.company_id and pr.position_code = c.position_code and pr.permission_code = p_permission and pr.status = 'active'
       and iam.fn_scope_match(pr.scope_kind, pr.scope_id, r, c.person_id, c.home_wing_id, c.home_department_id, c.home_location_id)
     order by (pr.effect = 'deny') desc
     limit 1;
  end if;
  if v_rule is null then
    return query select false, 'no_grant', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  return query select v_effect = 'allow', case when v_effect = 'allow' then 'granted' else 'denied_by_rule' end, v_rule,
                      c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme;
end $$;

-- Raising form used by every business RPC (default: locking, for writes). Error code tells the client why.
create function iam.fn_require(p_permission text, p_resource iam.resource, p_lock boolean default true)
returns table (person_id uuid, company_id uuid, assignment_id uuid, position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare d record;
begin
  select * into d from iam.fn_authorize(p_permission, p_resource, p_lock);
  if not d.allowed then
    perform core.fn_raise(case d.reason
                            when 'wrong_company' then 'E_WRONG_COMPANY'
                            when 'mfa_required' then 'E_MFA_REQUIRED'
                            when 'permission_not_active' then 'E_FEATURE_NOT_READY'
                            else 'E_FORBIDDEN' end, p_permission);
  end if;
  return query select d.person_id, d.company_id, d.assignment_id, d.position_code, d.is_supreme;
end $$;

-- Resource = "my current company" (for company-level actions).
create function iam.fn_my_company_resource() returns iam.resource
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  select company_id into v from iam.fn_context(false);
  return iam.fn_resource(v);
end $$;

-- ---------------------------------------------------------------- rule management (escalation-safe)
create function iam.fn_assert_can_manage_rule(p_target_position text, p_target_assignment uuid, p_permission text, p_effect text)
returns table (person_id uuid, company_id uuid, assignment_id uuid, position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare me record; v_target_position text := p_target_position; p iam.permission_catalog%rowtype; mine record;
begin
  select * into me from iam.fn_require('iam.permission.manage', iam.fn_my_company_resource(), true);
  if p_target_assignment is not null then
    select a.position_code into v_target_position from iam.position_assignment a where a.id = p_target_assignment and a.company_id = me.company_id;
    if v_target_position is null then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  end if;
  if not exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = v_target_position) then
    perform core.fn_raise('E_NOT_FOUND', 'position');
  end if;
  if v_target_position = 'CHAIRMAN' then
    perform core.fn_raise('E_PROTECTED_POSITION', 'the Chairman is supreme; rules do not apply');
  end if;
  select * into p from iam.permission_catalog where code = p_permission;
  if not found or p.status = 'retired' then perform core.fn_raise('E_NOT_FOUND', 'permission'); end if;
  if not me.is_supreme then
    -- a delegated manager can never widen their own power or hand out powers they do not hold
    if v_target_position = me.position_code or p_target_assignment = me.assignment_id then
      perform core.fn_raise('E_SELF_GRANT', 'cannot change rules of your own position');
    end if;
    if p_effect = 'allow' then
      if p.action_kind = 'admin' then perform core.fn_raise('E_FORBIDDEN', 'only the Chairman grants admin permissions'); end if;
      select * into mine from iam.fn_authorize(p_permission, iam.fn_my_company_resource(), false);
      if not mine.allowed then perform core.fn_raise('E_FORBIDDEN', 'you cannot grant a permission you do not hold'); end if;
    end if;
  end if;
  return query select me.person_id, me.company_id, me.assignment_id, me.position_code, me.is_supreme;
end $$;

-- ---------------------------------------------------------------- app API
create function api.v1_iam_permission_catalog() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
begin
  perform iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', code, 'module', module, 'name_bn', name_bn, 'action_kind', action_kind,
                         'is_sensitive', is_sensitive, 'is_delegable', is_delegable, 'requires_aal2', requires_aal2,
                         'allowed_scopes', to_jsonb(allowed_scopes), 'status', status) order by sort_order)
                     from iam.permission_catalog where status <> 'retired'), '[]'::jsonb);
end $$;

-- What can I do (UI hints only; the server re-checks every action). Supreme = every active permission, company-wide.
create function api.v1_iam_my_permissions() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare c record;
begin
  select * into c from iam.fn_context(false);
  if c.is_supreme then
    return jsonb_build_object('position_code', c.position_code, 'is_supreme', true, 'permissions',
      coalesce((select jsonb_agg(jsonb_build_object('code', code, 'scopes', jsonb_build_array(jsonb_build_object('kind', 'COMPANY'))) order by code)
                  from iam.permission_catalog where status = 'active'), '[]'::jsonb));
  end if;
  return jsonb_build_object('position_code', c.position_code, 'is_supreme', false, 'permissions', coalesce((
    select jsonb_agg(jsonb_build_object('code', g.permission_code, 'scopes', g.scopes) order by g.permission_code)
      from (select x.permission_code,
                   jsonb_agg(distinct jsonb_build_object('kind', x.scope_kind, 'id',
                       case x.scope_kind when 'WING' then coalesce(x.scope_id, c.home_wing_id)
                                         when 'DEPARTMENT' then coalesce(x.scope_id, c.home_department_id)
                                         when 'LOCATION' then coalesce(x.scope_id, c.home_location_id)
                                         else x.scope_id end)) as scopes
              from (select pr.permission_code, pr.scope_kind, pr.scope_id
                      from iam.position_permission_rule pr
                     where pr.company_id = c.company_id and pr.position_code = c.position_code and pr.status = 'active' and pr.effect = 'allow'
                    union all
                    select ar.permission_code, ar.scope_kind, ar.scope_id
                      from iam.assignment_permission_rule ar
                     where ar.assignment_id = c.assignment_id and ar.status = 'active' and ar.effect = 'allow'
                       and (ar.valid_until is null or ar.valid_until > clock_timestamp())) x
              join iam.permission_catalog pc on pc.code = x.permission_code and pc.status = 'active'
             where not exists (select 1 from iam.assignment_permission_rule d
                                where d.assignment_id = c.assignment_id and d.permission_code = x.permission_code and d.status = 'active'
                                  and d.effect = 'deny' and d.scope_kind = 'COMPANY' and (d.valid_until is null or d.valid_until > clock_timestamp()))
               and (not exists (select 1 from iam.position_permission_rule d
                                 where d.company_id = c.company_id and d.position_code = c.position_code and d.permission_code = x.permission_code
                                   and d.status = 'active' and d.effect = 'deny' and d.scope_kind = 'COMPANY')
                    or exists (select 1 from iam.assignment_permission_rule o
                                where o.assignment_id = c.assignment_id and o.permission_code = x.permission_code and o.status = 'active'
                                  and o.effect = 'allow' and (o.valid_until is null or o.valid_until > clock_timestamp())))
             group by x.permission_code) g), '[]'::jsonb));
end $$;

create function api.v1_iam_position_rules(p_position_code text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.permission.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'permission_code', r.permission_code, 'effect', r.effect,
                      'scope_kind', r.scope_kind, 'scope_id', r.scope_id, 'origin', r.origin, 'created_at', r.created_at, 'reason', r.reason)
                      order by r.permission_code, r.effect, r.scope_kind)
                     from iam.position_permission_rule r
                    where r.company_id = me.company_id and r.position_code = p_position_code and r.status = 'active'), '[]'::jsonb);
end $$;

create function api.v1_iam_set_position_rule(p_position_code text, p_permission text, p_effect text, p_scope_kind text, p_scope_id uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare me record; v uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_assert_can_manage_rule(p_position_code, null, p_permission, p_effect);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.position_permission_rule (company_id, position_code, permission_code, effect, scope_kind, scope_id, origin, created_by, reason)
  values (me.company_id, p_position_code, p_permission, p_effect, p_scope_kind, p_scope_id,
          case when me.is_supreme then 'chairman' else 'manager' end, me.person_id, p_reason)
  returning id into v;
  return v;
end $$;

create function api.v1_iam_revoke_position_rule(p_rule_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record; r iam.position_permission_rule%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into r from iam.position_permission_rule where id = p_rule_id and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'rule'); end if;
  select * into me from iam.fn_assert_can_manage_rule(r.position_code, null, r.permission_code, 'deny');
  if r.company_id <> me.company_id then perform core.fn_raise('E_WRONG_COMPANY'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.position_permission_rule set status = 'revoked', revoked_at = clock_timestamp(), revoked_by = me.person_id, reason = p_reason
   where id = p_rule_id;
end $$;

create function api.v1_iam_assignment_rules(p_assignment_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('iam.permission.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'permission_code', r.permission_code, 'effect', r.effect,
                      'scope_kind', r.scope_kind, 'scope_id', r.scope_id, 'valid_until', r.valid_until, 'origin', r.origin, 'reason', r.reason)
                      order by r.permission_code)
                     from iam.assignment_permission_rule r
                    where r.company_id = me.company_id and r.assignment_id = p_assignment_id and r.status = 'active'), '[]'::jsonb);
end $$;

create function api.v1_iam_set_assignment_rule(p_assignment_id uuid, p_permission text, p_effect text, p_scope_kind text, p_scope_id uuid,
                                               p_valid_until timestamptz, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare me record; v uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_assert_can_manage_rule(null, p_assignment_id, p_permission, p_effect);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.assignment_permission_rule (company_id, assignment_id, permission_code, effect, scope_kind, scope_id, valid_until, origin, created_by, reason)
  values (me.company_id, p_assignment_id, p_permission, p_effect, p_scope_kind, p_scope_id, p_valid_until,
          case when me.is_supreme then 'chairman' else 'manager' end, me.person_id, p_reason)
  returning id into v;
  return v;
end $$;

create function api.v1_iam_revoke_assignment_rule(p_rule_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare me record; r iam.assignment_permission_rule%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into r from iam.assignment_permission_rule where id = p_rule_id and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'rule'); end if;
  select * into me from iam.fn_assert_can_manage_rule(null, r.assignment_id, r.permission_code, 'deny');
  if r.company_id <> me.company_id then perform core.fn_raise('E_WRONG_COMPANY'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.assignment_permission_rule set status = 'revoked', revoked_at = clock_timestamp(), revoked_by = me.person_id, reason = p_reason
   where id = p_rule_id;
end $$;

reset role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'grant execute on function api.v1_iam_permission_catalog() to authenticated';
    execute 'grant execute on function api.v1_iam_my_permissions() to authenticated';
    execute 'grant execute on function api.v1_iam_position_rules(text) to authenticated';
    execute 'grant execute on function api.v1_iam_set_position_rule(text, text, text, text, uuid, text) to authenticated';
    execute 'grant execute on function api.v1_iam_revoke_position_rule(uuid, text) to authenticated';
    execute 'grant execute on function api.v1_iam_assignment_rules(uuid) to authenticated';
    execute 'grant execute on function api.v1_iam_set_assignment_rule(uuid, text, text, text, uuid, timestamptz, text) to authenticated';
    execute 'grant execute on function api.v1_iam_revoke_assignment_rule(uuid, text) to authenticated';
  end if;
end $$;

-- 20261108000400_iam_person_membership.sql  (S05)
-- One human = one core.person = one login (iam.person_auth_link, 1:1 with a Supabase auth user) = any number of
-- company memberships (iam.company_membership). Only identity lives on the person; everything company-specific
-- (employee number, HR data, positions) lives under a membership/company (OWN-08: companies share nothing else).
-- Identity changes (no company) go to a global hash-chained audit stream. STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ---------------------------------------------------------------- global (company-less) audit chain
create table audit.global_chain_head (
  id        smallint primary key default 1 check (id = 1),
  last_seq  bigint not null default 0,
  last_hash bytea  not null default '\x00'::bytea
);
insert into audit.global_chain_head (id) values (1);

create table audit.global_event (
  seq                bigint      primary key,
  occurred_at        timestamptz not null,
  actor_auth_user_id uuid,
  actor_person_id    uuid,
  action             text        not null check (action ~ '^[a-z0-9_.:]+$'),
  entity_table       text,
  entity_id          uuid,
  outcome            text        not null default 'success' check (outcome in ('success','denied','failed')),
  reason             text,
  detail             jsonb       not null default '{}'::jsonb,
  request_id         text,
  prev_hash          bytea       not null,
  row_hash           bytea       not null
);
create trigger trg_global_event_no_mutation before update or delete on audit.global_event for each row execute function core.fn_deny_mutation();
create trigger trg_global_event_no_truncate before truncate on audit.global_event for each statement execute function core.fn_deny_mutation();
create trigger trg_global_head_no_delete before delete on audit.global_chain_head for each row execute function core.fn_deny_mutation();

-- ---------------------------------------------------------------- person
create table core.person (
  id            uuid primary key default gen_random_uuid(),
  full_name_bn  text not null check (length(btrim(full_name_bn)) > 0),
  full_name_en  text,
  phone         text check (phone ~ '^\+?[0-9]{8,15}$'),
  email         text check (email ~ '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  status        text not null default 'active' check (status in ('active','disabled')),
  authz_epoch   integer not null default 0,     -- bumped on any identity/membership/position change: live sessions re-check
  created_at    timestamptz not null default clock_timestamp(),
  updated_at    timestamptz not null default clock_timestamp(),
  row_version   integer not null default 1
);
create unique index person_phone_uq on core.person (phone) where phone is not null;
create unique index person_email_uq on core.person (lower(email)) where email is not null;

create function iam.fn_person_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.id is distinct from old.id then
    raise exception 'E_IMMUTABLE: person id cannot change' using errcode = 'P0001';
  end if;
  if new.status is distinct from old.status then
    new.authz_epoch := old.authz_epoch + 1;
  end if;
  return new;
end $$;
create trigger trg_person_guard before update on core.person for each row execute function iam.fn_person_guard();
create trigger trg_person_touch before update on core.person for each row execute function core.fn_touch_row();
create trigger trg_person_nodel before delete on core.person for each row execute function core.fn_deny_delete();

-- ---------------------------------------------------------------- login link (1 person : 1 auth user, history kept)
create table iam.person_auth_link (
  id            uuid primary key default gen_random_uuid(),
  person_id     uuid not null references core.person(id),
  auth_user_id  uuid not null,
  status        text not null default 'active' check (status in ('active','revoked')),
  linked_at     timestamptz not null default clock_timestamp(),
  revoked_at    timestamptz,
  revoke_reason text,
  check ((status = 'revoked') = (revoked_at is not null)),
  check (status = 'active' or length(btrim(coalesce(revoke_reason, ''))) > 0)
);
create unique index person_auth_link_one_active_per_person on iam.person_auth_link (person_id)    where status = 'active';
create unique index person_auth_link_one_active_per_user   on iam.person_auth_link (auth_user_id) where status = 'active';
create index person_auth_link_user on iam.person_auth_link (auth_user_id);

-- A link is never edited except active -> revoked (re-linking = a new row). Keeps the identity history provable.
create function iam.fn_auth_link_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.id <> old.id or new.person_id <> old.person_id or new.auth_user_id <> old.auth_user_id or new.linked_at <> old.linked_at then
    raise exception 'E_IMMUTABLE: login link identity cannot change' using errcode = 'P0001';
  end if;
  if old.status = 'revoked' then
    raise exception 'E_IMMUTABLE: a revoked login link cannot be changed' using errcode = 'P0001';
  end if;
  update core.person set authz_epoch = authz_epoch + 1 where id = new.person_id;
  return new;
end $$;
create trigger trg_auth_link_guard before update on iam.person_auth_link for each row execute function iam.fn_auth_link_guard();
create trigger trg_auth_link_nodel before delete on iam.person_auth_link for each row execute function core.fn_deny_delete();

-- Best effort: real FK to Supabase auth.users when this migration role may grant it (OI-02). Never fails the migration.
do $$
begin
  if exists (select 1 from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'auth' and c.relname = 'users') then
    begin
      execute 'reset role';
      execute 'grant references on auth.users to erp_owner';
      execute 'set role erp_owner';
      execute 'alter table iam.person_auth_link add constraint person_auth_link_auth_user_fk foreign key (auth_user_id) references auth.users(id)';
    exception when others then
      execute 'set role erp_owner';
      raise notice 'OI-02: auth.users FK not created (%); link existence is enforced by provisioning only', sqlerrm;
    end;
  end if;
end $$;

-- ---------------------------------------------------------------- company membership
create table iam.company_membership (
  id            uuid primary key default gen_random_uuid(),
  person_id     uuid not null references core.person(id),
  company_id    uuid not null references core.company(id),
  employee_no   text check (employee_no ~ '^[A-Za-z0-9_-]{1,30}$'),
  status        text not null default 'active' check (status in ('invited','active','suspended','ended')),
  started_on    date not null default current_date,
  ended_on      date,
  end_reason    text,
  authz_epoch   integer not null default 0,
  created_at    timestamptz not null default clock_timestamp(),
  updated_at    timestamptz not null default clock_timestamp(),
  row_version   integer not null default 1,
  unique (id, company_id),
  check ((status = 'ended') = (ended_on is not null)),
  check (ended_on is null or ended_on >= started_on),
  check (status <> 'ended' or length(btrim(coalesce(end_reason, ''))) > 0)
);
create unique index membership_one_open_per_company on iam.company_membership (person_id, company_id) where status <> 'ended';
create unique index membership_employee_no on iam.company_membership (company_id, employee_no) where employee_no is not null;
create index membership_person on iam.company_membership (person_id);

create function iam.fn_membership_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.id <> old.id or new.person_id <> old.person_id or new.company_id <> old.company_id then
    raise exception 'E_IMMUTABLE: membership person/company cannot change' using errcode = 'P0001';
  end if;
  if old.status = 'ended' then
    raise exception 'E_MEMBERSHIP_ENDED: an ended membership cannot change; create a new one' using errcode = 'P0001';
  end if;
  if new.status is distinct from old.status then
    new.authz_epoch := old.authz_epoch + 1;
    update core.person set authz_epoch = authz_epoch + 1 where id = new.person_id;
  end if;
  return new;
end $$;
create trigger trg_membership_guard before update on iam.company_membership for each row execute function iam.fn_membership_guard();
create trigger trg_membership_touch before update on iam.company_membership for each row execute function core.fn_touch_row();
create trigger trg_membership_nodel before delete on iam.company_membership for each row execute function core.fn_deny_delete();

-- ---------------------------------------------------------------- caller identity
-- The person behind the JWT: active link AND active person. NULL otherwise (callers raise E_AUTH).
create function iam.fn_current_person() returns uuid
language sql stable security definer set search_path = pg_catalog as $$
  select l.person_id
    from iam.person_auth_link l join core.person p on p.id = l.person_id
   where l.auth_user_id = core.fn_jwt_sub() and l.status = 'active' and p.status = 'active'
$$;

create function iam.fn_require_person() returns uuid
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v uuid := iam.fn_current_person();
begin
  if v is null then perform core.fn_raise('E_AUTH', 'no active person for this login'); end if;
  return v;
end $$;

create function iam.fn_is_active_member(p_person uuid, p_company uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from iam.company_membership m join core.company c on c.id = m.company_id
                  where m.person_id = p_person and m.company_id = p_company and m.status = 'active' and c.status = 'active')
$$;

-- ---------------------------------------------------------------- audit: route company-less rows to the global chain
create function audit.fn_append_global(p_action text, p_entity_table text default null, p_entity_id uuid default null,
                                       p_outcome text default 'success', p_detail jsonb default '{}'::jsonb, p_reason text default null,
                                       p_person uuid default null, p_request_id text default null)
returns bigint language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_head audit.global_chain_head%rowtype; v_seq bigint; v_ts timestamptz := clock_timestamp(); v_hash bytea;
        v_actor uuid := core.fn_jwt_sub(); v_person uuid := coalesce(p_person, iam.fn_current_person());
begin
  select * into v_head from audit.global_chain_head where id = 1 for update;
  v_seq  := v_head.last_seq + 1;
  v_hash := audit.fn_digest(v_head.last_hash, null, v_seq, v_ts, v_actor, v_person, p_action, p_entity_table,
                            p_entity_id, p_outcome, p_reason, coalesce(p_detail, '{}'::jsonb));
  insert into audit.global_event (seq, occurred_at, actor_auth_user_id, actor_person_id, action, entity_table, entity_id,
                                  outcome, reason, detail, request_id, prev_hash, row_hash)
  values (v_seq, v_ts, v_actor, v_person, p_action, p_entity_table, p_entity_id, p_outcome, p_reason,
          coalesce(p_detail, '{}'::jsonb), p_request_id, v_head.last_hash, v_hash);
  update audit.global_chain_head set last_seq = v_seq, last_hash = v_hash where id = 1;
  return v_seq;
end $$;

create function audit.fn_verify_global_chain() returns bigint
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare r audit.global_event%rowtype; v_prev bytea := '\x00'::bytea; v_expect bytea; v_n bigint := 0;
begin
  for r in select * from audit.global_event order by seq loop
    v_n := v_n + 1;
    if r.seq <> v_n or r.prev_hash <> v_prev then return r.seq; end if;
    v_expect := audit.fn_digest(v_prev, null, r.seq, r.occurred_at, r.actor_auth_user_id, r.actor_person_id,
                                r.action, r.entity_table, r.entity_id, r.outcome, r.reason, r.detail);
    if v_expect <> r.row_hash then return r.seq; end if;
    v_prev := r.row_hash;
  end loop;
  if exists (select 1 from audit.global_chain_head h where h.last_seq <> v_n or h.last_hash <> v_prev) then return v_n + 1; end if;
  return null;
end $$;

-- Company appender now records the acting person automatically (iam exists from here on).
create or replace function audit.fn_append(p_company uuid, p_action text, p_entity_table text default null, p_entity_id uuid default null,
                                p_outcome text default 'success', p_detail jsonb default '{}'::jsonb, p_reason text default null,
                                p_person uuid default null, p_request_id text default null)
returns bigint language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_head audit.chain_head%rowtype; v_seq bigint; v_ts timestamptz := clock_timestamp(); v_hash bytea;
        v_actor uuid := core.fn_jwt_sub(); v_person uuid := coalesce(p_person, iam.fn_current_person());
begin
  if p_company is null then
    perform core.fn_raise('E_AUDIT_COMPANY_REQUIRED');
  end if;
  insert into audit.chain_head (company_id) values (p_company) on conflict do nothing;
  select * into v_head from audit.chain_head where company_id = p_company for update;
  v_seq  := v_head.last_seq + 1;
  v_hash := audit.fn_digest(v_head.last_hash, p_company, v_seq, v_ts, v_actor, v_person, p_action, p_entity_table,
                            p_entity_id, p_outcome, p_reason, coalesce(p_detail, '{}'::jsonb));
  insert into audit.event (company_id, seq, occurred_at, actor_auth_user_id, actor_person_id, action, entity_table, entity_id,
                           outcome, reason, detail, request_id, prev_hash, row_hash)
  values (p_company, v_seq, v_ts, v_actor, v_person, p_action, p_entity_table, p_entity_id,
          p_outcome, p_reason, coalesce(p_detail, '{}'::jsonb), p_request_id, v_head.last_hash, v_hash);
  update audit.chain_head set last_seq = v_seq, last_hash = v_hash where company_id = p_company;
  return v_seq;
end $$;

create or replace function audit.fn_row_change() returns trigger
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_company uuid; v_detail jsonb; v_action text := lower(tg_op) || ':' || tg_table_schema || '.' || tg_table_name;
        v_reason text := nullif(current_setting('mohona.change_reason', true), '');
begin
  v_company := case when tg_table_schema = 'core' and tg_table_name = 'company' then new.id else (to_jsonb(new) ->> 'company_id')::uuid end;
  v_detail := case when tg_op = 'INSERT' then jsonb_build_object('new', to_jsonb(new))
                   else jsonb_build_object('old', to_jsonb(old), 'new', to_jsonb(new)) end;
  if v_company is null then
    perform audit.fn_append_global(v_action, tg_table_schema || '.' || tg_table_name, new.id, 'success', v_detail, v_reason);
  else
    perform audit.fn_append(v_company, v_action, tg_table_schema || '.' || tg_table_name, new.id, 'success', v_detail, v_reason);
  end if;
  return null;
end $$;

create trigger trg_person_audit     after insert or update on core.person             for each row execute function audit.fn_row_change();
create trigger trg_auth_link_audit  after insert or update on iam.person_auth_link   for each row execute function audit.fn_row_change();
create trigger trg_membership_audit after insert or update on iam.company_membership for each row execute function audit.fn_row_change();

-- ---------------------------------------------------------------- provisioning (server-side only: service_role)
-- Used by the admin back-office / bootstrap (first Chairman, S09). App users never call these.
create function svc.v1_iam_provision_person(p_full_name_bn text, p_phone text, p_email text, p_auth_user_id uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_person uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_auth_user_id is not null and exists (select 1 from iam.person_auth_link where auth_user_id = p_auth_user_id and status = 'active') then
    perform core.fn_raise('E_DUPLICATE', 'login already linked');
  end if;
  insert into core.person (full_name_bn, phone, email) values (p_full_name_bn, p_phone, p_email) returning id into v_person;
  if p_auth_user_id is not null then
    insert into iam.person_auth_link (person_id, auth_user_id) values (v_person, p_auth_user_id);
  end if;
  return v_person;
end $$;

create function svc.v1_iam_relink_login(p_person uuid, p_new_auth_user_id uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.person_auth_link set status = 'revoked', revoked_at = clock_timestamp(), revoke_reason = p_reason
   where person_id = p_person and status = 'active';
  if p_new_auth_user_id is not null then
    insert into iam.person_auth_link (person_id, auth_user_id) values (p_person, p_new_auth_user_id);
  end if;
end $$;

create function svc.v1_iam_add_membership(p_person uuid, p_company uuid, p_employee_no text, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if not exists (select 1 from core.company where id = p_company and status in ('provisioning','active')) then
    perform core.fn_raise('E_NOT_FOUND', 'company not open');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.company_membership (person_id, company_id, employee_no) values (p_person, p_company, p_employee_no) returning id into v;
  return v;
end $$;

create function svc.v1_iam_end_membership(p_membership uuid, p_ended_on date, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.company_membership set status = 'ended', ended_on = coalesce(p_ended_on, current_date), end_reason = p_reason
   where id = p_membership;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
end $$;

-- ---------------------------------------------------------------- app API
-- Who am I: person + open memberships (companies). Positions are added in S06.
create function api.v1_iam_whoami() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); v jsonb;
begin
  select jsonb_build_object(
           'person', jsonb_build_object('id', p.id, 'full_name_bn', p.full_name_bn, 'full_name_en', p.full_name_en, 'authz_epoch', p.authz_epoch),
           'memberships', coalesce((
              select jsonb_agg(jsonb_build_object('membership_id', m.id, 'company_id', c.id, 'company_code', c.code, 'company_name_bn', c.name_bn,
                                                  'status', m.status, 'company_status', c.status, 'employee_no', m.employee_no) order by c.code)
                from iam.company_membership m join core.company c on c.id = m.company_id
               where m.person_id = p.id and m.status <> 'ended'), '[]'::jsonb))
    into v from core.person p where p.id = v_person;
  return v;
end $$;

reset role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'grant execute on function api.v1_iam_whoami() to authenticated';
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_iam_provision_person(text, text, text, uuid, text) to service_role';
    execute 'grant execute on function svc.v1_iam_relink_login(uuid, uuid, text) to service_role';
    execute 'grant execute on function svc.v1_iam_add_membership(uuid, uuid, text, text) to service_role';
    execute 'grant execute on function svc.v1_iam_end_membership(uuid, date, text) to service_role';
  end if;
end $$;

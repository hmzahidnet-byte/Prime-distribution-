-- 20261108000500_iam_positions_session.sql  (S06)
-- Company position catalog (Chairman-customisable, seeded from 17 owner-approved templates, OD-04),
-- position assignments (person's membership -> position, time-bounded, home wing/department scope),
-- and the ACTIVE POSITION of a login session (exactly one at a time; every business RPC acts as that one position,
-- never as a union of positions: blueprint 113/123/140).
-- Lock order (blueprint 125, used by every write RPC and every revocation):
--   core.company -> iam.company_membership -> iam.position_assignment -> (hr.employment, S70) -> grants -> domain rows.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- Generic JWT claim reader (never raises).
create function core.fn_jwt_claim(p_name text) returns text
language plpgsql stable set search_path = pg_catalog as $$
begin
  return nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> p_name;
exception when others then
  return null;
end $$;

-- ---------------------------------------------------------------- templates (platform defaults, read-only)
create table iam.position_template (
  code          text primary key check (code ~ '^[A-Z][A-Z0-9_]{1,39}$'),
  name_bn       text not null,
  name_en       text not null,
  rank          integer not null check (rank between 0 and 1000),
  max_holders   integer check (max_holders > 0),
  is_supreme    boolean not null default false,
  is_protected  boolean not null default false,
  enabled_by_default boolean not null default true,
  description_bn text,
  check (not is_supreme or code = 'CHAIRMAN')
);
create trigger trg_position_template_no_mutation before update or delete on iam.position_template for each row execute function core.fn_deny_mutation();

insert into iam.position_template (code, name_bn, name_en, rank, max_holders, is_supreme, is_protected, enabled_by_default, description_bn) values
  ('CHAIRMAN',         'চেয়ারম্যান',              'Chairman',              1000, 1,    true,  true,  true,  'কোম্পানির সর্বোচ্চ কর্তৃপক্ষ; সব সেটিং ও কাস্টমাইজেশন'),
  ('MD',               'ব্যবস্থাপনা পরিচালক',     'Managing Director',      900, 1,    false, true,  true,  'কোম্পানি-পরিচালনা'),
  ('WING_HEAD',        'উইং-প্রধান',               'Wing Head',              800, null, false, false, true,  'নির্দিষ্ট উইং-এর প্রধান'),
  ('FIN_MANAGER',      'অর্থ-ব্যবস্থাপক',          'Finance Manager',        700, null, false, false, true,  null),
  ('ACCOUNTANT',       'হিসাবরক্ষক',               'Accountant',             600, null, false, false, true,  null),
  ('CASHIER',          'ক্যাশিয়ার',                'Cashier',                500, null, false, false, true,  null),
  ('HR_OFFICER',       'এইচআর কর্মকর্তা',          'HR Officer',             600, null, false, false, true,  null),
  ('PAYROLL_OFFICER',  'বেতন-কর্মকর্তা',            'Payroll Officer',        600, null, false, false, true,  'ADR-04 seeded position'),
  ('STOREKEEPER',      'স্টোরকিপার',               'Storekeeper',            500, null, false, false, true,  null),
  ('PROD_SUPERVISOR',  'উৎপাদন-তত্ত্বাবধায়ক',      'Production Supervisor',  600, null, false, false, true,  null),
  ('QC_OFFICER',       'মান-নিয়ন্ত্রণ কর্মকর্তা',  'QC Officer',             550, null, false, false, true,  null),
  ('PURCHASE_OFFICER', 'ক্রয়-কর্মকর্তা',           'Purchase Officer',       550, null, false, false, true,  null),
  ('SALES_MANAGER',    'বিক্রয়-ব্যবস্থাপক',        'Sales Manager',          650, null, false, false, true,  null),
  ('FIELD_SALES',      'মাঠ-বিক্রয়কর্মী',          'Field Sales',            400, null, false, false, true,  null),
  ('AUDITOR',          'নিরীক্ষক',                 'Auditor',                650, null, false, false, true,  'শুধু পাঠ ও যাচাই'),
  ('EMPLOYEE_SELF',    'কর্মী (নিজস্ব)',           'Employee Self-service',  100, null, false, true,  true,  'নিজের তথ্য'),
  ('TECH_ADMIN',       'টেক-অ্যাডমিন',             'Technical Admin',        300, null, false, false, true,  'প্রযুক্তিগত; ব্যবসায়িক তথ্য নয়'),
  ('EMERGENCY_ADMIN',  'জরুরি-অ্যাডমিন',           'Emergency Admin',        950, 1,    false, true,  false, 'নিষ্ক্রিয় (নীতি অনুমোদিত নয়)');

-- ---------------------------------------------------------------- company catalog (Chairman edits name/rank/enabled/limits; S20 UI)
create table iam.position_catalog (
  company_id     uuid not null references core.company(id),
  code           text not null check (code ~ '^[A-Z][A-Z0-9_]{1,39}$'),
  name_bn        text not null check (length(btrim(name_bn)) > 0),
  name_en        text,
  rank           integer not null default 100 check (rank between 0 and 1000),
  max_holders    integer check (max_holders > 0),
  is_supreme     boolean not null default false,
  is_protected   boolean not null default false,
  is_enabled     boolean not null default true,
  template_code  text references iam.position_template(code),
  department_id  uuid,                         -- optional org-chart placement
  reports_to_code text,
  sort_order     integer not null default 0,
  created_at     timestamptz not null default clock_timestamp(),
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1,
  primary key (company_id, code),
  check (not is_supreme or code = 'CHAIRMAN'),
  check (reports_to_code is null or reports_to_code <> code),
  foreign key (department_id, company_id) references core.department (id, company_id),
  foreign key (company_id, reports_to_code) references iam.position_catalog (company_id, code)
);

create trigger trg_position_catalog_touch before update on iam.position_catalog for each row execute function core.fn_touch_row();
create trigger trg_position_catalog_nodel before delete on iam.position_catalog for each row execute function core.fn_deny_delete();

-- Copies the templates into a company (idempotent). Called when a company is provisioned.
create function iam.fn_seed_company_positions(p_company uuid) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare n integer;
begin
  insert into iam.position_catalog (company_id, code, name_bn, name_en, rank, max_holders, is_supreme, is_protected, is_enabled, template_code, sort_order)
  select p_company, t.code, t.name_bn, t.name_en, t.rank, t.max_holders, t.is_supreme, t.is_protected, t.enabled_by_default, t.code, 1000 - t.rank
    from iam.position_template t
  on conflict (company_id, code) do nothing;
  get diagnostics n = row_count;
  return n;
end $$;

create function iam.fn_company_seed_positions() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform iam.fn_seed_company_positions(new.id);
  return null;
end $$;
create trigger trg_company_seed_positions after insert on core.company for each row execute function iam.fn_company_seed_positions();

-- ---------------------------------------------------------------- assignments
create table iam.position_assignment (
  id                 uuid primary key default gen_random_uuid(),
  company_id         uuid not null,
  membership_id      uuid not null,
  position_code      text not null,
  assignment_kind    text not null default 'regular' check (assignment_kind in ('regular','acting')),
  status             text not null default 'active' check (status in ('active','suspended','ended')),
  valid_from         timestamptz not null default clock_timestamp(),
  valid_until        timestamptz,
  home_wing_id       uuid,
  home_department_id uuid,
  home_location_id   uuid,
  ended_at           timestamptz,
  end_reason         text,
  authz_epoch        integer not null default 0,
  created_at         timestamptz not null default clock_timestamp(),
  updated_at         timestamptz not null default clock_timestamp(),
  row_version        integer not null default 1,
  unique (id, company_id),
  check (valid_until is null or valid_until > valid_from),
  check ((status = 'ended') = (ended_at is not null)),
  check (status <> 'ended' or length(btrim(coalesce(end_reason, ''))) > 0),
  foreign key (membership_id, company_id) references iam.company_membership (id, company_id),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code),
  foreign key (home_wing_id, company_id) references core.wing (id, company_id),
  foreign key (home_department_id, company_id) references core.department (id, company_id),
  foreign key (home_location_id, company_id) references core.location (id, company_id)
);
create index position_assignment_membership on iam.position_assignment (company_id, membership_id) where status <> 'ended';
create index position_assignment_code on iam.position_assignment (company_id, position_code) where status <> 'ended';
-- One person cannot hold the same position twice at the same time.
create unique index position_assignment_no_duplicate on iam.position_assignment (membership_id, position_code) where status <> 'ended';

-- Insert/update rules: enabled position, open membership, holder limit (serialised by locking the catalog row).
create function iam.fn_assignment_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
declare v_cat iam.position_catalog%rowtype; v_holders integer; v_mstatus text;
begin
  if tg_op = 'UPDATE' then
    if new.id <> old.id or new.company_id <> old.company_id or new.membership_id <> old.membership_id
       or new.position_code <> old.position_code or new.valid_from <> old.valid_from then
      raise exception 'E_IMMUTABLE: assignment holder/position/start cannot change' using errcode = 'P0001';
    end if;
    if old.status = 'ended' then
      raise exception 'E_ASSIGNMENT_ENDED: an ended assignment cannot change' using errcode = 'P0001';
    end if;
    if new.status is distinct from old.status or new.valid_until is distinct from old.valid_until then
      new.authz_epoch := old.authz_epoch + 1;
      update core.person set authz_epoch = authz_epoch + 1
       where id = (select m.person_id from iam.company_membership m where m.id = new.membership_id);
    end if;
    if new.status <> 'active' then return new; end if;
    if old.status = 'active' then return new; end if;     -- unchanged-active edits (e.g. home scope) skip the holder count
  end if;
  select * into v_cat from iam.position_catalog where company_id = new.company_id and code = new.position_code for update;
  if not v_cat.is_enabled then
    raise exception 'E_POSITION_DISABLED: position % is disabled', new.position_code using errcode = 'P0001';
  end if;
  select status into v_mstatus from iam.company_membership where id = new.membership_id;
  if v_mstatus not in ('active','invited') then
    raise exception 'E_MEMBERSHIP_NOT_ACTIVE: membership is %', v_mstatus using errcode = 'P0001';
  end if;
  if v_cat.max_holders is not null then
    select count(*) into v_holders from iam.position_assignment a
     where a.company_id = new.company_id and a.position_code = new.position_code and a.status = 'active' and a.id <> new.id
       and (a.valid_until is null or a.valid_until > new.valid_from)
       and (new.valid_until is null or a.valid_from < new.valid_until);
    if v_holders >= v_cat.max_holders then
      raise exception 'E_POSITION_FULL: % already has % holder(s)', new.position_code, v_holders using errcode = 'P0001';
    end if;
  end if;
  return new;
end $$;
create trigger trg_assignment_guard before insert or update on iam.position_assignment for each row execute function iam.fn_assignment_guard();
create trigger trg_assignment_touch before update on iam.position_assignment for each row execute function core.fn_touch_row();
create trigger trg_assignment_nodel before delete on iam.position_assignment for each row execute function core.fn_deny_delete();

create function iam.fn_position_catalog_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.company_id <> old.company_id or new.code <> old.code then
    raise exception 'E_IMMUTABLE: position code cannot change' using errcode = 'P0001';
  end if;
  if new.is_supreme is distinct from old.is_supreme or new.is_protected is distinct from old.is_protected
     or new.template_code is distinct from old.template_code then
    raise exception 'E_IMMUTABLE: supreme/protected/template flags are fixed' using errcode = 'P0001';
  end if;
  if old.code = 'CHAIRMAN' and (not new.is_enabled or new.max_holders is distinct from 1) then
    raise exception 'E_PROTECTED_POSITION: the Chairman position is always enabled with exactly one holder' using errcode = 'P0001';
  end if;
  if new.reports_to_code is distinct from old.reports_to_code and new.reports_to_code is not null then
    declare v_cur text := new.reports_to_code; v_depth integer := 0;
    begin
      while v_cur is not null loop
        if v_cur = new.code then
          raise exception 'E_POSITION_CYCLE: reporting line would contain a cycle' using errcode = 'P0001';
        end if;
        v_depth := v_depth + 1;
        if v_depth > 50 then raise exception 'E_POSITION_CYCLE: reporting line deeper than 50' using errcode = 'P0001'; end if;
        select pc.reports_to_code into v_cur from iam.position_catalog pc where pc.company_id = new.company_id and pc.code = v_cur;
      end loop;
    end;
  end if;
  if old.is_enabled and not new.is_enabled and exists (
       select 1 from iam.position_assignment a
        where a.company_id = new.company_id and a.position_code = new.code and a.status = 'active'
          and (a.valid_until is null or a.valid_until > clock_timestamp())) then
    raise exception 'E_POSITION_IN_USE: end the active assignments before disabling this position' using errcode = 'P0001';
  end if;
  return new;
end $$;
-- Ending a membership ends its assignments (same transaction, same lock order: membership row already locked by the update).
create function iam.fn_membership_end_cascade() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.status in ('ended','suspended') and old.status is distinct from new.status then
    update iam.position_assignment
       set status = case when new.status = 'ended' then 'ended' else 'suspended' end,
           ended_at = case when new.status = 'ended' then clock_timestamp() else ended_at end,
           end_reason = case when new.status = 'ended' then 'membership ended: ' || coalesce(new.end_reason, '') else end_reason end
     where membership_id = new.id and (status = 'active' or (new.status = 'ended' and status = 'suspended'));   -- ending ends suspended ones too
  end if;
  return null;
end $$;
create trigger trg_membership_end_cascade after update of status on iam.company_membership for each row execute function iam.fn_membership_end_cascade();

-- ---------------------------------------------------------------- active position per login session
create table iam.session_context (
  session_key     text primary key,               -- JWT session_id (Supabase) or 'user:'||sub when absent
  auth_user_id    uuid not null,
  person_id       uuid not null references core.person(id),
  company_id      uuid not null,
  membership_id   uuid not null,
  assignment_id   uuid not null,
  selected_at     timestamptz not null default clock_timestamp(),
  person_epoch_at_select integer not null,
  foreign key (membership_id, company_id) references iam.company_membership (id, company_id),
  foreign key (assignment_id, company_id) references iam.position_assignment (id, company_id)
);
create index session_context_person on iam.session_context (person_id);

create function iam.fn_session_key() returns text
language sql stable set search_path = pg_catalog as $$
  select coalesce(nullif(core.fn_jwt_claim('session_id'), ''), 'user:' || core.fn_jwt_sub()::text)
$$;

-- Is this assignment usable RIGHT NOW by this person? (company active, membership active, assignment active+in validity,
-- position enabled). Single source of truth for selection AND for every later request.
create function iam.fn_assignment_usable(p_person uuid, p_assignment uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (
    select 1
      from iam.position_assignment a
      join iam.company_membership m on m.id = a.membership_id and m.company_id = a.company_id
      join core.company c on c.id = a.company_id
      join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
     where a.id = p_assignment and m.person_id = p_person
       and c.status = 'active' and m.status = 'active' and a.status = 'active' and pc.is_enabled
       and a.valid_from <= clock_timestamp() and (a.valid_until is null or a.valid_until > clock_timestamp()))
$$;

-- The caller's live context. Raises E_AUTH (no person) / E_NO_ACTIVE_POSITION (none selected or no longer usable).
-- p_lock = true (write RPCs): takes FOR SHARE locks in the canonical order, so a concurrent revocation (which takes
-- FOR UPDATE on the same rows) waits for this transaction, and a revocation that committed first is seen here.
create function iam.fn_context(p_lock boolean default false)
returns table (person_id uuid, company_id uuid, membership_id uuid, assignment_id uuid, position_code text, is_supreme boolean,
               home_wing_id uuid, home_department_id uuid, home_location_id uuid)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare v_person uuid := iam.fn_require_person(); s iam.session_context%rowtype;
begin
  select * into s from iam.session_context where session_key = iam.fn_session_key();
  if not found or s.person_id <> v_person then
    perform core.fn_raise('E_NO_ACTIVE_POSITION');
  end if;
  if p_lock then
    perform 1 from core.company           where id = s.company_id    for share;
    perform 1 from iam.company_membership where id = s.membership_id for share;
    perform 1 from iam.position_assignment where id = s.assignment_id for share;
  end if;
  if not iam.fn_assignment_usable(v_person, s.assignment_id) then
    perform core.fn_raise('E_NO_ACTIVE_POSITION', 'selected position is no longer active');
  end if;
  return query
    select v_person, a.company_id, a.membership_id, a.id, a.position_code, pc.is_supreme, a.home_wing_id, a.home_department_id, a.home_location_id
      from iam.position_assignment a join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
     where a.id = s.assignment_id;
end $$;

create trigger trg_position_catalog_guard before update on iam.position_catalog for each row execute function iam.fn_position_catalog_guard();

-- ---------------------------------------------------------------- audit
create trigger trg_position_catalog_audit after insert or update on iam.position_catalog for each row execute function audit.fn_row_change();
create trigger trg_assignment_audit after insert or update on iam.position_assignment for each row execute function audit.fn_row_change();

-- position_catalog has no id column: audit row trigger reads new.id -> give the trigger a stable entity id instead.
create or replace function audit.fn_row_change() returns trigger
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare v_company uuid; v_detail jsonb; v_action text := lower(tg_op) || ':' || tg_table_schema || '.' || tg_table_name;
        v_reason text := nullif(current_setting('mohona.change_reason', true), ''); v_row jsonb := to_jsonb(new); v_id uuid;
begin
  v_company := case when tg_table_schema = 'core' and tg_table_name = 'company' then (v_row ->> 'id')::uuid else (v_row ->> 'company_id')::uuid end;
  -- ledger-style tables use bigint identities: entity id null, the row (with its id) stays in the detail
  v_id := case when (v_row ->> 'id') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then (v_row ->> 'id')::uuid end;
  v_detail := case when tg_op = 'INSERT' then jsonb_build_object('new', v_row)
                   else jsonb_build_object('old', to_jsonb(old), 'new', v_row) end;
  if v_row ? 'code' and v_id is null then v_detail := v_detail || jsonb_build_object('key', v_row ->> 'code'); end if;
  if v_id is null and v_row ? 'id' then v_detail := v_detail || jsonb_build_object('row_id', v_row ->> 'id'); end if;
  if v_company is null then
    perform audit.fn_append_global(v_action, tg_table_schema || '.' || tg_table_name, v_id, 'success', v_detail, v_reason);
  else
    perform audit.fn_append(v_company, v_action, tg_table_schema || '.' || tg_table_name, v_id, 'success', v_detail, v_reason);
  end if;
  return null;
end $$;

-- ---------------------------------------------------------------- provisioning (service_role; Chairman-managed API arrives with permissions, S07/S09)
create function svc.v1_iam_seed_company_positions(p_company uuid) returns integer
language plpgsql security definer set search_path = '' as $$
begin
  if not exists (select 1 from core.company where id = p_company) then perform core.fn_raise('E_NOT_FOUND', 'company'); end if;
  perform set_config('mohona.change_reason', 'seed position catalog from templates', true);
  return iam.fn_seed_company_positions(p_company);
end $$;

create function svc.v1_iam_assign_position(p_membership uuid, p_position_code text, p_valid_from timestamptz, p_valid_until timestamptz,
                                           p_kind text, p_home_wing uuid, p_home_department uuid, p_reason text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_company uuid; v uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select company_id into v_company from iam.company_membership where id = p_membership for no key update;   -- lock order: (company share by FK) -> membership
  if v_company is null then perform core.fn_raise('E_NOT_FOUND', 'membership'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind, valid_from, valid_until, home_wing_id, home_department_id)
  values (v_company, p_membership, p_position_code, coalesce(p_kind, 'regular'), coalesce(p_valid_from, clock_timestamp()), p_valid_until, p_home_wing, p_home_department)
  returning id into v;
  return v;
end $$;

create function svc.v1_iam_end_assignment(p_assignment uuid, p_reason text)
returns void language plpgsql security definer set search_path = '' as $$
declare v_company uuid; v_membership uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select company_id, membership_id into v_company, v_membership from iam.position_assignment where id = p_assignment;
  if v_company is null then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  -- Revocation locks membership then assignment (NO KEY UPDATE conflicts with the FOR SHARE taken by in-flight
  -- write RPCs in iam.fn_context(true), so they finish first; later requests see the ended assignment).
  perform 1 from iam.company_membership where id = v_membership for no key update;
  perform set_config('mohona.change_reason', p_reason, true);
  update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = p_reason where id = p_assignment;
end $$;

-- ---------------------------------------------------------------- app API
-- All my usable and not-yet-usable assignments, across my companies (the position picker).
create function api.v1_iam_my_positions() returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person();
begin
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'assignment_id', a.id, 'company_id', c.id, 'company_code', c.code, 'company_name_bn', c.name_bn,
             'position_code', a.position_code, 'position_name_bn', pc.name_bn, 'rank', pc.rank, 'is_supreme', pc.is_supreme,
             'kind', a.assignment_kind, 'valid_from', a.valid_from, 'valid_until', a.valid_until,
             'home_wing_id', a.home_wing_id, 'home_department_id', a.home_department_id,
             'usable', iam.fn_assignment_usable(v_person, a.id))
           order by c.code, pc.rank desc, a.position_code)
      from iam.position_assignment a
      join iam.company_membership m on m.id = a.membership_id
      join core.company c on c.id = a.company_id
      join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
     where m.person_id = v_person and a.status <> 'ended' and m.status <> 'ended'), '[]'::jsonb);
end $$;

-- Current context (or E_NO_ACTIVE_POSITION). Includes the epoch so the client can drop caches when it changes.
create function api.v1_iam_current_context() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare r record; v_epoch integer;
begin
  select * into r from iam.fn_context(false);
  select authz_epoch into v_epoch from core.person where id = r.person_id;
  return jsonb_build_object(
    'person_id', r.person_id, 'company_id', r.company_id, 'membership_id', r.membership_id, 'assignment_id', r.assignment_id,
    'position_code', r.position_code, 'is_supreme', r.is_supreme, 'home_wing_id', r.home_wing_id,
    'home_department_id', r.home_department_id, 'authz_epoch', v_epoch,
    'company_code', (select code from core.company where id = r.company_id),
    'company_name_bn', (select name_bn from core.company where id = r.company_id),
    'position_name_bn', (select name_bn from iam.position_catalog where company_id = r.company_id and code = r.position_code));
end $$;

-- Select the ONE position this session acts as. Replaces any previous selection of this session. Audited.
create function api.v1_iam_select_position(p_assignment_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_person uuid := iam.fn_require_person(); a iam.position_assignment%rowtype; v_epoch integer; v_key text := iam.fn_session_key(); v_max integer;
begin
  if p_assignment_id is null or not iam.fn_assignment_usable(v_person, p_assignment_id) then
    perform core.fn_raise('E_FORBIDDEN', 'position not usable by this login');
  end if;
  select * into a from iam.position_assignment where id = p_assignment_id;
  select authz_epoch into v_epoch from core.person where id = v_person;
  insert into iam.session_context (session_key, auth_user_id, person_id, company_id, membership_id, assignment_id, person_epoch_at_select)
  values (v_key, core.fn_jwt_sub(), v_person, a.company_id, a.membership_id, a.id, v_epoch)
  on conflict (session_key) do update
     set auth_user_id = excluded.auth_user_id, person_id = excluded.person_id, company_id = excluded.company_id,
         membership_id = excluded.membership_id, assignment_id = excluded.assignment_id,
         selected_at = clock_timestamp(), person_epoch_at_select = excluded.person_epoch_at_select;
  -- ADR-08: concurrent-session limit (Chairman setting; default 1). Older sessions of this person lose their selection.
  v_max := config.fn_get_int(a.company_id, 'iam.session.max_concurrent');
  if v_max > 0 then
    delete from iam.session_context sc
     where sc.person_id = v_person and sc.session_key <> v_key
       and sc.session_key not in (select o.session_key from iam.session_context o
                                   where o.person_id = v_person and o.session_key <> v_key
                                   order by o.selected_at desc limit greatest(v_max - 1, 0));
  end if;
  perform audit.fn_append(a.company_id, 'session.select_position', 'iam.position_assignment', a.id, 'success',
                          jsonb_build_object('position_code', a.position_code));
  return api.v1_iam_current_context();
end $$;

-- Forget this session's selection (logout / switch screen).
create function api.v1_iam_clear_position() returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform iam.fn_require_person();
  delete from iam.session_context where session_key = iam.fn_session_key();
end $$;

reset role;

do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'grant execute on function api.v1_iam_my_positions() to authenticated';
    execute 'grant execute on function api.v1_iam_select_position(uuid) to authenticated';
    execute 'grant execute on function api.v1_iam_current_context() to authenticated';
    execute 'grant execute on function api.v1_iam_clear_position() to authenticated';
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_iam_seed_company_positions(uuid) to service_role';
    execute 'grant execute on function svc.v1_iam_assign_position(uuid, text, timestamptz, timestamptz, text, uuid, uuid, text) to service_role';
    execute 'grant execute on function svc.v1_iam_end_assignment(uuid, text) to service_role';
  end if;
end $$;

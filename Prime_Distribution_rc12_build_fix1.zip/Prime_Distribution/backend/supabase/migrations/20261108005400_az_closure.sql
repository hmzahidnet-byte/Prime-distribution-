-- 20261108005400_az_closure.sql  (S70 — gaps found by the full A–Z pass of 15 Nov 2026; see docs/V180_AZ_STATUS_BN.md §A–Z)
-- V170/V171 domain contracts, V174 entities, V161 dealer features (300), V166/V169 hybrid location — what was still missing:
--   A  supplier bank-account change only through an approved request (V171 SUPPLIER "banking changes")
--   B  machine service schedule + services due (V170/V171 MACHINE "service schedule")
--   C  production-plan readiness: material need from the approved BOM vs available stock, daily capacity (V171 PLAN)
--   D  utility cost as its own WIP component (V170 WIP / V174 mfg.wip_cost)
--   E  location claims: USER_SELECTED / GOOGLE_MATCHED / ADMIN_CROSSCHECKED / APPROVED / REJECTED with evidence and an independent
--      reviewer; dealer address change goes through it (V166 01/09/12, V169 44/45)
--   F  market merge / split (V161 02-08/09/16)
--   G  dealer outlets (multi-outlet dealer, V161 01-08) + outlet on order requests / orders
--   H  dealer self-service: contact change request, notification preferences + terms consent, own-data export, offboarding (V161 01-11/15/16/17/19)
--   I  disputes on ledger / payment / invoice / order / delivery / visit (V161 01-18, 05-09, 06-18, 10-17)
--   J  receivable aging + optional overdue hold on new orders (V161 04-03, 05-13)
--   K  manual order hold / release before dispatch + stale (expiring) order list (V161 04-12/13/14)
--   L  notices targeted by market; offer redemption linked to order requests (V161 07-04/15)
--   M  visit check-out (V161 10-04)
--   N  per-product dealer visibility (V162 15)
-- STATUS: WRITTEN; executed with the SQL suite (t_s70_az_closure.sql).
set role erp_owner;

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('mfg.capacity.daily_poly',         'mfg',   'int',  '0', 0, 10000000, null, 'দৈনিক উৎপাদন-সক্ষমতা (পলি; ০ = নির্ধারিত নয়)', 'V171 PLAN', false, 2800),
  ('mfg.plan.require_material_ready', 'mfg',   'bool', 'false', null, null, null, 'কাঁচামাল ঘাটতি থাকলে পরিকল্পনা অনুমোদন বন্ধ', 'V171 PLAN', false, 2801),
  ('sales.order.overdue_hold_days',   'sales', 'int',  '0', 0, 365, null, 'এত দিনের বেশি মেয়াদোত্তীর্ণ বকেয়া থাকলে নতুন অর্ডার হোল্ডে (০ = বন্ধ)', 'V161 04-03', false, 2802),
  ('sales.order.stale_days',          'sales', 'int',  '7', 1, 90, null, 'অনুমোদিত কিন্তু না-পাঠানো অর্ডার কত দিনে "পুরোনো"', 'V161 04-14', false, 2803)
on conflict (key) do nothing;

-- ================================================================ A supplier bank change
create table procurement.supplier_bank_change (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  supplier_id  uuid not null,
  old_masked   text,
  new_masked   text not null check (new_masked ~ '^[•*xX]+[0-9]{2,4}$'),
  reason       text not null check (length(btrim(reason)) > 0),
  evidence_path text,
  status       text not null default 'pending' check (status in ('pending','approved','rejected')),
  requested_by uuid not null references core.person(id),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  check (decided_by is null or decided_by <> requested_by),
  foreign key (supplier_id, company_id) references procurement.supplier (id, company_id)
);
create unique index ux_supplier_bank_change_open on procurement.supplier_bank_change (supplier_id) where status = 'pending';
create trigger trg_supplier_bank_change_nodel before delete on procurement.supplier_bank_change for each row execute function core.fn_deny_delete();
create trigger trg_supplier_bank_change_audit after insert or update on procurement.supplier_bank_change for each row execute function audit.fn_row_change();
select core.fn_apply_rls('procurement', 'supplier_bank_change');

create function procurement.fn_supplier_bank_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.bank_account_masked is distinct from old.bank_account_masked and coalesce(current_setting('mohona.bank_change_ok', true), '') <> 'on' then
    raise exception 'E_APPROVAL_REQUIRED: a supplier bank account changes only through an approved change request' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_supplier_bank_guard before update on procurement.supplier for each row execute function procurement.fn_supplier_bank_guard();

create function api.v1_supplier_bank_change_request(p_supplier_id uuid, p_new_masked text, p_evidence_path text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s procurement.supplier%rowtype; v uuid;
begin
  select * into me from iam.fn_require('master.supplier.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into s from procurement.supplier where id = p_supplier_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'supplier'); end if;
  if coalesce(p_new_masked, '') !~ '^[•*xX]+[0-9]{2,4}$' then perform core.fn_raise('E_INVALID_ACTION', 'bank account must be stored masked (only the last digits)'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into procurement.supplier_bank_change (company_id, supplier_id, old_masked, new_masked, reason, evidence_path, requested_by)
  values (me.company_id, s.id, s.bank_account_masked, p_new_masked, btrim(p_reason), p_evidence_path, me.person_id) returning id into v;
  return jsonb_build_object('change_id', v, 'status', 'pending');
end $$;

create function api.v1_supplier_bank_change_decide(p_change_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c procurement.supplier_bank_change%rowtype;
begin
  select * into me from iam.fn_require('finance.ap.pay', iam.fn_my_company_resource(), true);
  select * into c from procurement.supplier_bank_change where id = p_change_id and company_id = me.company_id for update;
  if not found or c.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending change'); end if;
  if c.requested_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  if not coalesce(p_approve, false) and length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'bank change approved'), true);
  update procurement.supplier_bank_change set status = case when p_approve then 'approved' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp() where id = c.id;
  if p_approve then
    perform set_config('mohona.bank_change_ok', 'on', true);
    update procurement.supplier set bank_account_masked = c.new_masked where id = c.supplier_id;
    perform set_config('mohona.bank_change_ok', '', true);
  end if;
  return jsonb_build_object('change_id', c.id, 'status', case when p_approve then 'approved' else 'rejected' end);
end $$;

-- ================================================================ B machine service schedule
create table mfg.machine_service_plan (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  machine_id    uuid not null,
  task_bn       text not null check (length(btrim(task_bn)) > 0),
  interval_days integer not null check (interval_days between 1 and 730),
  last_done_on  date,
  status        text not null default 'active' check (status in ('active','retired')),
  unique (machine_id, task_bn),
  foreign key (machine_id, company_id) references mfg.machine (id, company_id)
);
create trigger trg_machine_service_plan_nodel before delete on mfg.machine_service_plan for each row execute function core.fn_deny_delete();
create trigger trg_machine_service_plan_audit after insert or update on mfg.machine_service_plan for each row execute function audit.fn_row_change();
select core.fn_apply_rls('mfg', 'machine_service_plan');

create function api.v1_machine_service_plan_set(p_machine_code text, p_task_bn text, p_interval_days integer, p_last_done_on date, p_status text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; m mfg.machine%rowtype; v uuid;
begin
  select * into me from iam.fn_require('mfg.machine.manage', iam.fn_my_company_resource(), true);
  select * into m from mfg.machine where company_id = me.company_id and code = upper(btrim(p_machine_code));
  if not found then perform core.fn_raise('E_NOT_FOUND', 'machine'); end if;
  if coalesce(p_interval_days, 0) not between 1 and 730 then perform core.fn_raise('E_INVALID_ACTION', 'interval 1–730 days'); end if;
  perform set_config('mohona.change_reason', 'service plan', true);
  insert into mfg.machine_service_plan (company_id, machine_id, task_bn, interval_days, last_done_on, status)
  values (me.company_id, m.id, btrim(p_task_bn), p_interval_days, p_last_done_on, coalesce(p_status, 'active'))
  on conflict (machine_id, task_bn) do update set interval_days = excluded.interval_days, last_done_on = coalesce(excluded.last_done_on, mfg.machine_service_plan.last_done_on),
                                                 status = excluded.status
  returning id into v;
  return jsonb_build_object('plan_id', v);
end $$;

-- Done: logs the preventive maintenance (S57 ledger) and moves the next due date.
create function api.v1_machine_service_done(p_plan_id uuid, p_note text, p_downtime_minutes integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s mfg.machine_service_plan%rowtype; m mfg.machine%rowtype;
begin
  select * into me from iam.fn_require('mfg.machine.manage', iam.fn_my_company_resource(), true);
  select * into s from mfg.machine_service_plan where id = p_plan_id and company_id = me.company_id and status = 'active' for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'service plan'); end if;
  select * into m from mfg.machine where id = s.machine_id;
  perform api.v1_machine_log(m.code, m.name_bn, m.status, 'preventive', s.task_bn, coalesce(nullif(btrim(p_note), ''), s.task_bn), p_downtime_minutes);
  update mfg.machine_service_plan set last_done_on = current_date where id = s.id;
  return jsonb_build_object('plan_id', s.id, 'next_due', current_date + s.interval_days);
end $$;

create function api.v1_machine_services_due(p_within_days integer) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('mfg.machine.manage', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('plan_id', s.id, 'machine', m.code || ' · ' || m.name_bn, 'task', s.task_bn,
             'last_done_on', s.last_done_on, 'next_due', coalesce(s.last_done_on + s.interval_days, current_date),
             'overdue', coalesce(s.last_done_on + s.interval_days, current_date) < current_date) order by coalesce(s.last_done_on + s.interval_days, current_date))
     from mfg.machine_service_plan s join mfg.machine m on m.id = s.machine_id
    where s.company_id = me.company_id and s.status = 'active' and m.status <> 'retired'
      and coalesce(s.last_done_on + s.interval_days, current_date) <= current_date + coalesce(p_within_days, 7)), '[]'::jsonb);
end $$;

-- ================================================================ C production-plan readiness
create function mfg.fn_plan_readiness(p_plan uuid) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare pl mfg.plan%rowtype; v_need jsonb; v_cap integer; v_total numeric;
begin
  select * into pl from mfg.plan where id = p_plan;
  if not found then return null; end if;
  with lines as (
    select (l ->> 'product_id')::uuid product_id, (l ->> 'target_poly')::numeric target from jsonb_array_elements(pl.lines) l
  ), boms as (
    select ln.product_id, ln.target,
           (select b.id from mfg.bom b where b.company_id = pl.company_id and b.product_id = ln.product_id and b.status = 'approved' order by b.version desc limit 1) bom_id
      from lines ln
  ), need as (
    select bl.material_id, sum(bs.target / b.output_qty * bl.qty * (1 + bl.normal_loss_pct / 100)) qty
      from boms bs join mfg.bom b on b.id = bs.bom_id join mfg.bom_line bl on bl.bom_id = b.id group by bl.material_id
  )
  select coalesce(jsonb_agg(jsonb_build_object('material_id', n.material_id, 'material', p.sku || ' · ' || p.name_bn, 'need', round(n.qty, 4),
           'available', round(av.qty, 4), 'short', round(greatest(n.qty - av.qty, 0), 4)) order by p.sku), '[]'::jsonb)
    into v_need
    from need n join inventory.product p on p.id = n.material_id
    cross join lateral (select coalesce(sum(inventory.fn_available(pl.company_id, w.id, n.material_id)), 0) qty
                          from inventory.warehouse w where w.company_id = pl.company_id and w.kind = 'raw_material') av;
  v_cap := config.fn_get_int(pl.company_id, 'mfg.capacity.daily_poly');
  select coalesce(sum((l ->> 'target_poly')::numeric), 0) into v_total from jsonb_array_elements(pl.lines) l;
  return jsonb_build_object('plan_id', pl.id, 'plan_date', pl.plan_date, 'target_poly', v_total,
    'capacity_poly', nullif(v_cap, 0), 'over_capacity', v_cap > 0 and v_total > v_cap,
    'products_without_bom', (select coalesce(jsonb_agg(l ->> 'product_id'), '[]'::jsonb) from jsonb_array_elements(pl.lines) l
                              where not exists (select 1 from mfg.bom b where b.company_id = pl.company_id and b.product_id = (l ->> 'product_id')::uuid and b.status = 'approved')),
    'materials', v_need,
    'ready', not exists (select 1 from jsonb_array_elements(v_need) x where (x ->> 'short')::numeric > 0) and not (v_cap > 0 and v_total > v_cap));
end $$;

create function api.v1_plan_readiness(p_plan_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('mfg.plan.create', iam.fn_my_company_resource(), false);
  if not exists (select 1 from mfg.plan p where p.id = p_plan_id and p.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'plan'); end if;
  return mfg.fn_plan_readiness(p_plan_id);
end $$;

create function mfg.fn_plan_ready_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.status = 'approved' and old.status <> 'approved' and coalesce(config.fn_get_bool(new.company_id, 'mfg.plan.require_material_ready'), false)
     and not (mfg.fn_plan_readiness(new.id) ->> 'ready')::boolean then
    raise exception 'E_MATERIAL_SHORT: the plan needs more material or capacity than available' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_plan_ready_guard before update on mfg.plan for each row execute function mfg.fn_plan_ready_guard();

-- ================================================================ D utility as its own WIP component
alter table mfg.wip_entry drop constraint if exists wip_entry_kind_check;
alter table mfg.wip_entry add constraint wip_entry_kind_check check (kind in ('material','rework_input','labor','utility','overhead','abnormal','scrap','variance','fg'));

create or replace function api.v1_batch_cost(p_batch_id uuid, p_kind text, p_amount numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; b mfg.batch%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.batch.start', iam.fn_my_company_resource(), true);
  select * into b from mfg.batch where id = p_batch_id and company_id = me.company_id;
  if not found or b.status not in ('approved','in_progress') then perform core.fn_raise('E_INVALID_ACTION', 'costs are added while the batch runs'); end if;
  if coalesce(p_kind, '') not in ('labor','utility','overhead') or coalesce(p_amount, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'kind / amount'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into mfg.wip_entry (company_id, batch_id, kind, amount, note, person_id) values (b.company_id, b.id, p_kind, round(p_amount, 4), p_reason, me.person_id);
  return jsonb_build_object('batch_id', b.id, 'wip', mfg.fn_wip(b.id));
end $$;

create or replace function finance.fn_on_wip_entry() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v numeric := abs(new.amount); p uuid; k text;
begin
  if v = 0 or new.kind = 'material' then return null; end if;
  select b.product_id into p from mfg.batch b where b.id = new.batch_id;
  -- utility is absorbed into WIP like overhead (same absorption account); its own kind keeps it visible in batch costing
  k := case new.kind when 'labor' then 'mfg.labor' when 'overhead' then 'mfg.overhead' when 'utility' then 'mfg.overhead' when 'abnormal' then 'mfg.abnormal'
                     when 'scrap' then 'mfg.scrap' when 'variance' then 'mfg.variance' when 'fg' then 'inv.fg' when 'rework_input' then 'inv.fg' end;
  if new.kind in ('labor','utility','overhead','rework_input') then
    perform finance.fn_emit(new.company_id, 'wip:' || new.id, 'WIP ' || new.kind, jsonb_build_array(jsonb_build_object('key', 'mfg.wip', 'dr', v, 'product_id', p),
                                                                                                   jsonb_build_object('key', k, 'cr', v, 'product_id', p)));
  else
    perform finance.fn_emit(new.company_id, 'wip:' || new.id, 'WIP ' || new.kind, jsonb_build_array(jsonb_build_object('key', k, 'dr', v, 'product_id', p),
                                                                                                   jsonb_build_object('key', 'mfg.wip', 'cr', v, 'product_id', p)));
  end if;
  return null;
end $$;

-- ================================================================ E location claims
create table sales.location_claim (
  id                uuid primary key default gen_random_uuid(),
  company_id        uuid not null,
  owner_kind        text not null check (owner_kind in ('dealer','retailer','outlet')),
  owner_id          uuid not null,
  latitude          numeric(9,6) not null check (latitude between 20.5 and 26.8),
  longitude         numeric(9,6) not null check (longitude between 88.0 and 92.8),
  accuracy_m        numeric(8,1) check (accuracy_m is null or accuracy_m >= 0),
  admin_area_code   text references location.admin_area(code),
  address_bn        text,
  provider          text not null check (provider in ('device_gps','google','manual','offline_list')),
  provider_place_id text,
  status            text not null check (status in ('USER_SELECTED','GOOGLE_MATCHED','ADMIN_CROSSCHECKED','APPROVED','REJECTED')),
  evidence          jsonb not null default '[]'::jsonb,           -- [{kind, path, note, by, at}]
  client_request_id text not null,
  created_by        uuid not null references core.person(id),
  created_at        timestamptz not null default clock_timestamp(),
  crosschecked_by   uuid references core.person(id),
  decided_by        uuid references core.person(id),
  decided_at        timestamptz,
  decision_note     text,
  unique (id, company_id), unique (company_id, client_request_id),
  check (decided_by is null or decided_by <> created_by)
);
create trigger trg_location_claim_nodel before delete on sales.location_claim for each row execute function core.fn_deny_delete();
create trigger trg_location_claim_audit after insert or update on sales.location_claim for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'location_claim');

-- ================================================================ G dealer outlets (before claims use them)
create table sales.dealer_outlet (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  dealer_id       uuid not null,
  code            text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn         text not null check (length(btrim(name_bn)) > 0),
  address_bn      text,
  admin_area_code text references location.admin_area(code),
  latitude        numeric(9,6), longitude numeric(9,6),
  status          text not null default 'active' check (status in ('active','inactive')),
  unique (id, company_id), unique (dealer_id, code),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_dealer_outlet_nodel before delete on sales.dealer_outlet for each row execute function core.fn_deny_delete();
create trigger trg_dealer_outlet_audit after insert or update on sales.dealer_outlet for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'dealer_outlet');
alter table sales.dealer_order_request add column outlet_id uuid references sales.dealer_outlet(id), add column offer_id uuid references sales.dealer_notice(id);
alter table sales.sales_order add column outlet_id uuid references sales.dealer_outlet(id);

create function api.v1_dealer_outlet_save(p_dealer_id uuid, p_outlet_id uuid, p_code text, p_name_bn text, p_address_bn text, p_admin_area_code text, p_status text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v uuid;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  perform set_config('mohona.change_reason', 'dealer outlet', true);
  if p_outlet_id is null then
    insert into sales.dealer_outlet (company_id, dealer_id, code, name_bn, address_bn, admin_area_code)
    values (d.company_id, d.id, upper(btrim(p_code)), btrim(p_name_bn), p_address_bn, p_admin_area_code) returning id into v;
  else
    update sales.dealer_outlet set name_bn = coalesce(nullif(btrim(p_name_bn), ''), name_bn), address_bn = coalesce(p_address_bn, address_bn),
           admin_area_code = coalesce(p_admin_area_code, admin_area_code), status = coalesce(p_status, status)
     where id = p_outlet_id and dealer_id = d.id returning id into v;
    if v is null then perform core.fn_raise('E_NOT_FOUND', 'outlet'); end if;
  end if;
  return jsonb_build_object('outlet_id', v);
end $$;

create function sales.fn_claim_dealer(p_kind text, p_owner uuid) returns uuid
language sql stable security definer set search_path = pg_catalog as $$
  select case p_kind when 'dealer' then p_owner
                     when 'retailer' then (select r.dealer_id from sales.retailer r where r.id = p_owner)
                     when 'outlet' then (select o.dealer_id from sales.dealer_outlet o where o.id = p_owner) end
$$;

-- E (continued) submit: staff with crm.dealer.manage on the dealer, or the dealer's own portal user
create function api.v1_location_claim_submit(p_owner_kind text, p_owner_id uuid, p_latitude numeric, p_longitude numeric, p_accuracy_m numeric,
                                             p_admin_area_code text, p_address_bn text, p_provider text, p_place_id text, p_evidence_path text, p_client_request_id text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_dealer uuid; d sales.dealer%rowtype; v uuid; v_portal boolean := false;
begin
  if coalesce(p_owner_kind, '') not in ('dealer','retailer','outlet') then perform core.fn_raise('E_INVALID_ACTION', 'owner kind'); end if;
  v_dealer := sales.fn_claim_dealer(p_owner_kind, p_owner_id);
  select * into d from sales.dealer where id = v_dealer and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'owner'); end if;
  select a.allowed into v_portal from iam.fn_authorize('dealer.portal.read', iam.fn_resource(d.company_id, null, null, null, null, iam.fn_current_person()), false) a;
  if coalesce(v_portal, false) then
    if sales.fn_my_dealer('dealer.portal.read') <> d.id then perform core.fn_raise('E_FORBIDDEN', 'own dealer only'); end if;
    select * into me from iam.fn_context(true);
  else
    select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  end if;
  if coalesce(p_provider, '') not in ('device_gps','google','manual','offline_list') then perform core.fn_raise('E_INVALID_ACTION', 'provider'); end if;
  if p_latitude is null or p_longitude is null or p_latitude not between 20.5 and 26.8 or p_longitude not between 88.0 and 92.8 then perform core.fn_raise('E_INVALID_ACTION', 'coordinates in Bangladesh'); end if;
  if coalesce(p_client_request_id, '') !~ '^[A-Za-z0-9_-]{8,80}$' then perform core.fn_raise('E_INVALID_ACTION', 'request key'); end if;
  select c.id into v from sales.location_claim c where c.company_id = d.company_id and c.client_request_id = p_client_request_id;
  if v is not null then return jsonb_build_object('claim_id', v, 'duplicate', true); end if;
  perform set_config('mohona.change_reason', 'location claim', true);
  insert into sales.location_claim (company_id, owner_kind, owner_id, latitude, longitude, accuracy_m, admin_area_code, address_bn, provider, provider_place_id,
                                    status, evidence, client_request_id, created_by)
  values (d.company_id, p_owner_kind, p_owner_id, round(p_latitude, 6), round(p_longitude, 6), p_accuracy_m, p_admin_area_code, nullif(btrim(p_address_bn), ''), p_provider,
          nullif(btrim(p_place_id), ''),
          -- a Google match is only a candidate: never approved by itself
          case when p_provider = 'google' and nullif(btrim(p_place_id), '') is not null then 'GOOGLE_MATCHED' else 'USER_SELECTED' end,
          case when p_evidence_path is null then '[]'::jsonb else jsonb_build_array(jsonb_build_object('kind', 'photo', 'path', p_evidence_path, 'by', me.person_id, 'at', clock_timestamp())) end,
          p_client_request_id, me.person_id)
  returning id into v;
  return jsonb_build_object('claim_id', v, 'status', (select status from sales.location_claim where id = v));
end $$;

-- crosscheck (admin compares with the BD list / visit evidence) | approve (independent person; updates the owner's pin) | reject
create function api.v1_location_claim_review(p_claim_id uuid, p_action text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c sales.location_claim%rowtype; d sales.dealer%rowtype;
begin
  select * into c from sales.location_claim where id = p_claim_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'claim'); end if;
  select * into d from sales.dealer where id = sales.fn_claim_dealer(c.owner_kind, c.owner_id);
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_note), ''), 'location ' || p_action), true);
  if p_action = 'crosscheck' and c.status in ('USER_SELECTED','GOOGLE_MATCHED') then
    if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'what was compared'); end if;
    update sales.location_claim set status = 'ADMIN_CROSSCHECKED', crosschecked_by = me.person_id,
           evidence = evidence || jsonb_build_array(jsonb_build_object('kind', 'crosscheck', 'note', btrim(p_note), 'by', me.person_id, 'at', clock_timestamp())) where id = c.id;
  elsif p_action = 'approve' and c.status = 'ADMIN_CROSSCHECKED' then
    if c.created_by = me.person_id or c.crosschecked_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'an independent reviewer approves'); end if;
    update sales.location_claim set status = 'APPROVED', decided_by = me.person_id, decided_at = clock_timestamp(), decision_note = p_note where id = c.id;
    if c.owner_kind = 'dealer' then
      update sales.dealer set latitude = c.latitude, longitude = c.longitude, admin_area_code = coalesce(c.admin_area_code, admin_area_code),
             address_bn = coalesce(c.address_bn, address_bn) where id = c.owner_id;
    elsif c.owner_kind = 'retailer' then
      update sales.retailer set latitude = c.latitude, longitude = c.longitude where id = c.owner_id;
    else
      update sales.dealer_outlet set latitude = c.latitude, longitude = c.longitude, admin_area_code = coalesce(c.admin_area_code, admin_area_code) where id = c.owner_id;
    end if;
  elsif p_action = 'reject' and c.status not in ('APPROVED','REJECTED') then
    if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
    if c.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
    update sales.location_claim set status = 'REJECTED', decided_by = me.person_id, decided_at = clock_timestamp(), decision_note = btrim(p_note) where id = c.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_action || ' from ' || c.status);
  end if;
  return jsonb_build_object('claim_id', c.id, 'status', (select status from sales.location_claim where id = c.id));
end $$;

create function api.v1_location_claims(p_status text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('crm.dealer.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('claim_id', c.id, 'owner_kind', c.owner_kind, 'owner_id', c.owner_id, 'status', c.status, 'provider', c.provider,
                                   'lat', c.latitude, 'lon', c.longitude, 'accuracy_m', c.accuracy_m, 'address', c.address_bn, 'evidence', jsonb_array_length(c.evidence),
                                   'at', c.created_at,
                                   'label_bn', case c.status when 'USER_SELECTED' then 'ব্যবহারকারীর বাছাই (যাচাই হয়নি)' when 'GOOGLE_MATCHED' then 'Google-এ মিলেছে (যাচাই হয়নি)'
                                                             when 'ADMIN_CROSSCHECKED' then 'অফিসে মিলিয়ে দেখা' when 'APPROVED' then 'অনুমোদিত' else 'বাতিল' end)
                                   order by c.created_at desc)
     from sales.location_claim c where c.company_id = me.company_id and (p_status is null or c.status = p_status)), '[]'::jsonb);
end $$;

-- ================================================================ F market merge / split
alter table sales.market add column merged_into uuid references sales.market(id), add column parent_market_id uuid references sales.market(id);

create function api.v1_market_merge(p_from_market uuid, p_into_market uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; f sales.market%rowtype; t sales.market%rowtype; n_end integer; n_rej integer;
begin
  select * into me from iam.fn_require('crm.market.approve', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into f from sales.market where id = p_from_market and company_id = me.company_id for update;
  select * into t from sales.market where id = p_into_market and company_id = me.company_id for update;
  if f.id is null or t.id is null or f.id = t.id or f.status <> 'active' or t.status <> 'active' then perform core.fn_raise('E_INVALID_ACTION', 'two different active markets'); end if;
  perform set_config('mohona.change_reason', 'merge: ' || p_reason, true);
  update sales.market_assignment set status = 'ended', valid_to = greatest(valid_from, current_date)
   where market_id = f.id and status in ('approved','suspended') and (valid_to is null or valid_to >= current_date);
  get diagnostics n_end = row_count;
  update sales.market_assignment set status = 'rejected', decided_at = clock_timestamp(), decided_by = me.person_id
   where market_id = f.id and status = 'requested' and requested_by <> me.person_id;
  get diagnostics n_rej = row_count;
  update sales.market set status = 'inactive', merged_into = t.id where id = f.id;
  return jsonb_build_object('merged', f.code, 'into', t.code, 'assignments_ended', n_end, 'requests_closed', n_rej,
                            'note_bn', 'আগের ইনভয়েস ও খাতা বদলায় না; নতুন বাজারে ডিলার-নিয়োগ আলাদা অনুরোধে।');
end $$;

create function api.v1_market_split(p_market_id uuid, p_new_code text, p_new_name_bn text, p_boundary jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; m sales.market%rowtype; v uuid; v_err text;
begin
  select * into me from iam.fn_require('crm.market.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into m from sales.market where id = p_market_id and company_id = me.company_id and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'active market'); end if;
  if p_boundary is not null then
    v_err := location.fn_ring_valid(p_boundary);
    if v_err is not null then perform core.fn_raise('E_INVALID_ACTION', 'boundary: ' || v_err); end if;
  end if;
  perform set_config('mohona.change_reason', 'split: ' || p_reason, true);
  insert into sales.market (company_id, code, name_bn, territory_id, admin_area_code, boundary, boundary_version, parent_market_id)
  values (me.company_id, upper(btrim(p_new_code)), btrim(p_new_name_bn), m.territory_id, m.admin_area_code, p_boundary, case when p_boundary is null then 0 else 1 end, m.id)
  returning id into v;
  if p_boundary is not null then
    insert into sales.market_boundary_version (company_id, market_id, version, boundary, reason, set_by) values (me.company_id, v, 1, p_boundary, 'split from ' || m.code, me.person_id);
  end if;
  return jsonb_build_object('market_id', v, 'parent', m.code, 'note_bn', 'নতুন বাজারে ডিলার-নিয়োগ আলাদা অনুরোধ ও অনুমোদনে।');
end $$;

-- ================================================================ H dealer self-service
alter table sales.dealer_user add column prefs jsonb not null default '{"notices": true, "offers": true, "payments": true}'::jsonb,
                              add column terms_version text, add column terms_accepted_at timestamptz;

create table sales.dealer_change_request (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  dealer_id    uuid not null,
  payload      jsonb not null,                           -- {phone?, address_bn?, admin_area_code?}
  note         text,
  status       text not null default 'pending' check (status in ('pending','approved','rejected')),
  requested_by uuid not null references core.person(id),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  reason       text,
  created_at   timestamptz not null default clock_timestamp(),
  check (decided_by is null or decided_by <> requested_by),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_dealer_change_request_nodel before delete on sales.dealer_change_request for each row execute function core.fn_deny_delete();
create trigger trg_dealer_change_request_audit after insert or update on sales.dealer_change_request for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'dealer_change_request');

create function api.v1_dealer_contact_change_request(p_phone text, p_address_bn text, p_admin_area_code text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; me record; v uuid; p jsonb := '{}'::jsonb;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into me from iam.fn_context(true);
  if p_phone is not null then
    if core.fn_phone_canonical(p_phone) is null then perform core.fn_raise('E_CONTACT_REQUIRED'); end if;
    p := p || jsonb_build_object('phone', core.fn_phone_canonical(p_phone));
  end if;
  if nullif(btrim(p_address_bn), '') is not null then p := p || jsonb_build_object('address_bn', btrim(p_address_bn)); end if;
  if p_admin_area_code is not null then
    if not exists (select 1 from location.admin_area a where a.code = p_admin_area_code) then perform core.fn_raise('E_NOT_FOUND', 'admin area'); end if;
    p := p || jsonb_build_object('admin_area_code', p_admin_area_code);
  end if;
  if p = '{}'::jsonb then perform core.fn_raise('E_INVALID_ACTION', 'nothing to change'); end if;
  if exists (select 1 from sales.dealer_change_request r where r.dealer_id = v_d and r.status = 'pending') then perform core.fn_raise('E_DUPLICATE', 'a change is already waiting'); end if;
  perform set_config('mohona.change_reason', 'dealer contact change', true);
  insert into sales.dealer_change_request (company_id, dealer_id, payload, note, requested_by) values (me.company_id, v_d, p, p_note, me.person_id) returning id into v;
  return jsonb_build_object('request_id', v, 'status', 'pending');
end $$;

create function api.v1_dealer_change_decide(p_request_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.dealer_change_request%rowtype; d sales.dealer%rowtype;
begin
  select * into r from sales.dealer_change_request where id = p_request_id and company_id = iam.fn_context_company() for update;
  if not found or r.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending request'); end if;
  select * into d from sales.dealer where id = r.dealer_id;
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  if r.requested_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  if not coalesce(p_approve, false) and length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'dealer contact change approved'), true);
  update sales.dealer_change_request set status = case when p_approve then 'approved' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp(), reason = p_reason
   where id = r.id;
  if p_approve then
    update sales.dealer set phone = coalesce(r.payload ->> 'phone', phone), address_bn = coalesce(r.payload ->> 'address_bn', address_bn),
           admin_area_code = coalesce(r.payload ->> 'admin_area_code', admin_area_code) where id = d.id;
  end if;
  return jsonb_build_object('request_id', r.id, 'status', case when p_approve then 'approved' else 'rejected' end);
end $$;

create function api.v1_dealer_portal_prefs(p_prefs jsonb, p_accept_terms_version text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; me record; k text;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into me from iam.fn_context(true);
  if p_prefs is not null then
    if jsonb_typeof(p_prefs) <> 'object' then perform core.fn_raise('E_INVALID_ACTION', 'prefs'); end if;
    for k in select jsonb_object_keys(p_prefs) loop
      if k not in ('notices','offers','payments') or jsonb_typeof(p_prefs -> k) <> 'boolean' then perform core.fn_raise('E_INVALID_ACTION', 'prefs: notices / offers / payments true|false'); end if;
    end loop;
  end if;
  perform set_config('mohona.change_reason', 'dealer preferences', true);
  update sales.dealer_user set prefs = prefs || coalesce(p_prefs, '{}'::jsonb),
         terms_version = coalesce(nullif(btrim(p_accept_terms_version), ''), terms_version),
         terms_accepted_at = case when nullif(btrim(p_accept_terms_version), '') is not null then clock_timestamp() else terms_accepted_at end
   where company_id = me.company_id and person_id = me.person_id and dealer_id = v_d and status = 'active';
  return (select jsonb_build_object('prefs', u.prefs, 'terms_version', u.terms_version, 'terms_accepted_at', u.terms_accepted_at)
            from sales.dealer_user u where u.company_id = me.company_id and u.person_id = me.person_id and u.status = 'active');
end $$;

-- Own data, read-only, as one JSON (the dealer saves / shares it from the app).
create function api.v1_dealer_my_data() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare v_d uuid; d sales.dealer%rowtype;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into d from sales.dealer where id = v_d;
  return jsonb_build_object('exported_at', clock_timestamp(),
    'profile', jsonb_build_object('code', d.code, 'name_bn', d.name_bn, 'owner', d.owner_name_bn, 'phone', d.phone, 'address_bn', d.address_bn, 'credit_limit', d.credit_limit,
                                  'credit_days', d.credit_days, 'status', d.status),
    'outlets', coalesce((select jsonb_agg(jsonb_build_object('code', o.code, 'name_bn', o.name_bn, 'address_bn', o.address_bn, 'status', o.status)) from sales.dealer_outlet o where o.dealer_id = d.id), '[]'::jsonb),
    'orders', coalesce((select jsonb_agg(jsonb_build_object('number', o.number, 'total', o.total, 'status', o.status, 'at', o.created_at) order by o.created_at) from sales.sales_order o where o.dealer_id = d.id), '[]'::jsonb),
    'invoices', coalesce((select jsonb_agg(jsonb_build_object('number', i.number, 'date', i.invoice_date, 'total', i.total, 'open', sales.fn_invoice_open(i.id)) order by i.invoice_date) from sales.invoice i where i.dealer_id = d.id), '[]'::jsonb),
    'payments', coalesce((select jsonb_agg(jsonb_build_object('number', c.number, 'amount', c.amount, 'method', c.method, 'status', c.status, 'at', c.collected_at) order by c.collected_at) from sales.collection c where c.dealer_id = d.id), '[]'::jsonb),
    'ledger', coalesce((select jsonb_agg(jsonb_build_object('date', l.entry_date, 'kind', l.kind, 'amount', l.amount, 'memo', l.memo) order by l.entry_date, l.id) from sales.dealer_ledger l where l.dealer_id = d.id), '[]'::jsonb),
    'balance', sales.fn_dealer_balance(d.id));
end $$;

-- Offboarding: only with nothing open; ends app users and market assignments; history stays.
create function api.v1_dealer_offboard(p_dealer_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; n_u integer; n_m integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company() for update;
  if not found or d.status = 'closed' then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  if sales.fn_dealer_balance(d.id) <> 0 then perform core.fn_raise('E_INVALID_ACTION', 'balance must be zero before offboarding'); end if;
  if exists (select 1 from sales.sales_order o where o.dealer_id = d.id and o.status in ('pending_approval','approved','allocated','dispatched')) then
    perform core.fn_raise('E_INVALID_ACTION', 'open orders exist');
  end if;
  perform set_config('mohona.change_reason', 'offboard: ' || p_reason, true);
  update sales.dealer_order_request set status = 'cancelled', decided_at = clock_timestamp(), reason = 'dealer offboarded' where dealer_id = d.id and status = 'submitted';
  update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = 'dealer offboarded'
   where id in (select u.assignment_id from sales.dealer_user u where u.dealer_id = d.id and u.status <> 'ended') and status <> 'ended';
  update sales.dealer_user set status = 'ended' where dealer_id = d.id and status <> 'ended';
  get diagnostics n_u = row_count;
  update sales.market_assignment set status = 'ended', valid_to = greatest(valid_from, current_date)
   where dealer_id = d.id and status in ('approved','suspended') and (valid_to is null or valid_to >= current_date);
  get diagnostics n_m = row_count;
  update sales.dealer set status = 'closed', suspended_reason = btrim(p_reason) where id = d.id;
  return jsonb_build_object('dealer_id', d.id, 'status', 'closed', 'app_users_ended', n_u, 'markets_ended', n_m);
end $$;

-- ================================================================ I disputes
create table sales.dispute (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  dealer_id    uuid not null,
  subject_type text not null check (subject_type in ('ledger_entry','payment','invoice','order','delivery','visit','other')),
  subject_ref  text,
  text_bn      text not null check (length(btrim(text_bn)) > 0),
  status       text not null default 'open' check (status in ('open','resolved','rejected')),
  raised_by    uuid not null references core.person(id),
  raised_via   text not null check (raised_via in ('dealer_app','staff')),
  resolved_by  uuid references core.person(id),
  resolved_at  timestamptz,
  resolution_bn text,
  created_at   timestamptz not null default clock_timestamp(),
  check (resolved_by is null or resolved_by <> raised_by),
  check (status = 'open' or length(btrim(coalesce(resolution_bn, ''))) > 0),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create function sales.fn_dispute_once() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status <> 'open' or (to_jsonb(new) - array['status','resolved_by','resolved_at','resolution_bn']) <> (to_jsonb(old) - array['status','resolved_by','resolved_at','resolution_bn']) then
    raise exception 'E_IMMUTABLE: a dispute is decided once; its facts never change' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dispute_once before update on sales.dispute for each row execute function sales.fn_dispute_once();
create trigger trg_dispute_nodel before delete on sales.dispute for each row execute function core.fn_deny_delete();
create trigger trg_dispute_audit after insert or update on sales.dispute for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'dispute');

create function api.v1_dealer_dispute_raise(p_subject_type text, p_subject_ref text, p_text_bn text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; me record; v uuid;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into me from iam.fn_context(true);
  if coalesce(p_subject_type, '') not in ('ledger_entry','payment','invoice','order','delivery','visit','other') then perform core.fn_raise('E_INVALID_ACTION', 'subject'); end if;
  perform set_config('mohona.change_reason', 'dispute raised by dealer', true);
  insert into sales.dispute (company_id, dealer_id, subject_type, subject_ref, text_bn, raised_by, raised_via)
  values (me.company_id, v_d, p_subject_type, nullif(btrim(p_subject_ref), ''), btrim(p_text_bn), me.person_id, 'dealer_app') returning id into v;
  return jsonb_build_object('dispute_id', v, 'status', 'open');
end $$;

create function api.v1_dispute_raise(p_dealer_id uuid, p_subject_type text, p_subject_ref text, p_text_bn text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v uuid;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), true);
  if coalesce(p_subject_type, '') not in ('ledger_entry','payment','invoice','order','delivery','visit','other') then perform core.fn_raise('E_INVALID_ACTION', 'subject'); end if;
  perform set_config('mohona.change_reason', 'dispute raised', true);
  insert into sales.dispute (company_id, dealer_id, subject_type, subject_ref, text_bn, raised_by, raised_via)
  values (d.company_id, d.id, p_subject_type, nullif(btrim(p_subject_ref), ''), btrim(p_text_bn), me.person_id, 'staff') returning id into v;
  return jsonb_build_object('dispute_id', v, 'status', 'open');
end $$;

-- Decided by another person; a money correction is a separate approved adjustment / reversal (posted entries never change).
create function api.v1_dispute_resolve(p_dispute_id uuid, p_accept boolean, p_resolution_bn text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; x sales.dispute%rowtype; d sales.dealer%rowtype;
begin
  select * into x from sales.dispute where id = p_dispute_id and company_id = iam.fn_context_company() for update;
  if not found or x.status <> 'open' then perform core.fn_raise('E_NOT_FOUND', 'open dispute'); end if;
  select * into d from sales.dealer where id = x.dealer_id;
  select * into me from iam.fn_require('crm.dealer.manage', sales.fn_dealer_resource(d), true);
  if x.raised_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  if length(btrim(coalesce(p_resolution_bn, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', 'dispute decided', true);
  update sales.dispute set status = case when p_accept then 'resolved' else 'rejected' end, resolved_by = me.person_id, resolved_at = clock_timestamp(),
         resolution_bn = btrim(p_resolution_bn) where id = x.id;
  return jsonb_build_object('dispute_id', x.id, 'status', case when p_accept then 'resolved' else 'rejected' end);
end $$;

create function api.v1_disputes(p_status text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_d uuid; v_portal boolean;
begin
  select a.allowed into v_portal from iam.fn_authorize('dealer.portal.read', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person()), false) a;
  if coalesce(v_portal, false) then v_d := sales.fn_my_dealer('dealer.portal.read'); select * into me from iam.fn_context(false);
  else select * into me from iam.fn_require('crm.dealer.read', iam.fn_my_company_resource(), false); end if;
  return coalesce((select jsonb_agg(jsonb_build_object('dispute_id', x.id, 'dealer', dd.code || ' · ' || dd.name_bn, 'subject', x.subject_type, 'ref', x.subject_ref, 'text', x.text_bn,
                                   'status', x.status, 'resolution', x.resolution_bn, 'via', x.raised_via, 'at', x.created_at) order by x.created_at desc)
     from sales.dispute x join sales.dealer dd on dd.id = x.dealer_id
    where x.company_id = me.company_id and (v_d is null or x.dealer_id = v_d) and (p_status is null or x.status = p_status)), '[]'::jsonb);
end $$;

-- ================================================================ J aging + overdue hold
create function sales.fn_dealer_aging(p_dealer uuid) returns jsonb
language sql stable security definer set search_path = pg_catalog as $$
  select jsonb_build_object(
    'not_due',  coalesce(sum(o) filter (where due_date >= current_date), 0),
    'd1_30',    coalesce(sum(o) filter (where current_date - due_date between 1 and 30), 0),
    'd31_60',   coalesce(sum(o) filter (where current_date - due_date between 31 and 60), 0),
    'd61_90',   coalesce(sum(o) filter (where current_date - due_date between 61 and 90), 0),
    'd90_plus', coalesce(sum(o) filter (where current_date - due_date > 90), 0),
    'total',    coalesce(sum(o), 0),
    'oldest_overdue_days', coalesce(max(current_date - due_date) filter (where due_date < current_date), 0))
  from (select i.due_date, sales.fn_invoice_open(i.id) o from sales.invoice i where i.dealer_id = p_dealer) x where o > 0
$$;

create function api.v1_dealer_aging(p_dealer_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('crm.dealer.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('dealer_id', d.id, 'dealer', d.code || ' · ' || d.name_bn) || sales.fn_dealer_aging(d.id) order by d.code)
     from sales.dealer d where d.company_id = me.company_id and (p_dealer_id is null or d.id = p_dealer_id)
      and (p_dealer_id is not null or (sales.fn_dealer_aging(d.id) ->> 'total')::numeric > 0)), '[]'::jsonb);
end $$;

create function api.v1_dealer_my_aging() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
begin
  return sales.fn_dealer_aging(sales.fn_my_dealer('dealer.portal.read'));
end $$;

-- credit check gains the optional overdue rule (S41 body + overdue)
create or replace function sales.fn_credit_check(p_dealer uuid, p_new_amount numeric, p_open_orders numeric default 0) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare d sales.dealer%rowtype; v_bal numeric; v_ex numeric; v_avail numeric; v_days integer; v_old integer;
begin
  select * into d from sales.dealer where id = p_dealer;
  if d.id is null then return jsonb_build_object('allowed', false, 'reason', 'unknown dealer'); end if;
  if d.status <> 'active' then return jsonb_build_object('allowed', false, 'reason', 'dealer ' || d.status); end if;
  v_bal := sales.fn_dealer_balance(d.id);
  v_ex := coalesce((select sum(e.amount) from sales.credit_exception e where e.dealer_id = d.id and e.status = 'posted' and e.valid_until >= current_date), 0);
  v_avail := d.credit_limit + v_ex - v_bal - coalesce(p_open_orders, 0);
  v_days := coalesce(config.fn_get_int(d.company_id, 'sales.order.overdue_hold_days'), 0);
  v_old := (sales.fn_dealer_aging(d.id) ->> 'oldest_overdue_days')::integer;
  if v_days > 0 and v_old > v_days then
    return jsonb_build_object('allowed', false, 'available', v_avail, 'balance', v_bal, 'limit', d.credit_limit, 'exceptions', v_ex,
                              'overdue_days', v_old, 'reason', 'overdue beyond ' || v_days || ' days');
  end if;
  return jsonb_build_object('allowed', coalesce(p_new_amount, 0) <= v_avail, 'available', v_avail, 'balance', v_bal, 'limit', d.credit_limit, 'exceptions', v_ex,
                            'overdue_days', v_old, 'reason', case when coalesce(p_new_amount, 0) > v_avail then 'credit limit exceeded' end);
end $$;

-- ================================================================ K manual hold / release + stale orders
create function api.v1_order_hold(p_order_id uuid, p_hold boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('sales.order.approve', iam.fn_my_company_resource(), true);
  select * into o from sales.sales_order where id = p_order_id and company_id = me.company_id for update;
  if not found or o.status not in ('pending_approval','approved','allocated') then perform core.fn_raise('E_INVALID_ACTION', 'only an order not yet dispatched'); end if;
  perform set_config('mohona.change_reason', case when p_hold then 'hold: ' else 'release: ' end || p_reason, true);
  update sales.sales_order set hold_reasons = case when p_hold then (select array_agg(distinct x) from unnest(hold_reasons || array['manual']) x)
                                                   else array_remove(hold_reasons, 'manual') end where id = o.id;
  return jsonb_build_object('order_id', o.id, 'on_hold', p_hold);
end $$;

create function sales.fn_dispatch_hold_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if exists (select 1 from sales.sales_order o where o.id = new.order_id and 'manual' = any (o.hold_reasons)) then
    raise exception 'E_ORDER_ON_HOLD: this order is on hold; release it before dispatch' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dispatch_hold_guard before insert on sales.dispatch for each row execute function sales.fn_dispatch_hold_guard();

create function api.v1_orders_stale() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; n integer;
begin
  select * into me from iam.fn_require('sales.order.approve', iam.fn_my_company_resource(), false);
  n := coalesce(config.fn_get_int(me.company_id, 'sales.order.stale_days'), 7);
  return coalesce((select jsonb_agg(jsonb_build_object('order_id', o.id, 'number', o.number, 'dealer', d.code || ' · ' || d.name_bn, 'status', o.status,
                                   'age_days', current_date - o.created_at::date, 'on_hold', 'manual' = any (o.hold_reasons)) order by o.created_at)
     from sales.sales_order o join sales.dealer d on d.id = o.dealer_id
    where o.company_id = me.company_id and o.status in ('approved','allocated') and o.created_at < clock_timestamp() - make_interval(days => n)), '[]'::jsonb);
end $$;

-- ================================================================ L notice by market + offer redemption
create or replace function sales.fn_notice_targets(n sales.dealer_notice, p_dealer uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((n.segment ->> 'all')::boolean, false)
      or (n.segment ? 'dealer_ids' and n.segment -> 'dealer_ids' ? p_dealer::text)
      or (n.segment ? 'territory_ids' and n.segment -> 'territory_ids' ? (select d.territory_id::text from sales.dealer d where d.id = p_dealer))
      or (n.segment ? 'market_ids' and exists (select 1 from sales.market_assignment a where a.dealer_id = p_dealer and a.status = 'approved'
                                                and a.valid_from <= current_date and (a.valid_to is null or a.valid_to >= current_date)
                                                and n.segment -> 'market_ids' ? a.market_id::text))
$$;

-- the dealer links an open request to an outlet and / or a published offer meant for them
create function api.v1_dealer_order_request_link(p_order_request_id uuid, p_outlet_id uuid, p_offer_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; r sales.dealer_order_request%rowtype; nt sales.dealer_notice%rowtype;
begin
  v_d := sales.fn_my_dealer('dealer.portal.order');
  select * into r from sales.dealer_order_request where id = p_order_request_id and dealer_id = v_d for update;
  if not found or r.status <> 'submitted' then perform core.fn_raise('E_NOT_FOUND', 'open request'); end if;
  if p_outlet_id is not null and not exists (select 1 from sales.dealer_outlet o where o.id = p_outlet_id and o.dealer_id = v_d and o.status = 'active') then
    perform core.fn_raise('E_NOT_FOUND', 'outlet');
  end if;
  if p_offer_id is not null then
    select * into nt from sales.dealer_notice where id = p_offer_id and company_id = r.company_id;
    if not found or nt.kind <> 'offer' or nt.status <> 'published' or current_date not between nt.valid_from and nt.valid_to or not sales.fn_notice_targets(nt, v_d) then
      perform core.fn_raise('E_NOT_FOUND', 'offer for this dealer');
    end if;
  end if;
  perform set_config('mohona.change_reason', 'request linked', true);
  perform set_config('mohona.request_link_ok', 'on', true);
  update sales.dealer_order_request set outlet_id = coalesce(p_outlet_id, outlet_id), offer_id = coalesce(p_offer_id, offer_id) where id = r.id;
  perform set_config('mohona.request_link_ok', '', true);
  return jsonb_build_object('order_request_id', r.id, 'outlet_id', coalesce(p_outlet_id, r.outlet_id), 'offer_id', coalesce(p_offer_id, r.offer_id));
end $$;

-- the S66 guard allowed only decisions; linking an outlet / offer while still submitted is allowed too (lines never change)
create or replace function sales.fn_dealer_request_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status <> 'submitted' or new.lines is distinct from old.lines or new.dealer_id <> old.dealer_id then
    raise exception 'E_IMMUTABLE: an order request is decided once and its lines never change' using errcode = 'P0001';
  end if;
  return new;
end $$;

-- accepted request: the order carries the outlet
create function sales.fn_request_to_order_outlet() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  if new.status = 'accepted' and new.order_id is not null and new.outlet_id is not null then
    update sales.sales_order set outlet_id = new.outlet_id where id = new.order_id;
  end if;
  return null;
end $$;
create trigger trg_request_to_order_outlet after update on sales.dealer_order_request for each row execute function sales.fn_request_to_order_outlet();

create function api.v1_offer_redemptions(p_notice_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('dealer.notice.manage', iam.fn_my_company_resource(), false);
  return (select jsonb_build_object('notice_id', p_notice_id, 'requests', count(*), 'accepted', count(*) filter (where r.status = 'accepted'),
            'order_value', coalesce(sum(o.total), 0))
            from sales.dealer_order_request r left join sales.sales_order o on o.id = r.order_id
           where r.company_id = me.company_id and r.offer_id = p_notice_id);
end $$;

-- ================================================================ M visit check-out
alter table sales.dealer_visit add column checked_out_at timestamptz;
create function api.v1_visit_check_out(p_visit_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype;
begin
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'visit'); end if;
  select * into me from iam.fn_require('crm.visit.record',
           case when v.dealer_id is not null then sales.fn_dealer_resource((select d from sales.dealer d where d.id = v.dealer_id))
                else iam.fn_resource(v.company_id, null, null, null, null, v.officer_id, v.officer_id) end, true);
  if v.checked_in_at is null or v.checked_out_at is not null then perform core.fn_raise('E_INVALID_ACTION', 'check in first; check out once'); end if;
  perform set_config('mohona.change_reason', 'visit check-out', true);
  update sales.dealer_visit set checked_out_at = clock_timestamp() where id = v.id;
  return jsonb_build_object('visit_id', v.id, 'minutes', round(extract(epoch from clock_timestamp() - v.checked_in_at) / 60));
end $$;

-- ================================================================ N per-product dealer visibility
alter table inventory.product add column dealer_visible boolean not null default true;
create function api.v1_product_dealer_visibility(p_product_id uuid, p_visible boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  update inventory.product set dealer_visible = coalesce(p_visible, true) where id = p_product_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  return jsonb_build_object('product_id', p_product_id, 'dealer_visible', coalesce(p_visible, true));
end $$;


-- N (continued): the dealer sees and requests only products marked visible to dealers
create or replace function api.v1_dealer_home() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare v_d uuid; d sales.dealer%rowtype; cc jsonb;
begin
  v_d := sales.fn_my_dealer('dealer.portal.read');
  select * into d from sales.dealer where id = v_d;
  cc := sales.fn_credit_check(d.id, 0, sales.fn_open_orders(d.id));
  return jsonb_build_object('dealer', d.code || ' · ' || d.name_bn, 'aging', sales.fn_dealer_aging(d.id),
    'open_disputes', (select count(*) from sales.dispute x where x.dealer_id = d.id and x.status = 'open'),
    'outlets', coalesce((select jsonb_agg(jsonb_build_object('outlet_id', o.id, 'name', o.name_bn)) from sales.dealer_outlet o where o.dealer_id = d.id and o.status = 'active'), '[]'::jsonb), 'due', sales.fn_dealer_balance(d.id), 'available_credit', cc -> 'available',
    'recent_orders', coalesce((select jsonb_agg(jsonb_build_object('number', o.number, 'total', o.total, 'status', o.status, 'at', o.created_at) order by o.created_at desc)
                                 from (select * from sales.sales_order o where o.dealer_id = d.id and o.status <> 'split' order by o.created_at desc limit 5) o), '[]'::jsonb),
    'order_requests', coalesce((select jsonb_agg(jsonb_build_object('request_id', r.id, 'status', r.status, 'at', r.created_at) order by r.created_at desc)
                                 from (select * from sales.dealer_order_request r where r.dealer_id = d.id order by r.created_at desc limit 5) r), '[]'::jsonb),
    'dispatches', coalesce((select jsonb_agg(jsonb_build_object('dispatch_id', x.id, 'number', x.number, 'order', o.number, 'vehicle', x.vehicle, 'dispatched_at', x.dispatched_at,
                                                                'delivered_at', x.delivered_at) order by x.dispatched_at desc)
                              from sales.dispatch x join sales.sales_order o on o.id = x.order_id where o.dealer_id = d.id and x.dispatched_at > clock_timestamp() - interval '30 days'), '[]'::jsonb),
    'open_invoices', coalesce((select jsonb_agg(jsonb_build_object('number', i.number, 'date', i.invoice_date, 'due_date', i.due_date, 'open', sales.fn_invoice_open(i.id)) order by i.due_date)
                                 from sales.invoice i where i.dealer_id = d.id and sales.fn_invoice_open(i.id) > 0), '[]'::jsonb),
    'notices', coalesce((select jsonb_agg(jsonb_build_object('notice_id', n.id, 'kind', n.kind, 'title', n.title_bn, 'body', n.body_bn, 'media_path', n.media_path,
                                                             'alt_text', n.alt_text_bn, 'eligibility', n.eligibility, 'valid_to', n.valid_to,
                                                             'read', exists (select 1 from sales.dealer_notice_read r where r.notice_id = n.id and r.dealer_id = d.id)) order by n.published_at desc)
                           from sales.dealer_notice n where n.company_id = d.company_id and n.status = 'published' and current_date between n.valid_from and n.valid_to
                            and sales.fn_notice_targets(n, d.id)), '[]'::jsonb),
    'products', coalesce((select jsonb_agg(jsonb_build_object('product', p.sku || ' · ' || p.name_bn, 'image_path', p.image_path,
                                                              'available', exists (select 1 from inventory.stock_balance b join inventory.warehouse w on w.id = b.warehouse_id
                                                                                    where b.product_id = p.id and w.kind = 'finished_goods' and b.qty > 0)) order by p.sku)
                            from inventory.product p where p.company_id = d.company_id and p.kind = 'finished_good' and p.status = 'active' and p.dealer_visible), '[]'::jsonb));
end $$;

create function sales.fn_dealer_request_visible() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if exists (select 1 from jsonb_array_elements(new.lines) l join inventory.product p on p.id = (l ->> 'product_id')::uuid where not p.dealer_visible) then
    raise exception 'E_INVALID_ACTION: a product is not offered to dealers' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dealer_request_visible before insert on sales.dealer_order_request for each row execute function sales.fn_dealer_request_visible();


-- V161 03-19: one-tap repeat of an earlier order as a NEW request (current prices, stock and credit apply again at acceptance)
create function api.v1_dealer_order_repeat(p_order_number text, p_idem_key text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_d uuid; o sales.sales_order%rowtype;
begin
  v_d := sales.fn_my_dealer('dealer.portal.order');
  select * into o from sales.sales_order where dealer_id = v_d and number = p_order_number;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'order of this dealer'); end if;
  return api.v1_dealer_order_request((select jsonb_agg(jsonb_build_object('product_id', l ->> 'product_id', 'qty', (l ->> 'qty')::numeric)) from jsonb_array_elements(o.lines) l),
                                     'আগের অর্ডার ' || o.number || ' আবার', p_idem_key);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array[
      'api.v1_supplier_bank_change_request(uuid, text, text, text)', 'api.v1_supplier_bank_change_decide(uuid, boolean, text)',
      'api.v1_machine_service_plan_set(text, text, integer, date, text)', 'api.v1_machine_service_done(uuid, text, integer)', 'api.v1_machine_services_due(integer)',
      'api.v1_plan_readiness(uuid)', 'api.v1_dealer_outlet_save(uuid, uuid, text, text, text, text, text)',
      'api.v1_location_claim_submit(text, uuid, numeric, numeric, numeric, text, text, text, text, text, text)', 'api.v1_location_claim_review(uuid, text, text)',
      'api.v1_location_claims(text)', 'api.v1_market_merge(uuid, uuid, text)', 'api.v1_market_split(uuid, text, text, jsonb, text)',
      'api.v1_dealer_contact_change_request(text, text, text, text)', 'api.v1_dealer_change_decide(uuid, boolean, text)', 'api.v1_dealer_portal_prefs(jsonb, text)',
      'api.v1_dealer_my_data()', 'api.v1_dealer_offboard(uuid, text)', 'api.v1_dealer_dispute_raise(text, text, text)', 'api.v1_dispute_raise(uuid, text, text, text)',
      'api.v1_dispute_resolve(uuid, boolean, text)', 'api.v1_disputes(text)', 'api.v1_dealer_aging(uuid)', 'api.v1_dealer_my_aging()', 'api.v1_order_hold(uuid, boolean, text)',
      'api.v1_orders_stale()', 'api.v1_dealer_order_request_link(uuid, uuid, uuid)', 'api.v1_offer_redemptions(uuid)', 'api.v1_visit_check_out(uuid)',
      'api.v1_product_dealer_visibility(uuid, boolean, text)', 'api.v1_dealer_order_repeat(text, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- 20261108004400_statement_closure.sql  (ধাপ ২ / S64 — 03_SOURCE_STATEMENT_REGISTER.csv, 234 statements; see docs/V180_STATEMENT_AUDIT_BN.md)
-- Gaps found and closed here:
--   REC-0105  demotion (besides promotion / transfer / suspension / reinstatement / termination), same history-keeping engine
--   REC-0031  sales commission: rule per position or person (basis: verified collections or net sales), monthly run, Chairman approval,
--             posted once (Dr commission expense, Cr salary payable)
--   REC-0037  SKU coverage by territory: dealers buying a SKU / active dealers (denominator), supply gaps, damage / returns
--   REC-0040  manual transport milestones (bus / launch / trawler / truck / van / rickshaw / courier): loaded -> departed -> arrived -> handed over
--   REC-0005/0078  cash custody belongs to the cash box, not to the person: custodian hand-over with a count, accepted by the new custodian;
--             the ledger is never reset
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ REC-0105 demotion
alter table hr.employment_change drop constraint if exists employment_change_kind_check;
alter table hr.employment_change add constraint employment_change_kind_check
  check (kind in ('promotion','demotion','transfer','suspension','reinstatement','termination'));

create or replace function hr.fn_apply_employment_change(p_change uuid) returns uuid
language plpgsql security definer set search_path = pg_catalog as $$
declare c hr.employment_change%rowtype; a iam.position_assignment%rowtype; v_new uuid; v_keep boolean;
begin
  select * into c from hr.employment_change where id = p_change for update;
  if c.status not in ('scheduled','pending_approval') then raise exception 'E_INVALID_ACTION: change is %', c.status using errcode = 'P0001'; end if;
  select * into a from iam.position_assignment where id = c.assignment_id and company_id = c.company_id for update;
  perform set_config('mohona.change_reason', c.kind || ': ' || c.reason, true);
  if c.kind in ('promotion','demotion','transfer') then
    if a.status = 'ended' then raise exception 'E_ASSIGNMENT_ENDED: the assignment ended before the change took effect' using errcode = 'P0001'; end if;
    v_keep := c.to_wing_id is null and c.to_department_id is null and c.to_location_id is null;
    if c.to_position_code is not null and c.to_position_code <> a.position_code or not v_keep then
      update iam.position_assignment set status = 'ended', ended_at = clock_timestamp(), end_reason = c.kind || ': ' || c.reason where id = a.id;
      insert into iam.position_assignment (company_id, membership_id, position_code, assignment_kind, home_wing_id, home_department_id, home_location_id)
      values (a.company_id, a.membership_id, coalesce(c.to_position_code, a.position_code), 'regular',
              case when v_keep then a.home_wing_id else c.to_wing_id end,
              case when v_keep then a.home_department_id else c.to_department_id end,
              case when v_keep then a.home_location_id else c.to_location_id end)
      returning id into v_new;
    end if;                                                   -- otherwise: grade / salary change only
  elsif c.kind = 'suspension' then
    update hr.employment em set status = 'suspended', reason = c.reason
     where em.status = 'active' and em.employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id);
    if not found then raise exception 'E_INVALID_ACTION: employment is not active' using errcode = 'P0001'; end if;
  elsif c.kind = 'reinstatement' then
    update hr.employment em set status = 'active', reason = c.reason
     where em.status = 'suspended' and em.employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id);
    if not found then raise exception 'E_INVALID_ACTION: employment is not suspended' using errcode = 'P0001'; end if;
  else
    update iam.company_membership set status = 'ended', ended_on = greatest(c.effective_on, started_on), end_reason = c.reason
     where id = c.membership_id and status <> 'ended';
    update hr.reporting_line set status = 'ended', ended_at = clock_timestamp()
     where company_id = c.company_id and status = 'active'
       and (employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id)
            or manager_employee_id = (select e.id from hr.employee e where e.membership_id = c.membership_id));
  end if;
  update hr.employment_change set status = 'applied', applied_at = clock_timestamp(), new_assignment_id = v_new where id = c.id;
  return v_new;
end $$;

create or replace function api.v1_hr_employment_change(p_kind text, p_assignment_id uuid, p_to_position_code text, p_to_wing_id uuid, p_to_department_id uuid,
                                            p_to_location_id uuid, p_grade text, p_salary numeric, p_effective_on date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; a iam.position_assignment%rowtype; v_person uuid; v_id uuid; v_new uuid; j jsonb; v_status text; v_can_salary boolean;
        v_eff date := coalesce(p_effective_on, current_date);
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if coalesce(p_kind, '') not in ('promotion','demotion','transfer','suspension','reinstatement','termination') then perform core.fn_raise('E_INVALID_ACTION', p_kind); end if;
  select * into a from iam.position_assignment where id = p_assignment_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'assignment'); end if;
  if a.status = 'ended' then perform core.fn_raise('E_ASSIGNMENT_ENDED'); end if;
  select * into me from iam.fn_require('iam.employee.change', iam.fn_resource(a.company_id, a.home_wing_id, a.home_department_id, a.home_location_id), true);
  select m.person_id into v_person from iam.company_membership m where m.id = a.membership_id for no key update;
  perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, a.position_code, v_person);
  if p_kind in ('promotion','demotion') then
    if p_to_position_code is not null then
      perform iam.fn_assert_below_me(me.is_supreme, me.company_id, me.position_code, me.person_id, p_to_position_code, v_person);
    elsif p_grade is null and p_salary is null and p_to_wing_id is null and p_to_department_id is null and p_to_location_id is null then
      perform core.fn_raise('E_INVALID_ACTION', p_kind || ' needs a new position, grade or salary');
    end if;
  elsif p_kind = 'transfer' then
    if p_to_wing_id is null and p_to_department_id is null and p_to_location_id is null then perform core.fn_raise('E_INVALID_ACTION', 'transfer needs a unit'); end if;
    if p_to_position_code is not null then perform core.fn_raise('E_INVALID_ACTION', 'a transfer keeps the position; use promotion'); end if;
    -- the manager must also be allowed to manage the destination unit
    perform iam.fn_require('iam.employee.change', iam.fn_resource(me.company_id, p_to_wing_id, p_to_department_id, p_to_location_id), false);
  elsif p_to_position_code is not null or p_to_wing_id is not null or p_to_department_id is not null or p_to_location_id is not null then
    perform core.fn_raise('E_INVALID_ACTION', p_kind || ' changes no position or unit');
  end if;
  if p_salary is not null or p_grade is not null then
    select d.allowed into v_can_salary from iam.fn_authorize('iam.salary.read', iam.fn_resource(me.company_id), false) d;
    if not (me.is_supreme or v_can_salary) then perform core.fn_raise('E_FORBIDDEN', 'iam.salary.read'); end if;
    if p_kind not in ('promotion','demotion','transfer') then perform core.fn_raise('E_INVALID_ACTION', 'pay changes go with promotion, demotion or transfer'); end if;
  end if;
  if exists (select 1 from hr.employment_change c where c.membership_id = a.membership_id and c.status in ('scheduled','pending_approval')
              and c.kind in ('termination') ) then
    perform core.fn_raise('E_DUPLICATE', 'a termination is already scheduled');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.employment_change (company_id, membership_id, assignment_id, kind, to_position_code, to_wing_id, to_department_id, to_location_id,
                                    grade, salary, effective_on, reason, created_by)
  values (me.company_id, a.membership_id, a.id, p_kind, p_to_position_code, p_to_wing_id, p_to_department_id, p_to_location_id,
          p_grade, p_salary, v_eff, p_reason, me.person_id) returning id into v_id;
  if config.fn_get_bool(me.company_id, 'hr.employment_change.requires_approval') then
    -- amount 0: pay never enters the approval payload / audit
    j := core.fn_approval_submit(me.company_id, 'hr.employment_change', v_id, 0,
                                 iam.fn_resource(me.company_id, a.home_wing_id, a.home_department_id, a.home_location_id, null, v_person),
                                 jsonb_build_object('change_id', v_id, 'kind', p_kind));
    if j ->> 'status' <> 'approved' then
      update hr.employment_change set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
      return jsonb_build_object('change_id', v_id, 'status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
    update hr.employment_change set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  end if;
  if v_eff <= current_date then
    v_new := hr.fn_apply_employment_change(v_id);
  end if;
  select c.status into v_status from hr.employment_change c where c.id = v_id;
  return jsonb_build_object('change_id', v_id, 'status', v_status, 'new_assignment_id', v_new, 'effective_on', v_eff);
end $$;

-- ================================================================ REC-0031 sales commission
insert into finance.coa_template (code, name_bn, type, parent, postable) values ('5710', 'বিক্রয়-কমিশন', 'expense', '5000', true) on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values ('hr.commission_expense', '5710', 'বিক্রয়-কমিশন') on conflict do nothing;

create table sales.commission_rule (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  position_code  text,
  person_id      uuid references core.person(id),
  basis          text not null check (basis in ('collection','sales')),
  pct            numeric(7,3) not null check (pct > 0 and pct <= 100),
  valid_from     date not null,
  status         text not null default 'active' check (status in ('active','superseded')),
  reason         text not null check (length(btrim(reason)) > 0),
  set_by         uuid not null references core.person(id),
  set_at         timestamptz not null default clock_timestamp(),
  check ((position_code is null) <> (person_id is null))
);
create trigger trg_commission_rule_nodel before delete on sales.commission_rule for each row execute function core.fn_deny_delete();
create trigger trg_commission_rule_audit after insert or update on sales.commission_rule for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'commission_rule');

create table sales.commission_run (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  period       date not null check (period = date_trunc('month', period)::date),
  lines        jsonb not null,          -- [{person_id, name, basis, base_amount, pct, amount}]
  total        numeric(16,2) not null check (total >= 0),
  status       text not null default 'calculated' check (status in ('calculated','posted','rejected')),
  maker_id     uuid not null references core.person(id),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  created_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  check (decided_by is null or decided_by <> maker_id)
);
create unique index ux_commission_run_period on sales.commission_run (company_id, period) where status <> 'rejected';
create function sales.fn_commission_run_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status <> 'calculated' or (to_jsonb(old) - array['status','decided_by','decided_at']) <> (to_jsonb(new) - array['status','decided_by','decided_at']) then
    raise exception 'E_IMMUTABLE: a commission run is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_commission_run_guard before update on sales.commission_run for each row execute function sales.fn_commission_run_guard();
create trigger trg_commission_run_nodel before delete on sales.commission_run for each row execute function core.fn_deny_delete();
create trigger trg_commission_run_audit after insert or update on sales.commission_run for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'commission_run');

create function api.v1_commission_rule_set(p_position_code text, p_person_id uuid, p_basis text, p_pct numeric, p_valid_from date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('hr.payroll.calculate', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if (p_position_code is null) = (p_person_id is null) then perform core.fn_raise('E_INVALID_ACTION', 'either a position or a person'); end if;
  if coalesce(p_basis, '') not in ('collection','sales') or coalesce(p_pct, 0) <= 0 or p_pct > 100 then perform core.fn_raise('E_INVALID_ACTION', 'basis / percent'); end if;
  if coalesce(p_valid_from, current_date) < date_trunc('month', current_date)::date then perform core.fn_raise('E_INVALID_ACTION', 'a rule starts this month or later'); end if;
  if p_person_id is not null and not exists (select 1 from iam.company_membership m where m.person_id = p_person_id and m.company_id = me.company_id) then
    perform core.fn_raise('E_NOT_FOUND', 'person');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update sales.commission_rule set status = 'superseded'
   where company_id = me.company_id and status = 'active' and position_code is not distinct from p_position_code and person_id is not distinct from p_person_id
     and valid_from >= coalesce(p_valid_from, current_date);
  insert into sales.commission_rule (company_id, position_code, person_id, basis, pct, valid_from, reason, set_by)
  values (me.company_id, p_position_code, p_person_id, p_basis, p_pct, coalesce(p_valid_from, current_date), btrim(p_reason), me.person_id) returning id into v_id;
  return jsonb_build_object('rule_id', v_id);
end $$;

-- Base per officer = dealers assigned to that officer: verified collections in the month, or invoices minus credit notes in the month.
create function api.v1_commission_calculate(p_period date) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; f date := date_trunc('month', coalesce(p_period, current_date))::date; t date; v_lines jsonb; v_total numeric; v_id uuid;
begin
  select * into me from iam.fn_require('hr.payroll.calculate', iam.fn_my_company_resource(), true);
  t := (f + interval '1 month' - interval '1 day')::date;
  if exists (select 1 from sales.commission_run r where r.company_id = me.company_id and r.period = f and r.status <> 'rejected') then
    perform core.fn_raise('E_DUPLICATE', 'commission for this month is already calculated');
  end if;
  with officers as (
    select distinct d.officer_id person_id from sales.dealer d where d.company_id = me.company_id and d.officer_id is not null),
  rule as (
    select o.person_id, r.basis, r.pct from officers o
      cross join lateral (select x.basis, x.pct from sales.commission_rule x
                           where x.company_id = me.company_id and x.status = 'active' and x.valid_from <= t
                             and (x.person_id = o.person_id
                                  or x.position_code in (select pa.position_code from iam.position_assignment pa join iam.company_membership m on m.id = pa.membership_id
                                                          where m.person_id = o.person_id and pa.company_id = me.company_id and pa.status = 'active'))
                           order by (x.person_id is null), x.valid_from desc limit 1) r),
  base as (
    select r.person_id, r.basis, r.pct,
           case r.basis
             when 'collection' then coalesce((select sum(c.amount) from sales.collection c join sales.dealer d on d.id = c.dealer_id
                                               where d.officer_id = r.person_id and c.company_id = me.company_id and c.status = 'verified' and c.verified_at::date between f and t), 0)
             else coalesce((select sum(i.total) from sales.invoice i join sales.dealer d on d.id = i.dealer_id
                             where d.officer_id = r.person_id and i.company_id = me.company_id and i.invoice_date between f and t), 0)
                - coalesce((select sum(x.credit_amount) from sales.sales_return x join sales.invoice i on i.id = x.invoice_id join sales.dealer d on d.id = i.dealer_id
                             where d.officer_id = r.person_id and x.company_id = me.company_id and x.created_at::date between f and t), 0)
           end base_amount
      from rule r)
  select coalesce(jsonb_agg(jsonb_build_object('person_id', b.person_id, 'name', p.full_name_bn, 'basis', b.basis, 'base_amount', b.base_amount, 'pct', b.pct,
                                               'amount', round(greatest(b.base_amount, 0) * b.pct / 100, 2)) order by p.full_name_bn), '[]'::jsonb),
         coalesce(sum(round(greatest(b.base_amount, 0) * b.pct / 100, 2)), 0)
    into v_lines, v_total
    from base b join core.person p on p.id = b.person_id;
  perform set_config('mohona.change_reason', 'commission ' || f, true);
  insert into sales.commission_run (company_id, period, lines, total, maker_id) values (me.company_id, f, v_lines, v_total, me.person_id) returning id into v_id;
  return jsonb_build_object('run_id', v_id, 'period', f, 'total', v_total, 'lines', v_lines);
end $$;

-- Money: only the Chairman posts (maker-checker; the Chairman's own run is prepared by someone else).
create function api.v1_commission_decide(p_run_id uuid, p_approve boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare v_ch uuid; r sales.commission_run%rowtype;
begin
  select * into r from sales.commission_run where id = p_run_id and company_id = iam.fn_context_company() for update;
  if not found or r.status <> 'calculated' then perform core.fn_raise('E_NOT_FOUND', 'calculated commission run'); end if;
  v_ch := core.fn_require_chairman(r.maker_id);
  perform set_config('mohona.change_reason', case when p_approve then 'commission approved' else 'commission rejected' end, true);
  update sales.commission_run set status = case when p_approve then 'posted' else 'rejected' end, decided_by = v_ch, decided_at = clock_timestamp() where id = r.id;
  if p_approve and r.total > 0 then
    perform finance.fn_emit(r.company_id, 'commission:' || r.id, 'বিক্রয়-কমিশন ' || to_char(r.period, 'YYYY-MM'), jsonb_build_array(
      jsonb_build_object('key', 'hr.commission_expense', 'dr', r.total), jsonb_build_object('key', 'hr.salary_payable', 'cr', r.total)));
  end if;
  return jsonb_build_object('run_id', r.id, 'status', case when p_approve then 'posted' else 'rejected' end, 'total', r.total);
end $$;

-- An officer sees the own commission lines only; payroll readers see the run (amounts follow the hr.payroll.amount mask).
create function api.v1_commission_runs(p_period date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_all boolean;
begin
  select * into me from iam.fn_context(false);
  select d.allowed into v_all from iam.fn_authorize('hr.payroll.read', iam.fn_my_company_resource(), false) d;
  return coalesce((select jsonb_agg(jsonb_build_object('run_id', r.id, 'period', r.period, 'status', r.status,
            'total', case when coalesce(v_all, false) then hr.fn_pay_view(r.total, false) end,
            'lines', coalesce((select jsonb_agg(case when x ->> 'person_id' = me.person_id::text then x
                                                     else x - 'amount' - 'base_amount' || jsonb_build_object('amount', hr.fn_pay_view((x ->> 'amount')::numeric, false)) end)
                                 from jsonb_array_elements(r.lines) x where coalesce(v_all, false) or x ->> 'person_id' = me.person_id::text), '[]'::jsonb))
            order by r.period desc)
     from sales.commission_run r where r.company_id = me.company_id and (p_period is null or r.period = date_trunc('month', p_period)::date)), '[]'::jsonb);
end $$;

-- ================================================================ REC-0037 SKU coverage by territory
create function api.v1_territory_coverage(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, date_trunc('month', current_date)::date); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('sales.monthly_summary.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('territory', tr.code || ' · ' || tr.name_bn,
            'active_dealers', (select count(*) from sales.dealer d where d.territory_id = tr.id and d.status = 'active'),
            'skus', coalesce((select jsonb_agg(jsonb_build_object('product', p.sku || ' · ' || p.name_bn,
                        'dealers_buying', q.buyers,
                        'coverage_pct', case when q.denominator = 0 then null else round(100.0 * q.buyers / q.denominator, 1) end,
                        'qty', q.qty, 'returned_qty', q.ret) order by q.buyers desc, p.sku)
                 from inventory.product p
                 cross join lateral (
                   select (select count(distinct i.dealer_id) from sales.invoice i join sales.dealer d on d.id = i.dealer_id, jsonb_array_elements(i.lines) l
                            where d.territory_id = tr.id and i.invoice_date between f and t and l ->> 'product_id' = p.id::text) buyers,
                          (select count(*) from sales.dealer d where d.territory_id = tr.id and d.status = 'active') denominator,
                          coalesce((select sum((l ->> 'qty')::numeric) from sales.invoice i join sales.dealer d on d.id = i.dealer_id, jsonb_array_elements(i.lines) l
                                     where d.territory_id = tr.id and i.invoice_date between f and t and l ->> 'product_id' = p.id::text), 0) qty,
                          coalesce((select sum((l ->> 'qty')::numeric) from sales.sales_return x join sales.invoice i on i.id = x.invoice_id join sales.dealer d on d.id = i.dealer_id,
                                           jsonb_array_elements(x.lines) l
                                     where d.territory_id = tr.id and x.created_at::date between f and t and l ->> 'product_id' = p.id::text), 0) ret) q
                where p.company_id = me.company_id and p.kind = 'finished_good' and p.status = 'active'), '[]'::jsonb),
            'supply_gaps', coalesce((select jsonb_agg(p.sku || ' · ' || p.name_bn order by p.sku) from inventory.product p
                                      where p.company_id = me.company_id and p.kind = 'finished_good' and p.status = 'active'
                                        and not exists (select 1 from sales.invoice i join sales.dealer d on d.id = i.dealer_id, jsonb_array_elements(i.lines) l
                                                         where d.territory_id = tr.id and i.invoice_date between f and t and l ->> 'product_id' = p.id::text)), '[]'::jsonb))
           order by tr.code)
     from sales.territory tr where tr.company_id = me.company_id and tr.status = 'active'), '[]'::jsonb);
end $$;

-- ================================================================ REC-0040 manual transport milestones
create table sales.transport_milestone (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  dispatch_id  uuid,
  shipment_id  uuid,
  mode         text not null check (mode in ('bus','launch','trawler','truck','van','rickshaw','courier','other')),
  milestone    text not null check (milestone in ('loaded','departed','arrived','handed_over','delayed','problem')),
  place        text,
  vehicle_ref  text,
  note         text,
  evidence_ref text,
  recorded_by  uuid not null references core.person(id),
  at           timestamptz not null default clock_timestamp(),
  check ((dispatch_id is null) <> (shipment_id is null)),
  foreign key (dispatch_id, company_id) references sales.dispatch (id, company_id),
  foreign key (shipment_id, company_id) references sales.shipment (id, company_id)
);
create trigger trg_transport_milestone_no_mutation before update or delete on sales.transport_milestone for each row execute function core.fn_deny_mutation();
create trigger trg_transport_milestone_audit after insert on sales.transport_milestone for each row execute function audit.fn_row_change();
select core.fn_apply_rls('sales', 'transport_milestone');

-- A milestone is information only: it never moves stock or money (delivery is still confirmed by the delivery / courier steps).
create function api.v1_transport_milestone(p_dispatch_id uuid, p_shipment_id uuid, p_mode text, p_milestone text, p_place text, p_vehicle_ref text,
                                           p_note text, p_evidence_ref text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_my_company_resource(), true);
  if (p_dispatch_id is null) = (p_shipment_id is null) then perform core.fn_raise('E_INVALID_ACTION', 'a dispatch or a shipment'); end if;
  if p_dispatch_id is not null and not exists (select 1 from sales.dispatch d where d.id = p_dispatch_id and d.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'dispatch'); end if;
  if p_shipment_id is not null and not exists (select 1 from sales.shipment s where s.id = p_shipment_id and s.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'shipment'); end if;
  if coalesce(p_mode, '') not in ('bus','launch','trawler','truck','van','rickshaw','courier','other')
     or coalesce(p_milestone, '') not in ('loaded','departed','arrived','handed_over','delayed','problem') then perform core.fn_raise('E_INVALID_ACTION', 'mode / milestone'); end if;
  if p_milestone in ('delayed','problem') and length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'say what happened'); end if;
  perform set_config('mohona.change_reason', 'transport ' || p_milestone, true);
  insert into sales.transport_milestone (company_id, dispatch_id, shipment_id, mode, milestone, place, vehicle_ref, note, evidence_ref, recorded_by)
  values (me.company_id, p_dispatch_id, p_shipment_id, p_mode, p_milestone, nullif(btrim(p_place), ''), nullif(btrim(p_vehicle_ref), ''), nullif(btrim(p_note), ''),
          p_evidence_ref, me.person_id) returning id into v_id;
  return jsonb_build_object('milestone_id', v_id);
end $$;

create function api.v1_transport_track(p_dispatch_id uuid, p_shipment_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('mode', m.mode, 'milestone', m.milestone, 'place', m.place, 'vehicle', m.vehicle_ref, 'note', m.note,
                                                        'at', m.at, 'by', p.full_name_bn) order by m.at)
                     from sales.transport_milestone m join core.person p on p.id = m.recorded_by
                    where m.company_id = me.company_id and (m.dispatch_id = p_dispatch_id or m.shipment_id = p_shipment_id)), '[]'::jsonb);
end $$;

-- ================================================================ REC-0005 / 0078 cash custody hand-over
create table finance.cash_handover (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  cash_account_id uuid not null,
  from_person     uuid references core.person(id),
  to_person       uuid not null references core.person(id),
  book_balance    numeric(16,2) not null,
  counted         numeric(16,2) not null check (counted >= 0),
  difference      numeric(16,2) not null,
  note            text,
  status          text not null default 'offered' check (status in ('offered','accepted','refused')),
  offered_by      uuid not null references core.person(id),
  offered_at      timestamptz not null default clock_timestamp(),
  decided_at      timestamptz,
  unique (id, company_id),
  check (difference = 0 or length(btrim(coalesce(note, ''))) > 0),
  foreign key (cash_account_id, company_id) references finance.cash_account (id, company_id)
);
create function finance.fn_cash_handover_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status <> 'offered' or (to_jsonb(old) - array['status','decided_at']) <> (to_jsonb(new) - array['status','decided_at']) then
    raise exception 'E_IMMUTABLE: a cash hand-over is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_cash_handover_guard before update on finance.cash_handover for each row execute function finance.fn_cash_handover_guard();
create trigger trg_cash_handover_nodel before delete on finance.cash_handover for each row execute function core.fn_deny_delete();
create trigger trg_cash_handover_audit after insert or update on finance.cash_handover for each row execute function audit.fn_row_change();
select core.fn_apply_rls('finance', 'cash_handover');

-- The cash box keeps its ledger; only the custodian changes. A difference is recorded (and must be explained), never silently absorbed:
-- the shortage / excess itself is booked through the normal cash-count / voucher route.
create function api.v1_cash_handover_offer(p_cash_account_id uuid, p_to_person uuid, p_counted numeric, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c finance.cash_account%rowtype; v_book numeric; v_id uuid;
begin
  select * into me from iam.fn_require('finance.cash.voucher', iam.fn_my_company_resource(), true);
  select * into c from finance.cash_account where id = p_cash_account_id and company_id = me.company_id for update;
  if not found or c.status <> 'active' then perform core.fn_raise('E_NOT_FOUND', 'active cash box'); end if;
  if p_to_person is null or p_to_person = c.custodian then perform core.fn_raise('E_INVALID_ACTION', 'a different new custodian'); end if;
  if not exists (select 1 from iam.company_membership m where m.person_id = p_to_person and m.company_id = me.company_id and m.status = 'active') then
    perform core.fn_raise('E_NOT_FOUND', 'active member of this company');
  end if;
  if exists (select 1 from finance.cash_handover h where h.cash_account_id = c.id and h.status = 'offered') then perform core.fn_raise('E_DUPLICATE', 'a hand-over is already waiting'); end if;
  if coalesce(p_counted, -1) < 0 then perform core.fn_raise('E_INVALID_ACTION', 'counted cash'); end if;
  v_book := finance.fn_balance(c.account_id, current_date);
  if p_counted <> v_book and length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'explain the difference'); end if;
  perform set_config('mohona.change_reason', 'cash hand-over offered', true);
  insert into finance.cash_handover (company_id, cash_account_id, from_person, to_person, book_balance, counted, difference, note, offered_by)
  values (me.company_id, c.id, c.custodian, p_to_person, v_book, p_counted, p_counted - v_book, nullif(btrim(p_note), ''), me.person_id) returning id into v_id;
  return jsonb_build_object('handover_id', v_id, 'book_balance', v_book, 'counted', p_counted, 'difference', p_counted - v_book);
end $$;

-- Only the new custodian accepts (or refuses) — custody passes only when the receiver confirms.
create function api.v1_cash_handover_accept(p_handover_id uuid, p_accept boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; h finance.cash_handover%rowtype;
begin
  select * into me from iam.fn_context(true);
  select * into h from finance.cash_handover where id = p_handover_id and company_id = me.company_id for update;
  if not found or h.status <> 'offered' then perform core.fn_raise('E_NOT_FOUND', 'waiting hand-over'); end if;
  if h.to_person <> me.person_id then perform core.fn_raise('E_FORBIDDEN', 'only the new custodian answers'); end if;
  perform set_config('mohona.change_reason', case when p_accept then 'cash custody accepted' else 'cash custody refused' end, true);
  update finance.cash_handover set status = case when p_accept then 'accepted' else 'refused' end, decided_at = clock_timestamp() where id = h.id;
  if p_accept then update finance.cash_account set custodian = h.to_person where id = h.cash_account_id; end if;
  return jsonb_build_object('handover_id', h.id, 'status', case when p_accept then 'accepted' else 'refused' end);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_commission_rule_set(text, uuid, text, numeric, date, text)', 'api.v1_commission_calculate(date)', 'api.v1_commission_decide(uuid, boolean)',
      'api.v1_commission_runs(date)', 'api.v1_territory_coverage(date, date)', 'api.v1_transport_milestone(uuid, uuid, text, text, text, text, text, text)',
      'api.v1_transport_track(uuid, uuid)', 'api.v1_cash_handover_offer(uuid, uuid, numeric, text)', 'api.v1_cash_handover_accept(uuid, boolean)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

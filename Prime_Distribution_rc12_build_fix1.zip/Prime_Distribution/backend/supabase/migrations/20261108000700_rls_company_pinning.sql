-- 20261108000700_rls_company_pinning.sql  (S08)
-- Row-Level Security on EVERY project table, FORCED (applies to the owner erp_owner as well), plus "company pinning":
-- once a request has resolved its active position (iam.fn_context), the transaction is pinned to that company and every
-- table read/write is limited to it by policy. A coding mistake in a later RPC (a missing "company_id = ..." filter)
-- therefore returns/affects nothing from another company instead of leaking it (defense in depth on top of fn_require).
-- API roles (anon/authenticated) have no table privileges and no policies: deny twice. FK checks are not affected by RLS.
-- Denials are written to the server log (RAISE LOG survives the rollback of the failed request) - closes OI-06.
-- Every later migration must call core.fn_apply_rls(...) for its new tables and end with core.fn_assert_rls_everywhere().
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create function core.fn_pinned_company() returns uuid
language plpgsql stable set search_path = pg_catalog as $$
begin
  return nullif(current_setting('mohona.company_scope', true), '')::uuid;
exception when others then
  return null;
end $$;

-- Applies the standard policy set to one table (idempotent):
--   has company_id   -> erp_owner sees/writes only the pinned company (all rows when not pinned)
--   core.company     -> same, keyed by id
--   company-less     -> erp_owner unrestricted (global identity/vocabulary/audit tables)
-- No policy is ever created for anon/authenticated/service_role.
create function core.fn_apply_rls(p_schema text, p_table text) returns void
language plpgsql set search_path = pg_catalog as $$
declare v_rel text := format('%I.%I', p_schema, p_table); v_has_company boolean; v_nullable boolean; v_pred text;
begin
  select true, not a.attnotnull into v_has_company, v_nullable
    from pg_attribute a where a.attrelid = v_rel::regclass and a.attname = 'company_id' and not a.attisdropped;
  v_pred := case
    when p_schema = 'core' and p_table = 'company' then 'core.fn_pinned_company() is null or id = core.fn_pinned_company()'
    when coalesce(v_has_company, false) and v_nullable then 'core.fn_pinned_company() is null or company_id is null or company_id = core.fn_pinned_company()'
    when coalesce(v_has_company, false) then 'core.fn_pinned_company() is null or company_id = core.fn_pinned_company()'
    else 'true' end;
  execute format('alter table %s enable row level security', v_rel);
  execute format('alter table %s force row level security', v_rel);
  execute format('drop policy if exists p_erp_owner on %s', v_rel);
  execute format('create policy p_erp_owner on %s as permissive for all to erp_owner using (%s) with check (%s)', v_rel, v_pred, v_pred);
end $$;

-- Fails the migration if any project table lacks RLS, FORCE RLS or the owner policy, or has a policy for an API role.
create function core.fn_assert_rls_everywhere() returns void
language plpgsql set search_path = pg_catalog as $$
declare v_bad text;
begin
  select string_agg(n.nspname || '.' || c.relname, ', ' order by 1) into v_bad
    from pg_class c join pg_namespace n on n.oid = c.relnamespace
   where c.relkind in ('r','p')
     and n.nspname in ('core','iam','config', 'design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify', 'location', 'hardware','api','svc')
     and (not c.relrowsecurity or not c.relforcerowsecurity
          or not exists (select 1 from pg_policy p where p.polrelid = c.oid and p.polname = 'p_erp_owner')
          or exists (select 1 from pg_policy p join pg_roles r on r.oid = any (p.polroles)
                      where p.polrelid = c.oid and r.rolname in ('anon','authenticated','service_role','public')));
  if v_bad is not null then
    raise exception 'E_RLS_MISSING: %', v_bad using errcode = 'P0001';
  end if;
end $$;

do $$
declare r record;
begin
  for r in select n.nspname, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
            where c.relkind in ('r','p') and n.nspname in ('core','iam','config', 'design','audit','finance','inventory','mfg','procurement','sales','hr','report','notify', 'location', 'hardware','api','svc')
  loop
    perform core.fn_apply_rls(r.nspname, r.relname);
  end loop;
end $$;

-- ---------------------------------------------------------------- request boundary: unpin at entry, pin after context
-- Every api.* entry resolves the person first (fn_require_person): a new request never inherits an old pin.
create or replace function iam.fn_require_person() returns uuid
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare v uuid;
begin
  perform set_config('mohona.company_scope', '', true);
  v := iam.fn_current_person();
  if v is null then perform core.fn_raise('E_AUTH', 'no active person for this login'); end if;
  return v;
end $$;
alter function api.v1_iam_whoami() volatile;
alter function api.v1_iam_my_positions() volatile;

create or replace function iam.fn_context(p_lock boolean default false)
returns table (person_id uuid, company_id uuid, membership_id uuid, assignment_id uuid, position_code text, is_supreme boolean,
               home_wing_id uuid, home_department_id uuid, home_location_id uuid)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare v_person uuid := iam.fn_require_person(); s iam.session_context%rowtype;
begin
  select * into s from iam.session_context where session_key = iam.fn_session_key();
  if not found or s.person_id <> v_person then
    perform core.fn_raise('E_NO_ACTIVE_POSITION');
  end if;
  if p_lock then
    perform 1 from core.company           where id = s.company_id    for share;
    perform 1 from iam.company_membership where id = s.membership_id for share;
    perform 1 from iam.position_assignment where id = s.assignment_id for share;
  end if;
  if not iam.fn_assignment_usable(v_person, s.assignment_id) then
    perform core.fn_raise('E_NO_ACTIVE_POSITION', 'selected position is no longer active');
  end if;
  perform set_config('mohona.company_scope', s.company_id::text, true);      -- pin: from here on, only this company
  return query
    select v_person, a.company_id, a.membership_id, a.id, a.position_code, pc.is_supreme, a.home_wing_id, a.home_department_id, a.home_location_id
      from iam.position_assignment a join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
     where a.id = s.assignment_id;
end $$;

-- Denials go to the server log with who/what/why/request id (never rolled back with the failed request).
create function core.fn_request_id() returns text
language plpgsql stable set search_path = pg_catalog as $$
begin
  return nullif(current_setting('request.headers', true), '')::json ->> 'x-request-id';
exception when others then
  return null;
end $$;

create or replace function iam.fn_require(p_permission text, p_resource iam.resource, p_lock boolean default true)
returns table (person_id uuid, company_id uuid, assignment_id uuid, position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare d record;
begin
  select * into d from iam.fn_authorize(p_permission, p_resource, p_lock);
  if not d.allowed then
    raise log 'MOHONA_SECURITY_DENIED person=% company=% assignment=% position=% permission=% reason=% resource_company=% request=%',
      d.person_id, d.company_id, d.assignment_id, d.position_code, p_permission, d.reason, (p_resource).company_id, core.fn_request_id();
    perform core.fn_raise(case d.reason
                            when 'wrong_company' then 'E_WRONG_COMPANY'
                            when 'mfa_required' then 'E_MFA_REQUIRED'
                            when 'permission_not_active' then 'E_FEATURE_NOT_READY'
                            else 'E_FORBIDDEN' end, p_permission);
  end if;
  return query select d.person_id, d.company_id, d.assignment_id, d.position_code, d.is_supreme;
end $$;

select core.fn_assert_rls_everywhere();

reset role;

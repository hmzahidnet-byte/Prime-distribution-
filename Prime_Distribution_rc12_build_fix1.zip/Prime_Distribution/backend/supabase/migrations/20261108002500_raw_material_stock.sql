-- 20261108002500_raw_material_stock.sql  (S25)
-- Raw material (blueprint RAW_MATERIAL MOS-F153-071, 073..080) + units, on a new stock ledger that every later stock
-- module (procurement GRN, manufacturing, sales, transfers, counts) posts through:
--   071 raw profile: ingredient, grade, purchase unit with a positive factor (fixed once stock exists), shelf life, FEFO
--   073 receipt engine: accepted / quarantined / rejected; ONLY accepted enters stock; quarantine is released later
--   074 lots with expiry; FEFO picking; expired lots are never issued
--   075 reservations per batch reference; never above available stock
--   076 issue against a reservation: reduces stock (FEFO lots) and the reservation
--   077 return references the original issue line and lot, at the issue cost
--   078 wastage: normal (posted) / abnormal (approval by another person, separate move type for separate expensing)
--   079 substitution: approved alternatives only (new controlled approval, never the proposer)
--   080 valuation: moving average per warehouse + SKU; no negative stock anywhere (balance, lot)
-- 072 (PO lines / PO-matched GRN) belongs to procurement (S26–S28) and will call inventory.fn_post_receipt.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

insert into inventory.unit (code, name_bn, dimension, to_base, sort_order) values
  ('bag', 'বস্তা', 'pack', null, 110), ('drum', 'ড্রাম', 'pack', null, 120), ('roll', 'রোল', 'pack', null, 130)
on conflict do nothing;

-- ================================================================ raw profile (F071)
create table inventory.raw_profile (
  product_id       uuid primary key,
  company_id       uuid not null,
  ingredient_type  text not null check (ingredient_type ~ '^[a-z_]{2,30}$'),
  grade            text check (grade is null or grade ~ '^[A-Za-z0-9 _.-]{1,20}$'),
  purchase_unit    text not null references inventory.unit(code),
  purchase_factor  numeric(14,6) not null check (purchase_factor > 0),     -- base units per purchase unit (e.g. 50 kg per bag)
  shelf_life_days  integer check (shelf_life_days is null or shelf_life_days > 0),
  min_stock        numeric(18,4) not null default 0 check (min_stock >= 0),
  default_supplier text,
  fefo             boolean not null default true,
  updated_at       timestamptz not null default clock_timestamp(),
  row_version      integer not null default 1,
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);
create trigger trg_raw_profile_touch before update on inventory.raw_profile for each row execute function core.fn_touch_row();
create trigger trg_raw_profile_nodel before delete on inventory.raw_profile for each row execute function core.fn_deny_delete();
create trigger trg_raw_profile_audit after insert or update on inventory.raw_profile for each row execute function audit.fn_row_change();

-- ================================================================ lots, balances, ledger
create table inventory.lot (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  product_id    uuid not null,
  lot_no        text not null check (lot_no ~ '^[A-Za-z0-9/_.-]{1,40}$'),
  supplier_lot  text,
  mfg_date      date,
  expiry_date   date,
  status        text not null default 'available' check (status in ('available','blocked')),
  received_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, product_id, lot_no),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  check (expiry_date is null or mfg_date is null or expiry_date >= mfg_date)
);
create trigger trg_lot_nodel before delete on inventory.lot for each row execute function core.fn_deny_delete();
create trigger trg_lot_audit after insert or update on inventory.lot for each row execute function audit.fn_row_change();

create table inventory.stock_balance (
  company_id   uuid not null,
  warehouse_id uuid not null,
  product_id   uuid not null,
  qty          numeric(18,4) not null default 0 check (qty >= 0),          -- F080: never negative
  value        numeric(18,4) not null default 0 check (value >= 0),
  updated_at   timestamptz not null default clock_timestamp(),
  primary key (company_id, warehouse_id, product_id),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id),
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);

create table inventory.lot_balance (
  company_id   uuid not null,
  warehouse_id uuid not null,
  lot_id       uuid not null,
  qty          numeric(18,4) not null default 0 check (qty >= 0),
  primary key (company_id, warehouse_id, lot_id),
  foreign key (lot_id, company_id) references inventory.lot (id, company_id)
);

create table inventory.stock_move (
  id           bigint generated always as identity primary key,
  company_id   uuid not null,
  warehouse_id uuid not null,
  product_id   uuid not null,
  lot_id       uuid,
  move_type    text not null check (move_type in ('receipt','opening','quarantine_release','issue','return','waste_normal','waste_abnormal',
                                                  'adjust_in','adjust_out','transfer_in','transfer_out','fg_receipt','sale')),
  qty          numeric(18,4) not null check (qty <> 0),
  unit_cost    numeric(18,6) not null check (unit_cost >= 0),
  value        numeric(18,4) not null,
  doc_type     text not null,
  doc_id       uuid not null,
  doc_line     integer not null default 0,
  reason       text,
  posted_by    uuid,
  posted_at    timestamptz not null default clock_timestamp()
);
create unique index stock_move_once on inventory.stock_move (doc_type, doc_id, doc_line, lot_id) nulls not distinct;   -- a document line posts once
create index stock_move_product on inventory.stock_move (company_id, product_id, posted_at desc);
create trigger trg_stock_move_no_mutation before update or delete on inventory.stock_move for each row execute function core.fn_deny_mutation();
create trigger trg_stock_move_audit after insert on inventory.stock_move for each row execute function audit.fn_row_change();

-- ================================================================ receipts + quarantine (F073)
create table inventory.receipt (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  warehouse_id  uuid not null,
  product_id    uuid not null,
  lot_id        uuid not null,
  accepted_qty  numeric(18,4) not null check (accepted_qty >= 0),
  quarantine_qty numeric(18,4) not null default 0 check (quarantine_qty >= 0),
  rejected_qty  numeric(18,4) not null default 0 check (rejected_qty >= 0),
  unit_cost     numeric(18,6) not null check (unit_cost >= 0),
  kind          text not null check (kind in ('opening','grn')),
  source_ref    text,
  reason        text not null,
  posted_by     uuid,
  posted_at     timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  check (accepted_qty + quarantine_qty + rejected_qty > 0),
  foreign key (lot_id, company_id) references inventory.lot (id, company_id)
);
create trigger trg_receipt_no_mutation before update or delete on inventory.receipt for each row execute function core.fn_deny_mutation();
create trigger trg_receipt_audit after insert on inventory.receipt for each row execute function audit.fn_row_change();

create table inventory.quarantine_hold (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  receipt_id   uuid not null,
  qty          numeric(18,4) not null check (qty > 0),
  status       text not null default 'held' check (status in ('held','released','rejected','partly')),
  released_qty numeric(18,4) not null default 0 check (released_qty >= 0),
  rejected_qty numeric(18,4) not null default 0 check (rejected_qty >= 0),
  decided_by   uuid, decided_at timestamptz, reason text,
  check (released_qty + rejected_qty <= qty),
  foreign key (receipt_id, company_id) references inventory.receipt (id, company_id)
);
create trigger trg_quarantine_nodel before delete on inventory.quarantine_hold for each row execute function core.fn_deny_delete();
create trigger trg_quarantine_audit after insert or update on inventory.quarantine_hold for each row execute function audit.fn_row_change();

-- ================================================================ reservations, issues, returns, wastage, substitution
create table inventory.reservation (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  warehouse_id  uuid not null,
  product_id    uuid not null,
  batch_ref     text not null check (batch_ref ~ '^[A-Za-z0-9/_.:-]{2,40}$'),    -- SO:/TR: prefixes
  qty           numeric(18,4) not null check (qty > 0),
  consumed_qty  numeric(18,4) not null default 0 check (consumed_qty >= 0),
  status        text not null default 'active' check (status in ('active','consumed','released')),
  created_by    uuid, created_at timestamptz not null default clock_timestamp(),
  reason        text,
  updated_at    timestamptz not null default clock_timestamp(),
  row_version   integer not null default 1,
  unique (id, company_id),
  check (consumed_qty <= qty),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id),
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);
create trigger trg_reservation_touch before update on inventory.reservation for each row execute function core.fn_touch_row();
create trigger trg_reservation_nodel before delete on inventory.reservation for each row execute function core.fn_deny_delete();
create trigger trg_reservation_audit after insert or update on inventory.reservation for each row execute function audit.fn_row_change();

create table inventory.material_issue (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  warehouse_id  uuid not null,
  reservation_id uuid not null,
  batch_ref     text not null,
  number        text,
  lines         jsonb not null,             -- [{line, product_id, substitute_for, lot_id, qty, unit_cost}]
  reason        text not null,
  posted_by     uuid, posted_at timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (reservation_id, company_id) references inventory.reservation (id, company_id)
);
create trigger trg_issue_no_mutation before update or delete on inventory.material_issue for each row execute function core.fn_deny_mutation();
create trigger trg_issue_audit after insert on inventory.material_issue for each row execute function audit.fn_row_change();

create table inventory.material_return (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  issue_id    uuid not null,
  issue_line  integer not null,
  lot_id      uuid,
  qty         numeric(18,4) not null check (qty > 0),
  reason      text not null,
  posted_by   uuid, posted_at timestamptz not null default clock_timestamp(),
  foreign key (issue_id, company_id) references inventory.material_issue (id, company_id)
);
create trigger trg_return_no_mutation before update or delete on inventory.material_return for each row execute function core.fn_deny_mutation();
create trigger trg_return_audit after insert on inventory.material_return for each row execute function audit.fn_row_change();

create table inventory.wastage (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  warehouse_id uuid not null,
  kind         text not null check (kind in ('normal','abnormal')),
  lines        jsonb not null,             -- [{product_id, qty}]
  reason       text not null check (length(btrim(reason)) > 0),
  status       text not null default 'pending' check (status in ('pending','posted','rejected')),
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  decided_by   uuid references core.person(id),
  decided_at   timestamptz,
  check (decided_by is null or decided_by <> created_by)
);
create function inventory.fn_wastage_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','decided_by','decided_at']) <> (to_jsonb(new) - array['status','decided_by','decided_at']) or old.status <> 'pending' then
    raise exception 'E_IMMUTABLE: wastage is decided once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_wastage_guard before update on inventory.wastage for each row execute function inventory.fn_wastage_guard();
create trigger trg_wastage_nodel before delete on inventory.wastage for each row execute function core.fn_deny_delete();
create trigger trg_wastage_audit after insert or update on inventory.wastage for each row execute function audit.fn_row_change();

create table inventory.substitution_rule (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  product_id    uuid not null,
  substitute_id uuid not null,
  ratio         numeric(12,6) not null check (ratio > 0),     -- substitute qty per 1 unit of the original
  status        text not null default 'pending' check (status in ('pending','approved','rejected','retired')),
  reason        text not null,
  created_by    uuid not null references core.person(id),
  approved_by   uuid references core.person(id),
  approved_at   timestamptz,
  check (product_id <> substitute_id),
  check (approved_by is null or approved_by <> created_by),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  foreign key (substitute_id, company_id) references inventory.product (id, company_id)
);
create unique index substitution_one_live on inventory.substitution_rule (product_id, substitute_id) where status in ('pending','approved');
create trigger trg_substitution_rule_nodel before delete on inventory.substitution_rule for each row execute function core.fn_deny_delete();
create trigger trg_substitution_rule_audit after insert or update on inventory.substitution_rule for each row execute function audit.fn_row_change();

select core.fn_apply_rls('inventory', 'raw_profile');
select core.fn_apply_rls('inventory', 'lot');
select core.fn_apply_rls('inventory', 'stock_balance');
select core.fn_apply_rls('inventory', 'lot_balance');
select core.fn_apply_rls('inventory', 'stock_move');
select core.fn_apply_rls('inventory', 'receipt');
select core.fn_apply_rls('inventory', 'quarantine_hold');
select core.fn_apply_rls('inventory', 'reservation');
select core.fn_apply_rls('inventory', 'material_issue');
select core.fn_apply_rls('inventory', 'material_return');
select core.fn_apply_rls('inventory', 'wastage');
select core.fn_apply_rls('inventory', 'substitution_rule');

-- ================================================================ permissions, modules
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('inventory.receipt.post', 'inventory', 'মাল-গ্রহণ / শুরুর মজুদ পোস্ট', 'write', true, false, array['COMPANY','WAREHOUSE'], 'active', 700);
update iam.permission_catalog set status = 'active'
 where code in ('inventory.stock.read','inventory.cost.read','inventory.reserve','inventory.adjust.submit','inventory.adjust.approve',
                'mfg.material.issue','mfg.material.return','mfg.waste.submit','mfg.bom.manage','mfg.bom.read');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, 'inventory.stock.read', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER','STOREKEEPER','PROD_SUPERVISOR','PURCHASE_OFFICER','AUDITOR','WING_HEAD','ACCOUNTANT']) x
union all select x, 'inventory.cost.read', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER','ACCOUNTANT','AUDITOR']) x
union all select x, 'inventory.receipt.post', 'allow', 'COMPANY' from unnest(array['STOREKEEPER']) x
union all select x, 'inventory.reserve', 'allow', 'COMPANY' from unnest(array['STOREKEEPER','PROD_SUPERVISOR']) x
union all select x, 'inventory.adjust.approve', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER']) x
union all select x, 'mfg.material.issue', 'allow', 'COMPANY' from unnest(array['STOREKEEPER']) x
union all select x, 'mfg.material.return', 'allow', 'COMPANY' from unnest(array['STOREKEEPER','PROD_SUPERVISOR']) x
union all select x, 'mfg.waste.submit', 'allow', 'COMPANY' from unnest(array['STOREKEEPER','PROD_SUPERVISOR']) x
union all select x, 'mfg.bom.read', 'allow', 'COMPANY' from unnest(array['MD','PROD_SUPERVISOR','STOREKEEPER','QC_OFFICER']) x
union all select x, 'mfg.bom.manage', 'allow', 'COMPANY' from unnest(array['PROD_SUPERVISOR']) x
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('inventory');
select config.fn_make_module_available('mfg');

-- ================================================================ ledger engine (every stock change goes through here)
-- Posts one move. Inbound adds at p_unit_cost (moving average); outbound always leaves at the CURRENT average cost.
-- Balances are locked row by row; no balance and no lot may go below zero (E_NEGATIVE_STOCK).
create function inventory.fn_post_move(p_company uuid, p_warehouse uuid, p_product uuid, p_lot uuid, p_type text, p_qty numeric, p_unit_cost numeric,
                                       p_doc_type text, p_doc_id uuid, p_line integer, p_reason text) returns numeric
language plpgsql security definer set search_path = pg_catalog as $$
declare b inventory.stock_balance%rowtype; v_cost numeric; v_value numeric;
begin
  if p_qty is null or p_qty = 0 then raise exception 'E_INVALID_ACTION: zero quantity' using errcode = 'P0001'; end if;
  insert into inventory.stock_balance (company_id, warehouse_id, product_id) values (p_company, p_warehouse, p_product) on conflict do nothing;
  select * into b from inventory.stock_balance where company_id = p_company and warehouse_id = p_warehouse and product_id = p_product for update;
  if p_qty > 0 then
    v_cost := coalesce(p_unit_cost, case when b.qty > 0 then b.value / b.qty else 0 end);
    v_value := round(p_qty * v_cost, 4);
  else
    if b.qty + p_qty < 0 then raise exception 'E_NEGATIVE_STOCK: only % available', b.qty using errcode = 'P0001'; end if;
    v_cost := case when b.qty > 0 then b.value / b.qty else 0 end;
    v_value := case when b.qty + p_qty = 0 then -b.value else round(p_qty * v_cost, 4) end;     -- last unit clears the value exactly
  end if;
  update inventory.stock_balance set qty = b.qty + p_qty, value = greatest(b.value + v_value, 0), updated_at = clock_timestamp()
   where company_id = p_company and warehouse_id = p_warehouse and product_id = p_product;
  if p_lot is not null then
    insert into inventory.lot_balance (company_id, warehouse_id, lot_id) values (p_company, p_warehouse, p_lot) on conflict do nothing;
    update inventory.lot_balance set qty = qty + p_qty where company_id = p_company and warehouse_id = p_warehouse and lot_id = p_lot;  -- check (qty >= 0)
  end if;
  insert into inventory.stock_move (company_id, warehouse_id, product_id, lot_id, move_type, qty, unit_cost, value, doc_type, doc_id, doc_line, reason, posted_by)
  values (p_company, p_warehouse, p_product, p_lot, p_type, p_qty, round(v_cost, 6), v_value, p_doc_type, p_doc_id, coalesce(p_line, 0), p_reason, iam.fn_current_person());
  return v_cost;
exception when check_violation then
  raise exception 'E_NEGATIVE_STOCK: lot or balance would go below zero' using errcode = 'P0001';
end $$;

create function inventory.fn_available(p_company uuid, p_warehouse uuid, p_product uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce((select b.qty from inventory.stock_balance b where b.company_id = p_company and b.warehouse_id = p_warehouse and b.product_id = p_product), 0)
       - coalesce((select sum(r.qty - r.consumed_qty) from inventory.reservation r
                    where r.company_id = p_company and r.warehouse_id = p_warehouse and r.product_id = p_product and r.status = 'active'), 0)
$$;

-- FEFO (F074): earliest expiry first (then oldest receipt); expired or blocked lots are never picked.
create function inventory.fn_fefo(p_company uuid, p_warehouse uuid, p_product uuid, p_qty numeric) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare r record; left_qty numeric := p_qty; out jsonb := '[]'::jsonb; v_expired numeric := 0;
begin
  for r in select l.id, l.expiry_date, l.status, lb.qty from inventory.lot_balance lb join inventory.lot l on l.id = lb.lot_id
            where lb.company_id = p_company and lb.warehouse_id = p_warehouse and l.product_id = p_product and lb.qty > 0
            order by l.expiry_date nulls last, l.received_at loop
    if r.status <> 'available' or (r.expiry_date is not null and r.expiry_date < current_date) then v_expired := v_expired + r.qty; continue; end if;
    exit when left_qty <= 0;
    out := out || jsonb_build_array(jsonb_build_object('lot_id', r.id, 'qty', least(r.qty, left_qty)));
    left_qty := left_qty - least(r.qty, left_qty);
  end loop;
  if left_qty > 0 then
    if v_expired >= left_qty then raise exception 'E_LOT_EXPIRED: only expired or blocked lots remain for %', left_qty using errcode = 'P0001'; end if;
    raise exception 'E_NEGATIVE_STOCK: % short', left_qty using errcode = 'P0001';
  end if;
  return out;
end $$;

-- Receipt engine (F073), also used by procurement GRN later: only accepted qty posts; quarantine is held.
create function inventory.fn_post_receipt(p_company uuid, p_warehouse uuid, p_product uuid, p_lot_no text, p_supplier_lot text, p_mfg date, p_expiry date,
                                          p_accepted numeric, p_quarantine numeric, p_rejected numeric, p_unit_cost numeric, p_kind text,
                                          p_source_ref text, p_reason text) returns jsonb
language plpgsql security definer set search_path = pg_catalog as $$
declare v_lot uuid; v_rec uuid; v_hold uuid; prof inventory.raw_profile%rowtype;
begin
  if not inventory.fn_product_usable(p_company, p_product) then raise exception 'E_PRODUCT_ARCHIVED: product is not active' using errcode = 'P0001'; end if;
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse and w.company_id = p_company and w.status = 'active') then
    raise exception 'E_NOT_FOUND: warehouse' using errcode = 'P0001';
  end if;
  if coalesce(p_accepted, 0) < 0 or coalesce(p_quarantine, 0) < 0 or coalesce(p_rejected, 0) < 0 or coalesce(p_unit_cost, -1) < 0 then
    raise exception 'E_INVALID_ACTION: quantities and cost must not be negative' using errcode = 'P0001';
  end if;
  if p_expiry is not null and p_expiry < current_date then raise exception 'E_LOT_EXPIRED: lot already expired' using errcode = 'P0001'; end if;
  select * into prof from inventory.raw_profile where product_id = p_product;
  insert into inventory.lot (company_id, product_id, lot_no, supplier_lot, mfg_date, expiry_date)
  values (p_company, p_product, p_lot_no, p_supplier_lot, p_mfg,
          coalesce(p_expiry, case when prof.shelf_life_days is not null then coalesce(p_mfg, current_date) + prof.shelf_life_days end))
  on conflict (company_id, product_id, lot_no) do nothing
  returning id into v_lot;
  if v_lot is null then raise exception 'E_DUPLICATE: lot % already received', p_lot_no using errcode = 'P0001'; end if;
  insert into inventory.receipt (company_id, warehouse_id, product_id, lot_id, accepted_qty, quarantine_qty, rejected_qty, unit_cost, kind, source_ref, reason, posted_by)
  values (p_company, p_warehouse, p_product, v_lot, coalesce(p_accepted, 0), coalesce(p_quarantine, 0), coalesce(p_rejected, 0), p_unit_cost, p_kind, p_source_ref,
          p_reason, iam.fn_current_person())
  returning id into v_rec;
  if coalesce(p_accepted, 0) > 0 then
    perform inventory.fn_post_move(p_company, p_warehouse, p_product, v_lot, case when p_kind = 'opening' then 'opening' else 'receipt' end,
                                   p_accepted, p_unit_cost, 'inventory.receipt', v_rec, 1, p_reason);
  end if;
  if coalesce(p_quarantine, 0) > 0 then
    insert into inventory.quarantine_hold (company_id, receipt_id, qty) values (p_company, v_rec, p_quarantine) returning id into v_hold;
  end if;
  return jsonb_build_object('receipt_id', v_rec, 'lot_id', v_lot, 'quarantine_hold_id', v_hold);
end $$;

-- ================================================================ API
create function api.v1_raw_profile_save(p_product_id uuid, p_ingredient_type text, p_grade text, p_purchase_unit text, p_purchase_factor numeric,
                                        p_shelf_life_days integer, p_min_stock numeric, p_default_supplier text, p_fefo boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; cur inventory.raw_profile%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from inventory.product p where p.id = p_product_id and p.company_id = me.company_id and p.kind in ('raw_material','packaging')) then
    perform core.fn_raise('E_NOT_FOUND', 'raw material');
  end if;
  if coalesce(p_purchase_factor, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'purchase factor must be positive'); end if;
  select * into cur from inventory.raw_profile where product_id = p_product_id for update;
  if cur.product_id is not null and (cur.purchase_factor <> p_purchase_factor or cur.purchase_unit <> p_purchase_unit)
     and exists (select 1 from inventory.stock_move m where m.company_id = me.company_id and m.product_id = p_product_id) then
    perform core.fn_raise('E_PRODUCT_LOCKED', 'conversion is fixed once stock has moved; create a new SKU');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.raw_profile (product_id, company_id, ingredient_type, grade, purchase_unit, purchase_factor, shelf_life_days, min_stock, default_supplier, fefo)
  values (p_product_id, me.company_id, p_ingredient_type, p_grade, p_purchase_unit, p_purchase_factor, p_shelf_life_days, coalesce(p_min_stock, 0), p_default_supplier, coalesce(p_fefo, true))
  on conflict (product_id) do update set ingredient_type = excluded.ingredient_type, grade = excluded.grade, purchase_unit = excluded.purchase_unit,
    purchase_factor = excluded.purchase_factor, shelf_life_days = excluded.shelf_life_days, min_stock = excluded.min_stock,
    default_supplier = excluded.default_supplier, fefo = excluded.fefo;
  return jsonb_build_object('product_id', p_product_id);
end $$;

-- Opening stock / direct receipt (until procurement GRN): quantity in BASE units or purchase units (p_in_purchase_units).
create function api.v1_stock_receive(p_warehouse_id uuid, p_product_id uuid, p_lot_no text, p_supplier_lot text, p_mfg_date date, p_expiry_date date,
                                     p_accepted numeric, p_quarantine numeric, p_rejected numeric, p_unit_cost numeric, p_in_purchase_units boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_f numeric := 1; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.receipt.post', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if coalesce(p_in_purchase_units, false) then
    select r.purchase_factor into v_f from inventory.raw_profile r where r.product_id = p_product_id and r.company_id = me.company_id;
    if v_f is null then perform core.fn_raise('E_UNIT_AMBIGUOUS', 'no purchase unit defined'); end if;
  end if;
  j := core.fn_idem_begin(me.company_id, 'v1_stock_receive', jsonb_build_object('w', p_warehouse_id, 'p', p_product_id, 'lot', p_lot_no, 'a', p_accepted, 'q', p_quarantine));
  if j is not null then return j; end if;
  perform set_config('mohona.change_reason', p_reason, true);
  j := inventory.fn_post_receipt(me.company_id, p_warehouse_id, p_product_id, p_lot_no, p_supplier_lot, p_mfg_date, p_expiry_date,
                                 coalesce(p_accepted, 0) * v_f, coalesce(p_quarantine, 0) * v_f, coalesce(p_rejected, 0) * v_f,
                                 p_unit_cost / v_f, 'opening', null, p_reason);
  return core.fn_idem_finish(me.company_id, j);
end $$;

create function api.v1_quarantine_decide(p_hold_id uuid, p_release_qty numeric, p_reject_qty numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; h inventory.quarantine_hold%rowtype; r inventory.receipt%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.adjust.approve', iam.fn_my_company_resource(), true);
  select * into h from inventory.quarantine_hold where id = p_hold_id and company_id = me.company_id for update;
  if not found or h.status not in ('held','partly') then perform core.fn_raise('E_NOT_FOUND', 'quarantine'); end if;
  if coalesce(p_release_qty, 0) < 0 or coalesce(p_reject_qty, 0) < 0 or h.released_qty + h.rejected_qty + coalesce(p_release_qty, 0) + coalesce(p_reject_qty, 0) > h.qty then
    perform core.fn_raise('E_INVALID_ACTION', 'more than held');
  end if;
  select * into r from inventory.receipt where id = h.receipt_id;
  perform set_config('mohona.change_reason', p_reason, true);
  if coalesce(p_release_qty, 0) > 0 then
    perform inventory.fn_post_move(me.company_id, r.warehouse_id, r.product_id, r.lot_id, 'quarantine_release', p_release_qty, r.unit_cost,
                                   'inventory.quarantine', h.id, (select count(*) from inventory.stock_move m where m.doc_id = h.id)::integer + 1, p_reason);
  end if;
  update inventory.quarantine_hold set released_qty = released_qty + coalesce(p_release_qty, 0), rejected_qty = rejected_qty + coalesce(p_reject_qty, 0),
         status = case when released_qty + coalesce(p_release_qty, 0) + rejected_qty + coalesce(p_reject_qty, 0) = qty then
                         case when released_qty + coalesce(p_release_qty, 0) = 0 then 'rejected' else 'released' end else 'partly' end,
         decided_by = me.person_id, decided_at = clock_timestamp(), reason = p_reason
   where id = h.id returning * into h;
  return jsonb_build_object('hold_id', h.id, 'status', h.status);
end $$;

create function api.v1_stock_reserve(p_warehouse_id uuid, p_product_id uuid, p_qty numeric, p_batch_ref text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; v_avail numeric;
begin
  select * into me from iam.fn_require('inventory.reserve', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if coalesce(p_qty, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'qty'); end if;
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse_id and w.company_id = me.company_id and w.status = 'active') then
    perform core.fn_raise('E_NOT_FOUND', 'warehouse');
  end if;
  if not inventory.fn_product_usable(me.company_id, p_product_id) then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
  perform pg_advisory_xact_lock(hashtext(p_warehouse_id::text || p_product_id::text));
  v_avail := inventory.fn_available(me.company_id, p_warehouse_id, p_product_id);
  if p_qty > v_avail then perform core.fn_raise('E_INSUFFICIENT_STOCK', 'available ' || v_avail); end if;
  perform set_config('mohona.change_reason', coalesce(p_reason, 'reserve'), true);
  insert into inventory.reservation (company_id, warehouse_id, product_id, batch_ref, qty, created_by, reason)
  values (me.company_id, p_warehouse_id, p_product_id, p_batch_ref, p_qty, me.person_id, p_reason) returning id into v_id;
  return jsonb_build_object('reservation_id', v_id, 'available_after', v_avail - p_qty);
end $$;

create function api.v1_stock_release_reservation(p_reservation_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r inventory.reservation%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into r from inventory.reservation where id = p_reservation_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'reservation'); end if;
  select * into me from iam.fn_require('inventory.reserve', iam.fn_resource(r.company_id, null, null, null, r.warehouse_id), true);
  perform set_config('mohona.change_reason', p_reason, true);
  update inventory.reservation set status = 'released', reason = p_reason where id = r.id and status = 'active';
  if not found then perform core.fn_raise('E_INVALID_ACTION', 'not active'); end if;
  return jsonb_build_object('reservation_id', r.id, 'status', 'released');
end $$;

-- Issue against a reservation (F076). p_substitute_id: an APPROVED substitute (F079) issued instead, qty x ratio.
create function api.v1_material_issue(p_reservation_id uuid, p_qty numeric, p_substitute_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r inventory.reservation%rowtype; v_id uuid := gen_random_uuid(); v_prod uuid; v_qty numeric; v_ratio numeric := 1; alloc jsonb; a jsonb;
        lines jsonb := '[]'::jsonb; n integer := 0; v_cost numeric; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into r from inventory.reservation where id = p_reservation_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'reservation'); end if;
  select * into me from iam.fn_require('mfg.material.issue', iam.fn_resource(r.company_id, null, null, null, r.warehouse_id), true);
  j := core.fn_idem_begin(me.company_id, 'v1_material_issue', jsonb_build_object('r', p_reservation_id, 'q', p_qty, 's', p_substitute_id));
  if j is not null then return j; end if;
  select * into r from inventory.reservation where id = p_reservation_id for update;
  if r.status <> 'active' then perform core.fn_raise('E_INVALID_ACTION', 'reservation is ' || r.status); end if;
  if coalesce(p_qty, 0) <= 0 or p_qty > r.qty - r.consumed_qty then perform core.fn_raise('E_INSUFFICIENT_STOCK', 'more than reserved'); end if;
  v_prod := r.product_id;
  if p_substitute_id is not null then
    select s.ratio into v_ratio from inventory.substitution_rule s
     where s.product_id = r.product_id and s.substitute_id = p_substitute_id and s.company_id = me.company_id and s.status = 'approved';
    if v_ratio is null then perform core.fn_raise('E_SUBSTITUTE_NOT_APPROVED'); end if;
    v_prod := p_substitute_id;
  end if;
  if not inventory.fn_product_usable(me.company_id, v_prod) then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
  v_qty := p_qty * v_ratio;
  alloc := inventory.fn_fefo(me.company_id, r.warehouse_id, v_prod, v_qty);
  perform set_config('mohona.change_reason', p_reason, true);
  for a in select * from jsonb_array_elements(alloc) loop
    n := n + 1;
    v_cost := inventory.fn_post_move(me.company_id, r.warehouse_id, v_prod, (a ->> 'lot_id')::uuid, 'issue', -((a ->> 'qty')::numeric), null,
                                     'inventory.issue', v_id, n, p_reason);
    lines := lines || jsonb_build_array(jsonb_build_object('line', n, 'product_id', v_prod, 'substitute_for', case when p_substitute_id is not null then r.product_id end,
                                                           'lot_id', a ->> 'lot_id', 'qty', (a ->> 'qty')::numeric, 'unit_cost', round(v_cost, 6)));
  end loop;
  -- the issue document is written once, after the moves, with its line snapshot (immutable from then on)
  insert into inventory.material_issue (id, company_id, warehouse_id, reservation_id, batch_ref, number, lines, reason, posted_by)
  values (v_id, me.company_id, r.warehouse_id, r.id, r.batch_ref, core.fn_next_number(me.company_id, 'inventory.issue', v_id), lines, p_reason, me.person_id);
  update inventory.reservation set consumed_qty = consumed_qty + p_qty, status = case when consumed_qty + p_qty >= qty then 'consumed' else 'active' end where id = r.id;
  return core.fn_idem_finish(me.company_id, jsonb_build_object('issue_id', v_id, 'number', (select x.number from inventory.material_issue x where x.id = v_id), 'lines', lines));
end $$;

-- Return (F077): references the issue line + lot; never more than issued minus returned; back in at the issue cost.
create function api.v1_material_return(p_issue_id uuid, p_issue_line integer, p_qty numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; i inventory.material_issue%rowtype; ln jsonb; v_done numeric; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into i from inventory.material_issue where id = p_issue_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'issue'); end if;
  select * into me from iam.fn_require('mfg.material.return', iam.fn_resource(i.company_id, null, null, null, i.warehouse_id), true);
  select x into ln from jsonb_array_elements(i.lines) x where (x ->> 'line')::integer = p_issue_line;
  if ln is null then perform core.fn_raise('E_NOT_FOUND', 'issue line'); end if;
  perform pg_advisory_xact_lock(hashtext(p_issue_id::text || p_issue_line));
  v_done := coalesce((select sum(r.qty) from inventory.material_return r where r.issue_id = i.id and r.issue_line = p_issue_line), 0);
  if coalesce(p_qty, 0) <= 0 or p_qty > (ln ->> 'qty')::numeric - v_done then perform core.fn_raise('E_INVALID_ACTION', 'more than issued and not yet returned'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.material_return (company_id, issue_id, issue_line, lot_id, qty, reason, posted_by)
  values (me.company_id, i.id, p_issue_line, (ln ->> 'lot_id')::uuid, p_qty, p_reason, me.person_id) returning id into v_id;
  perform inventory.fn_post_move(me.company_id, i.warehouse_id, (ln ->> 'product_id')::uuid, (ln ->> 'lot_id')::uuid, 'return', p_qty, (ln ->> 'unit_cost')::numeric,
                                 'inventory.return', v_id, 1, p_reason);
  return jsonb_build_object('return_id', v_id, 'returned_total', v_done + p_qty);
end $$;

-- Wastage (F078): normal posts at once; abnormal waits for another person's approval and posts as its own move type.
create function api.v1_wastage_submit(p_warehouse_id uuid, p_kind text, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; l jsonb; n integer := 0; a jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.waste.submit', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), true);
  if coalesce(p_kind, '') not in ('normal','abnormal') or jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 50 then
    perform core.fn_raise('E_INVALID_ACTION', 'kind / lines');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.wastage (company_id, warehouse_id, kind, lines, reason, created_by, status)
  values (me.company_id, p_warehouse_id, p_kind, p_lines, p_reason, me.person_id, 'pending') returning id into v_id;
  if p_kind = 'normal' then
    for l in select * from jsonb_array_elements(p_lines) loop
      for a in select * from jsonb_array_elements(inventory.fn_fefo(me.company_id, p_warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
        n := n + 1;
        perform inventory.fn_post_move(me.company_id, p_warehouse_id, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'waste_normal', -((a ->> 'qty')::numeric), null,
                                       'inventory.wastage', v_id, n, p_reason);
      end loop;
    end loop;
    update inventory.wastage set status = 'posted' where id = v_id;
  end if;
  return jsonb_build_object('wastage_id', v_id, 'status', (select w.status from inventory.wastage w where w.id = v_id));
end $$;

create function api.v1_wastage_decide(p_wastage_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; w inventory.wastage%rowtype; l jsonb; a jsonb; n integer := 0;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.adjust.approve', iam.fn_my_company_resource(), true);
  select * into w from inventory.wastage where id = p_wastage_id and company_id = me.company_id for update;
  if not found or w.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending wastage'); end if;
  if w.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_approve then
    for l in select * from jsonb_array_elements(w.lines) loop
      for a in select * from jsonb_array_elements(inventory.fn_fefo(me.company_id, w.warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
        n := n + 1;
        perform inventory.fn_post_move(me.company_id, w.warehouse_id, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'waste_abnormal', -((a ->> 'qty')::numeric), null,
                                       'inventory.wastage', w.id, n, p_reason);
      end loop;
    end loop;
  end if;
  update inventory.wastage set status = case when p_approve then 'posted' else 'rejected' end, decided_by = me.person_id, decided_at = clock_timestamp() where id = w.id;
  return jsonb_build_object('wastage_id', w.id, 'status', case when p_approve then 'posted' else 'rejected' end);
end $$;

-- Substitution (F079): proposed by BOM managers, approved by ANOTHER person with the adjust-approve right.
create function api.v1_substitution_propose(p_product_id uuid, p_substitute_id uuid, p_ratio numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('mfg.bom.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_ratio, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'ratio'); end if;
  if (select count(*) from inventory.product p where p.company_id = me.company_id and p.id in (p_product_id, p_substitute_id) and p.kind in ('raw_material','packaging')) <> 2 then
    perform core.fn_raise('E_NOT_FOUND', 'raw materials');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into inventory.substitution_rule (company_id, product_id, substitute_id, ratio, reason, created_by)
  values (me.company_id, p_product_id, p_substitute_id, p_ratio, p_reason, me.person_id) returning id into v_id;
  return jsonb_build_object('rule_id', v_id, 'status', 'pending');
end $$;

create function api.v1_substitution_decide(p_rule_id uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s inventory.substitution_rule%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('inventory.adjust.approve', iam.fn_my_company_resource(), true);
  select * into s from inventory.substitution_rule where id = p_rule_id and company_id = me.company_id for update;
  if not found or s.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending substitution'); end if;
  if s.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update inventory.substitution_rule set status = case when p_approve then 'approved' else 'rejected' end,
         approved_by = case when p_approve then me.person_id end, approved_at = case when p_approve then clock_timestamp() end where id = s.id;
  return jsonb_build_object('rule_id', s.id, 'status', case when p_approve then 'approved' else 'rejected' end);
end $$;

-- Read models: balances (values only with the cost right), lots with expiry state, ledger.
create function api.v1_stock_balances(p_warehouse_id uuid default null, p_product_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_cost boolean;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), false);
  select d.allowed into v_cost from iam.fn_authorize('inventory.cost.read', iam.fn_resource(me.company_id), false) d;
  return coalesce((select jsonb_agg(jsonb_build_object('warehouse_id', b.warehouse_id, 'product_id', b.product_id, 'sku', p.sku, 'name_bn', p.name_bn, 'unit', p.base_unit,
           'qty', b.qty, 'available', inventory.fn_available(me.company_id, b.warehouse_id, b.product_id),
           'avg_cost', case when v_cost and b.qty > 0 then round(b.value / b.qty, 4) end, 'value', case when v_cost then b.value end,
           'below_min', b.qty < coalesce((select r.min_stock from inventory.raw_profile r where r.product_id = b.product_id), 0)) order by p.sku)
     from inventory.stock_balance b join inventory.product p on p.id = b.product_id
    where b.company_id = me.company_id and (p_warehouse_id is null or b.warehouse_id = p_warehouse_id) and (p_product_id is null or b.product_id = p_product_id)), '[]'::jsonb);
end $$;

create function api.v1_stock_lots(p_product_id uuid, p_warehouse_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_resource(iam.fn_context_company(), null, null, null, p_warehouse_id), false);
  return coalesce((select jsonb_agg(jsonb_build_object('lot_id', l.id, 'lot_no', l.lot_no, 'warehouse_id', lb.warehouse_id, 'qty', lb.qty, 'expiry_date', l.expiry_date,
           'expired', l.expiry_date is not null and l.expiry_date < current_date, 'status', l.status) order by l.expiry_date nulls last, l.received_at)
     from inventory.lot l join inventory.lot_balance lb on lb.lot_id = l.id
    where l.company_id = me.company_id and l.product_id = p_product_id and (p_warehouse_id is null or lb.warehouse_id = p_warehouse_id) and lb.qty > 0), '[]'::jsonb);
end $$;

create function api.v1_stock_moves(p_product_id uuid, p_limit integer default 100) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_cost boolean;
begin
  select * into me from iam.fn_require('inventory.stock.read', iam.fn_my_company_resource(), false);
  select d.allowed into v_cost from iam.fn_authorize('inventory.cost.read', iam.fn_resource(me.company_id), false) d;
  return coalesce((select jsonb_agg(x) from (select jsonb_build_object('id', m.id, 'type', m.move_type, 'qty', m.qty, 'lot_id', m.lot_id, 'warehouse_id', m.warehouse_id,
           'unit_cost', case when v_cost then m.unit_cost end, 'value', case when v_cost then m.value end, 'doc_type', m.doc_type, 'doc_id', m.doc_id, 'at', m.posted_at) x
     from inventory.stock_move m where m.company_id = me.company_id and m.product_id = p_product_id order by m.id desc limit greatest(1, least(coalesce(p_limit, 100), 1000))) q), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_raw_profile_save(uuid, text, text, text, numeric, integer, numeric, text, boolean, text)',
      'api.v1_stock_receive(uuid, uuid, text, text, date, date, numeric, numeric, numeric, numeric, boolean, text)',
      'api.v1_quarantine_decide(uuid, numeric, numeric, text)', 'api.v1_stock_reserve(uuid, uuid, numeric, text, text)',
      'api.v1_stock_release_reservation(uuid, text)', 'api.v1_material_issue(uuid, numeric, uuid, text)', 'api.v1_material_return(uuid, integer, numeric, text)',
      'api.v1_wastage_submit(uuid, text, jsonb, text)', 'api.v1_wastage_decide(uuid, boolean, text)',
      'api.v1_substitution_propose(uuid, uuid, numeric, text)', 'api.v1_substitution_decide(uuid, boolean, text)',
      'api.v1_stock_balances(uuid, uuid)', 'api.v1_stock_lots(uuid, uuid)', 'api.v1_stock_moves(uuid, integer)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- 20261108002100_notify_audit_governance.sql  (S22)
-- Notifications (blueprint NOTIFICATIONS MOS-F153-211..220) + audit governance remainder (AUDIT_GOVERNANCE 261, 266,
-- 269, 270):
--   211 fixed categories (approval, due, stock, hr, security, form, system) — deterministic rules, no AI engine
--   212 personal inbox; texts carry no confidential payload (no amounts or field values, only a safe reference)
--   213 approval reminders after a configured age — reminders never approve anything
--   214 per-person read / unread / archive state (no effect on any posting)
--   215 priority banner for critical items (account locked, broadcasts marked critical) with generic wording
--   216 channel preferences (in-app, SMS, e-mail when connected); mandatory channels cannot be switched off
--   217 manual escalation policy per document type (after N minutes to a position) — the maker is never notified as
--       an approver and escalation grants nothing
--   218 Bengali templates (company overrides) with whitelisted {{placeholders}}; values are sanitised
--   219 delivery log with idempotent keys, retries with back-off, failures recorded
--   220 retention: notifications are cleaned up after N days; the audit trail is never touched
--   261 audit event search API · 266 policy publication: proposal -> simulation -> independent critical reviewer ->
--   effective date (approval policies) · 269 tamper-evident audit export bundle (hash chain, redaction, log)
--   270 audit retention status; audit can never become a recycle class
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ notification tables
create table notify.category (
  code               text primary key check (code ~ '^[a-z]{2,20}$'),
  name_bn            text not null,
  default_priority   text not null check (default_priority in ('normal','high','critical')),
  mandatory_channels text[] not null default array['in_app'],
  sort_order         integer not null default 0
);
create trigger trg_notify_category_nodel before delete on notify.category for each row execute function core.fn_deny_delete();

create table notify.template (
  code        text primary key check (code ~ '^[a-z]+\.[a-z_]{2,40}$'),
  category    text not null references notify.category(code),
  title_bn    text not null,
  body_bn     text not null,
  vars        text[] not null default array[]::text[]
);
create trigger trg_notify_template_nodel before delete on notify.template for each row execute function core.fn_deny_delete();

create table notify.template_override (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null references notify.template(code),
  title_bn    text not null check (length(btrim(title_bn)) between 1 and 120),
  body_bn     text not null check (length(btrim(body_bn)) between 1 and 500),
  version     integer not null check (version >= 1),
  status      text not null default 'active' check (status in ('active','superseded')),
  set_by      uuid, set_at timestamptz not null default clock_timestamp(),
  reason      text not null check (length(btrim(reason)) > 0)
);
create unique index template_override_one_active on notify.template_override (company_id, code) where status = 'active';
create trigger trg_template_override_guard before update on notify.template_override for each row execute function config.fn_history_only_supersede();
create trigger trg_template_override_nodel before delete on notify.template_override for each row execute function core.fn_deny_delete();
create trigger trg_template_override_audit after insert or update on notify.template_override for each row execute function audit.fn_row_change();

-- One notification per recipient. Deliberately NOT audited row by row (volume); its evidence is notify.delivery.
-- Deletable only by the retention job (F220).
create table notify.notification (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  person_id     uuid not null references core.person(id),
  category      text not null references notify.category(code),
  template_code text references notify.template(code),
  priority      text not null check (priority in ('normal','high','critical')),
  title_bn      text not null,
  body_bn       text not null,
  link_kind     text check (link_kind is null or link_kind ~ '^[a-z_]{2,30}$'),
  link_id       uuid,
  dedupe_key    text not null check (length(dedupe_key) between 3 and 200),
  created_at    timestamptz not null default clock_timestamp(),
  read_at       timestamptz,
  archived_at   timestamptz,
  unique (person_id, dedupe_key)
);
create index notification_inbox on notify.notification (person_id, company_id, created_at desc) where archived_at is null;
create function notify.fn_notification_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['read_at','archived_at']) <> (to_jsonb(new) - array['read_at','archived_at']) then
    raise exception 'E_IMMUTABLE: a notification text never changes' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_notification_guard before update on notify.notification for each row execute function notify.fn_notification_guard();

create table notify.delivery (
  id              uuid primary key default gen_random_uuid(),
  notification_id uuid not null references notify.notification(id) on delete cascade,
  company_id      uuid not null,
  channel         text not null check (channel in ('in_app','sms','email')),
  status          text not null default 'queued' check (status in ('queued','sent','failed','skipped')),
  attempts        integer not null default 0 check (attempts between 0 and 10),
  next_attempt_at timestamptz not null default clock_timestamp(),
  last_error      text,
  delivered_at    timestamptz,
  created_at      timestamptz not null default clock_timestamp(),
  unique (notification_id, channel)                      -- idempotent delivery key (F219)
);
create index delivery_due on notify.delivery (channel, next_attempt_at) where status = 'queued';

create table notify.preference (
  company_id  uuid not null references core.company(id),
  person_id   uuid not null references core.person(id),
  category    text not null references notify.category(code),
  channel     text not null check (channel in ('in_app','sms','email')),
  enabled     boolean not null,
  updated_at  timestamptz not null default clock_timestamp(),
  primary key (company_id, person_id, category, channel)
);
create trigger trg_preference_audit after insert or update on notify.preference for each row execute function audit.fn_row_change();

create table notify.escalation_policy (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  document_type  text not null check (document_type ~ '^[a-z][a-z0-9_.%]{1,60}$'),
  after_minutes  integer not null check (after_minutes between 15 and 43200),
  position_code  text not null,
  version        integer not null check (version >= 1),
  status         text not null default 'active' check (status in ('active','superseded')),
  set_by         uuid, set_at timestamptz not null default clock_timestamp(),
  reason         text not null check (length(btrim(reason)) > 0),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index escalation_one_active on notify.escalation_policy (company_id, document_type) where status = 'active';
create trigger trg_escalation_guard before update on notify.escalation_policy for each row execute function config.fn_history_only_supersede();
create trigger trg_escalation_nodel before delete on notify.escalation_policy for each row execute function core.fn_deny_delete();
create trigger trg_escalation_audit after insert or update on notify.escalation_policy for each row execute function audit.fn_row_change();

select core.fn_apply_rls('notify', 'category');
select core.fn_apply_rls('notify', 'template');
select core.fn_apply_rls('notify', 'template_override');
select core.fn_apply_rls('notify', 'notification');
select core.fn_apply_rls('notify', 'delivery');
select core.fn_apply_rls('notify', 'preference');
select core.fn_apply_rls('notify', 'escalation_policy');

insert into notify.category (code, name_bn, default_priority, mandatory_channels, sort_order) values
  ('approval', 'অনুমোদন', 'high', array['in_app'], 10), ('due', 'মেয়াদ/বকেয়া', 'normal', array['in_app'], 20),
  ('stock', 'মজুদ', 'high', array['in_app'], 30), ('hr', 'কর্মী', 'normal', array['in_app'], 40),
  ('security', 'নিরাপত্তা', 'critical', array['in_app','sms'], 50), ('form', 'ফর্ম', 'normal', array['in_app'], 60),
  ('system', 'ঘোষণা', 'normal', array['in_app'], 70);
insert into notify.template (code, category, title_bn, body_bn, vars) values
  ('approval.pending',  'approval', 'অনুমোদন দরকার', '{{doc}} আপনার অনুমোদনের অপেক্ষায়।', array['doc']),
  ('approval.reminder', 'approval', 'অনুমোদন এখনো বাকি', '{{doc}} {{hours}} ঘণ্টা ধরে অপেক্ষায়।', array['doc','hours']),
  ('approval.escalated','approval', 'অনুমোদন বিলম্বিত', '{{doc}} নির্ধারিত সময় পেরিয়েছে; দেখুন।', array['doc']),
  ('approval.decided',  'approval', 'সিদ্ধান্ত হয়েছে', '{{doc}}: {{decision}}।', array['doc','decision']),
  ('security.locked',   'security', 'লগইন লক হয়েছে', 'ভুল PIN-এর কারণে আপনার লগইন সাময়িক লক। আপনি না হলে এখনই জানান।', array[]::text[]),
  ('system.broadcast',  'system',   '{{title}}', '{{body}}', array['title','body']);

insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('notify.template.manage',   'notify', 'নোটিফিকেশন-লেখা', 'admin', false, false, array['COMPANY'], 'active', 1110),
  ('notify.escalation.manage', 'notify', 'বিলম্ব-ঊর্ধ্বগমন নীতি', 'admin', true, false, array['COMPANY'], 'active', 1120);
update iam.permission_catalog set status = 'active' where code in ('notify.inbox.read','notify.broadcast.send','audit.export');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'notify.inbox.read', 'allow', 'SELF' from iam.position_template t where not t.is_supreme
union all select 'MD', 'notify.broadcast.send', 'allow', 'COMPANY' union all select 'WING_HEAD', 'notify.broadcast.send', 'allow', 'WING'
union all select 'AUDITOR', 'audit.export', 'allow', 'COMPANY';
select iam.fn_backfill_template_rules(null);
update config.module_catalog set permission_modules = array['notify'] where code = 'notify';
select config.fn_make_module_available('notify');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('notify.retention_days',              'notify', 'int', '90', 7, 730, null, 'নোটিফিকেশন রাখার মেয়াদ (দিন)', 'MOS-F153-220', false, 1100),
  ('notify.approval.remind_after_hours', 'notify', 'int', '24', 1, 720, null, 'কত ঘণ্টা পর অনুমোদন-স্মরণ', 'MOS-F153-213', false, 1110),
  ('notify.delivery.max_attempts',       'notify', 'int', '5', 1, 10, null, 'SMS/ইমেইল সর্বোচ্চ চেষ্টা', 'MOS-F153-219', false, 1120),
  ('governance.policy_review.required',  'governance', 'bool', 'true', null, null, null, 'নীতি-পরিবর্তনে স্বাধীন পর্যালোচক বাধ্যতামূলক', 'MOS-F153-266', true, 1130),
  ('governance.critical_reviewers',      'governance', 'text_array', '["MD","AUDITOR"]', null, null, null, 'নীতি-পর্যালোচক পদ', 'MOS-F153-266', true, 1140);

alter table core.recycle_class add constraint recycle_class_never_audit check (code !~ '^audit\.');   -- F270

-- ================================================================ rendering + creation
-- Sanitised placeholder value: no markup/control characters, bounded length.
create function notify.fn_clean(p text) returns text
language sql immutable set search_path = pg_catalog as $$
  select left(regexp_replace(regexp_replace(coalesce(p, ''), '[<>{}`$[:cntrl:]]', '', 'g'), '\s+', ' ', 'g'), 120)
$$;

-- Template text check (F218): only declared {{vars}}; everything else must be free of markup / scripts.
create function notify.fn_template_ok(p_text text, p_vars text[]) returns boolean
language plpgsql immutable set search_path = pg_catalog as $$
declare v text;
begin
  for v in select m[1] from regexp_matches(coalesce(p_text, ''), '\{\{([^}]*)\}\}', 'g') m loop
    if not (v = any (p_vars)) then return false; end if;
  end loop;
  return not config.fn_form_text_unsafe(regexp_replace(coalesce(p_text, ''), '\{\{[a-z_]+\}\}', '', 'g'));
end $$;

create function notify.fn_render(p_text text, p_vals jsonb) returns text
language plpgsql immutable set search_path = pg_catalog as $$
declare k text; v text; out text := p_text;
begin
  for k, v in select * from jsonb_each_text(coalesce(p_vals, '{}'::jsonb)) loop
    out := replace(out, '{{' || k || '}}', notify.fn_clean(v));
  end loop;
  return regexp_replace(out, '\{\{[a-z_]+\}\}', '', 'g');
end $$;

-- Safe label of a document type (never the amount or the content).
create function notify.fn_doc_label(p_document_type text) returns text
language sql immutable set search_path = pg_catalog as $$
  select case
    when p_document_type like 'forms.%' then 'ফর্ম ' || upper(substr(p_document_type, 7))
    when p_document_type = 'hr.employment_change' then 'কর্মী-পরিবর্তন'
    when p_document_type = 'iam.md_appointment' then 'এমডি-নিয়োগ'
    when p_document_type like 'design.%' then 'ডিজাইন প্রকাশ'
    when p_document_type = 'config.rule_publish' then 'নিয়ম প্রকাশ'
    else 'নথি (' || p_document_type || ')' end
$$;

-- Creates one notification (idempotent by person + dedupe key) and its deliveries per enabled channel.
create function notify.fn_send(p_company uuid, p_person uuid, p_template text, p_vals jsonb, p_link_kind text, p_link_id uuid, p_dedupe text,
                               p_priority text default null) returns uuid
language plpgsql security definer set search_path = pg_catalog as $$
declare t notify.template%rowtype; o notify.template_override%rowtype; cat notify.category%rowtype; v_id uuid; ch text;
begin
  select * into t from notify.template where code = p_template;
  if not found or p_person is null then return null; end if;
  if not exists (select 1 from iam.company_membership m where m.company_id = p_company and m.person_id = p_person and m.status = 'active') then return null; end if;
  select * into cat from notify.category where code = t.category;
  select * into o from notify.template_override x where x.company_id = p_company and x.code = p_template and x.status = 'active';
  insert into notify.notification (company_id, person_id, category, template_code, priority, title_bn, body_bn, link_kind, link_id, dedupe_key)
  values (p_company, p_person, t.category, t.code, coalesce(p_priority, cat.default_priority),
          left(notify.fn_render(coalesce(o.title_bn, t.title_bn), p_vals), 120), left(notify.fn_render(coalesce(o.body_bn, t.body_bn), p_vals), 500),
          p_link_kind, p_link_id, p_dedupe)
  on conflict (person_id, dedupe_key) do nothing
  returning id into v_id;
  if v_id is null then return null; end if;
  foreach ch in array array['in_app','sms','email'] loop
    if ch = any (cat.mandatory_channels)
       or coalesce((select p.enabled from notify.preference p where p.company_id = p_company and p.person_id = p_person and p.category = t.category and p.channel = ch),
                   ch = 'in_app') then
      insert into notify.delivery (notification_id, company_id, channel, status, delivered_at)
      values (v_id, p_company, ch, case when ch = 'in_app' then 'sent' else 'queued' end, case when ch = 'in_app' then clock_timestamp() end)
      on conflict do nothing;
    end if;
  end loop;
  return v_id;
end $$;

-- Who may decide this request (never the maker; never auto-approval). Bounded to 50 people.
create function notify.fn_approvers(r core.approval_request) returns setof uuid
language plpgsql stable security definer set search_path = pg_catalog as $$
declare x record; res iam.resource; d record; n integer := 0;
begin
  res := iam.fn_resource(r.company_id, (r.resource ->> 'wing_id')::uuid, (r.resource ->> 'department_id')::uuid, (r.resource ->> 'location_id')::uuid,
                         (r.resource ->> 'warehouse_id')::uuid, (r.resource ->> 'owner_person_id')::uuid, null);
  for x in select a.id, a.position_code, pc.is_supreme, m.person_id, a.home_wing_id, a.home_department_id, a.home_location_id
             from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
             join iam.position_catalog pc on pc.company_id = a.company_id and pc.code = a.position_code
            where a.company_id = r.company_id and a.status = 'active' and m.status = 'active' and m.person_id <> r.maker_person_id loop
    select * into d from iam.fn_decide(r.company_id, x.id, x.position_code, x.is_supreme, x.person_id, x.home_wing_id, x.home_department_id, x.home_location_id,
                                       'approval.decide', res, true);
    continue when not d.allowed;
    if r.approver_permission is not null and not x.is_supreme then
      select * into d from iam.fn_decide(r.company_id, x.id, x.position_code, x.is_supreme, x.person_id, x.home_wing_id, x.home_department_id, x.home_location_id,
                                         r.approver_permission, res, true);
      continue when not d.allowed;
    end if;
    return next x.person_id;
    n := n + 1;
    exit when n >= 50;
  end loop;
end $$;

-- Producer: approval engine events.
create function notify.fn_on_approval() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare p uuid;
begin
  if tg_op = 'INSERT' and new.status = 'pending' then
    for p in select distinct x from notify.fn_approvers(new) x loop
      perform notify.fn_send(new.company_id, p, 'approval.pending', jsonb_build_object('doc', notify.fn_doc_label(new.document_type)),
                             'approval_request', new.id, 'approval:' || new.id);
    end loop;
  elsif tg_op = 'UPDATE' and old.status = 'pending' and new.status in ('approved','rejected') then
    perform notify.fn_send(new.company_id, new.maker_person_id, 'approval.decided',
                           jsonb_build_object('doc', notify.fn_doc_label(new.document_type), 'decision', case new.status when 'approved' then 'অনুমোদিত' else 'প্রত্যাখ্যাত' end),
                           'approval_request', new.id, 'decided:' || new.id);
  end if;
  return null;
end $$;
create trigger trg_approval_notify after insert or update of status on core.approval_request for each row execute function notify.fn_on_approval();

-- Producer: login locked -> the person's own critical banner, in every company they belong to (no details).
create function notify.fn_on_login_attempt() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare c uuid;
begin
  if new.outcome = 'locked' and new.kind = 'pin_login' and new.person_id is not null then
    for c in select m.company_id from iam.company_membership m where m.person_id = new.person_id and m.status = 'active' loop
      perform notify.fn_send(c, new.person_id, 'security.locked', '{}'::jsonb, null, null, 'locked:' || to_char(new.occurred_at, 'YYYYMMDDHH24'), 'critical');
    end loop;
  end if;
  return null;
end $$;
create trigger trg_login_attempt_notify after insert on iam.login_attempt for each row execute function notify.fn_on_login_attempt();

-- ================================================================ notification API
create function api.v1_notify_inbox(p_unread_only boolean default false, p_limit integer default 50) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(x order by x ->> 'created_at' desc) from (
    select jsonb_build_object('id', n.id, 'category', n.category, 'priority', n.priority, 'title_bn', n.title_bn, 'body_bn', n.body_bn,
                              'link_kind', n.link_kind, 'link_id', n.link_id, 'created_at', n.created_at, 'read', n.read_at is not null) x
      from notify.notification n
     where n.person_id = me.person_id and n.company_id = me.company_id and n.archived_at is null and (not coalesce(p_unread_only, false) or n.read_at is null)
     order by n.created_at desc limit greatest(1, least(coalesce(p_limit, 50), 200))) q), '[]'::jsonb);
end $$;

-- read | unread | archive (own notifications only; no effect on any document)
create function api.v1_notify_mark(p_ids uuid[], p_action text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; n integer;
begin
  select * into me from iam.fn_context(false);
  if coalesce(p_action, '') not in ('read','unread','archive') then perform core.fn_raise('E_INVALID_ACTION', p_action); end if;
  update notify.notification x
     set read_at = case p_action when 'read' then coalesce(x.read_at, clock_timestamp()) when 'unread' then null else coalesce(x.read_at, clock_timestamp()) end,
         archived_at = case when p_action = 'archive' then clock_timestamp() else x.archived_at end
   where x.person_id = me.person_id and x.company_id = me.company_id and x.id = any (coalesce(p_ids, array[]::uuid[]));
  get diagnostics n = row_count;
  return n;
end $$;

-- Critical, unread items for the top banner (F215).
create function api.v1_notify_banner() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'title_bn', n.title_bn, 'body_bn', n.body_bn, 'category', n.category) order by n.created_at desc)
                     from notify.notification n
                    where n.person_id = me.person_id and n.company_id = me.company_id and n.priority = 'critical' and n.read_at is null and n.archived_at is null), '[]'::jsonb);
end $$;

create function api.v1_notify_preferences() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('category', c.code, 'name_bn', c.name_bn, 'mandatory', to_jsonb(c.mandatory_channels),
           'in_app', true,
           'sms', 'sms' = any (c.mandatory_channels) or coalesce((select p.enabled from notify.preference p where p.company_id = me.company_id and p.person_id = me.person_id and p.category = c.code and p.channel = 'sms'), false),
           'email', 'email' = any (c.mandatory_channels) or coalesce((select p.enabled from notify.preference p where p.company_id = me.company_id and p.person_id = me.person_id and p.category = c.code and p.channel = 'email'), false))
           order by c.sort_order) from notify.category c), '[]'::jsonb);
end $$;

create function api.v1_notify_set_preference(p_category text, p_channel text, p_enabled boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c notify.category%rowtype;
begin
  select * into me from iam.fn_context(true);
  select * into c from notify.category where code = p_category;
  if not found or coalesce(p_channel, '') not in ('in_app','sms','email') or p_enabled is null then perform core.fn_raise('E_INVALID_ACTION', 'category / channel'); end if;
  if not p_enabled and p_channel = any (c.mandatory_channels) then perform core.fn_raise('E_NOTIFY_MANDATORY', p_category || '/' || p_channel); end if;
  perform set_config('mohona.change_reason', 'notification preference', true);
  insert into notify.preference (company_id, person_id, category, channel, enabled) values (me.company_id, me.person_id, p_category, p_channel, p_enabled)
  on conflict (company_id, person_id, category, channel) do update set enabled = excluded.enabled, updated_at = clock_timestamp();
  return jsonb_build_object('category', p_category, 'channel', p_channel, 'enabled', p_enabled);
end $$;

create function api.v1_notify_set_template(p_code text, p_title_bn text, p_body_bn text, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; t notify.template%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('notify.template.manage', iam.fn_my_company_resource(), true);
  select * into t from notify.template where code = p_code;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'template'); end if;
  if not notify.fn_template_ok(p_title_bn, t.vars) or not notify.fn_template_ok(p_body_bn, t.vars) then
    perform core.fn_raise('E_NOTIFY_TEMPLATE', 'allowed placeholders: ' || array_to_string(t.vars, ', '));
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update notify.template_override set status = 'superseded' where company_id = me.company_id and code = p_code and status = 'active';
  v_next := coalesce((select max(o.version) from notify.template_override o where o.company_id = me.company_id and o.code = p_code), 0) + 1;
  insert into notify.template_override (company_id, code, title_bn, body_bn, version, set_by, reason) values (me.company_id, p_code, p_title_bn, p_body_bn, v_next, me.person_id, p_reason);
  return v_next;
end $$;

-- Escalation (F217): after N minutes a pending request is shown to the holders of a position. Informational only.
create function api.v1_notify_set_escalation(p_document_type text, p_after_minutes integer, p_position_code text, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('notify.escalation.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  update notify.escalation_policy set status = 'superseded' where company_id = me.company_id and document_type = p_document_type and status = 'active';
  v_next := coalesce((select max(e.version) from notify.escalation_policy e where e.company_id = me.company_id and e.document_type = p_document_type), 0) + 1;
  insert into notify.escalation_policy (company_id, document_type, after_minutes, position_code, version, set_by, reason)
  values (me.company_id, p_document_type, p_after_minutes, p_position_code, v_next, me.person_id, p_reason);
  return v_next;
end $$;

-- Announcement to everyone in the company (or one wing). Text sanitised; critical = banner.
create function api.v1_notify_broadcast(p_title_bn text, p_body_bn text, p_wing_id uuid, p_priority text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p uuid; n integer := 0; v_key text := 'broadcast:' || gen_random_uuid();
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('notify.broadcast.send', iam.fn_resource(iam.fn_context_company(), p_wing_id), true);
  if coalesce(p_priority, 'normal') not in ('normal','high','critical') or length(btrim(coalesce(p_title_bn, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'title / priority'); end if;
  if config.fn_form_text_unsafe(p_title_bn) or config.fn_form_text_unsafe(p_body_bn) then perform core.fn_raise('E_NOTIFY_TEMPLATE', 'markup is not allowed'); end if;
  for p in select distinct m.person_id from iam.company_membership m
            where m.company_id = me.company_id and m.status = 'active'
              and (p_wing_id is null or exists (select 1 from iam.position_assignment a where a.membership_id = m.id and a.status = 'active' and a.home_wing_id = p_wing_id)) loop
    if notify.fn_send(me.company_id, p, 'system.broadcast', jsonb_build_object('title', p_title_bn, 'body', coalesce(p_body_bn, '')), null, null, v_key,
                      coalesce(p_priority, 'normal')) is not null then n := n + 1; end if;
  end loop;
  perform audit.fn_append(me.company_id, 'notify.broadcast', 'notify.notification', null, 'success',
                          jsonb_build_object('recipients', n, 'wing_id', p_wing_id, 'priority', p_priority), p_reason);
  return jsonb_build_object('recipients', n);
end $$;

-- Delivery evidence (F219) for one notification (audit readers).
create function api.v1_notify_deliveries(p_notification_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('channel', d.channel, 'status', d.status, 'attempts', d.attempts, 'last_error', d.last_error,
                                                       'delivered_at', d.delivered_at, 'next_attempt_at', d.next_attempt_at) order by d.channel)
                     from notify.delivery d where d.notification_id = p_notification_id and d.company_id = me.company_id), '[]'::jsonb);
end $$;

-- ================================================================ notification jobs (platform)
-- Reminders (F213), escalations (F217), retention (F220). Deterministic; never decides anything.
create function svc.v1_notify_run() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare r core.approval_request%rowtype; p uuid; e record; n_rem integer := 0; n_esc integer := 0; n_del integer := 0; v_hours integer;
begin
  perform set_config('mohona.company_scope', '', true);
  for r in select * from core.approval_request x where x.status = 'pending' loop
    v_hours := config.fn_get_int(r.company_id, 'notify.approval.remind_after_hours');
    if r.created_at <= clock_timestamp() - make_interval(hours => v_hours) then
      for p in select distinct x from notify.fn_approvers(r) x loop
        if notify.fn_send(r.company_id, p, 'approval.reminder',
                          jsonb_build_object('doc', notify.fn_doc_label(r.document_type), 'hours', floor(extract(epoch from clock_timestamp() - r.created_at) / 3600)::integer),
                          'approval_request', r.id, 'remind:' || r.id || ':' || to_char(clock_timestamp(), 'YYYYMMDD')) is not null then n_rem := n_rem + 1; end if;
      end loop;
    end if;
    for e in select * from notify.escalation_policy x where x.company_id = r.company_id and x.status = 'active'
               and r.document_type like x.document_type and r.created_at <= clock_timestamp() - make_interval(mins => x.after_minutes) loop
      for p in select distinct m.person_id from iam.position_assignment a join iam.company_membership m on m.id = a.membership_id
                where a.company_id = r.company_id and a.position_code = e.position_code and a.status = 'active' and m.person_id <> r.maker_person_id loop
        if notify.fn_send(r.company_id, p, 'approval.escalated', jsonb_build_object('doc', notify.fn_doc_label(r.document_type)),
                          'approval_request', r.id, 'escalate:' || r.id) is not null then n_esc := n_esc + 1; end if;
      end loop;
    end loop;
  end loop;
  delete from notify.notification x
   where x.created_at < clock_timestamp() - make_interval(days => config.fn_get_int(x.company_id, 'notify.retention_days'));
  get diagnostics n_del = row_count;
  return jsonb_build_object('reminders', n_rem, 'escalations', n_esc, 'cleaned', n_del);
end $$;

-- SMS / e-mail sender (Edge Function) claims due deliveries; the text is the notification's own (already safe).
create function svc.v1_notify_claim(p_channel text, p_limit integer default 50) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform set_config('mohona.company_scope', '', true);
  return coalesce((select jsonb_agg(jsonb_build_object('delivery_id', d.id, 'person_id', n.person_id, 'title_bn', n.title_bn, 'body_bn', n.body_bn,
                                                       'phone', case when p_channel = 'sms' then core.fn_phone_canonical(pe.phone) end,
                                                       'email', case when p_channel = 'email' then pe.email end))
                     from notify.delivery d join notify.notification n on n.id = d.notification_id join core.person pe on pe.id = n.person_id
                    where d.id in (select x.id from notify.delivery x where x.channel = p_channel and x.status = 'queued' and x.next_attempt_at <= clock_timestamp()
                                    order by x.next_attempt_at limit greatest(1, least(coalesce(p_limit, 50), 500)) for update skip locked)), '[]'::jsonb);
end $$;

-- Result of one attempt: sent, or failed with exponential back-off until max attempts (then failed for good).
create function svc.v1_notify_result(p_delivery_id uuid, p_ok boolean, p_error text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare d notify.delivery%rowtype; v_max integer;
begin
  perform set_config('mohona.company_scope', '', true);
  select * into d from notify.delivery where id = p_delivery_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'delivery'); end if;
  if d.status <> 'queued' then return jsonb_build_object('status', d.status, 'duplicate', true); end if;     -- idempotent
  v_max := config.fn_get_int(d.company_id, 'notify.delivery.max_attempts');
  if p_ok then
    update notify.delivery set status = 'sent', attempts = d.attempts + 1, delivered_at = clock_timestamp(), last_error = null where id = d.id;
  else
    update notify.delivery set attempts = d.attempts + 1, last_error = left(p_error, 200),
           status = case when d.attempts + 1 >= v_max then 'failed' else 'queued' end,
           next_attempt_at = clock_timestamp() + make_interval(mins => (power(2, d.attempts + 1))::integer) where id = d.id;
  end if;
  return jsonb_build_object('status', (select x.status from notify.delivery x where x.id = d.id));
end $$;

-- ================================================================ audit governance
-- Detail keys that never leave in clear through the audit APIs (the base tables already keep values out of audit,
-- this is a second line for older or generic rows).
create function audit.fn_redact(p_detail jsonb) returns jsonb
language sql immutable set search_path = pg_catalog as $$
  select coalesce(p_detail, '{}'::jsonb)
       #- '{new,pin_hash}' #- '{old,pin_hash}' #- '{new,refresh_hash}' #- '{old,refresh_hash}' #- '{new,salary}' #- '{old,salary}'
       #- '{new,field_values}' #- '{old,field_values}' #- '{new,value}' #- '{old,value}' #- '{new,payload}' #- '{old,payload}'
$$;

-- Search (F261): who, what, when, before/after (redacted), outcome.
create function api.v1_audit_events(p_from timestamptz, p_to timestamptz, p_entity_table text default null, p_actor uuid default null, p_limit integer default 200) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(x order by (x ->> 'seq')::bigint desc) from (
    select jsonb_build_object('seq', e.seq, 'at', e.occurred_at, 'actor_person_id', e.actor_person_id, 'action', e.action, 'table', e.entity_table,
                              'entity_id', e.entity_id, 'outcome', e.outcome, 'reason', e.reason, 'detail', audit.fn_redact(e.detail)) x
      from audit.event e
     where e.company_id = me.company_id and e.occurred_at >= coalesce(p_from, clock_timestamp() - interval '7 days') and e.occurred_at <= coalesce(p_to, clock_timestamp())
       and (p_entity_table is null or e.entity_table = p_entity_table) and (p_actor is null or e.actor_person_id = p_actor)
     order by e.seq desc limit greatest(1, least(coalesce(p_limit, 200), 2000))) q), '[]'::jsonb);
end $$;

-- Tamper-evident evidence bundle (F269): a continuous seq range with prev/row hashes, the chain verification result and a
-- digest over the row hashes; restricted fields redacted; every export logged (as an audit event itself).
create function api.v1_audit_export(p_from_seq bigint, p_to_seq bigint, p_reason text) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog, public, extensions as $$
declare me record; v_rows jsonb; v_digest text; v_first bigint; v_last bigint; v_verified bigint; v_n integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('audit.export', iam.fn_my_company_resource(), false);
  if p_from_seq is null or p_to_seq is null or p_to_seq < p_from_seq or p_to_seq - p_from_seq > 50000 then
    perform core.fn_raise('E_INVALID_ACTION', 'seq range (max 50000)');
  end if;
  select jsonb_agg(jsonb_build_object('seq', e.seq, 'at', e.occurred_at, 'actor_person_id', e.actor_person_id, 'action', e.action, 'table', e.entity_table,
                                      'entity_id', e.entity_id, 'outcome', e.outcome, 'reason', e.reason, 'detail', audit.fn_redact(e.detail),
                                      'redacted', audit.fn_redact(e.detail) is distinct from e.detail,
                                      'prev_hash', encode(e.prev_hash, 'hex'), 'row_hash', encode(e.row_hash, 'hex')) order by e.seq),
         encode(digest(string_agg(encode(e.row_hash, 'hex'), '' order by e.seq), 'sha256'), 'hex'), min(e.seq), max(e.seq), count(*)
    into v_rows, v_digest, v_first, v_last, v_n
    from audit.event e where e.company_id = me.company_id and e.seq between p_from_seq and p_to_seq;
  v_verified := audit.fn_verify_chain(me.company_id);
  perform audit.fn_append(me.company_id, 'audit.export', 'audit.event', null, 'success',
                          jsonb_build_object('from_seq', v_first, 'to_seq', v_last, 'rows', v_n, 'bundle_digest', v_digest), p_reason);
  return jsonb_build_object('company_id', me.company_id, 'from_seq', v_first, 'to_seq', v_last, 'rows', coalesce(v_n, 0), 'events', coalesce(v_rows, '[]'::jsonb),
                            'bundle_digest', v_digest, 'chain_verified_through', v_verified, 'exported_at', clock_timestamp(),
                            'note_bn', 'প্রতিটি সারির row_hash পরের সারির prev_hash-এর সাথে মেলে; bundle_digest = row_hash-গুলোর SHA-256।');
end $$;

-- Retention status (F270): audit is immutable and never a recycle class; archiving to cold storage is a platform job.
create function api.v1_audit_retention_status() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('audit.read', iam.fn_my_company_resource(), false);
  return jsonb_build_object('retention_years', config.fn_get_int(me.company_id, 'audit.retention_years'),
           'oldest_event', (select min(e.occurred_at) from audit.event e where e.company_id = me.company_id),
           'events', (select count(*) from audit.event e where e.company_id = me.company_id),
           'chain_verified_through', audit.fn_verify_chain(me.company_id),
           'recyclable', false, 'purgeable', false);
end $$;

-- ================================================================ policy publication (F266)
create table config.policy_proposal (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  kind          text not null check (kind in ('approval_policy')),
  payload       jsonb not null,
  simulation    jsonb not null,
  effective_at  timestamptz not null,
  status        text not null default 'pending_review' check (status in ('pending_review','scheduled','applied','rejected','cancelled')),
  proposed_by   uuid not null references core.person(id),
  proposed_at   timestamptz not null default clock_timestamp(),
  reason        text not null check (length(btrim(reason)) > 0),
  reviewed_by   uuid references core.person(id),
  reviewed_at   timestamptz,
  review_note   text,
  applied_at    timestamptz,
  check (reviewed_by is null or reviewed_by <> proposed_by)
);
create function config.fn_policy_proposal_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','reviewed_by','reviewed_at','review_note','applied_at']) <> (to_jsonb(new) - array['status','reviewed_by','reviewed_at','review_note','applied_at'])
     or not ((old.status = 'pending_review' and new.status in ('scheduled','rejected','cancelled')) or (old.status = 'scheduled' and new.status in ('applied','cancelled'))) then
    raise exception 'E_IMMUTABLE: a policy proposal is only reviewed, applied or cancelled' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_policy_proposal_guard before update on config.policy_proposal for each row execute function config.fn_policy_proposal_guard();
create trigger trg_policy_proposal_nodel before delete on config.policy_proposal for each row execute function core.fn_deny_delete();
create trigger trg_policy_proposal_audit after insert or update on config.policy_proposal for each row execute function audit.fn_row_change();
select core.fn_apply_rls('config', 'policy_proposal');

-- Shared apply path (direct when review is switched off; scheduled proposals otherwise). In-flight requests keep their
-- policy snapshot (S12), so nothing changes retroactively.
create function config.fn_apply_approval_policy(p_company uuid, p_person uuid, p_document_type text, p_min_amount numeric, p_required integer,
                                                p_permission text, p_reason text) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare cur config.approval_policy%rowtype; v integer;
begin
  perform set_config('mohona.change_reason', p_reason, true);
  select * into cur from config.approval_policy where company_id = p_company and document_type = p_document_type
                                                  and min_amount = coalesce(p_min_amount, 0) and status = 'active' for update;
  if cur.id is not null then update config.approval_policy set status = 'superseded' where id = cur.id; end if;
  if coalesce(p_required, 0) = 0 then return 0; end if;
  v := coalesce(cur.version, 0) + 1;
  insert into config.approval_policy (company_id, document_type, min_amount, required_approvals, approver_permission, version, reason, set_by)
  values (p_company, p_document_type, coalesce(p_min_amount, 0), p_required, p_permission, v, p_reason, p_person);
  return v;
end $$;

create or replace function api.v1_approval_set_policy(p_document_type text, p_min_amount numeric, p_required_approvals integer,
                                                      p_approver_permission text, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.approval_rule.manage', iam.fn_my_company_resource(), true);
  if config.fn_get_bool(me.company_id, 'governance.policy_review.required') then
    perform core.fn_raise('E_POLICY_REVIEW_REQUIRED', 'propose the change (api.v1_policy_propose) for an independent review');
  end if;
  return config.fn_apply_approval_policy(me.company_id, me.person_id, p_document_type, p_min_amount, p_required_approvals, p_approver_permission, p_reason);
end $$;

-- Proposal with simulation: how many requests of the last 90 days would have needed a different number of approvals.
create function api.v1_policy_propose(p_kind text, p_payload jsonb, p_effective_at timestamptz, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid; sim jsonb; v_doc text := p_payload ->> 'document_type'; v_min numeric := coalesce((p_payload ->> 'min_amount')::numeric, 0);
        v_req integer := (p_payload ->> 'required_approvals')::integer; p uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.approval_rule.manage', iam.fn_my_company_resource(), true);
  if p_kind <> 'approval_policy' or coalesce(v_doc, '') !~ '^[a-z][a-z0-9_.]{1,60}$' or v_req is null or v_req not between 0 and 10 or v_min < 0
     or (p_payload ? 'approver_permission' and jsonb_typeof(p_payload -> 'approver_permission') <> 'null'
         and not exists (select 1 from iam.permission_catalog c where c.code = p_payload ->> 'approver_permission')) then
    perform core.fn_raise('E_INVALID_ACTION', 'payload: document_type, min_amount, required_approvals (0 = remove), approver_permission');
  end if;
  sim := jsonb_build_object('window_days', 90,
           'requests_in_scope', (select count(*) from core.approval_request r where r.company_id = me.company_id and r.document_type = v_doc
                                   and r.amount >= v_min and r.created_at > clock_timestamp() - interval '90 days'),
           'would_change', (select count(*) from core.approval_request r where r.company_id = me.company_id and r.document_type = v_doc
                              and r.amount >= v_min and r.created_at > clock_timestamp() - interval '90 days' and r.required_approvals <> greatest(v_req, 1)),
           'pending_now_unaffected', (select count(*) from core.approval_request r where r.company_id = me.company_id and r.document_type = v_doc and r.status = 'pending'));
  perform set_config('mohona.change_reason', p_reason, true);
  insert into config.policy_proposal (company_id, kind, payload, simulation, effective_at, proposed_by, reason)
  values (me.company_id, p_kind, p_payload, sim, greatest(coalesce(p_effective_at, clock_timestamp()), clock_timestamp()), me.person_id, p_reason)
  returning id into v_id;
  return jsonb_build_object('proposal_id', v_id, 'simulation', sim, 'status', 'pending_review');
end $$;

-- Review by an independent critical reviewer (position in governance.critical_reviewers, or the Chairman — never the proposer).
create function api.v1_policy_review(p_proposal_id uuid, p_decision text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; pr config.policy_proposal%rowtype;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_context(true);
  select * into pr from config.policy_proposal where id = p_proposal_id and company_id = me.company_id for update;
  if not found or pr.status <> 'pending_review' then perform core.fn_raise('E_NOT_FOUND', 'proposal'); end if;
  if pr.proposed_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'an independent reviewer is mandatory'); end if;
  if not (me.is_supreme or me.position_code = any (config.fn_get_text_array(me.company_id, 'governance.critical_reviewers'))) then
    perform core.fn_raise('E_FORBIDDEN', 'not a critical reviewer');
  end if;
  perform set_config('mohona.change_reason', p_note, true);
  if p_decision = 'approve' then
    update config.policy_proposal set status = 'scheduled', reviewed_by = me.person_id, reviewed_at = clock_timestamp(), review_note = p_note where id = pr.id;
    if pr.effective_at <= clock_timestamp() then
      perform config.fn_apply_approval_policy(pr.company_id, pr.proposed_by, pr.payload ->> 'document_type', coalesce((pr.payload ->> 'min_amount')::numeric, 0),
                                              (pr.payload ->> 'required_approvals')::integer, pr.payload ->> 'approver_permission', pr.reason);
      update config.policy_proposal set status = 'applied', applied_at = clock_timestamp() where id = pr.id;
    end if;
  elsif p_decision = 'reject' then
    update config.policy_proposal set status = 'rejected', reviewed_by = me.person_id, reviewed_at = clock_timestamp(), review_note = p_note where id = pr.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_decision);
  end if;
  return jsonb_build_object('proposal_id', pr.id, 'status', (select x.status from config.policy_proposal x where x.id = pr.id));
end $$;

create function api.v1_policy_proposals(p_status text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'kind', x.kind, 'payload', x.payload, 'simulation', x.simulation, 'effective_at', x.effective_at,
                                                       'status', x.status, 'proposed_by', x.proposed_by, 'reason', x.reason, 'reviewed_by', x.reviewed_by,
                                                       'review_note', x.review_note) order by x.proposed_at desc)
                     from config.policy_proposal x where x.company_id = me.company_id and (p_status is null or x.status = p_status)), '[]'::jsonb);
end $$;

-- Applies reviewed proposals whose effective date has come (platform cron).
create function svc.v1_policy_apply_due() returns integer
language plpgsql security definer set search_path = '' as $$
declare pr config.policy_proposal%rowtype; n integer := 0;
begin
  perform set_config('mohona.company_scope', '', true);
  for pr in select * from config.policy_proposal x where x.status = 'scheduled' and x.effective_at <= clock_timestamp() for update loop
    perform config.fn_apply_approval_policy(pr.company_id, pr.proposed_by, pr.payload ->> 'document_type', coalesce((pr.payload ->> 'min_amount')::numeric, 0),
                                            (pr.payload ->> 'required_approvals')::integer, pr.payload ->> 'approver_permission', pr.reason);
    update config.policy_proposal set status = 'applied', applied_at = clock_timestamp() where id = pr.id;
    n := n + 1;
  end loop;
  return n;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_notify_inbox(boolean, integer)', 'api.v1_notify_mark(uuid[], text)', 'api.v1_notify_banner()',
      'api.v1_notify_preferences()', 'api.v1_notify_set_preference(text, text, boolean)', 'api.v1_notify_set_template(text, text, text, text)',
      'api.v1_notify_set_escalation(text, integer, text, text)', 'api.v1_notify_broadcast(text, text, uuid, text, text)', 'api.v1_notify_deliveries(uuid)',
      'api.v1_audit_events(timestamptz, timestamptz, text, uuid, integer)', 'api.v1_audit_export(bigint, bigint, text)', 'api.v1_audit_retention_status()',
      'api.v1_policy_propose(text, jsonb, timestamptz, text)', 'api.v1_policy_review(uuid, text, text)', 'api.v1_policy_proposals(text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    foreach f in array array['svc.v1_notify_run()', 'svc.v1_notify_claim(text, integer)', 'svc.v1_notify_result(uuid, boolean, text)', 'svc.v1_policy_apply_due()'] loop
      execute format('grant execute on function %s to service_role', f);
    end loop;
  end if;
end $$;

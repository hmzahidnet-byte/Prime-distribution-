-- 20261108004900_route_recovery.sql  (ধাপ ৪খ / S67 — V162 domain 14 "field route recovery", the parts not already in S44)
--   duplicate-visit guard: one open visit per officer + dealer (or retailer) + day
--   follow-up due date on a visit (e.g. "collect the cheque on Tuesday") and the list of follow-ups that are due
--   completion summary of a day / route plan: planned, done, missed (by reason), rescheduled, still open
-- (illness / missed reasons, supervisor reassignment, reschedule and revisit priority already exist: S44.) STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create function sales.fn_visit_no_duplicate() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if exists (select 1 from sales.dealer_visit v where v.company_id = new.company_id and v.officer_id is not distinct from new.officer_id
               and v.planned_date = new.planned_date and v.status = 'planned'
               and v.dealer_id is not distinct from new.dealer_id and v.retailer_id is not distinct from new.retailer_id) then
    raise exception 'E_DUPLICATE: this visit is already planned for that day' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_visit_no_duplicate before insert on sales.dealer_visit for each row execute function sales.fn_visit_no_duplicate();

alter table sales.dealer_visit add column follow_up_due date, add column follow_up_note text, add column follow_up_done_at timestamptz;

create function api.v1_visit_follow_up(p_visit_id uuid, p_due date, p_note text, p_done boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype;
begin
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'visit'); end if;
  -- same right as recording the visit (assigned officer, or a manager covering the route)
  select * into me from iam.fn_require('crm.visit.record',
           case when v.dealer_id is not null then sales.fn_dealer_resource((select d from sales.dealer d where d.id = v.dealer_id))
                else iam.fn_resource(v.company_id, null, null, null, null, v.officer_id, v.officer_id) end, true);
  perform set_config('mohona.change_reason', 'visit follow-up', true);
  if coalesce(p_done, false) then
    if v.follow_up_due is null then perform core.fn_raise('E_INVALID_ACTION', 'no follow-up set'); end if;
    update sales.dealer_visit set follow_up_done_at = clock_timestamp() where id = v.id;
  else
    if p_due is null or p_due < current_date or length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'a future date and what to do'); end if;
    update sales.dealer_visit set follow_up_due = p_due, follow_up_note = btrim(p_note), follow_up_done_at = null where id = v.id;
  end if;
  return jsonb_build_object('visit_id', v.id, 'follow_up_due', coalesce(p_due, v.follow_up_due), 'done', coalesce(p_done, false));
end $$;

-- Follow-ups due up to a date: an officer sees the own, a manager the company's.
create function api.v1_follow_ups_due(p_until date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_all boolean;
begin
  select * into me from iam.fn_require('crm.visit.record', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person(), iam.fn_current_person()), false);
  select a.allowed into v_all from iam.fn_authorize('crm.dealer.manage', iam.fn_my_company_resource(), false) a;
  return coalesce((select jsonb_agg(jsonb_build_object('visit_id', v.id, 'dealer', d.name_bn, 'due', v.follow_up_due, 'note', v.follow_up_note,
                                                        'overdue', v.follow_up_due < current_date) order by v.follow_up_due)
                     from sales.dealer_visit v left join sales.dealer d on d.id = v.dealer_id
                    where v.company_id = me.company_id and v.follow_up_due is not null and v.follow_up_done_at is null
                      and v.follow_up_due <= coalesce(p_until, current_date + 7) and (coalesce(v_all, false) or v.officer_id = me.person_id)), '[]'::jsonb);
end $$;

-- Completion summary for one day (own route, or the whole company for a manager).
create function api.v1_route_completion(p_day date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_all boolean; d date := coalesce(p_day, current_date);
begin
  select * into me from iam.fn_require('crm.visit.record', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person(), iam.fn_current_person()), false);
  select a.allowed into v_all from iam.fn_authorize('crm.dealer.manage', iam.fn_my_company_resource(), false) a;
  return (select jsonb_build_object('day', d,
            'planned', count(*), 'done', count(*) filter (where v.status = 'done'), 'missed', count(*) filter (where v.status = 'missed'),
            'open', count(*) filter (where v.status = 'planned'), 'rescheduled_out', (select count(*) from sales.dealer_visit r where r.company_id = me.company_id
                                                                                      and r.reschedule_of in (select x.id from sales.dealer_visit x where x.company_id = me.company_id and x.planned_date = d)),
            'missed_reasons', coalesce((select jsonb_object_agg(q.missed_reason, q.n) from (
                                select v2.missed_reason, count(*) n from sales.dealer_visit v2 where v2.company_id = me.company_id and v2.planned_date = d and v2.status = 'missed'
                                   and (coalesce(v_all, false) or v2.officer_id = me.person_id) group by v2.missed_reason) q), '{}'::jsonb),
            'note_bn', 'অসুস্থতা বা না-যাওয়া অসদাচরণের প্রমাণ নয়; কারণ ও তত্ত্বাবধায়কের সিদ্ধান্ত আলাদা রাখা হয়।')
            from sales.dealer_visit v where v.company_id = me.company_id and v.planned_date = d and (coalesce(v_all, false) or v.officer_id = me.person_id));
end $$;

reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_visit_follow_up(uuid, date, text, boolean)', 'api.v1_follow_ups_due(date)', 'api.v1_route_completion(date)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

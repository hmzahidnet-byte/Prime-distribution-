-- 20261108001300_config_dynamic_forms.sql  (S14)
-- Dynamic Forms (blueprint DYNAMIC_FORMS, MOS-F153-041..050) + field masking engine (base of MOS-F153-029):
--   041 schema registry: versioned, immutable form definitions; a whitelist schema language that rejects executable content
--   042 field types: text, textarea, integer, decimal, money, date, datetime, bool, select, multiselect, phone, email, qr,
--       photo, file — canonical, locale-independent values only (ASCII digits, ISO dates); the app normalises Bengali input
--   043 conditional visibility: field/group conditions in the Rule Studio language (S13); the server decides visibility,
--       so a client can never skip a required field by claiming it is hidden
--   044 validation builder: required / required_if, range, length, regex, options, cross-field compare and rule checks;
--       the server re-checks everything on every save and submit
--   045 publication: draft -> preview (dry run) -> publish (optionally through the approval engine) -> active; rollback;
--       every submission is pinned to the version it was created with
--   046 permissions per field and position (write / entry / read / masked / none); 'entry' = may fill in, reads masked;
--       masked and hidden values never leave the server
--   047 attachments: server-built company-scoped storage paths, short-lived per-person grants checked by storage policies
--   048 offline drafts: sync of encrypted device drafts (flag forms.offline_drafts); a draft is never submitted or approved
--       by a sync
--   049 archive: retired forms are read-only; submissions are preserved
--   050 audit: append-only value revisions; audit events carry field names only (never values)
--   masking: generic per-field / per-position mask policy (show / mask / hide) for later modules (S15+ uses it)
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ tables
create table config.form (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  code            text not null check (code ~ '^[A-Z][A-Z0-9_]{2,40}$'),
  name_bn         text not null check (length(btrim(name_bn)) > 0),
  wing_id         uuid,
  status          text not null default 'draft' check (status in ('draft','active','archived')),
  active_version  integer,
  created_by      uuid,
  created_at      timestamptz not null default clock_timestamp(),
  updated_at      timestamptz not null default clock_timestamp(),
  row_version     integer not null default 1,
  unique (id, company_id),
  unique (company_id, code),
  foreign key (wing_id, company_id) references core.wing (id, company_id),
  check (status <> 'active' or active_version is not null)
);
create trigger trg_form_touch before update on config.form for each row execute function core.fn_touch_row();
create trigger trg_form_nodel before delete on config.form for each row execute function core.fn_deny_delete();
create trigger trg_form_audit after insert or update on config.form for each row execute function audit.fn_row_change();

create table config.form_version (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  form_id             uuid not null,
  version             integer not null check (version >= 1),
  definition          jsonb not null,
  field_count         integer not null check (field_count between 1 and 200),
  status              text not null default 'draft' check (status in ('draft','pending_approval','published','superseded','rejected')),
  reason              text not null check (length(btrim(reason)) > 0),
  created_by          uuid,
  created_at          timestamptz not null default clock_timestamp(),
  published_at        timestamptz,
  approval_request_id uuid,
  unique (form_id, version),
  foreign key (form_id, company_id) references config.form (id, company_id)
);
create function config.fn_form_version_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.definition is distinct from old.definition or new.version <> old.version or new.form_id <> old.form_id
     or new.company_id <> old.company_id or new.field_count <> old.field_count then
    raise exception 'E_IMMUTABLE: a form version never changes; create a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_form_version_guard before update on config.form_version for each row execute function config.fn_form_version_guard();
create trigger trg_form_version_nodel before delete on config.form_version for each row execute function core.fn_deny_delete();
create trigger trg_form_version_audit after insert or update on config.form_version for each row execute function audit.fn_row_change();

-- Per field x position access. position_code null = every non-Chairman position (a position-specific row wins).
create table config.form_field_access (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  form_id        uuid not null,
  field_key      text not null check (field_key ~ '^[a-z][a-z0-9_]{0,40}$'),
  position_code  text,
  access         text not null check (access in ('write','entry','read','masked','none')),
  version        integer not null check (version >= 1),
  status         text not null default 'active' check (status in ('active','superseded')),
  set_by         uuid,
  set_at         timestamptz not null default clock_timestamp(),
  reason         text not null check (length(btrim(reason)) > 0),
  foreign key (form_id, company_id) references config.form (id, company_id),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index form_field_access_one_active on config.form_field_access (form_id, field_key, position_code) nulls not distinct where status = 'active';
create function config.fn_history_only_supersede() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - 'status') <> (to_jsonb(new) - 'status') or old.status <> 'active' or new.status <> 'superseded' then
    raise exception 'E_IMMUTABLE: % history is append-only', tg_table_name using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_form_field_access_guard before update on config.form_field_access for each row execute function config.fn_history_only_supersede();
create trigger trg_form_field_access_nodel before delete on config.form_field_access for each row execute function core.fn_deny_delete();
create trigger trg_form_field_access_audit after insert or update on config.form_field_access for each row execute function audit.fn_row_change();

create table config.form_submission (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  form_id             uuid not null,
  form_version        integer not null,
  wing_id             uuid,
  number              text,
  status              text not null default 'draft'
                      check (status in ('draft','submitted','pending_approval','approved','rejected','returned','cancelled','void','superseded')),
  field_values        jsonb not null default '{}'::jsonb check (jsonb_typeof(field_values) = 'object'),
  origin              text not null default 'online' check (origin in ('online','offline')),
  client_draft_id     text check (client_draft_id is null or client_draft_id ~ '^[A-Za-z0-9_-]{8,64}$'),
  client_saved_at     timestamptz,
  amends_id           uuid,
  approval_request_id uuid,
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  submitted_at        timestamptz,
  decided_at          timestamptz,
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id),
  unique (company_id, created_by, client_draft_id),
  foreign key (form_id, company_id) references config.form (id, company_id),
  foreign key (form_id, form_version) references config.form_version (form_id, version),
  foreign key (wing_id, company_id) references core.wing (id, company_id),
  foreign key (amends_id, company_id) references config.form_submission (id, company_id)
);
create index form_submission_by_form on config.form_submission (company_id, form_id, created_at desc);

-- Pinning + locking: identity and pinned schema version never change; values change only while editable;
-- status follows the lifecycle graph.
create function config.fn_form_submission_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.company_id <> old.company_id or new.form_id <> old.form_id or new.form_version <> old.form_version
     or new.created_by <> old.created_by or new.client_draft_id is distinct from old.client_draft_id
     or new.amends_id is distinct from old.amends_id or new.origin <> old.origin
     or (old.number is not null and new.number is distinct from old.number) then
    raise exception 'E_IMMUTABLE: submission identity and pinned form version never change' using errcode = 'P0001';
  end if;
  if new.field_values is distinct from old.field_values and old.status not in ('draft','returned','rejected','pending_approval') then
    raise exception 'E_FORM_LOCKED: a % submission is never edited; amend or void it', old.status using errcode = 'P0001';
  end if;
  if new.field_values is distinct from old.field_values and old.status = 'pending_approval' and new.status <> 'draft' then
    raise exception 'E_FORM_LOCKED: submission is waiting for approval' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not (
       (old.status = 'draft'            and new.status in ('submitted','pending_approval','approved','cancelled'))
    or (old.status = 'pending_approval' and new.status in ('approved','rejected','cancelled','draft'))
    or (old.status in ('rejected','returned') and new.status in ('draft','cancelled'))
    or (old.status in ('submitted','approved') and new.status in ('void','superseded'))) then
    raise exception 'E_INVALID_ACTION: submission % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_form_submission_guard before update on config.form_submission for each row execute function config.fn_form_submission_guard();
create trigger trg_form_submission_touch before update on config.form_submission for each row execute function core.fn_touch_row();
create trigger trg_form_submission_nodel before delete on config.form_submission for each row execute function core.fn_deny_delete();

-- Value history (F050). Append-only; read only through api.v1_forms_submission_history (masked per reader).
create table config.form_submission_revision (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null,
  submission_id    uuid not null,
  revision         integer not null check (revision >= 1),
  action           text not null check (action ~ '^[a-z_]{2,30}$'),
  status_from      text,
  status_to        text not null,
  values_before    jsonb,
  values_after     jsonb not null,
  changed_fields   text[] not null default array[]::text[],
  actor_person_id  uuid,
  reason           text,
  created_at       timestamptz not null default clock_timestamp(),
  unique (submission_id, revision),
  foreign key (submission_id, company_id) references config.form_submission (id, company_id)
);
create trigger trg_form_revision_no_mutation before update or delete on config.form_submission_revision for each row execute function core.fn_deny_mutation();

-- Revision + redacted audit event on every value or status change. The generic audit.fn_row_change is deliberately NOT
-- used on submissions: it copies whole rows into audit.event, which would let an audit reader extract masked values.
create function config.fn_form_submission_track() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
declare v_changed text[]; v_rev integer; v_before jsonb; v_from text;
        v_action text := coalesce(nullif(current_setting('mohona.form_action', true), ''), lower(tg_op));
        v_reason text := nullif(current_setting('mohona.change_reason', true), '');
begin
  if tg_op = 'UPDATE' then
    if new.field_values is not distinct from old.field_values and new.status = old.status then
      return null;
    end if;
    v_before := old.field_values; v_from := old.status;
  end if;
  select coalesce(array_agg(k order by k), array[]::text[]) into v_changed
    from (select jsonb_object_keys(new.field_values) as k union select jsonb_object_keys(coalesce(v_before, '{}'::jsonb))) ks
   where v_before is null or (new.field_values -> k) is distinct from (v_before -> k);
  v_rev := coalesce((select max(r.revision) from config.form_submission_revision r where r.submission_id = new.id), 0) + 1;
  insert into config.form_submission_revision (company_id, submission_id, revision, action, status_from, status_to, values_before, values_after,
                                               changed_fields, actor_person_id, reason)
  values (new.company_id, new.id, v_rev, v_action, v_from, new.status, v_before, new.field_values, v_changed, iam.fn_current_person(), v_reason);
  perform audit.fn_append(new.company_id, 'forms.submission.' || v_action, 'config.form_submission', new.id, 'success',
                          jsonb_build_object('form_id', new.form_id, 'form_version', new.form_version, 'revision', v_rev,
                                             'status_from', v_from, 'status_to', new.status, 'number', new.number,
                                             'changed_fields', to_jsonb(v_changed)), v_reason);
  return null;
end $$;
create trigger trg_form_submission_track after insert or update on config.form_submission for each row execute function config.fn_form_submission_track();

-- Attachment metadata (F047). The object itself lives in private storage bucket 'forms' at a server-built path.
create table config.form_attachment (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  form_id        uuid not null,
  field_key      text not null check (field_key ~ '^[a-z][a-z0-9_]{0,40}$'),
  kind           text not null check (kind in ('photo','file')),
  mime_type      text not null check (mime_type ~ '^[a-z]+/[a-z0-9.+-]{1,60}$'),
  size_bytes     bigint not null check (size_bytes > 0),
  sha256         text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  bucket         text not null default 'forms',
  object_path    text not null unique,
  status         text not null default 'pending' check (status in ('pending','uploaded','linked','rejected')),
  submission_id  uuid,
  created_by     uuid not null references core.person(id),
  created_at     timestamptz not null default clock_timestamp(),
  updated_at     timestamptz not null default clock_timestamp(),
  row_version    integer not null default 1,
  unique (id, company_id),
  foreign key (form_id, company_id) references config.form (id, company_id),
  foreign key (submission_id, company_id) references config.form_submission (id, company_id),
  check (object_path like company_id::text || '/%')
);
create function config.fn_form_attachment_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','submission_id','updated_at','row_version']) <> (to_jsonb(new) - array['status','submission_id','updated_at','row_version'])
     or (old.submission_id is not null and new.submission_id is distinct from old.submission_id) then
    raise exception 'E_IMMUTABLE: attachment metadata never changes' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_form_attachment_guard before update on config.form_attachment for each row execute function config.fn_form_attachment_guard();
create trigger trg_form_attachment_touch before update on config.form_attachment for each row execute function core.fn_touch_row();
create trigger trg_form_attachment_nodel before delete on config.form_attachment for each row execute function core.fn_deny_delete();
create trigger trg_form_attachment_audit after insert or update on config.form_attachment for each row execute function audit.fn_row_change();

-- Short-lived, per-person storage grants (the storage policies only allow what a live grant names).
create table config.form_attachment_grant (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  attachment_id  uuid not null,
  person_id      uuid not null references core.person(id),
  purpose        text not null check (purpose in ('upload','read')),
  expires_at     timestamptz not null,
  created_at     timestamptz not null default clock_timestamp(),
  foreign key (attachment_id, company_id) references config.form_attachment (id, company_id),
  check (expires_at > created_at)
);
create index form_attachment_grant_live on config.form_attachment_grant (attachment_id, person_id, expires_at);
create trigger trg_form_attachment_grant_no_mutation before update or delete on config.form_attachment_grant for each row execute function core.fn_deny_mutation();
create trigger trg_form_attachment_grant_audit after insert on config.form_attachment_grant for each row execute function audit.fn_row_change();

-- Every export is logged (who, how many rows, which fields were redacted).
create table config.form_export_log (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null,
  form_id          uuid not null,
  person_id        uuid not null references core.person(id),
  position_code    text,
  row_count        integer not null check (row_count >= 0),
  redacted_fields  text[] not null default array[]::text[],
  omitted_fields   text[] not null default array[]::text[],
  created_at       timestamptz not null default clock_timestamp(),
  foreign key (form_id, company_id) references config.form (id, company_id)
);
create trigger trg_form_export_log_no_mutation before update or delete on config.form_export_log for each row execute function core.fn_deny_mutation();
create trigger trg_form_export_log_audit after insert on config.form_export_log for each row execute function audit.fn_row_change();

-- Generic field masking (base of MOS-F153-029): field_key = '<module>.<entity>.<field>' (e.g. hr.employee.salary).
create table config.mask_policy (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null references core.company(id),
  field_key      text not null check (field_key ~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,4}$'),
  position_code  text,
  mode           text not null check (mode in ('show','mask','hide')),
  version        integer not null check (version >= 1),
  status         text not null default 'active' check (status in ('active','superseded')),
  set_by         uuid,
  set_at         timestamptz not null default clock_timestamp(),
  reason         text not null check (length(btrim(reason)) > 0),
  foreign key (company_id, position_code) references iam.position_catalog (company_id, code)
);
create unique index mask_policy_one_active on config.mask_policy (company_id, field_key, position_code) nulls not distinct where status = 'active';
create trigger trg_mask_policy_guard before update on config.mask_policy for each row execute function config.fn_history_only_supersede();
create trigger trg_mask_policy_nodel before delete on config.mask_policy for each row execute function core.fn_deny_delete();
create trigger trg_mask_policy_audit after insert or update on config.mask_policy for each row execute function audit.fn_row_change();

select core.fn_apply_rls('config', 'form');
select core.fn_apply_rls('config', 'form_version');
select core.fn_apply_rls('config', 'form_field_access');
select core.fn_apply_rls('config', 'form_submission');
select core.fn_apply_rls('config', 'form_submission_revision');
select core.fn_apply_rls('config', 'form_attachment');
select core.fn_apply_rls('config', 'form_attachment_grant');
select core.fn_apply_rls('config', 'form_export_log');
select core.fn_apply_rls('config', 'mask_policy');

-- ================================================================ schema language (F041 / F042 / F043 / F044)
-- Definition: {"title_bn","description_bn","fields":[...],"groups":[...],"checks":[...],"amount_field","approval":{"required":bool}}
-- Field: {"key","type","label_bn","help_bn","placeholder_bn","required","required_if","visible_if","group","options",
--         "min","max","min_length","max_length","pattern","decimals","sensitive","access_default","mask","default"}
-- Conditions use the Rule Studio language (config.fn_rule_validate / fn_rule_eval) over EARLIER fields only.
-- Nothing in a definition is ever executed: unknown keys are refused, script-like keys and text are refused.

create function config.fn_form_text_unsafe(p text) returns boolean
language sql immutable set search_path = pg_catalog as $$
  select coalesce(p, '') ~* '(<\s*/?\s*(script|iframe|object|embed|svg|link|meta|style)\M|javascript\s*:|vbscript\s*:|data\s*:\s*text/html|\mon[a-z]{3,20}\s*=|\$\{|\{\{|<%|\mexec\s*\(|\meval\s*\()'
$$;

create function config.fn_form_has_unsafe(p jsonb) returns boolean
language plpgsql immutable set search_path = pg_catalog as $$
declare x jsonb; k text;
begin
  case jsonb_typeof(p)
    when 'string' then return config.fn_form_text_unsafe(p #>> '{}');
    when 'array' then
      for x in select * from jsonb_array_elements(p) loop if config.fn_form_has_unsafe(x) then return true; end if; end loop;
    when 'object' then
      for k, x in select * from jsonb_each(p) loop
        if config.fn_form_text_unsafe(k) or config.fn_form_has_unsafe(x) then return true; end if;
      end loop;
    else null;
  end case;
  return false;
end $$;

-- Field names referenced by a Rule Studio condition.
create function config.fn_rule_fields(p jsonb) returns text[]
language plpgsql immutable set search_path = pg_catalog as $$
declare out text[] := array[]::text[]; x jsonb;
begin
  if p is null or jsonb_typeof(p) <> 'object' then return out; end if;
  if p ? 'field' then out := out || (p ->> 'field'); end if;
  if p ? 'arg' then out := out || config.fn_rule_fields(p -> 'arg'); end if;
  if jsonb_typeof(p -> 'args') = 'array' then
    for x in select * from jsonb_array_elements(p -> 'args') loop out := out || config.fn_rule_fields(x); end loop;
  end if;
  return out;
end $$;

create function config.fn_form_field(p_def jsonb, p_key text) returns jsonb
language sql immutable set search_path = pg_catalog as $$
  select x from jsonb_array_elements(coalesce(p_def -> 'fields', '[]'::jsonb)) x where x ->> 'key' = p_key limit 1
$$;

create function config.fn_is_iso_date(p text) returns boolean
language plpgsql stable set search_path = pg_catalog as $$
begin
  if p is null or p !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then return false; end if;
  return to_char(p::date, 'YYYY-MM-DD') = p;
exception when others then return false;
end $$;

create function config.fn_is_iso_datetime(p text) returns boolean
language plpgsql stable set search_path = pg_catalog as $$
declare t timestamptz;
begin
  if p is null or p !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}(:[0-9]{2}(\.[0-9]{1,6})?)?(Z|[+-][0-9]{2}:[0-9]{2})$' then return false; end if;
  if not config.fn_is_iso_date(left(p, 10)) then return false; end if;
  t := p::timestamptz;
  return t is not null;
exception when others then return false;
end $$;

create function config.fn_form_error_bn(p_code text) returns text
language sql immutable set search_path = pg_catalog as $$
  select case p_code
    when 'required'   then 'এই ঘর পূরণ করুন।'
    when 'type'       then 'মানের ধরন সঠিক নয়।'
    when 'range'      then 'মান অনুমোদিত সীমার বাইরে।'
    when 'length'     then 'লেখার দৈর্ঘ্য অনুমোদিত সীমার বাইরে।'
    when 'pattern'    then 'ফরম্যাট সঠিক নয়।'
    when 'option'     then 'তালিকার বাইরের মান দেওয়া হয়েছে।'
    when 'attachment' then 'সংযুক্তি পাওয়া যায়নি বা আপলোড সম্পূর্ণ হয়নি।'
    when 'hidden'     then 'লুকানো ঘরে মান দেওয়া যাবে না।'
    when 'unknown'    then 'ফর্মে এই ঘর নেই।'
    when 'forbidden'  then 'এই ঘর বদলানোর অনুমতি নেই।'
    else 'মান গ্রহণযোগ্য নয়।' end
$$;

-- One value against one field definition. Returns null when valid, else an error code.
-- Canonical values only: numbers are JSON numbers, dates ISO strings, phone/QR ASCII (the app converts Bengali digits).
create function config.fn_form_value_error(p_field jsonb, p_value jsonb, p_company uuid, p_form uuid, p_submission uuid, p_owner uuid)
returns text language plpgsql stable set search_path = pg_catalog as $$
declare t text := p_field ->> 'type'; s text; n numeric; v_scale integer; x jsonb; v_len integer; v_count integer;
begin
  case t
    when 'text', 'textarea' then
      if jsonb_typeof(p_value) <> 'string' then return 'type'; end if;
      s := p_value #>> '{}'; v_len := char_length(s);
      if v_len > coalesce((p_field ->> 'max_length')::integer, case when t = 'text' then 2000 else 10000 end)
         or v_len < coalesce((p_field ->> 'min_length')::integer, 0) then return 'length'; end if;
      if p_field ? 'pattern' and s !~ (p_field ->> 'pattern') then return 'pattern'; end if;
    when 'integer', 'decimal', 'money' then
      if jsonb_typeof(p_value) <> 'number' then return 'type'; end if;
      n := (p_value #>> '{}')::numeric;
      v_scale := case t when 'integer' then 0
                        when 'money' then case when p_company is null then 2 else config.fn_get_int(p_company, 'finance.money.scale') end
                        else coalesce((p_field ->> 'decimals')::integer, 4) end;
      if n <> round(n, v_scale) then return 'type'; end if;
      if (p_field ? 'min' and n < (p_field ->> 'min')::numeric) or (p_field ? 'max' and n > (p_field ->> 'max')::numeric) then return 'range'; end if;
    when 'date' then
      if jsonb_typeof(p_value) <> 'string' or not config.fn_is_iso_date(p_value #>> '{}') then return 'type'; end if;
      if (p_field ? 'min' and (p_value #>> '{}') < (p_field ->> 'min')) or (p_field ? 'max' and (p_value #>> '{}') > (p_field ->> 'max')) then return 'range'; end if;
    when 'datetime' then
      if jsonb_typeof(p_value) <> 'string' or not config.fn_is_iso_datetime(p_value #>> '{}') then return 'type'; end if;
    when 'bool' then
      if jsonb_typeof(p_value) <> 'boolean' then return 'type'; end if;
    when 'select' then
      if jsonb_typeof(p_value) <> 'string' then return 'type'; end if;
      if not exists (select 1 from jsonb_array_elements(p_field -> 'options') o where o ->> 'value' = p_value #>> '{}') then return 'option'; end if;
    when 'multiselect' then
      if jsonb_typeof(p_value) <> 'array' then return 'type'; end if;
      v_count := jsonb_array_length(p_value);
      for x in select * from jsonb_array_elements(p_value) loop
        if jsonb_typeof(x) <> 'string' then return 'type'; end if;
        if not exists (select 1 from jsonb_array_elements(p_field -> 'options') o where o ->> 'value' = x #>> '{}') then return 'option'; end if;
      end loop;
      if (select count(distinct e) from jsonb_array_elements_text(p_value) e) <> v_count then return 'option'; end if;
      if (p_field ? 'min' and v_count < (p_field ->> 'min')::integer) or (p_field ? 'max' and v_count > (p_field ->> 'max')::integer) then return 'range'; end if;
    when 'phone' then
      if jsonb_typeof(p_value) <> 'string' or (p_value #>> '{}') !~ '^01[3-9][0-9]{8}$' then return 'pattern'; end if;
    when 'email' then
      if jsonb_typeof(p_value) <> 'string' or length(p_value #>> '{}') > 254
         or (p_value #>> '{}') !~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$' then return 'pattern'; end if;
    when 'qr' then
      if jsonb_typeof(p_value) <> 'string' or (p_value #>> '{}') !~ '^[!-~]{1,512}$' then return 'pattern'; end if;
    when 'photo', 'file' then
      if jsonb_typeof(p_value) <> 'string' or (p_value #>> '{}') !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then return 'type'; end if;
      if p_company is null then return null; end if;            -- definition-time default check: nothing to look up
      if not exists (select 1 from config.form_attachment a
                      where a.id = (p_value #>> '{}')::uuid and a.company_id = p_company and a.form_id = p_form
                        and a.field_key = p_field ->> 'key' and a.kind = t and a.status in ('uploaded','linked')
                        and ((a.submission_id is null and a.created_by = p_owner) or a.submission_id = p_submission)) then
        return 'attachment';
      end if;
    else
      return 'type';
  end case;
  return null;
end $$;

-- Validates a whole definition; returns its field count. Raises E_FORM_SCRIPT_REJECTED / E_FORM_SCHEMA_INVALID / E_RULE_INVALID.
create function config.fn_form_validate_definition(p jsonb) returns integer
language plpgsql stable set search_path = pg_catalog as $$
declare f jsonb; g jsonb; c jsonb; o jsonb; k text; v_key text; v_type text; v_keys text[] := array[]::text[]; v_types jsonb := '{}'::jsonb;
        v_groups jsonb := '{}'::jsonb; v_ref text; v_opts text[]; v_t2 text;
        c_script constant text := '^(script|scripts|js|javascript|formula|formulas|expression|expr|eval|exec|code|sql|query|html|template|compute|computed|calc|calculation|function|handler|hook|webhook|action|actions|on[a-z_]+)$';
        c_top    constant text[] := array['title_bn','description_bn','fields','groups','checks','amount_field','approval'];
        c_field  constant text[] := array['key','type','label_bn','help_bn','placeholder_bn','required','required_if','visible_if','group','options',
                                          'min','max','min_length','max_length','pattern','decimals','sensitive','access_default','mask','default'];
        c_types  constant text[] := array['text','textarea','integer','decimal','money','date','datetime','bool','select','multiselect','phone','email','qr','photo','file'];
begin
  if p is null or jsonb_typeof(p) <> 'object' then raise exception 'E_FORM_SCHEMA_INVALID: definition must be an object' using errcode = 'P0001'; end if;
  if length(p::text) > 262144 then raise exception 'E_FORM_SCHEMA_INVALID: definition larger than 256 KB' using errcode = 'P0001'; end if;
  if config.fn_form_has_unsafe(p) then raise exception 'E_FORM_SCRIPT_REJECTED: executable or markup content is not allowed' using errcode = 'P0001'; end if;
  for k in select jsonb_object_keys(p) loop
    if k ~* c_script then raise exception 'E_FORM_SCRIPT_REJECTED: key %', k using errcode = 'P0001'; end if;
    if not (k = any (c_top)) then raise exception 'E_FORM_SCHEMA_INVALID: unknown key %', k using errcode = 'P0001'; end if;
  end loop;
  -- groups
  if p ? 'groups' then
    if jsonb_typeof(p -> 'groups') <> 'array' then raise exception 'E_FORM_SCHEMA_INVALID: groups must be a list' using errcode = 'P0001'; end if;
    for g in select * from jsonb_array_elements(p -> 'groups') loop
      if jsonb_typeof(g) <> 'object' then raise exception 'E_FORM_SCHEMA_INVALID: group must be an object' using errcode = 'P0001'; end if;
      for k in select jsonb_object_keys(g) loop
        if k ~* c_script then raise exception 'E_FORM_SCRIPT_REJECTED: key %', k using errcode = 'P0001'; end if;
        if k not in ('key','label_bn','visible_if') then raise exception 'E_FORM_SCHEMA_INVALID: unknown group key %', k using errcode = 'P0001'; end if;
      end loop;
      v_key := g ->> 'key';
      if coalesce(v_key, '') !~ '^[a-z][a-z0-9_]{0,40}$' or v_groups ? v_key then raise exception 'E_FORM_SCHEMA_INVALID: bad or duplicate group key' using errcode = 'P0001'; end if;
      if length(btrim(coalesce(g ->> 'label_bn', ''))) = 0 then raise exception 'E_FORM_SCHEMA_INVALID: group % needs label_bn', v_key using errcode = 'P0001'; end if;
      if g ? 'visible_if' then perform config.fn_rule_validate(g -> 'visible_if'); end if;
      v_groups := v_groups || jsonb_build_object(v_key, coalesce(g -> 'visible_if', 'null'::jsonb));
    end loop;
  end if;
  -- fields
  if jsonb_typeof(p -> 'fields') is distinct from 'array' or jsonb_array_length(p -> 'fields') not between 1 and 200 then
    raise exception 'E_FORM_SCHEMA_INVALID: 1..200 fields required' using errcode = 'P0001';
  end if;
  for f in select * from jsonb_array_elements(p -> 'fields') loop
    if jsonb_typeof(f) <> 'object' then raise exception 'E_FORM_SCHEMA_INVALID: field must be an object' using errcode = 'P0001'; end if;
    for k in select jsonb_object_keys(f) loop
      if k ~* c_script then raise exception 'E_FORM_SCRIPT_REJECTED: field key %', k using errcode = 'P0001'; end if;
      if not (k = any (c_field)) then raise exception 'E_FORM_SCHEMA_INVALID: unknown field attribute %', k using errcode = 'P0001'; end if;
    end loop;
    v_key := f ->> 'key'; v_type := f ->> 'type';
    if coalesce(v_key, '') !~ '^[a-z][a-z0-9_]{0,40}$' or v_key = any (v_keys) then
      raise exception 'E_FORM_SCHEMA_INVALID: bad or duplicate field key %', v_key using errcode = 'P0001';
    end if;
    if not (coalesce(v_type, '') = any (c_types)) then raise exception 'E_FORM_SCHEMA_INVALID: unknown field type %', v_type using errcode = 'P0001'; end if;
    if jsonb_typeof(f -> 'label_bn') is distinct from 'string' or length(btrim(f ->> 'label_bn')) = 0 then
      raise exception 'E_FORM_SCHEMA_INVALID: field % needs label_bn', v_key using errcode = 'P0001';
    end if;
    if (f ? 'required' and jsonb_typeof(f -> 'required') <> 'boolean') or (f ? 'sensitive' and jsonb_typeof(f -> 'sensitive') <> 'boolean') then
      raise exception 'E_FORM_SCHEMA_INVALID: required/sensitive must be true/false' using errcode = 'P0001';
    end if;
    if f ? 'access_default' and coalesce(f ->> 'access_default', '') not in ('write','entry','read','masked','none') then
      raise exception 'E_FORM_SCHEMA_INVALID: access_default' using errcode = 'P0001';
    end if;
    if f ? 'mask' and coalesce(f ->> 'mask', '') not in ('partial','full') then raise exception 'E_FORM_SCHEMA_INVALID: mask' using errcode = 'P0001'; end if;
    -- conditions: valid Rule Studio trees over earlier fields only (deterministic, no cycles)
    foreach k in array array['visible_if','required_if'] loop
      if f ? k then
        perform config.fn_rule_validate(f -> k);
        foreach v_ref in array config.fn_rule_fields(f -> k) loop
          if not (v_ref = any (v_keys)) then
            raise exception 'E_FORM_SCHEMA_INVALID: % of % uses % which is not an earlier field', k, v_key, v_ref using errcode = 'P0001';
          end if;
        end loop;
      end if;
    end loop;
    if f ? 'group' then
      if not v_groups ? (f ->> 'group') then raise exception 'E_FORM_SCHEMA_INVALID: unknown group %', f ->> 'group' using errcode = 'P0001'; end if;
      foreach v_ref in array config.fn_rule_fields(v_groups -> (f ->> 'group')) loop
        if not (v_ref = any (v_keys)) then
          raise exception 'E_FORM_SCHEMA_INVALID: group % condition uses % which is not before field %', f ->> 'group', v_ref, v_key using errcode = 'P0001';
        end if;
      end loop;
    end if;
    -- options
    if v_type in ('select','multiselect') then
      if jsonb_typeof(f -> 'options') is distinct from 'array' or jsonb_array_length(f -> 'options') not between 1 and 500 then
        raise exception 'E_FORM_SCHEMA_INVALID: % needs 1..500 options', v_key using errcode = 'P0001';
      end if;
      v_opts := array[]::text[];
      for o in select * from jsonb_array_elements(f -> 'options') loop
        if jsonb_typeof(o) <> 'object' or coalesce(o ->> 'value', '') !~ '^[A-Za-z0-9_.-]{1,60}$' or length(btrim(coalesce(o ->> 'label_bn', ''))) = 0
           or (o ->> 'value') = any (v_opts) or exists (select 1 from jsonb_object_keys(o) ok where ok not in ('value','label_bn')) then
          raise exception 'E_FORM_SCHEMA_INVALID: bad option in %', v_key using errcode = 'P0001';
        end if;
        v_opts := v_opts || (o ->> 'value');
      end loop;
    elsif f ? 'options' then
      raise exception 'E_FORM_SCHEMA_INVALID: options only for select fields' using errcode = 'P0001';
    end if;
    -- ranges and lengths
    if f ? 'min' or f ? 'max' then
      if v_type in ('integer','decimal','money','multiselect') then
        if (f ? 'min' and jsonb_typeof(f -> 'min') <> 'number') or (f ? 'max' and jsonb_typeof(f -> 'max') <> 'number')
           or (f ? 'min' and f ? 'max' and (f ->> 'min')::numeric > (f ->> 'max')::numeric) then
          raise exception 'E_FORM_SCHEMA_INVALID: min/max of %', v_key using errcode = 'P0001';
        end if;
      elsif v_type = 'date' then
        if (f ? 'min' and not config.fn_is_iso_date(f ->> 'min')) or (f ? 'max' and not config.fn_is_iso_date(f ->> 'max'))
           or (f ? 'min' and f ? 'max' and (f ->> 'min') > (f ->> 'max')) then
          raise exception 'E_FORM_SCHEMA_INVALID: date min/max of %', v_key using errcode = 'P0001';
        end if;
      else
        raise exception 'E_FORM_SCHEMA_INVALID: min/max not allowed for %', v_type using errcode = 'P0001';
      end if;
    end if;
    if f ? 'min_length' or f ? 'max_length' or f ? 'pattern' then
      if v_type not in ('text','textarea') then raise exception 'E_FORM_SCHEMA_INVALID: length/pattern only for text' using errcode = 'P0001'; end if;
      if (f ? 'min_length' and (jsonb_typeof(f -> 'min_length') <> 'number' or (f ->> 'min_length')::numeric not between 0 and 10000))
         or (f ? 'max_length' and (jsonb_typeof(f -> 'max_length') <> 'number' or (f ->> 'max_length')::numeric not between 1 and 10000))
         or (f ? 'min_length' and f ? 'max_length' and (f ->> 'min_length')::numeric > (f ->> 'max_length')::numeric) then
        raise exception 'E_FORM_SCHEMA_INVALID: length of %', v_key using errcode = 'P0001';
      end if;
      if f ? 'pattern' then
        if jsonb_typeof(f -> 'pattern') <> 'string' or length(f ->> 'pattern') not between 1 and 200 then
          raise exception 'E_FORM_SCHEMA_INVALID: pattern of %', v_key using errcode = 'P0001';
        end if;
        begin
          perform '' ~ (f ->> 'pattern');
        exception when others then
          raise exception 'E_FORM_SCHEMA_INVALID: pattern of % does not compile', v_key using errcode = 'P0001';
        end;
      end if;
    end if;
    if f ? 'decimals' and (v_type <> 'decimal' or jsonb_typeof(f -> 'decimals') <> 'number' or (f ->> 'decimals')::numeric not in (0,1,2,3,4,5,6)) then
      raise exception 'E_FORM_SCHEMA_INVALID: decimals of %', v_key using errcode = 'P0001';
    end if;
    if f ? 'default' and (v_type in ('photo','file') or config.fn_form_value_error(f, f -> 'default', null, null, null, null) is not null) then
      raise exception 'E_FORM_SCHEMA_INVALID: default of % is not a valid value', v_key using errcode = 'P0001';
    end if;
    v_keys := v_keys || v_key;
    v_types := v_types || jsonb_build_object(v_key, v_type);
  end loop;
  -- cross-field checks
  if p ? 'checks' then
    if jsonb_typeof(p -> 'checks') <> 'array' or jsonb_array_length(p -> 'checks') > 50 then
      raise exception 'E_FORM_SCHEMA_INVALID: checks must be a list (max 50)' using errcode = 'P0001';
    end if;
    for c in select * from jsonb_array_elements(p -> 'checks') loop
      if jsonb_typeof(c) <> 'object' or length(btrim(coalesce(c ->> 'message_bn', ''))) = 0 then
        raise exception 'E_FORM_SCHEMA_INVALID: check needs message_bn' using errcode = 'P0001';
      end if;
      for k in select jsonb_object_keys(c) loop
        if k ~* c_script then raise exception 'E_FORM_SCRIPT_REJECTED: check key %', k using errcode = 'P0001'; end if;
        if k not in ('kind','left','op','right','condition','message_bn') then raise exception 'E_FORM_SCHEMA_INVALID: unknown check key %', k using errcode = 'P0001'; end if;
      end loop;
      if c ->> 'kind' = 'compare' then
        v_type := v_types ->> (c ->> 'left'); v_t2 := v_types ->> (c ->> 'right');
        if v_type is null or v_t2 is null or coalesce(c ->> 'op', '') not in ('=','!=','>','>=','<','<=')
           or not ((v_type in ('integer','decimal','money') and v_t2 in ('integer','decimal','money'))
                   or (v_type = v_t2 and v_type in ('date','datetime','text','select'))) then
          raise exception 'E_FORM_SCHEMA_INVALID: compare check needs two comparable fields' using errcode = 'P0001';
        end if;
      elsif c ->> 'kind' = 'rule' then
        perform config.fn_rule_validate(c -> 'condition');
        foreach v_ref in array config.fn_rule_fields(c -> 'condition') loop
          if not (v_ref = any (v_keys)) then raise exception 'E_FORM_SCHEMA_INVALID: check uses unknown field %', v_ref using errcode = 'P0001'; end if;
        end loop;
      else
        raise exception 'E_FORM_SCHEMA_INVALID: check kind must be compare or rule' using errcode = 'P0001';
      end if;
    end loop;
  end if;
  if p ? 'amount_field' and coalesce(v_types ->> (p ->> 'amount_field'), '') not in ('integer','decimal','money') then
    raise exception 'E_FORM_SCHEMA_INVALID: amount_field must be a numeric field' using errcode = 'P0001';
  end if;
  if p ? 'approval' and (jsonb_typeof(p -> 'approval') <> 'object' or exists (select 1 from jsonb_object_keys(p -> 'approval') ak where ak <> 'required')
                         or jsonb_typeof(coalesce(p -> 'approval' -> 'required', 'false'::jsonb)) <> 'boolean') then
    raise exception 'E_FORM_SCHEMA_INVALID: approval = {"required": true|false}' using errcode = 'P0001';
  end if;
  return cardinality(v_keys);
end $$;

-- Validates values against a definition. The SERVER decides visibility (fields evaluated in order; conditions see only
-- earlier visible values), so "hidden" can never be claimed by a client to skip a required field.
-- p_partial = draft save: types are checked, required/checks are not. Returns {ok, errors[], visible[], values}.
create function config.fn_form_check(p_def jsonb, p_values jsonb, p_company uuid, p_form uuid, p_submission uuid, p_owner uuid, p_partial boolean)
returns jsonb language plpgsql stable set search_path = pg_catalog as $$
declare f jsonb; c jsonb; g jsonb; k text; v jsonb; a jsonb; b jsonb; e text; ok boolean; is_vis boolean; is_req boolean;
        facts jsonb := '{}'::jsonb; clean jsonb := '{}'::jsonb; errs jsonb := '[]'::jsonb; vis text[] := array[]::text[];
        v_groups jsonb := '{}'::jsonb; v_policy text := 'strip';
begin
  if p_values is null or jsonb_typeof(p_values) <> 'object' then
    return jsonb_build_object('ok', false, 'errors', jsonb_build_array(jsonb_build_object('field', '_form', 'code', 'type', 'message_bn', config.fn_form_error_bn('type'))),
                              'visible', '[]'::jsonb, 'values', '{}'::jsonb);
  end if;
  if p_company is not null then v_policy := config.fn_get_text(p_company, 'forms.hidden_value_policy'); end if;
  for k in select jsonb_object_keys(p_values) loop
    if config.fn_form_field(p_def, k) is null then
      errs := errs || jsonb_build_array(jsonb_build_object('field', k, 'code', 'unknown', 'message_bn', config.fn_form_error_bn('unknown')));
    end if;
  end loop;
  for g in select * from jsonb_array_elements(coalesce(p_def -> 'groups', '[]'::jsonb)) loop
    v_groups := v_groups || jsonb_build_object(g ->> 'key', coalesce(g -> 'visible_if', 'null'::jsonb));
  end loop;
  for f in select * from jsonb_array_elements(p_def -> 'fields') loop
    k := f ->> 'key'; v := p_values -> k;
    if v is not null and (jsonb_typeof(v) = 'null' or (jsonb_typeof(v) = 'string' and btrim(v #>> '{}') = '')
                          or (jsonb_typeof(v) = 'array' and jsonb_array_length(v) = 0)) then
      v := null;
    end if;
    is_vis := (not f ? 'visible_if' or config.fn_rule_eval(f -> 'visible_if', facts))
          and (not f ? 'group' or jsonb_typeof(v_groups -> (f ->> 'group')) is distinct from 'object'
               or config.fn_rule_eval(v_groups -> (f ->> 'group'), facts));
    if not is_vis then
      if v is not null and v_policy = 'reject' then
        errs := errs || jsonb_build_array(jsonb_build_object('field', k, 'code', 'hidden', 'message_bn', config.fn_form_error_bn('hidden')));
      end if;
      continue;                                               -- 'strip' (default): a hidden field's value is dropped
    end if;
    vis := vis || k;
    is_req := coalesce((f ->> 'required')::boolean, false) or (f ? 'required_if' and config.fn_rule_eval(f -> 'required_if', facts));
    if v is null then
      if is_req and not p_partial then
        errs := errs || jsonb_build_array(jsonb_build_object('field', k, 'code', 'required', 'message_bn', config.fn_form_error_bn('required')));
      end if;
      continue;
    end if;
    e := config.fn_form_value_error(f, v, p_company, p_form, p_submission, p_owner);
    if e is not null then
      errs := errs || jsonb_build_array(jsonb_build_object('field', k, 'code', e, 'message_bn', config.fn_form_error_bn(e)));
      continue;
    end if;
    clean := clean || jsonb_build_object(k, v);
    facts := facts || jsonb_build_object(k, v);
  end loop;
  if not p_partial and jsonb_array_length(errs) = 0 then
    for c in select * from jsonb_array_elements(coalesce(p_def -> 'checks', '[]'::jsonb)) loop
      if c ->> 'kind' = 'compare' then
        a := clean -> (c ->> 'left'); b := clean -> (c ->> 'right');
        continue when a is null or b is null;                 -- an empty side is the required-rule's job
        if jsonb_typeof(a) = 'number' then
          ok := case c ->> 'op' when '=' then (a #>> '{}')::numeric = (b #>> '{}')::numeric when '!=' then (a #>> '{}')::numeric <> (b #>> '{}')::numeric
                                when '>' then (a #>> '{}')::numeric > (b #>> '{}')::numeric when '>=' then (a #>> '{}')::numeric >= (b #>> '{}')::numeric
                                when '<' then (a #>> '{}')::numeric < (b #>> '{}')::numeric else (a #>> '{}')::numeric <= (b #>> '{}')::numeric end;
        else
          ok := case c ->> 'op' when '=' then (a #>> '{}') = (b #>> '{}') when '!=' then (a #>> '{}') <> (b #>> '{}')
                                when '>' then (a #>> '{}') > (b #>> '{}') when '>=' then (a #>> '{}') >= (b #>> '{}')
                                when '<' then (a #>> '{}') < (b #>> '{}') else (a #>> '{}') <= (b #>> '{}') end;
        end if;
        if not ok then
          errs := errs || jsonb_build_array(jsonb_build_object('field', c ->> 'left', 'code', 'check', 'message_bn', c ->> 'message_bn'));
        end if;
      elsif not config.fn_rule_eval(c -> 'condition', clean) then
        errs := errs || jsonb_build_array(jsonb_build_object('field', '_form', 'code', 'check', 'message_bn', c ->> 'message_bn'));
      end if;
    end loop;
  end if;
  return jsonb_build_object('ok', jsonb_array_length(errs) = 0, 'errors', errs, 'visible', to_jsonb(vis), 'values', clean);
end $$;

-- ================================================================ field access + masking (F046 + masking engine)
-- Effective access of a position to a form field: Chairman = write (supreme, no limits); position row > all-positions row >
-- field access_default > sensitive default (Chairman setting) > write.
create function config.fn_form_field_access(p_company uuid, p_form uuid, p_field jsonb, p_position text, p_supreme boolean)
returns text language plpgsql stable security definer set search_path = pg_catalog as $$
declare v text;
begin
  if p_supreme then return 'write'; end if;
  select a.access into v from config.form_field_access a
   where a.form_id = p_form and a.company_id = p_company and a.field_key = p_field ->> 'key' and a.status = 'active'
     and (a.position_code = p_position or a.position_code is null)
   order by (a.position_code is null) limit 1;
  if v is not null then return v; end if;
  if p_field ? 'access_default' then return p_field ->> 'access_default'; end if;
  if coalesce((p_field ->> 'sensitive')::boolean, false) then return config.fn_get_text(p_company, 'forms.sensitive.default_access'); end if;
  return 'write';
end $$;

-- Renders a masked value. Numbers, dates and lists are never partially shown (magnitude leaks); short text is fully hidden.
create function config.fn_mask_render(p_value jsonb, p_style text, p_keep integer) returns jsonb
language plpgsql immutable set search_path = pg_catalog as $$
declare s text; n integer;
begin
  if p_value is null or jsonb_typeof(p_value) = 'null' then return p_value; end if;
  if coalesce(p_style, 'full') <> 'partial' or jsonb_typeof(p_value) <> 'string' then return to_jsonb('••••••'::text); end if;
  s := p_value #>> '{}'; n := char_length(s);
  if coalesce(p_keep, 0) <= 0 or n <= p_keep * 2 then return to_jsonb(repeat('•', greatest(n, 4))); end if;
  return to_jsonb(repeat('•', n - p_keep) || right(s, p_keep));
end $$;

-- What a reader may see of submission values: 'none' fields are omitted, 'masked'/'entry' fields are masked (export may redact),
-- attachment ids of masked fields are never returned. Returns {values, access, masked[], omitted[]}.
create function config.fn_form_project(p_company uuid, p_form uuid, p_def jsonb, p_values jsonb, p_position text, p_supreme boolean, p_mode text)
returns jsonb language plpgsql stable security definer set search_path = pg_catalog as $$
declare f jsonb; k text; v jsonb; acc text; out jsonb := '{}'::jsonb; v_access jsonb := '{}'::jsonb; masked text[] := array[]::text[];
        omitted text[] := array[]::text[];
        v_style text := config.fn_get_text(p_company, 'mask.style'); v_keep integer := config.fn_get_int(p_company, 'mask.keep_last');
        v_export text := config.fn_get_text(p_company, 'mask.export_policy');
begin
  for f in select * from jsonb_array_elements(p_def -> 'fields') loop
    k := f ->> 'key';
    acc := config.fn_form_field_access(p_company, p_form, f, p_position, p_supreme);
    if acc = 'none' then omitted := omitted || k; continue; end if;
    v_access := v_access || jsonb_build_object(k, acc);
    v := p_values -> k;
    continue when v is null;
    if acc in ('masked','entry') then
      masked := masked || k;
      if f ->> 'type' in ('photo','file') then v := 'null'::jsonb;
      elsif p_mode = 'export' and v_export = 'redact' then v := to_jsonb('[গোপন]'::text);
      else v := config.fn_mask_render(v, coalesce(f ->> 'mask', v_style), v_keep);
      end if;
    end if;
    out := out || jsonb_build_object(k, v);
  end loop;
  return jsonb_build_object('values', out, 'access', v_access, 'masked', to_jsonb(masked), 'omitted', to_jsonb(omitted));
end $$;

-- Overlays new values on stored ones honouring write access. A non-writable field may be resent only unchanged.
create function config.fn_form_merge(p_company uuid, p_form uuid, p_def jsonb, p_old jsonb, p_new jsonb, p_position text, p_supreme boolean)
returns jsonb language plpgsql stable security definer set search_path = pg_catalog as $$
declare k text; v jsonb; f jsonb; out jsonb := coalesce(p_old, '{}'::jsonb); forb text[] := array[]::text[];
begin
  for k, v in select * from jsonb_each(coalesce(p_new, '{}'::jsonb)) loop
    f := config.fn_form_field(p_def, k);
    if f is null or config.fn_form_field_access(p_company, p_form, f, p_position, p_supreme) in ('write','entry') then
      out := case when jsonb_typeof(v) = 'null' then out - k else out || jsonb_build_object(k, v) end;
    elsif (coalesce(p_old, '{}'::jsonb) -> k) is distinct from v then
      forb := forb || k;
    end if;
  end loop;
  return jsonb_build_object('values', out, 'forbidden', to_jsonb(forb));
end $$;

-- Definition as one position may see it: 'none' fields removed, every field carries its effective access.
create function config.fn_form_client_definition(p_company uuid, p_form uuid, p_def jsonb, p_position text, p_supreme boolean)
returns jsonb language sql stable security definer set search_path = pg_catalog as $$
  select jsonb_set(p_def, '{fields}', coalesce((
    select jsonb_agg(x.f || jsonb_build_object('access', x.acc) order by x.ord)
      from (select e.f, e.ord, config.fn_form_field_access(p_company, p_form, e.f, p_position, p_supreme) acc
              from jsonb_array_elements(p_def -> 'fields') with ordinality e(f, ord)) x
     where x.acc <> 'none'), '[]'::jsonb))
$$;

-- Generic mask policy (later modules): supreme = show; position row > all-positions row > show.
create function config.fn_mask_mode(p_company uuid, p_field_key text, p_position text, p_supreme boolean) returns text
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v text;
begin
  if p_supreme then return 'show'; end if;
  select m.mode into v from config.mask_policy m
   where m.company_id = p_company and m.field_key = p_field_key and m.status = 'active' and (m.position_code = p_position or m.position_code is null)
   order by (m.position_code is null) limit 1;
  return coalesce(v, 'show');
end $$;

-- For the current session's position: value as shown ('hide' -> null). Used by S15+ read RPCs and exports.
create function config.fn_mask_apply(p_field_key text, p_value jsonb, p_export boolean default false) returns jsonb
language plpgsql volatile security definer set search_path = pg_catalog as $$
declare c record; v_mode text;
begin
  select * into c from iam.fn_context(false);
  v_mode := config.fn_mask_mode(c.company_id, p_field_key, c.position_code, c.is_supreme);
  if v_mode = 'hide' then return null; end if;
  if v_mode = 'show' or p_value is null then return p_value; end if;
  if p_export and config.fn_get_text(c.company_id, 'mask.export_policy') = 'redact' then return to_jsonb('[গোপন]'::text); end if;
  return config.fn_mask_render(p_value, config.fn_get_text(c.company_id, 'mask.style'), config.fn_get_int(c.company_id, 'mask.keep_last'));
end $$;

-- ================================================================ permissions, module, settings
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('forms.form.read',         'forms',  'ফর্ম ও ফর্ম-সংজ্ঞা দেখা', 'read', false, true, array['COMPANY','WING'], 'active', 1200),
  ('forms.form.manage',       'forms',  'ফর্ম ডিজাইন/প্রকাশ/আর্কাইভ/ঘর-অনুমতি', 'admin', true, false, array['COMPANY'], 'active', 1201),
  ('forms.submission.read',   'forms',  'ফর্ম-জমা দেখা', 'read', false, true, array['COMPANY','WING','SELF'], 'active', 1202),
  ('forms.submission.write',  'forms',  'ফর্ম পূরণ, খসড়া ও জমা', 'write', false, true, array['COMPANY','WING','SELF'], 'active', 1203),
  ('forms.submission.void',   'forms',  'জমা-দেওয়া ফর্ম বাতিল (void)', 'approve', true, false, array['COMPANY','WING'], 'active', 1204),
  ('forms.submission.export', 'forms',  'ফর্ম-ডেটা রপ্তানি', 'export', true, false, array['COMPANY','WING'], 'active', 1205),
  ('config.mask.manage',      'config', 'মাস্কিং-নীতি নির্ধারণ', 'admin', true, false, array['COMPANY'], 'active', 198);

insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'forms.form.read', 'allow', 'COMPANY' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN')
union all
select t.code, 'forms.submission.write', 'allow', 'SELF' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN')
union all
select t.code, 'forms.submission.read', 'allow', 'SELF' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN');
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind) values
  ('MD', 'forms.submission.read', 'allow', 'COMPANY'), ('MD', 'forms.submission.export', 'allow', 'COMPANY'), ('MD', 'forms.submission.void', 'allow', 'COMPANY'),
  ('WING_HEAD', 'forms.submission.read', 'allow', 'WING'), ('AUDITOR', 'forms.submission.read', 'allow', 'COMPANY');
select iam.fn_backfill_template_rules(null);

update config.module_catalog set permission_modules = array['forms'] where code = 'forms';
select config.fn_make_module_available('forms');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('forms.publish.requires_approval',   'forms', 'bool', 'false', null, null, null, 'ফর্ম প্রকাশে অনুমোদন লাগবে', 'MOS-F153-045', true, 500),
  ('forms.hidden_value_policy',         'forms', 'text', '"strip"', null, null, '["strip","reject"]', 'লুকানো ঘরে পাঠানো মান: বাদ দেওয়া / প্রত্যাখ্যান', 'MOS-F153-043', false, 510),
  ('forms.sensitive.default_access',    'forms', 'text', '"entry"', null, null, '["entry","masked","none","read"]', 'সংবেদনশীল ঘরের ডিফল্ট দৃশ্যমানতা', 'MOS-F153-046', true, 520),
  ('forms.attachment.max_mb',           'forms', 'int', '10', 1, 100, null, 'সংযুক্তির সর্বোচ্চ আকার (MB)', 'MOS-F153-047', false, 530),
  ('forms.attachment.allowed_mime',     'forms', 'text_array', '["image/jpeg","image/png","image/webp","application/pdf"]', null, null,
     '["image/jpeg","image/png","image/webp","image/heic","application/pdf","text/csv"]', 'অনুমোদিত সংযুক্তি-ধরন', 'MOS-F153-047', false, 540),
  ('forms.attachment.url_ttl_seconds',  'forms', 'int', '300', 30, 3600, null, 'সংযুক্তি-লিংকের মেয়াদ (সেকেন্ড)', 'MOS-F153-047', true, 550),
  ('forms.offline.draft_ttl_days',      'forms', 'int', '14', 1, 90, null, 'ডিভাইসে অফলাইন-খসড়ার মেয়াদ (দিন)', 'MOS-F153-048', false, 560),
  ('forms.offline.max_drafts',          'forms', 'int', '50', 1, 500, null, 'একজনের সর্বোচ্চ খোলা খসড়া', 'MOS-F153-048', false, 570),
  ('forms.edit.reason_required',        'forms', 'bool', 'true', null, null, null, 'ফেরত/প্রত্যাখ্যাত ফর্ম সংশোধনে কারণ বাধ্যতামূলক', 'MOS-F153-050', false, 580),
  ('forms.list.max_rows',               'forms', 'int', '200', 10, 1000, null, 'তালিকা/রপ্তানিতে সর্বোচ্চ সারি', 'MOS-F153-046', false, 590),
  ('mask.style',                        'mask',  'text', '"partial"', null, null, '["partial","full"]', 'মাস্কিং-ধরন: শেষ অংশ দেখানো / সম্পূর্ণ লুকানো', 'MOS-F153-029', true, 600),
  ('mask.keep_last',                    'mask',  'int', '4', 0, 8, null, 'মাস্কিংয়ে শেষের কতটি অক্ষর দেখা যাবে', 'MOS-F153-029', true, 610),
  ('mask.export_policy',                'mask',  'text', '"redact"', null, null, '["redact","as_screen"]', 'রপ্তানিতে মাস্ক-করা ঘর: সম্পূর্ণ গোপন / পর্দার মতো', 'MOS-F153-029', true, 620);

-- ================================================================ publication (F045)
create function config.fn_form_publish_version(p_company uuid, p_form uuid, p_version integer) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  update config.form_version set status = 'superseded' where form_id = p_form and company_id = p_company and status = 'published';
  update config.form_version set status = 'published', published_at = clock_timestamp() where form_id = p_form and company_id = p_company and version = p_version;
  update config.form set status = case when status = 'archived' then 'archived' else 'active' end, active_version = p_version
   where id = p_form and company_id = p_company;
end $$;

-- A form submission's approval request was approved.
create function config.fn_form_submission_approved(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform set_config('mohona.form_action', 'approve', true);
  update config.form_submission set status = 'approved', decided_at = clock_timestamp()
   where id = r.document_id and company_id = r.company_id and status = 'pending_approval';
  perform set_config('mohona.form_action', 'supersede', true);
  update config.form_submission o set status = 'superseded'
   where o.company_id = r.company_id and o.status in ('submitted','approved')
     and o.id = (select x.amends_id from config.form_submission x where x.id = r.document_id and x.company_id = r.company_id);
  perform set_config('mohona.form_action', '', true);
end $$;

-- Effective status: a pending submission whose request was rejected/cancelled reads as such (decide() runs no handler
-- on rejection; the stored row is moved on the next edit or cancel).
create function config.fn_form_live_status(s config.form_submission) returns text
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v text;
begin
  if s.status <> 'pending_approval' or s.approval_request_id is null then return s.status; end if;
  select r.status into v from core.approval_request r where r.id = s.approval_request_id and r.company_id = s.company_id;
  return case v when 'rejected' then 'rejected' when 'cancelled' then 'cancelled' when 'approved' then 'approved' else s.status end;
end $$;

-- Generic approval handlers: S13 cases + S14 form publication + every form submission ('forms.<code>').
create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- Links uploaded attachments referenced by a submission's photo/file values to it (first use only).
create function config.fn_form_link_attachments(p_company uuid, p_submission uuid, p_def jsonb, p_values jsonb) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare f jsonb; v text;
begin
  for f in select * from jsonb_array_elements(p_def -> 'fields') x where x ->> 'type' in ('photo','file') loop
    v := p_values ->> (f ->> 'key');
    continue when v is null or v !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    update config.form_attachment set status = 'linked', submission_id = p_submission
     where id = v::uuid and company_id = p_company and submission_id is null and status = 'uploaded';
  end loop;
end $$;

-- ================================================================ API: design, publication, field access
create function api.v1_forms_list(p_include_archived boolean default false) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_manage boolean;
begin
  select * into me from iam.fn_require('forms.form.read', iam.fn_my_company_resource(), false);
  select d.allowed into v_manage from iam.fn_authorize('forms.form.manage', iam.fn_resource(me.company_id), false) d;
  return coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'code', f.code, 'name_bn', f.name_bn, 'wing_id', f.wing_id, 'status', f.status,
                         'active_version', f.active_version, 'row_version', f.row_version,
                         'versions', case when v_manage then (select jsonb_agg(jsonb_build_object('version', v.version, 'status', v.status, 'field_count', v.field_count,
                                                                  'reason', v.reason, 'created_at', v.created_at, 'published_at', v.published_at) order by v.version desc)
                                                                from config.form_version v where v.form_id = f.id) end)
                         order by f.code)
                     from config.form f
                    where f.company_id = me.company_id
                      and (f.status = 'active' or (f.status = 'archived' and coalesce(p_include_archived, false)) or (v_manage and f.status = 'draft'))), '[]'::jsonb);
end $$;

-- Definition for filling or reviewing: 'none' fields removed; drafts only for form designers.
create function api.v1_forms_definition(p_form_id uuid, p_version integer default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f config.form%rowtype; v config.form_version%rowtype;
begin
  select * into me from iam.fn_require('forms.form.read', iam.fn_my_company_resource(), false);
  select * into f from config.form where id = p_form_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  select * into v from config.form_version where form_id = f.id and version = coalesce(p_version, f.active_version);
  if not found then perform core.fn_raise('E_FORM_NOT_PUBLISHED'); end if;
  if v.status not in ('published','superseded') then
    perform iam.fn_require('forms.form.manage', iam.fn_resource(me.company_id), false);
  end if;
  return jsonb_build_object('form_id', f.id, 'code', f.code, 'name_bn', f.name_bn, 'wing_id', f.wing_id, 'status', f.status, 'row_version', f.row_version,
           'version', v.version, 'version_status', v.status,
           'definition', config.fn_form_client_definition(me.company_id, f.id, v.definition, me.position_code, me.is_supreme),
           'offline_drafts', config.fn_flag(me.company_id, 'forms.offline_drafts', f.wing_id),
           'limits', jsonb_build_object('attachment_max_mb', config.fn_get_int(me.company_id, 'forms.attachment.max_mb'),
                                        'allowed_mime', config.fn_get(me.company_id, 'forms.attachment.allowed_mime'),
                                        'draft_ttl_days', config.fn_get_int(me.company_id, 'forms.offline.draft_ttl_days'),
                                        'max_drafts', config.fn_get_int(me.company_id, 'forms.offline.max_drafts'),
                                        'money_scale', config.fn_get_int(me.company_id, 'finance.money.scale'),
                                        'hidden_value_policy', config.fn_get_text(me.company_id, 'forms.hidden_value_policy')));
end $$;

-- Creates the form (first call) or adds a new immutable draft version.
create function api.v1_forms_save_version(p_code text, p_name_bn text, p_wing_id uuid, p_definition jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; f config.form%rowtype; n integer; v integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('forms.form.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_code, '') !~ '^[A-Z][A-Z0-9_]{2,40}$' or length(btrim(coalesce(p_name_bn, ''))) = 0 then
    perform core.fn_raise('E_FORM_SCHEMA_INVALID', 'code (A-Z, 3..41) and name_bn required');
  end if;
  if p_wing_id is not null and not exists (select 1 from core.wing w where w.id = p_wing_id and w.company_id = me.company_id) then
    perform core.fn_raise('E_WRONG_COMPANY', 'wing');
  end if;
  n := config.fn_form_validate_definition(p_definition);
  perform set_config('mohona.change_reason', p_reason, true);
  select * into f from config.form where company_id = me.company_id and code = p_code for update;
  if not found then
    insert into config.form (company_id, code, name_bn, wing_id, created_by)
    values (me.company_id, p_code, p_name_bn, p_wing_id, me.person_id) returning * into f;
  else
    if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
    update config.form set name_bn = p_name_bn, wing_id = p_wing_id where id = f.id;
  end if;
  v := coalesce((select max(x.version) from config.form_version x where x.form_id = f.id), 0) + 1;
  insert into config.form_version (company_id, form_id, version, definition, field_count, created_by, reason)
  values (me.company_id, f.id, v, p_definition, n, me.person_id, p_reason);
  return jsonb_build_object('form_id', f.id, 'version', v, 'field_count', n);
end $$;

-- Preview = dry run of the server validation against any version (drafts: designers only). Never writes.
create function api.v1_forms_preview(p_form_id uuid, p_version integer, p_values jsonb) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f config.form%rowtype; v config.form_version%rowtype;
begin
  select * into me from iam.fn_require('forms.form.read', iam.fn_my_company_resource(), false);
  select * into f from config.form where id = p_form_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  select * into v from config.form_version where form_id = f.id and version = coalesce(p_version, f.active_version);
  if not found then perform core.fn_raise('E_FORM_NOT_PUBLISHED'); end if;
  if v.status not in ('published','superseded') then
    perform iam.fn_require('forms.form.manage', iam.fn_resource(me.company_id), false);
  end if;
  return config.fn_form_check(v.definition, coalesce(p_values, '{}'::jsonb), me.company_id, f.id, null, me.person_id, false)
         || jsonb_build_object('version', v.version);
end $$;

-- publish | rollback | archive | restore
create function api.v1_forms_action(p_form_id uuid, p_action text, p_version integer, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; f config.form%rowtype; v config.form_version%rowtype; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('forms.form.manage', iam.fn_my_company_resource(), true);
  select * into f from config.form where id = p_form_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  if f.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_action in ('publish','rollback') then
    if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
    select * into v from config.form_version where form_id = f.id and version = p_version;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'version'); end if;
    if p_action = 'rollback' and (f.active_version is null or p_version >= f.active_version or v.status not in ('superseded','published')) then
      perform core.fn_raise('E_INVALID_ACTION', 'rollback goes to an earlier published version');
    end if;
    if p_action = 'publish' and v.status <> 'draft' then perform core.fn_raise('E_INVALID_ACTION', 'only a draft is published'); end if;
    if p_action = 'publish' and config.fn_get_bool(me.company_id, 'forms.publish.requires_approval') then
      j := core.fn_approval_submit(me.company_id, 'config.form_publish', v.id, 0, iam.fn_resource(me.company_id),
                                   jsonb_build_object('form_id', f.id, 'version', v.version));
      if j ->> 'status' = 'approved' then
        perform config.fn_form_publish_version(me.company_id, f.id, v.version);
        return jsonb_build_object('status', 'published', 'version', v.version);
      end if;
      update config.form_version set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = v.id;
      return jsonb_build_object('status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
    perform config.fn_form_publish_version(me.company_id, f.id, v.version);
    return jsonb_build_object('status', 'published', 'version', v.version);
  elsif p_action = 'archive' and f.status in ('draft','active') then
    update config.form set status = 'archived' where id = f.id;
  elsif p_action = 'restore' and f.status = 'archived' then
    update config.form set status = case when f.active_version is null then 'draft' else 'active' end where id = f.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', coalesce(p_action, '?') || ' from ' || f.status);
  end if;
  return jsonb_build_object('status', (select x.status from config.form x where x.id = f.id));
end $$;

-- Field access per position (position null = every non-Chairman position). Returns the new version.
create function api.v1_forms_set_field_access(p_form_id uuid, p_field_key text, p_position_code text, p_access text,
                                              p_expected_version integer, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; f config.form%rowtype; cur config.form_field_access%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('forms.form.manage', iam.fn_my_company_resource(), true);
  select * into f from config.form where id = p_form_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  if coalesce(p_access, '') not in ('write','entry','read','masked','none') then perform core.fn_raise('E_INVALID_ACTION', 'access'); end if;
  if not exists (select 1 from config.form_version v where v.form_id = f.id and config.fn_form_field(v.definition, p_field_key) is not null) then
    perform core.fn_raise('E_NOT_FOUND', 'field');
  end if;
  if p_position_code is not null then
    if not exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code) then
      perform core.fn_raise('E_NOT_FOUND', 'position');
    end if;
    if exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code and pc.is_supreme) then
      perform core.fn_raise('E_PROTECTED_POSITION', 'the Chairman always sees every field');
    end if;
  end if;
  select * into cur from config.form_field_access a
   where a.form_id = f.id and a.field_key = p_field_key and a.position_code is not distinct from p_position_code and a.status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then update config.form_field_access set status = 'superseded' where id = cur.id; end if;
  v_next := coalesce((select max(a.version) from config.form_field_access a
                       where a.form_id = f.id and a.field_key = p_field_key and a.position_code is not distinct from p_position_code), 0) + 1;
  insert into config.form_field_access (company_id, form_id, field_key, position_code, access, version, set_by, reason)
  values (me.company_id, f.id, p_field_key, p_position_code, p_access, v_next, me.person_id, p_reason);
  return v_next;
end $$;

create function api.v1_forms_field_access(p_form_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('forms.form.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('field_key', a.field_key, 'position_code', a.position_code, 'access', a.access, 'version', a.version,
                                                       'reason', a.reason, 'set_at', a.set_at) order by a.field_key, a.position_code nulls first)
                     from config.form_field_access a where a.form_id = p_form_id and a.company_id = me.company_id and a.status = 'active'), '[]'::jsonb);
end $$;

-- ================================================================ API: submissions (F042..F046, F048..F050)
-- Create (p_submission_id null) or edit a draft. Values are merged honouring field write access, type-checked
-- (required/checks wait for submit), hidden-by-condition values dropped or refused (Chairman setting).
create function api.v1_forms_submission_save(p_form_id uuid, p_submission_id uuid, p_values jsonb, p_wing_id uuid,
                                             p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; v config.form_version%rowtype; s config.form_submission%rowtype;
        v_wing uuid; m jsonb; chk jsonb; j jsonb; v_live text;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  if p_submission_id is null then
    select * into f from config.form where id = p_form_id and company_id = v_company;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
    if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
    if f.active_version is null then perform core.fn_raise('E_FORM_NOT_PUBLISHED'); end if;
    v_wing := coalesce(p_wing_id, f.wing_id);
    if f.wing_id is not null and v_wing <> f.wing_id then perform core.fn_raise('E_INVALID_ACTION', 'form belongs to another wing'); end if;
    select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, v_wing, null, null, null, iam.fn_current_person()), true);
    j := core.fn_idem_begin(me.company_id, 'v1_forms_submission_save', jsonb_build_object('form', p_form_id, 'values', p_values, 'wing', v_wing));
    if j is not null then return j; end if;
    select * into v from config.form_version where form_id = f.id and version = f.active_version;
    m := config.fn_form_merge(me.company_id, f.id, v.definition, '{}'::jsonb, p_values, me.position_code, me.is_supreme);
    if jsonb_array_length(m -> 'forbidden') > 0 then perform core.fn_raise('E_FORM_FIELD_FORBIDDEN', (m -> 'forbidden')::text); end if;
    chk := config.fn_form_check(v.definition, m -> 'values', me.company_id, f.id, null, me.person_id, true);
    if not (chk ->> 'ok')::boolean then perform core.fn_raise('E_FORM_VALIDATION', (chk -> 'errors')::text); end if;
    perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'draft'), true);
    perform set_config('mohona.form_action', 'create', true);
    insert into config.form_submission (company_id, form_id, form_version, wing_id, field_values, created_by)
    values (me.company_id, f.id, v.version, v_wing, chk -> 'values', me.person_id) returning * into s;
  else
    select * into s from config.form_submission where id = p_submission_id and company_id = v_company;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'submission'); end if;
    select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, s.wing_id, null, null, null, s.created_by), true);
    select * into s from config.form_submission where id = p_submission_id and company_id = me.company_id for update;
    if s.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    v_live := config.fn_form_live_status(s);
    if v_live in ('submitted','approved','void','superseded') then perform core.fn_raise('E_FORM_LOCKED', v_live); end if;
    if v_live not in ('draft','returned','rejected') then perform core.fn_raise('E_INVALID_ACTION', 'edit from ' || v_live); end if;
    if v_live in ('returned','rejected') and config.fn_get_bool(me.company_id, 'forms.edit.reason_required') and length(btrim(coalesce(p_reason, ''))) = 0 then
      perform core.fn_raise('E_REASON_REQUIRED');
    end if;
    select * into f from config.form where id = s.form_id;
    if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
    select * into v from config.form_version where form_id = s.form_id and version = s.form_version;    -- pinned version
    m := config.fn_form_merge(me.company_id, f.id, v.definition, s.field_values, p_values, me.position_code, me.is_supreme);
    if jsonb_array_length(m -> 'forbidden') > 0 then perform core.fn_raise('E_FORM_FIELD_FORBIDDEN', (m -> 'forbidden')::text); end if;
    chk := config.fn_form_check(v.definition, m -> 'values', me.company_id, f.id, s.id, s.created_by, true);
    if not (chk ->> 'ok')::boolean then perform core.fn_raise('E_FORM_VALIDATION', (chk -> 'errors')::text); end if;
    perform set_config('mohona.change_reason', coalesce(nullif(btrim(p_reason), ''), 'draft edit'), true);
    perform set_config('mohona.form_action', 'edit', true);
    update config.form_submission set field_values = chk -> 'values', status = 'draft' where id = s.id returning * into s;
  end if;
  perform config.fn_form_link_attachments(me.company_id, s.id, v.definition, s.field_values);
  perform set_config('mohona.form_action', '', true);
  return core.fn_idem_finish(me.company_id, jsonb_build_object('submission_id', s.id, 'status', s.status, 'row_version', s.row_version,
                                                              'form_version', s.form_version));
end $$;

-- Submit: full server validation on the PINNED version, number, Rule Studio, approval engine when needed. Idempotent.
create function api.v1_forms_submission_submit(p_submission_id uuid, p_expected_row_version integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; v config.form_version%rowtype; s config.form_submission%rowtype;
        chk jsonb; j jsonb; v_live text; v_doc text; v_amount numeric := 0; v_facts jsonb; v_rules jsonb; v_no text; v_status text; v_req uuid; ja jsonb;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into s from config.form_submission where id = p_submission_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'submission'); end if;
  select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, s.wing_id, null, null, null, s.created_by), true);
  j := core.fn_idem_begin(me.company_id, 'v1_forms_submission_submit', jsonb_build_object('id', p_submission_id));
  if j is not null then return j; end if;
  select * into s from config.form_submission where id = p_submission_id and company_id = me.company_id for update;
  if s.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  v_live := config.fn_form_live_status(s);
  if v_live in ('submitted','approved','void','superseded') then perform core.fn_raise('E_FORM_LOCKED', v_live); end if;
  if v_live <> 'draft' then perform core.fn_raise('E_INVALID_ACTION', 'submit from ' || v_live); end if;
  select * into f from config.form where id = s.form_id;
  if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
  select * into v from config.form_version where form_id = s.form_id and version = s.form_version;
  chk := config.fn_form_check(v.definition, s.field_values, me.company_id, f.id, s.id, s.created_by, false);   -- server rechecks everything
  if not (chk ->> 'ok')::boolean then perform core.fn_raise('E_FORM_VALIDATION', (chk -> 'errors')::text); end if;
  v_doc := 'forms.' || lower(f.code);
  if v.definition ? 'amount_field' then v_amount := coalesce((chk -> 'values' ->> (v.definition ->> 'amount_field'))::numeric, 0); end if;
  select coalesce(jsonb_object_agg(e.key, e.value), '{}'::jsonb) into v_facts
    from jsonb_each(chk -> 'values') e
   where jsonb_typeof(e.value) in ('number','string','boolean')            -- sensitive values never enter rules/approval payloads (audited)
     and not coalesce((config.fn_form_field(v.definition, e.key) ->> 'sensitive')::boolean, false);
  v_rules := config.fn_rules_evaluate(me.company_id, v_doc, s.wing_id,
               jsonb_build_object('amount', v_amount, 'wing_id', s.wing_id, 'maker_position', me.position_code) || v_facts);
  if (v_rules ->> 'blocked')::boolean then perform core.fn_raise('E_RULE_BLOCKED', v_rules ->> 'message_bn'); end if;
  v_no := core.fn_next_number(me.company_id, v_doc, s.id);
  perform set_config('mohona.change_reason', 'submit', true);
  if coalesce((v.definition -> 'approval' ->> 'required')::boolean, false) or v_rules ? 'required_approvals'
     or coalesce((v_rules ->> 'force_approval')::boolean, false) then
    ja := core.fn_approval_submit(me.company_id, v_doc, s.id, v_amount, iam.fn_resource(me.company_id, s.wing_id, null, null, null, s.created_by),
                                  jsonb_build_object('facts', v_facts, 'form_id', f.id, 'form_version', s.form_version));
    v_status := case when ja ->> 'status' = 'approved' then 'approved' else 'pending_approval' end;
    v_req := (ja ->> 'request_id')::uuid;
  else
    v_status := 'submitted';
  end if;
  perform set_config('mohona.form_action', 'submit', true);
  update config.form_submission
     set status = v_status, number = v_no, field_values = chk -> 'values', submitted_at = clock_timestamp(), approval_request_id = v_req,
         decided_at = case when v_status <> 'pending_approval' then clock_timestamp() end
   where id = s.id returning * into s;
  if v_status <> 'pending_approval' and s.amends_id is not null then
    perform set_config('mohona.form_action', 'supersede', true);
    update config.form_submission set status = 'superseded' where id = s.amends_id and company_id = s.company_id and status in ('submitted','approved');
  end if;
  perform config.fn_form_link_attachments(me.company_id, s.id, v.definition, s.field_values);
  perform set_config('mohona.form_action', '', true);
  return core.fn_idem_finish(me.company_id, jsonb_build_object('submission_id', s.id, 'status', s.status, 'number', s.number,
                                                              'request_id', v_req, 'row_version', s.row_version));
end $$;

-- Offline draft sync (F048): upsert by the device's client_draft_id; never submits, never approves, never overwrites a
-- submission that left draft (returns conflict). Gated by feature flag forms.offline_drafts (company / wing).
create function api.v1_forms_draft_sync(p_form_id uuid, p_client_draft_id text, p_form_version integer, p_values jsonb, p_wing_id uuid,
                                        p_client_saved_at timestamptz) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; v config.form_version%rowtype; s config.form_submission%rowtype;
        v_wing uuid; m jsonb; chk jsonb; v_live text; v_saved timestamptz := least(coalesce(p_client_saved_at, clock_timestamp()), clock_timestamp());
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into f from config.form where id = p_form_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
  v_wing := coalesce(p_wing_id, f.wing_id);
  if f.wing_id is not null and v_wing <> f.wing_id then perform core.fn_raise('E_INVALID_ACTION', 'form belongs to another wing'); end if;
  if not config.fn_flag(v_company, 'forms.offline_drafts', v_wing) then perform core.fn_raise('E_FEATURE_DISABLED', 'offline drafts'); end if;
  if coalesce(p_client_draft_id, '') !~ '^[A-Za-z0-9_-]{8,64}$' then perform core.fn_raise('E_INVALID_ACTION', 'client draft id'); end if;
  select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, v_wing, null, null, null, iam.fn_current_person()), true);
  select * into v from config.form_version where form_id = f.id and version = p_form_version and status in ('published','superseded');
  if not found then perform core.fn_raise('E_FORM_NOT_PUBLISHED'); end if;
  select * into s from config.form_submission
   where company_id = me.company_id and created_by = me.person_id and client_draft_id = p_client_draft_id for update;
  if found then
    if s.form_id <> f.id then perform core.fn_raise('E_IDEMPOTENCY_MISMATCH', 'client draft id belongs to another form'); end if;
    v_live := config.fn_form_live_status(s);
    if v_live <> 'draft' or s.form_version <> p_form_version then
      return jsonb_build_object('submission_id', s.id, 'status', v_live, 'number', s.number, 'row_version', s.row_version,
                                'form_version', s.form_version, 'conflict', true);
    end if;
    m := config.fn_form_merge(me.company_id, f.id, v.definition, s.field_values, p_values, me.position_code, me.is_supreme);
    if jsonb_array_length(m -> 'forbidden') > 0 then perform core.fn_raise('E_FORM_FIELD_FORBIDDEN', (m -> 'forbidden')::text); end if;
    chk := config.fn_form_check(v.definition, m -> 'values', me.company_id, f.id, s.id, s.created_by, true);
    if not (chk ->> 'ok')::boolean then perform core.fn_raise('E_FORM_VALIDATION', (chk -> 'errors')::text); end if;
    perform set_config('mohona.change_reason', 'offline draft sync', true);
    perform set_config('mohona.form_action', 'sync', true);
    update config.form_submission set field_values = chk -> 'values', client_saved_at = v_saved where id = s.id returning * into s;
  else
    if (select count(*) from config.form_submission x where x.company_id = me.company_id and x.created_by = me.person_id and x.status = 'draft')
       >= config.fn_get_int(me.company_id, 'forms.offline.max_drafts') then
      perform core.fn_raise('E_FORM_DRAFT_LIMIT');
    end if;
    m := config.fn_form_merge(me.company_id, f.id, v.definition, '{}'::jsonb, p_values, me.position_code, me.is_supreme);
    if jsonb_array_length(m -> 'forbidden') > 0 then perform core.fn_raise('E_FORM_FIELD_FORBIDDEN', (m -> 'forbidden')::text); end if;
    chk := config.fn_form_check(v.definition, m -> 'values', me.company_id, f.id, null, me.person_id, true);
    if not (chk ->> 'ok')::boolean then perform core.fn_raise('E_FORM_VALIDATION', (chk -> 'errors')::text); end if;
    perform set_config('mohona.change_reason', 'offline draft sync', true);
    perform set_config('mohona.form_action', 'sync', true);
    insert into config.form_submission (company_id, form_id, form_version, wing_id, field_values, origin, client_draft_id, client_saved_at, created_by)
    values (me.company_id, f.id, v.version, v_wing, chk -> 'values', 'offline', p_client_draft_id, v_saved, me.person_id) returning * into s;
  end if;
  perform config.fn_form_link_attachments(me.company_id, s.id, v.definition, s.field_values);
  perform set_config('mohona.form_action', '', true);
  return jsonb_build_object('submission_id', s.id, 'status', s.status, 'row_version', s.row_version, 'form_version', s.form_version, 'conflict', false);
end $$;

-- Read one submission as the caller may see it.
create function api.v1_forms_submission_get(p_submission_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; v config.form_version%rowtype; s config.form_submission%rowtype; p jsonb;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into s from config.form_submission where id = p_submission_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'submission'); end if;
  select * into me from iam.fn_require('forms.submission.read', iam.fn_resource(v_company, s.wing_id, null, null, null, s.created_by), false);
  select * into f from config.form where id = s.form_id;
  select * into v from config.form_version where form_id = s.form_id and version = s.form_version;
  p := config.fn_form_project(me.company_id, f.id, v.definition, s.field_values, me.position_code, me.is_supreme, 'view');
  return jsonb_build_object('id', s.id, 'form_id', f.id, 'form_code', f.code, 'form_name_bn', f.name_bn, 'form_status', f.status,
           'form_version', s.form_version, 'wing_id', s.wing_id, 'number', s.number, 'status', config.fn_form_live_status(s), 'origin', s.origin,
           'created_by', s.created_by, 'created_at', s.created_at, 'submitted_at', s.submitted_at, 'decided_at', s.decided_at,
           'amends_id', s.amends_id, 'approval_request_id', s.approval_request_id, 'row_version', s.row_version,
           'values', p -> 'values', 'access', p -> 'access', 'masked', p -> 'masked',
           'definition', config.fn_form_client_definition(me.company_id, f.id, v.definition, me.position_code, me.is_supreme),
           'attachments', coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'field_key', a.field_key, 'kind', a.kind, 'mime_type', a.mime_type,
                                                                        'size_bytes', a.size_bytes, 'status', a.status))
                                      from config.form_attachment a
                                     where a.submission_id = s.id and a.company_id = s.company_id
                                       and (p -> 'access' ->> a.field_key) in ('read','write')), '[]'::jsonb));
end $$;

-- List: only rows the caller may read (per-row scope check), values projected per field access.
create function api.v1_forms_submissions(p_form_id uuid, p_status text default null, p_limit integer default 50) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f config.form%rowtype; s config.form_submission%rowtype; v_def jsonb; v_ver integer := -1; v_ok boolean;
        out jsonb := '[]'::jsonb; n integer := 0; v_limit integer; v_live text; p jsonb;
begin
  select * into me from iam.fn_require('forms.form.read', iam.fn_my_company_resource(), false);
  select * into f from config.form where id = p_form_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  v_limit := greatest(1, least(coalesce(p_limit, 50), config.fn_get_int(me.company_id, 'forms.list.max_rows')));
  for s in select * from config.form_submission x where x.company_id = me.company_id and x.form_id = f.id order by x.form_version, x.created_at desc loop
    v_live := config.fn_form_live_status(s);
    continue when p_status is not null and v_live <> p_status;
    select d.allowed into v_ok from iam.fn_authorize('forms.submission.read', iam.fn_resource(me.company_id, s.wing_id, null, null, null, s.created_by), false) d;
    continue when not coalesce(v_ok, false);
    if s.form_version <> v_ver then
      select x.definition into v_def from config.form_version x where x.form_id = f.id and x.version = s.form_version; v_ver := s.form_version;
    end if;
    p := config.fn_form_project(me.company_id, f.id, v_def, s.field_values, me.position_code, me.is_supreme, 'view');
    out := out || jsonb_build_array(jsonb_build_object('id', s.id, 'number', s.number, 'status', v_live, 'form_version', s.form_version, 'wing_id', s.wing_id,
                                                       'created_by', s.created_by, 'created_at', s.created_at, 'submitted_at', s.submitted_at,
                                                       'row_version', s.row_version, 'values', p -> 'values', 'masked', p -> 'masked'));
    n := n + 1;
    exit when n >= v_limit;
  end loop;
  return coalesce((select jsonb_agg(e order by e ->> 'created_at' desc) from jsonb_array_elements(out) e), '[]'::jsonb);
end $$;

-- Value history (F050), masked with the reader's CURRENT access; fields the reader may not see are left out.
create function api.v1_forms_submission_history(p_submission_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_company uuid; s config.form_submission%rowtype; v config.form_version%rowtype; r record; a jsonb; b jsonb; out jsonb := '[]'::jsonb;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into s from config.form_submission where id = p_submission_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'submission'); end if;
  select * into me from iam.fn_require('forms.submission.read', iam.fn_resource(v_company, s.wing_id, null, null, null, s.created_by), false);
  select * into v from config.form_version where form_id = s.form_id and version = s.form_version;
  for r in select * from config.form_submission_revision x where x.submission_id = s.id and x.company_id = s.company_id order by x.revision loop
    b := config.fn_form_project(me.company_id, s.form_id, v.definition, coalesce(r.values_before, '{}'::jsonb), me.position_code, me.is_supreme, 'view');
    a := config.fn_form_project(me.company_id, s.form_id, v.definition, r.values_after, me.position_code, me.is_supreme, 'view');
    out := out || jsonb_build_array(jsonb_build_object('revision', r.revision, 'action', r.action, 'status_from', r.status_from, 'status_to', r.status_to,
             'before', case when r.values_before is null then null else b -> 'values' end, 'after', a -> 'values',
             'changed_fields', coalesce((select jsonb_agg(cf) from unnest(r.changed_fields) cf where not ((a -> 'omitted') ? cf)), '[]'::jsonb),
             'actor_person_id', r.actor_person_id, 'reason', r.reason, 'created_at', r.created_at));
  end loop;
  return out;
end $$;

-- cancel (draft/rejected/pending) | void (submitted/approved; permission forms.submission.void) | amend (new draft linked to it)
create function api.v1_forms_submission_action(p_submission_id uuid, p_action text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; nv config.form_version%rowtype; s config.form_submission%rowtype; n config.form_submission%rowtype;
        v_live text; v_vals jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into s from config.form_submission where id = p_submission_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'submission'); end if;
  if p_action = 'void' then
    select * into me from iam.fn_require('forms.submission.void', iam.fn_resource(v_company, s.wing_id), true);
  else
    select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, s.wing_id, null, null, null, s.created_by), true);
  end if;
  select * into s from config.form_submission where id = p_submission_id and company_id = me.company_id for update;
  if s.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  v_live := config.fn_form_live_status(s);
  perform set_config('mohona.change_reason', p_reason, true);
  perform set_config('mohona.form_action', p_action, true);
  if p_action = 'cancel' and v_live in ('draft','returned','rejected','pending_approval') then
    if v_live = 'pending_approval' then
      update core.approval_request set status = 'cancelled', decided_at = clock_timestamp()
       where id = s.approval_request_id and company_id = s.company_id and status = 'pending';
    end if;
    update config.form_submission set status = 'cancelled' where id = s.id returning * into s;
  elsif p_action = 'void' and s.status in ('submitted','approved') then
    update config.form_submission set status = 'void' where id = s.id returning * into s;
  elsif p_action = 'amend' and s.status in ('submitted','approved') then
    select * into f from config.form where id = s.form_id;
    if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
    if exists (select 1 from config.form_submission x where x.amends_id = s.id and x.company_id = s.company_id and x.status in ('draft','pending_approval')) then
      perform core.fn_raise('E_DUPLICATE', 'an amendment is already open');
    end if;
    select * into nv from config.form_version where form_id = f.id and version = f.active_version;
    -- the amendment is a new record on the ACTIVE version; values of fields that no longer exist and attachments are not carried
    select coalesce(jsonb_object_agg(e.key, e.value), '{}'::jsonb) into v_vals
      from jsonb_each(s.field_values) e
     where config.fn_form_field(nv.definition, e.key) is not null and config.fn_form_field(nv.definition, e.key) ->> 'type' not in ('photo','file');
    insert into config.form_submission (company_id, form_id, form_version, wing_id, field_values, amends_id, created_by)
    values (s.company_id, f.id, nv.version, s.wing_id, v_vals, s.id, me.person_id) returning * into n;
    perform set_config('mohona.form_action', '', true);
    return jsonb_build_object('submission_id', n.id, 'status', n.status, 'row_version', n.row_version, 'amends_id', s.id, 'form_version', n.form_version);
  else
    perform core.fn_raise('E_INVALID_ACTION', coalesce(p_action, '?') || ' from ' || v_live);
  end if;
  perform set_config('mohona.form_action', '', true);
  return jsonb_build_object('submission_id', s.id, 'status', s.status, 'row_version', s.row_version);
end $$;

-- Export (F046 "deny sensitive field extraction"): permission forms.submission.export; per-row read scope; masked fields
-- redacted (Chairman setting mask.export_policy), 'none' fields omitted; every export logged.
create function api.v1_forms_export(p_form_id uuid, p_limit integer default 200) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; s config.form_submission%rowtype; v_def jsonb; v_ver integer := -1; v_ok boolean; p jsonb;
        v_rows jsonb := '[]'::jsonb; n integer := 0; v_limit integer; v_red text[] := array[]::text[]; v_omit text[] := array[]::text[];
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into f from config.form where id = p_form_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  select * into me from iam.fn_require('forms.submission.export', iam.fn_resource(v_company, f.wing_id), false);
  v_limit := greatest(1, least(coalesce(p_limit, 200), config.fn_get_int(me.company_id, 'forms.list.max_rows')));
  for s in select * from config.form_submission x
            where x.company_id = me.company_id and x.form_id = f.id and x.status in ('submitted','approved','pending_approval')
            order by x.form_version, x.created_at loop
    select d.allowed into v_ok from iam.fn_authorize('forms.submission.read', iam.fn_resource(me.company_id, s.wing_id, null, null, null, s.created_by), false) d;
    continue when not coalesce(v_ok, false);
    if s.form_version <> v_ver then
      select x.definition into v_def from config.form_version x where x.form_id = f.id and x.version = s.form_version; v_ver := s.form_version;
    end if;
    p := config.fn_form_project(me.company_id, f.id, v_def, s.field_values, me.position_code, me.is_supreme, 'export');
    v_rows := v_rows || jsonb_build_array(jsonb_build_object('number', s.number, 'status', config.fn_form_live_status(s), 'form_version', s.form_version,
                                                         'submitted_at', s.submitted_at, 'values', p -> 'values'));
    v_red := array(select distinct x from unnest(v_red || array(select jsonb_array_elements_text(p -> 'masked'))) x);
    v_omit := array(select distinct x from unnest(v_omit || array(select jsonb_array_elements_text(p -> 'omitted'))) x);
    n := n + 1;
    exit when n >= v_limit;
  end loop;
  insert into config.form_export_log (company_id, form_id, person_id, position_code, row_count, redacted_fields, omitted_fields)
  values (me.company_id, f.id, me.person_id, me.position_code, n, v_red, v_omit);
  return jsonb_build_object('form_id', f.id, 'code', f.code, 'rows', v_rows, 'row_count', n, 'redacted_fields', to_jsonb(v_red),
                            'omitted_fields', to_jsonb(v_omit), 'exported_at', clock_timestamp());
end $$;

-- ================================================================ API: attachments (F047)
create function api.v1_forms_attachment_begin(p_form_id uuid, p_field_key text, p_mime_type text, p_size_bytes bigint, p_sha256 text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; f config.form%rowtype; v config.form_version%rowtype; fld jsonb; v_id uuid := gen_random_uuid(); v_path text; v_ttl integer;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into f from config.form where id = p_form_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'form'); end if;
  if f.status = 'archived' then perform core.fn_raise('E_FORM_ARCHIVED'); end if;
  if f.active_version is null then perform core.fn_raise('E_FORM_NOT_PUBLISHED'); end if;
  select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, f.wing_id, null, null, null, iam.fn_current_person()), true);
  select * into v from config.form_version where form_id = f.id and version = f.active_version;
  fld := config.fn_form_field(v.definition, p_field_key);
  if fld is null or fld ->> 'type' not in ('photo','file') then perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'not an attachment field'); end if;
  if config.fn_form_field_access(me.company_id, f.id, fld, me.position_code, me.is_supreme) not in ('write','entry') then
    perform core.fn_raise('E_FORM_FIELD_FORBIDDEN', p_field_key);
  end if;
  if not (coalesce(p_mime_type, '') = any (config.fn_get_text_array(me.company_id, 'forms.attachment.allowed_mime')))
     or (fld ->> 'type' = 'photo' and p_mime_type not like 'image/%') then
    perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'type ' || coalesce(p_mime_type, '?'));
  end if;
  if coalesce(p_size_bytes, 0) not between 1 and config.fn_get_int(me.company_id, 'forms.attachment.max_mb')::bigint * 1048576 then
    perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'size');
  end if;
  if coalesce(p_sha256, '') !~ '^[0-9a-f]{64}$' then perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'sha256'); end if;
  -- the path is built by the server only: <company>/<form>/<attachment>.<ext>
  v_path := me.company_id::text || '/' || f.id::text || '/' || v_id::text || '.' ||
            case p_mime_type when 'image/jpeg' then 'jpg' when 'image/png' then 'png' when 'image/webp' then 'webp' when 'image/heic' then 'heic'
                             when 'application/pdf' then 'pdf' when 'text/csv' then 'csv' else 'bin' end;
  v_ttl := config.fn_get_int(me.company_id, 'forms.attachment.url_ttl_seconds');
  perform set_config('mohona.change_reason', 'attachment upload', true);
  insert into config.form_attachment (id, company_id, form_id, field_key, kind, mime_type, size_bytes, sha256, object_path, created_by)
  values (v_id, me.company_id, f.id, p_field_key, fld ->> 'type', p_mime_type, p_size_bytes, p_sha256, v_path, me.person_id);
  insert into config.form_attachment_grant (company_id, attachment_id, person_id, purpose, expires_at)
  values (me.company_id, v_id, me.person_id, 'upload', clock_timestamp() + make_interval(secs => v_ttl));
  return jsonb_build_object('attachment_id', v_id, 'bucket', 'forms', 'path', v_path, 'expires_in', v_ttl);
end $$;

-- Marks an upload complete. On Supabase the object must exist in storage; plain PostgreSQL (tests) has no storage schema.
create function api.v1_forms_attachment_confirm(p_attachment_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; a config.form_attachment%rowtype; f config.form%rowtype; v_exists boolean := true;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into a from config.form_attachment where id = p_attachment_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'attachment'); end if;
  select * into f from config.form where id = a.form_id;
  select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, f.wing_id, null, null, null, a.created_by), true);
  if a.created_by <> me.person_id then perform core.fn_raise('E_FORBIDDEN', 'only the uploader confirms'); end if;
  select * into a from config.form_attachment where id = p_attachment_id and company_id = me.company_id for update;
  if a.status <> 'pending' then return jsonb_build_object('attachment_id', a.id, 'status', a.status); end if;
  if to_regclass('storage.objects') is not null then
    execute 'select exists (select 1 from storage.objects o where o.bucket_id = $1 and o.name = $2)' into v_exists using a.bucket, a.object_path;
  end if;
  if not v_exists then perform core.fn_raise('E_FORM_ATTACHMENT_MISSING'); end if;
  perform set_config('mohona.change_reason', 'attachment uploaded', true);
  update config.form_attachment set status = 'uploaded' where id = a.id returning * into a;
  return jsonb_build_object('attachment_id', a.id, 'status', a.status);
end $$;

-- Read access: a short-lived grant for exactly this object; masked/hidden fields never get one.
create function api.v1_forms_attachment_access(p_attachment_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_company uuid; a config.form_attachment%rowtype; f config.form%rowtype; s config.form_submission%rowtype; v_def jsonb; v_ttl integer;
begin
  v_company := (iam.fn_my_company_resource()).company_id;
  select * into a from config.form_attachment where id = p_attachment_id and company_id = v_company;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'attachment'); end if;
  select * into f from config.form where id = a.form_id;
  if a.submission_id is null then
    select * into me from iam.fn_require('forms.submission.write', iam.fn_resource(v_company, f.wing_id, null, null, null, a.created_by), false);
    if a.created_by <> me.person_id then perform core.fn_raise('E_FORBIDDEN', 'attachment'); end if;
    select x.definition into v_def from config.form_version x where x.form_id = f.id and x.version = f.active_version;
  else
    select * into s from config.form_submission where id = a.submission_id;
    select * into me from iam.fn_require('forms.submission.read', iam.fn_resource(v_company, s.wing_id, null, null, null, s.created_by), false);
    select x.definition into v_def from config.form_version x where x.form_id = s.form_id and x.version = s.form_version;
  end if;
  if config.fn_form_field_access(me.company_id, f.id, coalesce(config.fn_form_field(v_def, a.field_key), jsonb_build_object('key', a.field_key)),
                                 me.position_code, me.is_supreme) not in ('read','write') then
    perform core.fn_raise('E_FORM_FIELD_FORBIDDEN', a.field_key);
  end if;
  if a.status not in ('uploaded','linked') then perform core.fn_raise('E_FORM_ATTACHMENT_MISSING'); end if;
  v_ttl := config.fn_get_int(me.company_id, 'forms.attachment.url_ttl_seconds');
  insert into config.form_attachment_grant (company_id, attachment_id, person_id, purpose, expires_at)
  values (me.company_id, a.id, me.person_id, 'read', clock_timestamp() + make_interval(secs => v_ttl));
  return jsonb_build_object('attachment_id', a.id, 'bucket', a.bucket, 'path', a.object_path, 'mime_type', a.mime_type, 'expires_in', v_ttl);
end $$;

-- Storage-policy predicates (storage.objects policies call these; they only answer for the caller's own live grants).
create function api.v1_forms_storage_can_read(p_bucket text, p_name text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from config.form_attachment a join config.form_attachment_grant g on g.attachment_id = a.id and g.company_id = a.company_id
                  where a.bucket = p_bucket and a.object_path = p_name and a.status in ('uploaded','linked') and g.purpose = 'read'
                    and g.person_id = iam.fn_current_person() and g.expires_at > clock_timestamp())
$$;
create function api.v1_forms_storage_can_upload(p_bucket text, p_name text) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from config.form_attachment a join config.form_attachment_grant g on g.attachment_id = a.id and g.company_id = a.company_id
                  where a.bucket = p_bucket and a.object_path = p_name and a.status = 'pending' and g.purpose = 'upload'
                    and g.person_id = iam.fn_current_person() and g.expires_at > clock_timestamp())
$$;

-- ================================================================ API: generic mask policy (base of F029)
create function api.v1_mask_policies(p_prefix text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('field_key', m.field_key, 'position_code', m.position_code, 'mode', m.mode, 'version', m.version,
                                                       'reason', m.reason, 'set_at', m.set_at) order by m.field_key, m.position_code nulls first)
                     from config.mask_policy m
                    where m.company_id = me.company_id and m.status = 'active' and (p_prefix is null or m.field_key like p_prefix || '%')), '[]'::jsonb);
end $$;

create function api.v1_mask_set_policy(p_field_key text, p_position_code text, p_mode text, p_expected_version integer, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; cur config.mask_policy%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.mask.manage', iam.fn_my_company_resource(), true);
  if coalesce(p_field_key, '') !~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+){1,4}$' or coalesce(p_mode, '') not in ('show','mask','hide') then
    perform core.fn_raise('E_INVALID_ACTION', 'field key / mode');
  end if;
  if p_position_code is not null then
    if not exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code) then
      perform core.fn_raise('E_NOT_FOUND', 'position');
    end if;
    if exists (select 1 from iam.position_catalog pc where pc.company_id = me.company_id and pc.code = p_position_code and pc.is_supreme) then
      perform core.fn_raise('E_PROTECTED_POSITION', 'the Chairman always sees every field');
    end if;
  end if;
  select * into cur from config.mask_policy m
   where m.company_id = me.company_id and m.field_key = p_field_key and m.position_code is not distinct from p_position_code and m.status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then update config.mask_policy set status = 'superseded' where id = cur.id; end if;
  v_next := coalesce((select max(m.version) from config.mask_policy m
                       where m.company_id = me.company_id and m.field_key = p_field_key and m.position_code is not distinct from p_position_code), 0) + 1;
  insert into config.mask_policy (company_id, field_key, position_code, mode, version, set_by, reason)
  values (me.company_id, p_field_key, p_position_code, p_mode, v_next, me.person_id, p_reason);
  return v_next;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_forms_list(boolean)', 'api.v1_forms_definition(uuid, integer)',
      'api.v1_forms_save_version(text, text, uuid, jsonb, text)', 'api.v1_forms_preview(uuid, integer, jsonb)',
      'api.v1_forms_action(uuid, text, integer, integer, text)', 'api.v1_forms_set_field_access(uuid, text, text, text, integer, text)',
      'api.v1_forms_field_access(uuid)', 'api.v1_forms_submission_save(uuid, uuid, jsonb, uuid, integer, text)',
      'api.v1_forms_submission_submit(uuid, integer)', 'api.v1_forms_draft_sync(uuid, text, integer, jsonb, uuid, timestamptz)',
      'api.v1_forms_submission_get(uuid)', 'api.v1_forms_submissions(uuid, text, integer)', 'api.v1_forms_submission_history(uuid)',
      'api.v1_forms_submission_action(uuid, text, integer, text)', 'api.v1_forms_export(uuid, integer)',
      'api.v1_forms_attachment_begin(uuid, text, text, bigint, text)', 'api.v1_forms_attachment_confirm(uuid)',
      'api.v1_forms_attachment_access(uuid)', 'api.v1_forms_storage_can_read(text, text)', 'api.v1_forms_storage_can_upload(text, text)',
      'api.v1_mask_policies(text)', 'api.v1_mask_set_policy(text, text, text, integer, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- Supabase Storage (best-effort, like OI-02): private bucket 'forms' + policies that accept only live per-person grants.
-- Plain PostgreSQL has no storage schema: nothing to do. A failure here is reported, never silently ignored.
do $$
begin
  if to_regclass('storage.objects') is null or to_regclass('storage.buckets') is null then
    raise notice 'MOHONA S14: no storage schema (plain PostgreSQL) - form attachment storage policies skipped';
    return;
  end if;
  execute $q$insert into storage.buckets (id, name, public) values ('forms', 'forms', false) on conflict (id) do update set public = false$q$;
  execute 'drop policy if exists mohona_forms_read on storage.objects';
  execute 'drop policy if exists mohona_forms_upload on storage.objects';
  execute $q$create policy mohona_forms_read on storage.objects for select to authenticated
             using (bucket_id = 'forms' and api.v1_forms_storage_can_read(bucket_id, name))$q$;
  execute $q$create policy mohona_forms_upload on storage.objects for insert to authenticated
             with check (bucket_id = 'forms' and api.v1_forms_storage_can_upload(bucket_id, name))$q$;
  execute 'grant select on storage.objects to erp_owner';
exception when insufficient_privilege then
  raise warning 'MOHONA S14: storage policies for bucket forms could not be created (privilege) - create them in the Supabase dashboard (see docs/FORMS_BN.md)';
end $$;

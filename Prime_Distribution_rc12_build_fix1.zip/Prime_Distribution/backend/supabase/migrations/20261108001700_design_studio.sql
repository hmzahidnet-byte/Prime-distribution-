-- 20261108001700_design_studio.sql  (S18)
-- Design Studio 1 (blueprint CHAIRMAN_DESIGN MOS-F153-001..005):
--   001 theme catalog: platform templates + company themes with immutable versions; a publish is refused when the
--       server validation finds an accessibility error (low contrast, clipped amounts, unreadable density)
--   002 palette: semantic colours (text, muted, primary, states, per-position accents); contrast-breaking TEXT colours denied
--   003 typography: Bengali-friendly scale/sizes/line height; sizes that would clip money on cards are refused
--   004 icons: whitelisted icon catalog (no uploaded code/SVG); an icon bound to an ACTION carries that action's
--       permission so the app never shows an icon implying something the position may not do
--   005 card composer: border, radius, padding, elevation within readable-density limits
-- Layout grid, presets, animation, responsive preview and rollback follow in S19.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ tables
create table design.theme_template (
  code        text primary key check (code ~ '^[A-Z][A-Z0-9_]{2,30}$'),
  name_bn     text not null,
  tokens      jsonb not null,
  sort_order  integer not null default 0
);
create trigger trg_theme_template_nodel before delete on design.theme_template for each row execute function core.fn_deny_delete();

create table design.theme (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  code            text not null check (code ~ '^[A-Z][A-Z0-9_]{2,30}$'),
  name_bn         text not null check (length(btrim(name_bn)) > 0),
  from_template   text references design.theme_template(code),
  is_active       boolean not null default false,
  active_version  integer,
  created_by      uuid,
  created_at      timestamptz not null default clock_timestamp(),
  updated_at      timestamptz not null default clock_timestamp(),
  row_version     integer not null default 1,
  unique (id, company_id),
  unique (company_id, code),
  check (not is_active or active_version is not null)
);
create unique index theme_one_active on design.theme (company_id) where is_active;
create trigger trg_theme_touch before update on design.theme for each row execute function core.fn_touch_row();
create trigger trg_theme_nodel before delete on design.theme for each row execute function core.fn_deny_delete();
create trigger trg_theme_audit after insert or update on design.theme for each row execute function audit.fn_row_change();

create table design.theme_version (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  theme_id            uuid not null,
  version             integer not null check (version >= 1),
  tokens              jsonb not null,
  report              jsonb not null,
  status              text not null default 'draft' check (status in ('draft','pending_approval','published','superseded')),
  reason              text not null check (length(btrim(reason)) > 0),
  created_by          uuid,
  created_at          timestamptz not null default clock_timestamp(),
  published_at        timestamptz,
  approval_request_id uuid,
  unique (theme_id, version),
  foreign key (theme_id, company_id) references design.theme (id, company_id)
);
create function design.fn_theme_version_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.tokens is distinct from old.tokens or new.version <> old.version or new.theme_id <> old.theme_id or new.company_id <> old.company_id
     or new.report is distinct from old.report then
    raise exception 'E_IMMUTABLE: a theme version never changes; save a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_theme_version_guard before update on design.theme_version for each row execute function design.fn_theme_version_guard();
create trigger trg_theme_version_nodel before delete on design.theme_version for each row execute function core.fn_deny_delete();
create trigger trg_theme_version_audit after insert or update on design.theme_version for each row execute function audit.fn_row_change();

-- Whitelisted icon names (Material icon set shipped in the app). Nothing executable or uploaded.
create table design.icon_catalog (
  name      text primary key check (name ~ '^[A-Z][A-Za-z0-9]{1,40}$'),
  grp       text not null check (grp ~ '^[a-z_]{2,20}$'),
  label_bn  text not null
);
create trigger trg_icon_catalog_nodel before delete on design.icon_catalog for each row execute function core.fn_deny_delete();

create table design.icon_binding (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references core.company(id),
  target_key       text not null check (target_key ~ '^(module|action|tab|kpi|status)\.[a-z0-9_.]{2,80}$'),
  icon_name        text not null references design.icon_catalog(name),
  permission_code  text references iam.permission_catalog(code),
  version          integer not null check (version >= 1),
  status           text not null default 'active' check (status in ('active','superseded')),
  set_by           uuid,
  set_at           timestamptz not null default clock_timestamp(),
  reason           text not null check (length(btrim(reason)) > 0),
  check (target_key !~ '^action\.' or permission_code is not null)
);
create unique index icon_binding_one_active on design.icon_binding (company_id, target_key) where status = 'active';
create trigger trg_icon_binding_guard before update on design.icon_binding for each row execute function config.fn_history_only_supersede();
create trigger trg_icon_binding_nodel before delete on design.icon_binding for each row execute function core.fn_deny_delete();
create trigger trg_icon_binding_audit after insert or update on design.icon_binding for each row execute function audit.fn_row_change();

select core.fn_apply_rls('design', 'theme_template');
select core.fn_apply_rls('design', 'theme');
select core.fn_apply_rls('design', 'theme_version');
select core.fn_apply_rls('design', 'icon_catalog');
select core.fn_apply_rls('design', 'icon_binding');

-- ================================================================ validation (server = authority)
create function design.fn_hex_ok(p text) returns boolean
language sql immutable set search_path = pg_catalog as $$ select coalesce(p, '') ~ '^#[0-9A-Fa-f]{6}$' $$;

-- WCAG 2.x relative luminance of #RRGGBB.
create function design.fn_luminance(p text) returns numeric
language plpgsql immutable set search_path = pg_catalog as $$
declare ch numeric[] := array[]::numeric[]; v numeric; i integer;
begin
  for i in 0..2 loop
    v := (('x' || substr(p, 2 + i * 2, 2))::bit(8)::integer)::numeric / 255;
    ch := ch || case when v <= 0.03928 then v / 12.92 else power((v + 0.055) / 1.055, 2.4) end;
  end loop;
  return 0.2126 * ch[1] + 0.7152 * ch[2] + 0.0722 * ch[3];
end $$;

create function design.fn_contrast(a text, b text) returns numeric
language sql immutable set search_path = pg_catalog as $$
  select round((greatest(design.fn_luminance(a), design.fn_luminance(b)) + 0.05) / (least(design.fn_luminance(a), design.fn_luminance(b)) + 0.05), 2)
$$;

-- Full report {ok, errors[], warnings[], contrast{}} for a token set (same floors as the app's TokenCodec, S04).
create function design.fn_tokens_report(p jsonb) returns jsonb
language plpgsql immutable set search_path = pg_catalog as $$
declare errs text[] := array[]::text[]; warns text[] := array[]::text[]; ratios jsonb := '{}'::jsonb; c jsonb; t jsonb; s jsonb; sp jsonb; cd jsonb;
        k text; v jsonb; r numeric; sc numeric;
        c_required constant text[] := array['primary','onPrimary','background','surfaceAlt','text','textMuted','divider','good','warn','bad','info'];
        c_allowed  constant text[] := array['primary','primaryDark','primarySoft','onPrimary','background','surfaceAlt','text','textMuted','divider',
                                            'good','warn','bad','info','chart','roleAccent','states'];
begin
  if p is null or jsonb_typeof(p) <> 'object' then return jsonb_build_object('ok', false, 'errors', jsonb_build_array('tokens must be an object')); end if;
  for k in select jsonb_object_keys(p) loop
    if k not in ('revision','colors','type','shapes','spacing','cards') then errs := errs || ('unknown section ' || k); end if;
  end loop;
  c := coalesce(p -> 'colors', '{}'::jsonb); t := coalesce(p -> 'type', '{}'::jsonb); s := coalesce(p -> 'shapes', '{}'::jsonb);
  sp := coalesce(p -> 'spacing', '{}'::jsonb); cd := coalesce(p -> 'cards', '{}'::jsonb);
  -- colours: structure
  foreach k in array c_required loop
    if not design.fn_hex_ok(c ->> k) then errs := errs || ('colors.' || k || ' must be #RRGGBB'); end if;
  end loop;
  for k in select jsonb_object_keys(c) loop
    if not (k = any (c_allowed)) then errs := errs || ('unknown colour ' || k);
    elsif k not in ('chart','roleAccent','states') and not design.fn_hex_ok(c ->> k) then errs := errs || ('colors.' || k || ' must be #RRGGBB');
    end if;
  end loop;
  if jsonb_typeof(c -> 'chart') is distinct from 'array' or jsonb_array_length(c -> 'chart') not between 2 and 12
     or exists (select 1 from jsonb_array_elements_text(c -> 'chart') x where not design.fn_hex_ok(x)) then
    errs := errs || 'colors.chart needs 2..12 #RRGGBB colours'::text;
  end if;
  if cardinality(errs) = 0 then
    -- text colours: hard floors (palette may never make text unreadable)
    r := design.fn_contrast(c ->> 'text', c ->> 'background'); ratios := ratios || jsonb_build_object('text/background', r);
    if r < 4.5 then errs := errs || ('text/background contrast ' || r || ' < 4.5'); end if;
    r := design.fn_contrast(c ->> 'text', c ->> 'surfaceAlt'); ratios := ratios || jsonb_build_object('text/surfaceAlt', r);
    if r < 4.5 then errs := errs || ('text/surfaceAlt contrast ' || r || ' < 4.5'); end if;
    r := design.fn_contrast(c ->> 'textMuted', c ->> 'background'); ratios := ratios || jsonb_build_object('textMuted/background', r);
    if r < 3.0 then errs := errs || ('textMuted/background contrast ' || r || ' < 3.0'); end if;
    r := design.fn_contrast(c ->> 'onPrimary', c ->> 'primary'); ratios := ratios || jsonb_build_object('onPrimary/primary', r);
    if r < 3.0 then errs := errs || ('onPrimary/primary contrast ' || r || ' < 3.0'); end if;
    -- status colours are indicators (always paired with a word/icon): warning only
    foreach k in array array['good','warn','bad','info'] loop
      r := design.fn_contrast(c ->> k, c ->> 'background'); ratios := ratios || jsonb_build_object(k || '/background', r);
      if r < 3.0 then warns := warns || (k || ' is a weak indicator on the background (' || r || ')'); end if;
    end loop;
    -- per-position accents (used for headers/badges with white text)
    if c ? 'roleAccent' then
      if jsonb_typeof(c -> 'roleAccent') <> 'object' then errs := errs || 'colors.roleAccent must be an object'::text;
      else
        for k, v in select * from jsonb_each(c -> 'roleAccent') loop
          if k !~ '^[A-Z][A-Z0-9_]{1,40}$' or not design.fn_hex_ok(v #>> '{}') then errs := errs || ('colors.roleAccent.' || k || ' invalid');
          elsif design.fn_contrast(v #>> '{}', c ->> 'onPrimary') < 3.0 then errs := errs || ('roleAccent ' || k || ' unreadable with onPrimary text');
          end if;
        end loop;
      end if;
    end if;
    if c ? 'states' then
      if jsonb_typeof(c -> 'states') <> 'object' then errs := errs || 'colors.states must be an object'::text;
      else
        for k, v in select * from jsonb_each(c -> 'states') loop
          if k not in ('pressed','disabled','focus','selected') or not design.fn_hex_ok(v #>> '{}') then errs := errs || ('colors.states.' || k || ' invalid'); end if;
        end loop;
        if design.fn_hex_ok(c -> 'states' ->> 'focus') and design.fn_contrast(c -> 'states' ->> 'focus', c ->> 'background') < 3.0 then
          errs := errs || 'focus indicator must reach 3.0 against the background'::text;
        end if;
      end if;
    end if;
  end if;
  -- typography (Bengali conjuncts; money on cards must not clip)
  for k, v in select * from jsonb_each(t) loop
    if k not in ('scale','bodySp','labelSp','titleSp','headlineSp','lineHeightFactor') or jsonb_typeof(v) <> 'number' then
      errs := errs || ('type.' || k || ' invalid');
    end if;
  end loop;
  if cardinality(errs) = 0 then
    sc := coalesce((t ->> 'scale')::numeric, 1.0);
    if sc not between 0.85 and 1.40 then errs := errs || 'type.scale must be 0.85..1.40'::text; end if;
    if coalesce((t ->> 'bodySp')::numeric, 15) not between 12 and 22 then errs := errs || 'type.bodySp must be 12..22'::text; end if;
    if coalesce((t ->> 'labelSp')::numeric, 13) not between 11 and 18 then errs := errs || 'type.labelSp must be 11..18'::text; end if;
    if coalesce((t ->> 'titleSp')::numeric, 18) not between 14 and 28 then errs := errs || 'type.titleSp must be 14..28'::text; end if;
    if coalesce((t ->> 'headlineSp')::numeric, 22) not between 18 and 36 then errs := errs || 'type.headlineSp must be 18..36'::text; end if;
    if coalesce((t ->> 'lineHeightFactor')::numeric, 1.45) not between 1.3 and 2.0 then errs := errs || 'type.lineHeightFactor must be 1.3..2.0 (Bengali)'::text; end if;
    if coalesce((t ->> 'headlineSp')::numeric, 22) * sc > 34 or coalesce((t ->> 'titleSp')::numeric, 18) * sc > 28
       or coalesce((t ->> 'bodySp')::numeric, 15) * sc > 24 then
      errs := errs || 'type sizes x scale would clip amounts on cards (headline <= 34, title <= 28, body <= 24 sp)'::text;
    end if;
    if coalesce((t ->> 'labelSp')::numeric, 13) * sc < 11 then errs := errs || 'labels below 11 sp are unreadable'::text; end if;
  end if;
  -- shapes / spacing / cards (readable density)
  for k, v in select * from jsonb_each(s) loop
    if k not in ('cornerSmallDp','cornerMediumDp','cornerLargeDp') or jsonb_typeof(v) <> 'number' or (v #>> '{}')::numeric not between 0 and 40 then
      errs := errs || ('shapes.' || k || ' invalid');
    end if;
  end loop;
  for k, v in select * from jsonb_each(sp) loop
    if not ((k = 'unitDp' and jsonb_typeof(v) = 'number' and (v #>> '{}')::numeric between 2 and 8)
         or (k = 'screenPaddingDp' and jsonb_typeof(v) = 'number' and (v #>> '{}')::numeric between 8 and 32)
         or (k = 'density' and v #>> '{}' in ('COMFORTABLE','COMPACT'))) then
      errs := errs || ('spacing.' || k || ' invalid');
    end if;
  end loop;
  for k, v in select * from jsonb_each(cd) loop
    if not (jsonb_typeof(v) = 'number' and ((k = 'borderDp' and (v #>> '{}')::numeric between 0 and 2)
         or (k = 'radiusDp' and (v #>> '{}')::numeric between 0 and 28) or (k = 'paddingDp' and (v #>> '{}')::numeric between 8 and 24)
         or (k = 'elevationDp' and (v #>> '{}')::numeric between 0 and 8) or (k = 'gapDp' and (v #>> '{}')::numeric between 4 and 24))) then
      errs := errs || ('cards.' || k || ' invalid (readable density limits)');
    end if;
  end loop;
  return jsonb_build_object('ok', cardinality(errs) = 0, 'errors', to_jsonb(errs), 'warnings', to_jsonb(warns), 'contrast', ratios);
end $$;

-- ================================================================ seeds: templates, icons, permissions, module, settings
create function design.fn_template_tokens(p_primary text, p_dark text, p_soft text, p_text text, p_muted text) returns jsonb
language sql immutable set search_path = pg_catalog as $$
  select jsonb_build_object('revision', 0,
    'colors', jsonb_build_object('primary', p_primary, 'primaryDark', p_dark, 'primarySoft', p_soft, 'onPrimary', '#FFFFFF', 'background', '#FFFFFF',
                                 'surfaceAlt', '#F4F5F7', 'text', p_text, 'textMuted', p_muted, 'divider', '#E5E7EB', 'good', '#2E9E5B',
                                 'warn', '#E8A317', 'bad', '#D64545', 'info', '#3B82F6',
                                 'chart', jsonb_build_array(p_primary, '#F85606', '#14B8A6', '#E8A317', '#7E22CE', '#2E9E5B', '#D64545', '#0F766E')),
    'type', jsonb_build_object('scale', 1.0, 'bodySp', 15, 'labelSp', 13, 'titleSp', 18, 'headlineSp', 22, 'lineHeightFactor', 1.45),
    'shapes', jsonb_build_object('cornerSmallDp', 8, 'cornerMediumDp', 12, 'cornerLargeDp', 16),
    'spacing', jsonb_build_object('unitDp', 4, 'screenPaddingDp', 16, 'density', 'COMFORTABLE'),
    'cards', jsonb_build_object('borderDp', 0, 'radiusDp', 16, 'paddingDp', 14, 'elevationDp', 1, 'gapDp', 10))
$$;
insert into design.theme_template (code, name_bn, tokens, sort_order) values
  ('MOHONA_BLUE',   'মোহনা নীল (ডিফল্ট)',  design.fn_template_tokens('#1456A0', '#0E3F78', '#E8F0FA', '#1F2430', '#5F6673'), 10),
  ('MOHONA_ORANGE', 'মোহনা কমলা',         design.fn_template_tokens('#C2410C', '#9A3412', '#FFF1E8', '#1F2430', '#5F6673'), 20),
  ('FOREST_GREEN',  'সবুজ',               design.fn_template_tokens('#15803D', '#166534', '#E9F7EE', '#1F2430', '#5F6673'), 30),
  ('HIGH_CONTRAST', 'উচ্চ কনট্রাস্ট',     design.fn_template_tokens('#0B3D91', '#072A66', '#E6EEFA', '#000000', '#333333'), 40);

insert into design.icon_catalog (name, grp, label_bn) values
  ('Home','nav','হোম'), ('Search','nav','অনুসন্ধান'), ('Assessment','report','রিপোর্ট'), ('BarChart','report','বার-চার্ট'), ('PieChart','report','পাই-চার্ট'),
  ('Checklist','task','কাজের তালিকা'), ('TaskAlt','task','সম্পন্ন'), ('Description','doc','নথি'), ('Receipt','doc','রসিদ'), ('Inventory','stock','মজুদ'),
  ('Factory','mfg','কারখানা'), ('LocalShipping','sales','ডেলিভারি'), ('ShoppingCart','sales','বিক্রয়'), ('Storefront','sales','দোকান'),
  ('Payments','finance','পেমেন্ট'), ('AccountBalance','finance','ব্যাংক'), ('AccountBalanceWallet','finance','ক্যাশ'), ('People','hr','কর্মী'),
  ('Person','hr','ব্যক্তি'), ('Badge','hr','পরিচয়'), ('Schedule','hr','সময়'), ('QrCodeScanner','tool','স্ক্যান'), ('QrCode','tool','QR'),
  ('Settings','admin','সেটিং'), ('Palette','admin','ডিজাইন'), ('Security','admin','নিরাপত্তা'), ('Lock','admin','লক'), ('Verified','status','যাচাইকৃত'),
  ('Warning','status','সতর্কতা'), ('Error','status','ত্রুটি'), ('Info','status','তথ্য'), ('CheckCircle','status','অনুমোদিত'), ('Cancel','status','বাতিল'),
  ('Pending','status','অপেক্ষমাণ'), ('Notifications','nav','বিজ্ঞপ্তি'), ('Science','mfg','মান-নিয়ন্ত্রণ'), ('Build','mfg','মেরামত'),
  ('Edit','action','সম্পাদনা'), ('Delete','action','মুছুন'), ('Add','action','যোগ'), ('Send','action','পাঠান'), ('Print','action','প্রিন্ট'),
  ('Share','action','শেয়ার'), ('Download','action','ডাউনলোড'), ('Approval','action','অনুমোদন'), ('Undo','action','ফেরত');

update iam.permission_catalog set status = 'active' where code in ('design.studio.edit', 'design.studio.publish');
select config.fn_make_module_available('design');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('design.publish.requires_approval', 'design', 'bool', 'false', null, null, null, 'থিম প্রকাশে অনুমোদন', 'MOS-F153-001', true, 900);

-- ================================================================ publish + approval handler
create function design.fn_publish_theme_version(p_company uuid, p_theme uuid, p_version integer) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  update design.theme_version set status = 'superseded' where theme_id = p_theme and company_id = p_company and status = 'published';
  update design.theme_version set status = 'published', published_at = clock_timestamp() where theme_id = p_theme and company_id = p_company and version = p_version;
  update design.theme set is_active = false where company_id = p_company and is_active and id <> p_theme;
  update design.theme set is_active = true, active_version = p_version where id = p_theme and company_id = p_company;
end $$;

-- Generic approval handlers: all earlier cases (S13, S14, S15) + S18 theme publication.
create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- ================================================================ API
create function api.v1_design_templates() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('code', t.code, 'name_bn', t.name_bn, 'tokens', t.tokens,
                                                       'report', design.fn_tokens_report(t.tokens)) order by t.sort_order) from design.theme_template t), '[]'::jsonb);
end $$;

create function api.v1_design_themes() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', t.id, 'code', t.code, 'name_bn', t.name_bn, 'from_template', t.from_template,
           'is_active', t.is_active, 'active_version', t.active_version, 'row_version', t.row_version,
           'versions', (select jsonb_agg(jsonb_build_object('version', v.version, 'status', v.status, 'ok', (v.report ->> 'ok')::boolean,
                                                            'reason', v.reason, 'created_at', v.created_at, 'published_at', v.published_at) order by v.version desc)
                          from design.theme_version v where v.theme_id = t.id)) order by t.code)
     from design.theme t where t.company_id = me.company_id), '[]'::jsonb);
end $$;

-- Preview: the validation report for any token set (nothing is stored).
create function api.v1_design_validate(p_tokens jsonb) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return design.fn_tokens_report(p_tokens);
end $$;

-- Saves a new immutable draft version (created from a template when the theme is new and p_tokens is null).
create function api.v1_design_save_theme(p_code text, p_name_bn text, p_tokens jsonb, p_from_template text, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t design.theme%rowtype; v_tokens jsonb := p_tokens; v integer; rep jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), true);
  if coalesce(p_code, '') !~ '^[A-Z][A-Z0-9_]{2,30}$' or length(btrim(coalesce(p_name_bn, ''))) = 0 then
    perform core.fn_raise('E_DESIGN_INVALID', 'code (A-Z, 3..31) and name_bn required');
  end if;
  if v_tokens is null then
    select x.tokens into v_tokens from design.theme_template x where x.code = p_from_template;
    if v_tokens is null then perform core.fn_raise('E_NOT_FOUND', 'template'); end if;
  end if;
  if length(v_tokens::text) > 65536 then perform core.fn_raise('E_DESIGN_INVALID', 'tokens larger than 64 KB'); end if;
  rep := design.fn_tokens_report(v_tokens);
  perform set_config('mohona.change_reason', p_reason, true);
  select * into t from design.theme where company_id = me.company_id and code = p_code for update;
  if not found then
    insert into design.theme (company_id, code, name_bn, from_template, created_by)
    values (me.company_id, p_code, p_name_bn, p_from_template, me.person_id) returning * into t;
  else
    update design.theme set name_bn = p_name_bn where id = t.id;
  end if;
  v := coalesce((select max(x.version) from design.theme_version x where x.theme_id = t.id), 0) + 1;
  insert into design.theme_version (company_id, theme_id, version, tokens, report, reason, created_by)
  values (me.company_id, t.id, v, v_tokens || jsonb_build_object('revision', v), rep, p_reason, me.person_id);
  return jsonb_build_object('theme_id', t.id, 'version', v, 'report', rep);
end $$;

-- Publish (design.studio.publish): refused while the validation report has errors; optional approval (setting).
create function api.v1_design_publish(p_theme_id uuid, p_version integer, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; t design.theme%rowtype; v design.theme_version%rowtype; j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.publish', iam.fn_my_company_resource(), true);
  select * into t from design.theme where id = p_theme_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'theme'); end if;
  if t.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  select * into v from design.theme_version where theme_id = t.id and version = p_version;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'version'); end if;
  if v.status <> 'draft' then perform core.fn_raise('E_INVALID_ACTION', 'only a draft is published (rollback comes in S19)'); end if;
  if not coalesce((v.report ->> 'ok')::boolean, false) then
    perform core.fn_raise('E_DESIGN_CONTRAST', coalesce(v.report -> 'errors' ->> 0, 'validation failed'));
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if config.fn_get_bool(me.company_id, 'design.publish.requires_approval') then
    j := core.fn_approval_submit(me.company_id, 'design.theme_publish', v.id, 0, iam.fn_resource(me.company_id),
                                 jsonb_build_object('theme_id', t.id, 'version', v.version));
    if j ->> 'status' <> 'approved' then
      update design.theme_version set status = 'pending_approval', approval_request_id = (j ->> 'request_id')::uuid where id = v.id;
      return jsonb_build_object('status', 'pending_approval', 'request_id', j ->> 'request_id');
    end if;
  end if;
  perform design.fn_publish_theme_version(me.company_id, t.id, v.version);
  return jsonb_build_object('status', 'published', 'version', v.version);
end $$;

-- What the app applies for the current position: the active theme (or null = built-in default) + icon bindings.
create function api.v1_design_active() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return jsonb_build_object(
    'theme', (select jsonb_build_object('theme_id', t.id, 'code', t.code, 'version', v.version, 'tokens', v.tokens)
                from design.theme t join design.theme_version v on v.theme_id = t.id and v.version = t.active_version
               where t.company_id = me.company_id and t.is_active),
    'icons', coalesce((select jsonb_agg(jsonb_build_object('target_key', b.target_key, 'icon', b.icon_name, 'permission', b.permission_code, 'version', b.version) order by b.target_key)
                         from design.icon_binding b where b.company_id = me.company_id and b.status = 'active'), '[]'::jsonb));
end $$;

create function api.v1_design_icon_catalog() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('name', i.name, 'group', i.grp, 'label_bn', i.label_bn) order by i.grp, i.name)
                     from design.icon_catalog i), '[]'::jsonb);
end $$;

-- Binds an icon to a target. action.* targets must name the permission the action needs (F004); icons never grant.
create function api.v1_design_set_icon(p_target_key text, p_icon_name text, p_permission_code text, p_expected_version integer, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; cur design.icon_binding%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('design.studio.edit', iam.fn_my_company_resource(), true);
  if coalesce(p_target_key, '') !~ '^(module|action|tab|kpi|status)\.[a-z0-9_.]{2,80}$' then perform core.fn_raise('E_DESIGN_INVALID', 'target key'); end if;
  if not exists (select 1 from design.icon_catalog i where i.name = p_icon_name) then perform core.fn_raise('E_DESIGN_INVALID', 'icon not in catalog'); end if;
  if p_target_key ~ '^action\.' and p_permission_code is null then
    perform core.fn_raise('E_DESIGN_INVALID', 'an action icon must carry the permission of that action');
  end if;
  if p_permission_code is not null and not exists (select 1 from iam.permission_catalog c where c.code = p_permission_code) then
    perform core.fn_raise('E_NOT_FOUND', 'permission');
  end if;
  select * into cur from design.icon_binding b where b.company_id = me.company_id and b.target_key = p_target_key and b.status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then update design.icon_binding set status = 'superseded' where id = cur.id; end if;
  v_next := coalesce((select max(b.version) from design.icon_binding b where b.company_id = me.company_id and b.target_key = p_target_key), 0) + 1;
  insert into design.icon_binding (company_id, target_key, icon_name, permission_code, version, set_by, reason)
  values (me.company_id, p_target_key, p_icon_name, p_permission_code, v_next, me.person_id, p_reason);
  return v_next;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_design_templates()', 'api.v1_design_themes()', 'api.v1_design_validate(jsonb)',
      'api.v1_design_save_theme(text, text, jsonb, text, text)', 'api.v1_design_publish(uuid, integer, integer, text)',
      'api.v1_design_active()', 'api.v1_design_icon_catalog()', 'api.v1_design_set_icon(text, text, text, integer, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

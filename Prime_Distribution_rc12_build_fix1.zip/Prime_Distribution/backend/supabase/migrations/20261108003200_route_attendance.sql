-- 20261108003200_route_attendance.sql  (S44–S46 in one step)
-- Route & field (ROUTE_FIELD MOS-F153-151..160) + HR attendance (HR_ATTENDANCE MOS-F153-161..170).
--   151 routes: territory stops in sequence   152 route plans: officer / vehicle / date; no overlapping mandatory plans
--   153 check-in only by the officer, location only with consent (no covert tracking)   154 structured outcomes (no-sale reason)
--   155 missed reasons; a visit is "done" only with a same-day check-in (no fake completion)   156 reschedule keeps the missed record
--   157 reassignment approved by a supervisor; the new officer must hold territory access   158 exceptions: evidence, reason frozen
--   159 route map: stops + consented check-ins; revoking consent stops sharing   160 performance: approved absence never penalised
--   161 gate QR: short-lived signed employee token, scanned only by a registered gate device, single use (replay-proof)
--   162 PIN backup at a registered gate device, rate-limited   163 manual attendance: reason + another person's approval
--   164 shift roster incl. overnight shifts   165 late policy versioned by effective date   166 leave: balance, no overlap, approval
--   167 correction requests keep the original scan   168 overtime within monthly cap   169 report (own data for employees)
--   170 offline gate queue resync without duplicates
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ routes (F151–F160)
create table sales.route (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  code          text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  name_bn       text not null,
  territory_id  uuid not null,
  stops         jsonb not null,                  -- [{seq, dealer_id | retailer_id}]
  status        text not null default 'active' check (status in ('active','inactive')),
  updated_at    timestamptz not null default clock_timestamp(),
  row_version   integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (territory_id, company_id) references sales.territory (id, company_id)
);
create trigger trg_route_guard before update on sales.route for each row execute function core.fn_scoped_guard();
create trigger trg_route_touch before update on sales.route for each row execute function core.fn_touch_row();
create trigger trg_route_nodel before delete on sales.route for each row execute function core.fn_deny_delete();
create trigger trg_route_audit after insert or update on sales.route for each row execute function audit.fn_row_change();

create table sales.route_plan (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  route_id            uuid not null,
  officer_id          uuid not null references core.person(id),
  vehicle             text,
  plan_date           date not null,
  mandatory           boolean not null default true,
  status              text not null default 'planned' check (status in ('planned','completed','cancelled')),
  created_by          uuid references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (route_id, company_id) references sales.route (id, company_id)
);
create unique index route_plan_no_overlap on sales.route_plan (officer_id, plan_date) where mandatory and status <> 'cancelled';     -- F152
create trigger trg_route_plan_nodel before delete on sales.route_plan for each row execute function core.fn_deny_delete();
create trigger trg_route_plan_audit after insert or update on sales.route_plan for each row execute function audit.fn_row_change();

alter table sales.dealer_visit add column route_plan_id uuid, add column stop_seq integer, add column missed_reason text
  check (missed_reason is null or missed_reason in ('illness','emergency','weather','vehicle','other')),
  add column no_sale_reason text check (no_sale_reason is null or no_sale_reason in ('stock_full','price','credit','closed','other')),
  add column reschedule_of uuid references sales.dealer_visit(id), add column priority integer not null default 0;
-- F155: done only with a same-day check-in; a missed visit never turns into a completed one.
create function sales.fn_visit_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if old.status in ('done','missed') and new.status <> old.status then raise exception 'E_INVALID_ACTION: visit already %', old.status using errcode = 'P0001'; end if;
  if new.status = 'done' and (new.checked_in_at is null or new.checked_in_at::date <> new.planned_date) then
    raise exception 'E_INVALID_ACTION: a visit is done only with a check-in on its planned day' using errcode = 'P0001';
  end if;
  if new.status = 'done' and new.outcome is null then raise exception 'E_INVALID_ACTION: outcome required' using errcode = 'P0001'; end if;
  if new.status = 'done' and new.outcome = 'no_order' and (new.no_sale_reason is null or length(btrim(coalesce(new.notes, ''))) = 0) then
    raise exception 'E_INVALID_ACTION: a no-sale needs its reason and a note' using errcode = 'P0001';
  end if;
  if new.status = 'missed' and new.missed_reason is null then raise exception 'E_INVALID_ACTION: missed reason required' using errcode = 'P0001'; end if;
  return new;
end $$;
create trigger trg_visit_guard before update on sales.dealer_visit for each row execute function sales.fn_visit_guard();

create table sales.route_exception (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  route_plan_id       uuid not null,
  visit_id            uuid references sales.dealer_visit(id),
  kind                text not null check (kind in ('missed','reassign')),
  reason              text not null check (length(btrim(reason)) > 0),
  evidence_path       text,
  payload             jsonb not null default '{}'::jsonb,
  status              text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  posted_at           timestamptz,
  foreign key (route_plan_id, company_id) references sales.route_plan (id, company_id)
);
create trigger trg_route_exception_guard before update on sales.route_exception for each row execute function procurement.fn_doc_status_guard();   -- F158 frozen
create trigger trg_route_exception_nodel before delete on sales.route_exception for each row execute function core.fn_deny_delete();
create trigger trg_route_exception_audit after insert or update on sales.route_exception for each row execute function audit.fn_row_change();

-- ================================================================ attendance (F161–F170)
create table hr.gate_device (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null references core.company(id),
  code         text not null check (code ~ '^[A-Z0-9_-]{2,20}$'),
  location_id  uuid,
  key_hash     text not null check (key_hash ~ '^[0-9a-f]{64}$'),
  status       text not null default 'active' check (status in ('active','revoked')),
  registered_by uuid references core.person(id),
  registered_at timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, code),
  foreign key (location_id, company_id) references core.location (id, company_id)
);
create trigger trg_gate_device_nodel before delete on hr.gate_device for each row execute function core.fn_deny_delete();
create trigger trg_gate_device_audit after insert or update on hr.gate_device for each row execute function audit.fn_row_change();

create table hr.attendance_event (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  employee_id   uuid not null,
  event_at      timestamptz not null,
  method        text not null check (method in ('qr','pin','manual','correction')),
  device_id     uuid references hr.gate_device(id),
  nonce         text unique,                    -- one QR token / queued scan = one event (F161, F170)
  status        text not null default 'posted' check (status in ('posted','pending','rejected')),
  reason        text,
  created_by    uuid references core.person(id),
  decided_by    uuid references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  check (decided_by is null or decided_by <> created_by),
  check (method not in ('manual','correction') or length(btrim(coalesce(reason, ''))) > 0),
  foreign key (employee_id, company_id) references hr.employee (id, company_id)
);
create index attendance_event_day on hr.attendance_event (employee_id, event_at);
create function hr.fn_attendance_event_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','decided_by']) <> (to_jsonb(new) - array['status','decided_by']) or old.status <> 'pending' then
    raise exception 'E_IMMUTABLE: attendance events are never edited (corrections add a new event)' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_attendance_event_guard before update on hr.attendance_event for each row execute function hr.fn_attendance_event_guard();
create trigger trg_attendance_event_nodel before delete on hr.attendance_event for each row execute function core.fn_deny_delete();
create trigger trg_attendance_event_audit after insert or update on hr.attendance_event for each row execute function audit.fn_row_change();

create table hr.pin_attempt (
  id          bigint generated always as identity primary key,
  company_id  uuid not null,
  device_id   uuid not null,
  employee_id uuid,
  ok          boolean not null,
  at          timestamptz not null default clock_timestamp()
);

create table hr.shift (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_-]{1,20}$'),
  name_bn     text not null,
  start_time  time not null,
  end_time    time not null,
  overnight   boolean generated always as (end_time <= start_time) stored,
  status      text not null default 'active' check (status in ('active','inactive')),
  unique (id, company_id), unique (company_id, code)
);
create trigger trg_shift_audit after insert or update on hr.shift for each row execute function audit.fn_row_change();

create table hr.roster (
  company_id  uuid not null,
  employee_id uuid not null,
  work_date   date not null,
  shift_id    uuid not null,
  set_by      uuid references core.person(id),
  primary key (employee_id, work_date),
  foreign key (employee_id, company_id) references hr.employee (id, company_id),
  foreign key (shift_id, company_id) references hr.shift (id, company_id)
);
create trigger trg_roster_audit after insert or update on hr.roster for each row execute function audit.fn_row_change();

create table hr.late_policy (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null references core.company(id),
  effective_from  date not null,
  grace_minutes   integer not null check (grace_minutes between 0 and 120),
  lates_per_deduction integer not null check (lates_per_deduction between 1 and 31),
  deduction_days  numeric(4,2) not null check (deduction_days between 0 and 5),
  set_by          uuid references core.person(id),
  reason          text not null,
  created_at      timestamptz not null default clock_timestamp(),
  unique (company_id, effective_from)
);
create trigger trg_late_policy_no_mutation before update or delete on hr.late_policy for each row execute function core.fn_deny_mutation();
create trigger trg_late_policy_audit after insert on hr.late_policy for each row execute function audit.fn_row_change();

create table hr.leave_type (
  company_id   uuid not null references core.company(id),
  code         text not null check (code ~ '^[A-Z]{2,10}$'),
  name_bn      text not null,
  annual_days  numeric(5,1) not null check (annual_days >= 0),
  primary key (company_id, code)
);
create table hr.leave_request (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  employee_id  uuid not null,
  leave_code   text not null,
  date_from    date not null,
  date_to      date not null,
  days         numeric(5,1) not null check (days > 0),
  reason       text not null,
  status       text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  posted_at    timestamptz,
  check (date_to >= date_from),
  foreign key (employee_id, company_id) references hr.employee (id, company_id),
  foreign key (company_id, leave_code) references hr.leave_type (company_id, code)
);
create trigger trg_leave_guard before update on hr.leave_request for each row execute function procurement.fn_doc_status_guard();
create trigger trg_leave_nodel before delete on hr.leave_request for each row execute function core.fn_deny_delete();
create trigger trg_leave_audit after insert or update on hr.leave_request for each row execute function audit.fn_row_change();

create table hr.overtime_request (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  employee_id  uuid not null,
  work_date    date not null,
  hours        numeric(4,1) not null check (hours > 0 and hours <= 12),
  reason       text not null,
  status       text not null default 'pending_approval' check (status in ('pending_approval','posted','rejected','cancelled')),
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  approval_request_id uuid,
  posted_at    timestamptz,
  foreign key (employee_id, company_id) references hr.employee (id, company_id)
);
create trigger trg_overtime_guard before update on hr.overtime_request for each row execute function procurement.fn_doc_status_guard();
create trigger trg_overtime_nodel before delete on hr.overtime_request for each row execute function core.fn_deny_delete();
create trigger trg_overtime_audit after insert or update on hr.overtime_request for each row execute function audit.fn_row_change();

select core.fn_apply_rls('sales', 'route');
select core.fn_apply_rls('sales', 'route_plan');
select core.fn_apply_rls('sales', 'route_exception');
select core.fn_apply_rls('hr', 'gate_device');
select core.fn_apply_rls('hr', 'attendance_event');
select core.fn_apply_rls('hr', 'pin_attempt');
select core.fn_apply_rls('hr', 'shift');
select core.fn_apply_rls('hr', 'roster');
select core.fn_apply_rls('hr', 'late_policy');
select core.fn_apply_rls('hr', 'leave_type');
select core.fn_apply_rls('hr', 'leave_request');
select core.fn_apply_rls('hr', 'overtime_request');

-- ================================================================ permissions + settings
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('route.manage',   'route', 'রুট ও রুট-পরিকল্পনা', 'write', false, true, array['COMPANY','WING'], 'active', 1700),
  ('route.approve',  'route', 'রুট-ব্যতিক্রম ও পুনর্বণ্টন অনুমোদন', 'approve', true, false, array['COMPANY','WING'], 'active', 1701),
  ('hr.roster.manage','hr', 'শিফট, রোস্টার, দেরি-নীতি, গেট-ডিভাইস', 'admin', true, false, array['COMPANY','WING','DEPARTMENT'], 'active', 1702),
  ('hr.overtime.approve','hr', 'ওভারটাইম অনুমোদন', 'approve', true, false, array['COMPANY','WING','DEPARTMENT'], 'active', 1703);
update iam.permission_catalog set status = 'active'
 where code in ('hr.employee.read','hr.attendance.scan','hr.attendance.read','hr.attendance.correct','hr.leave.request','hr.leave.approve','location.dealer_map.read');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, x, 'allow', 'SELF' from iam.position_template t, unnest(array['hr.attendance.scan','hr.attendance.read','hr.leave.request','hr.employee.read']) x
 where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN')
union all select x, y, 'allow', z from (values ('HR_OFFICER','hr.attendance.read','COMPANY'), ('HR_OFFICER','hr.attendance.correct','COMPANY'), ('HR_OFFICER','hr.roster.manage','COMPANY'),
  ('HR_OFFICER','hr.employee.read','COMPANY'), ('MD','hr.leave.approve','COMPANY'), ('MD','hr.overtime.approve','COMPANY'), ('MD','hr.attendance.read','COMPANY'),
  ('WING_HEAD','hr.leave.approve','WING'), ('WING_HEAD','hr.overtime.approve','WING'), ('SALES_MANAGER','route.manage','COMPANY'), ('SALES_MANAGER','route.approve','COMPANY'),
  ('SALES_MANAGER','location.dealer_map.read','COMPANY'), ('FIELD_SALES','location.dealer_map.read','ASSIGNED')) v(x, y, z)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('route');
select config.fn_make_module_available('hr');
select config.fn_make_module_available('location');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('hr.gate.qr_window_seconds',  'hr', 'int', '30', 15, 300, null, 'হাজিরা-QR কত সেকেন্ড বৈধ', 'MOS-F153-161', true, 1800),
  ('hr.gate.offline_max_hours',  'hr', 'int', '24', 1, 72, null, 'গেট-ডিভাইস অফলাইনে সর্বোচ্চ কত ঘণ্টার স্ক্যান পরে জমা দিতে পারে', 'MOS-F153-170', true, 1810),
  ('hr.gate.pin_max_failures',   'hr', 'int', '5', 3, 10, null, 'গেটে PIN-এ ১৫ মিনিটে সর্বোচ্চ ভুল', 'MOS-F153-162', true, 1820),
  ('hr.overtime.max_hours_month','hr', 'int', '40', 0, 120, null, 'মাসে সর্বোচ্চ অনুমোদিত ওভারটাইম (ঘণ্টা)', 'MOS-F153-168', true, 1830);

-- ================================================================ engine
create function hr.fn_employee_of(p_company uuid, p_person uuid) returns uuid
language sql stable security definer set search_path = pg_catalog as $$
  select e.id from hr.employee e join iam.company_membership m on m.id = e.membership_id where e.company_id = p_company and e.person_id = p_person and m.status = 'active'
$$;

create function hr.fn_employee_active(p_employee uuid) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from hr.employment x where x.employee_id = p_employee and x.status = 'active' and x.effective_to is null)
$$;

create function hr.fn_gate_device(p_company uuid, p_code text, p_key text) returns hr.gate_device
language plpgsql stable security definer set search_path = pg_catalog, public, extensions as $$
declare g hr.gate_device;
begin
  select * into g from hr.gate_device x where x.company_id = p_company and x.code = upper(p_code) and x.status = 'active';
  if g.id is null or encode(digest(coalesce(p_key, ''), 'sha256'), 'hex') <> g.key_hash then
    raise exception 'E_GATE_DEVICE_INVALID: not a registered gate device of this company' using errcode = 'P0001';
  end if;
  return g;
end $$;

-- Gate QR (F161, F170): token valid for its window (or, from an offline queue, if scanned inside its window and synced in
-- time); the token's hash is the nonce, so a replay or a re-sync never makes a second event.
create function hr.fn_qr_scan(p_company uuid, p_device hr.gate_device, p_payload text, p_scanned_at timestamptz) returns text
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare parts text[] := string_to_array(coalesce(p_payload, ''), '|'); v_code text; v_win integer := config.fn_get_int(p_company, 'hr.gate.qr_window_seconds');
        v_tok timestamptz; v_at timestamptz := coalesce(p_scanned_at, clock_timestamp()); v_emp uuid; v_nonce text := encode(digest(coalesce(p_payload, ''), 'sha256'), 'hex');
begin
  select c.code into v_code from core.company c where c.id = p_company;
  if cardinality(parts) <> 6 or parts[1] <> 'MOS1' or parts[2] <> 'A' or parts[3] is distinct from v_code
     or sales.fn_signed(p_company, array_to_string(parts[1:5], '|')) <> p_payload then
    return 'invalid';
  end if;
  v_emp := parts[4]::uuid; v_tok := to_timestamp(parts[5]::bigint * v_win);
  if v_at < v_tok or v_at > v_tok + make_interval(secs => 2 * v_win) or v_at > clock_timestamp() + interval '1 minute'
     or clock_timestamp() - v_at > make_interval(hours => config.fn_get_int(p_company, 'hr.gate.offline_max_hours')) then
    return 'expired';
  end if;
  if not hr.fn_employee_active(v_emp) then return 'inactive'; end if;
  insert into hr.attendance_event (company_id, employee_id, event_at, method, device_id, nonce) values (p_company, v_emp, v_at, 'qr', p_device.id, v_nonce)
  on conflict (nonce) do nothing;
  return case when found then 'ok' else 'duplicate' end;
end $$;

create function hr.fn_on_approved(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare l hr.leave_request%rowtype; o hr.overtime_request%rowtype; v_used numeric;
begin
  if r.document_type = 'hr.leave' then
    select * into l from hr.leave_request where id = r.document_id for update;
    if l.status <> 'pending_approval' then return; end if;
    if exists (select 1 from hr.leave_request x where x.employee_id = l.employee_id and x.id <> l.id and x.status = 'posted'
                and daterange(x.date_from, x.date_to, '[]') && daterange(l.date_from, l.date_to, '[]')) then
      raise exception 'E_LEAVE_OVERLAP' using errcode = 'P0001';
    end if;
    update hr.leave_request set status = 'posted', posted_at = clock_timestamp() where id = l.id;
  elsif r.document_type = 'hr.overtime' then
    select * into o from hr.overtime_request where id = r.document_id for update;
    if o.status <> 'pending_approval' then return; end if;
    select coalesce(sum(x.hours), 0) into v_used from hr.overtime_request x where x.employee_id = o.employee_id and x.status = 'posted'
       and date_trunc('month', x.work_date) = date_trunc('month', o.work_date);
    if v_used + o.hours > config.fn_get_int(o.company_id, 'hr.overtime.max_hours_month') then raise exception 'E_OVERTIME_CAP' using errcode = 'P0001'; end if;
    update hr.overtime_request set status = 'posted', posted_at = clock_timestamp() where id = o.id;
  end if;
end $$;

create or replace function sales.fn_on_approved(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare a sales.dealer_adjustment%rowtype; e sales.route_exception%rowtype;
begin
  if r.document_type = 'sales.credit_exception' then
    update sales.credit_exception set status = 'posted', posted_at = clock_timestamp() where id = r.document_id and status = 'pending_approval';
  elsif r.document_type = 'sales.dealer_adjustment' then
    select * into a from sales.dealer_adjustment where id = r.document_id for update;
    if a.status <> 'pending_approval' then return; end if;
    perform sales.fn_post_ledger(a.company_id, a.dealer_id, 'adjustment', a.amount, current_date, null, 'sales.dealer_adjustment', a.id, a.reason);
    perform finance.fn_emit(a.company_id, 'dealer_adj:' || a.id, 'ডিলার-খাতা সমন্বয়', jsonb_build_array(
      jsonb_build_object('key', 'sales.ar', 'dr', greatest(a.amount, 0), 'cr', greatest(-a.amount, 0)),
      jsonb_build_object('key', 'sales.adjustment', 'dr', greatest(-a.amount, 0), 'cr', greatest(a.amount, 0))));
    update sales.dealer_adjustment set status = 'posted', posted_at = clock_timestamp() where id = a.id;
  elsif r.document_type = 'sales.order' then
    update sales.sales_order set status = 'approved' where id = r.document_id and status = 'pending_approval';
    perform sales.fn_allocate(r.document_id);
  elsif r.document_type = 'sales.route_exception' then
    select * into e from sales.route_exception where id = r.document_id for update;
    if e.status <> 'pending_approval' then return; end if;
    if e.kind = 'reassign' then
      update sales.route_plan set officer_id = (e.payload ->> 'officer_id')::uuid where id = e.route_plan_id;
      update sales.dealer_visit set officer_id = (e.payload ->> 'officer_id')::uuid where route_plan_id = e.route_plan_id and status = 'planned';
    end if;
    update sales.route_exception set status = 'posted', posted_at = clock_timestamp() where id = e.id;
  end if;
end $$;

create or replace function core.fn_approval_apply(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
begin
  case
    when r.document_type = 'iam.md_appointment' then perform iam.fn_apply_md_appointment(r.company_id, r.payload);
    when r.document_type = 'config.rule_publish' then perform config.fn_publish_rule_version(r.company_id, (r.payload ->> 'rule_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'config.form_publish' then perform config.fn_form_publish_version(r.company_id, (r.payload ->> 'form_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'hr.employment_change' then perform hr.fn_employment_change_approved(r.document_id);
    when r.document_type in ('hr.leave','hr.overtime') then perform hr.fn_on_approved(r);
    when r.document_type = 'design.theme_publish' then perform design.fn_publish_theme_version(r.company_id, (r.payload ->> 'theme_id')::uuid, (r.payload ->> 'version')::integer);
    when r.document_type = 'design.layout_publish' then perform design.fn_publish_layout_version(r.company_id, r.payload ->> 'screen_key', (r.payload ->> 'version')::integer);
    when r.document_type = 'inventory.transfer' then perform inventory.fn_post_transfer(r.document_id);
    when r.document_type = 'finance.journal' then perform finance.fn_post_journal(r.document_id, false);
    when r.document_type like 'sales.%' then perform sales.fn_on_approved(r);
    when r.document_type like 'procurement.%' then perform procurement.fn_on_approved(r);
    when r.document_type like 'forms.%' then perform config.fn_form_submission_approved(r);
    else null;
  end case;
end $$;

-- ================================================================ API: routes (F151–F160)
create function api.v1_route_save(p_id uuid, p_code text, p_name_bn text, p_territory_id uuid, p_stops jsonb, p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.route%rowtype; s jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('route.manage', iam.fn_my_company_resource(), true);
  if jsonb_typeof(p_stops) is distinct from 'array' or jsonb_array_length(p_stops) not between 1 and 60 then perform core.fn_raise('E_INVALID_ACTION', 'stops'); end if;
  for s in select * from jsonb_array_elements(p_stops) loop
    if not exists (select 1 from sales.dealer d where d.id = (s ->> 'dealer_id')::uuid and d.territory_id = p_territory_id and d.status = 'active')
       and not exists (select 1 from sales.retailer x where x.id = (s ->> 'retailer_id')::uuid and x.territory_id = p_territory_id and x.status = 'active') then
      perform core.fn_raise('E_TERRITORY_MISMATCH', 'every stop must be an active dealer / retailer of the route''s territory');
    end if;
  end loop;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into sales.route (company_id, code, name_bn, territory_id, stops)
    values (me.company_id, upper(p_code), p_name_bn, p_territory_id, (select jsonb_agg(x || jsonb_build_object('seq', o)) from jsonb_array_elements(p_stops) with ordinality t(x, o)))
    returning * into r;
  else
    select * into r from sales.route where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'route'); end if;
    if r.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    update sales.route set name_bn = coalesce(p_name_bn, name_bn), territory_id = p_territory_id, status = coalesce(p_status, status),
           stops = (select jsonb_agg(x || jsonb_build_object('seq', o)) from jsonb_array_elements(p_stops) with ordinality t(x, o)) where id = r.id returning * into r;
  end if;
  return jsonb_build_object('route_id', r.id, 'row_version', r.row_version);
end $$;

-- Plan a route day for an officer: one visit per stop; overlapping mandatory plans are refused (F152).
create function api.v1_route_plan(p_route_id uuid, p_officer_id uuid, p_vehicle text, p_plan_date date, p_mandatory boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; r sales.route%rowtype; v_id uuid := gen_random_uuid(); s jsonb;
begin
  select * into me from iam.fn_require('route.manage', iam.fn_my_company_resource(), true);
  select * into r from sales.route where id = p_route_id and company_id = me.company_id and status = 'active';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'route'); end if;
  if p_plan_date is null or p_plan_date < current_date then perform core.fn_raise('E_INVALID_ACTION', 'plan date from today'); end if;
  if exists (select 1 from sales.route_plan x where x.officer_id = p_officer_id and x.plan_date = p_plan_date and x.mandatory and x.status <> 'cancelled') and coalesce(p_mandatory, true) then
    perform core.fn_raise('E_ROUTE_OVERLAP');
  end if;
  perform set_config('mohona.change_reason', 'route plan', true);
  insert into sales.route_plan (id, company_id, route_id, officer_id, vehicle, plan_date, mandatory, created_by)
  values (v_id, me.company_id, r.id, p_officer_id, p_vehicle, p_plan_date, coalesce(p_mandatory, true), me.person_id);
  for s in select * from jsonb_array_elements(r.stops) loop
    insert into sales.dealer_visit (company_id, dealer_id, retailer_id, officer_id, planned_date, route_plan_id, stop_seq)
    values (me.company_id, (s ->> 'dealer_id')::uuid, (s ->> 'retailer_id')::uuid, p_officer_id, p_plan_date, v_id, (s ->> 'seq')::integer);
  end loop;
  return jsonb_build_object('route_plan_id', v_id, 'stops', jsonb_array_length(r.stops));
end $$;

-- Check-in (F153): only the officer, only on the planned day, coordinates only with consent.
create function api.v1_visit_check_in(p_visit_id uuid, p_latitude numeric, p_longitude numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype; v_consent boolean;
begin
  select * into me from iam.fn_context(true);
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = me.company_id for update;
  if not found or v.officer_id <> me.person_id or v.status <> 'planned' then perform core.fn_raise('E_NOT_FOUND', 'your planned visit'); end if;
  if v.planned_date <> current_date then perform core.fn_raise('E_INVALID_ACTION', 'check in on the planned day'); end if;
  v_consent := exists (select 1 from sales.location_consent c where c.person_id = me.person_id and c.revoked_at is null);
  update sales.dealer_visit set checked_in_at = clock_timestamp(), latitude = case when v_consent then p_latitude end,
         longitude = case when v_consent then p_longitude end where id = v.id;
  return jsonb_build_object('visit_id', v.id, 'checked_in', true, 'location_saved', v_consent and p_latitude is not null);
end $$;

-- Structured outcome (F154): order | collection | complaint | no_order (+ no-sale reason and note) | closed_shop | other.
create function api.v1_visit_outcome(p_visit_id uuid, p_outcome text, p_no_sale_reason text, p_notes text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype;
begin
  select * into me from iam.fn_context(true);
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = me.company_id for update;
  if not found or v.officer_id <> me.person_id then perform core.fn_raise('E_NOT_FOUND', 'your visit'); end if;
  perform set_config('mohona.change_reason', 'visit outcome', true);
  update sales.dealer_visit set status = 'done', outcome = p_outcome, no_sale_reason = p_no_sale_reason, notes = p_notes where id = v.id;   -- guard enforces F154/F155
  return jsonb_build_object('visit_id', v.id, 'status', 'done');
end $$;

-- Missed (F155): reason code + note + optional evidence -> exception for supervisor review (F158).
create function api.v1_visit_missed(p_visit_id uuid, p_reason_code text, p_note text, p_evidence_path text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype; v_ex uuid := gen_random_uuid(); j jsonb;
begin
  select * into me from iam.fn_context(true);
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = me.company_id for update;
  if not found or v.officer_id <> me.person_id or v.status <> 'planned' then perform core.fn_raise('E_NOT_FOUND', 'your planned visit'); end if;
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  perform set_config('mohona.change_reason', 'visit missed', true);
  update sales.dealer_visit set status = 'missed', missed_reason = p_reason_code, notes = p_note where id = v.id;
  if v.route_plan_id is not null then
    insert into sales.route_exception (id, company_id, route_plan_id, visit_id, kind, reason, evidence_path, created_by)
    values (v_ex, me.company_id, v.route_plan_id, v.id, 'missed', p_reason_code || ': ' || p_note, p_evidence_path, me.person_id);
    j := core.fn_approval_submit(me.company_id, 'sales.route_exception', v_ex, 0, iam.fn_my_company_resource(), jsonb_build_object('kind', 'missed'));
    update sales.route_exception set approval_request_id = (j ->> 'request_id')::uuid where id = v_ex;
  end if;
  return jsonb_build_object('visit_id', v.id, 'status', 'missed', 'exception_id', case when v.route_plan_id is not null then v_ex end);
end $$;

-- Reschedule (F156): a new visit; the missed one stays as it was.
create function api.v1_visit_reschedule(p_visit_id uuid, p_new_date date, p_priority integer) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v sales.dealer_visit%rowtype; v_id uuid;
begin
  select * into me from iam.fn_require('route.manage', iam.fn_my_company_resource(), true);
  select * into v from sales.dealer_visit where id = p_visit_id and company_id = me.company_id;
  if not found or v.status <> 'missed' then perform core.fn_raise('E_NOT_FOUND', 'missed visit'); end if;
  if p_new_date is null or p_new_date < current_date then perform core.fn_raise('E_INVALID_ACTION', 'new date from today'); end if;
  insert into sales.dealer_visit (company_id, dealer_id, retailer_id, officer_id, planned_date, route_plan_id, stop_seq, reschedule_of, priority)
  values (v.company_id, v.dealer_id, v.retailer_id, v.officer_id, p_new_date, null, v.stop_seq, v.id, coalesce(p_priority, 1)) returning id into v_id;
  return jsonb_build_object('visit_id', v_id, 'reschedule_of', v.id);
end $$;

-- Reassignment (F157): the new officer must already hold territory-level visit rights; a supervisor approves.
create function api.v1_route_reassign(p_route_plan_id uuid, p_officer_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p sales.route_plan%rowtype; v_wing uuid; a record; d record; v_ok boolean := false; v_ex uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('route.manage', iam.fn_my_company_resource(), true);
  select * into p from sales.route_plan where id = p_route_plan_id and company_id = me.company_id and status = 'planned';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'planned route'); end if;
  select t.wing_id into v_wing from sales.route r join sales.territory t on t.id = r.territory_id where r.id = p.route_id;
  for a in select x.id, x.position_code, pc.is_supreme, m.person_id, x.home_wing_id, x.home_department_id, x.home_location_id
             from iam.position_assignment x join iam.company_membership m on m.id = x.membership_id join iam.position_catalog pc on pc.company_id = x.company_id and pc.code = x.position_code
            where x.company_id = me.company_id and m.person_id = p_officer_id and x.status = 'active' loop
    select * into d from iam.fn_decide(me.company_id, a.id, a.position_code, a.is_supreme, a.person_id, a.home_wing_id, a.home_department_id, a.home_location_id,
                                       'crm.visit.record', iam.fn_resource(me.company_id, v_wing), true);
    v_ok := v_ok or d.allowed;
  end loop;
  if not v_ok then perform core.fn_raise('E_FORBIDDEN', 'the new officer has no visit rights for this territory'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.route_exception (id, company_id, route_plan_id, kind, reason, payload, created_by)
  values (v_ex, me.company_id, p.id, 'reassign', p_reason, jsonb_build_object('officer_id', p_officer_id), me.person_id);
  j := core.fn_approval_submit(me.company_id, 'sales.route_exception', v_ex, 0, iam.fn_my_company_resource(), jsonb_build_object('kind', 'reassign'));
  update sales.route_exception set approval_request_id = (j ->> 'request_id')::uuid where id = v_ex;
  if j ->> 'status' = 'approved' then perform sales.fn_on_approved((select r from core.approval_request r where r.id = (j ->> 'request_id')::uuid)); end if;
  return jsonb_build_object('exception_id', v_ex, 'status', (select e.status from sales.route_exception e where e.id = v_ex));
end $$;

create function api.v1_my_visits(p_date date default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_context(false);
  return coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'seq', v.stop_seq, 'status', v.status, 'planned_date', v.planned_date, 'checked_in', v.checked_in_at is not null,
           'name_bn', coalesce(d.name_bn, rt.name_bn), 'reschedule_of', v.reschedule_of) order by v.stop_seq nulls last, v.priority desc)
     from sales.dealer_visit v left join sales.dealer d on d.id = v.dealer_id left join sales.retailer rt on rt.id = v.retailer_id
    where v.company_id = me.company_id and v.officer_id = me.person_id and v.planned_date = coalesce(p_date, current_date)), '[]'::jsonb);
end $$;

-- Route map (F159): stops with dealer coordinates; the officer's check-ins only while consent is active.
create function api.v1_route_map(p_route_plan_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; p sales.route_plan%rowtype; v_share boolean;
begin
  select * into p from sales.route_plan where id = p_route_plan_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'route plan'); end if;
  select * into me from iam.fn_require('location.dealer_map.read', iam.fn_resource(p.company_id, null, null, null, null, null, p.officer_id), false);
  v_share := exists (select 1 from sales.location_consent c where c.person_id = p.officer_id and c.revoked_at is null);
  return jsonb_build_object('route_plan_id', p.id, 'officer_sharing', v_share,
    'stops', coalesce((select jsonb_agg(jsonb_build_object('seq', v.stop_seq, 'visit_id', v.id, 'status', v.status,
               'name_bn', coalesce(d.name_bn, rt.name_bn), 'lat', coalesce(d.latitude, rt.latitude), 'lon', coalesce(d.longitude, rt.longitude),
               'check_in', case when v_share and v.latitude is not null then jsonb_build_object('lat', v.latitude, 'lon', v.longitude, 'at', v.checked_in_at) end)
               order by v.stop_seq)
             from sales.dealer_visit v left join sales.dealer d on d.id = v.dealer_id left join sales.retailer rt on rt.id = v.retailer_id
            where v.route_plan_id = p.id), '[]'::jsonb));
end $$;

-- Performance (F160): approved absences are excluded before scoring.
create function api.v1_route_performance(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := coalesce(p_from, current_date - 30); t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('route.manage', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('officer_id', x.officer_id, 'planned', x.planned, 'visited', x.visited, 'missed', x.missed, 'recovered', x.recovered,
           'approved_absence', x.approved, 'score_pct', round(100.0 * x.visited / nullif(x.planned - x.approved, 0), 1))) from (
    select v.officer_id, count(*) filter (where v.reschedule_of is null) planned, count(*) filter (where v.status = 'done' and v.reschedule_of is null) visited,
           count(*) filter (where v.status = 'missed') missed, count(*) filter (where v.status = 'done' and v.reschedule_of is not null) recovered,
           count(*) filter (where v.status = 'missed' and exists (select 1 from sales.route_exception e where e.visit_id = v.id and e.status = 'posted')) approved
      from sales.dealer_visit v where v.company_id = me.company_id and v.planned_date between f and t and (v.route_plan_id is not null or v.reschedule_of is not null)
     group by v.officer_id) x), '[]'::jsonb);
end $$;

-- ================================================================ API: attendance (F161–F170)
create function api.v1_gate_register(p_code text, p_location_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare me record; v_key text := encode(gen_random_bytes(24), 'hex'); v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.roster.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.gate_device (company_id, code, location_id, key_hash, registered_by)
  values (me.company_id, upper(p_code), p_location_id, encode(digest(v_key, 'sha256'), 'hex'), me.person_id) returning id into v_id;
  return jsonb_build_object('device_id', v_id, 'device_key', v_key, 'note_bn', 'এই চাবি একবারই দেখানো হলো — গেট-ডিভাইসে সংরক্ষণ করুন।');
end $$;

-- The employee's short-lived attendance QR (shown on the phone, scanned by the gate device).
create function api.v1_attendance_qr() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_emp uuid; v_win integer; v_w bigint;
begin
  select * into me from iam.fn_require('hr.attendance.scan', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person()), false);
  v_emp := hr.fn_employee_of(me.company_id, me.person_id);
  if v_emp is null or not hr.fn_employee_active(v_emp) then perform core.fn_raise('E_ONBOARDING_INCOMPLETE', 'no active employment'); end if;
  v_win := config.fn_get_int(me.company_id, 'hr.gate.qr_window_seconds');
  v_w := floor(extract(epoch from clock_timestamp()) / v_win)::bigint;
  return jsonb_build_object('payload', sales.fn_signed(me.company_id, 'MOS1|A|' || (select c.code from core.company c where c.id = me.company_id) || '|' || v_emp || '|' || v_w),
                            'valid_seconds', v_win);
end $$;

-- Gate scan (online) and offline queue sync (F161, F170). Called by the gate app with its device key.
create function api.v1_gate_scan(p_device_code text, p_device_key text, p_payload text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; g hr.gate_device; v text;
begin
  select * into me from iam.fn_context(false);
  g := hr.fn_gate_device(me.company_id, p_device_code, p_device_key);
  perform set_config('mohona.change_reason', 'gate scan', true);
  v := hr.fn_qr_scan(me.company_id, g, p_payload, null);
  if v in ('invalid','expired','inactive') then perform core.fn_raise('E_QR_INVALID', v); end if;
  return jsonb_build_object('result', v);
end $$;

create function api.v1_gate_sync(p_device_code text, p_device_key text, p_scans jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; g hr.gate_device; s jsonb; v text; out jsonb := '{}'::jsonb;
begin
  select * into me from iam.fn_context(false);
  g := hr.fn_gate_device(me.company_id, p_device_code, p_device_key);
  perform set_config('mohona.change_reason', 'gate offline sync', true);
  for s in select * from jsonb_array_elements(coalesce(p_scans, '[]'::jsonb)) loop
    v := hr.fn_qr_scan(me.company_id, g, s ->> 'payload', (s ->> 'scanned_at')::timestamptz);
    out := jsonb_set(out, array[v], to_jsonb(coalesce((out ->> v)::integer, 0) + 1));
  end loop;
  return out;
end $$;

-- PIN backup at a registered gate device (F162), rate-limited per device + employee.
create function api.v1_gate_pin(p_device_code text, p_device_key text, p_employee_code text, p_pin text) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
declare me record; g hr.gate_device; e hr.employee%rowtype; v_hash text; v_ok boolean;
begin
  select * into me from iam.fn_context(false);
  g := hr.fn_gate_device(me.company_id, p_device_code, p_device_key);
  select * into e from hr.employee where company_id = me.company_id and employee_code = p_employee_code;
  if (select count(*) from hr.pin_attempt a where a.device_id = g.id and a.employee_id is not distinct from e.id and not a.ok and a.at > clock_timestamp() - interval '15 minutes')
     >= config.fn_get_int(me.company_id, 'hr.gate.pin_max_failures') then
    perform core.fn_raise('E_RATE_LIMITED');
  end if;
  select p.pin_hash into v_hash from iam.login_pin p where p.person_id = e.person_id;
  v_ok := e.id is not null and v_hash is not null and crypt(coalesce(p_pin, ''), v_hash) = v_hash and hr.fn_employee_active(e.id);
  insert into hr.pin_attempt (company_id, device_id, employee_id, ok) values (me.company_id, g.id, e.id, v_ok);
  if not v_ok then return jsonb_build_object('result', 'failed'); end if;       -- same answer for every failure (no hints)
  perform set_config('mohona.change_reason', 'gate PIN', true);
  insert into hr.attendance_event (company_id, employee_id, event_at, method, device_id) values (me.company_id, e.id, clock_timestamp(), 'pin', g.id);
  return jsonb_build_object('result', 'ok');
end $$;

-- Manual entry by HR (F163) and correction request by the employee (F167): both pending until another person decides.
create function api.v1_attendance_manual(p_employee_id uuid, p_event_at timestamptz, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.attendance.correct', iam.fn_my_company_resource(), true);
  if not exists (select 1 from hr.employee e where e.id = p_employee_id and e.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'employee'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.attendance_event (company_id, employee_id, event_at, method, status, reason, created_by)
  values (me.company_id, p_employee_id, p_event_at, 'manual', 'pending', p_reason, me.person_id) returning id into v_id;
  return jsonb_build_object('event_id', v_id, 'status', 'pending');
end $$;

create function api.v1_attendance_correction(p_event_at timestamptz, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.attendance.scan', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person()), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.attendance_event (company_id, employee_id, event_at, method, status, reason, created_by)
  values (me.company_id, hr.fn_employee_of(me.company_id, me.person_id), p_event_at, 'correction', 'pending', p_reason, me.person_id) returning id into v_id;
  return jsonb_build_object('event_id', v_id, 'status', 'pending');
end $$;

create function api.v1_attendance_decide(p_event_id uuid, p_approve boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; ev hr.attendance_event%rowtype;
begin
  select * into me from iam.fn_require('hr.attendance.correct', iam.fn_my_company_resource(), true);
  select * into ev from hr.attendance_event where id = p_event_id and company_id = me.company_id for update;
  if not found or ev.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending attendance'); end if;
  if ev.created_by = me.person_id or (select e.person_id from hr.employee e where e.id = ev.employee_id) = me.person_id then perform core.fn_raise('E_SELF_APPROVAL'); end if;
  perform set_config('mohona.change_reason', 'attendance decision', true);
  update hr.attendance_event set status = case when p_approve then 'posted' else 'rejected' end, decided_by = me.person_id where id = ev.id;
  return jsonb_build_object('event_id', ev.id, 'status', case when p_approve then 'posted' else 'rejected' end);
end $$;

-- Shifts, roster, late policy (F164, F165)
create function api.v1_shift_save(p_code text, p_name_bn text, p_start time, p_end time) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid;
begin
  select * into me from iam.fn_require('hr.roster.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', 'shift', true);
  insert into hr.shift (company_id, code, name_bn, start_time, end_time) values (me.company_id, upper(p_code), p_name_bn, p_start, p_end)
  on conflict (company_id, code) do update set name_bn = excluded.name_bn, start_time = excluded.start_time, end_time = excluded.end_time returning id into v_id;
  return jsonb_build_object('shift_id', v_id, 'overnight', p_end <= p_start);
end $$;

create function api.v1_roster_set(p_employee_id uuid, p_from date, p_to date, p_shift_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d date; n integer := 0;
begin
  select * into me from iam.fn_require('hr.roster.manage', iam.fn_my_company_resource(), true);
  if p_to < p_from or p_to - p_from > 92 then perform core.fn_raise('E_INVALID_ACTION', 'range'); end if;
  perform set_config('mohona.change_reason', 'roster', true);
  for d in select generate_series(p_from, p_to, interval '1 day')::date loop
    insert into hr.roster (company_id, employee_id, work_date, shift_id, set_by) values (me.company_id, p_employee_id, d, p_shift_id, me.person_id)
    on conflict (employee_id, work_date) do update set shift_id = excluded.shift_id, set_by = excluded.set_by;
    n := n + 1;
  end loop;
  return jsonb_build_object('days', n);
end $$;

create function api.v1_late_policy_add(p_effective_from date, p_grace_minutes integer, p_lates_per_deduction integer, p_deduction_days numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.roster.manage', iam.fn_my_company_resource(), true);
  if p_effective_from < current_date then perform core.fn_raise('E_INVALID_ACTION', 'a policy starts today or later (past days keep their policy)'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.late_policy (company_id, effective_from, grace_minutes, lates_per_deduction, deduction_days, set_by, reason)
  values (me.company_id, p_effective_from, p_grace_minutes, p_lates_per_deduction, p_deduction_days, me.person_id, p_reason);
  return jsonb_build_object('effective_from', p_effective_from);
end $$;

-- Leave (F166) and overtime (F168) through the approval engine.
create function api.v1_leave_type_save(p_code text, p_name_bn text, p_annual_days numeric) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('hr.roster.manage', iam.fn_my_company_resource(), true);
  insert into hr.leave_type (company_id, code, name_bn, annual_days) values (me.company_id, upper(p_code), p_name_bn, p_annual_days)
  on conflict (company_id, code) do update set name_bn = excluded.name_bn, annual_days = excluded.annual_days;
  return jsonb_build_object('code', upper(p_code));
end $$;

create function api.v1_leave_request(p_code text, p_from date, p_to date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_emp uuid; v_days numeric; v_used numeric; v_quota numeric; v_id uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.leave.request', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person()), true);
  v_emp := hr.fn_employee_of(me.company_id, me.person_id);
  if p_from is null or p_to < p_from then perform core.fn_raise('E_INVALID_ACTION', 'dates'); end if;
  v_days := p_to - p_from + 1;
  select t.annual_days into v_quota from hr.leave_type t where t.company_id = me.company_id and t.code = upper(p_code);
  if v_quota is null then perform core.fn_raise('E_NOT_FOUND', 'leave type'); end if;
  select coalesce(sum(l.days), 0) into v_used from hr.leave_request l where l.employee_id = v_emp and l.leave_code = upper(p_code) and l.status in ('posted','pending_approval')
     and extract(year from l.date_from) = extract(year from p_from);
  if v_used + v_days > v_quota then perform core.fn_raise('E_LEAVE_BALANCE', 'remaining ' || (v_quota - v_used)); end if;
  if exists (select 1 from hr.leave_request l where l.employee_id = v_emp and l.status in ('posted','pending_approval')
              and daterange(l.date_from, l.date_to, '[]') && daterange(p_from, p_to, '[]')) then perform core.fn_raise('E_LEAVE_OVERLAP'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.leave_request (id, company_id, employee_id, leave_code, date_from, date_to, days, reason, created_by)
  values (v_id, me.company_id, v_emp, upper(p_code), p_from, p_to, v_days, p_reason, me.person_id);
  j := core.fn_approval_submit(me.company_id, 'hr.leave', v_id, v_days, iam.fn_resource(me.company_id, (select c.home_wing_id from iam.fn_context(false) c), (select c.home_department_id from iam.fn_context(false) c), null, null, me.person_id), null);
  update hr.leave_request set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  if j ->> 'status' = 'approved' then perform hr.fn_on_approved((select r from core.approval_request r where r.id = (j ->> 'request_id')::uuid)); end if;
  return jsonb_build_object('leave_id', v_id, 'days', v_days, 'status', (select l.status from hr.leave_request l where l.id = v_id));
end $$;

create function api.v1_overtime_request(p_work_date date, p_hours numeric, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); j jsonb;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('hr.attendance.scan', iam.fn_resource(iam.fn_context_company(), null, null, null, null, iam.fn_current_person()), true);
  perform set_config('mohona.change_reason', p_reason, true);
  insert into hr.overtime_request (id, company_id, employee_id, work_date, hours, reason, created_by)
  values (v_id, me.company_id, hr.fn_employee_of(me.company_id, me.person_id), p_work_date, p_hours, p_reason, me.person_id);
  j := core.fn_approval_submit(me.company_id, 'hr.overtime', v_id, p_hours, iam.fn_resource(me.company_id, (select c.home_wing_id from iam.fn_context(false) c), (select c.home_department_id from iam.fn_context(false) c), null, null, me.person_id), null);
  update hr.overtime_request set approval_request_id = (j ->> 'request_id')::uuid where id = v_id;
  if j ->> 'status' = 'approved' then perform hr.fn_on_approved((select r from core.approval_request r where r.id = (j ->> 'request_id')::uuid)); end if;
  return jsonb_build_object('overtime_id', v_id, 'status', (select o.status from hr.overtime_request o where o.id = v_id));
end $$;

-- Report (F169): per employee and day; employees see only themselves (SELF scope).
create function hr.fn_day_row(p_company uuid, p_employee uuid, p_day date) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare s hr.shift%rowtype; pol hr.late_policy%rowtype; v_start timestamptz; v_end timestamptz; v_in timestamptz; v_out timestamptz; v_late integer := 0; v_status text;
begin
  select sh.* into s from hr.roster r join hr.shift sh on sh.id = r.shift_id where r.employee_id = p_employee and r.work_date = p_day;
  select * into pol from hr.late_policy p where p.company_id = p_company and p.effective_from <= p_day order by p.effective_from desc limit 1;
  if s.id is not null then
    v_start := p_day + s.start_time; v_end := (p_day + case when s.overnight then 1 else 0 end) + s.end_time;     -- overnight ends next day (F164)
    select min(e.event_at), max(e.event_at) into v_in, v_out from hr.attendance_event e
     where e.employee_id = p_employee and e.status = 'posted' and e.event_at between v_start - interval '3 hours' and v_end + interval '6 hours';
  else
    select min(e.event_at), max(e.event_at) into v_in, v_out from hr.attendance_event e where e.employee_id = p_employee and e.status = 'posted' and e.event_at::date = p_day;
  end if;
  if exists (select 1 from hr.leave_request l where l.employee_id = p_employee and l.status = 'posted' and p_day between l.date_from and l.date_to) then v_status := 'leave';
  elsif v_in is null then v_status := case when s.id is null then 'off' else 'absent' end;
  else
    v_late := case when s.id is null then 0 else greatest(0, floor(extract(epoch from v_in - v_start) / 60)::integer - coalesce(pol.grace_minutes, 0)) end;
    v_status := case when v_late > 0 then 'late' else 'present' end;
  end if;
  return jsonb_build_object('employee_id', p_employee, 'date', p_day, 'shift', s.code, 'first_in', v_in, 'last_out', v_out, 'status', v_status, 'late_minutes', v_late);
end $$;

create function api.v1_attendance_report(p_from date, p_to date, p_employee_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_emp uuid; v_rows jsonb := '[]'::jsonb; e record; d date; pol hr.late_policy%rowtype; v_lates integer;
begin
  select * into me from iam.fn_context(false);
  v_emp := coalesce(p_employee_id, hr.fn_employee_of(me.company_id, me.person_id));
  if p_to < p_from or p_to - p_from > 62 then perform core.fn_raise('E_INVALID_ACTION', 'range up to 62 days'); end if;
  for e in select x.id, x.person_id from hr.employee x where x.company_id = me.company_id and (x.id = v_emp or (p_employee_id is null and false)) loop
    perform iam.fn_require('hr.attendance.read', iam.fn_resource(me.company_id, null, null, null, null, e.person_id), false);
    for d in select generate_series(p_from, p_to, interval '1 day')::date loop
      v_rows := v_rows || jsonb_build_array(hr.fn_day_row(me.company_id, e.id, d));
    end loop;
  end loop;
  select * into pol from hr.late_policy p where p.company_id = me.company_id and p.effective_from <= p_to order by p.effective_from desc limit 1;
  v_lates := (select count(*) from jsonb_array_elements(v_rows) x where x ->> 'status' = 'late');
  return jsonb_build_object('rows', v_rows, 'late_days', v_lates,
                            'deduction_days', case when pol.id is null then 0 else floor(v_lates::numeric / pol.lates_per_deduction) * pol.deduction_days end);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_route_save(uuid, text, text, uuid, jsonb, text, integer, text)', 'api.v1_route_plan(uuid, uuid, text, date, boolean)',
      'api.v1_visit_check_in(uuid, numeric, numeric)', 'api.v1_visit_outcome(uuid, text, text, text)', 'api.v1_visit_missed(uuid, text, text, text)',
      'api.v1_visit_reschedule(uuid, date, integer)', 'api.v1_route_reassign(uuid, uuid, text)', 'api.v1_route_map(uuid)', 'api.v1_route_performance(date, date)', 'api.v1_my_visits(date)',
      'api.v1_gate_register(text, uuid, text)', 'api.v1_attendance_qr()', 'api.v1_gate_scan(text, text, text)', 'api.v1_gate_sync(text, text, jsonb)',
      'api.v1_gate_pin(text, text, text, text)', 'api.v1_attendance_manual(uuid, timestamptz, text)', 'api.v1_attendance_correction(timestamptz, text)',
      'api.v1_attendance_decide(uuid, boolean)', 'api.v1_shift_save(text, text, time, time)', 'api.v1_roster_set(uuid, date, date, uuid)',
      'api.v1_late_policy_add(date, integer, integer, numeric, text)', 'api.v1_leave_type_save(text, text, numeric)', 'api.v1_leave_request(text, date, date, text)',
      'api.v1_overtime_request(date, numeric, text)', 'api.v1_attendance_report(date, date, uuid)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

-- 20261108004200_masking_reads.sql  (S61 — OI-19: the Chairman's masking policy applied to the remaining sensitive reads)
--   hr.payroll.amount   pay amounts of OTHER people (payslip opened by HR/MD, payroll reconciliation). A person's own payslip is never masked.
--   hr.person.phone / sales.contact.phone / procurement.supplier.phone   phone numbers in search lists (20261108004100_lookup_pickers.sql)
-- Default = show (no policy row). The Chairman sets 'mask' or 'hide' per position in Settings -> masking (api.v1_mask_set_policy);
-- the Chairman always sees everything. Money is never re-calculated from a masked value: masking is display only.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

create function hr.fn_pay_view(p_value numeric, p_self boolean) returns jsonb
language sql volatile security definer set search_path = pg_catalog as $$
  select case when p_self then to_jsonb(p_value) else config.fn_mask_apply('hr.payroll.amount', to_jsonb(p_value)) end
$$;

create or replace function api.v1_payslip(p_run_id uuid, p_employee_id uuid default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; v_emp uuid; l hr.payroll_line%rowtype; r hr.payroll_run%rowtype; v_person uuid; v_self boolean; v_paid numeric;
begin
  select * into me from iam.fn_context(false);
  v_emp := coalesce(p_employee_id, hr.fn_employee_of(me.company_id, me.person_id));
  select e.person_id into v_person from hr.employee e where e.id = v_emp and e.company_id = me.company_id;
  v_self := v_person = me.person_id;
  if v_self then
    perform iam.fn_require('hr.payslip.read_self', iam.fn_resource(me.company_id, null, null, null, null, me.person_id), false);
  else
    perform iam.fn_require('hr.payroll.read', iam.fn_my_company_resource(), false);
  end if;
  select * into r from hr.payroll_run where id = p_run_id and company_id = me.company_id and status = 'posted';
  select * into l from hr.payroll_line where run_id = p_run_id and employee_id = v_emp;
  if r.id is null or l.id is null then perform core.fn_raise('E_NOT_FOUND', 'posted payslip'); end if;
  v_paid := coalesce((select sum(x.amount) from hr.payroll_payment x where x.run_id = r.id and x.employee_id = v_emp), 0);
  return jsonb_build_object('run', r.number, 'period', r.period, 'kind', r.kind, 'employee', (select p.full_name_bn from core.person p where p.id = v_person),
    'days_employed', l.days_employed, 'absent_days', l.absent_days, 'leave_days', l.leave_days, 'overtime_hours', l.overtime_hours,
    'earnings', case when v_self or config.fn_mask_apply('hr.payroll.amount', to_jsonb(1)) = to_jsonb(1) then l.earnings end,
    'deductions', case when v_self or config.fn_mask_apply('hr.payroll.amount', to_jsonb(1)) = to_jsonb(1) then l.deductions end,
    'gross', hr.fn_pay_view(l.gross, v_self), 'deduction_total', hr.fn_pay_view(l.deduction_total, v_self), 'net', hr.fn_pay_view(l.net, v_self),
    'paid', hr.fn_pay_view(v_paid, v_self), 'masked', not v_self and config.fn_mask_apply('hr.payroll.amount', to_jsonb(1)) is distinct from to_jsonb(1));
end $$;

create or replace function api.v1_payroll_reconcile(p_run_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('hr.payroll.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('employee_id', q.employee_id, 'employee', q.name,
           'net', hr.fn_pay_view(q.net, q.person_id = me.person_id), 'paid', hr.fn_pay_view(q.paid, q.person_id = me.person_id),
           'unpaid', hr.fn_pay_view(q.net - q.paid, q.person_id = me.person_id), 'settled', q.net = q.paid))
     from (select l.employee_id, e.person_id, p.full_name_bn name, l.net,
                  coalesce((select sum(x.amount) from hr.payroll_payment x where x.run_id = l.run_id and x.employee_id = l.employee_id), 0) paid
             from hr.payroll_line l join hr.payroll_run r on r.id = l.run_id join hr.employee e on e.id = l.employee_id join core.person p on p.id = e.person_id
            where l.run_id = p_run_id and r.company_id = me.company_id) q), '[]'::jsonb);
end $$;

reset role;

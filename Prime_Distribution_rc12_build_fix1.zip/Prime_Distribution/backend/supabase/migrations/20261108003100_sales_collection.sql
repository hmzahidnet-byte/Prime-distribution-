-- 20261108003100_sales_collection.sql  (S41–S43 in one step)
-- Sales (SALES_ORDER MOS-F153-141..150, ADR-10 returns) + collections (COLLECTION_PAYMENT MOS-F153-131..140).
--   141 quotation: never promises more than available FG     142 order: credit + availability; breach = hold
--   143 approval engine for discounts / overrides / credit holds (maker-checker)   144 allocation = FG reservation, no oversell
--   145 dispatch: FEFO stock-out of the reservation, COGS journal   146 delivery proof once
--   147 invoice: number, signed QR, dealer ledger + revenue journal, no VAT   148 return (ADR-10): original dispatch cost,
--       into a quarantine warehouse first, credit note linked to the invoice   149 price override: approval, original kept
--   150 reporting: weekly for weekly-only roles (max 5 weeks per query, no month totals), monthly only with its right
--   131 collection intent with unique number   132 cash: recorded by one, verified by another, cash voucher
--   133 bank: verified only against an imported bank statement line   134/135 bKash / Nagad: verified only by a provider
--       confirmation (OTP or screenshot never settles)   136 signed receipt QR (amount always from the server)
--   137 payment QR only for a configured provider   138 partial allocation within verified funds
--   139 reversal (never delete)   140 idempotent dealer due reconciliation
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

alter table inventory.stock_move drop constraint stock_move_move_type_check;
alter table inventory.stock_move add constraint stock_move_move_type_check check (move_type in ('receipt','opening','quarantine_release','issue','return','waste_normal',
  'waste_abnormal','adjust_in','adjust_out','transfer_in','transfer_out','fg_receipt','sale','purchase_return','sales_return'));

-- ================================================================ documents
create table sales.quotation (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  number       text,
  dealer_id    uuid not null,
  lines        jsonb not null,                  -- [{product_id, qty, price}]
  total        numeric(16,2) not null,
  valid_until  date not null,
  status       text not null default 'open' check (status in ('open','ordered','expired','cancelled')),
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_quotation_nodel before delete on sales.quotation for each row execute function core.fn_deny_delete();
create trigger trg_quotation_audit after insert or update on sales.quotation for each row execute function audit.fn_row_change();

create table sales.sales_order (
  id                  uuid primary key default gen_random_uuid(),
  company_id          uuid not null,
  number              text,
  dealer_id           uuid not null,
  warehouse_id        uuid not null,
  quotation_id        uuid,
  price_list_id       uuid,
  lines               jsonb not null,           -- [{line, product_id, qty, list_price, price, override_reason}]
  total               numeric(16,2) not null check (total >= 0),
  status              text not null default 'pending_approval'
                       check (status in ('pending_approval','approved','allocated','dispatched','delivered','invoiced','cancelled','rejected')),
  hold_reasons        text[] not null default array[]::text[],
  approval_request_id uuid,
  created_by          uuid not null references core.person(id),
  created_at          timestamptz not null default clock_timestamp(),
  updated_at          timestamptz not null default clock_timestamp(),
  row_version         integer not null default 1,
  unique (id, company_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id)
);
create function sales.fn_order_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.lines is distinct from old.lines or new.total <> old.total or new.dealer_id <> old.dealer_id or new.created_by <> old.created_by then
    raise exception 'E_IMMUTABLE: an order''s lines and prices never change (cancel and re-order)' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'pending_approval' and new.status in ('approved','rejected','cancelled'))
       or (old.status = 'approved' and new.status in ('allocated','cancelled')) or (old.status = 'allocated' and new.status in ('dispatched','cancelled'))
       or (old.status = 'dispatched' and new.status in ('delivered','invoiced')) or (old.status = 'delivered' and new.status = 'invoiced')) then
    raise exception 'E_INVALID_ACTION: order % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_order_guard before update on sales.sales_order for each row execute function sales.fn_order_guard();
create trigger trg_order_touch before update on sales.sales_order for each row execute function core.fn_touch_row();
create trigger trg_order_nodel before delete on sales.sales_order for each row execute function core.fn_deny_delete();
create trigger trg_order_audit after insert or update on sales.sales_order for each row execute function audit.fn_row_change();

create table sales.dispatch (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  number          text,
  order_id        uuid not null,
  vehicle         text,
  driver_name     text,
  lines           jsonb not null,                 -- [{product_id, lot_id, qty, unit_cost}]  (ADR-10 traceable cost)
  cogs            numeric(16,4) not null,
  dispatched_by   uuid not null references core.person(id),
  dispatched_at   timestamptz not null default clock_timestamp(),
  delivered_at    timestamptz,
  recipient_name  text,
  signature_sha256 text check (signature_sha256 is null or signature_sha256 ~ '^[0-9a-f]{64}$'),
  delivery_by     uuid references core.person(id),
  unique (id, company_id), unique (order_id),
  foreign key (order_id, company_id) references sales.sales_order (id, company_id)
);
create function sales.fn_dispatch_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['delivered_at','recipient_name','signature_sha256','delivery_by']) <> (to_jsonb(new) - array['delivered_at','recipient_name','signature_sha256','delivery_by'])
     or old.delivered_at is not null then
    raise exception 'E_ALREADY_DELIVERED: delivery is confirmed once' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_dispatch_guard before update on sales.dispatch for each row execute function sales.fn_dispatch_guard();
create trigger trg_dispatch_nodel before delete on sales.dispatch for each row execute function core.fn_deny_delete();
create trigger trg_dispatch_audit after insert or update on sales.dispatch for each row execute function audit.fn_row_change();

create table sales.invoice (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null,
  number      text not null,
  order_id    uuid not null unique,
  dealer_id   uuid not null,
  invoice_date date not null,
  due_date    date not null,
  total       numeric(16,2) not null check (total >= 0),
  lines       jsonb not null,
  posted_by   uuid, posted_at timestamptz not null default clock_timestamp(),
  unique (id, company_id), unique (company_id, number),
  foreign key (order_id, company_id) references sales.sales_order (id, company_id),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create trigger trg_invoice_no_mutation before update or delete on sales.invoice for each row execute function core.fn_deny_mutation();
create trigger trg_invoice_audit after insert on sales.invoice for each row execute function audit.fn_row_change();

create table sales.sales_return (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  number        text,
  invoice_id    uuid not null,
  warehouse_id  uuid not null,
  lines         jsonb not null,                  -- [{product_id, lot_id, qty, condition, unit_cost, price}]
  credit_amount numeric(16,2) not null check (credit_amount > 0),
  cost_amount   numeric(16,4) not null,
  reason        text not null,
  created_by    uuid not null references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  unique (id, company_id),
  foreign key (invoice_id, company_id) references sales.invoice (id, company_id),
  foreign key (warehouse_id, company_id) references inventory.warehouse (id, company_id)
);
create trigger trg_sales_return_no_mutation before update or delete on sales.sales_return for each row execute function core.fn_deny_mutation();
create trigger trg_sales_return_audit after insert on sales.sales_return for each row execute function audit.fn_row_change();

-- ================================================================ collections
create table sales.provider_txn (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  provider    text not null check (provider in ('bkash','nagad')),
  trx_id      text not null check (trx_id ~ '^[A-Za-z0-9]{6,30}$'),
  amount      numeric(16,2) not null check (amount > 0),
  msisdn      text,
  status      text not null check (status in ('verified','failed')),
  received_at timestamptz not null default clock_timestamp(),
  unique (provider, trx_id)
);
create trigger trg_provider_txn_no_mutation before update or delete on sales.provider_txn for each row execute function core.fn_deny_mutation();
create trigger trg_provider_txn_audit after insert on sales.provider_txn for each row execute function audit.fn_row_change();

create table sales.collection (
  id             uuid primary key default gen_random_uuid(),
  company_id     uuid not null,
  number         text not null,
  dealer_id      uuid not null,
  method         text not null check (method in ('cash','bank','bkash','nagad')),
  amount         numeric(16,2) not null check (amount > 0),
  reference      text,
  evidence_path  text,
  allocations    jsonb not null default '[]'::jsonb,       -- [{invoice_id, amount}]
  status         text not null default 'recorded' check (status in ('recorded','verified','rejected','reversed')),
  collected_by   uuid not null references core.person(id),
  collected_at   timestamptz not null default clock_timestamp(),
  verified_by    uuid references core.person(id),
  verified_at    timestamptz,
  bank_line_id   uuid,
  provider_txn_id uuid references sales.provider_txn(id),
  cash_account_id uuid,
  reversed_by    uuid references core.person(id),
  reversal_reason text,
  unique (id, company_id), unique (company_id, number),
  check (verified_by is null or verified_by <> collected_by),
  foreign key (dealer_id, company_id) references sales.dealer (id, company_id)
);
create unique index collection_bank_line_once on sales.collection (bank_line_id) where bank_line_id is not null and status <> 'reversed';
create unique index collection_provider_once on sales.collection (provider_txn_id) where provider_txn_id is not null and status <> 'reversed';
create function sales.fn_collection_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.amount <> old.amount or new.dealer_id <> old.dealer_id or new.method <> old.method or new.number <> old.number or new.collected_by <> old.collected_by
     or (old.status <> 'recorded' and new.allocations is distinct from old.allocations)
     or not ((old.status = 'recorded' and new.status in ('recorded','verified','rejected')) or (old.status = 'verified' and new.status in ('verified','reversed'))
             or new.status = old.status) then
    raise exception 'E_IMMUTABLE: a collection is verified or reversed, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_collection_guard before update on sales.collection for each row execute function sales.fn_collection_guard();
create trigger trg_collection_nodel before delete on sales.collection for each row execute function core.fn_deny_delete();
create trigger trg_collection_audit after insert or update on sales.collection for each row execute function audit.fn_row_change();

create table sales.report_log (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  person_id   uuid not null references core.person(id),
  report      text not null,
  params      jsonb not null,
  created_at  timestamptz not null default clock_timestamp()
);
create trigger trg_sales_report_log_no_mutation before update or delete on sales.report_log for each row execute function core.fn_deny_mutation();

select core.fn_apply_rls('sales', 'quotation');
select core.fn_apply_rls('sales', 'sales_order');
select core.fn_apply_rls('sales', 'dispatch');
select core.fn_apply_rls('sales', 'invoice');
select core.fn_apply_rls('sales', 'sales_return');
select core.fn_apply_rls('sales', 'provider_txn');
select core.fn_apply_rls('sales', 'collection');
select core.fn_apply_rls('sales', 'report_log');

-- ================================================================ permissions + settings
update iam.permission_catalog set status = 'active'
 where code in ('sales.order.create','sales.order.approve','sales.dispatch.post','sales.invoice.post','sales.collection.record','sales.collection.verify',
                'sales.return.create','sales.weekly_summary.read','sales.monthly_summary.read','finance.ar.receive');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select x, y, 'allow', z from (values
  ('FIELD_SALES','sales.order.create','ASSIGNED'), ('FIELD_SALES','sales.collection.record','ASSIGNED'), ('FIELD_SALES','sales.weekly_summary.read','ASSIGNED'),
  ('SALES_MANAGER','sales.order.create','COMPANY'), ('SALES_MANAGER','sales.order.approve','COMPANY'), ('SALES_MANAGER','sales.return.create','COMPANY'),
  ('SALES_MANAGER','sales.weekly_summary.read','COMPANY'), ('SALES_MANAGER','sales.monthly_summary.read','COMPANY'), ('SALES_MANAGER','sales.collection.record','COMPANY'),
  ('STOREKEEPER','sales.dispatch.post','COMPANY'), ('ACCOUNTANT','sales.invoice.post','COMPANY'), ('ACCOUNTANT','sales.collection.verify','COMPANY'),
  ('CASHIER','sales.collection.verify','COMPANY'), ('CASHIER','sales.collection.record','COMPANY'), ('FIN_MANAGER','finance.ar.receive','COMPANY'),
  ('FIN_MANAGER','sales.collection.verify','COMPANY'), ('MD','sales.order.approve','COMPANY'), ('MD','sales.monthly_summary.read','COMPANY'),
  ('MD','sales.weekly_summary.read','COMPANY')) v(x, y, z)
on conflict do nothing;
select iam.fn_backfill_template_rules(null);

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('sales.quotation.valid_days',  'sales', 'int', '7', 1, 90, null, 'কোটেশনের মেয়াদ (দিন)', 'MOS-F153-141', false, 1700),
  ('sales.payment_qr.providers',  'sales', 'text_array', '[]', null, null, '["bkash","nagad"]', 'চালু পেমেন্ট-QR প্রদানকারী (চুক্তি থাকলে)', 'MOS-F153-137', true, 1710),
  ('sales.report.weekly_max_weeks','sales', 'int', '5', 1, 8, null, 'সাপ্তাহিক-রিপোর্টে একবারে সর্বোচ্চ সপ্তাহ', 'MOS-F153-150', true, 1720);
insert into finance.coa_template (code, name_bn, type, parent, postable) values ('4150','বিক্রয়-ফেরত','income','4000',true) on conflict do nothing;
insert into finance.mapping_template (event_key, code, name_bn) values ('sales.returns','4150','বিক্রয়-ফেরত') on conflict do nothing;

-- ================================================================ engine
create function sales.fn_fg_available(p_company uuid, p_product uuid, p_warehouse uuid default null) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(inventory.fn_available(p_company, w.id, p_product)), 0) from inventory.warehouse w
   where w.company_id = p_company and w.status = 'active' and w.kind in ('finished_goods','general') and (p_warehouse is null or w.id = p_warehouse)
$$;

create function sales.fn_open_orders(p_dealer uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select coalesce(sum(o.total), 0) from sales.sales_order o where o.dealer_id = p_dealer and o.status in ('pending_approval','approved','allocated','dispatched','delivered')
$$;

-- Open amount of an invoice = total − verified, not reversed allocations − credit notes.
create function sales.fn_invoice_open(p_invoice uuid) returns numeric
language sql stable security definer set search_path = pg_catalog as $$
  select i.total
       - coalesce((select sum((a ->> 'amount')::numeric) from sales.collection c, jsonb_array_elements(c.allocations) a
                    where c.dealer_id = i.dealer_id and c.status = 'verified' and (a ->> 'invoice_id')::uuid = i.id), 0)
       - coalesce((select sum(r.credit_amount) from sales.sales_return r where r.invoice_id = i.id), 0)
    from sales.invoice i where i.id = p_invoice
$$;

-- Approval: allocate FG (reservation per line, never above available — F144).
create function sales.fn_allocate(p_order uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare o sales.sales_order%rowtype; l jsonb;
begin
  select * into o from sales.sales_order where id = p_order for update;
  if o.status <> 'approved' then return; end if;
  for l in select * from jsonb_array_elements(o.lines) loop
    perform pg_advisory_xact_lock(hashtext(o.warehouse_id::text || (l ->> 'product_id')));
    if (l ->> 'qty')::numeric > inventory.fn_available(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid) then
      raise exception 'E_INSUFFICIENT_STOCK: % not available', l ->> 'product_id' using errcode = 'P0001';
    end if;
    insert into inventory.reservation (company_id, warehouse_id, product_id, batch_ref, qty, created_by, reason)
    values (o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, 'SO:' || o.number, (l ->> 'qty')::numeric, o.created_by, 'sales order ' || o.number);
  end loop;
  update sales.sales_order set status = 'allocated' where id = o.id;
end $$;

create or replace function sales.fn_on_approved(r core.approval_request) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare a sales.dealer_adjustment%rowtype;
begin
  if r.document_type = 'sales.credit_exception' then
    update sales.credit_exception set status = 'posted', posted_at = clock_timestamp() where id = r.document_id and status = 'pending_approval';
  elsif r.document_type = 'sales.dealer_adjustment' then
    select * into a from sales.dealer_adjustment where id = r.document_id for update;
    if a.status <> 'pending_approval' then return; end if;
    perform sales.fn_post_ledger(a.company_id, a.dealer_id, 'adjustment', a.amount, current_date, null, 'sales.dealer_adjustment', a.id, a.reason);
    perform finance.fn_emit(a.company_id, 'dealer_adj:' || a.id, 'ডিলার-খাতা সমন্বয়', jsonb_build_array(
      jsonb_build_object('key', 'sales.ar', 'dr', greatest(a.amount, 0), 'cr', greatest(-a.amount, 0)),
      jsonb_build_object('key', 'sales.adjustment', 'dr', greatest(-a.amount, 0), 'cr', greatest(a.amount, 0))));
    update sales.dealer_adjustment set status = 'posted', posted_at = clock_timestamp() where id = a.id;
  elsif r.document_type = 'sales.order' then
    update sales.sales_order set status = 'approved' where id = r.document_id and status = 'pending_approval';
    perform sales.fn_allocate(r.document_id);
  end if;
end $$;

create function sales.fn_signed(p_company uuid, p_body text) returns text
language plpgsql security definer set search_path = pg_catalog, public, extensions as $$
begin
  return p_body || '|' || left(encode(hmac(convert_to(p_body, 'UTF8'), inventory.fn_qr_secret(p_company), 'sha256'), 'hex'), 16);
end $$;

-- Verified collection -> dealer ledger credit + journal (idempotent: one source per collection).
create function sales.fn_post_collection(p_collection uuid) returns void
language plpgsql security definer set search_path = pg_catalog as $$
declare c sales.collection%rowtype;
begin
  select * into c from sales.collection where id = p_collection;
  perform sales.fn_post_ledger(c.company_id, c.dealer_id, 'collection', -c.amount, current_date, null, 'sales.collection', c.id, c.method || ' ' || coalesce(c.reference, ''));
  perform finance.fn_emit(c.company_id, 'collection:' || c.id, 'কালেকশন ' || c.number, jsonb_build_array(
    jsonb_build_object('key', case when c.method = 'cash' then 'fin.cash' else 'fin.bank' end, 'dr', c.amount),
    jsonb_build_object('key', 'sales.ar', 'cr', c.amount)));
end $$;

-- ================================================================ API: quotation + order (F141–F144, F149)
create function api.v1_quotation_create(p_dealer_id uuid, p_lines jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; l jsonb; v_total numeric := 0; v_id uuid := gen_random_uuid();
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('sales.order.create', sales.fn_dealer_resource(d), true);
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    if coalesce((l ->> 'qty')::numeric, 0) <= 0 or (l ->> 'qty')::numeric > sales.fn_fg_available(d.company_id, (l ->> 'product_id')::uuid) then
      perform core.fn_raise('E_INSUFFICIENT_STOCK', 'cannot promise ' || (l ->> 'product_id'));               -- F141
    end if;
    v_total := v_total + (l ->> 'qty')::numeric * (l ->> 'price')::numeric;
  end loop;
  perform set_config('mohona.change_reason', 'quotation', true);
  insert into sales.quotation (id, company_id, number, dealer_id, lines, total, valid_until, created_by)
  values (v_id, d.company_id, core.fn_next_number(d.company_id, 'sales.quotation', v_id), d.id, p_lines, round(v_total, 2),
          current_date + config.fn_get_int(d.company_id, 'sales.quotation.valid_days'), me.person_id);
  return jsonb_build_object('quotation_id', v_id, 'total', round(v_total, 2));
end $$;

-- Order: list prices from the price list; any other price needs a reason and approval (original kept, F149);
-- credit breach -> hold reason; everything goes through the approval engine (maker-checker, F143).
create function api.v1_order_create(p_dealer_id uuid, p_warehouse_id uuid, p_price_list_id uuid, p_lines jsonb, p_quotation_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; l jsonb; v_lines jsonb := '[]'::jsonb; n integer := 0; v_list numeric; v_price numeric; v_total numeric := 0;
        v_holds text[] := array[]::text[]; v_id uuid := gen_random_uuid(); cc jsonb; j jsonb;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('sales.order.create', sales.fn_dealer_resource(d), true);
  j := core.fn_idem_begin(me.company_id, 'v1_order_create', jsonb_build_object('d', p_dealer_id, 'l', p_lines, 'q', p_quotation_id));
  if j is not null then return j; end if;
  if d.status <> 'active' then perform core.fn_raise('E_DEALER_SUSPENDED', d.status); end if;
  if jsonb_typeof(p_lines) is distinct from 'array' or jsonb_array_length(p_lines) not between 1 and 100 then perform core.fn_raise('E_INVALID_ACTION', 'lines'); end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    n := n + 1;
    if not inventory.fn_product_usable(me.company_id, (l ->> 'product_id')::uuid) then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
    if coalesce((l ->> 'qty')::numeric, 0) <= 0 or (l ->> 'qty')::numeric > inventory.fn_available(me.company_id, p_warehouse_id, (l ->> 'product_id')::uuid) then
      perform core.fn_raise('E_INSUFFICIENT_STOCK', l ->> 'product_id');
    end if;
    select pr.amount into v_list from inventory.price pr
     where pr.price_list_id = p_price_list_id and pr.company_id = me.company_id and pr.product_id = (l ->> 'product_id')::uuid and pr.variant_id is null
       and pr.unit = (select p.base_unit from inventory.product p where p.id = (l ->> 'product_id')::uuid) and pr.status = 'active'
       and pr.effective_from <= current_date and (pr.effective_to is null or pr.effective_to >= current_date)
     order by pr.effective_from desc limit 1;
    if v_list is null then perform core.fn_raise('E_NOT_FOUND', 'price for ' || (l ->> 'product_id')); end if;
    v_price := coalesce((l ->> 'price')::numeric, v_list);
    if v_price <> v_list then
      if length(btrim(coalesce(l ->> 'override_reason', ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED', 'price override'); end if;
      v_holds := array_append(v_holds, 'price_override');
    end if;
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('line', n, 'product_id', l ->> 'product_id', 'qty', (l ->> 'qty')::numeric, 'list_price', v_list, 'price', v_price,
                                                               'override_reason', l ->> 'override_reason'));
    v_total := v_total + round((l ->> 'qty')::numeric * v_price, 2);
  end loop;
  cc := sales.fn_credit_check(d.id, v_total, sales.fn_open_orders(d.id));
  if not (cc ->> 'allowed')::boolean then v_holds := array_append(v_holds, 'credit'); end if;                    -- F142 hold
  perform set_config('mohona.change_reason', 'sales order', true);
  insert into sales.sales_order (id, company_id, number, dealer_id, warehouse_id, quotation_id, price_list_id, lines, total, hold_reasons, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'sales.order', v_id), d.id, p_warehouse_id, p_quotation_id, p_price_list_id, v_lines, v_total,
          coalesce((select array_agg(distinct x) from unnest(v_holds) x), array[]::text[]), me.person_id);
  update sales.quotation set status = 'ordered' where id = p_quotation_id and dealer_id = d.id and status = 'open';
  j := core.fn_approval_submit(me.company_id, 'sales.order', v_id, v_total, sales.fn_dealer_resource(d),
                               jsonb_build_object('holds', to_jsonb(v_holds), 'credit', cc));
  update sales.sales_order set approval_request_id = (j ->> 'request_id')::uuid, hold_reasons = coalesce(hold_reasons, array[]::text[]) where id = v_id;
  if j ->> 'status' = 'approved' and cardinality(v_holds) = 0 then
    perform sales.fn_on_approved((select r from core.approval_request r where r.id = (j ->> 'request_id')::uuid));
  end if;
  return core.fn_idem_finish(me.company_id, jsonb_build_object('order_id', v_id, 'total', v_total, 'holds', to_jsonb(v_holds), 'credit', cc,
                                                                'status', (select o.status from sales.sales_order o where o.id = v_id)));
end $$;

create function api.v1_order_cancel(p_order_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('sales.order.approve', iam.fn_my_company_resource(), true);
  select * into o from sales.sales_order where id = p_order_id and company_id = me.company_id for update;
  if not found or o.status not in ('pending_approval','approved','allocated') then perform core.fn_raise('E_INVALID_ACTION', 'only undispatched orders are cancelled'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update inventory.reservation set status = 'released', reason = p_reason where company_id = o.company_id and batch_ref = 'SO:' || o.number and status = 'active';
  update sales.sales_order set status = 'cancelled' where id = o.id;
  update core.approval_request set status = 'cancelled', decided_at = clock_timestamp() where id = o.approval_request_id and status = 'pending';
  return jsonb_build_object('order_id', o.id, 'status', 'cancelled');
end $$;

-- ================================================================ API: dispatch, delivery, invoice, return (F145–F148)
create function api.v1_dispatch_post(p_order_id uuid, p_vehicle text, p_driver text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype; l jsonb; a jsonb; v_id uuid := gen_random_uuid(); n integer := 0; v_cost numeric; v_lines jsonb := '[]'::jsonb; v_cogs numeric := 0; rs uuid;
begin
  select * into o from sales.sales_order where id = p_order_id and company_id = iam.fn_context_company() for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'order'); end if;
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_resource(o.company_id, null, null, null, o.warehouse_id), true);
  if o.status <> 'allocated' then perform core.fn_raise('E_INVALID_ACTION', 'dispatch only an allocated (approved) order'); end if;
  perform set_config('mohona.change_reason', 'dispatch ' || o.number, true);
  for l in select * from jsonb_array_elements(o.lines) loop
    select r.id into rs from inventory.reservation r where r.company_id = o.company_id and r.batch_ref = 'SO:' || o.number and r.product_id = (l ->> 'product_id')::uuid and r.status = 'active' for update;
    update inventory.reservation set status = 'consumed', consumed_qty = qty where id = rs;           -- free the reservation before FEFO picks
    for a in select * from jsonb_array_elements(inventory.fn_fefo(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'qty')::numeric)) loop
      n := n + 1;
      v_cost := inventory.fn_post_move(o.company_id, o.warehouse_id, (l ->> 'product_id')::uuid, (a ->> 'lot_id')::uuid, 'sale', -((a ->> 'qty')::numeric), null,
                                       'sales.dispatch', v_id, n, 'dispatch ' || o.number);
      v_lines := v_lines || jsonb_build_array(jsonb_build_object('product_id', l ->> 'product_id', 'lot_id', a ->> 'lot_id', 'qty', (a ->> 'qty')::numeric, 'unit_cost', round(v_cost, 6)));
      v_cogs := v_cogs + round((a ->> 'qty')::numeric * v_cost, 4);
    end loop;
  end loop;
  insert into sales.dispatch (id, company_id, number, order_id, vehicle, driver_name, lines, cogs, dispatched_by)
  values (v_id, o.company_id, core.fn_next_number(o.company_id, 'sales.dispatch', v_id), o.id, p_vehicle, p_driver, v_lines, v_cogs, me.person_id);
  update sales.sales_order set status = 'dispatched' where id = o.id;
  perform finance.fn_emit(o.company_id, 'dispatch:' || v_id, 'বিক্রীত পণ্যের খরচ ' || o.number, jsonb_build_array(
    jsonb_build_object('key', 'sales.cogs', 'dr', v_cogs), jsonb_build_object('key', 'inv.fg', 'cr', v_cogs)));
  return jsonb_build_object('dispatch_id', v_id, 'lines', v_lines);
end $$;

create function api.v1_delivery_confirm(p_dispatch_id uuid, p_recipient_name text, p_signature_sha256 text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; ds sales.dispatch%rowtype;
begin
  select * into me from iam.fn_require('sales.dispatch.post', iam.fn_my_company_resource(), true);
  select * into ds from sales.dispatch where id = p_dispatch_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dispatch'); end if;
  if ds.delivered_at is not null then perform core.fn_raise('E_ALREADY_DELIVERED'); end if;                 -- F146
  if length(btrim(coalesce(p_recipient_name, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'recipient'); end if;
  perform set_config('mohona.change_reason', 'delivery', true);
  update sales.dispatch set delivered_at = clock_timestamp(), recipient_name = p_recipient_name, signature_sha256 = p_signature_sha256, delivery_by = me.person_id where id = ds.id;
  update sales.sales_order set status = 'delivered' where id = ds.order_id and status = 'dispatched';
  return jsonb_build_object('dispatch_id', ds.id, 'delivered', true);
end $$;

-- Invoice (F147): after dispatch; dealer ledger debit with due date; revenue journal; signed QR; no VAT module.
create function api.v1_invoice_post(p_order_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; o sales.sales_order%rowtype; d sales.dealer%rowtype; v_id uuid := gen_random_uuid(); v_no text;
begin
  select * into me from iam.fn_require('sales.invoice.post', iam.fn_my_company_resource(), true);
  select * into o from sales.sales_order where id = p_order_id and company_id = me.company_id for update;
  if not found or o.status not in ('dispatched','delivered') then perform core.fn_raise('E_INVALID_ACTION', 'invoice a dispatched order once'); end if;
  select * into d from sales.dealer where id = o.dealer_id;
  v_no := core.fn_next_number(me.company_id, 'sales.invoice', v_id);
  perform set_config('mohona.change_reason', 'invoice ' || v_no, true);
  insert into sales.invoice (id, company_id, number, order_id, dealer_id, invoice_date, due_date, total, lines, posted_by)
  values (v_id, me.company_id, v_no, o.id, o.dealer_id, current_date, current_date + d.credit_days, o.total, o.lines, me.person_id);
  update sales.sales_order set status = 'invoiced' where id = o.id;
  perform sales.fn_post_ledger(me.company_id, o.dealer_id, 'invoice', o.total, current_date, current_date + d.credit_days, 'sales.invoice', v_id, 'invoice ' || v_no);
  perform finance.fn_emit(me.company_id, 'invoice:' || v_id, 'বিক্রয় ' || v_no, jsonb_build_array(
    jsonb_build_object('key', 'sales.ar', 'dr', o.total), jsonb_build_object('key', 'sales.revenue', 'cr', o.total)));
  return jsonb_build_object('invoice_id', v_id, 'number', v_no, 'total', o.total, 'due_date', current_date + d.credit_days,
                            'qr', sales.fn_signed(me.company_id, 'MOS1|I|' || (select c.code from core.company c where c.id = me.company_id) || '|' || v_no));
end $$;

-- Return (F148, ADR-10): lots from the original dispatch at their original cost, into a QUARANTINE warehouse;
-- credit note at the invoiced price, linked to the invoice.
create function api.v1_sales_return(p_invoice_id uuid, p_warehouse_id uuid, p_lines jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; i sales.invoice%rowtype; ds sales.dispatch%rowtype; l jsonb; dl jsonb; v_id uuid := gen_random_uuid(); n integer := 0; v_credit numeric := 0; v_cost numeric := 0;
        v_lines jsonb := '[]'::jsonb; v_price numeric; v_done numeric;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('sales.return.create', iam.fn_my_company_resource(), true);
  select * into i from sales.invoice where id = p_invoice_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'invoice'); end if;
  if not exists (select 1 from inventory.warehouse w where w.id = p_warehouse_id and w.company_id = me.company_id and w.kind = 'quarantine') then
    perform core.fn_raise('E_INVALID_ACTION', 'returns go to a quarantine warehouse first (QC before restock)');
  end if;
  select * into ds from sales.dispatch where order_id = i.order_id;
  perform pg_advisory_xact_lock(hashtext(i.id::text));
  for l in select * from jsonb_array_elements(p_lines) loop
    select x into dl from jsonb_array_elements(ds.lines) x where x ->> 'lot_id' = l ->> 'lot_id' and x ->> 'product_id' = l ->> 'product_id' limit 1;
    if dl is null then perform core.fn_raise('E_INVALID_ACTION', 'lot was not dispatched on this invoice'); end if;
    v_done := coalesce((select sum((y ->> 'qty')::numeric) from sales.sales_return r, jsonb_array_elements(r.lines) y
                         where r.invoice_id = i.id and y ->> 'lot_id' = l ->> 'lot_id'), 0);
    if coalesce((l ->> 'qty')::numeric, 0) <= 0 or (l ->> 'qty')::numeric + v_done > (dl ->> 'qty')::numeric then perform core.fn_raise('E_INVALID_ACTION', 'more than dispatched'); end if;
    select (z ->> 'price')::numeric into v_price from jsonb_array_elements(i.lines) z where z ->> 'product_id' = l ->> 'product_id' limit 1;
    n := n + 1;
    perform inventory.fn_post_move(me.company_id, p_warehouse_id, (l ->> 'product_id')::uuid, (l ->> 'lot_id')::uuid, 'sales_return', (l ->> 'qty')::numeric,
                                   (dl ->> 'unit_cost')::numeric, 'sales.return', v_id, n, p_reason);         -- ADR-10: original outbound cost
    v_credit := v_credit + round((l ->> 'qty')::numeric * v_price, 2);
    v_cost := v_cost + round((l ->> 'qty')::numeric * (dl ->> 'unit_cost')::numeric, 4);
    v_lines := v_lines || jsonb_build_array(l || jsonb_build_object('unit_cost', (dl ->> 'unit_cost')::numeric, 'price', v_price));
  end loop;
  if v_credit > i.total - coalesce((select sum(r.credit_amount) from sales.sales_return r where r.invoice_id = i.id), 0) then
    perform core.fn_raise('E_INVALID_ACTION', 'credit above the invoice');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  insert into sales.sales_return (id, company_id, number, invoice_id, warehouse_id, lines, credit_amount, cost_amount, reason, created_by)
  values (v_id, me.company_id, core.fn_next_number(me.company_id, 'sales.return', v_id), i.id, p_warehouse_id, v_lines, v_credit, v_cost, p_reason, me.person_id);
  perform sales.fn_post_ledger(me.company_id, i.dealer_id, 'return', -v_credit, current_date, null, 'sales.return', v_id, 'credit note');
  perform finance.fn_emit(me.company_id, 'sales_return:' || v_id, 'বিক্রয়-ফেরত', jsonb_build_array(
    jsonb_build_object('key', 'sales.returns', 'dr', v_credit), jsonb_build_object('key', 'sales.ar', 'cr', v_credit),
    jsonb_build_object('key', 'inv.fg', 'dr', v_cost), jsonb_build_object('key', 'sales.cogs', 'cr', v_cost)));
  return jsonb_build_object('return_id', v_id, 'credit', v_credit, 'cost', v_cost);
end $$;

-- ================================================================ API: collections (F131–F140)
-- Record (intent): unique number; nothing reduces the due until verification.
create function api.v1_collection_record(p_dealer_id uuid, p_method text, p_amount numeric, p_reference text, p_evidence_path text, p_allocations jsonb) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v_id uuid := gen_random_uuid(); a jsonb; v_sum numeric := 0; j jsonb;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('sales.collection.record', sales.fn_dealer_resource(d), true);
  j := core.fn_idem_begin(me.company_id, 'v1_collection_record', jsonb_build_object('d', p_dealer_id, 'm', p_method, 'a', p_amount, 'r', p_reference));
  if j is not null then return j; end if;
  if coalesce(p_method, '') not in ('cash','bank','bkash','nagad') or coalesce(p_amount, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'method / amount'); end if;
  if p_method <> 'cash' and coalesce(p_reference, '') !~ '^[A-Za-z0-9/_-]{4,40}$' then perform core.fn_raise('E_INVALID_ACTION', 'transaction reference'); end if;
  for a in select * from jsonb_array_elements(coalesce(p_allocations, '[]'::jsonb)) loop
    if not exists (select 1 from sales.invoice i where i.id = (a ->> 'invoice_id')::uuid and i.dealer_id = d.id) then perform core.fn_raise('E_NOT_FOUND', 'invoice of this dealer'); end if;
    if coalesce((a ->> 'amount')::numeric, 0) <= 0 or (a ->> 'amount')::numeric > sales.fn_invoice_open((a ->> 'invoice_id')::uuid) then perform core.fn_raise('E_OVERPAYMENT', a ->> 'invoice_id'); end if;
    v_sum := v_sum + (a ->> 'amount')::numeric;
  end loop;
  if v_sum > p_amount then perform core.fn_raise('E_OVERPAYMENT', 'allocations above the amount'); end if;      -- F138
  perform set_config('mohona.change_reason', 'collection', true);
  insert into sales.collection (id, company_id, number, dealer_id, method, amount, reference, evidence_path, allocations, collected_by)
  values (v_id, d.company_id, core.fn_next_number(d.company_id, 'sales.collection', v_id), d.id, p_method, p_amount, p_reference, p_evidence_path,
          coalesce(p_allocations, '[]'::jsonb), me.person_id);
  return core.fn_idem_finish(me.company_id, jsonb_build_object('collection_id', v_id, 'number', (select c.number from sales.collection c where c.id = v_id), 'status', 'recorded',
    'receipt_qr', sales.fn_signed(d.company_id, 'MOS1|R|' || (select c.code from core.company c where c.id = d.company_id) || '|' || (select c.number from sales.collection c where c.id = v_id))));
end $$;

-- Verify (another person): cash into a cash account; bank only against an imported statement line; bKash / Nagad only
-- against a provider confirmation. A screenshot or an OTP is never proof (F132–F135). Then the due goes down (idempotent).
create function api.v1_collection_verify(p_collection_id uuid, p_cash_account_id uuid, p_bank_line_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c sales.collection%rowtype; bl record; pt sales.provider_txn%rowtype; a jsonb;
begin
  select * into me from iam.fn_require('sales.collection.verify', iam.fn_my_company_resource(), true);
  select * into c from sales.collection where id = p_collection_id and company_id = me.company_id for update;
  if not found or c.status <> 'recorded' then perform core.fn_raise('E_NOT_FOUND', 'recorded collection'); end if;
  if c.collected_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'the collector does not verify'); end if;
  for a in select * from jsonb_array_elements(c.allocations) loop
    if (a ->> 'amount')::numeric > sales.fn_invoice_open((a ->> 'invoice_id')::uuid) then perform core.fn_raise('E_OVERPAYMENT', a ->> 'invoice_id'); end if;
  end loop;
  perform set_config('mohona.change_reason', 'collection verified', true);
  if c.method = 'cash' then
    if not exists (select 1 from finance.cash_account x where x.id = p_cash_account_id and x.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'cash account'); end if;
    update sales.collection set cash_account_id = p_cash_account_id where id = c.id;
  elsif c.method = 'bank' then
    select * into bl from finance.bank_statement_line x where x.id = p_bank_line_id and x.company_id = me.company_id;
    if bl.id is null or bl.amount <> c.amount or coalesce(bl.reference, '') <> coalesce(c.reference, '') then
      perform core.fn_raise('E_UNVERIFIED_PAYMENT', 'a matching bank statement line (amount + reference) is required');
    end if;
    update sales.collection set bank_line_id = bl.id where id = c.id;
  else
    select * into pt from sales.provider_txn x where x.company_id = me.company_id and x.provider = c.method and x.trx_id = c.reference;
    if pt.id is null or pt.status <> 'verified' or pt.amount <> c.amount then
      perform core.fn_raise('E_UNVERIFIED_PAYMENT', 'no verified ' || c.method || ' confirmation for this reference and amount');
    end if;
    update sales.collection set provider_txn_id = pt.id where id = c.id;
  end if;
  update sales.collection set status = 'verified', verified_by = me.person_id, verified_at = clock_timestamp() where id = c.id;
  perform sales.fn_post_collection(c.id);
  return jsonb_build_object('collection_id', c.id, 'status', 'verified', 'balance', sales.fn_dealer_balance(c.dealer_id));
end $$;

create function api.v1_collection_reject(p_collection_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('sales.collection.verify', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  update sales.collection set status = 'rejected', reversal_reason = p_reason where id = p_collection_id and company_id = me.company_id and status = 'recorded';
  if not found then perform core.fn_raise('E_NOT_FOUND', 'recorded collection'); end if;
  return jsonb_build_object('collection_id', p_collection_id, 'status', 'rejected');
end $$;

-- Reversal (F139): dispute / bounced payment; posted entries are reversed, never deleted.
create function api.v1_collection_reverse(p_collection_id uuid, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; c sales.collection%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('finance.ar.receive', iam.fn_my_company_resource(), true);
  select * into c from sales.collection where id = p_collection_id and company_id = me.company_id for update;
  if not found or c.status <> 'verified' then perform core.fn_raise('E_NOT_FOUND', 'verified collection'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update sales.collection set status = 'reversed', reversed_by = me.person_id, reversal_reason = p_reason where id = c.id;
  perform sales.fn_post_ledger(c.company_id, c.dealer_id, 'debit_note', c.amount, current_date, current_date, 'sales.collection_reversal', c.id, 'reversal: ' || p_reason);
  perform finance.fn_emit(c.company_id, 'collection_rev:' || c.id, 'কালেকশন রিভার্সাল ' || c.number, jsonb_build_array(
    jsonb_build_object('key', 'sales.ar', 'dr', c.amount), jsonb_build_object('key', case when c.method = 'cash' then 'fin.cash' else 'fin.bank' end, 'cr', c.amount)));
  return jsonb_build_object('collection_id', c.id, 'status', 'reversed', 'balance', sales.fn_dealer_balance(c.dealer_id));
end $$;

-- Provider confirmation (bKash / Nagad gateway webhook via Edge Function, service role only). Idempotent per trx id.
create function svc.v1_provider_confirm(p_company uuid, p_provider text, p_trx_id text, p_amount numeric, p_msisdn text, p_status text) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform set_config('mohona.company_scope', '', true);
  insert into sales.provider_txn (company_id, provider, trx_id, amount, msisdn, status) values (p_company, p_provider, p_trx_id, p_amount, core.fn_phone_canonical(p_msisdn), p_status)
  on conflict (provider, trx_id) do nothing;
  return jsonb_build_object('provider', p_provider, 'trx_id', p_trx_id, 'stored', true);
end $$;

-- Receipt QR lookup (F136): the signature covers the receipt number; amount and status always come from the server.
create function api.v1_receipt_qr_lookup(p_payload text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); c sales.collection%rowtype; v_code text;
begin
  select * into me from iam.fn_context(false);
  select x.code into v_code from core.company x where x.id = me.company_id;
  if cardinality(parts) <> 5 or parts[1] <> 'MOS1' or parts[2] <> 'R' or parts[3] is distinct from v_code
     or sales.fn_signed(me.company_id, 'MOS1|R|' || v_code || '|' || parts[4]) <> p_payload then
    perform core.fn_raise('E_QR_INVALID');
  end if;
  select * into c from sales.collection where company_id = me.company_id and number = parts[4];
  if not found then perform core.fn_raise('E_QR_INVALID'); end if;
  return jsonb_build_object('number', c.number, 'dealer', (select d.name_bn from sales.dealer d where d.id = c.dealer_id), 'amount', c.amount, 'method', c.method,
                            'status', c.status, 'collected_at', c.collected_at, 'verified', c.status = 'verified');
end $$;

-- Payment QR (F137): only for a provider the Chairman enabled after an authorised integration exists.
create function api.v1_payment_qr(p_dealer_id uuid, p_amount numeric, p_provider text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('sales.collection.record', sales.fn_dealer_resource(d), false);
  if not (coalesce(p_provider, '') = any (config.fn_get_text_array(me.company_id, 'sales.payment_qr.providers'))) then
    perform core.fn_raise('E_FEATURE_DISABLED', 'no authorised ' || coalesce(p_provider, '?') || ' integration');
  end if;
  if coalesce(p_amount, 0) <= 0 then perform core.fn_raise('E_INVALID_ACTION', 'amount'); end if;
  return jsonb_build_object('provider', p_provider, 'payload', sales.fn_signed(me.company_id, 'MOS1|PAY|' || p_provider || '|' || d.code || '|' || round(p_amount, 2)),
                            'note_bn', 'প্রদানকারীর নিশ্চয়তা আসার আগে বকেয়া কমে না।');
end $$;

-- Due reconciliation (F140): invoices with open amounts and the ledger balance; any difference is shown, never hidden.
create function api.v1_dealer_reconcile(p_dealer_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d sales.dealer%rowtype; v_open numeric;
begin
  select * into d from sales.dealer where id = p_dealer_id and company_id = iam.fn_context_company();
  if not found then perform core.fn_raise('E_NOT_FOUND', 'dealer'); end if;
  select * into me from iam.fn_require('crm.dealer.read', sales.fn_dealer_resource(d), false);
  select coalesce(sum(sales.fn_invoice_open(i.id)), 0) into v_open from sales.invoice i where i.dealer_id = d.id;
  return jsonb_build_object('dealer_id', d.id, 'ledger_balance', sales.fn_dealer_balance(d.id), 'open_invoices', v_open,
    'unallocated', sales.fn_dealer_balance(d.id) - v_open,
    'invoices', coalesce((select jsonb_agg(jsonb_build_object('invoice_id', i.id, 'number', i.number, 'total', i.total, 'open', sales.fn_invoice_open(i.id), 'due_date', i.due_date)
                                  order by i.invoice_date) from sales.invoice i where i.dealer_id = d.id), '[]'::jsonb),
    'pending_collections', coalesce((select jsonb_agg(jsonb_build_object('number', c.number, 'amount', c.amount, 'method', c.method)) from sales.collection c
                                      where c.dealer_id = d.id and c.status = 'recorded'), '[]'::jsonb));
end $$;

-- ================================================================ API: reports (F150)
create function api.v1_sales_weekly(p_from date, p_to date) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; f date := date_trunc('week', coalesce(p_from, current_date - 28))::date; t date := coalesce(p_to, current_date);
begin
  select * into me from iam.fn_require('sales.weekly_summary.read', iam.fn_resource(iam.fn_context_company(), null, null, null, null, null, iam.fn_current_person()), false);
  if (t - f) / 7 + 1 > config.fn_get_int(me.company_id, 'sales.report.weekly_max_weeks') then
    perform core.fn_raise('E_REPORT_RANGE', 'too many weeks in one request');           -- no stitching weeks into months
  end if;
  insert into sales.report_log (company_id, person_id, report, params) values (me.company_id, me.person_id, 'weekly', jsonb_build_object('from', f, 'to', t));
  return coalesce((select jsonb_agg(x order by x ->> 'week', x ->> 'dealer') from (
    select jsonb_build_object('week', date_trunc('week', i.invoice_date)::date, 'dealer', d.code, 'territory', tr.code, 'amount', sum(i.total)) x
      from sales.invoice i join sales.dealer d on d.id = i.dealer_id join sales.territory tr on tr.id = d.territory_id
     where i.company_id = me.company_id and i.invoice_date between f and t
       and (select a.allowed from iam.fn_authorize('sales.weekly_summary.read', sales.fn_dealer_resource(d), false) a)
     group by date_trunc('week', i.invoice_date), d.code, tr.code) q), '[]'::jsonb);
end $$;

create function api.v1_sales_monthly(p_year integer) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('sales.monthly_summary.read', iam.fn_my_company_resource(), false);
  insert into sales.report_log (company_id, person_id, report, params) values (me.company_id, me.person_id, 'monthly', jsonb_build_object('year', p_year));
  return coalesce((select jsonb_agg(jsonb_build_object('month', m, 'territory', tc, 'amount', a) order by m, tc) from (
    select date_trunc('month', i.invoice_date)::date m, tr.code tc, sum(i.total) a from sales.invoice i join sales.dealer d on d.id = i.dealer_id
      join sales.territory tr on tr.id = d.territory_id where i.company_id = me.company_id and extract(year from i.invoice_date) = coalesce(p_year, extract(year from current_date))
     group by 1, 2) q), '[]'::jsonb);
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_quotation_create(uuid, jsonb)', 'api.v1_order_create(uuid, uuid, uuid, jsonb, uuid)', 'api.v1_order_cancel(uuid, text)',
      'api.v1_dispatch_post(uuid, text, text)', 'api.v1_delivery_confirm(uuid, text, text)', 'api.v1_invoice_post(uuid)', 'api.v1_sales_return(uuid, uuid, jsonb, text)',
      'api.v1_collection_record(uuid, text, numeric, text, text, jsonb)', 'api.v1_collection_verify(uuid, uuid, uuid)', 'api.v1_collection_reject(uuid, text)',
      'api.v1_collection_reverse(uuid, text)', 'api.v1_receipt_qr_lookup(text)', 'api.v1_payment_qr(uuid, numeric, text)', 'api.v1_dealer_reconcile(uuid)',
      'api.v1_sales_weekly(date, date)', 'api.v1_sales_monthly(integer)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function svc.v1_provider_confirm(uuid, text, text, numeric, text, text) to service_role';
  end if;
end $$;

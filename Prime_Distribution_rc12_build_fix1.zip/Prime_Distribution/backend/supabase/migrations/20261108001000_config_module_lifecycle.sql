-- 20261108001000_config_module_lifecycle.sql  (S11)
-- Module lifecycle & feature flags (blueprint MODULE_LIFECYCLE, MOS-F153-281..290):
-- platform module catalog with declared dependencies and releases; per-company module state
-- (disabled -> enabled <-> suspended -> retired -> reactivate), optional wing scope, versions with compatibility-checked
-- upgrade and data-safe rollback, append-only lifecycle history; versioned company/wing feature flags.
-- SERVER ENFORCEMENT: iam.fn_authorize now gates every permission by its module state
-- (disabled = no access; suspended/retired = read & export only; wing-scoped = only listed wings). Core modules and
-- core-security flags cannot be switched off. Every action is a Chairman option (permission config.module.manage /
-- config.feature.toggle). STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ---------------------------------------------------------------- platform vocabulary
create table config.module_catalog (
  code               text primary key check (code ~ '^[a-z][a-z0-9_]{1,39}$'),
  name_bn            text not null,
  description_bn     text,
  is_core            boolean not null default false,
  permission_modules text[] not null default '{}',
  wing_scopable      boolean not null default true,
  status             text not null default 'registered' check (status in ('registered','available','withdrawn')),
  sort_order         integer not null default 0
);
create trigger trg_module_catalog_nodel before delete on config.module_catalog for each row execute function core.fn_deny_delete();

create table config.module_dependency (
  module_code text not null references config.module_catalog(code),
  depends_on  text not null references config.module_catalog(code),
  kind        text not null default 'hard' check (kind in ('hard','soft')),
  primary key (module_code, depends_on),
  check (module_code <> depends_on)
);

-- No cycles among hard dependencies.
create function config.fn_module_dependency_no_cycle() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.kind = 'hard' and exists (
       with recursive up(code) as (
         select d.depends_on from config.module_dependency d where d.module_code = new.depends_on and d.kind = 'hard'
         union
         select d.depends_on from config.module_dependency d join up on d.module_code = up.code where d.kind = 'hard')
       select 1 from up where code = new.module_code) then
    raise exception 'E_MODULE_CYCLE: % -> % would create a cyclic hard dependency', new.module_code, new.depends_on using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_module_dependency_cycle before insert or update on config.module_dependency for each row execute function config.fn_module_dependency_no_cycle();

create table config.module_release (
  module_code           text not null references config.module_catalog(code),
  version               text not null check (version ~ '^[0-9]+\.[0-9]+\.[0-9]+$'),
  compatible_from       text not null check (compatible_from ~ '^[0-9]+\.[0-9]+\.[0-9]+$'),
  data_schema_version   integer not null check (data_schema_version >= 1),
  rollback_safe         boolean not null default true,
  released_at           timestamptz not null default clock_timestamp(),
  notes_bn              text,
  primary key (module_code, version)
);
create trigger trg_module_release_no_mutation before update or delete on config.module_release for each row execute function core.fn_deny_mutation();

create function config.fn_semver(p text) returns integer[]
language sql immutable set search_path = pg_catalog as $$
  select array[split_part(p, '.', 1)::integer, split_part(p, '.', 2)::integer, split_part(p, '.', 3)::integer]
$$;

create table config.feature_flag_definition (
  key              text primary key check (key ~ '^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$'),
  module_code      text not null references config.module_catalog(code),
  name_bn          text not null,
  description_bn   text,
  default_enabled  boolean not null,
  is_security_core boolean not null default false,
  status           text not null default 'active' check (status in ('active','retired')),
  sort_order       integer not null default 0,
  check (not is_security_core or default_enabled)
);
create trigger trg_flag_definition_nodel before delete on config.feature_flag_definition for each row execute function core.fn_deny_delete();

-- ---------------------------------------------------------------- per company
create table config.company_module (
  company_id   uuid not null references core.company(id),
  module_code  text not null references config.module_catalog(code),
  status       text not null check (status in ('disabled','enabled','suspended','retired')),
  version      text check (version ~ '^[0-9]+\.[0-9]+\.[0-9]+$'),
  wing_ids     uuid[],                               -- null = whole company
  changed_at   timestamptz not null default clock_timestamp(),
  changed_by   uuid,
  id           uuid not null default gen_random_uuid() unique,
  created_at   timestamptz not null default clock_timestamp(),
  updated_at   timestamptz not null default clock_timestamp(),
  row_version  integer not null default 1,
  primary key (company_id, module_code),
  check (wing_ids is null or cardinality(wing_ids) > 0)
);
create trigger trg_company_module_touch before update on config.company_module for each row execute function core.fn_touch_row();
create trigger trg_company_module_nodel before delete on config.company_module for each row execute function core.fn_deny_delete();
create trigger trg_company_module_audit after insert or update on config.company_module for each row execute function audit.fn_row_change();

-- Immutable lifecycle history (enable / suspend / resume / retire / reactivate / upgrade / rollback / scope).
create table config.company_module_event (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references core.company(id),
  module_code   text not null references config.module_catalog(code),
  action        text not null check (action in ('seed','enable','suspend','resume','retire','reactivate','upgrade','rollback','scope')),
  from_status   text,
  to_status     text,
  from_version  text,
  to_version    text,
  wing_ids      uuid[],
  reason        text not null check (length(btrim(reason)) > 0),
  actor         uuid,
  at            timestamptz not null default clock_timestamp()
);
create index company_module_event_lookup on config.company_module_event (company_id, module_code, at desc);
create trigger trg_company_module_event_no_mutation before update or delete on config.company_module_event for each row execute function core.fn_deny_mutation();
create trigger trg_company_module_event_audit after insert on config.company_module_event for each row execute function audit.fn_row_change();

create table config.company_feature_flag (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  flag_key    text not null references config.feature_flag_definition(key),
  wing_id     uuid,
  enabled     boolean not null,
  version     integer not null check (version >= 1),
  status      text not null default 'active' check (status in ('active','superseded')),
  set_by      uuid,
  set_at      timestamptz not null default clock_timestamp(),
  reason      text not null check (length(btrim(reason)) > 0),
  foreign key (wing_id, company_id) references core.wing (id, company_id)
);
create unique index company_flag_one_active on config.company_feature_flag (company_id, flag_key, wing_id) nulls not distinct where status = 'active';
create function config.fn_flag_value_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - 'status') <> (to_jsonb(new) - 'status') or old.status <> 'active' or new.status <> 'superseded' then
    raise exception 'E_IMMUTABLE: flag history is append-only' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_company_flag_guard before update on config.company_feature_flag for each row execute function config.fn_flag_value_guard();
create trigger trg_company_flag_nodel before delete on config.company_feature_flag for each row execute function core.fn_deny_delete();
create trigger trg_company_flag_audit after insert or update on config.company_feature_flag for each row execute function audit.fn_row_change();

select core.fn_apply_rls('config', 'module_catalog');
select core.fn_apply_rls('config', 'module_dependency');
select core.fn_apply_rls('config', 'module_release');
select core.fn_apply_rls('config', 'feature_flag_definition');
select core.fn_apply_rls('config', 'company_module');
select core.fn_apply_rls('config', 'company_module_event');
select core.fn_apply_rls('config', 'company_feature_flag');

-- ---------------------------------------------------------------- seeds (blueprint 30 domains -> modules)
insert into config.module_catalog (code, name_bn, is_core, permission_modules, wing_scopable, status, sort_order) values
  ('core',        'মূল কাঠামো',              true,  array['core'],        false, 'available', 10),
  ('iam',         'পরিচয় ও অনুমতি',          true,  array['iam'],         false, 'available', 20),
  ('config',      'সেটিং ও মডিউল',           true,  array['config'],      false, 'available', 30),
  ('audit',       'অডিট',                    true,  array['audit'],       false, 'available', 40),
  ('technical',   'প্রযুক্তিগত',              true,  array['technical'],   false, 'available', 50),
  ('approval',    'অনুমোদন-ইঞ্জিন',          false, array['approval'],    false, 'registered', 60),
  ('rules',       'Rule Studio',             false, array[]::text[],      false, 'registered', 70),
  ('forms',       'ডায়নামিক ফর্ম',            false, array[]::text[],      true,  'registered', 80),
  ('design',      'ডিজাইন-স্টুডিও',          false, array['design'],      false, 'registered', 90),
  ('kpi',         'KPI-ড্যাশবোর্ড',            false, array[]::text[],      true,  'registered', 100),
  ('recycle',     'রিসাইকেল-বিন',            false, array[]::text[],      false, 'registered', 110),
  ('notify',      'নোটিফিকেশন',              false, array['notify'],      false, 'registered', 120),
  ('master',      'মাস্টার-ডেটা',             false, array['master'],      true,  'registered', 130),
  ('procurement', 'ক্রয় ও দেনা',             false, array['procurement'], true,  'registered', 140),
  ('inventory',   'ইনভেন্টরি',               false, array['inventory'],   true,  'registered', 150),
  ('mfg',         'উৎপাদন',                  false, array['mfg'],         true,  'registered', 160),
  ('finance',     'ফাইন্যান্স',               false, array['finance'],     false, 'registered', 170),
  ('crm',         'ডিলার-CRM',               false, array['crm'],         true,  'registered', 180),
  ('sales',       'বিক্রয় ও কালেকশন',        false, array['sales'],       true,  'registered', 190),
  ('route',       'রুট ও মাঠ',               false, array[]::text[],      true,  'registered', 200),
  ('hr',          'HR ও বেতন',               false, array['hr'],          true,  'registered', 210),
  ('qr',          'ইউনিভার্সাল QR',           false, array['qr'],          true,  'registered', 220),
  ('report',      'রিপোর্ট ও প্রিন্ট',         false, array['reports'],     true,  'registered', 230),
  ('location',    'ম্যাপ ও লোকেশন',           false, array['location'],    true,  'registered', 240),
  ('hardware',    'হার্ডওয়্যার-ডিভাইস',        false, array['device'],      true,  'registered', 250),
  ('backup',      'ব্যাকআপ-পুনরুদ্ধার',        false, array[]::text[],      false, 'registered', 260);

insert into config.module_dependency (module_code, depends_on, kind) values
  ('rules','config','hard'), ('forms','config','hard'), ('design','config','hard'), ('kpi','design','hard'), ('recycle','config','hard'),
  ('approval','config','hard'), ('notify','core','hard'), ('master','core','hard'),
  ('inventory','master','hard'), ('procurement','inventory','hard'), ('procurement','approval','soft'),
  ('mfg','inventory','hard'), ('finance','core','hard'), ('mfg','finance','soft'), ('procurement','finance','soft'),
  ('crm','master','hard'), ('sales','inventory','hard'), ('sales','crm','soft'), ('sales','finance','soft'),
  ('route','crm','hard'), ('route','location','soft'), ('hr','core','hard'), ('qr','core','hard'), ('report','core','hard'),
  ('location','core','hard'), ('hardware','core','hard'), ('backup','core','hard');

insert into config.module_release (module_code, version, compatible_from, data_schema_version, notes_bn)
select code, '1.0.0', '1.0.0', 1, 'প্রথম সংস্করণ' from config.module_catalog;

insert into config.feature_flag_definition (key, module_code, name_bn, default_enabled, is_security_core, sort_order) values
  ('iam.audit_trail',             'iam',        'অডিট-ট্রেইল',                        true,  true,  10),
  ('iam.mfa_enforcement',         'iam',        'MFA-প্রয়োগ',                         true,  true,  20),
  ('iam.row_level_security',      'iam',        'কোম্পানি-বিচ্ছিন্নতা (RLS)',            true,  true,  30),
  ('design.ad_slots',             'design',     'ড্যাশবোর্ডে বিজ্ঞাপন-স্লট',              false, false, 40),
  ('kpi.product_images',          'kpi',        'KPI-তে পণ্যের ছবি',                     true,  false, 50),
  ('inventory.fefo_picking',      'inventory',  'FEFO-পিকিং',                           true,  false, 60),
  ('sales.credit_limit_check',    'sales',      'ক্রেডিট-সীমা যাচাই',                   true,  false, 70),
  ('sales.collection_bkash',      'sales',      'bKash কালেকশন',                        false, false, 80),
  ('sales.collection_nagad',      'sales',      'Nagad কালেকশন',                        false, false, 90),
  ('report.whatsapp_share',       'report',     'WhatsApp-ছবি শেয়ার',                   true,  false, 100),
  ('hr.gate_qr_attendance',       'hr',         'গেট-QR উপস্থিতি',                      true,  false, 110),
  ('hr.pin_attendance_backup',    'hr',         'PIN-বিকল্প উপস্থিতি',                  true,  false, 120),
  ('location.live_tracking',      'location',   'লাইভ-লোকেশন',                          false, false, 130),
  ('recycle.bulk_restore',        'recycle',    'একসাথে পুনরুদ্ধার',                    true,  false, 140),
  ('forms.offline_drafts',        'forms',      'অফলাইন-খসড়া',                         true,  false, 150);

insert into config.setting_definition (key, module, value_type, default_value, name_bn, description_bn, is_sensitive, sort_order) values
  ('module.new_available.auto_enable', 'module', 'bool', 'true', 'নতুন মডিউল তৈরি হলে স্বয়ংক্রিয় চালু', 'MODULE_LIFECYCLE', false, 300),
  ('module.suspend.cascade_default',   'module', 'bool', 'false', 'স্থগিত করলে নির্ভরশীল মডিউলও স্থগিত', 'MODULE_LIFECYCLE', false, 310);

-- Company rows: core modules enabled; available modules enabled when auto_enable; others disabled until built.
create function config.fn_seed_company_modules(p_company uuid) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare n integer;
begin
  insert into config.company_module (company_id, module_code, status, version)
  select p_company, m.code,
         case when m.is_core then 'enabled'
              when m.status = 'available' and config.fn_get_bool(p_company, 'module.new_available.auto_enable') then 'enabled'
              else 'disabled' end,
         (select r.version from config.module_release r where r.module_code = m.code order by config.fn_semver(r.version) desc limit 1)
    from config.module_catalog m
  on conflict (company_id, module_code) do nothing;
  get diagnostics n = row_count;
  insert into config.company_module_event (company_id, module_code, action, to_status, to_version, reason)
  select cm.company_id, cm.module_code, 'seed', cm.status, cm.version, 'company provisioning'
    from config.company_module cm
   where cm.company_id = p_company and not exists (select 1 from config.company_module_event e where e.company_id = cm.company_id and e.module_code = cm.module_code);
  return n;
end $$;

-- Called by the step that builds a module: makes it available and enables it where the company never chose otherwise.
create function config.fn_make_module_available(p_module text) returns integer
language plpgsql security definer set search_path = pg_catalog as $$
declare n integer := 0; c record;
begin
  update config.module_catalog set status = 'available' where code = p_module;
  for c in select cm.company_id from config.company_module cm
            where cm.module_code = p_module and cm.status = 'disabled'
              and not exists (select 1 from config.company_module_event e where e.company_id = cm.company_id and e.module_code = p_module and e.action <> 'seed')
              and config.fn_get_bool(cm.company_id, 'module.new_available.auto_enable')
  loop
    update config.company_module set status = 'enabled', changed_at = clock_timestamp() where company_id = c.company_id and module_code = p_module;
    insert into config.company_module_event (company_id, module_code, action, from_status, to_status, reason)
    values (c.company_id, p_module, 'enable', 'disabled', 'enabled', 'module became available');
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function iam.fn_company_seed_positions() returns trigger
language plpgsql security definer set search_path = pg_catalog as $$
begin
  perform iam.fn_seed_company_positions(new.id);
  perform iam.fn_backfill_template_rules(new.id);
  perform config.fn_seed_company_modules(new.id);
  return null;
end $$;

do $$ declare c record; begin for c in select id from core.company loop perform config.fn_seed_company_modules(c.id); end loop; end $$;

-- ---------------------------------------------------------------- read helpers
-- Effective flag: wing-specific active value > company-wide active value > definition default.
create function config.fn_flag(p_company uuid, p_key text, p_wing uuid default null) returns boolean
language plpgsql stable security definer set search_path = pg_catalog as $$
declare v boolean; d config.feature_flag_definition%rowtype;
begin
  select * into d from config.feature_flag_definition where key = p_key and status = 'active';
  if not found then raise exception 'E_FLAG_UNKNOWN: %', p_key using errcode = 'P0001'; end if;
  if d.is_security_core then return true; end if;
  if p_wing is not null then
    select f.enabled into v from config.company_feature_flag f where f.company_id = p_company and f.flag_key = p_key and f.wing_id = p_wing and f.status = 'active';
    if v is not null then return v; end if;
  end if;
  select f.enabled into v from config.company_feature_flag f where f.company_id = p_company and f.flag_key = p_key and f.wing_id is null and f.status = 'active';
  return coalesce(v, d.default_enabled);
end $$;

-- Module gate for a permission module: 'ok' | 'disabled' | 'read_only' | 'not_in_wing'.
create function config.fn_module_gate(p_company uuid, p_permission_module text, p_action_kind text, p_wing uuid) returns text
language plpgsql stable security definer set search_path = pg_catalog as $$
declare m record;
begin
  select mc.code, mc.is_core, cm.status, cm.wing_ids into m
    from config.module_catalog mc left join config.company_module cm on cm.module_code = mc.code and cm.company_id = p_company
   where p_permission_module = any (mc.permission_modules)
   order by mc.is_core desc limit 1;
  if not found or m.is_core then return 'ok'; end if;
  if m.status is null or m.status = 'disabled' then return 'disabled'; end if;
  if m.status in ('suspended','retired') and p_action_kind not in ('read','export') then return 'read_only'; end if;
  if m.wing_ids is not null and p_wing is not null and not (p_wing = any (m.wing_ids)) then return 'not_in_wing'; end if;
  return 'ok';
end $$;

-- ---------------------------------------------------------------- authorization: module gate added
create or replace function iam.fn_authorize(p_permission text, p_resource iam.resource, p_lock boolean default false)
returns table (allowed boolean, reason text, rule_id uuid, person_id uuid, company_id uuid, assignment_id uuid,
               position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare c record; p iam.permission_catalog%rowtype; r iam.resource := p_resource; v_dw uuid; v_lw uuid; d record; v_gate text;
begin
  select * into c from iam.fn_context(p_lock);
  select * into p from iam.permission_catalog pc where pc.code = p_permission;
  if not found then
    return query select false, 'unknown_permission', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if p.status <> 'active' then
    return query select false, 'permission_not_active', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.company_id is null or r.company_id <> c.company_id then
    return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.wing_id is not null and not exists (select 1 from core.wing w where w.id = r.wing_id and w.company_id = r.company_id) then
    return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if r.department_id is not null then
    select dd.wing_id into v_dw from core.department dd where dd.id = r.department_id and dd.company_id = r.company_id;
    if v_dw is null or (r.wing_id is not null and r.wing_id <> v_dw) then
      return query select false, 'inconsistent_resource', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
    end if;
    r.wing_id := v_dw;
  end if;
  if r.location_id is not null then
    if not exists (select 1 from core.location l where l.id = r.location_id and l.company_id = r.company_id) then
      return query select false, 'wrong_company', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
    end if;
    select l.wing_id into v_lw from core.location l where l.id = r.location_id;
    if v_lw is not null then
      if r.wing_id is not null and r.wing_id <> v_lw then
        return query select false, 'inconsistent_resource', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
      end if;
      r.wing_id := v_lw;
    end if;
  end if;
  -- module lifecycle gate (S11): disabled / read-only (suspended, retired) / wing-scoped
  v_gate := config.fn_module_gate(c.company_id, p.module, p.action_kind, r.wing_id);
  if v_gate <> 'ok' then
    return query select false, 'module_' || v_gate, null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  if p.requires_aal2 and core.fn_jwt_claim('aal') is distinct from 'aal2' then
    return query select false, 'mfa_required', null::uuid, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme; return;
  end if;
  select * into d from iam.fn_decide(c.company_id, c.assignment_id, c.position_code, c.is_supreme, c.person_id,
                                     c.home_wing_id, c.home_department_id, c.home_location_id, p_permission, r, true);
  return query select d.allowed, d.reason, d.rule_id, c.person_id, c.company_id, c.assignment_id, c.position_code, c.is_supreme;
end $$;

create or replace function iam.fn_require(p_permission text, p_resource iam.resource, p_lock boolean default true)
returns table (person_id uuid, company_id uuid, assignment_id uuid, position_code text, is_supreme boolean)
language plpgsql volatile security definer set search_path = pg_catalog as $$
#variable_conflict use_column
declare d record;
begin
  select * into d from iam.fn_authorize(p_permission, p_resource, p_lock);
  if not d.allowed then
    raise log 'MOHONA_SECURITY_DENIED person=% company=% assignment=% position=% permission=% reason=% resource_company=% request=%',
      d.person_id, d.company_id, d.assignment_id, d.position_code, p_permission, d.reason, (p_resource).company_id, core.fn_request_id();
    perform core.fn_raise(case d.reason
                            when 'wrong_company' then 'E_WRONG_COMPANY'
                            when 'mfa_required' then 'E_MFA_REQUIRED'
                            when 'permission_not_active' then 'E_FEATURE_NOT_READY'
                            when 'module_disabled' then 'E_FEATURE_DISABLED'
                            when 'module_read_only' then 'E_MODULE_READ_ONLY'
                            else 'E_FORBIDDEN' end, p_permission);
  end if;
  return query select d.person_id, d.company_id, d.assignment_id, d.position_code, d.is_supreme;
end $$;

-- ---------------------------------------------------------------- permissions
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('config.module.manage', 'config', 'মডিউল চালু/স্থগিত/অবসর/আপগ্রেড/রোলব্যাক', 'admin', true, false, array['COMPANY'], 'active', 195);
update iam.permission_catalog set status = 'active' where code = 'config.feature.toggle';

-- ---------------------------------------------------------------- API
create function api.v1_config_modules() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((
    select jsonb_agg(jsonb_build_object(
             'code', m.code, 'name_bn', m.name_bn, 'is_core', m.is_core, 'built', m.status = 'available', 'wing_scopable', m.wing_scopable,
             'status', cm.status, 'version', cm.version, 'wing_ids', to_jsonb(cm.wing_ids), 'row_version', cm.row_version,
             'depends_on', coalesce((select jsonb_agg(jsonb_build_object('module', d.depends_on, 'kind', d.kind)) from config.module_dependency d where d.module_code = m.code), '[]'::jsonb),
             'releases', coalesce((select jsonb_agg(jsonb_build_object('version', r.version, 'compatible_from', r.compatible_from,
                                     'data_schema_version', r.data_schema_version, 'rollback_safe', r.rollback_safe) order by r.released_at)
                                     from config.module_release r where r.module_code = m.code), '[]'::jsonb))
           order by m.sort_order)
      from config.module_catalog m left join config.company_module cm on cm.module_code = m.code and cm.company_id = me.company_id
     where m.status <> 'withdrawn'), '[]'::jsonb);
end $$;

-- Launcher: modules the caller can open (server re-checks every action). Read-only mode is reported.
create function api.v1_config_my_modules() returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare c record;
begin
  select * into c from iam.fn_context(false);
  return coalesce((
    select jsonb_agg(jsonb_build_object('code', m.code, 'name_bn', m.name_bn, 'mode', case when cm.status = 'enabled' then 'full' else 'read_only' end,
                                        'wing_ids', to_jsonb(cm.wing_ids)) order by m.sort_order)
      from config.module_catalog m join config.company_module cm on cm.module_code = m.code and cm.company_id = c.company_id
     where m.status = 'available' and cm.status in ('enabled','suspended','retired')
       and (c.is_supreme or m.is_core or exists (
             select 1 from iam.permission_catalog pc where pc.module = any (m.permission_modules) and pc.status = 'active'
                and (exists (select 1 from iam.position_permission_rule pr where pr.company_id = c.company_id and pr.position_code = c.position_code
                               and pr.permission_code = pc.code and pr.status = 'active' and pr.effect = 'allow')
                     or exists (select 1 from iam.assignment_permission_rule ar where ar.assignment_id = c.assignment_id
                               and ar.permission_code = pc.code and ar.status = 'active' and ar.effect = 'allow'
                               and (ar.valid_until is null or ar.valid_until > clock_timestamp())))))), '[]'::jsonb);
end $$;

create function config.fn_module_transition(p_company uuid, p_module text, p_action text, p_reason text, p_actor uuid, p_cascade boolean)
returns void language plpgsql security definer set search_path = pg_catalog as $$
declare m config.module_catalog%rowtype; cm config.company_module%rowtype; v_to text; v_missing text; v_dep record;
begin
  select * into m from config.module_catalog where code = p_module;
  if not found then raise exception 'E_NOT_FOUND: module %', p_module using errcode = 'P0001'; end if;
  if m.is_core then raise exception 'E_CORE_PROTECTED: core module % is always on', p_module using errcode = 'P0001'; end if;
  select * into cm from config.company_module where company_id = p_company and module_code = p_module for update;
  v_to := case p_action
            when 'enable' then case when cm.status = 'disabled' then 'enabled' end
            when 'suspend' then case when cm.status = 'enabled' then 'suspended' end
            when 'resume' then case when cm.status = 'suspended' then 'enabled' end
            when 'retire' then case when cm.status = 'suspended' then 'retired' end
            when 'reactivate' then case when cm.status = 'retired' then 'enabled' end end;
  if v_to is null then
    raise exception 'E_INVALID_ACTION: % is not possible from %', p_action, coalesce(cm.status, 'none') using errcode = 'P0001';
  end if;
  if v_to = 'enabled' then
    if m.status <> 'available' then raise exception 'E_MODULE_NOT_AVAILABLE: % is not built yet', p_module using errcode = 'P0001'; end if;
    select string_agg(d.depends_on, ', ') into v_missing
      from config.module_dependency d left join config.company_module x on x.company_id = p_company and x.module_code = d.depends_on
      join config.module_catalog dm on dm.code = d.depends_on
     where d.module_code = p_module and d.kind = 'hard' and not dm.is_core and coalesce(x.status, 'disabled') <> 'enabled';
    if v_missing is not null then raise exception 'E_MODULE_DEPENDENCY: enable first: %', v_missing using errcode = 'P0001'; end if;
  else
    for v_dep in select d.module_code from config.module_dependency d join config.company_module x on x.company_id = p_company and x.module_code = d.module_code
                  where d.depends_on = p_module and d.kind = 'hard' and x.status = 'enabled' loop
      if p_cascade and p_action = 'suspend' then
        perform config.fn_module_transition(p_company, v_dep.module_code, 'suspend', 'cascade from ' || p_module || ': ' || p_reason, p_actor, true);
      else
        raise exception 'E_MODULE_DEPENDENTS: % depends on %', v_dep.module_code, p_module using errcode = 'P0001';
      end if;
    end loop;
  end if;
  update config.company_module set status = v_to, changed_at = clock_timestamp(), changed_by = p_actor where company_id = p_company and module_code = p_module;
  insert into config.company_module_event (company_id, module_code, action, from_status, to_status, from_version, to_version, reason, actor)
  values (p_company, p_module, p_action, cm.status, v_to, cm.version, cm.version, p_reason, p_actor);
end $$;

create function api.v1_config_module_action(p_module text, p_action text, p_expected_row_version integer, p_reason text, p_cascade boolean default null)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; v integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_action not in ('enable','suspend','resume','retire','reactivate') then perform core.fn_raise('E_INVALID_ACTION', p_action); end if;
  select * into me from iam.fn_require('config.module.manage', iam.fn_my_company_resource(), true);
  if p_action = 'reactivate' and not me.is_supreme then perform core.fn_raise('E_FORBIDDEN', 'only the Chairman reactivates a retired module'); end if;
  select row_version into v from config.company_module where company_id = me.company_id and module_code = p_module;
  if v is null then perform core.fn_raise('E_NOT_FOUND', p_module); end if;
  if v <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform config.fn_module_transition(me.company_id, p_module, p_action, p_reason, me.person_id,
                                      coalesce(p_cascade, config.fn_get_bool(me.company_id, 'module.suspend.cascade_default')));
  return (select row_version from config.company_module where company_id = me.company_id and module_code = p_module);
end $$;

create function api.v1_config_module_set_wings(p_module text, p_wing_ids uuid[], p_expected_row_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; cm config.company_module%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.module.manage', iam.fn_my_company_resource(), true);
  select * into cm from config.company_module where company_id = me.company_id and module_code = p_module for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', p_module); end if;
  if cm.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  if not (select wing_scopable from config.module_catalog where code = p_module) and p_wing_ids is not null then
    perform core.fn_raise('E_INVALID_ACTION', 'module is company-wide only');
  end if;
  if p_wing_ids is not null and (cardinality(p_wing_ids) = 0 or exists (select 1 from unnest(p_wing_ids) w
       where not exists (select 1 from core.wing x where x.id = w and x.company_id = me.company_id))) then
    perform core.fn_raise('E_WRONG_COMPANY', 'wing list');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update config.company_module set wing_ids = p_wing_ids, changed_at = clock_timestamp(), changed_by = me.person_id
   where company_id = me.company_id and module_code = p_module;
  insert into config.company_module_event (company_id, module_code, action, from_status, to_status, wing_ids, reason, actor)
  values (me.company_id, p_module, 'scope', cm.status, cm.status, p_wing_ids, p_reason, me.person_id);
  return cm.row_version + 1;
end $$;

-- Upgrade: target newer than installed and compatible_from <= installed. In-flight documents keep the version they
-- were created with (documents store module_version from S12), so nothing in progress changes meaning.
create function api.v1_config_module_upgrade(p_module text, p_to_version text, p_expected_row_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; cm config.company_module%rowtype; rel config.module_release%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.module.manage', iam.fn_my_company_resource(), true);
  select * into cm from config.company_module where company_id = me.company_id and module_code = p_module for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', p_module); end if;
  if cm.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  select * into rel from config.module_release where module_code = p_module and version = p_to_version;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'release ' || p_to_version); end if;
  if config.fn_semver(p_to_version) <= config.fn_semver(cm.version) then perform core.fn_raise('E_VERSION_INCOMPATIBLE', 'not newer'); end if;
  if config.fn_semver(rel.compatible_from) > config.fn_semver(cm.version) then
    perform core.fn_raise('E_VERSION_INCOMPATIBLE', 'upgrade to ' || rel.compatible_from || ' first');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update config.company_module set version = p_to_version, changed_at = clock_timestamp(), changed_by = me.person_id
   where company_id = me.company_id and module_code = p_module;
  insert into config.company_module_event (company_id, module_code, action, from_status, to_status, from_version, to_version, reason, actor)
  values (me.company_id, p_module, 'upgrade', cm.status, cm.status, cm.version, p_to_version, p_reason, me.person_id);
  return cm.row_version + 1;
end $$;

-- Rollback: only to an older release with the SAME data schema version and marked rollback-safe (no data loss).
create function api.v1_config_module_rollback(p_module text, p_to_version text, p_expected_row_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; cm config.company_module%rowtype; tgt config.module_release%rowtype; cur config.module_release%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.module.manage', iam.fn_my_company_resource(), true);
  select * into cm from config.company_module where company_id = me.company_id and module_code = p_module for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', p_module); end if;
  if cm.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  select * into tgt from config.module_release where module_code = p_module and version = p_to_version;
  select * into cur from config.module_release where module_code = p_module and version = cm.version;
  if tgt.version is null or cur.version is null then perform core.fn_raise('E_NOT_FOUND', 'release'); end if;
  if config.fn_semver(p_to_version) >= config.fn_semver(cm.version) then perform core.fn_raise('E_VERSION_INCOMPATIBLE', 'not older'); end if;
  if not cur.rollback_safe or tgt.data_schema_version <> cur.data_schema_version then
    perform core.fn_raise('E_ROLLBACK_UNSAFE', 'data schema changed between versions');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update config.company_module set version = p_to_version, changed_at = clock_timestamp(), changed_by = me.person_id
   where company_id = me.company_id and module_code = p_module;
  insert into config.company_module_event (company_id, module_code, action, from_status, to_status, from_version, to_version, reason, actor)
  values (me.company_id, p_module, 'rollback', cm.status, cm.status, cm.version, p_to_version, p_reason, me.person_id);
  return cm.row_version + 1;
end $$;

create function api.v1_config_module_history(p_module text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('action', e.action, 'from_status', e.from_status, 'to_status', e.to_status,
                         'from_version', e.from_version, 'to_version', e.to_version, 'wing_ids', to_jsonb(e.wing_ids),
                         'reason', e.reason, 'actor', e.actor, 'at', e.at) order by e.at desc)
                     from config.company_module_event e where e.company_id = me.company_id and e.module_code = p_module), '[]'::jsonb);
end $$;

create function api.v1_config_flags(p_module text default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('config.settings.read', iam.fn_my_company_resource(), false);
  return coalesce((
    select jsonb_agg(jsonb_build_object('key', d.key, 'module', d.module_code, 'name_bn', d.name_bn, 'default_enabled', d.default_enabled,
             'is_security_core', d.is_security_core, 'enabled', config.fn_flag(me.company_id, d.key, null),
             'version', coalesce((select f.version from config.company_feature_flag f where f.company_id = me.company_id and f.flag_key = d.key
                                    and f.wing_id is null and f.status = 'active'), 0),
             'wing_overrides', coalesce((select jsonb_agg(jsonb_build_object('wing_id', f.wing_id, 'enabled', f.enabled, 'version', f.version))
                                           from config.company_feature_flag f where f.company_id = me.company_id and f.flag_key = d.key
                                            and f.wing_id is not null and f.status = 'active'), '[]'::jsonb))
           order by d.sort_order)
      from config.feature_flag_definition d where d.status = 'active' and (p_module is null or d.module_code = p_module)), '[]'::jsonb);
end $$;

create function api.v1_config_set_flag(p_key text, p_wing_id uuid, p_enabled boolean, p_expected_version integer, p_reason text)
returns integer language plpgsql security definer set search_path = '' as $$
declare me record; d config.feature_flag_definition%rowtype; cur config.company_feature_flag%rowtype; v_next integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  if p_enabled is null then perform core.fn_raise('E_SETTING_INVALID', 'enabled required'); end if;
  select * into me from iam.fn_require('config.feature.toggle', iam.fn_my_company_resource(), true);
  select * into d from config.feature_flag_definition where key = p_key and status = 'active';
  if not found then perform core.fn_raise('E_FLAG_UNKNOWN', p_key); end if;
  if d.is_security_core and not p_enabled then perform core.fn_raise('E_CORE_PROTECTED', 'core security cannot be switched off'); end if;
  if p_wing_id is not null and not exists (select 1 from core.wing where id = p_wing_id and company_id = me.company_id) then
    perform core.fn_raise('E_WRONG_COMPANY', 'wing');
  end if;
  select * into cur from config.company_feature_flag
   where company_id = me.company_id and flag_key = p_key and wing_id is not distinct from p_wing_id and status = 'active' for update;
  if coalesce(cur.version, 0) <> coalesce(p_expected_version, -1) then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if cur.id is not null then update config.company_feature_flag set status = 'superseded' where id = cur.id; end if;
  v_next := coalesce((select max(version) from config.company_feature_flag where company_id = me.company_id and flag_key = p_key
                       and wing_id is not distinct from p_wing_id), 0) + 1;
  insert into config.company_feature_flag (company_id, flag_key, wing_id, enabled, version, set_by, reason)
  values (me.company_id, p_key, p_wing_id, p_enabled, v_next, me.person_id, p_reason);
  return v_next;
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_config_modules()', 'api.v1_config_my_modules()', 'api.v1_config_module_action(text, text, integer, text, boolean)',
      'api.v1_config_module_set_wings(text, uuid[], integer, text)', 'api.v1_config_module_upgrade(text, text, integer, text)',
      'api.v1_config_module_rollback(text, text, integer, text)', 'api.v1_config_module_history(text)', 'api.v1_config_flags(text)',
      'api.v1_config_set_flag(text, uuid, boolean, integer, text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

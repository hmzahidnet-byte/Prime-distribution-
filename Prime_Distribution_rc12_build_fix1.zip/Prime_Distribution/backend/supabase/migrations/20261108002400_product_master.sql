-- 20261108002400_product_master.sql  (S24)
-- Product master (blueprint PRODUCT_MASTER MOS-F153-061..070) + POLY specification (ADR-12):
--   061 product: SKU unique per company, name, image, category, base unit
--   062 variants (size / flavour / package / recipe reference); a variant used by a posted BOM or sale is locked
--   063 lifecycle draft -> active <-> suspended -> archived; inventory.fn_product_usable() blocks new transactions
--   064 POLY (ADR-12): versioned sachets-per-POLY and grams-per-sachet (positive), approved by a second person,
--       effective-dated, snapshot for batches; conversions only through a spec — "pcs" is never converted (ambiguous)
--   065 QR payload per product / variant; resolution only inside the caller's company
--   066 effective-dated price lists; started prices are never rewritten (a new row closes the old one)
--   067 product media: images only, size-limited, server-built company paths
--   068 Chairman-defined attribute fields (Dynamic Forms schema language, versioned, validated)
--   069 maker-checker: every change is a draft version, applied only when ANOTHER person approves
--   070 history: immutable versions with field-level diff; BOM / sales references preserved
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

-- ================================================================ reference: units
create table inventory.unit (
  code        text primary key check (code ~ '^[a-z_]{1,12}$'),
  name_bn     text not null,
  dimension   text not null check (dimension in ('count','mass','volume','pack')),
  to_base     numeric(18,6),             -- mass: grams; volume: millilitres; count/pack: null (only via a product spec)
  sort_order  integer not null default 0
);
create trigger trg_unit_nodel before delete on inventory.unit for each row execute function core.fn_deny_delete();
insert into inventory.unit (code, name_bn, dimension, to_base, sort_order) values
  ('g', 'গ্রাম', 'mass', 1, 10), ('kg', 'কেজি', 'mass', 1000, 20), ('ton', 'টন', 'mass', 1000000, 30),
  ('ml', 'মিলি', 'volume', 1, 40), ('ltr', 'লিটার', 'volume', 1000, 50),
  ('sachet', 'স্যাশে', 'pack', null, 60), ('poly', 'পলি', 'pack', null, 70), ('carton', 'কার্টন', 'pack', null, 80),
  ('pcs', 'পিস', 'count', null, 90), ('dozen', 'ডজন', 'count', null, 100);

-- ================================================================ categories, attribute schema
create table inventory.product_category (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn     text not null check (length(btrim(name_bn)) > 0),
  parent_id   uuid,
  status      text not null default 'active' check (status in ('active','inactive')),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (parent_id, company_id) references inventory.product_category (id, company_id)
);
create trigger trg_product_category_guard before update on inventory.product_category for each row execute function core.fn_scoped_guard();
create trigger trg_product_category_touch before update on inventory.product_category for each row execute function core.fn_touch_row();
create trigger trg_product_category_nodel before delete on inventory.product_category for each row execute function core.fn_deny_delete();
create trigger trg_product_category_audit after insert or update on inventory.product_category for each row execute function audit.fn_row_change();

create table inventory.attribute_schema (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  version     integer not null check (version >= 1),
  definition  jsonb not null,
  status      text not null default 'active' check (status in ('active','superseded')),
  set_by      uuid, set_at timestamptz not null default clock_timestamp(),
  reason      text not null check (length(btrim(reason)) > 0),
  unique (company_id, version)
);
create unique index attribute_schema_one_active on inventory.attribute_schema (company_id) where status = 'active';
create trigger trg_attribute_schema_guard before update on inventory.attribute_schema for each row execute function config.fn_history_only_supersede();
create trigger trg_attribute_schema_nodel before delete on inventory.attribute_schema for each row execute function core.fn_deny_delete();
create trigger trg_attribute_schema_audit after insert or update on inventory.attribute_schema for each row execute function audit.fn_row_change();

-- ================================================================ products + versions (maker-checker)
create table inventory.product (
  id               uuid primary key default gen_random_uuid(),
  company_id       uuid not null references core.company(id),
  sku              text not null check (sku ~ '^[A-Z0-9][A-Z0-9_-]{1,30}$'),
  name_bn          text not null,
  name_en          text,
  kind             text not null check (kind in ('finished_good','raw_material','packaging','trading','service')),
  category_id      uuid,
  base_unit        text not null references inventory.unit(code),
  attributes       jsonb not null default '{}'::jsonb,
  attribute_schema_version integer,
  image_path       text,
  status           text not null default 'draft' check (status in ('draft','active','suspended','archived')),
  current_version  integer not null default 0,
  created_by       uuid,
  created_at       timestamptz not null default clock_timestamp(),
  updated_at       timestamptz not null default clock_timestamp(),
  row_version      integer not null default 1,
  unique (id, company_id), unique (company_id, sku),
  foreign key (category_id, company_id) references inventory.product_category (id, company_id)
);
create function inventory.fn_product_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.company_id <> old.company_id or new.sku <> old.sku or new.kind <> old.kind or new.base_unit <> old.base_unit then
    raise exception 'E_IMMUTABLE: SKU, kind and base unit never change (create a new product)' using errcode = 'P0001';
  end if;
  if new.status <> old.status and not ((old.status = 'draft' and new.status in ('active','archived')) or (old.status = 'active' and new.status in ('suspended','archived'))
                                       or (old.status = 'suspended' and new.status in ('active','archived'))) then
    raise exception 'E_INVALID_ACTION: product % -> %', old.status, new.status using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_product_guard before update on inventory.product for each row execute function inventory.fn_product_guard();
create trigger trg_product_touch before update on inventory.product for each row execute function core.fn_touch_row();
create trigger trg_product_nodel before delete on inventory.product for each row execute function core.fn_deny_delete();
create trigger trg_product_audit after insert or update on inventory.product for each row execute function audit.fn_row_change();

create table inventory.product_version (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null,
  product_id    uuid not null,
  version       integer not null check (version >= 1),
  snapshot      jsonb not null,
  diff          jsonb not null default '{}'::jsonb,
  status        text not null default 'pending' check (status in ('pending','approved','rejected','withdrawn')),
  reason        text not null check (length(btrim(reason)) > 0),
  created_by    uuid not null references core.person(id),
  created_at    timestamptz not null default clock_timestamp(),
  decided_by    uuid references core.person(id),
  decided_at    timestamptz,
  decision_note text,
  unique (product_id, version),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  check (decided_by is null or decided_by <> created_by)
);
create unique index product_version_one_pending on inventory.product_version (product_id) where status = 'pending';
create function inventory.fn_product_version_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','decided_by','decided_at','decision_note']) <> (to_jsonb(new) - array['status','decided_by','decided_at','decision_note'])
     or old.status <> 'pending' then
    raise exception 'E_IMMUTABLE: a product version is only decided once, never edited' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_product_version_guard before update on inventory.product_version for each row execute function inventory.fn_product_version_guard();
create trigger trg_product_version_nodel before delete on inventory.product_version for each row execute function core.fn_deny_delete();
create trigger trg_product_version_audit after insert or update on inventory.product_version for each row execute function audit.fn_row_change();

-- ================================================================ variants (F062)
create table inventory.product_variant (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  product_id   uuid not null,
  code         text not null check (code ~ '^[A-Z0-9][A-Z0-9_-]{0,20}$'),
  name_bn      text not null check (length(btrim(name_bn)) > 0),
  size_label   text, flavor text, package text,
  recipe_ref   text,                   -- BOM / recipe code (mfg module); pinned once used
  status       text not null default 'active' check (status in ('active','inactive')),
  locked_at    timestamptz,            -- set by the first posted BOM / sale reference (later modules)
  locked_by_ref text,
  updated_at   timestamptz not null default clock_timestamp(),
  row_version  integer not null default 1,
  unique (id, company_id), unique (product_id, code),
  foreign key (product_id, company_id) references inventory.product (id, company_id)
);
create function inventory.fn_variant_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if new.code <> old.code or new.product_id <> old.product_id or new.company_id <> old.company_id then
    raise exception 'E_IMMUTABLE: variant identity never changes' using errcode = 'P0001';
  end if;
  if old.locked_at is not null and (new.recipe_ref is distinct from old.recipe_ref or new.size_label is distinct from old.size_label
                                    or new.package is distinct from old.package or new.locked_at is distinct from old.locked_at) then
    raise exception 'E_PRODUCT_LOCKED: variant is used by posted records (%); create a new variant', old.locked_by_ref using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_variant_guard before update on inventory.product_variant for each row execute function inventory.fn_variant_guard();
create trigger trg_variant_touch before update on inventory.product_variant for each row execute function core.fn_touch_row();
create trigger trg_variant_nodel before delete on inventory.product_variant for each row execute function core.fn_deny_delete();
create trigger trg_variant_audit after insert or update on inventory.product_variant for each row execute function audit.fn_row_change();

-- ================================================================ POLY specification (F064, ADR-12)
create table inventory.pack_spec (
  id                 uuid primary key default gen_random_uuid(),
  company_id         uuid not null,
  product_id         uuid not null,
  variant_id         uuid,
  version            integer not null check (version >= 1),
  sachets_per_poly   integer not null check (sachets_per_poly > 0),
  grams_per_sachet   numeric(12,4) not null check (grams_per_sachet > 0),
  polys_per_carton   integer check (polys_per_carton is null or polys_per_carton > 0),
  effective_from     timestamptz not null,
  status             text not null default 'pending' check (status in ('pending','approved','rejected','superseded')),
  reason             text not null check (length(btrim(reason)) > 0),
  created_by         uuid not null references core.person(id),
  created_at         timestamptz not null default clock_timestamp(),
  approved_by        uuid references core.person(id),
  approved_at        timestamptz,
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  foreign key (variant_id, company_id) references inventory.product_variant (id, company_id),
  check (approved_by is null or approved_by <> created_by)
);
create unique index pack_spec_version on inventory.pack_spec (product_id, variant_id, version) nulls not distinct;
create function inventory.fn_pack_spec_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['status','approved_by','approved_at']) <> (to_jsonb(new) - array['status','approved_by','approved_at'])
     or not ((old.status = 'pending' and new.status in ('approved','rejected')) or (old.status = 'approved' and new.status = 'superseded')) then
    raise exception 'E_IMMUTABLE: a POLY specification never changes; add a new version' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_pack_spec_guard before update on inventory.pack_spec for each row execute function inventory.fn_pack_spec_guard();
create trigger trg_pack_spec_nodel before delete on inventory.pack_spec for each row execute function core.fn_deny_delete();
create trigger trg_pack_spec_audit after insert or update on inventory.pack_spec for each row execute function audit.fn_row_change();

-- ================================================================ prices (F066)
create table inventory.price_list (
  id          uuid primary key default gen_random_uuid(),
  company_id  uuid not null references core.company(id),
  code        text not null check (code ~ '^[A-Z0-9_]{2,20}$'),
  name_bn     text not null,
  wing_id     uuid,
  currency    text not null default 'BDT' check (currency = 'BDT'),
  status      text not null default 'active' check (status in ('active','inactive')),
  updated_at  timestamptz not null default clock_timestamp(),
  row_version integer not null default 1,
  unique (id, company_id), unique (company_id, code),
  foreign key (wing_id, company_id) references core.wing (id, company_id)
);
create trigger trg_price_list_guard before update on inventory.price_list for each row execute function core.fn_scoped_guard();
create trigger trg_price_list_touch before update on inventory.price_list for each row execute function core.fn_touch_row();
create trigger trg_price_list_nodel before delete on inventory.price_list for each row execute function core.fn_deny_delete();
create trigger trg_price_list_audit after insert or update on inventory.price_list for each row execute function audit.fn_row_change();

create table inventory.price (
  id              uuid primary key default gen_random_uuid(),
  company_id      uuid not null,
  price_list_id   uuid not null,
  product_id      uuid not null,
  variant_id      uuid,
  unit            text not null references inventory.unit(code),
  amount          numeric(14,2) not null check (amount >= 0),
  effective_from  date not null,
  effective_to    date,
  status          text not null default 'active' check (status in ('active','superseded')),
  created_by      uuid, created_at timestamptz not null default clock_timestamp(),
  reason          text not null check (length(btrim(reason)) > 0),
  foreign key (price_list_id, company_id) references inventory.price_list (id, company_id),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  foreign key (variant_id, company_id) references inventory.product_variant (id, company_id),
  check (effective_to is null or effective_to >= effective_from)
);
create index price_lookup on inventory.price (price_list_id, product_id, variant_id, unit, effective_from desc) where status = 'active';
-- A price that has started is history: its amount and start never change; only its end date may be set once.
create function inventory.fn_price_guard() returns trigger
language plpgsql set search_path = pg_catalog as $$
begin
  if (to_jsonb(old) - array['effective_to','status']) <> (to_jsonb(new) - array['effective_to','status'])
     or (old.effective_to is not null and new.effective_to is distinct from old.effective_to)
     or (new.status = 'superseded' and old.effective_from <= current_date) then
    raise exception 'E_IMMUTABLE: a started price is history; add a new price from a future date' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger trg_price_guard before update on inventory.price for each row execute function inventory.fn_price_guard();
create trigger trg_price_nodel before delete on inventory.price for each row execute function core.fn_deny_delete();
create trigger trg_price_audit after insert or update on inventory.price for each row execute function audit.fn_row_change();

-- ================================================================ media (F067)
create table inventory.product_media (
  id           uuid primary key default gen_random_uuid(),
  company_id   uuid not null,
  product_id   uuid not null,
  kind         text not null check (kind in ('image','brand')),
  mime_type    text not null check (mime_type in ('image/jpeg','image/png','image/webp')),
  size_bytes   integer not null check (size_bytes > 0),
  sha256       text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  object_path  text not null unique,
  status       text not null default 'pending' check (status in ('pending','uploaded','retired')),
  created_by   uuid not null references core.person(id),
  created_at   timestamptz not null default clock_timestamp(),
  foreign key (product_id, company_id) references inventory.product (id, company_id),
  check (object_path like company_id::text || '/products/%')
);
create trigger trg_product_media_nodel before delete on inventory.product_media for each row execute function core.fn_deny_delete();
create trigger trg_product_media_audit after insert or update on inventory.product_media for each row execute function audit.fn_row_change();

select core.fn_apply_rls('inventory', 'unit');
select core.fn_apply_rls('inventory', 'product_category');
select core.fn_apply_rls('inventory', 'attribute_schema');
select core.fn_apply_rls('inventory', 'product');
select core.fn_apply_rls('inventory', 'product_version');
select core.fn_apply_rls('inventory', 'product_variant');
select core.fn_apply_rls('inventory', 'pack_spec');
select core.fn_apply_rls('inventory', 'price_list');
select core.fn_apply_rls('inventory', 'price');
select core.fn_apply_rls('inventory', 'product_media');

-- ================================================================ permissions, module, settings
insert into iam.permission_catalog (code, module, name_bn, action_kind, is_sensitive, is_delegable, allowed_scopes, status, sort_order) values
  ('master.sku.approve', 'master', 'পণ্য-পরিবর্তন ও POLY-স্পেক অনুমোদন', 'approve', true, false, array['COMPANY'], 'active', 505);
update iam.permission_catalog set status = 'active' where code in ('master.sku.read','master.sku.manage','master.price.manage');
select iam.fn_seed_permission_dependencies();
insert into iam.permission_template_rule (position_code, permission_code, effect, scope_kind)
select t.code, 'master.sku.read', 'allow', 'COMPANY' from iam.position_template t where not t.is_supreme and t.code not in ('TECH_ADMIN','EMERGENCY_ADMIN')
union all select x, 'master.sku.manage', 'allow', 'COMPANY' from unnest(array['STOREKEEPER','PURCHASE_OFFICER','SALES_MANAGER','PROD_SUPERVISOR']) x
union all select x, 'master.sku.approve', 'allow', 'COMPANY' from unnest(array['MD','FIN_MANAGER']) x
union all select x, 'master.price.manage', 'allow', 'COMPANY' from unnest(array['MD','SALES_MANAGER']) x;
select iam.fn_backfill_template_rules(null);
select config.fn_make_module_available('master');

insert into config.setting_definition (key, module, value_type, default_value, min_value, max_value, allowed_values, name_bn, description_bn, is_sensitive, sort_order) values
  ('master.media.max_mb', 'master', 'int', '5', 1, 20, null, 'পণ্য-ছবির সর্বোচ্চ আকার (MB)', 'MOS-F153-067', false, 1200),
  ('master.qr.prefix', 'master', 'text', '"MOS1"', null, null, '["MOS1"]', 'পণ্য-QR সংস্করণ', 'MOS-F153-065', false, 1210);

-- ================================================================ engine
create function inventory.fn_snapshot(p inventory.product) returns jsonb
language sql immutable set search_path = pg_catalog as $$
  select jsonb_build_object('name_bn', p.name_bn, 'name_en', p.name_en, 'category_id', p.category_id, 'attributes', p.attributes,
                            'attribute_schema_version', p.attribute_schema_version)
$$;

-- Field-level diff; attribute keys appear as "attributes.<key>".
create function inventory.fn_diff(a jsonb, b jsonb) returns jsonb
language sql immutable set search_path = pg_catalog as $$
  select coalesce(jsonb_object_agg(k, jsonb_build_object('from', av, 'to', bv)), '{}'::jsonb) from (
    select k, a -> k av, b -> k bv from (select jsonb_object_keys(coalesce(a, '{}')) k union select jsonb_object_keys(coalesce(b, '{}'))) ks
     where k <> 'attributes' and (a -> k) is distinct from (b -> k)
    union all
    select 'attributes.' || k, a -> 'attributes' -> k, b -> 'attributes' -> k
      from (select jsonb_object_keys(coalesce(a -> 'attributes', '{}')) k union select jsonb_object_keys(coalesce(b -> 'attributes', '{}'))) ka
     where (a -> 'attributes' -> k) is distinct from (b -> 'attributes' -> k)) d
$$;

-- For later modules: can this product / variant start a NEW transaction? (archived and suspended never)
create function inventory.fn_product_usable(p_company uuid, p_product uuid, p_variant uuid default null) returns boolean
language sql stable security definer set search_path = pg_catalog as $$
  select exists (select 1 from inventory.product p where p.id = p_product and p.company_id = p_company and p.status = 'active')
     and (p_variant is null or exists (select 1 from inventory.product_variant v where v.id = p_variant and v.product_id = p_product and v.status = 'active'))
$$;

-- For later modules: the first posted BOM / sale referencing a variant locks it (F062).
create function inventory.fn_lock_variant(p_variant uuid, p_ref text) returns void
language sql security definer set search_path = pg_catalog as $$
  update inventory.product_variant set locked_at = clock_timestamp(), locked_by_ref = left(p_ref, 120) where id = p_variant and locked_at is null
$$;

-- The approved POLY spec in force at a moment: variant-specific first, else product-level (ADR-12 snapshot source).
create function inventory.fn_pack_spec_at(p_product uuid, p_variant uuid, p_at timestamptz) returns inventory.pack_spec
language sql stable security definer set search_path = pg_catalog as $$
  select s from inventory.pack_spec s
   where s.product_id = p_product and s.status = 'approved' and s.effective_from <= p_at and (s.variant_id = p_variant or s.variant_id is null)
   order by (s.variant_id is null), s.effective_from desc, s.version desc limit 1
$$;

-- Batch snapshot (ADR-12): what a batch / BOM / sale stores so later spec edits never move its numbers.
create function inventory.fn_pack_spec_snapshot(p_product uuid, p_variant uuid, p_at timestamptz) returns jsonb
language plpgsql stable security definer set search_path = pg_catalog as $$
declare s inventory.pack_spec;
begin
  s := inventory.fn_pack_spec_at(p_product, p_variant, p_at);
  if s.id is null then raise exception 'E_UNIT_AMBIGUOUS: no approved POLY specification in force' using errcode = 'P0001'; end if;
  return jsonb_build_object('spec_id', s.id, 'version', s.version, 'sachets_per_poly', s.sachets_per_poly, 'grams_per_sachet', s.grams_per_sachet,
                            'polys_per_carton', s.polys_per_carton, 'effective_from', s.effective_from, 'taken_at', p_at);
end $$;

-- Quantity conversion. Mass/volume by fixed factors; pack units (sachet/poly/carton) and grams of a pack product only
-- through the spec in force (or a given snapshot); pcs/dozen are never converted to anything but each other.
create function inventory.fn_convert(p_qty numeric, p_from text, p_to text, p_spec jsonb) returns numeric
language plpgsql immutable set search_path = pg_catalog as $$
declare f text := lower(p_from); t text := lower(p_to); sach numeric; per_poly numeric; g numeric; per_carton numeric;
        mass constant jsonb := '{"g":1,"kg":1000,"ton":1000000}'; vol constant jsonb := '{"ml":1,"ltr":1000}';
begin
  if p_qty is null then return null; end if;
  if f = t then return p_qty; end if;
  if mass ? f and mass ? t then return p_qty * (mass ->> f)::numeric / (mass ->> t)::numeric; end if;
  if vol ? f and vol ? t then return p_qty * (vol ->> f)::numeric / (vol ->> t)::numeric; end if;
  if f in ('pcs','dozen') and t in ('pcs','dozen') then return case when f = 'dozen' then p_qty * 12 else p_qty / 12 end; end if;
  if f in ('pcs','dozen') or t in ('pcs','dozen') or not ((f in ('sachet','poly','carton') or mass ? f) and (t in ('sachet','poly','carton') or mass ? t)) then
    raise exception 'E_UNIT_AMBIGUOUS: % -> % has no defined conversion', f, t using errcode = 'P0001';
  end if;
  if p_spec is null then raise exception 'E_UNIT_AMBIGUOUS: pack conversion needs the POLY specification' using errcode = 'P0001'; end if;
  per_poly := (p_spec ->> 'sachets_per_poly')::numeric; g := (p_spec ->> 'grams_per_sachet')::numeric;
  per_carton := (p_spec ->> 'polys_per_carton')::numeric;
  if (f = 'carton' or t = 'carton') and per_carton is null then raise exception 'E_UNIT_AMBIGUOUS: polys per carton not defined' using errcode = 'P0001'; end if;
  sach := case f when 'sachet' then p_qty when 'poly' then p_qty * per_poly when 'carton' then p_qty * per_carton * per_poly
                 else p_qty * (mass ->> f)::numeric / g end;
  return case t when 'sachet' then sach when 'poly' then sach / per_poly when 'carton' then sach / (per_poly * per_carton)
                else sach * g / (mass ->> t)::numeric end;
end $$;

create function inventory.fn_qr_payload(p_company uuid, p_sku text, p_variant_code text) returns text
language sql stable security definer set search_path = pg_catalog as $$
  select config.fn_get_text(p_company, 'master.qr.prefix') || '|P|' || (select c.code from core.company c where c.id = p_company) || '|' || p_sku || '|' || coalesce(p_variant_code, '-')
$$;

-- ================================================================ API: products
create function api.v1_product_list(p_text text default null, p_status text default null, p_limit integer default 100) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(x) from (
    select jsonb_build_object('id', p.id, 'sku', p.sku, 'name_bn', p.name_bn, 'kind', p.kind, 'base_unit', p.base_unit, 'status', p.status,
                              'image_path', p.image_path, 'current_version', p.current_version, 'row_version', p.row_version,
                              'pending_version', (select v.version from inventory.product_version v where v.product_id = p.id and v.status = 'pending')) x
      from inventory.product p
     where p.company_id = me.company_id and (p_status is null or p.status = p_status)
       and (p_text is null or p.sku ilike '%' || p_text || '%' or p.name_bn ilike '%' || p_text || '%')
     order by p.sku limit greatest(1, least(coalesce(p_limit, 100), 500))) q), '[]'::jsonb);
end $$;

create function api.v1_product_get(p_product_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; p inventory.product%rowtype;
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  select * into p from inventory.product where id = p_product_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  return to_jsonb(p) - 'company_id' || jsonb_build_object(
    'qr', inventory.fn_qr_payload(me.company_id, p.sku, null),
    'variants', coalesce((select jsonb_agg(jsonb_build_object('id', v.id, 'code', v.code, 'name_bn', v.name_bn, 'size_label', v.size_label, 'flavor', v.flavor,
                    'package', v.package, 'recipe_ref', v.recipe_ref, 'status', v.status, 'locked', v.locked_at is not null, 'row_version', v.row_version,
                    'qr', inventory.fn_qr_payload(me.company_id, p.sku, v.code)) order by v.code)
                  from inventory.product_variant v where v.product_id = p.id), '[]'::jsonb),
    'pack_specs', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'variant_id', s.variant_id, 'version', s.version, 'sachets_per_poly', s.sachets_per_poly,
                    'grams_per_sachet', s.grams_per_sachet, 'polys_per_carton', s.polys_per_carton, 'effective_from', s.effective_from, 'status', s.status)
                    order by s.variant_id nulls first, s.version desc)
                  from inventory.pack_spec s where s.product_id = p.id), '[]'::jsonb),
    'pending', (select jsonb_build_object('version', v.version, 'diff', v.diff, 'created_by', v.created_by, 'reason', v.reason)
                  from inventory.product_version v where v.product_id = p.id and v.status = 'pending'));
end $$;

-- Every change is a pending version (F069); nothing applies until ANOTHER person approves.
create function api.v1_product_propose(p_product_id uuid, p_sku text, p_name_bn text, p_name_en text, p_kind text, p_category_id uuid, p_base_unit text,
                                       p_attributes jsonb, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p inventory.product%rowtype; sch inventory.attribute_schema%rowtype; chk jsonb; snap jsonb; v integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  if length(btrim(coalesce(p_name_bn, ''))) = 0 then perform core.fn_raise('E_INVALID_ACTION', 'name_bn'); end if;
  select * into sch from inventory.attribute_schema where company_id = me.company_id and status = 'active';
  if sch.id is not null then
    chk := config.fn_form_check(sch.definition, coalesce(p_attributes, '{}'::jsonb), me.company_id, null, null, null, false);
    if not (chk ->> 'ok')::boolean then perform core.fn_raise('E_FORM_VALIDATION', (chk -> 'errors')::text); end if;
  elsif p_attributes is not null and p_attributes <> '{}'::jsonb then
    perform core.fn_raise('E_INVALID_ACTION', 'no attribute fields are defined yet');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_product_id is null then
    if upper(btrim(coalesce(p_sku, ''))) !~ '^[A-Z0-9][A-Z0-9_-]{1,30}$' then perform core.fn_raise('E_INVALID_ACTION', 'SKU: A-Z 0-9 _ -'); end if;
    if exists (select 1 from inventory.product x where x.company_id = me.company_id and x.sku = upper(btrim(p_sku))) then perform core.fn_raise('E_DUPLICATE', 'SKU'); end if;
    insert into inventory.product (company_id, sku, name_bn, name_en, kind, category_id, base_unit, created_by)
    values (me.company_id, upper(btrim(p_sku)), p_name_bn, p_name_en, p_kind, p_category_id, p_base_unit, me.person_id) returning * into p;
  else
    select * into p from inventory.product where id = p_product_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
    if p.status = 'archived' then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
    if exists (select 1 from inventory.product_version x where x.product_id = p.id and x.status = 'pending') then
      perform core.fn_raise('E_DUPLICATE', 'a change is already waiting for approval');
    end if;
  end if;
  snap := jsonb_build_object('name_bn', p_name_bn, 'name_en', p_name_en, 'category_id', p_category_id, 'attributes', coalesce(chk -> 'values', '{}'::jsonb),
                             'attribute_schema_version', sch.version);
  v := coalesce((select max(x.version) from inventory.product_version x where x.product_id = p.id), 0) + 1;
  insert into inventory.product_version (company_id, product_id, version, snapshot, diff, reason, created_by)
  values (me.company_id, p.id, v, snap, inventory.fn_diff(case when p.current_version = 0 then '{}'::jsonb else inventory.fn_snapshot(p) end, snap), p_reason, me.person_id);
  return jsonb_build_object('product_id', p.id, 'version', v, 'status', 'pending');
end $$;

create function api.v1_product_decide(p_product_id uuid, p_version integer, p_decision text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v inventory.product_version%rowtype; p inventory.product%rowtype;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.approve', iam.fn_my_company_resource(), true);
  select * into v from inventory.product_version where product_id = p_product_id and version = p_version and company_id = me.company_id for update;
  if not found or v.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending version'); end if;
  if v.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'the author cannot approve own change'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  if p_decision = 'approve' then
    update inventory.product_version set status = 'approved', decided_by = me.person_id, decided_at = clock_timestamp(), decision_note = p_note where id = v.id;
    update inventory.product set name_bn = v.snapshot ->> 'name_bn', name_en = v.snapshot ->> 'name_en', category_id = (v.snapshot ->> 'category_id')::uuid,
                                 attributes = coalesce(v.snapshot -> 'attributes', '{}'::jsonb), attribute_schema_version = (v.snapshot ->> 'attribute_schema_version')::integer,
                                 current_version = v.version, status = case when status = 'draft' then 'active' else status end
     where id = v.product_id returning * into p;
  elsif p_decision = 'reject' then
    update inventory.product_version set status = 'rejected', decided_by = me.person_id, decided_at = clock_timestamp(), decision_note = p_note where id = v.id;
  else
    perform core.fn_raise('E_INVALID_ACTION', p_decision);
  end if;
  return jsonb_build_object('product_id', p_product_id, 'version', p_version, 'decision', p_decision,
                            'status', (select x.status from inventory.product x where x.id = p_product_id));
end $$;

-- suspend | resume | archive. Resume needs the approve right (a second look before selling again).
create function api.v1_product_action(p_product_id uuid, p_action text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p inventory.product%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require(case when p_action = 'resume' then 'master.sku.approve' else 'master.sku.manage' end, iam.fn_my_company_resource(), true);
  select * into p from inventory.product where id = p_product_id and company_id = me.company_id for update;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  if p.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update inventory.product set status = case p_action when 'suspend' then 'suspended' when 'resume' then 'active' when 'archive' then 'archived' else status end
   where id = p.id returning * into p;
  if p_action not in ('suspend','resume','archive') then perform core.fn_raise('E_INVALID_ACTION', p_action); end if;
  return jsonb_build_object('product_id', p.id, 'status', p.status, 'row_version', p.row_version);
end $$;

create function api.v1_product_history(p_product_id uuid) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record;
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  return coalesce((select jsonb_agg(jsonb_build_object('version', v.version, 'status', v.status, 'diff', v.diff, 'reason', v.reason, 'created_by', v.created_by,
                                                       'created_at', v.created_at, 'decided_by', v.decided_by, 'decided_at', v.decided_at, 'decision_note', v.decision_note)
                                    order by v.version desc)
                     from inventory.product_version v where v.product_id = p_product_id and v.company_id = me.company_id), '[]'::jsonb);
end $$;

create function api.v1_product_save_variant(p_product_id uuid, p_variant_id uuid, p_code text, p_name_bn text, p_size text, p_flavor text, p_package text,
                                            p_recipe_ref text, p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p inventory.product%rowtype; v inventory.product_variant%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  select * into p from inventory.product where id = p_product_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  if p.status = 'archived' then perform core.fn_raise('E_PRODUCT_ARCHIVED'); end if;
  perform set_config('mohona.change_reason', p_reason, true);
  if p_variant_id is null then
    insert into inventory.product_variant (company_id, product_id, code, name_bn, size_label, flavor, package, recipe_ref)
    values (me.company_id, p.id, upper(p_code), p_name_bn, p_size, p_flavor, p_package, p_recipe_ref) returning * into v;
  else
    select * into v from inventory.product_variant where id = p_variant_id and product_id = p.id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'variant'); end if;
    if v.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    update inventory.product_variant set name_bn = coalesce(p_name_bn, name_bn), size_label = p_size, flavor = p_flavor, package = p_package, recipe_ref = p_recipe_ref,
                                         status = coalesce(p_status, status) where id = v.id returning * into v;
  end if;
  return jsonb_build_object('variant_id', v.id, 'row_version', v.row_version, 'qr', inventory.fn_qr_payload(me.company_id, p.sku, v.code));
end $$;

-- ================================================================ API: POLY specification (ADR-12)
create function api.v1_pack_spec_propose(p_product_id uuid, p_variant_id uuid, p_sachets_per_poly integer, p_grams_per_sachet numeric, p_polys_per_carton integer,
                                         p_effective_from timestamptz, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; p inventory.product%rowtype; v integer; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  select * into p from inventory.product where id = p_product_id and company_id = me.company_id;
  if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  if p.kind <> 'finished_good' then perform core.fn_raise('E_INVALID_ACTION', 'POLY specifications are for finished goods'); end if;
  if coalesce(p_sachets_per_poly, 0) <= 0 or coalesce(p_grams_per_sachet, 0) <= 0 or coalesce(p_polys_per_carton, 1) <= 0 then
    perform core.fn_raise('E_INVALID_ACTION', 'conversion factors must be positive');
  end if;
  if p_variant_id is not null and not exists (select 1 from inventory.product_variant x where x.id = p_variant_id and x.product_id = p.id) then
    perform core.fn_raise('E_NOT_FOUND', 'variant');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform pg_advisory_xact_lock(hashtext(p.id::text || coalesce(p_variant_id::text, '-')));
  v := coalesce((select max(s.version) from inventory.pack_spec s where s.product_id = p.id and s.variant_id is not distinct from p_variant_id), 0) + 1;
  insert into inventory.pack_spec (company_id, product_id, variant_id, version, sachets_per_poly, grams_per_sachet, polys_per_carton, effective_from, reason, created_by)
  values (me.company_id, p.id, p_variant_id, v, p_sachets_per_poly, p_grams_per_sachet, p_polys_per_carton,
          greatest(coalesce(p_effective_from, clock_timestamp()), clock_timestamp()), p_reason, me.person_id)
  returning id into v_id;
  return jsonb_build_object('spec_id', v_id, 'version', v, 'status', 'pending');
end $$;

create function api.v1_pack_spec_decide(p_spec_id uuid, p_decision text, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; s inventory.pack_spec%rowtype;
begin
  if length(btrim(coalesce(p_note, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.sku.approve', iam.fn_my_company_resource(), true);
  select * into s from inventory.pack_spec where id = p_spec_id and company_id = me.company_id for update;
  if not found or s.status <> 'pending' then perform core.fn_raise('E_NOT_FOUND', 'pending specification'); end if;
  if s.created_by = me.person_id then perform core.fn_raise('E_SELF_APPROVAL', 'the author cannot approve own specification'); end if;
  perform set_config('mohona.change_reason', p_note, true);
  update inventory.pack_spec set status = case p_decision when 'approve' then 'approved' when 'reject' then 'rejected' else status end,
                                 approved_by = case when p_decision = 'approve' then me.person_id end,
                                 approved_at = case when p_decision = 'approve' then clock_timestamp() end
   where id = s.id;
  if p_decision not in ('approve','reject') then perform core.fn_raise('E_INVALID_ACTION', p_decision); end if;
  return jsonb_build_object('spec_id', s.id, 'status', (select x.status from inventory.pack_spec x where x.id = s.id));
end $$;

-- Conversion through the spec in force at p_at (or the snapshot you pass): pcs is never guessed.
create function api.v1_product_convert(p_product_id uuid, p_variant_id uuid, p_qty numeric, p_from text, p_to text, p_at timestamptz default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; snap jsonb;
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  if not exists (select 1 from inventory.product p where p.id = p_product_id and p.company_id = me.company_id) then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  if lower(p_from) in ('sachet','poly','carton') or lower(p_to) in ('sachet','poly','carton') then
    snap := inventory.fn_pack_spec_snapshot(p_product_id, p_variant_id, coalesce(p_at, clock_timestamp()));
  end if;
  return jsonb_build_object('qty', inventory.fn_convert(p_qty, p_from, p_to, snap), 'from', p_from, 'to', p_to, 'spec', snap);
end $$;

-- ================================================================ API: prices (F066)
create function api.v1_price_list_save(p_id uuid, p_code text, p_name_bn text, p_wing_id uuid, p_status text, p_expected_row_version integer, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; l inventory.price_list%rowtype;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.price.manage', iam.fn_my_company_resource(), true);
  perform set_config('mohona.change_reason', p_reason, true);
  if p_id is null then
    insert into inventory.price_list (company_id, code, name_bn, wing_id) values (me.company_id, upper(p_code), p_name_bn, p_wing_id) returning * into l;
  else
    select * into l from inventory.price_list where id = p_id and company_id = me.company_id for update;
    if not found then perform core.fn_raise('E_NOT_FOUND', 'price list'); end if;
    if l.row_version <> p_expected_row_version then perform core.fn_raise('E_STALE_VERSION'); end if;
    update inventory.price_list set name_bn = coalesce(p_name_bn, name_bn), wing_id = p_wing_id, status = coalesce(p_status, status) where id = l.id returning * into l;
  end if;
  return jsonb_build_object('price_list_id', l.id, 'row_version', l.row_version);
end $$;

-- New price from today or later. An open earlier price is closed the day before; future prices it overtakes are
-- superseded; a price that already started is never changed (invoices keep their history).
create function api.v1_price_set(p_price_list_id uuid, p_product_id uuid, p_variant_id uuid, p_unit text, p_amount numeric, p_effective_from date, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_from date := coalesce(p_effective_from, current_date); x record; v_id uuid;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('master.price.manage', iam.fn_my_company_resource(), true);
  if v_from < current_date then perform core.fn_raise('E_PRICE_BACKDATED'); end if;
  if coalesce(p_amount, -1) < 0 then perform core.fn_raise('E_INVALID_ACTION', 'amount'); end if;
  if not exists (select 1 from inventory.price_list l where l.id = p_price_list_id and l.company_id = me.company_id and l.status = 'active') then perform core.fn_raise('E_NOT_FOUND', 'price list'); end if;
  if not exists (select 1 from inventory.product p where p.id = p_product_id and p.company_id = me.company_id and p.status in ('draft','active','suspended')) then
    perform core.fn_raise('E_PRODUCT_ARCHIVED');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  perform pg_advisory_xact_lock(hashtext(p_price_list_id::text || p_product_id::text || coalesce(p_variant_id::text, '-') || p_unit));
  for x in select * from inventory.price pr where pr.price_list_id = p_price_list_id and pr.product_id = p_product_id and pr.variant_id is not distinct from p_variant_id
             and pr.unit = p_unit and pr.status = 'active' and (pr.effective_to is null or pr.effective_to >= v_from) for update loop
    if x.effective_from < v_from then
      update inventory.price set effective_to = v_from - 1 where id = x.id;
    elsif x.effective_from > current_date then
      update inventory.price set status = 'superseded' where id = x.id;
    else
      perform core.fn_raise('E_PRICE_STARTED', 'a price starting ' || x.effective_from || ' already applies; set the new one from tomorrow');
    end if;
  end loop;
  insert into inventory.price (company_id, price_list_id, product_id, variant_id, unit, amount, effective_from, created_by, reason)
  values (me.company_id, p_price_list_id, p_product_id, p_variant_id, p_unit, p_amount, v_from, me.person_id, p_reason) returning id into v_id;
  return jsonb_build_object('price_id', v_id, 'effective_from', v_from);
end $$;

create function api.v1_price_at(p_price_list_id uuid, p_product_id uuid, p_variant_id uuid, p_unit text, p_date date default null) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; d date := coalesce(p_date, current_date);
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  return (select jsonb_build_object('price_id', pr.id, 'amount', pr.amount, 'effective_from', pr.effective_from, 'effective_to', pr.effective_to)
            from inventory.price pr
           where pr.company_id = me.company_id and pr.price_list_id = p_price_list_id and pr.product_id = p_product_id
             and pr.variant_id is not distinct from p_variant_id and pr.unit = p_unit and pr.status = 'active'
             and pr.effective_from <= d and (pr.effective_to is null or pr.effective_to >= d)
           order by pr.effective_from desc limit 1);
end $$;

-- ================================================================ API: media, attribute fields, QR
create function api.v1_product_media_begin(p_product_id uuid, p_kind text, p_mime_type text, p_size_bytes integer, p_sha256 text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; v_id uuid := gen_random_uuid(); v_path text;
begin
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  if not exists (select 1 from inventory.product p where p.id = p_product_id and p.company_id = me.company_id and p.status <> 'archived') then
    perform core.fn_raise('E_NOT_FOUND', 'product');
  end if;
  if coalesce(p_mime_type, '') not in ('image/jpeg','image/png','image/webp') or coalesce(p_kind, '') not in ('image','brand') then
    perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'images only (jpeg, png, webp)');
  end if;
  if coalesce(p_size_bytes, 0) not between 1 and config.fn_get_int(me.company_id, 'master.media.max_mb') * 1048576 then
    perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'size');
  end if;
  if coalesce(p_sha256, '') !~ '^[0-9a-f]{64}$' then perform core.fn_raise('E_FORM_ATTACHMENT_INVALID', 'sha256'); end if;
  v_path := me.company_id::text || '/products/' || p_product_id::text || '/' || v_id::text || case p_mime_type when 'image/png' then '.png' when 'image/webp' then '.webp' else '.jpg' end;
  perform set_config('mohona.change_reason', 'product media upload', true);
  insert into inventory.product_media (id, company_id, product_id, kind, mime_type, size_bytes, sha256, object_path, created_by)
  values (v_id, me.company_id, p_product_id, p_kind, p_mime_type, p_size_bytes, p_sha256, v_path, me.person_id);
  return jsonb_build_object('media_id', v_id, 'bucket', 'products', 'path', v_path);
end $$;

create function api.v1_product_media_confirm(p_media_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare me record; m inventory.product_media%rowtype; v_exists boolean := true;
begin
  select * into me from iam.fn_require('master.sku.manage', iam.fn_my_company_resource(), true);
  select * into m from inventory.product_media where id = p_media_id and company_id = me.company_id for update;
  if not found or m.created_by <> me.person_id then perform core.fn_raise('E_NOT_FOUND', 'media'); end if;
  if m.status <> 'pending' then return jsonb_build_object('media_id', m.id, 'status', m.status); end if;
  if to_regclass('storage.objects') is not null then
    execute 'select exists (select 1 from storage.objects o where o.bucket_id = $1 and o.name = $2)' into v_exists using 'products', m.object_path;
  end if;
  if not v_exists then perform core.fn_raise('E_FORM_ATTACHMENT_MISSING'); end if;
  perform set_config('mohona.change_reason', 'product media uploaded', true);
  update inventory.product_media set status = 'uploaded' where id = m.id;
  if m.kind = 'image' then
    update inventory.product_media set status = 'retired' where product_id = m.product_id and kind = 'image' and status = 'uploaded' and id <> m.id;
    update inventory.product set image_path = m.object_path where id = m.product_id;
  end if;
  return jsonb_build_object('media_id', m.id, 'status', 'uploaded', 'path', m.object_path);
end $$;

-- Storage policies: product images are readable by members of that company; uploads only for one's own pending row.
create function api.v1_products_storage_can_read(p_bucket text, p_name text) returns boolean
language sql stable security definer set search_path = '' as $$
  select p_bucket = 'products' and exists (select 1 from iam.company_membership m where m.person_id = iam.fn_current_person() and m.status = 'active'
                                             and p_name like m.company_id::text || '/products/%')
$$;
create function api.v1_products_storage_can_upload(p_bucket text, p_name text) returns boolean
language sql stable security definer set search_path = '' as $$
  select p_bucket = 'products' and exists (select 1 from inventory.product_media x where x.object_path = p_name and x.status = 'pending'
                                             and x.created_by = iam.fn_current_person() and x.created_at > clock_timestamp() - interval '30 minutes')
$$;

-- Chairman-defined product fields (F068): Dynamic Forms schema language, versioned.
create function api.v1_product_set_attribute_schema(p_definition jsonb, p_reason text) returns integer
language plpgsql security definer set search_path = '' as $$
declare me record; v integer;
begin
  if length(btrim(coalesce(p_reason, ''))) = 0 then perform core.fn_raise('E_REASON_REQUIRED'); end if;
  select * into me from iam.fn_require('config.settings.manage', iam.fn_my_company_resource(), true);
  perform config.fn_form_validate_definition(p_definition);
  if exists (select 1 from jsonb_array_elements(p_definition -> 'fields') f where f ->> 'type' in ('photo','file')) then
    perform core.fn_raise('E_FORM_SCHEMA_INVALID', 'product fields cannot be attachments (use product media)');
  end if;
  perform set_config('mohona.change_reason', p_reason, true);
  update inventory.attribute_schema set status = 'superseded' where company_id = me.company_id and status = 'active';
  v := coalesce((select max(x.version) from inventory.attribute_schema x where x.company_id = me.company_id), 0) + 1;
  insert into inventory.attribute_schema (company_id, version, definition, set_by, reason) values (me.company_id, v, p_definition, me.person_id, p_reason);
  return v;
end $$;

-- QR (F065): MOS1|P|<company code>|<SKU>|<variant code or ->. Resolves only inside the caller's own company.
create function api.v1_product_resolve_qr(p_payload text) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; parts text[] := string_to_array(coalesce(p_payload, ''), '|'); p inventory.product%rowtype; v inventory.product_variant%rowtype;
begin
  select * into me from iam.fn_require('master.sku.read', iam.fn_my_company_resource(), false);
  if cardinality(parts) <> 5 or parts[1] <> config.fn_get_text(me.company_id, 'master.qr.prefix') or parts[2] <> 'P'
     or parts[3] is distinct from (select c.code from core.company c where c.id = me.company_id) then
    perform core.fn_raise('E_NOT_FOUND', 'product');
  end if;
  select * into p from inventory.product where company_id = me.company_id and sku = parts[4];
  if not found then perform core.fn_raise('E_NOT_FOUND', 'product'); end if;
  if parts[5] <> '-' then
    select * into v from inventory.product_variant where product_id = p.id and code = parts[5];
    if not found then perform core.fn_raise('E_NOT_FOUND', 'variant'); end if;
  end if;
  return jsonb_build_object('product_id', p.id, 'sku', p.sku, 'name_bn', p.name_bn, 'status', p.status, 'variant_id', v.id, 'variant_code', v.code,
                            'usable', inventory.fn_product_usable(me.company_id, p.id, v.id));
end $$;

select core.fn_assert_rls_everywhere();
reset role;

do $$
declare f text;
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    foreach f in array array['api.v1_product_list(text, text, integer)', 'api.v1_product_get(uuid)',
      'api.v1_product_propose(uuid, text, text, text, text, uuid, text, jsonb, text)', 'api.v1_product_decide(uuid, integer, text, text)',
      'api.v1_product_action(uuid, text, integer, text)', 'api.v1_product_history(uuid)',
      'api.v1_product_save_variant(uuid, uuid, text, text, text, text, text, text, text, integer, text)',
      'api.v1_pack_spec_propose(uuid, uuid, integer, numeric, integer, timestamptz, text)', 'api.v1_pack_spec_decide(uuid, text, text)',
      'api.v1_product_convert(uuid, uuid, numeric, text, text, timestamptz)',
      'api.v1_price_list_save(uuid, text, text, uuid, text, integer, text)', 'api.v1_price_set(uuid, uuid, uuid, text, numeric, date, text)',
      'api.v1_price_at(uuid, uuid, uuid, text, date)', 'api.v1_product_media_begin(uuid, text, text, integer, text)', 'api.v1_product_media_confirm(uuid)',
      'api.v1_products_storage_can_read(text, text)', 'api.v1_products_storage_can_upload(text, text)',
      'api.v1_product_set_attribute_schema(jsonb, text)', 'api.v1_product_resolve_qr(text)'] loop
      execute format('grant execute on function %s to authenticated', f);
    end loop;
  end if;
end $$;

do $$
begin
  if to_regclass('storage.objects') is null or to_regclass('storage.buckets') is null then
    raise notice 'MOHONA S24: no storage schema (plain PostgreSQL) - product media policies skipped';
    return;
  end if;
  execute $q$insert into storage.buckets (id, name, public) values ('products', 'products', false) on conflict (id) do update set public = false$q$;
  execute 'drop policy if exists mohona_products_read on storage.objects';
  execute 'drop policy if exists mohona_products_upload on storage.objects';
  execute $q$create policy mohona_products_read on storage.objects for select to authenticated using (bucket_id = 'products' and api.v1_products_storage_can_read(bucket_id, name))$q$;
  execute $q$create policy mohona_products_upload on storage.objects for insert to authenticated with check (bucket_id = 'products' and api.v1_products_storage_can_upload(bucket_id, name))$q$;
exception when insufficient_privilege then
  raise warning 'MOHONA S24: storage policies for bucket products could not be created (privilege) - see backend/supabase/functions/README_BN.md';
end $$;

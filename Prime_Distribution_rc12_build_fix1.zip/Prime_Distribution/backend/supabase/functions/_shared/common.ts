// Shared helpers for the S16 login Edge Functions (Deno). Secrets come ONLY from the function environment:
// SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY, MOHONA_JWT_SECRET (= project JWT secret).
// Nothing here is shipped in the app. STATUS: WRITTEN, NOT DEPLOYED (owner rule 5: run only at the end).
import { createClient, SupabaseClient } from "jsr:@supabase/supabase-js@2";
import { SignJWT } from "npm:jose@5.9.6";

export const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });

export function serviceClient(): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL"), key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) throw new Error("function environment incomplete");
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

/** Calls svc.<fn>(args) as service_role. Database text is never echoed to the caller. */
export async function svc(fn: string, args: Record<string, unknown>): Promise<Record<string, unknown>> {
  const { data, error } = await serviceClient().schema("svc").rpc(fn, args);
  if (error) throw new Error("svc." + fn + " failed");
  return data as Record<string, unknown>;
}

/** Access token for a PIN session: aal1 ALWAYS (the database rejects anything else for a PIN session), short-lived. */
export async function mintAccessToken(authUserId: string, sessionId: string, minutes: number): Promise<{ token: string; expiresAt: number }> {
  const secret = Deno.env.get("MOHONA_JWT_SECRET");
  if (!secret) throw new Error("jwt secret missing");
  const now = Math.floor(Date.now() / 1000), exp = now + Math.max(5, Math.min(minutes, 60)) * 60;
  const token = await new SignJWT({ role: "authenticated", session_id: sessionId, aal: "aal1", amr: [{ method: "pin", timestamp: now }] })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" }).setSubject(authUserId).setAudience("authenticated")
    .setIssuedAt(now).setExpirationTime(exp).sign(new TextEncoder().encode(secret));
  return { token, expiresAt: exp };
}

export const DEVICE_ID = /^[A-Za-z0-9_-]{16,128}$/;

export async function body(req: Request): Promise<Record<string, unknown>> {
  if (req.method !== "POST") throw new Error("POST only");
  if (Number(req.headers.get("content-length") ?? "0") > 4096) throw new Error("body too large");
  return await req.json();
}

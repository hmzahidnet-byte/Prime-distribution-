// POST {everywhere} with the caller's bearer token. Ends PIN sessions in the database (api.v1_auth_sign_out, AS the
// caller) and, for "everywhere", also the caller's native GoTrue sessions (OI-11).
import { createClient } from "jsr:@supabase/supabase-js@2";
import { body, json, svc } from "../_shared/common.ts";

Deno.serve(async (req) => {
  try {
    const b = await body(req);
    const auth = req.headers.get("Authorization") ?? "";
    if (!auth.startsWith("Bearer ")) return json(401, { error: "E_AUTH" });
    const asUser = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!,
                                { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
    const everywhere = b.everywhere === true;
    const { data, error } = await asUser.schema("api").rpc("v1_auth_sign_out", { p_everywhere: everywhere });
    if (error) return json(401, { error: "E_AUTH" });                 // the database verified the caller; sub below is trusted
    let native = 0;
    if (everywhere) {
      const seg = auth.slice(7).split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
      const payload = JSON.parse(atob(seg + "=".repeat((4 - (seg.length % 4)) % 4)));
      native = Number((await svc("v1_auth_kill_native_sessions", { p_auth_user: payload.sub })) ?? 0);
    }
    return json(200, { ...(data as Record<string, unknown>), native_sessions_ended: native });
  } catch (_e) {
    return json(400, { error: "E_AUTH" });
  }
});

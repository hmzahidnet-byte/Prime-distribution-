// POST {refresh_token, device_id} -> new access token + ROTATED refresh token. Replaying an old token revokes the session.
import { body, DEVICE_ID, json, mintAccessToken, svc } from "../_shared/common.ts";

Deno.serve(async (req) => {
  try {
    const b = await body(req);
    const deviceId = String(b.device_id ?? "");
    if (!DEVICE_ID.test(deviceId)) return json(401, { error: "E_SESSION_REVOKED" });
    const r = await svc("v1_auth_refresh", { p_refresh_token: String(b.refresh_token ?? ""), p_device_id: deviceId });
    if (r.ok !== true) return json(401, { error: "E_SESSION_REVOKED" });
    const t = await mintAccessToken(String(r.auth_user_id), String(r.session_id), Number(r.access_minutes ?? 15));
    return json(200, { access_token: t.token, expires_at: t.expiresAt, refresh_token: r.refresh_token, session_id: r.session_id, token_type: "pin" });
  } catch (_e) {
    return json(401, { error: "E_SESSION_REVOKED" });
  }
});

// POST {phone, pin, device_id, device_name, platform} -> {access_token, refresh_token, expires_at, session_id}
// The PIN is checked ONLY in the database (bcrypt, lockout, rate limit). Every failure has the same shape.
import { body, DEVICE_ID, json, mintAccessToken, svc } from "../_shared/common.ts";

Deno.serve(async (req) => {
  try {
    const b = await body(req);
    const deviceId = String(b.device_id ?? "");
    if (!DEVICE_ID.test(deviceId)) return json(401, { error: "E_AUTH_FAILED" });
    const r = await svc("v1_auth_pin_verify", {
      p_phone: String(b.phone ?? ""), p_pin: String(b.pin ?? ""), p_device_id: deviceId,
      p_device_name: String(b.device_name ?? "").slice(0, 80), p_platform: String(b.platform ?? "android"),
    });
    if (r.ok !== true) return json(401, { error: r.error ?? "E_AUTH_FAILED" });
    const t = await mintAccessToken(String(r.auth_user_id), String(r.session_id), Number(r.access_minutes ?? 15));
    return json(200, { access_token: t.token, expires_at: t.expiresAt, refresh_token: r.refresh_token, session_id: r.session_id,
                       refresh_expires_at: r.refresh_expires_at, token_type: "pin" });
  } catch (_e) {
    return json(401, { error: "E_AUTH_FAILED" });
  }
});

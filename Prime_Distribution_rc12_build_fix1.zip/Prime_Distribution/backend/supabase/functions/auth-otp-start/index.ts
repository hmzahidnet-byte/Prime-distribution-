// POST {phone} -> {allowed}. Gate in front of Supabase phone OTP: only invited or linked numbers (self sign-up stays
// disabled in Auth settings). For an invited number without an Auth user yet, the user is created unconfirmed here, so
// the app can call signInWithOtp({ phone, options: { shouldCreateUser: false } }).
import { body, json, serviceClient, svc } from "../_shared/common.ts";

Deno.serve(async (req) => {
  try {
    const b = await body(req);
    const r = await svc("v1_auth_otp_allowed", { p_phone: String(b.phone ?? "") });
    if (r.allowed !== true) return json(200, { allowed: false, retry_after_seconds: r.retry_after_seconds ?? null });
    const { error } = await serviceClient().auth.admin.createUser({ phone: String(r.phone).replace("+", ""), phone_confirm: false });
    if (error && !/already/i.test(error.message)) return json(200, { allowed: false });
    return json(200, { allowed: true, phone: r.phone });
  } catch (_e) {
    return json(400, { allowed: false });
  }
});

# Edge Functions (S16 লগইন) — চুক্তি ও স্থাপন

অবস্থা: লেখা হয়েছে, **স্থাপন/চালানো হয়নি** (মালিকের নিয়ম ৫)। অ্যাপে কোনো গোপন চাবি নেই; সব গোপন তথ্য শুধু Function-পরিবেশে।

| Function | অনুরোধ | উত্তর | ডাটাবেস |
|---|---|---|---|
| `auth-otp-start` | `{phone}` | `{allowed, phone}` | `svc.v1_auth_otp_allowed` — শুধু আমন্ত্রিত/সংযুক্ত নম্বর, হার-সীমা |
| `auth-pin-login` | `{phone, pin, device_id, device_name, platform}` | `{access_token, expires_at, refresh_token, session_id, token_type:"pin"}` বা `401 {error}` | `svc.v1_auth_pin_verify` — bcrypt, লক, হার-সীমা; সব ব্যর্থতা একই আকারে |
| `auth-pin-refresh` | `{refresh_token, device_id}` | নতুন access + ঘূর্ণিত refresh | `svc.v1_auth_refresh` — পুরোনো টোকেন আবার = পুরো সেশন বাতিল |
| `auth-sign-out` | `{everywhere}` + Bearer | `{pin_sessions_ended, native_sessions_ended}` | `api.v1_auth_sign_out` (ব্যবহারকারী হিসেবে) + `svc.v1_auth_kill_native_sessions` |

পরিবেশ: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` (প্ল্যাটফর্ম দেয়), `MOHONA_JWT_SECRET` = প্রকল্পের JWT secret (Legacy HS256)।
প্রকল্পে অসমমিত JWT-চাবি চালু থাকলে PIN-টোকেন বানাতে সেই চাবির ব্যবস্থা লাগবে (OI-24)।

Auth সেটিং: Phone provider চালু, **sign-up বন্ধ**; `auth-otp-start` আমন্ত্রিত নম্বরের জন্য অনিশ্চিত ব্যবহারকারী তৈরি করে, অ্যাপ `create_user:false` দিয়ে OTP চায়।
PIN-সেশন সবসময় `aal1` — চেয়ারম্যান/MFA-পদের কাজে Supabase MFA (TOTP) দিয়ে `aal2` সেশন লাগবে।

স্থাপন (শেষ ধাপে): `supabase functions deploy auth-otp-start auth-pin-login auth-pin-refresh auth-sign-out --no-verify-jwt`
(`auth-sign-out` নিজে ডাটাবেসে ব্যবহারকারীর টোকেন যাচাই করায়; বাকিগুলো লগইনের আগে ডাকা হয়)।

#!/usr/bin/env bash
# Applies every migration to an EMPTY, THROW-AWAY PostgreSQL and runs every SQL test file.
# Never point this at Staging or Production: it creates roles and expects an empty database.
#   PGURL=postgres://postgres:postgres@localhost:5432/mohona_test backend/ops/run_sql_tests.sh
set -uo pipefail
: "${PGURL:?set PGURL to a throw-away database}"
case "$PGURL" in *supabase.co*|*supabase.com*|*pooler*) echo "Refusing: this looks like a hosted Supabase database."; exit 2;; esac
OUT="${OUT_DIR:-sql-test-output}"; mkdir -p "$OUT"
MIG=backend/supabase/migrations; TESTS=backend/supabase/tests

if [ "$(psql "$PGURL" -At -c "select count(*) from pg_namespace where nspname in ('core','iam','api')")" != "0" ]; then
  echo "Refusing: the database is not empty (schemas core/iam/api exist)."; exit 2
fi
# the API roles Supabase provides (so the grant blocks in the migrations are exercised)
psql "$PGURL" -v ON_ERROR_STOP=1 -q -c "do \$\$ declare r text; begin foreach r in array array['anon','authenticated','service_role'] loop
  if not exists (select 1 from pg_roles where rolname = r) then execute format('create role %I nologin', r); end if; end loop; end \$\$;" || exit 1

echo "== migrations"
for f in $(ls "$MIG"/*.sql | sort); do
  if ! psql "$PGURL" -v ON_ERROR_STOP=1 -q -f "$f" > "$OUT/$(basename "$f").log" 2>&1; then
    echo "MIGRATION FAILED: $f"; tail -n 25 "$OUT/$(basename "$f").log"; echo "MIGRATION_FAILED|$(basename "$f")" > "$OUT/summary.txt"; exit 1
  fi
  echo "ok  $(basename "$f")"
done

echo "== tests"
: > "$OUT/results.txt"; errors=0
for t in $(ls "$TESTS"/*.sql | sort); do
  log="$OUT/$(basename "$t").log"
  if psql "$PGURL" -v ON_ERROR_STOP=1 -At -q -f "$t" > "$log" 2>&1; then
    grep '^RESULT|' "$log" >> "$OUT/results.txt" || true
  else
    errors=$((errors + 1)); echo "ERROR|$(basename "$t")|$(grep -m1 -E 'ERROR|error' "$log" | cut -c1-300)" >> "$OUT/results.txt"
  fi
done
pass=$(grep -c '^RESULT|[^|]*|PASS' "$OUT/results.txt" || true); fail=$(grep -c '^RESULT|[^|]*|FAIL' "$OUT/results.txt" || true)
echo "PASS=$pass FAIL=$fail ERROR_FILES=$errors" | tee "$OUT/summary.txt"
grep -E '^(RESULT\|[^|]*\|FAIL|ERROR\|)' "$OUT/results.txt" || true
[ "$fail" = "0" ] && [ "$errors" = "0" ]

#!/bin/bash
# Runs every migration and every SQL test against a local PostgreSQL (15+), exactly like .github/workflows/sql-tests.yml.
# Usage: PGHOST=localhost PGPORT=5432 PGUSER=postgres backend/ops/run_sql_local.sh [migrate | <test-name-part>]
# It DROPS and recreates the database "mohona_test" — never point it at a real database.
set -u
R=$(cd "$(dirname "$0")/../.." && pwd)
L=${LOG_DIR:-$R/.sqltest-logs}; rm -rf "$L"; mkdir -p "$L"
psql -q -d postgres -c "drop database if exists mohona_test" -c "create database mohona_test" >/dev/null || exit 2
export PGDATABASE=mohona_test
psql -q -v ON_ERROR_STOP=1 -c "do \$\$ begin
  if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if;
  if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if;
  if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin; end if; end \$\$" >/dev/null
n=0
for f in $(ls "$R"/backend/supabase/migrations/*.sql | sort); do
  n=$((n+1))
  if ! psql -v ON_ERROR_STOP=1 -q -f "$f" > "$L/migration_$(basename "$f").log" 2>&1; then
    echo "MIGRATION FAILED: $(basename "$f")"; grep -n "ERROR\|LINE\|CONTEXT" "$L/migration_$(basename "$f").log" | head -12; exit 1
  fi
done
echo "applied $n migrations"
[ "${1:-}" = "migrate" ] && exit 0
: > "$L/results.txt"; broken=0
for t in $(ls "$R"/backend/supabase/tests/t_*.sql | sort); do
  [ -n "${1:-}" ] && [[ "$(basename "$t")" != *"$1"* ]] && continue
  name=$(basename "$t")
  if psql -v ON_ERROR_STOP=1 -At -q -f "$t" > "$L/test_$name.log" 2>&1; then
    grep '^RESULT|' "$L/test_$name.log" >> "$L/results.txt" || true
    grep -q '^RESULT|' "$L/test_$name.log" || { broken=$((broken+1)); echo "NO RESULTS: $name"; }
  else
    broken=$((broken+1)); echo "STOPPED: $name"; grep -m3 "ERROR\|CONTEXT" "$L/test_$name.log" | cut -c1-300
  fi
done
echo "passed=$(grep -c '|PASS|' "$L/results.txt") failed=$(grep -c '|FAIL|' "$L/results.txt") broken=$broken"
grep '|FAIL|' "$L/results.txt" | head -40
[ "$(grep -c '|FAIL|' "$L/results.txt")" = "0" ] && [ "$broken" = "0" ]

-- Privilege probe (v1 baseline, S02+). Run AFTER all migrations on Staging.
-- Tries forbidden actions as anon / authenticated / service_role; records whether each was DENIED.
-- PASS = every probe denied=true and holes = 0. Any 'false' = a hole (stop and report).
create temp table if not exists spike_s2 (probe text, role_name text, denied boolean, detail text);
create or replace function pg_temp.probe(p_role text, p_sql text, p_label text) returns void language plpgsql as $$
declare v_denied boolean := false; v_detail text := 'executed without error';
begin
  begin
    execute format('set local role %I', p_role);
    execute p_sql;
  exception when others then v_denied := true; v_detail := sqlerrm;
  end;
  reset role;
  insert into spike_s2 values (p_label, p_role, v_denied, v_detail);
end $$;
do $$
declare r text;
begin
  foreach r in array array['anon','authenticated','service_role'] loop
    perform pg_temp.probe(r, 'select * from core.company limit 1', 'select core.company');
    perform pg_temp.probe(r, $$insert into core.company (code, name_bn) values ('SPIKE','x')$$, 'insert core.company');
    perform pg_temp.probe(r, 'select * from core.wing limit 1', 'select core.wing');
    perform pg_temp.probe(r, 'select * from audit.event limit 1', 'select audit.event');
    perform pg_temp.probe(r, 'select audit.fn_append(gen_random_uuid(), ''spike'')', 'execute audit.fn_append');
    perform pg_temp.probe(r, 'select core.fn_raise(''E_SPIKE'')', 'execute core.fn_raise');
  end loop;
end $$;
select * from spike_s2 order by role_name, probe;
select count(*) filter (where not denied) as holes from spike_s2;   -- PASS requires holes = 0

# STATE — Mohona Enterprise OS (নতুন চ্যাটে প্রথমে এটি পড়ুন)

**সর্বশেষ সম্পন্ন ধাপ:** S71 — দ্বিতীয় পূর্ণ A–Z পাস: ৪২টি ফাঁক পূরণ, ৫৭ migration, ৬৭৩ PASS (`docs/V180_AZ_STATUS_BN.md`) · **পরের কাজ:** GitHub-এ "Android Debug APK" (প্রথম কম্পাইল) ও "SQL Tests"; তারপর staging, Supabase, Drive-ব্যাকআপ মহড়া। নতুন migration-এর নাম `20261108009900_lookup_refresh.sql`-এর আগে; বদলের পর `backend/ops/run_sql_local.sh` চালিয়ে সব পাস নিশ্চিত করুন ·  **পরের কাজ:** OI-54 — GitHub-এ “SQL Tests” ও “Android Debug APK” সবুজ করা; তারপর সার্ভার-ডিপ্লয়। নির্দেশিকা `docs/RELEASE_RUNBOOK_BN.md`, সিদ্ধান্ত `docs/PRIME_V180_DECISIONS_BN.md`
**ব্লুপ্রিন্ট:** লক v179 (SHA `909cbd0d66946677f5136c9b22e8f4cc3d23d03d5731aa46738ceb245e4c0540`) — সম্পাদনা নয়। কাজের জন্য প্রয়োজনীয় সারাংশ এই ZIP-এ: `docs/blueprint/`।

## Claude-এর জন্য কাজের নিয়ম (মালিকের নির্দেশ, স্থায়ী)
1. মালিক শুধু ZIP সংযুক্ত করে "next" বলবেন → এই ফাইল পড়ে পরের ধাপ সরাসরি শুরু। কোনো প্রশ্ন নয়, কোনো সিদ্ধান্ত চাওয়া নয়।
2. **সব অপশন অ্যাপে** (অপারেটিং-সিস্টেমের মতো); একাধিক পথ = সবগুলো Chairman-সেটিং (`config.setting_definition`), সেরা ডিফল্টসহ। Chairman সর্বোচ্চ; কোনো ক্ষমতার সীমা নেই — শুধু ৩টি সুরক্ষা স্থির: অডিট অমোছনীয়, পোস্ট-হওয়া হিসাব শুধু বাতিল/সংশোধন, জার্নাল ব্যালান্স।
3. বর্জিত: VAT/Tax, CCTV, AI/স্বয়ংক্রিয়-ইঞ্জিন, Group Chairman। শুধু বাংলা, Light থিম। Kotlin/Compose + Supabase।
4. **বড় ধাপ** (প্রতি ধাপে ~২,৫০০–৩,০০০ লাইন: Migration + RPC + SQL-Test + Android Repository/Test + নথি)। বাড়তি বার্তা নয়; উত্তর ১–২ লাইন বাংলায় + ZIP।
5. **Compile/চালানো শুধু সব শেষে** (মালিকের নির্দেশ)। প্রতিটি ধাপে এখানে চালানো যায় এমন যাচাই অবশ্যই: `python3 backend/ops/mohona_ops.py write-layout && MANIFEST_OUT=/tmp/m.json python3 backend/ops/mohona_ops.py static && python3 backend/ops/test_mohona_ops.py`
6. প্রতিটি ধাপ শেষে: `STATE.md` হালনাগাদ, `docs/blueprint/FEATURE_INDEX.csv`-এ ফিচারের status/implemented_in, `CHECKPOINT_STATUS.md`, `backend/ops/expected.json` (স্ক্রিপ্টে পুনঃউৎপাদন), `SHA256_MANIFEST.json`, ZIP: `Mohona_Enterprise_OS_Checkpoint_SNN.zip` (ভেতরে রুটে STATE.md)।

## কোডের প্রথা (মেনে চলতে হবে)
- স্কিমা: core, iam, config, design, audit, finance, inventory, mfg, procurement, sales, hr, report, notify, location, hardware, api (অ্যাপ), svc (প্ল্যাটফর্ম)।
- প্রতিটি নতুন টেবিল: company_id + composite FK (id, company_id), মোছা নিষেধ/স্ট্যাটাস, audit-trigger (`audit.fn_row_change`), Migration শেষে `core.fn_apply_rls(schema, table)` ও `select core.fn_assert_rls_everywhere();`।
- প্রতিটি RPC: `api.v1_<module>_<verb>`, SECURITY DEFINER, `set search_path = ''`, শুরুতে `iam.fn_require(permission, iam.fn_resource(...), lock)`, কারণ বাধ্যতামূলক যেখানে প্রযোজ্য, `set_config('mohona.change_reason', ...)`, ত্রুটি `core.fn_raise('E_CODE', ...)` (নতুন E_ কোড অ্যাপের `ErrorCatalog`-এ যোগ — Test যাচাই করে)।
- অনুমতি-কোড: `iam.permission_catalog`-এ `registered` থাকে; মডিউল তৈরির ধাপে `active` + ডিফল্ট নিয়ম (`iam.permission_template_rule` + `iam.fn_backfill_template_rules()`); `docs/plan/DEFAULT_PERMISSION_TEMPLATES.csv` দেখুন।
- সেটিং পড়া: `config.fn_get_int/bool/text/text_array(company, key)`; ফিচার-সুইচ: `config.fn_flag(company, key, wing)`।
- ডকুমেন্ট পোস্টিংয়ে: `core.fn_next_number(company, 'module.doc')`, `core.fn_idem_begin/finish`, অনুমোদন `core.fn_approval_submit(...)` / `core.fn_approval_status(...)`।
- নিয়ম: অনুমোদন-ইভেন্টে Rule Studio স্বয়ংক্রিয় (`config.fn_rules_evaluate`); নতুন অনুমোদন-হ্যান্ডলার = `core.fn_approval_apply` create or replace-এ CASE যোগ (S44 সংস্করণে আগের সব CASE আছে — রাখতে হবে)।
- অনুমতি-প্রদান: নতুন অনুমতি-কোড যোগ করলে `select iam.fn_seed_permission_dependencies();` (x.y.* → x.y.read); প্রদান-ট্রিগার নির্ভরতা ও SoD যাচাই করে (টেমপ্লেট-পথ ছাড়)। সংবেদনশীল কর্মী-তথ্য (বেতন) `hr.fn_salary_view` দিয়ে পড়ুন।
- Android: নতুন পর্দা `ui/navigation/AppNavigation.kt`-এ রুট; অনুমতি-ইঙ্গিত `LocalPermissions`/`IfCan`; শেল-কনফিগ `api.v1_ui_config`।
- হিসাব: মডিউল-জার্নাল `finance.fn_emit(company, source_key, memo, lines[{key, dr|cr}])` — ম্যাপিং-কী দিয়ে, পুনরাবৃত্তিহীন; ব্যর্থ হলে লেনদেন আটকায় না (gl_event = error)।
- উৎপাদন: WIP `mfg.wip_entry` (সমাপ্তিতে যোগফল শূন্য), FG-পোস্ট `mfg.fn_post_fg` (ADR-11)।
- ক্রয়: নথি জমা `procurement.fn_submit` (অনুমোদন-ইঞ্জিন; সঙ্গে সঙ্গে অনুমোদিত হলে প্রয়োগ); দেনা `procurement.fn_bill_open` (শুধু পোস্ট-করা)।
- মজুদ: প্রতিটি মজুদ-পরিবর্তন শুধু `inventory.fn_post_move` দিয়ে (চলমান গড়, ঋণাত্মক নয়, নথি-লাইন একবার); গ্রহণ `inventory.fn_post_receipt`; বাছাই `inventory.fn_fefo`; ব্যবহারযোগ্য `inventory.fn_available`।
- পণ্য: নতুন লেনদেনের আগে `inventory.fn_product_usable`; ব্যাচ/BOM/বিক্রয় POLY-স্পেক নেয় `inventory.fn_pack_spec_snapshot` দিয়ে, রূপান্তর `inventory.fn_convert`; প্রথম পোস্টে `inventory.fn_lock_variant`।
- কাঠামো: গুদাম `inventory.warehouse` (WAREHOUSE-পরিধি চালু); এলাকা `location.admin_area` (কোড DD.DD.DDD.DDD)।
- নোটিফিকেশন: `notify.fn_send(company, person, template, vars, link_kind, link_id, dedupe_key)` — লেখায় টাকা/মান নয়; নতুন অনুমোদন-নীতি `api.v1_policy_propose`।
- লগইন: প্রতিটি RPC-র প্রথমে `iam.fn_require_person()` (এখন সেশন-জীবন্ততাও যাচাই করে); নতুন svc-ফাংশন হলে `service_role`-কে grant দিতে ভুলবেন না।
- মাস্কিং: সংবেদনশীল মান পড়ার RPC-তে `config.fn_mask_apply('<module>.<entity>.<field>', value, export)`; সংবেদনশীল টেবিলে `audit.fn_row_change` নয় — মানহীন নিজস্ব অডিট (S14 `config.fn_form_submission_track` দেখুন)।
- মডিউল তৈরির ধাপে: `select config.fn_make_module_available('<module>');` + অনুমতি `active` — মডিউল-গেট (`config.fn_module_gate`) `iam.fn_authorize`-এ স্বয়ংক্রিয়।
- লেখার RPC: `iam.fn_context(true)` লক-ক্রম (company → membership → assignment → employment → grants → domain)।
- SQL-Test: `backend/supabase/tests/t_sNN_*.sql`, ফলাফল `RESULT|ID|PASS|note`, সহায়ক `pg_temp.as_user(uuid, session, aal default 'aal2')` (MFA-পদ)।

## ফাইল-মানচিত্র
- `docs/plan/STEP_PLAN_BN.md` — ধাপ-পরিকল্পনা v2 (S10–S55)
- `docs/blueprint/FEATURE_INDEX.csv` — ৩০০ ফিচার → ধাপ → অবস্থা; প্রতিটির স্পেক `docs/blueprint/features/`
- `docs/blueprint/adr/` — V179 ADR-01..13 (লক নীতি); `docs/blueprint/v176/` — ২৪ ক্রস-কাটিং চুক্তি; `docs/blueprint/core/` — COA, GL-ম্যাপিং, WAC, পোস্টিং, ইনভ্যারিয়েন্ট; `docs/blueprint/geo/` — বাংলাদেশ প্রশাসনিক-এলাকা (অযাচাইকৃত)
- `docs/RECYCLE_BIN_BN.md` (নতুন রেকর্ড-শ্রেণির চুক্তি) · `backend/supabase/functions/README_BN.md` (লগইন Edge Function-চুক্তি) · `docs/FORMS_BN.md` (ডায়নামিক ফর্ম/মাস্কিং) · `docs/plan/DECISION_REGISTER_BN.md` · `docs/CHAIRMAN_SETTINGS_BN.md` · `docs/plan/OPEN_ITEMS_BN.md` · `docs/IAM_MODEL_BN.md` · `docs/SECURITY_MODEL_BN.md`
- `docs/V180_TRACE_BN.md` — v180 কুরিয়ার + Prime 00–10 → কোড → পরীক্ষা (গেট ৯)
- `tools/`: `update_expected.py` (expected.json SQL থেকে পুনর্গণনা; নতুন টেস্ট-ফাইল: `--add FILE CATEGORY`), `add_actions.py` (নতুন api.v1_* → অ্যাপের কাজের ফর্ম),
  `gen_lookup.py` (api.v1_lookup + `assets/lookup_kinds.json` একসাথে; হাতে সম্পাদনা নয়), `bn_labels.py` (ফর্মের ঘর বাংলায়)
- `backend/supabase/migrations/` (প্রামাণিক) · `backend/supabase/tests/` · `backend/ops/` (static gate) · `app/` (Android)

## অবস্থা
Migration ৫৭টি · SQL-Test ৪৪ ফাইল (৬৭৩টি ফলাফল, সব PASS — আসল PostgreSQL 16-এ চালানো) · Edge Function ৪টি (স্থাপিত নয়) · কোনো SQL/Kotlin চালানো হয়নি (নিয়ম ৫)।

#!/usr/bin/env python3
"""Generates backend/supabase/migrations/20261108004100_lookup_pickers.sql (api.v1_lookup) and app assets/lookup_kinds.json
from one spec, so the server kinds and the app's parameter -> kind map never drift apart."""
import json, os, re
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
# kind, permission, from (alias t, company filter on t.company_id), label, sub, order (expression, desc?)
def PH(key, col): return "coalesce(config.fn_mask_apply('" + key + "', to_jsonb(" + col + ")) #>> '{}', '')"
K = [
 ('product', 'master.sku.read', 'inventory.product t', "t.sku || ' · ' || t.name_bn", 't.kind', ('t.name_bn', False)),
 ('variant', 'master.sku.read', 'inventory.product_variant t join inventory.product p on p.id = t.product_id', "t.code || ' · ' || coalesce(t.name_bn, p.name_bn)", 'p.name_bn', ('t.code', False)),
 ('price_list', 'master.sku.read', 'inventory.price_list t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('warehouse', 'inventory.stock.read', 'inventory.warehouse t', "t.code || ' · ' || t.name_bn", 't.kind', ('t.code', False)),
 ('lot', 'inventory.stock.read', 'inventory.lot t join inventory.product p on p.id = t.product_id', "t.lot_no || ' · ' || p.name_bn", "'মেয়াদ ' || coalesce(t.expiry_date::text, '—') || ' · ' || t.status", ('t.received_at', True)),
 ('transfer', 'inventory.stock.read', 'inventory.transfer t', 't.number', 't.status', ('t.created_at', True)),
 ('count', 'inventory.stock.read', 'inventory.count_session t', 't.number', 't.status', ('t.started_at', True)),
 ('dealer', 'crm.dealer.read', 'sales.dealer t', "t.code || ' · ' || t.name_bn", PH('sales.contact.phone', 't.phone'), ('t.name_bn', False)),
 ('retailer', 'crm.dealer.read', 'sales.retailer t', "t.code || ' · ' || t.name_bn", PH('sales.contact.phone', 't.phone'), ('t.name_bn', False)),
 ('territory', 'crm.dealer.read', 'sales.territory t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('route', 'crm.dealer.read', 'sales.route t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('route_plan', 'crm.dealer.read', 'sales.route_plan t join sales.route r on r.id = t.route_id', "t.plan_date::text || ' · ' || r.name_bn", 't.status', ('t.plan_date', True)),
 ('visit', 'crm.dealer.read', 'sales.dealer_visit t left join sales.dealer d on d.id = t.dealer_id', "t.planned_date::text || ' · ' || coalesce(d.name_bn, '—')", 't.status', ('t.planned_date', True)),
 ('order', 'crm.dealer.read', 'sales.sales_order t join sales.dealer d on d.id = t.dealer_id', "coalesce(t.number, '—') || ' · ' || d.name_bn", "t.status || ' · ৳' || t.total", ('t.created_at', True)),
 ('invoice', 'crm.dealer.read', 'sales.invoice t join sales.dealer d on d.id = t.dealer_id', "t.number || ' · ' || d.name_bn", "'৳' || t.total || ' · ' || t.invoice_date", ('t.invoice_date', True)),
 ('dispatch', 'crm.dealer.read', 'sales.dispatch t', "coalesce(t.number, '—')", "coalesce(t.vehicle, '') || ' ' || t.dispatched_at::date", ('t.dispatched_at', True)),
 ('collection', 'crm.dealer.read', 'sales.collection t join sales.dealer d on d.id = t.dealer_id', "coalesce(t.number, '—') || ' · ' || d.name_bn", "t.method || ' · ৳' || t.amount || ' · ' || t.status", ('t.collected_at', True)),
 ('party', 'master.party.read', 'sales.party t', "t.code || ' · ' || t.name_bn", PH('sales.contact.phone', 't.phone'), ('t.name_bn', False)),
 ('supplier', 'master.supplier.read', 'procurement.supplier t', "t.code || ' · ' || t.name_bn", PH('procurement.supplier.phone', 't.phone'), ('t.name_bn', False)),
 ('pr', 'procurement.read', 'procurement.pr t', "coalesce(t.number, '—')", 't.status', ('t.created_at', True)),
 ('po', 'procurement.read', 'procurement.po t join procurement.supplier s on s.id = t.supplier_id', "coalesce(t.number, '—') || ' · ' || s.name_bn", "t.status || ' · ৳' || t.total", ('t.created_at', True)),
 ('grn', 'procurement.read', 'procurement.grn t', "coalesce(t.number, '—')", 't.received_at::date::text', ('t.received_at', True)),
 ('bill', 'procurement.read', 'procurement.bill t join procurement.supplier s on s.id = t.supplier_id', "coalesce(t.number, '—') || ' · ' || s.name_bn", "t.status || ' · ৳' || t.total", ('t.created_at', True)),
 ('batch', 'mfg.bom.read', 'mfg.batch t join inventory.product p on p.id = t.product_id', "coalesce(t.number, '—') || ' · ' || p.name_bn", 't.kind', ('t.number', True)),
 ('bom', 'mfg.bom.read', 'mfg.bom t join inventory.product p on p.id = t.product_id', "p.name_bn || ' · v' || t.version", 't.status', ('t.created_at', True)),
 ('plan', 'mfg.bom.read', 'mfg.plan t', 't.plan_date::text', 't.status', ('t.plan_date', True)),
 ('machine', 'mfg.bom.read', 'mfg.machine t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('shipment', 'courier.read', 'sales.shipment t join sales.dealer d on d.id = t.dealer_id', "t.number || ' · ' || d.name_bn", "t.destination || ' · ' || t.status", ('t.dispatched_at', True)),
 ('provider', 'courier.read', 'sales.courier_provider t', "t.code || ' · ' || t.name_bn", PH('sales.contact.phone', 't.phone'), ('t.name_bn', False)),
 ('courier_collection', 'courier.read', 'sales.courier_collection t join sales.shipment s on s.id = t.shipment_id', "s.number || ' · ৳' || t.collected_amount", 't.status', ('t.collected_at', True)),
 ('remittance', 'courier.read', 'sales.courier_remittance t join sales.courier_provider p on p.id = t.provider_id', "p.name_bn || ' · ৳' || t.amount", "t.method || ' · ' || t.status", ('t.posted_at', True)),
 ('condition_change', 'courier.read', 'sales.condition_change t join sales.shipment s on s.id = t.shipment_id', "s.number || ' · ৳' || t.old_amount || ' → ৳' || t.proposed_amount", 't.state', ('t.created_at', True)),
 ('settlement', 'courier.read', 'sales.courier_settlement t join sales.shipment s on s.id = t.shipment_id', "s.number || ' · ' || t.kind || ' · ৳' || t.amount", 't.status', ('t.created_at', True)),
 ('dispute', 'courier.read', 'sales.shipment_dispute t join sales.shipment s on s.id = t.shipment_id', "s.number || ' · ' || t.kind", 't.status', ('t.opened_at', True)),
 ('employee', 'hr.employee.read', 'hr.employee t join core.person p on p.id = t.person_id', "t.employee_code || ' · ' || p.full_name_bn", PH('hr.person.phone', 'p.phone'), ('p.full_name_bn', False)),
 ('person', 'hr.employee.read', 'iam.company_membership t join core.person p on p.id = t.person_id', 'p.full_name_bn', "coalesce(t.employee_no, '') || ' · ' || t.status", ('p.full_name_bn', False), 'p.id'),
 ('membership', 'hr.employee.read', 'iam.company_membership t join core.person p on p.id = t.person_id', 'p.full_name_bn', "coalesce(t.employee_no, '') || ' · ' || t.status", ('p.full_name_bn', False)),
 ('assignment', 'iam.position.read', 'iam.position_assignment t join iam.company_membership m on m.id = t.membership_id join core.person p on p.id = m.person_id', "p.full_name_bn || ' · ' || t.position_code", 't.status', ('p.full_name_bn', False)),
 ('payroll_run', 'hr.payroll.read', 'hr.payroll_run t', "coalesce(t.number, '—') || ' · ' || t.period", "t.kind || ' · ' || t.status", ('t.period', True)),
 ('leave', 'hr.attendance.read', 'hr.leave_request t join hr.employee e on e.id = t.employee_id join core.person p on p.id = e.person_id', "p.full_name_bn || ' · ' || t.date_from", "t.leave_code || ' · ' || t.status", ('t.created_at', True)),
 ('shift', 'hr.attendance.read', 'hr.shift t', "t.code || ' · ' || t.name_bn", "t.start_time || '–' || t.end_time", ('t.code', False)),
 ('wing', 'core.structure.read', 'core.wing t', "t.code || ' · ' || t.name_bn", 't.wing_kind', ('t.sort_order', False)),
 ('department', 'core.structure.read', 'core.department t', "t.code || ' · ' || t.name_bn", 't.status', ('t.sort_order', False)),
 ('location', 'core.structure.read', 'core.location t', "t.code || ' · ' || t.name_bn", 't.location_kind', ('t.code', False)),
 ('cash_account', 'finance.ledger.read', 'finance.cash_account t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('bank_account', 'finance.ledger.read', 'finance.bank_account t', "t.code || ' · ' || t.bank_name", 't.account_masked', ('t.code', False)),
 ('journal', 'finance.ledger.read', 'finance.journal t', "coalesce(t.number, '—') || ' · ' || t.journal_date", "coalesce(t.memo, '') || ' · ' || t.status", ('t.created_at', True)),
 ('bank_line', 'finance.ledger.read', 'finance.bank_statement_line t', "t.txn_date || ' · ৳' || t.amount", "coalesce(t.reference, '') || ' ' || coalesce(t.description, '')", ('t.txn_date', True)),
 ('money_request', 'finance.ledger.read', 'finance.money_request t', "coalesce(t.number, '—') || ' · ৳' || t.amount", "t.kind || ' · ' || t.status", ('t.created_at', True)),
 ('approval', 'approval.inbox.read', 'core.approval_request t', "t.document_type || coalesce(' · ৳' || t.amount, '')", 't.status', ('t.created_at', True)),
 ('form', 'forms.form.read', 'config.form t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('submission', 'forms.form.read', 'config.form_submission t join config.form f on f.id = t.form_id', "coalesce(t.number, '—') || ' · ' || f.name_bn", 't.status', ('t.created_at', True)),
 ('rule', 'config.settings.read', 'config.rule t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('dealer_request', 'crm.dealer.read', 'sales.dealer_order_request t join sales.dealer d on d.id = t.dealer_id', "d.name_bn || ' · ' || t.created_at::date", 't.status', ('t.created_at', True)),
 ('dealer_notice', 'dealer.notice.manage', 'sales.dealer_notice t', "t.title_bn", "t.kind || ' · ' || t.status", ('t.created_at', True)),
 ('market', 'crm.dealer.read', 'sales.market t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('market_assignment', 'crm.dealer.read', 'sales.market_assignment t join sales.market m on m.id = t.market_id join sales.dealer d on d.id = t.dealer_id', "m.code || ' → ' || d.name_bn", "t.status || ' · ' || t.valid_from", ('t.created_at', True)),
 ('vacancy', 'hr.recruit.manage', 'hr.vacancy t', "t.title_bn", "t.position_code || ' · ' || t.status", ('t.created_at', True)),
 ('applicant', 'hr.recruit.manage', 'hr.applicant t', "t.full_name_bn", 't.status', ('t.created_at', True)),
 ('offer', 'hr.recruit.manage', 'hr.offer t join hr.applicant a on a.id = t.applicant_id', "a.full_name_bn", "t.status || ' · ' || t.join_date", ('t.join_date', True)),
 ('location_claim', 'crm.dealer.read', 'sales.location_claim t', "t.owner_kind || ' · ' || coalesce(t.address_bn, t.latitude::text)", 't.status', ('t.created_at', True)),
 ('dispute', 'crm.dealer.read', 'sales.dispute t join sales.dealer d on d.id = t.dealer_id', "d.code || ' · ' || t.subject_type", 't.status', ('t.created_at', True)),
 ('outlet', 'crm.dealer.read', 'sales.dealer_outlet t', "t.code || ' · ' || t.name_bn", 't.status', ('t.code', False)),
 ('machine_service', 'mfg.machine.manage', 'mfg.machine_service_plan t join mfg.machine m on m.id = t.machine_id', "m.code || ' · ' || t.task_bn", 't.status', ('t.task_bn', False)),
 ('theme', 'config.settings.read', 'design.theme t', "t.code || ' · ' || t.name_bn", "case when t.is_active then 'চালু' else '' end", ('t.code', False)),
]
# parameter name -> kind (the app shows a search list instead of a raw id field)
P = {'p_product_id': 'product', 'p_variant_id': 'variant', 'p_price_list_id': 'price_list', 'p_warehouse_id': 'warehouse', 'p_source_warehouse': 'warehouse',
 'p_raw_warehouse': 'warehouse', 'p_fg_warehouse': 'warehouse', 'p_lot_id': 'lot', 'p_fg_lot_id': 'lot', 'p_transfer_id': 'transfer', 'p_count_id': 'count',
 'p_dealer_id': 'dealer', 'p_retailer_id': 'retailer', 'p_territory_id': 'territory', 'p_route_id': 'route', 'p_route_plan_id': 'route_plan', 'p_visit_id': 'visit',
 'p_order_id': 'order', 'p_invoice_id': 'invoice', 'p_dispatch_id': 'dispatch', 'p_collection_id': 'collection', 'p_party_id': 'party', 'p_supplier_id': 'supplier',
 'p_default_supplier': 'supplier', 'p_pr_id': 'pr', 'p_po_id': 'po', 'p_grn_id': 'grn', 'p_bill_id': 'bill', 'p_batch_id': 'batch', 'p_bom_id': 'bom', 'p_plan_id': 'plan',
 'p_shipment_id': 'shipment', 'p_provider_id': 'provider', 'p_remittance_id': 'remittance', 'p_change_id': 'condition_change', 'p_settlement_id': 'settlement',
 'p_dispute_id': 'dispute', 'p_employee_id': 'employee', 'p_manager_employee_id': 'employee', 'p_person_id': 'person', 'p_officer_id': 'person', 'p_custodian': 'person', 'p_to_person': 'person',
 'p_membership_id': 'membership', 'p_to_membership': 'membership', 'p_assignment_id': 'assignment', 'p_substitute_assignment': 'assignment',
 'p_delegate_assignment': 'assignment', 'p_absent_assignment': 'assignment', 'p_run_id': 'payroll_run', 'p_shift_id': 'shift', 'p_wing_id': 'wing', 'p_to_wing_id': 'wing',
 'p_home_wing': 'wing', 'p_wing': 'wing', 'p_department_id': 'department', 'p_to_department_id': 'department', 'p_home_department': 'department', 'p_location_id': 'location',
 'p_to_location_id': 'location', 'p_home_location': 'location', 'p_cash_account_id': 'cash_account', 'p_bank_account_id': 'bank_account', 'p_journal_id': 'journal',
 'p_reversal_of': 'journal', 'p_bank_line_id': 'bank_line', 'p_statement_line_id': 'bank_line', 'p_request_id': 'approval', 'p_form_id': 'form',
 'p_submission_id': 'submission', 'p_rule_id': 'rule', 'p_theme_id': 'theme', 'p_machine_id': 'machine', 'p_order_request_id': 'dealer_request', 'p_notice_id': 'dealer_notice', 'p_vacancy_id': 'vacancy', 'p_applicant_id': 'applicant', 'p_offer_id': 'offer', 'p_claim_id': 'location_claim', 'p_dispute_id': 'dispute', 'p_outlet_id': 'outlet', 'p_plan_id': 'plan', 'p_from_market': 'market', 'p_into_market': 'market', 'p_market_id': 'market', 'p_assignment_id_m': 'market_assignment'}
kinds = {k[0] for k in K}
assert all(v in kinds for v in P.values()), [v for v in P.values() if v not in kinds]

MIG = os.path.join(ROOT, 'backend/supabase/migrations')
BASE = '20261108004100_lookup_pickers.sql'; REFRESH = '20261108009900_lookup_refresh.sql'   # always the last migration
created = {}
for n in sorted(os.listdir(MIG)):
    if n.endswith('.sql') and n not in (BASE, REFRESH):
        for m in re.finditer(r'create\s+table\s+([a-z_]+\.[a-z_0-9]+)', open(os.path.join(MIG, n), encoding='utf-8').read(), re.I):
            created.setdefault(m.group(1).lower(), n)

def render(kinds, title, create_kw):
    br = []
    for spec in kinds:
        kind, perm, frm, label, sub, (ordx, desc) = spec[:6]; idx = spec[6] if len(spec) > 6 else 't.id'
        br.append(f"""  elsif p_kind = '{kind}' then
    return coalesce((select jsonb_agg(jsonb_build_object('id', x.id, 'label', x.label, 'sub', x.sub)) from (
      select {idx} id, {label} label, {sub} sub from {frm}
       where t.company_id = c and (q is null or ({label}) ilike q or coalesce({sub}, '') ilike q)
       order by {ordx}{' desc' if desc else ''} nulls last limit n) x), '[]'::jsonb);""")
    perm_case = '\n'.join(f"    when '{k[0]}' then '{k[1]}'" for k in kinds)
    return f"""-- {title} — generated by tools/gen_lookup.py, do not edit by hand
-- api.v1_lookup(kind, query, limit) -> [{{id, label, sub}}] of the CURRENT company only, behind the same read permission as the
-- module's own lists (company-wide resource: a person whose right is narrower gets the server's refusal and types the id instead).
-- Phone numbers go through config.fn_mask_apply (Chairman's masking policy per position: sales.contact.phone,
-- procurement.supplier.phone, hr.person.phone).
-- Search: words in the label or the second line (ilike, %-wrapped); 20 rows by default, 50 at most. Nothing is written.
-- STATUS: WRITTEN, NOT EXECUTED.
set role erp_owner;

{create_kw} api.v1_lookup(p_kind text, p_query text default null, p_limit integer default 20) returns jsonb
language plpgsql volatile security definer set search_path = '' as $$
declare me record; c uuid; n integer := least(greatest(coalesce(p_limit, 20), 1), 50);
        q text := case when length(btrim(coalesce(p_query, ''))) = 0 then null
                       else '%' || replace(replace(replace(btrim(p_query), '\\', '\\\\'), '%', '\\%'), '_', '\\_') || '%' end;
        v_perm text;
begin
  v_perm := case p_kind
{perm_case}
  end;
  if v_perm is null then perform core.fn_raise('E_INVALID_ACTION', 'unknown list'); end if;
  select * into me from iam.fn_require(v_perm, iam.fn_my_company_resource(), false);
  c := me.company_id;
  if false then return null;
{chr(10).join(br)}
  end if;
  return '[]'::jsonb;
end $$;

reset role;
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    grant execute on function api.v1_lookup(text, text, integer) to authenticated;
  end if;
end $$;
"""

base_k = [k for k in K if all(created.get(t, '0') < BASE for t in re.findall(r'([a-z_]+\.[a-z_0-9]+) [a-z]\b', k[2]))]
open(os.path.join(MIG, BASE), 'w', encoding='utf-8').write(render(base_k, '20261108004100_lookup_pickers.sql  (S60 — search lists instead of typing ids)', 'create function'))
open(os.path.join(MIG, REFRESH), 'w', encoding='utf-8').write(render(K, '20261108009900_lookup_refresh.sql  (S66–S67 — all list kinds, including tables added after S60)', 'create or replace function'))
print('base kinds', len(base_k))

json.dump({'version': 1, 'params': P}, open(os.path.join(ROOT, 'app/src/main/assets/lookup_kinds.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1, sort_keys=True)
print('kinds', len(K), 'params', len(P))

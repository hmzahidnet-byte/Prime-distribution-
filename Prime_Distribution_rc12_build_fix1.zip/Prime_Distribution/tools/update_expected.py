#!/usr/bin/env python3
"""Recounts backend/ops/expected.json from the SQL text (tables, functions, api functions, test ids). Usage:
   python3 tools/update_expected.py [--check] [--add FILE CATEGORY]   (new test ids of FILE go to CATEGORY; negatives = ids whose
   line contains expect_fail)."""
import json, os, re, sys
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
MIG = os.path.join(ROOT, 'backend/supabase/migrations'); TST = os.path.join(ROOT, 'backend/supabase/tests'); EXP = os.path.join(ROOT, 'backend/ops/expected.json')
def strip(sql): return re.sub(r'--[^\n]*', '', sql)
tables, funcs, schemas = set(), set(), set()
for n in sorted(os.listdir(MIG)):
    if not n.endswith('.sql'): continue
    s = strip(open(os.path.join(MIG, n), encoding='utf-8').read())
    for m in re.finditer(r'create\s+table\s+(?:if\s+not\s+exists\s+)?([a-z_]+)\.([a-z_0-9]+)', s, re.I): tables.add((m.group(1) + '.' + m.group(2)).lower())
    for m in re.finditer(r'create\s+(?:or\s+replace\s+)?function\s+([a-z_]+)\.([a-z_0-9]+)\s*\(([^)]*)\)', s, re.I):
        funcs.add((m.group(1) + '.' + m.group(2)).lower())
    for m in re.finditer(r'create\s+schema\s+(?:if\s+not\s+exists\s+)?([a-z_]+)', s, re.I): schemas.add(m.group(1).lower())
e = json.load(open(EXP, encoding='utf-8'))
print('tables', len(tables), 'expected', len(e['tables']), 'diff', sorted(tables ^ set(e['tables']))[:10])
print('functions', len(funcs), 'expected', len(e['functions']), 'diff', sorted(funcs ^ set(e['functions']))[:10])
if '--check' in sys.argv: sys.exit(0)
if '--add' in sys.argv:
    i = sys.argv.index('--add'); fn, cat = sys.argv[i + 1], sys.argv[i + 2]
    text = open(os.path.join(TST, fn), encoding='utf-8').read()
    ids = sorted(set(re.findall(r"insert into _r values \('([A-Z0-9]+-[0-9]+)'", text)))
    e['test_files'][fn] = ids
    for t in ids: e['tests'][t] = 1
    e['categories'][cat] = ids
    neg = set(e['negative_ids'])
    for blk in re.split(r"(?=insert into _r values \(')", text):
        mm = re.match(r"insert into _r values \('([A-Z0-9]+-[0-9]+)'", blk)
        if mm and 'expect_fail' in blk.split(';')[0]: neg.add(mm.group(1))
    e['negative_ids'] = sorted(neg)
    if cat not in e['required_categories'] and isinstance(e['required_categories'], list): e['required_categories'].append(cat)
e['tables'] = e['tables'] + sorted(tables - set(e['tables'])); e['functions'] = sorted(funcs); e['function_count'] = len(funcs)
e['api_functions'] = sorted(f.split('.', 1)[1] for f in funcs if f.startswith('api.'))
for k in ('tests', 'test_files', 'categories', 'negative_ids', 'required_categories'):
    pass
json.dump(e, open(EXP, 'w', encoding='utf-8'), indent=2, ensure_ascii=False); open(EXP, 'a').write('\n')
print('written: tables %d functions %d api %d tests %d' % (len(e['tables']), len(e['functions']), len(e['api_functions']), len(e['tests'])))

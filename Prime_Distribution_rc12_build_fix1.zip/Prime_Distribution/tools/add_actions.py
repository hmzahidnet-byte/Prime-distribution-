#!/usr/bin/env python3
"""Adds / replaces entries in app/src/main/assets/actions.json from the SQL signature of each api.v1_* function.
Usage: python3 tools/add_actions.py DEPT RPC 'বাংলা নাম' [write|read] ...  (labels of known parameters are reused from the catalog)."""
import json, os, re, sys
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
CAT = os.path.join(ROOT, 'app/src/main/assets/actions.json'); MIG = os.path.join(ROOT, 'backend/supabase/migrations')
EXTRA = {'p_now': 'এখন যা যাবে [{product_id, qty}]', 'p_allocations': 'মিল [{collection_id, amount}]', 'p_kind': 'ধরন', 'p_qty': 'পরিমাণ', 'p_amount': 'টাকা',
         'p_reason': 'কারণ', 'p_evidence_ref': 'প্রমাণ (ফাইল)', 'p_resolution': 'সমাধান', 'p_settlement_id': 'নিষ্পত্তি', 'p_dispute_id': 'বিরোধ', 'p_remittance_id': 'জমা (রেমিট্যান্স)',
         'p_from': 'শুরুর তারিখ', 'p_to': 'শেষ তারিখ', 'p_query': 'খুঁজুন', 'p_limit': 'সর্বোচ্চ', 'p_path': 'ফাইলের পথ', 'p_sha256': 'SHA-256', 'p_payload': 'তথ্য'}
TYPE = {'uuid': 'UUID', 'text': 'TEXT', 'numeric': 'NUMBER', 'integer': 'INT', 'int': 'INT', 'bigint': 'INT', 'smallint': 'INT', 'date': 'DATE', 'boolean': 'BOOL',
        'jsonb': 'JSON', 'json': 'JSON', 'text[]': 'TEXT_ARRAY', 'timestamptz': 'TEXT'}
sql = ''.join(open(os.path.join(MIG, n), encoding='utf-8').read() for n in sorted(os.listdir(MIG)) if n.endswith('.sql'))
cat = json.load(open(CAT, encoding='utf-8'))
labels = {}
for a in cat['actions']:
    for f in a['f']: labels.setdefault(f['p'], f['l'])
args = sys.argv[1:]
while args:
    dept, rpc, name, mode = args[:4]; args = args[4:]
    m = list(re.finditer(r'create\s+(?:or\s+replace\s+)?function\s+api\.' + rpc + r'\s*\(([^)]*)\)', sql, re.I))
    if not m: sys.exit('not found: ' + rpc)
    fields = []
    for part in [p.strip() for p in m[-1].group(1).split(',') if p.strip()]:
        opt = ' default ' in part.lower()
        bits = re.sub(r'\s+default\s+.*$', '', part, flags=re.I).split()
        p, t = bits[0], ' '.join(bits[1:]).lower()
        fields.append({'p': p, 'l': EXTRA.get(p) or labels.get(p) or p[2:].replace('_', ' '), 't': TYPE.get(t, 'TEXT'), 'o': opt or p in ('p_from', 'p_to', 'p_evidence_ref', 'p_settlement_id', 'p_lot_id', 'p_qty', 'p_amount', 'p_provider_id')})
    entry = {'d': dept, 'r': rpc, 'n': name, 'w': mode == 'write', 'f': fields}
    cat['actions'] = [a for a in cat['actions'] if a['r'] != rpc] + [entry]
    print(rpc, [(f['p'], f['t'], f['l']) for f in fields])
json.dump(cat, open(CAT, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('actions:', len(cat['actions']))

#!/usr/bin/env python3
"""Bengali-only UI: every form label and action title in app/src/main/assets/actions.json gets a Bengali text.
Field labels that are still English are rebuilt word by word from W (+ whole-name overrides O); action titles from T."""
import json, os, re
ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
CAT = os.path.join(ROOT, 'app/src/main/assets/actions.json')
W = dict(a='ক', prefs='পছন্দ', subject='বিষয়', within='এত দিনের মধ্যে', revision='সংস্করণ', property='বৈশিষ্ট্য', preview='দেখুন', outlet='শাখা', into='যার সাথে', interval='বিরতি', component='উপাদান', claim='দাবি', applicant='আবেদনকারী', vacancy='পদ-খালি', offer='নিয়োগ-প্রস্তাব', description='বিবরণ', week='সপ্তাহ', headcount='জনসংখ্যা', round='পর্ব', score='নম্বর (০–১০০)', join='যোগদান', cv='জীবনবৃত্তান্ত', grain='সময়-একক (day/week/month)', due='নির্ধারিত তারিখ', boundary='সীমানা', overlap='মিল', lat='অক্ষাংশ', lon='দ্রাঘিমাংশ', assignment_='নিয়োগ', order='অর্ডার', notice='নোটিশ', user='ব্যবহারকারী', text='লেখা', to_='পর্যন্ত', idem='অনুরোধ-নম্বর (ফাঁকা = নিজে তৈরি)', issues='সমস্যা [{kind: short/damaged, product_id, qty, note}]', segment='কাদের জন্য', eligibility='শর্ত', alt='বর্ণনা', withdraw='প্রত্যাহার', max='সর্বোচ্চ', time='সময়', window='সীমা', weekdays='সপ্তাহের দিন (০=রবি…৬=শনি)', allergens='অ্যালার্জেন (কমা দিয়ে)', ingredients='উপাদান', last_='শেষ', day='দিন', rma='ফেরত-অনুমতি', approve_='অনুমোদন?', milestone='ধাপ', place='স্থান', mode_='মাধ্যম', accept='গ্রহণ', counted_='গণনাকৃত', basis_='ভিত্তি', handover='হস্তান্তর', pct='শতাংশ', review='পর্যালোচনা', close='বন্ধের', found='পাওয়া গেছে (তালিকা)', absent='অনুপস্থিত', accepted='গৃহীত', access='প্রবেশাধিকার', account='হিসাব', accuracy='নির্ভুলতা', action='কাজ', actions='কাজগুলো', active='সক্রিয়',
 actor='কর্তা', address='ঠিকানা', adjustment='সমন্বয়', admin='প্রশাসনিক', after='পরে', agg='সমষ্টি', agreement='চুক্তি', alias='ডাকনাম', allocations='বরাদ্দ',
 allowances='ভাতা', allowed='অনুমোদিত', amount='টাকা', annual='বার্ষিক', application='আবেদন', approvals='অনুমোদন', approver='অনুমোদনকারী', archived='আর্কাইভ',
 area='এলাকা', as_='হিসেবে', assignment='দায়িত্ব', at='সময়', attachment='সংযুক্তি', attributes='বৈশিষ্ট্য', authorized='অনুমোদিত', b='খ', background='পটভূমি',
 backup='ব্যাকআপ', bank='ব্যাংক', base='মূল', basis='ভিত্তি', batch='ব্যাচ', battery='ব্যাটারি', bill='বিল', bin='তাক', bn='বাংলা', body='লেখা', bom='BOM',
 bucket='বালতি', by='দ্বারা', bytes='বাইট', cadence='পুনরাবৃত্তি', carton='কার্টন', cartons='কার্টন', cascade='সাথে সব', cash='নগদ', category='শ্রেণি',
 change='পরিবর্তন', changes='পরিবর্তনগুলো', channel='মাধ্যম', class_='শ্রেণি', classes='শ্রেণিগুলো', client='ডিভাইস', code='কোড', codes='কোডগুলো',
 collected='আদায়', collection='আদায়', company='কোম্পানি', condition='কন্ডিশন', contact='যোগাযোগ', cost='খরচ', count='গণনা', counted='গণনাকৃত',
 counter='বিপরীত', credit='বাকি', custodian='দায়িত্বপ্রাপ্ত', damaged='ক্ষতিগ্রস্ত', dataset='ডেটাসেট', date='তারিখ', days='দিন', dealer='ডিলার',
 decision='সিদ্ধান্ত', deduction='কর্তন', deductions='কর্তন', default='ডিফল্ট', definition='সংজ্ঞা', delegate='প্রতিনিধি', delegation='প্রতিনিধিত্ব',
 delivery='ডেলিভারি', department='বিভাগ', design='নকশা', device='ডিভাইস', dimension='মাত্রা', dispatch='প্রেরণ', doc='নথি', document='নথি', done='সম্পন্ন',
 downtime='বন্ধ সময়', draft='খসড়া', drill='মহড়া', driver='চালক', duty='দায়িত্ব', effect='প্রভাব', effective='কার্যকর', email='ইমেইল', employee='কর্মী',
 enabled='চালু', end='শেষ', entity='সত্তা', env='পরিবেশ', event='ঘটনা', evidence='প্রমাণ', expected='প্রত্যাশিত', expiry='মেয়াদ', external='বাইরের',
 factor='গুণক', facts='তথ্য', fefo='FEFO', fg='তৈরি পণ্য', field='ঘর', filters='ছাঁকনি', final='চূড়ান্ত', fingerprint='ফিঙ্গারপ্রিন্ট', flavor='স্বাদ',
 form='ফর্ম', format='ধরন', formula='সূত্র', free='খালি', freight='ভাড়া', from_='থেকে', full='পূর্ণ', geofence='জিওফেন্স', grace='ছাড়', grade='গ্রেড',
 grams='গ্রাম', grant='অনুমতি', grn='GRN', has='আছে', hold='স্থগিত', home='মূল', hours='ঘণ্টা', icon='আইকন', id='আইডি', ids='আইডিগুলো', image='ছবি',
 in_='', include='সহ', info='তথ্য', ingredient='উপকরণ', input='ইনপুট', investor='বিনিয়োগকারী', invoice='ইনভয়েস', issue='ইস্যু', item='আইটেম',
 journal='জার্নাল', key='কী', kind='ধরন', lates='দেরি', latitude='অক্ষাংশ', layout='লেআউট', lead='সরবরাহ', life='আয়ু', limit='সীমা', line='লাইন',
 list='তালিকা', location='অবস্থান', longitude='দ্রাঘিমাংশ', lost='হারানো', lot='লট', m='মিটার', machine='যন্ত্র', manager='ব্যবস্থাপক',
 mandatory='বাধ্যতামূলক', market='বাজার', masked='আংশিক লুকানো', mb='MB', media='মিডিয়া', membership='সদস্যপদ', memo='বিবরণ', method='পদ্ধতি',
 mfg='উৎপাদন', mime='ফাইল-ধরন', min='ন্যূনতম', minutes='মিনিট', missing='অনুপস্থিত', mobile='মোবাইল', mode='পদ্ধতি', module='মডিউল', month='মাস',
 name='নাম', needed='প্রয়োজন', new='নতুন', no='নম্বর', note='নোট', notes='নোট', notification='নোটিফিকেশন', now='এখন', number='নম্বর', of='এর', on='তারিখে',
 onboarding='যোগদান', online='অনলাইন', only='শুধু', outcome='ফলাফল', output='উৎপাদ', override='পরিবর্তন', owner='মালিক', package='প্যাকেজ', padding='ফাঁকা জায়গা',
 parameters='প্যারামিটার', parent='মূল', part='যন্ত্রাংশ', party='পার্টি', path='পথ', pay='পরিশোধ', payer='বহনকারী', per='প্রতি', permission='অনুমতি',
 permissions='অনুমতিগুলো', person='ব্যক্তি', pin='পিন', plan='পরিকল্পনা', planned='পরিকল্পিত', po='PO', policy='নীতি', poly='পলি', polys='পলি', position='পদ',
 positions='পদগুলো', pr='PR', prefix='উপসর্গ', preset='প্রিসেট', price='মূল্য', priority='অগ্রাধিকার', product='পণ্য', production='উৎপাদন', products='পণ্যগুলো',
 proof='প্রমাণ', proposal='প্রস্তাব', proposed='প্রস্তাবিত', provider='প্রদানকারী', purchase='ক্রয়', qty='পরিমাণ', quarantine='কোয়ারেন্টাইন', quotation='কোটেশন',
 ratio='অনুপাত', raw='কাঁচামাল', reason='কারণ', receipt='রসিদ', received='গৃহীত', recipe='রেসিপি', recipient='প্রাপক', recipients='প্রাপকরা', record='রেকর্ড',
 recorded='লিপিবদ্ধ', ref='রেফারেন্স', reference='রেফারেন্স', refresh='হালনাগাদ', reject='প্রত্যাখ্যাত', rejected='প্রত্যাখ্যাত', release='ছাড়', remittance='জমা',
 request='অনুরোধ', required='প্রয়োজনীয়', reservation='সংরক্ষণ', reset='পুনরায় শুরু', resolution='সমাধান', resolve='সমাধান', restored='পুনরুদ্ধার', result='ফলাফল',
 retailer='রিটেইলার', return_='ফেরত', reversal='বিপরীত', role='ভূমিকা', route='রুট', rule='নিয়ম', run='রান', sachet='স্যাশে', sachets='স্যাশে', salary='বেতন',
 sale='বিক্রি', samples='নমুনা', saved='সংরক্ষিত', scans='স্ক্যান', scope='পরিধি', screen='পর্দা', seconds='সেকেন্ড', seq='ক্রম', service='সেবা', settlement='নিষ্পত্তি',
 sha256='SHA-256', share='অংশ', shelf='তাক', shift='শিফট', signature='স্বাক্ষর', since='থেকে', size='আকার', sku='SKU', slip='স্লিপ', slot='স্থান', snapshot='স্ন্যাপশট',
 sort='ক্রম', source='উৎস', spec='বিবরণ', stage='ধাপ', start='শুরু', started='শুরু', statement='বিবরণী', stock='মজুদ', stops='থামার জায়গা', storage='স্টোরেজ',
 style='স্টাইল', submission='জমা', substitute='বদলি', substitution='বদলি', supplier='সরবরাহকারী', table='টেবিল', target='লক্ষ্য', task='কাজ', tasks='কাজগুলো',
 tax='কর', template='টেমপ্লেট', terms='শর্ত', theme='থিম', tls='TLS', to='প্রতি', token='টোকেন', tokens='টোকেন', transfer='স্থানান্তর',
 transit='পথে', type='ধরন', unit='একক', units='একক', unread='না-পড়া', until='পর্যন্ত', valid='বৈধ', value='মান', values='মানগুলো', variant='ভ্যারিয়েন্ট',
 vehicle='যানবাহন', version='সংস্করণ', visible='দৃশ্যমান', visit='ভিজিট', wallet='ওয়ালেট', warehouse='গুদাম', wastage='অপচয়', waste='অপচয়', wing='উইং',
 work='কাজের', year='বছর', category_id='শ্রেণি', **{'as': 'হিসেবে', 'class': 'শ্রেণি', 'from': 'থেকে', 'in': '', 'return': 'ফেরত'})
O = {'p_valid_from': 'কার্যকর শুরু', 'p_valid_until': 'কার্যকর শেষ', 'p_as_of': 'যে তারিখ পর্যন্ত', 'p_from_seq': 'ক্রম থেকে', 'p_to_seq': 'ক্রম পর্যন্ত',
 'p_to_version': 'যে সংস্করণে', 'p_to_bin': 'যে তাকে', 'p_from_bin': 'যে তাক থেকে', 'p_to_position_code': 'নতুন পদ', 'p_to_membership': 'যার কাছে',
 'p_from_preset': 'যে প্রিসেট থেকে', 'p_from_template': 'যে টেমপ্লেট থেকে', 'p_in_purchase_units': 'ক্রয়-এককে', 'p_has_products': 'পণ্য আছে',
 'p_unread_only': 'শুধু না-পড়া', 'p_include_archived': 'আর্কাইভসহ', 'p_lates_per_deduction': 'কত দেরিতে এক দিন কর্তন', 'p_after_minutes': 'কত মিনিট পরে',
 'p_permission_a': 'অনুমতি ক', 'p_permission_b': 'অনুমতি খ', 'p_tax_id': 'TIN / পরিচয় নম্বর', 'p_tls': 'নিরাপদ সংযোগ (TLS)', 'p_bucket': 'স্টোরেজ-বাক্স',
 'p_qty_poly': 'পরিমাণ (পলি)', 'p_fg_poly': 'তৈরি পণ্য (পলি)', 'p_input_poly': 'ইনপুট (পলি)', 'p_received_poly': 'গৃহীত (পলি)', 'p_planned_poly': 'পরিকল্পিত (পলি)',
 'p_poly_per_carton': 'প্রতি কার্টনে পলি', 'p_polys_per_carton': 'প্রতি কার্টনে পলি', 'p_sachets_per_poly': 'প্রতি পলিতে স্যাশে', 'p_grams_per_sachet': 'প্রতি স্যাশে গ্রাম',
 'p_accuracy_m': 'নির্ভুলতা (মিটার)', 'p_geofence_m': 'জিওফেন্স (মিটার)', 'p_storage_free_mb': 'খালি স্টোরেজ (MB)', 'p_size_bytes': 'আকার (বাইট)',
 'p_target_env': 'লক্ষ্য-পরিবেশ', 'p_full_name_bn': 'পুরো নাম (বাংলা)', 'p_name': 'নাম', 'p_no_sale_reason': 'বিক্রি না হওয়ার কারণ'}
def bn(p):
    if p in O: return O[p]
    toks = p[2:].split('_')
    if len(toks) > 1 and toks[-1] in ('id', 'ids'): toks = toks[:-1] + ([] if toks[-1] == 'id' else ['তালিকা'])
    out = [W.get(t, W.get(t + '_', t)) for t in toks]
    return ' '.join(x for x in out if x)
T = {}
cat = json.load(open(CAT, encoding='utf-8'))
miss = set()
for a in cat['actions']:
    for f in a['f']:
        if re.search(r'[a-z]', f['l']) and not re.search(r'[ঀ-৿]', f['l']) or f['l'] == f['p'][2:].replace('_', ' '):
            f['l'] = bn(f['p'])
            for w in re.findall(r'[a-z]+', f['l']): miss.add(w)
json.dump(cat, open(CAT, 'w', encoding='utf-8'), ensure_ascii=False, separators=(',', ':'))
print('untranslated words:', sorted(miss))

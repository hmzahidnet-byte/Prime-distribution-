# Prime Distribution — রিলিজ ও ডিপ্লয় নির্দেশিকা (চূড়ান্ত ধাপ S58)

> **সত্য অবস্থা:** এই ভান্ডারের SQL ও Kotlin লেখা হয়েছে, কিন্তু লেখার পরিবেশে **একবারও চালানো বা কম্পাইল করা হয়নি**।
> নিচের ধাপ ১ ও ২-ই প্রথম আসল পরীক্ষা। সেখানে লাল (ব্যর্থ) এলে সেটি স্বাভাবিক — লগ পাঠালে ঠিক করা হবে। সবুজ না হওয়া পর্যন্ত ধাপ ৩-এ যাবেন না।

## স্থানীয়ভাবে SQL যাচাই (ঐচ্ছিক, deploy-এর আগে)
নিজের কম্পিউটারে PostgreSQL 15+ থাকলে: `PGHOST=localhost PGUSER=postgres backend/ops/run_sql_local.sh` — `mohona_test` ডেটাবেস মুছে নতুন করে বানায়, সব migration ও পরীক্ষা চালায় (১৪-১১-২০২৬: ৫৭ migration, ৬৭৩ PASS)। আসল ডেটাবেসে কখনো চালাবেন না।

## ধাপ ১ — GitHub-এ তুলুন, SQL নিজে নিজে পরীক্ষা হবে
1. ZIP খুলে `Mohona_Enterprise_OS` ফোল্ডারের ভেতরের সবকিছু আপনার GitHub ভান্ডারে তুলুন (commit + push)।
2. **Actions → “SQL Tests (temporary PostgreSQL)”** নিজে চালু হবে। এটি GitHub-এর ভেতরে একটি অস্থায়ী ডেটাবেসে ৪১টি migration ও ৩৪টি টেস্ট-ফাইল (৫৩৮টি পরীক্ষা) চালায়। কোনো গোপন তথ্য লাগে না, কোথাও কিছু ডিপ্লয় হয় না।
3. ফল দেখুন (run-এর Summary):
   - **Migration FAILED** → কোন ফাইল ও কোন লাইনে থেমেছে লেখা থাকবে। `sql-test-logs` নামের artifact নামিয়ে পাঠান।
   - **Failed > 0** → কোন পরীক্ষা (যেমন `S41-05`) ব্যর্থ, তালিকায় থাকবে।
   - সব সবুজ → ধাপ ২।

## ধাপ ২ — APK বানান
1. **Actions → “Android Debug APK”** প্রতিটি push-এ চলে। সবুজ হলে run-এর নিচে `mohona-erp-debug-apk` artifact থেকে APK নামান।
2. লাল হলে `build.log`-এর শেষ ৫০ লাইন পাঠান (প্রথম কম্পাইলে কিছু ত্রুটি আসা প্রত্যাশিত)।
3. সার্ভার-সংযুক্ত APK চাইলে: ভান্ডারের **Settings → Secrets and variables → Actions**-এ দুটি secret দিন — `SUPABASE_URL` ও `SUPABASE_ANON_KEY` (শুধু **anon/publishable** কী; service-role কী কখনো নয়) — তারপর workflow আবার চালান। secret না দিলে APK “প্রিভিউ মোডে” চলে (সার্ভার ছাড়া)।
4. QR ক্যামেরা-স্ক্যানের জন্য ফোনে Google Play services লাগে; না থাকলে লেখা পেস্ট করে কাজ চলে।

## ধাপ ৩ — সার্ভার (Supabase) ডিপ্লয়: আগে Staging, পরে Production
বিস্তারিত ফোন-বান্ধব ধাপ: `backend/ops/GUIDE_BN.md` (workflow “Staging Migrations (manual)”)। সংক্ষেপে:
1. দুটি আলাদা Supabase প্রকল্প রাখুন: **Staging** ও **Production**। আগে সবকিছু Staging-এ।
2. `approval-check` → `validate-only` → লগ দেখা → `apply` (APPLY-TO-STAGING লিখে)।
3. Migration ক্রম ফাইলের নামের ক্রমই (`20261108000100_…` থেকে `20261108009900_lookup_refresh.sql`, মোট ৫৭টি; শেষ ফাইলটি সবসময় lookup-তালিকা)। কোনোটি বাদ দেওয়া বা আগে-পরে করা যাবে না।
4. Edge Function চারটি (`auth-otp-start`, `auth-pin-login`, `auth-pin-refresh`, `auth-sign-out`) Supabase CLI দিয়ে ডিপ্লয় করুন; secret: `MOHONA_JWT_SECRET`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` (শুধু Supabase-এর Function secrets-এ; GitHub বা অ্যাপে নয়)।
5. প্রথম কোম্পানি ও চেয়ারম্যান: service-role দিয়ে `svc.v1_iam_provision_person` → `svc.v1_gov_bootstrap_company` (একবার)।
6. হিসাব চালুর আগে: `api.v1_coa_seed_default` → হিসাবরক্ষকের পর্যালোচনা → চেয়ারম্যানের অনুমোদন। না হলে মডিউলের জার্নাল “অপেক্ষায়” থাকবে (ব্যবসার লেনদেন আটকায় না)।

## ধাপ ৪ — নির্ধারিত কাজ (pg_cron বা Supabase Scheduled Function; service-role)
| কাজ | ফাংশন | কত ঘন ঘন |
|---|---|---|
| নোটিফিকেশন, রিমাইন্ডার, এসকেলেশন | `svc.v1_notify_run()` | ৫ মিনিট |
| SMS/ইমেইল পাঠানো (Edge Function লাগবে, OI-35) | `svc.v1_notify_claim` / `svc.v1_notify_result` | ১ মিনিট |
| HR পরিবর্তন কার্যকর | `svc.v1_hr_apply_due_changes()` | প্রতিদিন রাত ১২:০৫ |
| নীতি কার্যকর | `svc.v1_policy_apply_due()` | প্রতি ঘণ্টা |
| ডিলার-পুনর্বণ্টন | `svc.v1_dealer_apply_reassignments()` | প্রতিদিন রাত ১২:১০ |
| দায়িত্ব-অর্পণের মেয়াদ শেষ | `svc.v1_delegations_expire()` | প্রতি ঘণ্টা |
| রিসাইকেল-বিন পরিষ্কার | `svc.v1_recycle_run()` | প্রতিদিন রাত ২টা |
| অবস্থান-ডেটা মোছা | `svc.v1_location_purge()` | প্রতিদিন রাত ২:৩০ |
| নির্ধারিত রিপোর্ট | `svc.v1_report_run_schedules()` | প্রতিদিন সকাল ৬টা |
| bKash/Nagad নিশ্চয়তা (গেটওয়ে-চুক্তির পর, OI-49) | `svc.v1_provider_confirm(...)` | webhook |

## ধাপ ৫ — ব্যাকআপ ও পুনরুদ্ধার (ফিচার ২৫১–২৬০)
**Google Drive দৈনিক ব্যাকআপ:** `.github/workflows/backup-drive.yml`। GitHub → Settings → Environments → `production-backup`-এ তিনটি secret দিন: `PROD_DB_URL`, `BACKUP_PASSPHRASE` (অফলাইনে কপি রাখুন — না থাকলে ব্যাকআপ খোলা যাবে না), `RCLONE_CONF` (`gdrive` ও `supastorage` রিমোট)। প্রথমবার Actions থেকে হাতে চালান, তারপর পুনরুদ্ধার-মহড়া।

কোডে আছে **রেকর্ড, মাপ ও প্রমাণ**; আসল ব্যাকআপ Supabase-এ আপনাকে চালু করতে হবে:
1. **PITR** (Point-in-Time Recovery) Supabase-এর পেইড প্ল্যানে চালু করুন — এটি শুধু ডেটাবেস; Storage-এর ফাইল এতে নেই।
2. **Storage কপি**: bucket-গুলোর (forms, products) সংস্করণসহ কপি আলাদা জায়গায়; প্রতিটি ফাইলের checksum মিলিয়ে `svc.v1_backup_record('storage_copy', …)`-এ লিখুন।
3. ব্যাকআপ-চাবি: শুধু চাবির **রেফারেন্স** (যেমন `kms:mohona-backup-2026`) রেকর্ডে যায়; চাবি বা পাসওয়ার্ড দিলে সার্ভার ফিরিয়ে দেয়।
4. **রিকভারি-মহড়া** (তিন মাসে একবার): আলাদা/isolated প্রকল্পে restore → `api.v1_recovery_drill_record` → অন্য একজনের `api.v1_recovery_drill_approve`। Production-এ মহড়া সার্ভার নেয় না। লক্ষ্য RPO ≤ ৬০ মিনিট, RTO ≤ ৪ ঘণ্টা — **এখনো মাপা হয়নি**।
5. এক কোম্পানির পুনরুদ্ধার: `svc.v1_tenant_manifest(company)` restore-এর আগে ও পরে চালিয়ে সারি-সংখ্যা ও checksum মেলান; অন্য কোম্পানির সারিতে হাত দেওয়া যাবে না।

## ধাপ ৬ — হাতে করার পরীক্ষা (ফিচার ২৭৬–২৭৮, ২৮০) — কোড দিয়ে প্রমাণ হয় না
- **পর্দা (২৭৬):** ছোট (৫″), মাঝারি, বড় ফোনে প্রতিটি পর্দা খুলুন; বাংলা লেখা কাটা পড়ছে কি না, বোতাম পর্দার বাইরে যাচ্ছে কি না, ফন্ট-স্কেল ১.৩-এ টাকা-সংখ্যা ভাঙছে কি না।
- **গতি (২৭৭):** লক্ষ্য-ফোনে তালিকা স্ক্রল ও পর্দা-বদল মসৃণ কি না (৯০–১২০ FPS একটি আকাঙ্ক্ষা, প্রতিশ্রুতি নয়)।
- **অ্যাক্সেসিবিলিটি (২৭৮):** TalkBack চালিয়ে লগইন, অনুমোদন, কালেকশন, হাজিরা-QR; প্রতিটি বোতাম অন্তত ৪৮dp; রং-বৈপরীত্য।
- **রোলব্যাক-মহড়া (২৮০):** Staging-এ — (ক) অ্যাপ: আগের APK বসানো যায়; (খ) ডিজাইন: থিম/লেআউট rollback API; (গ) ডেটাবেস: PITR দিয়ে আগের সময়ে ফেরা। পোস্ট-হওয়া খাতা কখনো মুছে rollback নয় — রিভার্সাল জার্নাল।
- ফল `svc.v1_requirement_mark('MOS-F153-276','manual','<তারিখ ও পরীক্ষক>','passed'|'failed')` দিয়ে লিখুন।

## ধাপ ৭ — রিলিজ-গেট (২৭৯)
চারটি ক্ষেত্র — security, finance, design, operations — **চারজন আলাদা ব্যক্তি** `api.v1_release_signoff('1.0.0', ক্ষেত্র, মন্তব্য)` দেবেন। চারটি না হলে `ready = false`। কিছুই নিজে থেকে প্রকাশ হয় না; Production-এ apply ও APK বিতরণ আপনার হাতে।

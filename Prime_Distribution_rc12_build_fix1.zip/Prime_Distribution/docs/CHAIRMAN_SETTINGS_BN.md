# Chairman-সেটিং ক্যাটালগ (সব অপশন; ডিফল্ট = সেরা অনুশীলন)

| কী | ধরন | ডিফল্ট | সীমা/অনুমোদিত | নাম |
|---|---|---|---|---|
| `iam.delegation.max_days` | int | `30` | 1–365 | ক্ষমতা-অর্পণের সর্বোচ্চ মেয়াদ (দিন) |
| `iam.session.max_concurrent` | int | `1` | 0–20 | একজনের একসাথে সর্বোচ্চ সেশন (০ = সীমাহীন) |
| `iam.mfa.required_positions` | text_array | `["CHAIRMAN","MD"]` |  | যেসব পদে MFA বাধ্যতামূলক |
| `iam.md_appointment.requires_review` | bool | `false` |  | MD নিয়োগে দ্বিতীয় পর্যালোচনা |
| `iam.md.max_active_primary` | int | `1` | 1–10 | একসাথে সক্রিয় প্রধান MD-এর সংখ্যা |
| `approval.chairman_self_approval.allowed` | bool | `false` |  | চেয়ারম্যান নিজের লেনদেন নিজে অনুমোদন করতে পারবেন |
| `approval.maker_checker.enabled` | bool | `true` |  | মেকার-চেকার চালু |
| `breakglass.enabled` | bool | `false` |  | জরুরি-প্রবেশ (Break-glass) চালু |
| `breakglass.custodians_required` | int | `2` | 1–3 | জরুরি-প্রবেশে প্রয়োজনীয় রক্ষক |
| `breakglass.max_minutes` | int | `30` | 5–1440 | জরুরি-প্রবেশের সর্বোচ্চ মেয়াদ (মিনিট) |
| `numbering.mode` | text | `"GAPS_ALLOWED"` | ["GAPS_ALLOWED","GAPLESS"] | ডকুমেন্ট-নম্বরিং পদ্ধতি |
| `finance.money.scale` | int | `2` | 0–6 | টাকার দশমিক ঘর |
| `finance.rounding.mode` | text | `"HALF_UP"` | ["HALF_UP","HALF_EVEN","UP","DOWN"] | রাউন্ডিং পদ্ধতি |
| `finance.unit_cost.scale` | int | `4` | 4–10 | একক-খরচের দশমিক ঘর |
| `finance.backdate.max_days` | int | `7` | 0–366 | সর্বোচ্চ পেছনের তারিখ (দিন) |
| `finance.posting.requires_reviewed_coa` | bool | `true` |  | পোস্টিংয়ের আগে COA-পর্যালোচনা বাধ্যতামূলক |
| `inventory.negative_stock.allowed` | bool | `false` |  | ঋণাত্মক স্টক অনুমতি |
| `inventory.return.valuation` | text | `"ORIGINAL_COST_ELSE_WAC_REVIEW"` | ["ORIGINAL_COST_ELSE_WAC_REVIEW","CURRENT_WAC","ORIGINAL_COST_ONLY"] | ফেরত-মালের মূল্যায়ন |
| `mfg.residual.allocation` | text | `"LAST_ELIGIBLE_LINE"` | ["LAST_ELIGIBLE_LINE","LARGEST_LINE","VARIANCE_ACCOUNT"] | অবশিষ্ট-খরচ বণ্টন |
| `company.intercompany.enabled` | bool | `false` |  | আন্তঃকোম্পানি লেনদেন |
| `company.chairman_consolidated_view` | bool | `true` |  | চেয়ারম্যানের সব কোম্পানির একীভূত ড্যাশবোর্ড |
| `hr.require_active_employment` | bool | `true` |  | প্রতিটি কাজে সক্রিয় কর্মসংস্থান যাচাই |
| `access.factory_pnl.positions` | text_array | `["CHAIRMAN","MD"]` |  | ফ্যাক্টরি লাভ-ক্ষতি দেখার পদ (ডিফল্ট) |
| `ui.theme.primary` | text | `"#1456A0"` |  | প্রধান রং |
| `ui.nav.bottom_tabs` | text_array | `["home","tasks","reports","more"]` |  | নিচের নেভিগেশন-ট্যাব |
| `ui.language` | text | `"bn"` | ["bn"] | ভাষা |
| `recycle.retention_days` | int | `90` | 1–3650 | রিসাইকেল-বিনে রাখার মেয়াদ (দিন) |
| `audit.retention_years` | int | `10` | 1–50 | অডিট-লগ সংরক্ষণ (বছর) |

## S14 — ডায়নামিক ফর্ম ও মাস্কিং
| কী | ধরন | ডিফল্ট | সীমা/বিকল্প | অর্থ |
|---|---|---|---|---|
| `forms.publish.requires_approval` | bool | `false` |  | ফর্ম প্রকাশে অনুমোদন-ইঞ্জিন |
| `forms.hidden_value_policy` | text | `"strip"` | ["strip","reject"] | লুকানো ঘরে পাঠানো মান বাদ / প্রত্যাখ্যান |
| `forms.sensitive.default_access` | text | `"entry"` | ["entry","masked","none","read"] | সংবেদনশীল ঘরের ডিফল্ট (entry = পূরণ করা যায়, দেখা মাস্ক-করা) |
| `forms.attachment.max_mb` | int | `10` | 1–100 | সংযুক্তির সর্বোচ্চ আকার |
| `forms.attachment.allowed_mime` | text_array | `["image/jpeg","image/png","image/webp","application/pdf"]` | + image/heic, text/csv | অনুমোদিত সংযুক্তি-ধরন |
| `forms.attachment.url_ttl_seconds` | int | `300` | 30–3600 | সংযুক্তি-লিংকের মেয়াদ |
| `forms.offline.draft_ttl_days` | int | `14` | 1–90 | ডিভাইসে খসড়ার মেয়াদ |
| `forms.offline.max_drafts` | int | `50` | 1–500 | একজনের সর্বোচ্চ খোলা খসড়া |
| `forms.edit.reason_required` | bool | `true` |  | ফেরত/প্রত্যাখ্যাত ফর্ম সংশোধনে কারণ |
| `forms.list.max_rows` | int | `200` | 10–1000 | তালিকা/রপ্তানির সর্বোচ্চ সারি |
| `mask.style` | text | `"partial"` | ["partial","full"] | মাস্কিং-ধরন |
| `mask.keep_last` | int | `4` | 0–8 | শেষের কতটি অক্ষর দেখা যাবে |
| `mask.export_policy` | text | `"redact"` | ["redact","as_screen"] | রপ্তানিতে মাস্ক-করা ঘর |

ফিচার-সুইচ: `forms.offline_drafts` (কোম্পানি/উইং; ডিফল্ট চালু)। ঘর×পদ অনুমতি (write / entry / read / masked / none) ও সাধারণ মাস্ক-নীতি (show / mask / hide) — অ্যাপের ফর্ম-ডিজাইনার ও মাস্কিং-পর্দা থেকে; চেয়ারম্যান সবসময় সব দেখেন।

## S15 — IAM ও কর্মী-কাঠামো
| কী | ধরন | ডিফল্ট | সীমা/বিকল্প | অর্থ |
|---|---|---|---|---|
| `iam.sod.default_mode` | text | `"block"` | ["block","warn"] | নতুন কোম্পানির ডিফল্ট দায়িত্ব-বিভাজন জোড়ার ধরন |
| `iam.permission.dependency_check` | bool | `true` |  | মূল অনুমতি ছাড়া শাখা-অনুমতি নয় |
| `hr.onboarding.block_login` | bool | `true` |  | নিয়োগ-চেকলিস্ট অনুমোদনের আগে লগইন বন্ধ |
| `hr.onboarding.default_tasks` | json | কাগজপত্র, নিয়োগপত্র, পরিচিতি-সভা |  | ডিফল্ট চেকলিস্ট (পদভিত্তিক টেমপ্লেট অগ্রাধিকার পায়) |
| `hr.employment_change.requires_approval` | bool | `false` |  | পদোন্নতি/বদলি/স্থগিত/অব্যাহতিতে অনুমোদন-ইঞ্জিন |
| `hr.substitution.max_days` | int | `30` | 1–365 | বিকল্প-দায়িত্বের সর্বোচ্চ মেয়াদ |

দায়িত্ব-বিভাজন জোড়া (`api.v1_iam_sod_set`: block / warn / off) ও মাস্ক-নীতি `hr.employment.salary` — চেয়ারম্যানের পর্দা থেকে।

## S16 — লগইন
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `auth.pin.length` | int | `6` | 4–8 | PIN-এর দৈর্ঘ্য |
| `auth.pin.max_failures` | int | `5` | 3–20 | কতবার ভুলে লক |
| `auth.pin.lock_minutes` | int | `15` | 1–1440 | লকের মেয়াদ |
| `auth.pin.rate_window_minutes` | int | `15` | 1–1440 | নম্বরপ্রতি চেষ্টার জানালা (প্ল্যাটফর্ম-ডিফল্ট; ব্যক্তি অজানা থাকায়) |
| `auth.pin.rate_max_attempts` | int | `10` | 3–100 | জানালায় সর্বোচ্চ চেষ্টা |
| `auth.otp.fresh_minutes` | int | `10` | 1–60 | OTP-যাচাই কত মিনিট বৈধ |
| `auth.session.access_minutes` | int | `15` | 5–60 | অ্যাক্সেস-টোকেনের মেয়াদ |
| `auth.session.refresh_days` | int | `30` | 1–180 | ডিভাইসে লগইন টিকে থাকার মেয়াদ |
| `auth.device.max_per_person` | int | `3` | 1–10 | একজনের সর্বোচ্চ সক্রিয় ডিভাইস |
| `auth.invitation.valid_days` | int | `7` | 1–60 | লগইন-আমন্ত্রণের মেয়াদ |

একজন ব্যক্তি একাধিক কোম্পানিতে থাকলে প্রতিটি সংখ্যায় **সবচেয়ে কঠোর** মান প্রযোজ্য। `iam.mfa.required_positions` থেকে CHAIRMAN কখনো সরানো যায় না।

## S18 — ডিজাইন-স্টুডিও ১
| কী | ধরন | ডিফল্ট | অর্থ |
|---|---|---|---|
| `design.publish.requires_approval` | bool | `false` | থিম প্রকাশে অনুমোদন-ইঞ্জিন |

থিম-টেমপ্লেট: মোহনা নীল (ডিফল্ট), মোহনা কমলা, সবুজ, উচ্চ কনট্রাস্ট। প্রকাশে সার্ভার-যাচাই: লেখা ≥৪.৫:১, ম্লান লেখা ও বোতাম-লেখা ≥৩:১, পদ-রঙে সাদা লেখা ≥৩:১; শিরোনাম×স্কেল ≤৩৪sp, শিরোনাম-২ ≤২৮sp, লেখা ≤২৪sp (টাকা কাটবে না); লাইন-উচ্চতা ≥১.৩; কার্ডের ভেতরের ফাঁকা ≥৮dp।

## S19 — ডিজাইন-স্টুডিও ২
| কী | ধরন | ডিফল্ট | সীমা/বিকল্প | অর্থ |
|---|---|---|---|---|
| `design.ads.min_slots` | int | `1` | 0–3 | বিজ্ঞাপন-সুইচ (`design.ad_slots`) চালু থাকলে প্রতি লেআউটে ন্যূনতম বিজ্ঞাপন-স্লট |
| `design.layout.approval_max_row` | int | `4` | 2–10 | অনুমোদন-প্যানেল সর্বোচ্চ কোন সারিতে (পর্দার বাইরে নয়) |
| `design.motion.duration_ms` | int | `200` | 0–600 | অ্যানিমেশনের সময় |
| `design.motion.easing` | text | `"standard"` | standard/emphasized/linear | গতি-রেখা |
| `design.motion.reduced` | text | `"respect_system"` | respect_system/always_reduce | ফোনের "অ্যানিমেশন বন্ধ" সবসময় মানা হয়; উপেক্ষা করার বিকল্প নেই |

## S20 — KPI-ড্যাশবোর্ড
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `design.ads.visible_max` | int | `2` | 1–2 | একসাথে দেখানো বিজ্ঞাপন (৩টি স্লট পর্যন্ত, পালাক্রমে) |
| `kpi.custom_range.max_days` | int | `366` | 7–1100 | নিজস্ব তারিখ-পরিসর |

KPI-দৃশ্যমানতা: প্রতিটি KPI-র ডিফল্ট পদ-তালিকা; চেয়ারম্যান পদভিত্তিক দেখান/লুকান (`api.v1_kpi_set_visibility`)। ফ্যাক্টরি লাভ-ক্ষতি শুধু `access.factory_pnl.positions`-এর পদে। স্টাইলে শুধু অর্থবহ রং (সতর্ক/খারাপ রং সংরক্ষিত)। নিচের ট্যাবে এখন "dashboard" বেছে নেওয়া যায়।

## S21 — রিসাইকেল-বিন
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `recycle.purge.delay_hours` | int | `72` | 1–720 | অনুমোদিত স্থায়ী-মোছার আগে অপেক্ষা |
| `recycle.bulk.max_items` | int | `100` | 1–500 | একসাথে ফেরতের সর্বোচ্চ সংখ্যা |

শ্রেণিভিত্তিক রাখার মেয়াদ: `api.v1_recycle_set_retention` (না থাকলে `recycle.retention_days`)।

## S22 — নোটিফিকেশন ও শাসন
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `notify.retention_days` | int | `90` | 7–730 | নোটিফিকেশন রাখার মেয়াদ (অডিট নয়) |
| `notify.approval.remind_after_hours` | int | `24` | 1–720 | অনুমোদন-স্মরণের সময় |
| `notify.delivery.max_attempts` | int | `5` | 1–10 | SMS/ইমেইল সর্বোচ্চ চেষ্টা |
| `governance.policy_review.required` | bool | `true` |  | অনুমোদন-নীতি বদলাতে স্বাধীন পর্যালোচক |
| `governance.critical_reviewers` | text_array | `["MD","AUDITOR"]` |  | নীতি-পর্যালোচক পদ (চেয়ারম্যানও পারেন, প্রস্তাবক কখনো নয়) |

নিরাপত্তা-নোটিফিকেশনের অ্যাপ ও SMS মাধ্যম বন্ধ করা যায় না। বিলম্ব-ঊর্ধ্বগমন: `api.v1_notify_set_escalation` (নথির ধরন, মিনিট, পদ)।

## S24 — পণ্য-মাস্টার
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `master.media.max_mb` | int | `5` | 1–20 | পণ্য-ছবির সর্বোচ্চ আকার |
| `master.qr.prefix` | text | `"MOS1"` | MOS1 | পণ্য-QR সংস্করণ |

পণ্যের নিজস্ব ঘর (যেমন মেয়াদ-দিন): `api.v1_product_set_attribute_schema` — ডায়নামিক-ফর্মের ভাষায়, সংস্করণসহ।
POLY-স্পেক (ADR-12): প্রতিটি তৈরি-পণ্যের স্যাশে/পলি ও গ্রাম/স্যাশে — দ্বিতীয় একজনের অনুমোদনে কার্যকর; পিস থেকে পলি কখনো অনুমান হয় না।

## S26–S28 — ক্রয় ও দেনা
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `procurement.match.price_tolerance_bp` | int | `100` | 0–2000 | ৩-পথ মিলে দামের সহনশীলতা (১০০ = ১%) |
| `procurement.match.qty_tolerance_bp` | int | `0` | 0–2000 | পরিমাণের সহনশীলতা |
| `procurement.grn.over_receipt_bp` | int | `0` | 0–2000 | অর্ডারের বেশি গ্রহণ |
| `procurement.grn.requires_qc` | bool | `false` |  | চালু থাকলে মান-পরীক্ষকের অধিকার ছাড়া গ্রহণ সব কোয়ারেন্টাইনে |

অনুমোদন-নীতি (কত টাকার ক্রয়-আদেশে কয়জন অনুমোদক): নথির ধরন `procurement.pr`, `procurement.po`, `procurement.po_change`, `procurement.bill_variance`, `procurement.payment`, `procurement.debit_note` — `api.v1_policy_propose` দিয়ে।

## S29–S31 — ইনভেন্টরি ও গুদাম
- `inventory.negative_stock.allowed` সবসময় `false`: চালু করার চেষ্টা সার্ভার ফিরিয়ে দেয় (মজুদ কখনো ঋণাত্মক নয়, MOS-F153-096)।
- স্থানান্তরের অনুমোদক নির্দিষ্ট করতে: অনুমোদন-নীতি (নথি `inventory.transfer`, অনুমোদক-অনুমতি `inventory.transfer.approve`) — `api.v1_policy_propose`।
- দায়িত্ব-বিভাজন (ডিফল্ট): স্থানান্তর তৈরি ↔ অনুমোদন, গণনা ↔ সমন্বয়-অনুমোদন একই পদে দেওয়া যায় না।

## S32–S35 — উৎপাদন
| কী | ধরন | ডিফল্ট | সীমা | অর্থ |
|---|---|---|---|---|
| `mfg.yield.min_pct` | int | `95` | 50–100 | এর কম উৎপাদন-হারে সমাপ্তিতে অনুমোদন; ঘাটতির খরচ আলাদা পার্থক্য-হিসাবে (ADR-11) |
| `mfg.qc.final_required` | bool | `true` |  | চূড়ান্ত QC পাস ছাড়া তৈরি-পণ্য পোস্ট নয় |

## S41–S43 — বিক্রয় ও কালেকশন
| কী | ধরন | ডিফল্ট | অর্থ |
|---|---|---|---|
| `sales.quotation.valid_days` | int | `7` | কোটেশনের মেয়াদ |
| `sales.payment_qr.providers` | text_array | `[]` | চুক্তিবদ্ধ পেমেন্ট-QR (bkash/nagad); খালি = বন্ধ |
| `sales.report.weekly_max_weeks` | int | `5` | সাপ্তাহিক-রিপোর্টে একবারে সর্বোচ্চ সপ্তাহ (মাসিক অনুমান ঠেকাতে) |

## S44–S46 — রুট ও হাজিরা
| কী | ধরন | ডিফল্ট | অর্থ |
|---|---|---|---|
| `hr.gate.qr_window_seconds` | int | `30` | হাজিরা-QR কত সেকেন্ড বৈধ |
| `hr.gate.offline_max_hours` | int | `24` | অফলাইন গেট-স্ক্যান পরে জমার সীমা |
| `hr.gate.pin_max_failures` | int | `5` | গেটে PIN-এ ১৫ মিনিটে সর্বোচ্চ ভুল |
| `hr.overtime.max_hours_month` | int | `40` | মাসিক ওভারটাইম-সীমা |
দেরি-নীতি তারিখভিত্তিক সংস্করণ (`api.v1_late_policy_add`, আজ বা পরের তারিখ থেকে)।

## S47–S55 — বেতন, অবস্থান, প্রিন্ট, রিপোর্ট
| কী | ধরন | ডিফল্ট | অর্থ |
|---|---|---|---|
| `hr.payroll.overtime_rate_pct` | int | `200` | ওভারটাইম-হার (ঘণ্টাপ্রতি মূল বেতনের %) |
| `hr.payroll.hours_per_month` | int | `208` | ঘণ্টাপ্রতি বেতন হিসাবের মাসিক ঘণ্টা |
| `location.retention_days` | int | `30` | অবস্থান-ডেটা রাখার দিন |
| `location.background.allowed` | bool | `false` | ব্যাকগ্রাউন্ড-অবস্থান (অ্যাপ এখন শুধু ফোরগ্রাউন্ড পাঠায়) |
| `location.live.stale_minutes` | int | `15` | কত মিনিট পর অবস্থান “পুরোনো” |
| `core.print_watermark.enabled` | bool | `true` | প্রিন্টে কে/কখন জলছাপ |
| `report.share.max_days` | int | `7` | রিপোর্ট-শেয়ারের সর্বোচ্চ মেয়াদ |

## S56–S57 — v180 কুরিয়ার + Prime Distribution Architect 1
| কী | ধরন | ডিফল্ট | অর্থ |
|---|---|---|---|
| `approval.financial.chairman_only` | bool | `true` | আর্থিক নথির চূড়ান্ত অনুমোদন শুধু চেয়ারম্যান |
| `mfg.fg.requires_warehouse_receipt` | bool | `true` | তৈরি-পণ্য গুদাম বুঝে নেওয়ার পর বিক্রয়যোগ্য |
বিস্তারিত ও ডিফল্ট সিদ্ধান্ত: `docs/PRIME_V180_DECISIONS_BN.md`।

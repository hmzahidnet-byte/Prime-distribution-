# MOS-F153-069 — Product approval

**Domain:** PRODUCT_MASTER  
**Blueprint status:** DESIGN PROPOSED / NOT IMPLEMENTED  
**Feature boundary:** maker checker product activation.

## 1. Business outcome
The system must support **Product approval** as a first-class, independently testable capability. User intent: maker checker product activation. The feature must work with Bengali-only Light UI, company Chairman governance, and company/wing/department/warehouse/employee/record scoping.

## 2. Data architecture
- Feature key: `MOS-F153-069`; record identity: `company_id + entity_id + version`; actor identity: `person_id + employment_id + selected_position_id`.
- Candidate contracts (names subject to canonical SQL approval): `core.company`, `iam.position_assignment`, `iam.company_membership`, `audit.event_log`.
- Record fields: `id`, `company_id`, `created_by`, `created_at`, `updated_at`, `version`, `status`, `policy_version_id`, `audit_correlation_id`; feature-specific payload for **Product approval** is typed and versioned.
- Foreign keys must enforce company alignment; all reads use RLS and all mutations go through guarded RPC. No `service_role` key in Android.

## 3. Business rules and invariants
1. **Feature-specific invariant:** author cannot approve own changes.
2. **Feature-specific processing:** maker checker product activation; validate before writing, reject inconsistent state, and expose a Bengali error reason.
3. Deny overrides Allow; employment and selected position must be active on every RPC.
4. Critical policy edits need Chairman approval plus independent reviewer, dry-run, immutable audit and explicit effective version.
5. No VAT/Tax module, no AI automation, no CCTV; posted ledger correction is reversal/replacement only.

## 4. State transitions and edge cases
- Draft → Submitted → Pending Approval → Approved/Returned/Rejected/Cancelled; Approved → Posted only for eligible financial/stock events.
- Duplicate submit: idempotency key returns original result, not a second posting.
- Concurrent update: optimistic version conflict returns current record and requires review.
- Inactive employee / revoked company membership: reject, even if a previously issued token is not expired.
- Missing dependency: fail closed and log actionable Bengali diagnostics.
- Company switch while editing: discard cached authorization and require new scoped check.

## 5. Premium UI and Chairman customization
- Screen family: `PRODUCT_MASTER` / **Product approval**; icon navigation, responsive phone/tablet layout, loading/empty/data/error/denied/offline states.
- Chairman can customize color, font, icon, widget placement, visible columns, filters, card design, and role-specific presets via versioned Design Studio.
- Live preview cannot change business data or elevate access. Accessibility: Bengali typography, contrast, TalkBack, 48dp targets, reduced motion.
- Context `⋮` actions: details, authorized image/PDF/print/share, QR where applicable; no inaccessible data in screenshots or exports.

## 6. API and security acceptance contract
- Query: scoped read by `company_id`, `selected_position_id`, permission and record state.
- Mutation: `rpc_product_master_09` **proposed interface name only**, not existing SQL. Inputs include `request_id`, `expected_version`, typed feature payload and reason if overriding.
- Audit: event type `MOS-F153-069`, actor, role, old/new version, approval chain, request ID and outcome.
- Tests: (A) valid approved product approval succeeds; (B) author cannot approve own changes violation is rejected; (C) cross-company access rejected; (D) revoked employee rejected; (E) duplicate request idempotent; (F) unauthorized export denied; (G) Bengali UI contrast and screen states validated.

## 7. Cross-module dependency and release evidence
- Required contracts: core.company, iam.position_assignment, iam.company_membership, audit.event_log.
- Evidence required before READY: canonical schema DDL, RPC tests on isolated PostgreSQL, RLS adversarial tests, Compose screen navigation, screenshot/contrast QA, audit log, and rollback demonstration.
- **Current evidence:** architectural specification only; no claim of Android compilation, PostgreSQL integration, payment-provider integration, or device tests.

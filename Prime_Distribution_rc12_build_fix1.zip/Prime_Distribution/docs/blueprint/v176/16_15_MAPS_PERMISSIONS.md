# v176/16 — Maps

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Field-sales location tracking and Google Maps routes require device consent, permission scope, purpose limitation and retention policy. Factory attendance uses fixed QR device, not mandatory continuous employee tracking. No CCTV.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

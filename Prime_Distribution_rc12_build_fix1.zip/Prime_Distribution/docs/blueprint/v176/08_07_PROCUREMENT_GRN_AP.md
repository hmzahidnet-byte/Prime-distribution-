# v176/08 — Procurement

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
PO -> receipt -> QC accepted GRN increases stock and GRNI; supplier invoice requires PO/GRN/invoice three-way match, creates AP, clears GRNI and records controlled price variances. Rejected quantities never enter accepted stock.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

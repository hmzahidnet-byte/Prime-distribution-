# v176/23 — Go/no-go

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
G0 design inventory; G1 decisions resolved; G2 canonical schema and migrations reviewed; G3 RPC/RLS reviewed with threat cases; G4 domain ledger reconciled; G5 Android contracts frozen; G6 deployment runbook reviewed. Current status: G0 partial, G1-G6 pending. Coding only after explicit owner approval of remaining design risks.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

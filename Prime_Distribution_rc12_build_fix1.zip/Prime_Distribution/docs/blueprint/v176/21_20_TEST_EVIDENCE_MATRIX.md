# v176/21 — Tests

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Required: schema migrations up/down; PostgreSQL constraints; RLS positive/negative cross-tenant; RPC authorization; concurrent stock depletion; duplicate idempotency; three-way matching; WIP/FG reconciliation; journal balancing; Android offline/error UX; accessibility and localization. None are claimed executed.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

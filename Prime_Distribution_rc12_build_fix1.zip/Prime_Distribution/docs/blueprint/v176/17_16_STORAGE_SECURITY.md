# v176/17 — Storage

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Storage bucket names, file path conventions, MIME/size allowlists, company-scoped access checks, signed URL TTL, revocation, malware scanning strategy and deletion retention must be specified before coding. Backups of PostgreSQL do not automatically include storage objects. Never expose unrestricted public bucket for sensitive documents.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

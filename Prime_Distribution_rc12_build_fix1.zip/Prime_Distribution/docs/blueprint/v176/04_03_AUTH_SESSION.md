# v176/04 — Sessions

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
No service_role key in Android. Chairman/MD MFA. Self-signup disabled. Termination revokes app sessions and prevents new RPC writes; already-issued JWT lifetime requires explicit server-side active-state checks on every privileged RPC. Break-glass sealed, independently audited and time-limited.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

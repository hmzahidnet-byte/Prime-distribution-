# v176/12 — QR

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Entity QR resolves typed company-scoped identifier, not authorization. Supported employee, dealer, retailer, product, batch, warehouse, invoice, document and transaction. Resolve through authorized server endpoint with expiry/revocation when needed; no sensitive payload in QR.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

# v176/03 — Identity

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Company membership is explicit. Employee must be active. Roles are scoped company > wing > department > warehouse > employee > record. Deny overrides allow. Chairman assignment is per company; no group chairman. Every tenant-owned row has company_id; composite foreign keys enforce company scope.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

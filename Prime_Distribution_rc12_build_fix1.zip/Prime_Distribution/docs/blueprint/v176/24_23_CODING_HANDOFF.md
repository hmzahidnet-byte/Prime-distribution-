# v176/24 — Coding sequence

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
After approval: establish canonical repo and Gradle version catalog; Supabase SQL migration skeleton and local test harness; domain models and RPC typed contracts; Android navigation/auth/IAM; manufacturing and finance vertical slice; contract tests; then build APK. Real cloud credentials and deployment deferred; local/mock backend test environment still needed for compile and verification.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

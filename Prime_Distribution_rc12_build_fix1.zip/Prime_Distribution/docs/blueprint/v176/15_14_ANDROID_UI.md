# v176/15 — Android

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Bengali-only light theme, icon-based permission-filtered home, no global KPI on home. Manufacturing landing has six product-image KPI cards, all-products drilldown, zeros shown for missing metrics, clickable lists and contextual date calendar. Universal overflow actions export/share exactly rendered authorized data. Target 90-120fps on capable devices, not a guarantee.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

# v176/22 — Pending approvals

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
D-01 numbering gapless vs unique; D-02 chairman own transaction independent approver; D-03 break-glass custody/unlock duration; D-04 official position titles; D-05 delegation expiry and limits; D-06 MD designation; D-07 CoA and GL mapping accountant approval; D-08 login model/1:1 session; D-09 monetary rounding; D-10 return valuation; D-11 residual value; D-12 POLY weight conversion; D-13 storage vendor and backup retention. Each requires owner, date, decision and version.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

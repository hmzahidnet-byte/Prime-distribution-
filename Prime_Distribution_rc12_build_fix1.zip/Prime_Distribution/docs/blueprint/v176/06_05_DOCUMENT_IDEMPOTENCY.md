# v176/06 — Idempotency

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Each posting RPC requires company-scoped idempotency key and canonical payload digest. Repeat same key and digest returns original result; same key different digest fails. Posting allocates final document number atomically. Gapless numbering remains a policy decision; never promise gaplessness under rollback without a dedicated serialized allocation protocol.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

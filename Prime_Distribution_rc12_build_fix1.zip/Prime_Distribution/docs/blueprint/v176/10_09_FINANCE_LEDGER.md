# v176/10 — Ledger

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Double-entry balanced posting, immutable posted journals, period locks and controlled exceptional backdating. Reversal/replacement links preserve original provenance. Factory P&L visible Chairman and MD per company permissions; posting approval separate from viewing.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

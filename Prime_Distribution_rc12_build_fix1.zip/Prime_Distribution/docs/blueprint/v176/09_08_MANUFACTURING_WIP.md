# v176/09 — Manufacturing

**Status:** REVIEW REQUIRED — canonical design contract; not deployed or tested.

## Normative decision
Versioned approved BOM; planned reservation, actual material issue/return, waste, rework and batch completion. Actual WIP includes material plus approved labor, utilities and overhead. Normal waste absorbed; abnormal waste expensed. Final FG in POLY units only, with defined conversion per SKU.

## Required implementation evidence
1. Exact tenant-scoped SQL DDL and migration with constraint names.
2. Explicit RPC signature, authorization predicate and transaction boundary.
3. Android typed request/response and Bengali error-state mapping.
4. Positive, negative, concurrency and replay test cases with expected outcomes.
5. Owner signoff and linked dependency IDs before coding.

## Fail-closed acceptance
Reject requests that lack tenant scope, current permission, expected workflow version, or safe transactional preconditions. Never mutate posted journals in place.

## Evidence status
Design rule recorded; executable evidence NOT PROVIDED.

# Android স্থাপত্য (S03)

## ১. স্তর (MVVM)
`Composable (UI)` → `ViewModel (UiState)` → `Repository (feature/*/data)` → `SupabaseClient (core/net)` → `api.*` RPC।
UI কখনো সরাসরি নেটওয়ার্ক বা ডেটাবেস ছোঁয় না। ViewModel শুধু `UiState<T>` (Loading / Empty / Content / Failed) দেয়।

## ২. প্যাকেজ-কাঠামো (`com.mohona.erp`)
| প্যাকেজ | কাজ |
|---|---|
| `core/net` | `SupabaseClient`, `HttpTransport`, `AppError`/`ErrorCatalog`, টোকেন |
| `core/cache` | স্মৃতি-ক্যাশ ও ক্যাশ-নীতি |
| `core/arch` | `UiState`, সাধারণ ViewModel-সহায়ক |
| `core/di` | `AppContainer` (হাতে-লেখা DI; বাড়তি লাইব্রেরি নেই) |
| `feature/<মডিউল>/{data,domain,ui}` | প্রতিটি মডিউল (iam, cfg, studio, master, proc, inv, mfg, finance, sales, hr, report, notify, maps, device) — S05 থেকে |
| `ui/theme`, `ui/components` | ডিজাইন-সিস্টেম (S04), সাধারণ কম্পোনেন্ট |
| `data/demo`, `domain` (বিদ্যমান) | Preview/ডেমো; সংযুক্ত মোডে ধীরে ধীরে feature-প্যাকেজে স্থানান্তর |

## ৩. Backend-চুক্তি
- শুধু `POST /rest/v1/rpc/<name>`, `Content-Profile/Accept-Profile: api`। টেবিলে সরাসরি পড়া/লেখা নেই (DB-তে অনুমতিই নেই)।
- RPC নাম: `v1_<মডিউল>_<ক্রিয়া>` (যেমন `v1_iam_select_position`)।
- প্রতিটি অনুরোধে `X-Request-Id`; প্রতিটি লেখার RPC-তে `Idempotency-Key` (একই কাজ পুনরায় চেষ্টা = একই কী)।
- ত্রুটি: সার্ভার বার্তা `E_CODE: বিবরণ` → `ErrorCatalog` বাংলা বার্তা। অজানা কোডও টাইপড ত্রুটি; কাঁচা সার্ভার-টেক্সট কখনো ব্যবহারকারীকে দেখানো হয় না।

## ৪. সেশন
- টোকেন শুধু মেমোরিতে (`MemoryTokenStore`)। মেয়াদ শেষের ৩০ সেকেন্ড আগে Refresh; 401 হলে একবার Refresh + একবার পুনরায় চেষ্টা (Mutex দিয়ে একটিই Refresh)।
- Refresh ব্যর্থ = সেশন মুছে `onSessionLost` → লগইন-স্ক্রিন, ক্যাশ খালি।
- "ডিভাইসে লগইন মনে রাখা" (এনক্রিপ্টেড) — Chairman-সেটিং হিসেবে S10-এ।

## ৫. ক্যাশ-নীতি
- শুধু মেমোরি; ডিভাইসের ডিস্কে কোনো ব্যবসায়িক তথ্য নয়।
- ব্যাপ্তি = ব্যক্তি + কোম্পানি + সক্রিয় পদ; পদ/কোম্পানি বদলালে সব বাতিল।
- সংবেদনশীল (P&L, বেতন, পে-স্লিপ, ব্যক্তিগত HR, ব্যাংক-হিসাব) কখনো ক্যাশ হয় না।
- ডিফল্ট TTL ৬০ সেকেন্ড; রেফারেন্স-তালিকা ১০ মিনিট।

## ৬. নির্ভরতা
নতুন লাইব্রেরি যোগ হয়নি (HttpURLConnection + org.json + coroutines)। Compile-ঝুঁকি কমাতে এই নীতি বজায় থাকবে; প্রয়োজন হলে ধাপ-নথিতে কারণসহ যোগ হবে।

# Backend-সংশোধন-তালিকা (v0.3 Migration কোথাও প্রয়োগ হয়নি ⇒ পুনর্লিখন নিরাপদ)
| # | বর্তমান (v0.3) | করণীয় | ধাপ |
|---|---|---|---|
| B01 ✅S02 | `core.organizations` kind = group/company, একক group-index | Group মুছে শুধু `core.company`; আন্তঃকোম্পানি FK নিষেধ | 2 |
| B02 ✅S02 (legacy সরানো; নতুন ব্যাপ্তি S07) | `core.user_roles.scope_type` 'group' | 'group' মুছে company/wing/department/location/self | 2, 7 |
| B03 ◐S02 (Group নেই; নিয়োগ S09) | CHAIRMAN = Group-স্তর (seed 0400) | কোম্পানি-Chairman, সর্বোচ্চ ক্ষমতা, প্রতি কোম্পানি আলাদা নিয়োগ | 2, 9 |
| B04 ✅S07 (চেয়ারম্যান সর্বোচ্চ; MD ডিফল্ট S61) | `fin.report.factory_pl` শুধু MD, অ-হস্তান্তরযোগ্য | ডিফল্ট CHAIRMAN + MD; Chairman-কনফিগযোগ্য | 7, 61 |
| B05 ✅S05 | `core.employee_accounts` (কোম্পানি-ভিত্তিক লগইন) | `iam.person` + `iam.person_auth_link` (১:১) + `iam.company_membership` | 5 |
| B06 ✅S06 | `core.user_roles` (ভূমিকার যোগফল) | `iam.position_assignment` + সক্রিয়-পদ সেশন | 6 |
| B07 ✅S07 | `core.permissions` | একক `iam.permission_catalog` | 7 |
| B08 | ১টি RPC (`api.v1_get_my_permissions`) | ব্লুপ্রিন্টের ৭১ RPC + কাস্টমাইজেশন RPC | 5–92 |
| B09 | `cfg` স্কিমা নেই | সেটিং/মেটাডেটা/Studio স্কিমা | 11–24 |
| B10 | `finance_lite` | পূর্ণ GL/AP/AR/পিরিয়ড | 53–62 |
| B11 | inventory/mfg/procurement/sales/hr স্কিমা নেই | নতুন | 32–75 |
| B12 | SQL-Test `t_od02_od03_isolation` OD-02 ধরে | নতুন লগইন-মডেলে পুনর্লিখন | 8 |

✅ = লেখা (UNVERIFIED), ◐ = আংশিক। Legacy v0.3 Migration/Test এখন `backend/supabase/legacy_v03_unapplied/` (শুধু রেফারেন্স)।

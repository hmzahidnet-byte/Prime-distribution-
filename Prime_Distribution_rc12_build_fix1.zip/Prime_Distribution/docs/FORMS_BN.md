# ডায়নামিক ফর্ম ও মাস্কিং (S14)

ব্লুপ্রিন্ট DYNAMIC_FORMS (MOS-F153-041…050) + ফিল্ড-মাস্কিংয়ের ভিত্তি (MOS-F153-029, বাকি অংশ S15)।
Migration: `backend/supabase/migrations/20261108001300_config_dynamic_forms.sql` · Test: `backend/supabase/tests/t_s14_forms.sql` (২৯) ·
Android: `feature/forms/data/` (`FormsRepository`, `FormEngine`, `FormMask`, `OfflineDraftStore`, `KeystoreDraftKey`)।
অবস্থা: লেখা হয়েছে, **চালানো হয়নি** (মালিকের নিয়ম ৫)।

## ১. ফর্ম-সংজ্ঞা (স্কিমা-ভাষা)
```json
{"title_bn":"ছুটির আবেদন","amount_field":"days","approval":{"required":false},
 "groups":[{"key":"medical","label_bn":"চিকিৎসা","visible_if":{"op":"=","field":"leave_type","value":"sick"}}],
 "fields":[{"key":"leave_type","type":"select","label_bn":"ধরন","required":true,"options":[{"value":"sick","label_bn":"অসুস্থতা"}]},
           {"key":"medical_photo","type":"photo","label_bn":"সনদ","required":true,"group":"medical"},
           {"key":"nid","type":"text","label_bn":"NID","sensitive":true,"pattern":"^[0-9]{10,17}$"}],
 "checks":[{"kind":"compare","left":"end_date","op":">=","right":"start_date","message_bn":"..."},
           {"kind":"rule","condition":{"op":"<=","field":"days","value":20},"message_bn":"..."}]}
```
- ঘরের ধরন: text, textarea, integer, decimal, money, date, datetime, bool, select, multiselect, phone, email, qr, photo, file।
- শুধু অনুমোদিত কী গ্রহণযোগ্য; script/formula/eval/on*-হ্যান্ডলার জাতীয় কী, `<script>`, `javascript:`, `${…}`, `{{…}}` → `E_FORM_SCRIPT_REJECTED`। কিছুই কখনো চালানো হয় না।
- শর্ত (`visible_if`, `required_if`, গ্রুপ, `rule` চেক) = Rule Studio-র নিরাপদ ভাষা (S13), এবং শুধু **আগের** ঘরের ওপর (চক্র অসম্ভব)।
- প্রতিটি সংরক্ষণ = নতুন অপরিবর্তনীয় সংস্করণ।

## ২. মান ও যাচাই
- সার্ভার শুধু প্রামাণিক মান নেয়: সংখ্যা JSON-সংখ্যা, তারিখ ISO (`2026-11-10`), ফোন `01XXXXXXXXX` (ASCII)। অ্যাপ বাংলা অঙ্ক/ফোন-ফরম্যাট রূপান্তর করে (`FormEngine.normalize`)।
- দৃশ্যমানতা সার্ভার নিজে নির্ণয় করে (ক্রমানুসারে, আগের দৃশ্যমান মান দিয়ে) — ক্লায়েন্ট "লুকানো" দাবি করে বাধ্যতামূলক ঘর এড়াতে পারে না। লুকানো ঘরে পাঠানো মান: বাদ (ডিফল্ট) বা প্রত্যাখ্যান (সেটিং)।
- খসড়ায় শুধু ধরন যাচাই; জমায় সব (বাধ্যতামূলক, সীমা, regex, তালিকা, ক্রস-ফিল্ড, নিয়ম) — সার্ভার প্রতিবার পুনরায় যাচাই করে। ত্রুটি `E_FORM_VALIDATION: [{"field","code","message_bn"}]`।

## ৩. জীবনচক্র
ফর্ম: খসড়া → (প্রিভিউ = শুষ্ক যাচাই) → প্রকাশ (সেটিং চালু থাকলে অনুমোদন-ইঞ্জিন দিয়ে) → সক্রিয় ⇄ আর্কাইভ (শুধু-পাঠ); রোলব্যাক = আগের প্রকাশিত সংস্করণ পুনঃপ্রকাশ।
জমা: draft → submitted (অনুমোদন লাগলে pending_approval → approved/rejected) → void / superseded (সংশোধনী)।
- প্রতিটি জমা তৈরির সময়ের সংস্করণে **পিন**; নতুন সংস্করণ পুরোনো রেকর্ড বদলায় না।
- জমা-দেওয়া/অনুমোদিত রেকর্ড কখনো সম্পাদনা নয় (`E_FORM_LOCKED`) — সংশোধনী (amend) বা বাতিল (void, কারণসহ)।
- নম্বর `core.fn_next_number('forms.<code>')`; জমা Idempotent; Rule Studio ইভেন্ট `forms.<code>` (বন্ধ/অনুমোদক-সংখ্যা/বাধ্যতামূলক অনুমোদন)।

## ৪. ঘর×পদ অনুমতি ও মাস্কিং
| স্তর | লেখা | দেখা |
|---|---|---|
| write | হ্যাঁ | পূর্ণ |
| entry | হ্যাঁ | মাস্ক-করা (সংবেদনশীল ঘরের ডিফল্ট) |
| read | না | পূর্ণ |
| masked | না | মাস্ক-করা; সংযুক্তির আইডি/লিংক কখনো নয় |
| none | না | ঘরটিই দেখা যায় না (সংজ্ঞা থেকেও বাদ) |

চেয়ারম্যান সবসময় write। রপ্তানিতে মাস্ক-করা ঘর `[গোপন]` (সেটিং), প্রতিটি রপ্তানি লগ-করা।
অডিট-ইভেন্টে শুধু ঘরের নাম যায়, মান নয়; মান-ইতিহাস `api.v1_forms_submission_history` দিয়ে পাঠকের বর্তমান অনুমতি অনুযায়ী মাস্ক-করে।
সংবেদনশীল ঘরের মান Rule Studio/অনুমোদন-অনুরোধের facts-এ যায় না।
সাধারণ মাস্ক-নীতি (`config.mask_policy`, `api.v1_mask_set_policy`, `config.fn_mask_apply`): `hr.employee.salary` ধরনের কী × পদ → show/mask/hide; S15 থেকে অন্যান্য মডিউল ব্যবহার করবে।

## ৫. সংযুক্তি (Storage)
১. `api.v1_forms_attachment_begin` → সার্ভার-নির্মিত পথ `<company>/<form>/<id>.<ext>` + ৫ মিনিটের আপলোড-অনুমতি (ধরন/আকার/SHA-256 যাচাই)।
২. অ্যাপ Supabase Storage-এ (প্রাইভেট bucket `forms`) আপলোড — `storage.objects` নীতি শুধু জীবিত, ব্যক্তিগত অনুমতি গ্রহণ করে (`api.v1_forms_storage_can_upload/read`)।
৩. `api.v1_forms_attachment_confirm` (Storage-এ বস্তু আছে কি না যাচাই) → মানে আইডি দিলে জমার সাথে যুক্ত।
৪. দেখা: `api.v1_forms_attachment_access` → নতুন স্বল্পমেয়াদি পাঠ-অনুমতি → Storage signed URL।
Migration-এর Storage-অংশ best-effort (OI-16): অনুমতি না থাকলে WARNING দেয় — তখন ড্যাশবোর্ডে একই দুটি নীতি তৈরি করুন:
`for select to authenticated using (bucket_id = 'forms' and api.v1_forms_storage_can_read(bucket_id, name))`,
`for insert to authenticated with check (bucket_id = 'forms' and api.v1_forms_storage_can_upload(bucket_id, name))`।

## ৬. অফলাইন-খসড়া
ডিভাইসে AES-256-GCM (Android Keystore-কী) এনক্রিপ্টেড, কোম্পানি+ব্যক্তি-আবদ্ধ, মেয়াদ ও সংখ্যা Chairman-সেটিং।
`api.v1_forms_draft_sync` শুধু খসড়া হালনাগাদ করে — জমা/অনুমোদন কখনো নয়; জমা-হয়ে-যাওয়া রেকর্ডে সিঙ্ক = `conflict`, মান অপরিবর্তিত।
ডিভাইসের সময় বিশ্বাস করা হয় না। ফিচার-সুইচ `forms.offline_drafts` (কোম্পানি/উইং)।

## ৭. অনুমতি
`forms.form.read`, `forms.form.manage`, `forms.submission.read/write/void/export`, `config.mask.manage`।
ডিফল্ট: সবাই (TECH/EMERGENCY ছাড়া) ফর্ম দেখা + নিজের জমা; MD সব জমা দেখা/রপ্তানি/void; WING_HEAD উইং; AUDITOR দেখা।

-- DEMO SEED (Dev only — never Staging/Production). Builds one fictional company with a realistic month of business through the
-- REAL api.* functions (every rule, approval and posting is the server's own), so tools/record_demo.py can record what each screen
-- would receive. All names, phones and amounts are fictional.
-- Run on a database that has all migrations applied:  psql -v ON_ERROR_STOP=1 -f backend/supabase/seed/demo_seed.sql
set role erp_owner;
create schema if not exists demo_seed;
create table if not exists demo_seed.ids (k text primary key, v uuid not null);
create table if not exists demo_seed.users (role text primary key, auth_uid uuid not null, person_id uuid, assignment_id uuid, session text not null, name_bn text);

create or replace function demo_seed.id(p text) returns uuid language sql stable as $$ select v from demo_seed.ids where k = p $$;
create or replace function demo_seed.put(p text, v uuid) returns uuid language sql as $$
  insert into demo_seed.ids values (p, v) on conflict (k) do update set v = excluded.v returning v $$;
-- act as a seeded user (selects the position once per session)
create or replace function demo_seed.as_role(p_role text) returns void language plpgsql as $$
declare u demo_seed.users;
begin select * into u from demo_seed.users where role = p_role;
  if u.auth_uid is null then raise exception 'no demo user %', p_role; end if;
  perform set_config('mohona.company_scope', '', false);
  perform set_config('request.jwt.claims', jsonb_build_object('sub', u.auth_uid, 'role', 'authenticated', 'session_id', u.session, 'aal', 'aal2')::text, false);
  perform api.v1_iam_select_position(u.assignment_id);
end $$;
create or replace function demo_seed.approve_pending(p_doc uuid) returns void language plpgsql as $$
declare r uuid := (select id from core.approval_request where document_id = p_doc and status = 'pending' limit 1);
begin if r is not null then perform api.v1_approval_decide(r, 'approve', (select row_version from core.approval_request where id = r), 'অনুমোদিত'); end if; end $$;

-- ------------------------------------------------------------------ 1. company and people
do $$
declare boot jsonb; ca uuid; m uuid; a uuid; p uuid; r record; i integer := 0;
begin
  p := svc.v1_iam_provision_person('মোঃ রফিকুল ইসলাম', '01710000001', null, '00000000-0000-4000-8000-000000000001', 'demo');
  boot := svc.v1_gov_bootstrap_company('PRM', 'প্রাইম ডিস্ট্রিবিউশন লিমিটেড', p, 'demo');
  ca := (boot ->> 'company_id')::uuid; perform demo_seed.put('company', ca);
  insert into demo_seed.users values ('CHAIRMAN', '00000000-0000-4000-8000-000000000001', p, (boot ->> 'chairman_assignment_id')::uuid, 'demo-ch', 'মোঃ রফিকুল ইসলাম');
  for r in select * from (values
      ('MD', 'সাইফুল আলম', '01710000002'), ('SALES_MANAGER', 'তানভীর আহমেদ', '01710000003'), ('FIELD_SALES', 'রাশেদ খান', '01710000004'),
      ('FIELD_SALES_2', 'মাসুদ রানা', '01710000005'), ('STOREKEEPER', 'কামরুল হাসান', '01710000006'), ('ACCOUNTANT', 'নাসরিন আক্তার', '01710000007'),
      ('FIN_MANAGER', 'মিজানুর রহমান', '01710000008'), ('PROD_SUPERVISOR', 'শফিকুল ইসলাম', '01710000009'), ('QC_OFFICER', 'ফারহানা ইয়াসমিন', '01710000010'),
      ('HR_OFFICER', 'সাবরিনা হক', '01710000011'), ('PURCHASE_OFFICER', 'আরিফ হোসেন', '01710000012'), ('CASHIER', 'জুয়েল রানা', '01710000013'),
      ('PAYROLL_OFFICER', 'শারমিন সুলতানা', '01710000014'), ('WING_HEAD', 'আনোয়ার হোসেন', '01710000015')) v(role, name, phone)
  loop
    i := i + 1;
    p := svc.v1_iam_provision_person(r.name, r.phone, null, ('00000000-0000-4000-8000-0000000001' || lpad(i::text, 2, '0'))::uuid, 'demo');
    m := svc.v1_iam_add_membership(p, ca, 'E-' || lpad((100 + i)::text, 4, '0'), 'demo');
    a := svc.v1_iam_assign_position(m, replace(r.role, '_2', ''), null, null, null, null, null, 'demo');
    insert into demo_seed.users values (r.role, ('00000000-0000-4000-8000-0000000001' || lpad(i::text, 2, '0'))::uuid, p, a, 'demo-' || lower(r.role), r.name);
  end loop;
end $$;

-- ------------------------------------------------------------------ 2. chart of accounts, cash/bank, warehouses, products, prices, territories, dealers
do $$
declare coa uuid; x uuid; r record; pl uuid; i integer := 0; fs1 uuid := (select person_id from demo_seed.users where role = 'FIELD_SALES');
        fs2 uuid := (select person_id from demo_seed.users where role = 'FIELD_SALES_2'); ac uuid := (select person_id from demo_seed.users where role = 'CASHIER');
begin
  perform demo_seed.as_role('FIN_MANAGER');
  coa := (api.v1_coa_seed_default('প্রাথমিক হিসাব-তালিকা') ->> 'version_id')::uuid;
  perform demo_seed.as_role('ACCOUNTANT'); perform api.v1_coa_review(coa, true, 'ঠিক আছে');
  perform demo_seed.as_role('CHAIRMAN');   perform api.v1_coa_approve(coa, 'অনুমোদিত');
  perform demo_seed.put('wh_rm', (api.v1_structure_save_warehouse(null, null, null, 'RM', 'কাঁচামাল গুদাম', 'raw_material', null, null, 'demo') ->> 'id')::uuid);
  perform demo_seed.put('wh_fg', (api.v1_structure_save_warehouse(null, null, null, 'FG', 'তৈরি পণ্যের গুদাম', 'finished_goods', null, null, 'demo') ->> 'id')::uuid);
  perform demo_seed.put('wh_qw', (api.v1_structure_save_warehouse(null, null, null, 'QW', 'ফেরত-কোয়ারেন্টাইন', 'quarantine', null, null, 'demo') ->> 'id')::uuid);
  for r in select * from (values ('p1','TEA20','প্রাইম চা-মিক্স ২০ গ্রাম', 'finished_good', 'poly'), ('p2','COF20','প্রাইম কফি-মিক্স ২০ গ্রাম', 'finished_good', 'poly'),
                                  ('p3','MAS50','প্রাইম নুডলস মশলা ৫০ গ্রাম', 'finished_good', 'poly'), ('p4','CHN150','প্রাইম চানাচুর ১৫০ গ্রাম', 'finished_good', 'poly'),
                                  ('p5','MLK25','প্রাইম দুধ-চা ২৫ গ্রাম', 'finished_good', 'poly'), ('p6','GNG20','প্রাইম আদা-চা ২০ গ্রাম', 'finished_good', 'poly'),
                                  ('m1','SUGAR','চিনি', 'raw_material', 'kg'), ('m2','MILKP','দুধের গুঁড়া', 'raw_material', 'kg'),
                                  ('m3','TEAL','চা-পাতা', 'raw_material', 'kg'), ('m4','FOIL','প্যাকেজিং ফয়েল', 'raw_material', 'kg')) v(k, code, name, kind, unit)
  loop
    perform demo_seed.put(r.k, (api.v1_product_propose(null, r.code, r.name, null, r.kind, null, r.unit, null, 'demo') ->> 'product_id')::uuid);
  end loop;
  perform demo_seed.as_role('MD');
  for r in select k from demo_seed.ids where k ~ '^[pm][0-9]$' loop perform api.v1_product_decide(demo_seed.id(r.k), 1, 'approve', 'অনুমোদিত'); end loop;
  perform demo_seed.as_role('FIN_MANAGER');
  perform demo_seed.put('cash', (api.v1_cash_account_save('MAIN', 'প্রধান ক্যাশ', '1100', ac, 'demo') ->> 'cash_account_id')::uuid);
  perform demo_seed.put('bank', (api.v1_bank_account_save('DBBL', 'ডাচ-বাংলা ব্যাংক', '••••4521', '1110', 'demo') ->> 'bank_account_id')::uuid);
  perform demo_seed.as_role('SALES_MANAGER');
  pl := demo_seed.put('pl', (api.v1_price_list_save(null, 'DEALER', 'ডিলার মূল্য-তালিকা', null, null, null, 'demo') ->> 'price_list_id')::uuid);
  perform api.v1_price_set(pl, demo_seed.id('p1'), null, 'poly', 120, current_date, 'চালু');
  perform api.v1_price_set(pl, demo_seed.id('p2'), null, 'poly', 150, current_date, 'চালু');
  perform api.v1_price_set(pl, demo_seed.id('p3'), null, 'poly', 85.50, current_date, 'চালু');
  perform api.v1_price_set(pl, demo_seed.id('p4'), null, 'poly', 60, current_date, 'চালু');
  perform api.v1_price_set(pl, demo_seed.id('p5'), null, 'poly', 135.75, current_date, 'চালু');
  perform api.v1_price_set(pl, demo_seed.id('p6'), null, 'poly', 125, current_date, 'চালু');
  for r in select * from (values ('t1','DHK','ঢাকা'), ('t2','KHL','খুলনা'), ('t3','CTG','চট্টগ্রাম'), ('t4','RAJ','রাজশাহী')) v(k, code, name) loop
    perform demo_seed.put(r.k, (api.v1_territory_save(null, r.code, r.name, null, null, null, null, 'demo') ->> 'territory_id')::uuid);
  end loop;
  for r in select * from (values
      ('d1','D-001','রহমান ট্রেডার্স','আব্দুর রহমান','01711000001','t1'), ('d2','D-002','করিম এন্টারপ্রাইজ','আব্দুল করিম','01711000002','t1'),
      ('d3','D-003','মেসার্স সালাম স্টোর','আবু সালাম','01711000003','t2'), ('d4','D-004','নিউ বিসমিল্লাহ ট্রেডার্স','হাবিবুর রহমান','01711000004','t2'),
      ('d5','D-005','চৌধুরী ডিস্ট্রিবিউশন','জসিম চৌধুরী','01711000005','t3'), ('d6','D-006','আল-আমিন এন্টারপ্রাইজ','আল-আমিন','01711000006','t3'),
      ('d7','D-007','বরেন্দ্র ট্রেডিং','মোস্তফা কামাল','01711000007','t4'), ('d8','D-008','পদ্মা স্টোর','নজরুল ইসলাম','01711000008','t4')) v(k, code, name, owner, phone, t)
  loop
    i := i + 1;
    x := demo_seed.put(r.k, (api.v1_dealer_save(null, r.code, r.name, r.owner, r.phone, null, null, demo_seed.id(r.t), case when i % 2 = 1 then fs1 else fs2 end, 0, 30, null, 'demo') ->> 'dealer_id')::uuid);
  end loop;
  perform demo_seed.as_role('CHAIRMAN');
  for r in select k from demo_seed.ids where k ~ '^d[0-9]$' loop
    perform api.v1_dealer_save(demo_seed.id(r.k), null, d.name_bn, d.owner_name_bn, d.phone, null, null, d.territory_id, d.officer_id, 300000, 30, d.row_version, 'ঋণসীমা')
      from sales.dealer d where d.id = demo_seed.id(r.k);
  end loop;
  perform demo_seed.as_role('STOREKEEPER');
  perform api.v1_stock_receive(demo_seed.id('wh_fg'), demo_seed.id('p' || g), 'OP-' || g, null, null, current_date + 240, 6000, 0, 0, 55 + g * 10, false, 'প্রারম্ভিক মজুত')
    from generate_series(1, 6) g;
  perform api.v1_stock_receive(demo_seed.id('wh_rm'), demo_seed.id('m1'), 'RM-S1', null, null, current_date + 300, 2000, 0, 0, 120, false, 'প্রারম্ভিক');
  perform api.v1_stock_receive(demo_seed.id('wh_rm'), demo_seed.id('m2'), 'RM-M1', null, null, current_date + 300, 800, 0, 0, 520, false, 'প্রারম্ভিক');
  perform api.v1_stock_receive(demo_seed.id('wh_rm'), demo_seed.id('m3'), 'RM-T1', null, null, current_date + 300, 500, 0, 0, 380, false, 'প্রারম্ভিক');
  perform api.v1_stock_receive(demo_seed.id('wh_rm'), demo_seed.id('m4'), 'RM-F1', null, null, current_date + 300, 300, 0, 0, 260, false, 'প্রারম্ভিক');
end $$;

-- ------------------------------------------------------------------ 3. a month of sales: orders -> approval -> dispatch -> invoice -> collections
do $$
declare n integer; dl uuid; o jsonb; inv jsonb; c jsonb; lines jsonb; fsrole text; amt numeric; meth text; g integer; k integer;
begin
  for n in 1..36 loop
    dl := demo_seed.id('d' || (1 + (n * 5) % 8));
    fsrole := case when (select officer_id from sales.dealer where id = dl) = (select person_id from demo_seed.users where role = 'FIELD_SALES') then 'FIELD_SALES' else 'FIELD_SALES_2' end;
    lines := '[]'::jsonb;
    for g in 1..6 loop
      if (n + g) % 3 <> 0 then lines := lines || jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('p' || g), 'qty', 40 + ((n * 7 + g * 13) % 9) * 15)); end if;
    end loop;
    perform demo_seed.as_role(fsrole);
    o := api.v1_order_create(dl, demo_seed.id('wh_fg'), demo_seed.id('pl'), lines, null);
    perform demo_seed.put('order' || n, (o ->> 'order_id')::uuid);
    continue when n > 33;                                  -- the last three wait for approval (Chairman / MD inbox)
    perform demo_seed.as_role('MD'); perform demo_seed.approve_pending((o ->> 'order_id')::uuid);
    continue when n > 31;                                  -- approved, not yet dispatched (warehouse queue)
    perform demo_seed.as_role('STOREKEEPER');
    perform api.v1_order_pick((o ->> 'order_id')::uuid); perform api.v1_order_pack((o ->> 'order_id')::uuid, 4 + n % 5);
    perform api.v1_dispatch_post((o ->> 'order_id')::uuid, 'ঢাকা-মেট্রো-ট-' || (1100 + n), null);
    continue when n > 29;                                  -- dispatched, invoice pending
    perform demo_seed.as_role('ACCOUNTANT');
    inv := api.v1_invoice_post((o ->> 'order_id')::uuid);
    perform demo_seed.put('inv' || n, (inv ->> 'invoice_id')::uuid);
    continue when n % 4 = 0;                               -- some invoices stay fully due
    amt := (select total from sales.invoice where id = (inv ->> 'invoice_id')::uuid);
    if n % 3 = 0 then amt := round(amt * 0.6, 2); end if;
    meth := case when n % 5 = 0 then 'bkash' when n % 2 = 0 then 'bank' else 'cash' end;
    perform demo_seed.as_role(fsrole);
    c := api.v1_collection_record(dl, meth, amt, case when meth = 'cash' then null else 'TRX' || (500000 + n) end, null,
                                  jsonb_build_array(jsonb_build_object('invoice_id', inv ->> 'invoice_id', 'amount', amt)));
    continue when n > 26;                                  -- reported, waiting for verification
    perform demo_seed.as_role('ACCOUNTANT');
    if meth = 'bank' then
      perform api.v1_bank_statement_import(demo_seed.id('bank'), jsonb_build_array(jsonb_build_object('date', current_date, 'amount', amt, 'reference', 'TRX' || (500000 + n), 'description', 'ডিলার জমা')));
      perform api.v1_collection_verify((c ->> 'collection_id')::uuid, null, (select id from finance.bank_statement_line where reference = 'TRX' || (500000 + n) limit 1));
    elsif meth = 'cash' then
      perform api.v1_collection_verify((c ->> 'collection_id')::uuid, demo_seed.id('cash'), null);
    else
      perform svc.v1_provider_confirm(demo_seed.id('company'), 'bkash', 'TRX' || (500000 + n), amt, '01711000999', 'verified');
      perform demo_seed.as_role('ACCOUNTANT');
      perform api.v1_collection_verify((c ->> 'collection_id')::uuid, null, null);
    end if;
  end loop;
end $$;

-- ------------------------------------------------------------------ 4. factory: pack spec, recipe, plan, batches (one finished, one running)
do $$
declare spec uuid; bom uuid; plan uuid; b1 jsonb; b2 jsonb; j jsonb; g integer;
begin
  perform demo_seed.as_role('PROD_SUPERVISOR');
  spec := (api.v1_pack_spec_propose(demo_seed.id('p1'), null, 12, 20, 24, null, 'প্যাকিং-নিয়ম') ->> 'spec_id')::uuid;
  bom := (api.v1_bom_propose(demo_seed.id('p1'), null, 1000, jsonb_build_array(
            jsonb_build_object('material_id', demo_seed.id('m1'), 'qty', 120), jsonb_build_object('material_id', demo_seed.id('m2'), 'qty', 60),
            jsonb_build_object('material_id', demo_seed.id('m3'), 'qty', 25), jsonb_build_object('material_id', demo_seed.id('m4'), 'qty', 8)), 'রেসিপি সংস্করণ ১') ->> 'bom_id')::uuid;
  perform demo_seed.as_role('MD');
  perform api.v1_pack_spec_decide(spec, 'approve', 'ঠিক আছে'); perform api.v1_bom_decide(bom, true, 'ঠিক আছে');
  perform demo_seed.as_role('PROD_SUPERVISOR');
  plan := (api.v1_plan_save(null, current_date, null, jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('p1'), 'target_poly', 3000)), 'আজকের পরিকল্পনা') ->> 'plan_id')::uuid;
  perform demo_seed.as_role('MD'); perform api.v1_plan_approve(plan, 'ঠিক আছে');
  perform demo_seed.as_role('PROD_SUPERVISOR');
  b1 := api.v1_batch_create(demo_seed.id('p1'), null, null, 2000, demo_seed.id('wh_rm'), demo_seed.id('wh_fg'), 'লাইন-১', plan, 1, 'সকালের ব্যাচ');
  b2 := api.v1_batch_create(demo_seed.id('p1'), null, null, 1000, demo_seed.id('wh_rm'), demo_seed.id('wh_fg'), 'লাইন-২', plan, 2, 'বিকেলের ব্যাচ');
  perform demo_seed.put('batch1', (b1 ->> 'batch_id')::uuid); perform demo_seed.put('batch2', (b2 ->> 'batch_id')::uuid);
  perform demo_seed.as_role('MD');
  perform api.v1_batch_approve((b1 ->> 'batch_id')::uuid, 'চালু করুন'); perform api.v1_batch_approve((b2 ->> 'batch_id')::uuid, 'চালু করুন');
  perform demo_seed.as_role('STOREKEEPER');
  for g in 1..4 loop
    perform api.v1_material_issue(r.id, r.qty, null, 'ইস্যু')
      from inventory.reservation r where r.batch_ref = b1 ->> 'number' and r.product_id = demo_seed.id('m' || g) and r.status = 'active';
    perform api.v1_material_issue(r.id, round(r.qty / 2, 3), null, 'আংশিক ইস্যু')
      from inventory.reservation r where r.batch_ref = b2 ->> 'number' and r.product_id = demo_seed.id('m' || g) and r.status = 'active';
  end loop;
  perform demo_seed.as_role('PROD_SUPERVISOR');
  perform api.v1_batch_cost((b1 ->> 'batch_id')::uuid, 'labor', 4500, 'শিফট-মজুরি');
  perform api.v1_batch_cost((b1 ->> 'batch_id')::uuid, 'overhead', 2200, 'গ্যাস ও বিদ্যুৎ');
  perform demo_seed.as_role('QC_OFFICER');
  perform api.v1_batch_qc((b1 ->> 'batch_id')::uuid, 'final', 'pass', '{"moisture": 3.2}', 'মান ঠিক আছে');
  perform demo_seed.as_role('PROD_SUPERVISOR');
  perform api.v1_batch_waste((b1 ->> 'batch_id')::uuid, 'normal', 15, 'ফয়েল-কাটা');
  perform api.v1_batch_complete((b1 ->> 'batch_id')::uuid, 1980, null, current_date + 240, 'সম্পন্ন');
end $$;

-- ------------------------------------------------------------------ 5. purchase: suppliers, requisition, PO, goods received
do $$
declare s1 uuid; s2 uuid; pr uuid; po uuid; pl uuid;
begin
  perform demo_seed.as_role('PURCHASE_OFFICER');
  s1 := demo_seed.put('sup1', (api.v1_supplier_save(null, 'SUP01', 'মেঘনা সুগার মিলস', null, '01811000001', null, 'নারায়ণগঞ্জ', null, null, 30, null, '••••7781', null, null, 'নতুন সরবরাহকারী') ->> 'supplier_id')::uuid);
  s2 := demo_seed.put('sup2', (api.v1_supplier_save(null, 'SUP02', 'সিলেট টি এস্টেট', null, '01811000002', null, 'সিলেট', null, null, 15, null, null, null, null, 'নতুন সরবরাহকারী') ->> 'supplier_id')::uuid);
  pr := (api.v1_pr_save(null, null, null, current_date + 10, jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('m1'), 'qty', 1000, 'est_price', 125)), 'মাসিক চিনি') ->> 'pr_id')::uuid;
  perform api.v1_pr_action(pr, 'submit', 'চিনি দরকার');
  perform demo_seed.as_role('CHAIRMAN'); perform demo_seed.approve_pending(pr);
  perform demo_seed.as_role('PURCHASE_OFFICER');
  perform api.v1_pr_quote_add(pr, s1, demo_seed.id('m1'), 118, 5);
  po := demo_seed.put('po1', (api.v1_po_create(s1, demo_seed.id('wh_rm'), pr, current_date + 7, null, jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('m1'), 'qty', 1000, 'unit_price', 118)), 'চিনি ক্রয়') ->> 'po_id')::uuid);
  perform api.v1_po_action(po, 'submit', (select x_.row_version from procurement.po x_ where x_.id = po), 'অনুমোদন দিন');
  perform demo_seed.as_role('CHAIRMAN'); perform demo_seed.approve_pending(po);
  perform demo_seed.as_role('STOREKEEPER');
  pl := (select id from procurement.po_line where po_id = po and line_no = 1);
  perform api.v1_grn_post(po, 'চালান-৫৫', jsonb_build_array(jsonb_build_object('po_line_id', pl, 'lot_no', 'SG-11', 'expiry_date', current_date + 300, 'received', 600, 'accepted', 590, 'quarantine', 0, 'rejected', 10)), 'প্রথম ট্রাক');
  perform demo_seed.as_role('PURCHASE_OFFICER');
  po := (api.v1_po_create(s2, demo_seed.id('wh_rm'), null, current_date + 12, null, jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('m3'), 'qty', 300, 'unit_price', 390)), 'চা-পাতা ক্রয়') ->> 'po_id')::uuid;
  perform api.v1_po_action(po, 'submit', (select x_.row_version from procurement.po x_ where x_.id = po), 'অনুমোদন দিন');      -- left pending for the Chairman
end $$;

-- ------------------------------------------------------------------ 6. dealer app: invitation, notices/offers, order request, delivery, payment report
do $$
declare inv jsonb; dp uuid; da uuid; nt uuid; nt2 uuid; rq jsonb; j jsonb; od uuid; ds jsonb;
begin
  perform demo_seed.as_role('SALES_MANAGER');
  inv := api.v1_dealer_portal_invite(demo_seed.id('d1'), 'আব্দুর রহমান', '01711000001', 'owner', 'ডিলার-অ্যাপ');
  dp := (inv ->> 'person_id')::uuid; da := (select assignment_id from sales.dealer_user where id = (inv ->> 'dealer_user_id')::uuid);
  insert into iam.person_auth_link (person_id, auth_user_id) values (dp, '00000000-0000-4000-8000-000000000201');
  insert into demo_seed.users values ('DEALER_PORTAL', '00000000-0000-4000-8000-000000000201', dp, da, 'demo-dealer', 'আব্দুর রহমান (রহমান ট্রেডার্স)');
  nt := (api.v1_dealer_notice_save('offer', 'শীতের অফার', '২০ কার্টন নিলে ১ কার্টন চা-মিক্স ফ্রি', null, null, null, null, '{"min_order_amount": 50000}'::jsonb, current_date, current_date + 20) ->> 'notice_id')::uuid;
  nt2 := (api.v1_dealer_notice_save('notice', 'নতুন পণ্য: আদা-চা', 'প্রাইম আদা-চা এখন সব এলাকায় পাওয়া যাচ্ছে', null, null, null, null, null, current_date, current_date + 30) ->> 'notice_id')::uuid;
  perform demo_seed.as_role('MD');
  perform api.v1_dealer_notice_publish(nt); perform api.v1_dealer_notice_publish(nt2);
  perform demo_seed.as_role('DEALER_PORTAL');
  perform api.v1_dealer_notice_read(nt2);
  rq := api.v1_dealer_order_request(jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('p1'), 'qty', 120), jsonb_build_object('product_id', demo_seed.id('p6'), 'qty', 60)), 'শুক্রবারের আগে দরকার', 'REQ-DEMO-0001');
  perform api.v1_dealer_order_request(jsonb_build_array(jsonb_build_object('product_id', demo_seed.id('p2'), 'qty', 80)), 'কফি-মিক্স শেষ', 'REQ-DEMO-0002');   -- stays pending
  perform demo_seed.as_role('SALES_MANAGER');
  j := api.v1_dealer_order_request_decide((rq ->> 'request_id')::uuid, true, demo_seed.id('wh_fg'), demo_seed.id('pl'), 'গ্রহণ');
  od := coalesce((j ->> 'order_id')::uuid, (select order_id from sales.dealer_order_request where id = (rq ->> 'request_id')::uuid));
  perform demo_seed.as_role('MD'); perform demo_seed.approve_pending(od);
  perform demo_seed.as_role('STOREKEEPER');
  perform api.v1_order_pick(od); perform api.v1_order_pack(od, 3);
  ds := api.v1_dispatch_post(od, 'ঢাকা-মেট্রো-ট-২২০১', null);
  perform demo_seed.as_role('ACCOUNTANT'); perform api.v1_invoice_post(od);
  perform demo_seed.as_role('DEALER_PORTAL');
  perform api.v1_dealer_delivery_ack((ds ->> 'dispatch_id')::uuid, jsonb_build_array(jsonb_build_object('kind', 'damaged', 'product_id', demo_seed.id('p1'), 'qty', 2, 'note', 'দুটি পলি ছেঁড়া')));
  perform api.v1_dealer_payment_report('bkash', 15000, 'BK778899001', null);
end $$;

-- ------------------------------------------------------------------ 7. people: salaries, attendance, leave, payroll, recruitment
do $$
declare r record; emp uuid; per date := date_trunc('month', current_date)::date; j jsonb; run uuid; vac uuid; ap uuid; i integer := 0;
begin
  perform demo_seed.as_role('HR_OFFICER');
  for r in select u.role, u.person_id from demo_seed.users u where u.role not in ('CHAIRMAN', 'DEALER_PORTAL') loop
    i := i + 1;
    emp := (select id from hr.employee where person_id = r.person_id and company_id = demo_seed.id('company'));
    continue when emp is null;
    perform api.v1_salary_set(emp, per, 'G' || (1 + i % 6), 18000 + i * 2500, '[{"code":"HOUSE","name_bn":"বাড়িভাড়া","amount":5000}]', '[{"code":"PF","name_bn":"ভবিষ্য তহবিল","amount":800}]', 'যোগদান-বেতন');
    perform api.v1_attendance_manual(emp, date_trunc('day', now()) + interval '9 hours' + (i || ' minutes')::interval, 'হাজিরা');
  end loop;
  perform api.v1_leave_type_save('CASUAL', 'নৈমিত্তিক ছুটি', 10);
  perform api.v1_leave_type_save('SICK', 'অসুস্থতা ছুটি', 14);
  j := api.v1_payroll_calculate(per); run := (j ->> 'run_id')::uuid; perform demo_seed.put('payroll_run', run);
  vac := (api.v1_vacancy_save('FIELD_SALES', null, 'মাঠ-বিক্রয়কর্মী (রাজশাহী)', 2, 'রাজশাহী এলাকার জন্য দুইজন') ->> 'vacancy_id')::uuid;
  perform demo_seed.put('vacancy', vac);
end $$;

-- ------------------------------------------------------------------ 8. the rest of a normal day (each step optional: a rule that refuses it only leaves a NOTICE)
create or replace function demo_seed.try(p_role text, p_sql text) returns jsonb language plpgsql as $$
declare v jsonb;
begin perform demo_seed.as_role(p_role); execute 'select to_jsonb((' || p_sql || '))' into v; return v;
exception when others then raise notice 'DEMO SKIPPED [%] %: %', p_role, left(p_sql, 80), sqlerrm; return null; end $$;
do $$
declare per date := date_trunc('month', current_date)::date; mk uuid; j jsonb; v uuid; inv uuid := demo_seed.id('inv3');
        fs1 uuid := (select person_id from demo_seed.users where role = 'FIELD_SALES'); fs2 uuid := (select person_id from demo_seed.users where role = 'FIELD_SALES_2');
begin
  -- money requests in the Chairman inbox
  perform demo_seed.try('ACCOUNTANT', $q$api.v1_money_request('expense', 'factory', 'electricity', 48650.75, 'bank', null, null, null, null, null, null, 'DESCO-1125', 'নভেম্বরের বিদ্যুৎ বিল')$q$);
  perform demo_seed.try('ACCOUNTANT', $q$api.v1_money_request('expense', 'dms', 'transport', 12500, 'cash', null, null, null, null, null, null, 'TR-0091', 'ডেলিভারি ভ্যানের জ্বালানি')$q$);
  j := demo_seed.try('ACCOUNTANT', $q$api.v1_money_request('expense', 'office', 'stationery', 3250.50, 'cash', null, null, null, null, null, null, 'ST-0007', 'অফিস-সামগ্রী')$q$);
  if j is not null then perform demo_seed.try('CHAIRMAN', format('api.v1_money_request_decide(%L, true)', j ->> 'request_id')); end if;
  -- a market return into quarantine
  perform demo_seed.try('SALES_MANAGER', format($q$api.v1_sales_return(%L, %L, jsonb_build_array(jsonb_build_object('product_id', %L, 'lot_id', (select id from inventory.lot where lot_no = 'OP-1' limit 1), 'qty', 6, 'condition', 'damaged')), 'ছেঁড়া প্যাকেট')$q$,
                                         inv, demo_seed.id('wh_qw'), demo_seed.id('p1')));
  -- markets and retailers (map)
  mk := (demo_seed.try('SALES_MANAGER', format($q$api.v1_market_save(null, 'MK01', 'কারওয়ান বাজার', %L, null, null, 'বাজার') ->> 'market_id'$q$, demo_seed.id('t1'))) #>> '{}')::uuid;
  perform demo_seed.try('SALES_MANAGER', format($q$api.v1_market_save(null, 'MK02', 'বড় বাজার খুলনা', %L, null, null, 'বাজার')$q$, demo_seed.id('t2')));
  perform demo_seed.try('SALES_MANAGER', format($q$api.v1_retailer_save(null, 'R-001', 'মায়ের দোয়া স্টোর', '01911000001', %L, null, 23.7509, 90.3935, null, null, 'দোকান')$q$, demo_seed.id('d1')));
  perform demo_seed.try('SALES_MANAGER', format($q$api.v1_retailer_save(null, 'R-002', 'হক জেনারেল স্টোর', '01911000002', %L, null, 23.7465, 90.3760, null, null, 'দোকান')$q$, demo_seed.id('d2')));
  perform demo_seed.try('SALES_MANAGER', format($q$api.v1_location_claim_submit('dealer', %L, 23.7515, 90.3920, 12, null, 'কারওয়ান বাজার, ঢাকা', 'device_gps', null, null, 'LC-DEMO-1')$q$, demo_seed.id('d1')));
  -- targets and visits
  perform demo_seed.try('SALES_MANAGER', format('api.v1_sales_target(%L, %L, 900000)', per, fs1));
  perform demo_seed.try('SALES_MANAGER', format('api.v1_sales_target(%L, %L, 750000)', per, fs2));
  j := demo_seed.try('FIELD_SALES', format('api.v1_visit_plan(%L, null, %L)', demo_seed.id('d1'), current_date));
  if j is not null then
    v := coalesce((j ->> 'visit_id')::uuid, (j #>> '{}')::uuid);
    perform demo_seed.try('FIELD_SALES', format('api.v1_visit_check_in(%L, 23.7512, 90.3925)', v));
  end if;
  perform demo_seed.try('FIELD_SALES', format('api.v1_visit_plan(%L, null, %L)', demo_seed.id('d3'), current_date + 1));
  -- a dealer dispute
  perform demo_seed.try('SALES_MANAGER', format($q$api.v1_dispute_raise(%L, 'invoice', 'ইনভয়েস', 'চালানে ২ পলি কম এসেছে')$q$, demo_seed.id('d3')));
  -- leave request by a staff member, applicant for the vacancy
  perform demo_seed.try('STOREKEEPER', format($q$api.v1_leave_request('CASUAL', %L, %L, 'পারিবারিক কাজ')$q$, current_date + 3, current_date + 4));
  perform demo_seed.try('CHAIRMAN', format($q$api.v1_vacancy_action(%L, 'open', 'অনুমোদিত')$q$, demo_seed.id('vacancy')));
  perform demo_seed.try('HR_OFFICER', format($q$api.v1_applicant_add(%L, 'রাকিবুল হাসান', '01611000001', null, 'রেফারেন্স')$q$, demo_seed.id('vacancy')));
  perform demo_seed.try('HR_OFFICER', format($q$api.v1_applicant_add(%L, 'সুমাইয়া আক্তার', '01611000002', null, 'বিজ্ঞাপন')$q$, demo_seed.id('vacancy')));
end $$;

-- ------------------------------------------------------------------ 9. spread the month over the last six weeks (demo only: graphs need history).
-- Guard triggers are bypassed ONLY here, in this dev seed, to move dates back; amounts and links stay exactly as the server posted them.
reset role;
set session_replication_role = replica;
do $$
declare n integer; o uuid; back integer; t timestamptz; inv uuid; c record; d record;
begin
  for n in 1..36 loop
    o := demo_seed.id('order' || n); continue when o is null;
    back := greatest(0, round((36 - n) * 1.25)::integer);
    t := now() - make_interval(days => back);
    update sales.sales_order set created_at = t where id = o;
    for d in select id from sales.dispatch where order_id = o loop
      update sales.dispatch set dispatched_at = t + interval '5 hours' where id = d.id;
      update finance.journal set journal_date = (t + interval '5 hours')::date, created_at = t, posted_at = t where posting_key in ('dispatch:' || d.id, 'cogs:' || d.id);
    end loop;
    inv := (select id from sales.invoice where order_id = o);
    continue when inv is null;
    update sales.invoice set invoice_date = (t + interval '6 hours')::date, due_date = (t + interval '6 hours')::date + 30, posted_at = t + interval '6 hours' where id = inv;
    update finance.journal set journal_date = (t + interval '6 hours')::date, created_at = t, posted_at = t where posting_key = 'invoice:' || inv;
    for c in select id from sales.collection where allocations @> jsonb_build_array(jsonb_build_object('invoice_id', inv)) loop
      update sales.collection set collected_at = t + interval '3 days', verified_at = case when verified_at is null then null else t + interval '3 days 4 hours' end where id = c.id;
      update finance.journal set journal_date = (t + interval '3 days 4 hours')::date where posting_key = 'collection:' || c.id;
    end loop;
  end loop;
end $$;
set session_replication_role = origin;

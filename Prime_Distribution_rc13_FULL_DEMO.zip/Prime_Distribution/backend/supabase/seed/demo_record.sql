-- DEMO RECORDER (Dev only). After demo_seed.sql: calls every READ api.* function the app uses, as every demo position, and stores
-- what the server answered (or the error it raised) in demo_seed.fixture. Every call runs in a sub-transaction that is ROLLED BACK,
-- so recording changes nothing. tools/build_demo_assets.py turns the table into app/src/main/assets/demo/rpc_fixtures.json.
reset role;
create table if not exists demo_seed.fixture (role text not null, rpc text not null, match jsonb not null default '{}', body jsonb, err_state text, err_message text,
                                              primary key (role, rpc, match));
create table if not exists demo_seed.param_source (param text primary key, many boolean not null, src text not null);
truncate demo_seed.fixture; truncate demo_seed.param_source;
insert into demo_seed.param_source values
  ('p_dealer_id', true,  $$select id::text from sales.dealer order by code$$),
  ('p_order_id', true,   $$select id::text from sales.sales_order order by created_at desc$$),
  ('p_invoice_id', true, $$select id::text from sales.invoice order by invoice_date desc$$),
  ('p_dispatch_id', true, $$select id::text from sales.dispatch order by dispatched_at desc$$),
  ('p_product_id', true, $$select id::text from inventory.product order by sku$$),
  ('p_batch_id', true,   $$select id::text from mfg.batch order by number$$),
  ('p_supplier_id', true, $$select id::text from procurement.supplier order by code$$),
  ('p_po_id', true,      $$select id::text from procurement.po order by number$$),
  ('p_employee_id', true, $$select id::text from hr.employee order by employee_code$$),
  ('p_territory_id', true, $$select id::text from sales.territory order by code$$),
  ('p_order_request_id', true, $$select id::text from sales.dealer_order_request$$),
  ('p_collection_id', true, $$select id::text from sales.collection$$),
  ('p_code', true,       $$select code from report.kpi_catalog order by code$$),
  ('p_kind', true,       $$select k from demo_seed.lookup_kind$$),
  ('p_warehouse_id', false, $$select demo_seed.id('wh_fg')::text$$),
  ('p_price_list_id', false, $$select demo_seed.id('pl')::text$$),
  ('p_run_id', false,    $$select demo_seed.id('payroll_run')::text$$),
  ('p_vacancy_id', false, $$select demo_seed.id('vacancy')::text$$),
  ('p_company_id', false, $$select demo_seed.id('company')::text$$),
  ('p_period', false,    $$select date_trunc('month', current_date)::date::text$$),
  ('p_month', false,     $$select date_trunc('month', current_date)::date::text$$),
  ('p_from', false,      $$select (current_date - 60)::text$$),
  ('p_to', false,        $$select current_date::text$$);
create table if not exists demo_seed.lookup_kind (k text primary key);
create table if not exists demo_seed.rpc_list (name text primary key);

create or replace function demo_seed.call_one(p_rpc text, p_oid oid, p_set jsonb) returns jsonb language plpgsql as $$
-- p_set: {param: value-text}; params not given are passed as NULL when they have no default
declare f record; args text := ''; i integer; n text; t text; v jsonb; q text; nreq integer;
begin
  select p.proname, p.pronargs, p.pronargdefaults, p.proargnames, p.proargtypes::oid[] as types, p.proretset into f from pg_proc p where p.oid = p_oid;
  nreq := f.pronargs - f.pronargdefaults;
  for i in 1..f.pronargs loop
    n := f.proargnames[i]; t := format_type(f.types[i - 1], null);
    if p_set ? n then args := args || case when args = '' then '' else ', ' end || format('%I => %L::%s', n, p_set ->> n, t);
    elsif i <= nreq then args := args || case when args = '' then '' else ', ' end || format('%I => null::%s', n, t);
    end if;
  end loop;
  q := case when f.proretset then format('select coalesce(jsonb_agg(to_jsonb(t_)), ''[]''::jsonb) from api.%I(%s) t_', p_rpc, args)
            else format('select to_jsonb(api.%I(%s))', p_rpc, args) end;
  begin
    execute q into v;
    raise exception using errcode = 'DMORB', message = 'demo rollback';
  exception when sqlstate 'DMORB' then return jsonb_build_object('ok', true, 'body', coalesce(v, 'null'::jsonb));
            when others then return jsonb_build_object('ok', false, 'state', sqlstate, 'message', sqlerrm);
  end;
end $$;

create or replace function demo_seed.record(p_role text, p_writes text[]) returns integer language plpgsql as $$
declare r record; a record; base jsonb; res jsonb; vals text[]; vparam text; fixed jsonb; val text; n integer := 0; cnt integer;
begin
  perform set_config('demo.role', p_role, false);
  perform demo_seed.as_role(p_role);
  for r in select l.name, (select p.oid from pg_proc p where p.proname = l.name and p.pronamespace = 'api'::regnamespace order by p.pronargs desc limit 1) as oid
           from demo_seed.rpc_list l where not (l.name = any (p_writes)) loop
    continue when r.oid is null;
    fixed := '{}'; vparam := null; vals := null;
    for a in select x.n, ps.many, ps.src from pg_proc p, unnest(p.proargnames[1:p.pronargs]) with ordinality x(n, i)
             join demo_seed.param_source ps on ps.param = x.n where p.oid = r.oid loop
      continue when a.n = 'p_code' and r.name not like 'v1_kpi%';
      continue when a.n = 'p_kind' and r.name <> 'v1_lookup';
      continue when a.n in ('p_period', 'p_month', 'p_from', 'p_to') and r.name like 'v1_kpi%';
      if a.many and vparam is null then
        vparam := a.n; execute 'select array(' || a.src || ' limit 40)' into vals;
      else
        execute a.src into val; if val is not null then fixed := fixed || jsonb_build_object(a.n, val); end if;
      end if;
    end loop;
    -- base answer: fixed params only (the first variant value when the variant parameter is required)
    if vparam is not null and coalesce(array_length(vals, 1), 0) > 0 and
       (select x.i <= p.pronargs - p.pronargdefaults from pg_proc p, unnest(p.proargnames) with ordinality x(n, i) where p.oid = r.oid and x.n = vparam) then
      base := fixed || jsonb_build_object(vparam, vals[1]);
    else base := fixed; end if;
    res := demo_seed.call_one(r.name, r.oid, base);
    insert into demo_seed.fixture values (p_role, r.name, '{}', res -> 'body', res ->> 'state', res ->> 'message') on conflict do nothing;
    n := n + 1;
    continue when vparam is null or not (res ->> 'ok')::boolean and res ->> 'state' <> 'P0001';
    cnt := 0;
    foreach val in array coalesce(vals, '{}') loop
      res := demo_seed.call_one(r.name, r.oid, fixed || jsonb_build_object(vparam, val));
      continue when not (res ->> 'ok')::boolean;
      insert into demo_seed.fixture values (p_role, r.name, jsonb_build_object(vparam, val), res -> 'body', null, null) on conflict do nothing;
      n := n + 1;
    end loop;
  end loop;
  return n;
end $$;
insert into demo_seed.param_source values ('p_assignment_id', false, $$select assignment_id::text from demo_seed.users where role = current_setting('demo.role')$$) on conflict do nothing;
insert into demo_seed.param_source values ('p_grain', false, $$select 'week'$$) on conflict do nothing;
insert into demo_seed.param_source values
  ('p_account_code', true, $$select a.code from finance.account a where exists (select 1 from finance.journal_line l where l.account_id = a.id) order by a.code$$),
  ('p_number', true, $$select number from sales.invoice order by invoice_date desc$$),
  ('p_membership_id', true, $$select id::text from iam.company_membership order by created_at$$),
  ('p_bank_account_id', false, $$select demo_seed.id('bank')::text$$),
  ('p_lot_id', true, $$select id::text from inventory.lot order by lot_no$$),
  ('p_fg_lot_id', true, $$select fg_lot_id::text from mfg.batch where fg_lot_id is not null$$),
  ('p_party_id', true, $$select id::text from sales.party$$)
on conflict do nothing;
-- KPI cards: every period, all KPIs (the app asks for <= 30 codes at a time; the demo answers any subset from this)
create or replace function demo_seed.record_kpi(p_role text) returns integer language plpgsql as $$
declare per text; res jsonb; res2 jsonb; o oid := (select oid from pg_proc where proname = 'v1_kpi_values' and pronamespace = 'api'::regnamespace limit 1);
        codes text[] := array(select code from report.kpi_catalog order by code); n integer := 0;
begin
  perform set_config('demo.role', p_role, false); perform demo_seed.as_role(p_role);
  foreach per in array array['today','yesterday','this_week','this_month','last_month','this_year'] loop
    res := demo_seed.call_one('v1_kpi_values', o, jsonb_build_object('p_codes', codes[1:30]::text, 'p_period', per));
    res2 := demo_seed.call_one('v1_kpi_values', o, jsonb_build_object('p_codes', codes[31:60]::text, 'p_period', per));
    continue when not (res ->> 'ok')::boolean or not (res2 ->> 'ok')::boolean;
    insert into demo_seed.fixture values (p_role, 'v1_kpi_values', jsonb_build_object('p_period', per), (res -> 'body') || (res2 -> 'body'), null, null)
      on conflict (role, rpc, match) do update set body = excluded.body, err_state = null, err_message = null;
    n := n + 1;
  end loop;
  return n;
end $$;
-- KPI donut splits: each KPI has its own split dimension (KpiFormat.splitBy in the app)
create or replace function demo_seed.record_extra(p_role text) returns integer language plpgsql as $$
declare r record; res jsonb; o oid := (select oid from pg_proc where proname = 'v1_kpi_split' and pronamespace = 'api'::regnamespace limit 1); n integer := 0;
begin
  perform set_config('demo.role', p_role, false); perform demo_seed.as_role(p_role);
  for r in select * from (values ('dms.sales','territory'), ('dms.collected','territory'), ('dms.receivable','territory'), ('stock.total_value','warehouse'),
                                 ('stock.fg_value','warehouse'), ('stock.raw_value','warehouse'), ('mfg.fg_output','product'), ('mfg.waste','product'),
                                 ('fin.expenses','account'), ('fin.revenue','account')) v(code, by_) loop
    res := demo_seed.call_one('v1_kpi_split', o, jsonb_build_object('p_code', r.code, 'p_by', r.by_, 'p_from', (current_date - 60)::text, 'p_to', current_date::text));
    continue when not (res ->> 'ok')::boolean;
    insert into demo_seed.fixture values (p_role, 'v1_kpi_split', jsonb_build_object('p_code', r.code), res -> 'body', null, null) on conflict do nothing;
    n := n + 1;
  end loop;
  return n;
end $$;

#!/bin/bash
# Rebuilds the FULL DEMO data of the app (assets/demo/rpc_fixtures.json) from the REAL server code. Dev machine only.
# 1) migrate a throw-away database  2) seed a fictional company through api.* (backend/supabase/seed/demo_seed.sql)
# 3) record every read as every demo position, rolled back (demo_record.sql)  4) export (tools/build_demo_assets.py)
# Usage: PGHOST=localhost PGPORT=5432 PGUSER=postgres backend/ops/build_demo.sh      (DROPS databases mohona_test and demo)
set -euo pipefail
R=$(cd "$(dirname "$0")/../.." && pwd)
LOG_DIR=${LOG_DIR:-/tmp/mohona-demo-logs} bash "$R/backend/ops/run_sql_local.sh" migrate
psql -q -d postgres -c "drop database if exists demo" -c "create database demo template mohona_test owner erp_owner"
export PGDATABASE=demo
psql -v ON_ERROR_STOP=1 -q -f "$R/backend/supabase/seed/demo_seed.sql" 2>&1 | grep -v "^psql.*NOTICE:  relation" || true
psql -q -f "$R/backend/supabase/seed/demo_record.sql" 2>&1 | grep -v NOTICE || true
python3 - "$R" > /tmp/mohona-demo-lists.txt <<'PY'
import json, re, glob, sys
r = sys.argv[1]
acts = json.load(open(r + '/app/src/main/assets/actions.json'))['actions']
names, writes = set(), {a['r'] for a in acts if a['w']}
for a in acts: names.add(a['r'])
for f in glob.glob(r + '/app/src/main/java/**/*.kt', recursive=True):
    s = open(f, encoding='utf-8').read()
    for m in re.finditer(r'"(v1_[a-z0-9_]+)"', s):
        names.add(m.group(1))
        seg = s[m.end():m.end() + 400].split('\n')
        line = seg[0] + ('\n' + seg[1] if seg[0].rstrip().endswith(',') and len(seg) > 1 else '')
        if 'write = true' in line: writes.add(m.group(1))
writes.discard('v1_iam_select_position')
kinds = sorted(set(json.load(open(r + '/app/src/main/assets/lookup_kinds.json'))['params'].values()))
print(','.join(sorted(names))); print(','.join(sorted(writes))); print(','.join(kinds))
PY
NAMES=$(sed -n 1p /tmp/mohona-demo-lists.txt); WRITES=$(sed -n 2p /tmp/mohona-demo-lists.txt); KINDS=$(sed -n 3p /tmp/mohona-demo-lists.txt)
psql -q -v ON_ERROR_STOP=1 -c "truncate demo_seed.rpc_list, demo_seed.lookup_kind" \
  -c "insert into demo_seed.rpc_list select unnest(string_to_array('$NAMES', ','))" \
  -c "insert into demo_seed.lookup_kind select unnest(string_to_array('$KINDS', ','))"
for role in $(psql -Atc "select role from demo_seed.users order by role"); do
  psql -Atc "select demo_seed.record('$role', string_to_array('$WRITES', ',')) + demo_seed.record_extra('$role') + demo_seed.record_kpi('$role')" > /dev/null
done
python3 "$R/tools/build_demo_assets.py"

package com.mohona.erp.core.net

/** Broad class of a failure; drives how the UI reacts (retry, re-login, show "no permission", etc.). */
enum class ErrorKind { NETWORK, TIMEOUT, SESSION_EXPIRED, FORBIDDEN, VALIDATION, CONFLICT, NOT_FOUND, BACKEND_NOT_READY, SERVER, CONFIG }

/**
 * One error model for the whole app. [code] is the stable server code (E_*) or a client code (C_*);
 * [messageBn] is what the user sees. Raw server text is kept in [detail] for diagnostics only, never shown as-is.
 */
data class AppError(
    val code: String,
    val kind: ErrorKind,
    val messageBn: String,
    val httpCode: Int? = null,
    val detail: String? = null,
    val requestId: String? = null
) {
    val retryable: Boolean
        get() = kind == ErrorKind.NETWORK || kind == ErrorKind.TIMEOUT || (kind == ErrorKind.SERVER && (httpCode ?: 0) >= 500)
}

sealed class ApiResult<out T> {
    data class Ok<T>(val value: T) : ApiResult<T>()
    data class Err(val error: AppError) : ApiResult<Nothing>()

    fun getOrNull(): T? = (this as? Ok<T>)?.value
    fun errorOrNull(): AppError? = (this as? Err)?.error
}

inline fun <T, R> ApiResult<T>.map(f: (T) -> R): ApiResult<R> = when (this) {
    is ApiResult.Ok -> ApiResult.Ok(f(value))
    is ApiResult.Err -> this
}

/** Server codes (raised by core.fn_raise / triggers as "E_CODE: detail") mapped to Bengali text and an [ErrorKind]. */
object ErrorCatalog {
    private class Entry(val kind: ErrorKind, val bn: String)

    private val entries: Map<String, Entry> = mapOf(
        "E_AUTH" to Entry(ErrorKind.SESSION_EXPIRED, "আপনার সেশন বৈধ নয়। আবার লগইন করুন।"),
        "E_SESSION_REVOKED" to Entry(ErrorKind.SESSION_EXPIRED, "এই সেশন বাতিল করা হয়েছে। আবার লগইন করুন।"),
        "E_NO_ACTIVE_POSITION" to Entry(ErrorKind.FORBIDDEN, "কোনো সক্রিয় পদ নির্বাচিত নেই। পদ নির্বাচন করুন।"),
        "E_FORBIDDEN" to Entry(ErrorKind.FORBIDDEN, "এই কাজের অনুমতি আপনার নেই।"),
        "E_WRONG_COMPANY" to Entry(ErrorKind.FORBIDDEN, "এই তথ্য অন্য কোম্পানির। দেখার অনুমতি নেই।"),
        "E_IMMUTABLE" to Entry(ErrorKind.VALIDATION, "এই তথ্য তৈরি হওয়ার পর আর বদলানো যায় না।"),
        "E_NO_DELETE" to Entry(ErrorKind.VALIDATION, "এই রেকর্ড মোছা যায় না; অবস্থা পরিবর্তন করুন।"),
        "E_APPEND_ONLY" to Entry(ErrorKind.VALIDATION, "এই রেকর্ড শুধু যোগ করা যায়; বদলানো বা মোছা যায় না।"),
        "E_DEPARTMENT_CYCLE" to Entry(ErrorKind.VALIDATION, "বিভাগের কাঠামোতে চক্র তৈরি হবে। অন্য মূল-বিভাগ বেছে নিন।"),
        "E_DEPARTMENT_DEPTH" to Entry(ErrorKind.VALIDATION, "বিভাগের স্তর খুব গভীর (সর্বোচ্চ ৩২)।"),
        "E_COMPANY_CLOSED" to Entry(ErrorKind.VALIDATION, "বন্ধ কোম্পানি আবার চালু করা যায় না।"),
        "E_STALE_VERSION" to Entry(ErrorKind.CONFLICT, "অন্য কেউ এই তথ্য ইতিমধ্যে বদলেছেন। নতুন করে খুলে আবার চেষ্টা করুন।"),
        "E_DUPLICATE" to Entry(ErrorKind.CONFLICT, "একই তথ্য আগে থেকেই আছে।"),
        "E_IDEMPOTENCY_MISMATCH" to Entry(ErrorKind.CONFLICT, "একই অনুরোধ ভিন্ন তথ্যসহ আবার পাঠানো হয়েছে।"),
        "E_NOT_FOUND" to Entry(ErrorKind.NOT_FOUND, "তথ্যটি পাওয়া যায়নি।"),
        "E_PERIOD_CLOSED" to Entry(ErrorKind.VALIDATION, "এই হিসাব-পিরিয়ড বন্ধ। এই তারিখে কিছু পোস্ট করা যাবে না।"),
        "E_BACKDATE_LIMIT" to Entry(ErrorKind.VALIDATION, "অনুমোদিত সীমার চেয়ে পুরোনো তারিখ দেওয়া হয়েছে।"),
        "E_CONSENT_REQUIRED" to Entry(ErrorKind.FORBIDDEN, "অবস্থান পাঠাতে আগে সম্মতি দিন (ব্যাকগ্রাউন্ড-অবস্থান বন্ধ)।"),
        "E_PRINTER_NOT_REGISTERED" to Entry(ErrorKind.FORBIDDEN, "এই প্রিন্টার নিবন্ধিত নয়, বাতিল, বা আপনার পদের জন্য অনুমোদিত নয়।"),
        "E_SCHEMA_INCOMPATIBLE" to Entry(ErrorKind.SERVER, "সার্ভারের কাঠামো অসম্পূর্ণ — প্রযুক্তি-দলকে জানান।"),
        "E_NOT_PACKED" to Entry(ErrorKind.CONFLICT, "পিক ও প্যাক শেষ না হলে ডিসপ্যাচ করা যায় না।"),
        "E_CHAIRMAN_ONLY" to Entry(ErrorKind.FORBIDDEN, "আর্থিক বিষয়ের চূড়ান্ত অনুমোদন শুধু চেয়ারম্যান দিতে পারেন।"),
        "E_TIME_WINDOW" to Entry(ErrorKind.FORBIDDEN, "এই সময়ে আপনার পদে এই কাজের অনুমতি নেই (কাজের সময়-সীমা)।"),
        "E_APPROVAL_CEILING" to Entry(ErrorKind.FORBIDDEN, "এই অঙ্ক আপনার পদের অনুমোদন-সীমার বেশি; ঊর্ধ্বতন অনুমোদন দেবেন।"),
        "E_RMA_REQUIRED" to Entry(ErrorKind.CONFLICT, "ফেরতের আগে অনুমোদিত ফেরত-অনুমতি (RMA) লাগবে, পরিমাণও তার মধ্যে।"),
        "E_APPROVAL_REQUIRED" to Entry(ErrorKind.FORBIDDEN, "এই পরিবর্তন অনুমোদিত অনুরোধের মাধ্যমেই হয় (যেমন সাপ্লায়ারের ব্যাংক হিসাব)।"),
        "E_MATERIAL_SHORT" to Entry(ErrorKind.CONFLICT, "কাঁচামাল বা উৎপাদন-সক্ষমতা কম — আগে প্রস্তুতি-রিপোর্ট দেখুন।"),
        "E_ORDER_ON_HOLD" to Entry(ErrorKind.CONFLICT, "অর্ডারটি হোল্ডে আছে — আগে ছাড় দিন, তারপর পাঠান।"),
        "E_DEMO_NO_DATA" to Entry(ErrorKind.NOT_FOUND, "ডেমোতে এই পর্দার নমুনা তথ্য নেই; আসল সার্ভারে এটি কাজ করবে।"),
        "E_CARTON_STATE" to Entry(ErrorKind.CONFLICT, "এই কার্টন এখন এই কাজের উপযুক্ত অবস্থায় নেই (আগেই বরাদ্দ/প্রেরিত)।"),
        "E_SHORTFALL_UNCLASSIFIED" to Entry(ErrorKind.VALIDATION, "ঘাটতির পুরো টাকা ডিলারের বকেয়া বা অনুমোদিত ছাড়ে ভাগ না করে চালান বন্ধ করা যায় না।"),
        "E_RATE_LIMITED" to Entry(ErrorKind.FORBIDDEN, "অনেকবার ভুল হয়েছে — কিছুক্ষণ পরে চেষ্টা করুন।"),
        "E_ROUTE_OVERLAP" to Entry(ErrorKind.CONFLICT, "এই কর্মীর এই দিনে আগেই বাধ্যতামূলক রুট আছে।"),
        "E_GATE_DEVICE_INVALID" to Entry(ErrorKind.FORBIDDEN, "এটি নিবন্ধিত গেট-ডিভাইস নয়।"),
        "E_LEAVE_OVERLAP" to Entry(ErrorKind.CONFLICT, "এই দিনগুলোতে আগেই ছুটি আছে।"),
        "E_LEAVE_BALANCE" to Entry(ErrorKind.VALIDATION, "ছুটির বাকি দিন যথেষ্ট নয়।"),
        "E_OVERTIME_CAP" to Entry(ErrorKind.CONFLICT, "মাসিক ওভারটাইম-সীমা পেরিয়ে যাবে।"),
        "E_ALREADY_DELIVERED" to Entry(ErrorKind.CONFLICT, "এই ডেলিভারি আগেই নিশ্চিত হয়েছে।"),
        "E_UNVERIFIED_PAYMENT" to Entry(ErrorKind.VALIDATION, "ব্যাংক-স্টেটমেন্ট বা bKash/Nagad-এর নিশ্চয়তা ছাড়া পরিশোধ যাচাই হয় না (স্ক্রিনশট/OTP প্রমাণ নয়)।"),
        "E_REPORT_RANGE" to Entry(ErrorKind.FORBIDDEN, "একবারে এত সপ্তাহের রিপোর্ট দেখা যায় না।"),
        "E_TERRITORY_MISMATCH" to Entry(ErrorKind.VALIDATION, "রিটেইলার তার ডিলারের এলাকার বাইরে যেতে পারে না।"),
        "E_DEALER_SUSPENDED" to Entry(ErrorKind.FORBIDDEN, "ডিলার স্থগিত — নতুন বাকিতে বিক্রি বা ক্রেডিট-ব্যতিক্রম নয়।"),
        "E_CONTACT_NOT_AUTHORIZED" to Entry(ErrorKind.FORBIDDEN, "এই নম্বর অনুমোদিত নয় — কল/মেসেজ করা যাবে না।"),
        "E_COA_NOT_APPROVED" to Entry(ErrorKind.FORBIDDEN, "হিসাব-তালিকা (COA) পর্যালোচনা ও চেয়ারম্যানের অনুমোদন ছাড়া পোস্টিং হয় না।"),
        "E_GL_MAPPING_MISSING" to Entry(ErrorKind.CONFIG, "এই লেনদেনের হিসাব-ম্যাপিং নেই — পোস্টিং অপেক্ষায় রইল।"),
        "E_JOURNAL_UNBALANCED" to Entry(ErrorKind.VALIDATION, "ডেবিট ও ক্রেডিট সমান নয়।"),
        "E_BACKDATE" to Entry(ErrorKind.VALIDATION, "অনুমোদিত দিনের চেয়ে পেছনের তারিখে জার্নাল হয় না।"),
        "E_ACCOUNT_IN_USE" to Entry(ErrorKind.CONFLICT, "পোস্ট-হওয়া হিসাব মোছা বা বন্ধ করা যায় না।"),
        "E_DUPLICATE_BANK_REF" to Entry(ErrorKind.CONFLICT, "এই ব্যাংক-রেফারেন্স আগেই আছে।"),
        "E_INSUFFICIENT_CASH" to Entry(ErrorKind.CONFLICT, "ক্যাশে এত টাকা নেই।"),
        "E_PERIOD_NOT_READY" to Entry(ErrorKind.CONFLICT, "এই মাসে অপোস্টেড জার্নাল বা আটকে থাকা পোস্টিং আছে — আগে মিটিয়ে নিন।"),
        "E_BATCH_NOT_APPROVED" to Entry(ErrorKind.FORBIDDEN, "অনুমোদিত ও চলমান ব্যাচ ছাড়া কাঁচামাল দেওয়া/ফেরত হয় না।"),
        "E_BOM_NOT_APPROVED" to Entry(ErrorKind.VALIDATION, "এই পণ্যের অনুমোদিত রেসিপি (BOM) নেই।"),
        "E_QC_FAILED" to Entry(ErrorKind.CONFLICT, "চূড়ান্ত QC পাস না হলে তৈরি-পণ্য পোস্ট হয় না।"),
        "E_REWORK_EXCEEDS" to Entry(ErrorKind.VALIDATION, "রিপ্যাক/রিওয়ার্কে যত নেওয়া হয়েছে তার বেশি তৈরি-পণ্য হতে পারে না।"),
        "E_WIP_UNBALANCED" to Entry(ErrorKind.SERVER, "ব্যাচের খরচ মেলেনি — প্রযুক্তি-দলকে জানান।"),
        "E_LEDGER_LOCKED" to Entry(ErrorKind.FORBIDDEN, "মজুদ-ব্যালান্স শুধু পোস্ট-করা চলাচলে বদলায়।"),
        "E_QR_INVALID" to Entry(ErrorKind.VALIDATION, "এই QR এই কোম্পানির বৈধ লেবেল নয়।"),
        "E_COUNT_INCOMPLETE" to Entry(ErrorKind.VALIDATION, "তালিকার প্রতিটি লট গুনে লিখুন, তারপর জমা দিন।"),
        "E_DUPLICATE_SUPPLIER" to Entry(ErrorKind.CONFLICT, "একই সাপ্লায়ার আগেই আছে (একই TIN বা নাম+ফোন)।"),
        "E_DUPLICATE_INVOICE" to Entry(ErrorKind.CONFLICT, "এই সাপ্লায়ারের এই ইনভয়েস আগেই নেওয়া হয়েছে।"),
        "E_PO_NOT_APPROVED" to Entry(ErrorKind.FORBIDDEN, "অনুমোদিত ক্রয়-আদেশ ছাড়া মাল-গ্রহণ হয় না।"),
        "E_PO_LOCKED" to Entry(ErrorKind.CONFLICT, "অনুমোদিত ক্রয়-আদেশ শুধু অনুমোদিত পরিবর্তন-আদেশে বদলায়।"),
        "E_OVER_RECEIPT" to Entry(ErrorKind.VALIDATION, "অর্ডারের চেয়ে বেশি গ্রহণ করা যায় না।"),
        "E_OVERPAYMENT" to Entry(ErrorKind.CONFLICT, "অনুমোদিত বকেয়ার বেশি পরিশোধ/সমন্বয় করা যায় না।"),
        "E_NEGATIVE_STOCK" to Entry(ErrorKind.VALIDATION, "পর্যাপ্ত স্টক নেই; ঋণাত্মক স্টক অনুমোদিত নয়।"),
        "E_FEATURE_DISABLED" to Entry(ErrorKind.FORBIDDEN, "এই ফিচারটি চেয়ারম্যান বন্ধ রেখেছেন।"),
        "E_INTERNAL" to Entry(ErrorKind.SERVER, "সার্ভারে অভ্যন্তরীণ ত্রুটি হয়েছে।"),
        "E_CHAIRMAN_SEAT" to Entry(ErrorKind.FORBIDDEN, "চেয়ারম্যান-পদ শুধু হস্তান্তর বা প্ল্যাটফর্ম-নিয়োগে বদলায়।"),
        "E_CONTACT_REQUIRED" to Entry(ErrorKind.VALIDATION, "ফোন বা ইমেইল অন্তত একটি দিন।"),
        "E_DELEGATION_INVALID" to Entry(ErrorKind.VALIDATION, "ক্ষমতা-অর্পণের তথ্য অসম্পূর্ণ (শেষ-সময় ও নির্দিষ্ট পরিধি লাগবে)।"),
        "E_DELEGATION_TOO_LONG" to Entry(ErrorKind.VALIDATION, "ক্ষমতা-অর্পণের মেয়াদ অনুমোদিত সীমার বেশি।"),
        "E_INVALID_ACTION" to Entry(ErrorKind.VALIDATION, "বর্তমান অবস্থায় এই কাজ করা যায় না।"),
        "E_NOT_DELEGABLE" to Entry(ErrorKind.FORBIDDEN, "এই অনুমতি অর্পণযোগ্য নয়।"),
        "E_RANK_TOO_HIGH" to Entry(ErrorKind.FORBIDDEN, "নিজের সমান বা উচ্চ পদের ক্ষেত্রে এই কাজ করা যায় না।"),
        "E_RLS_MISSING" to Entry(ErrorKind.SERVER, "সার্ভার-নিরাপত্তা কনফিগারেশন অসম্পূর্ণ।"),
        "E_SELF_ACTION" to Entry(ErrorKind.FORBIDDEN, "নিজের ক্ষেত্রে এই কাজ করা যায় না।"),
        "E_TRANSFER_INVALID" to Entry(ErrorKind.VALIDATION, "চেয়ারম্যান-হস্তান্তর বৈধ নয় বা মেয়াদোত্তীর্ণ।"),
        "E_TRANSFER_PENDING" to Entry(ErrorKind.CONFLICT, "একটি হস্তান্তর-প্রস্তাব ইতিমধ্যে অপেক্ষমাণ।"),
        "E_EMPLOYMENT_INACTIVE" to Entry(ErrorKind.FORBIDDEN, "আপনার কর্মসংস্থান সক্রিয় নয়।"),
        "E_SETTING_INVALID" to Entry(ErrorKind.VALIDATION, "সেটিং-এর মান গ্রহণযোগ্য নয়।"),
        "E_SETTING_UNKNOWN" to Entry(ErrorKind.VALIDATION, "এই সেটিং পাওয়া যায়নি।"),
        "E_MODULE_CYCLE" to Entry(ErrorKind.VALIDATION, "মডিউল-নির্ভরতায় চক্র তৈরি হবে।"),
        "E_CORE_PROTECTED" to Entry(ErrorKind.FORBIDDEN, "মূল নিরাপত্তা-অংশ বন্ধ করা যায় না।"),
        "E_MODULE_NOT_AVAILABLE" to Entry(ErrorKind.VALIDATION, "এই মডিউল এখনো তৈরি হয়নি।"),
        "E_MODULE_DEPENDENCY" to Entry(ErrorKind.VALIDATION, "আগে নির্ভরশীল মডিউল চালু করুন।"),
        "E_MODULE_DEPENDENTS" to Entry(ErrorKind.CONFLICT, "অন্য মডিউল এর ওপর নির্ভরশীল; আগে সেগুলো স্থগিত করুন বা একসাথে স্থগিত বেছে নিন।"),
        "E_MODULE_READ_ONLY" to Entry(ErrorKind.FORBIDDEN, "মডিউলটি এখন শুধু-পাঠ অবস্থায় আছে।"),
        "E_VERSION_INCOMPATIBLE" to Entry(ErrorKind.VALIDATION, "এই সংস্করণে সরাসরি যাওয়া যায় না।"),
        "E_ROLLBACK_UNSAFE" to Entry(ErrorKind.VALIDATION, "তথ্য হারানোর ঝুঁকি থাকায় এই রোলব্যাক সম্ভব নয়।"),
        "E_FLAG_UNKNOWN" to Entry(ErrorKind.VALIDATION, "এই ফিচার-সুইচ পাওয়া যায়নি।"),
        "E_SELF_APPROVAL" to Entry(ErrorKind.FORBIDDEN, "নিজের কাজ নিজে অনুমোদন করা যায় না।"),
        "E_BREAKGLASS_SCOPE" to Entry(ErrorKind.VALIDATION, "জরুরি-প্রবেশে এই অনুমতি দেওয়া যায় না (পোস্টিং কখনো নয়)।"),
        "E_RULE_INVALID" to Entry(ErrorKind.VALIDATION, "নিয়মের শর্ত বা কাজ সঠিক নয়।"),
        "E_RULE_BLOCKED" to Entry(ErrorKind.FORBIDDEN, "চেয়ারম্যানের নিয়ম অনুযায়ী এই কাজ এখন বন্ধ।"),
        "E_INSUFFICIENT_STOCK" to Entry(ErrorKind.CONFLICT, "ব্যবহারযোগ্য মজুদ (সংরক্ষিত বাদে) যথেষ্ট নয়।"),
        "E_LOT_EXPIRED" to Entry(ErrorKind.VALIDATION, "মেয়াদোত্তীর্ণ লট ব্যবহার বা গ্রহণ করা যায় না।"),
        "E_SUBSTITUTE_NOT_APPROVED" to Entry(ErrorKind.FORBIDDEN, "এই বিকল্প কাঁচামাল অনুমোদিত নয়।"),
        "E_PRODUCT_LOCKED" to Entry(ErrorKind.CONFLICT, "এই ভ্যারিয়েন্ট পোস্ট-করা রেকর্ডে ব্যবহৃত — রেসিপি/প্যাক বদলাতে নতুন ভ্যারিয়েন্ট করুন।"),
        "E_PRODUCT_ARCHIVED" to Entry(ErrorKind.VALIDATION, "পণ্যটি আর্কাইভ করা — নতুন কোনো কাজে ব্যবহার করা যাবে না।"),
        "E_UNIT_AMBIGUOUS" to Entry(ErrorKind.VALIDATION, "এই একক-রূপান্তর নির্ধারিত নয় (পিস থেকে পলি অনুমান করা হয় না; অনুমোদিত POLY-স্পেক লাগবে)।"),
        "E_PRICE_BACKDATED" to Entry(ErrorKind.VALIDATION, "অতীত তারিখ থেকে দাম বসানো যায় না।"),
        "E_PRICE_STARTED" to Entry(ErrorKind.CONFLICT, "আজকের দাম ইতিমধ্যে চালু — নতুন দাম আগামীকাল থেকে দিন।"),
        "E_STRUCTURE_IN_USE" to Entry(ErrorKind.CONFLICT, "এই একক এখনো ব্যবহৃত হচ্ছে (নিয়োগ, বিভাগ, গুদাম বা অনুমতি) — আগে সেগুলো সরান।"),
        "E_NOTIFY_MANDATORY" to Entry(ErrorKind.VALIDATION, "এই ধরনের নোটিফিকেশনের এই মাধ্যম বন্ধ করা যায় না।"),
        "E_NOTIFY_TEMPLATE" to Entry(ErrorKind.VALIDATION, "লেখায় অনুমোদিত নয় এমন ঘর বা মার্কআপ আছে।"),
        "E_POLICY_REVIEW_REQUIRED" to Entry(ErrorKind.FORBIDDEN, "নীতি-পরিবর্তন প্রস্তাব করুন — স্বাধীন পর্যালোচকের অনুমোদন লাগবে।"),
        "E_RECYCLE_NOT_ELIGIBLE" to Entry(ErrorKind.VALIDATION, "শুধু খসড়া (পোস্ট হয়নি এমন) রেকর্ড বিনে পাঠানো যায়।"),
        "E_LEGAL_HOLD" to Entry(ErrorKind.FORBIDDEN, "আইনি স্থগিতাদেশ চলছে — এখন মোছা, ফেরানো বা স্থায়ীভাবে মুছে ফেলা যাবে না।"),
        "E_RECYCLE_CONFLICT" to Entry(ErrorKind.CONFLICT, "ফেরত আনায় সংঘাত — কিছুই ফেরত আনা হয়নি।"),
        "E_DESIGN_LAYOUT" to Entry(ErrorKind.VALIDATION, "লেআউট নিয়ম মানে না (গ্রিড, অনুমোদন-বোতাম বা বিজ্ঞাপন-স্লট)।"),
        "E_DESIGN_INVALID" to Entry(ErrorKind.VALIDATION, "ডিজাইনের মান সঠিক নয়।"),
        "E_DESIGN_CONTRAST" to Entry(ErrorKind.VALIDATION, "এই থিমে লেখা পড়া কঠিন বা অঙ্ক কেটে যাবে; ত্রুটি ঠিক করে প্রকাশ করুন।"),
        "E_AUTH_FAILED" to Entry(ErrorKind.VALIDATION, "মোবাইল নম্বর বা PIN সঠিক নয়।"),
        "E_AUTH_LOCKED" to Entry(ErrorKind.FORBIDDEN, "অনেকবার ভুল হয়েছে; কিছুক্ষণ পরে চেষ্টা করুন বা ব্যবস্থাপককে জানান।"),
        "E_DEVICE_REVOKED" to Entry(ErrorKind.FORBIDDEN, "এই ডিভাইস বাতিল করা হয়েছে; OTP দিয়ে আবার নিবন্ধন করুন।"),
        "E_DEVICE_LIMIT" to Entry(ErrorKind.FORBIDDEN, "সর্বোচ্চ সংখ্যক ডিভাইস নিবন্ধিত; পুরোনো একটি সরান।"),
        "E_NOT_INVITED" to Entry(ErrorKind.FORBIDDEN, "এই নম্বরে লগইনের আমন্ত্রণ নেই; ব্যবস্থাপকের সাথে যোগাযোগ করুন।"),
        "E_OTP_REQUIRED" to Entry(ErrorKind.VALIDATION, "এই কাজের আগে মোবাইলে পাঠানো কোড যাচাই করুন।"),
        "E_PIN_WEAK" to Entry(ErrorKind.VALIDATION, "PIN গ্রহণযোগ্য নয় (শুধু সংখ্যা, নির্দিষ্ট দৈর্ঘ্য, সহজ ক্রম নয়)।"),
        "E_PERMISSION_DEPENDENCY" to Entry(ErrorKind.VALIDATION, "এই অনুমতির আগে তার মূল অনুমতি দিতে হবে (বা আগে শাখা-অনুমতি সরান)।"),
        "E_SOD_CONFLICT" to Entry(ErrorKind.FORBIDDEN, "দায়িত্ব-বিভাজন নিয়মে এই দুই অনুমতি একসাথে দেওয়া যায় না।"),
        "E_REPORTING_CYCLE" to Entry(ErrorKind.VALIDATION, "রিপোর্টিং-লাইনে চক্র তৈরি হবে।"),
        "E_ONBOARDING_INCOMPLETE" to Entry(ErrorKind.VALIDATION, "নিয়োগ-চেকলিস্টের বাধ্যতামূলক কাজ বাকি আছে।"),
        "E_FORM_SCHEMA_INVALID" to Entry(ErrorKind.VALIDATION, "ফর্মের নকশা সঠিক নয়।"),
        "E_FORM_SCRIPT_REJECTED" to Entry(ErrorKind.VALIDATION, "ফর্মে স্ক্রিপ্ট বা চালানো-যায় এমন কিছু রাখা যায় না।"),
        "E_FORM_VALIDATION" to Entry(ErrorKind.VALIDATION, "ফর্মের কিছু ঘর ঠিক করুন।"),
        "E_FORM_NOT_PUBLISHED" to Entry(ErrorKind.VALIDATION, "এই ফর্ম এখনো প্রকাশিত হয়নি।"),
        "E_FORM_ARCHIVED" to Entry(ErrorKind.VALIDATION, "এই ফর্ম আর্কাইভ করা; শুধু দেখা যায়।"),
        "E_FORM_LOCKED" to Entry(ErrorKind.VALIDATION, "জমা-দেওয়া ফর্ম বদলানো যায় না; সংশোধনী তৈরি করুন।"),
        "E_FORM_FIELD_FORBIDDEN" to Entry(ErrorKind.FORBIDDEN, "এই ঘর বদলানো বা দেখার অনুমতি আপনার নেই।"),
        "E_FORM_ATTACHMENT_INVALID" to Entry(ErrorKind.VALIDATION, "সংযুক্তির ধরন বা আকার অনুমোদিত নয়।"),
        "E_FORM_ATTACHMENT_MISSING" to Entry(ErrorKind.VALIDATION, "সংযুক্তির আপলোড সম্পূর্ণ হয়নি।"),
        "E_FORM_DRAFT_LIMIT" to Entry(ErrorKind.VALIDATION, "খোলা খসড়ার সর্বোচ্চ সংখ্যা পূর্ণ; আগের খসড়া জমা দিন বা বাতিল করুন।"),
        "E_MFA_REQUIRED" to Entry(ErrorKind.FORBIDDEN, "এই কাজের জন্য দ্বি-স্তর যাচাই (MFA) প্রয়োজন।"),
        "E_FEATURE_NOT_READY" to Entry(ErrorKind.FORBIDDEN, "এই অংশটি এখনো চালু হয়নি।"),
        "E_SELF_GRANT" to Entry(ErrorKind.FORBIDDEN, "নিজের পদের অনুমতি নিজে বদলানো যায় না।"),
        "E_PROTECTED_POSITION" to Entry(ErrorKind.VALIDATION, "চেয়ারম্যান-পদ সুরক্ষিত; এটি বন্ধ বা ভাগ করা যায় না।"),
        "E_POSITION_FULL" to Entry(ErrorKind.CONFLICT, "এই পদে অনুমোদিত সংখ্যক ব্যক্তি ইতিমধ্যে আছেন।"),
        "E_POSITION_DISABLED" to Entry(ErrorKind.VALIDATION, "এই পদটি বন্ধ রাখা আছে।"),
        "E_POSITION_IN_USE" to Entry(ErrorKind.CONFLICT, "এই পদে এখনো কেউ নিয়োজিত; আগে নিয়োগ শেষ করুন।"),
        "E_POSITION_CYCLE" to Entry(ErrorKind.VALIDATION, "রিপোর্টিং-লাইনে চক্র তৈরি হবে।"),
        "E_ASSIGNMENT_ENDED" to Entry(ErrorKind.VALIDATION, "এই নিয়োগ শেষ হয়ে গেছে; আর বদলানো যায় না।"),
        "E_MEMBERSHIP_ENDED" to Entry(ErrorKind.VALIDATION, "এই সদস্যপদ শেষ হয়ে গেছে; নতুন সদস্যপদ তৈরি করুন।"),
        "E_MEMBERSHIP_NOT_ACTIVE" to Entry(ErrorKind.VALIDATION, "সদস্যপদ সক্রিয় নয়।"),
        "E_REASON_REQUIRED" to Entry(ErrorKind.VALIDATION, "কারণ লিখুন।"),
        "E_SCOPE_NOT_ALLOWED" to Entry(ErrorKind.VALIDATION, "এই অনুমতির জন্য এই পরিধি প্রযোজ্য নয়।"),
        "E_SCOPE_NOT_AVAILABLE" to Entry(ErrorKind.VALIDATION, "এই পরিধি এখনো চালু হয়নি।"),
        "E_AUDIT_COMPANY_REQUIRED" to Entry(ErrorKind.SERVER, "অডিট-রেকর্ডে কোম্পানি নেই (অভ্যন্তরীণ ত্রুটি)।")
    )

    private val codeRegex = Regex("^(E_[A-Z0-9_]+)(?::\\s*(.*))?$", RegexOption.DOT_MATCHES_ALL)

    /** Parses "E_CODE: detail" from a server message. Unknown E_ codes still become a typed error, never raw text. */
    fun fromServerMessage(message: String?, httpCode: Int?, requestId: String?): AppError? {
        val text = message?.trim() ?: return null
        val m = codeRegex.find(text) ?: return null
        val code = m.groupValues[1]
        val detail = m.groupValues.getOrNull(2)?.takeIf { it.isNotBlank() }
        val e = entries[code]
        return if (e != null) AppError(code, e.kind, e.bn, httpCode, detail, requestId)
        else AppError(code, ErrorKind.SERVER, "সার্ভার একটি ত্রুটি জানিয়েছে (" + code + ")।", httpCode, detail, requestId)
    }

    fun knows(code: String): Boolean = code in entries

    fun network(detail: String? = null) = AppError("C_NETWORK", ErrorKind.NETWORK, "সার্ভারের সাথে যোগাযোগ করা যায়নি। ইন্টারনেট সংযোগ দেখুন।", detail = detail)
    fun timeout() = AppError("C_TIMEOUT", ErrorKind.TIMEOUT, "সার্ভার সময়মতো সাড়া দেয়নি। আবার চেষ্টা করুন।")
    fun config(messageBn: String) = AppError("C_CONFIG", ErrorKind.CONFIG, messageBn)
    fun sessionExpired() = AppError("C_SESSION_EXPIRED", ErrorKind.SESSION_EXPIRED, "আপনার সেশন শেষ হয়েছে। আবার লগইন করুন।")
    fun backendNotReady(name: String) = AppError("C_BACKEND_NOT_READY", ErrorKind.BACKEND_NOT_READY, "সার্ভারে প্রয়োজনীয় ফাংশন পাওয়া যায়নি (" + name + ")।")
    fun badResponse(detail: String?) = AppError("C_BAD_RESPONSE", ErrorKind.SERVER, "সার্ভারের উত্তর বোঝা যায়নি।", detail = detail)

    /** HTTP status with no recognisable E_ code. */
    fun fromHttp(httpCode: Int, detail: String?, requestId: String?): AppError = when (httpCode) {
        401 -> sessionExpired().copy(httpCode = 401, requestId = requestId)
        403 -> AppError("C_FORBIDDEN", ErrorKind.FORBIDDEN, "এই কাজের অনুমতি আপনার নেই।", 403, detail, requestId)
        404 -> AppError("C_NOT_FOUND", ErrorKind.NOT_FOUND, "তথ্যটি পাওয়া যায়নি।", 404, detail, requestId)
        409 -> AppError("C_CONFLICT", ErrorKind.CONFLICT, "তথ্যে সংঘাত হয়েছে। নতুন করে খুলে আবার চেষ্টা করুন।", 409, detail, requestId)
        in 500..599 -> AppError("C_SERVER", ErrorKind.SERVER, "সার্ভার ত্রুটি (কোড " + httpCode + ")।", httpCode, detail, requestId)
        else -> AppError("C_HTTP_" + httpCode, ErrorKind.SERVER, "অপ্রত্যাশিত সার্ভার-উত্তর (কোড " + httpCode + ")।", httpCode, detail, requestId)
    }
}

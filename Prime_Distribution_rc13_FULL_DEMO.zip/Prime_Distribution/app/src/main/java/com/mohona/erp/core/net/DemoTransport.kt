package com.mohona.erp.core.net

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * FULL DEMO without a server (owner's request: see every screen before buying a server).
 *
 * Plugged in at the HTTP seam ([HttpTransport]) when no Supabase project is configured, so every screen runs its REAL code path
 * (login -> position -> permissions -> theme -> dashboards -> lists -> details -> forms). Reads are answered with what the REAL
 * server functions returned for a fictional company (assets/demo/rpc_fixtures.json, recorded by backend/supabase/seed/demo_record.sql
 * — never hand-written numbers). Writes (every call carrying an Idempotency-Key) are acknowledged but NOTHING is stored.
 * Any mobile number + any PIN logs in; the position list holds one demo person per role.
 */
class DemoTransport(private val loadFixtures: () -> String?) : HttpTransport {

    private class Entry(val match: JSONObject, val body: Any?, val error: JSONObject?)

    private val lock = Any()
    @Volatile private var loaded = false
    private var companies: JSONArray = JSONArray()
    private val roleByAssignment = HashMap<String, String>()
    private val fixtures = HashMap<String, HashMap<String, List<Entry>>>()

    /** Role of the selected demo position; Chairman until a position is chosen. */
    @Volatile var role: String = "CHAIRMAN"
        private set

    private fun ensureLoaded() {
        if (loaded) return
        synchronized(lock) {
            if (loaded) return
            val text = loadFixtures() ?: "{}"
            val doc = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
            companies = doc.optJSONArray("companies") ?: JSONArray()
            doc.optJSONObject("roles")?.let { r -> r.keys().forEach { k -> roleByAssignment[k] = r.optString(k) } }
            val fx = doc.optJSONObject("fixtures") ?: JSONObject()
            fx.keys().forEach { roleKey ->
                val perRpc = HashMap<String, List<Entry>>()
                val o = fx.getJSONObject(roleKey)
                o.keys().forEach { rpc ->
                    val a = o.getJSONArray(rpc)
                    perRpc[rpc] = (0 until a.length()).map { i ->
                        val e = a.getJSONObject(i)
                        Entry(e.optJSONObject("m") ?: JSONObject(), if (e.has("b")) e.opt("b") else null, e.optJSONObject("e"))
                    }
                }
                fixtures[roleKey] = perRpc
            }
            loaded = true
        }
    }

    override fun execute(request: HttpRequest): HttpResponse {
        ensureLoaded()
        val path = request.url.substringAfter("://").substringAfter('/', "").let { "/" + it }.substringBefore('?')
        return when {
            path.startsWith("/functions/v1/auth-otp-start") -> ok(JSONObject().put("allowed", true))
            path.startsWith("/functions/v1/auth-pin-login") || path.startsWith("/functions/v1/auth-pin-refresh") -> ok(tokens())
            path.startsWith("/functions/v1/") -> ok(JSONObject().put("ok", true).put("demo", true))
            path.startsWith("/auth/v1/user") -> ok(JSONObject().put("id", "demo-user").put("factors", JSONArray()))
            path.startsWith("/auth/v1/verify") || path.startsWith("/auth/v1/token") -> ok(tokens())
            path.startsWith("/auth/v1/") -> ok(JSONObject())
            path.startsWith("/storage/v1/") -> ok(JSONObject().put("Key", path.substringAfter("/object/")))
            path.startsWith("/rest/v1/rpc/") -> rpc(path.removePrefix("/rest/v1/rpc/"), request)
            else -> HttpResponse(404, JSONObject().put("message", "E_DEMO_NO_DATA").toString())
        }
    }

    private fun rpc(name: String, request: HttpRequest): HttpResponse {
        val params = try { JSONObject(request.body ?: "{}") } catch (e: Exception) { JSONObject() }
        when (name) {
            "v1_auth_my_companies" -> return HttpResponse(200, companies.toString())
            "v1_iam_select_position" -> roleByAssignment[params.optString("p_assignment_id")]?.let { role = it }
            "v1_auth_my_devices" -> return HttpResponse(200, JSONArray().put(JSONObject().put("device_id", "demo").put("name", "ডেমো ফোন")
                .put("platform", "android").put("status", "active")).toString())
        }
        // writes: acknowledged, never stored (the position selection above is the only write the demo keeps, in memory)
        if (request.headers.containsKey("Idempotency-Key") && name != "v1_iam_select_position") { onDemoWrite?.invoke(); return ok(saved()) }
        if (name == "v1_kpi_values") return kpiValues(params)
        val entries = fixtures[role]?.get(name) ?: fixtures["CHAIRMAN"]?.get(name)
            ?: return HttpResponse(400, JSONObject().put("code", "P0001").put("message", "E_DEMO_NO_DATA").toString())
        val best = entries.filter { e -> e.match.keys().asSequence().all { k -> params.has(k) && params.opt(k)?.toString() == e.match.optString(k) } }
            .maxByOrNull { it.match.length() } ?: entries.firstOrNull { it.match.length() == 0 } ?: entries.first()
        best.error?.let { err ->
            val state = err.optString("code")
            return HttpResponse(if (state == "42501") 403 else 400, JSONObject().put("code", state).put("message", err.optString("message")).toString())
        }
        return HttpResponse(200, when (val b = best.body) { null -> "null"; is String -> JSONObject.quote(b); else -> b.toString() })
    }

    /** KPI cards ask for any subset of codes: answer from the recorded full set of the requested period, in the requested order. */
    private fun kpiValues(params: JSONObject): HttpResponse {
        val period = params.optString("p_period").ifBlank { "today" }.let { if (it == "custom") "this_month" else it }
        val entries = fixtures[role]?.get("v1_kpi_values") ?: fixtures["CHAIRMAN"]?.get("v1_kpi_values") ?: emptyList()
        val all = (entries.firstOrNull { it.match.optString("p_period") == period } ?: entries.firstOrNull { it.body is JSONArray })?.body as? JSONArray
            ?: return HttpResponse(400, JSONObject().put("code", "P0001").put("message", "E_DEMO_NO_DATA").toString())
        val byCode = (0 until all.length()).mapNotNull { all.optJSONObject(it) }.associateBy { it.optString("code") }
        val asked = params.optJSONArray("p_codes")
        val out = JSONArray()
        if (asked == null) byCode.values.forEach { out.put(it) } else for (i in 0 until asked.length()) byCode[asked.optString(i)]?.let { out.put(it) }
        return HttpResponse(200, out.toString())
    }

    private fun ok(o: JSONObject) = HttpResponse(200, o.toString())

    private fun tokens(): JSONObject = JSONObject()
        .put("access_token", "demo-access-" + UUID.randomUUID())
        .put("refresh_token", "demo-refresh")
        .put("expires_in", 30L * 24 * 3600)
        .put("expires_at", System.currentTimeMillis() / 1000 + 30L * 24 * 3600)
        .put("token_type", "bearer")

    /** A write in the demo: the screen gets a success answer with fresh ids, and the user is told nothing was stored. */
    private fun saved(): JSONObject {
        val id = UUID.randomUUID().toString()
        val o = JSONObject().put("ok", true).put("demo", true).put("status", "demo_saved").put("id", id)
            .put("message_bn", "ডেমো: কাজটি দেখানো হলো, কিছুই সংরক্ষিত হয়নি।")
        for (k in listOf("order_id", "request_id", "collection_id", "invoice_id", "batch_id", "notice_id", "claim_id", "dispute_id",
                         "submission_id", "document_id", "change_id", "visit_id", "shipment_id", "product_id", "dealer_id", "employee_id",
                         "vacancy_id", "applicant_id", "po_id", "pr_id", "run_id", "journal_id", "approval_request_id", "draft_id")) o.put(k, id)
        return o
    }

    companion object {
        /** Shown to the user after every demo write ("nothing was stored"); set by MainActivity, called off the main thread. */
        @Volatile var onDemoWrite: (() -> Unit)? = null
        const val BASE_URL = "https://demo.prime-distribution.invalid"
        const val ANON_KEY = "demo-public-key"
    }
}

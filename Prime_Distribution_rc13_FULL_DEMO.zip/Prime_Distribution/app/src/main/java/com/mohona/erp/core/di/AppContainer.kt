package com.mohona.erp.core.di

import com.mohona.erp.core.arch.DiagnosticsLog
import com.mohona.erp.core.cache.MemoryCache
import com.mohona.erp.core.net.DemoTransport
import com.mohona.erp.core.net.MemoryTokenStore
import com.mohona.erp.core.net.SupabaseClient
import com.mohona.erp.core.net.SupabaseConfig
import com.mohona.erp.core.net.TokenStore
import com.mohona.erp.core.net.UrlConnectionTransport
import com.mohona.erp.core.shell.ShellRepository
import com.mohona.erp.data.AppConfig
import com.mohona.erp.feature.auth.data.LoginRepository
import com.mohona.erp.feature.auth.data.LoginRules
import com.mohona.erp.feature.config.data.ApprovalRepository
import com.mohona.erp.feature.config.data.ModulesRepository
import com.mohona.erp.feature.config.data.RulesRepository
import com.mohona.erp.feature.config.data.SettingsRepository
import com.mohona.erp.feature.design.data.DesignRepository
import com.mohona.erp.feature.kpi.data.KpiCache
import com.mohona.erp.feature.kpi.data.KpiRepository
import com.mohona.erp.feature.recycle.data.RecycleRepository
import com.mohona.erp.feature.notify.data.NotifyRepository
import com.mohona.erp.feature.structure.data.StructureRepository
import com.mohona.erp.feature.product.data.ProductRepository
import com.mohona.erp.feature.stock.data.StockRepository
import com.mohona.erp.feature.stock.data.WarehouseRepository
import com.mohona.erp.feature.mfg.data.MfgRepository
import com.mohona.erp.feature.finance.data.FinanceRepository
import com.mohona.erp.feature.crm.data.CrmRepository
import com.mohona.erp.feature.sales.data.SalesRepository
import com.mohona.erp.feature.payroll.data.PayrollRepository
import com.mohona.erp.feature.qr.data.QrRepository
import com.mohona.erp.feature.print.data.PrintRepository
import com.mohona.erp.feature.report.data.ReportRepository
import com.mohona.erp.feature.ops.data.OpsRepository
import com.mohona.erp.feature.courier.data.CourierRepository
import com.mohona.erp.feature.field.data.FieldRepository
import com.mohona.erp.feature.procurement.data.ProcurementRepository
import com.mohona.erp.feature.forms.data.FileDraftStorage
import com.mohona.erp.feature.forms.data.FormsRepository
import com.mohona.erp.feature.forms.data.KeystoreDraftKey
import com.mohona.erp.feature.forms.data.OfflineDraftStore
import com.mohona.erp.feature.hr.data.HierarchyRepository
import com.mohona.erp.feature.iam.data.GovernanceRepository
import com.mohona.erp.feature.iam.data.IamRepository
import com.mohona.erp.feature.iam.data.PermissionRepository
import com.mohona.erp.feature.iam.data.PositionRepository

/**
 * Manual dependency container (no DI framework: fewer build dependencies). One instance per process.
 * Feature repositories (S05+) are created here from [client] and [cache].
 */
object AppContainer {
    val tokenStore: TokenStore by lazy { MemoryTokenStore() }
    val cache: MemoryCache by lazy { MemoryCache() }

    /** The full demo (no server configured) answers through [DemoTransport]; null only when the configuration is broken. */
    val demo: DemoTransport? by lazy {
        if (!AppConfig.demoServer) null
        else DemoTransport { appContext?.assets?.open("demo/rpc_fixtures.json")?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } }
    }

    val client: SupabaseClient? by lazy {
        val d = demo
        if (d != null) SupabaseClient(SupabaseConfig(DemoTransport.BASE_URL, DemoTransport.ANON_KEY), d, tokenStore).also { c ->
            c.onError = { DiagnosticsLog.record(it) }
        }
        else if (!AppConfig.connectedConfigured) null
        else SupabaseClient(SupabaseConfig(AppConfig.supabaseUrl, AppConfig.anonKey), UrlConnectionTransport(), tokenStore).also { c ->
            c.onSessionLost = { cache.clearAll() }
            c.onError = { DiagnosticsLog.record(it) }
        }
    }

    /** Application context (set once by MainActivity); needed only for on-device storage. */
    @Volatile var appContext: android.content.Context? = null

    /** Chairman limit forms.offline.max_drafts of the current company (from the shell configuration). */
    @Volatile var uiMaxDrafts: Int = 50

    /** Person of the selected position (set at position selection); drafts are bound to it. */
    @Volatile var currentPersonId: String? = null

    /** Encrypted offline drafts (S14 store on app-private files, Keystore key). Null before the app context exists. */
    val draftStore: OfflineDraftStore? by lazy {
        appContext?.let { OfflineDraftStore(FileDraftStorage(java.io.File(it.filesDir, "form_drafts")), { KeystoreDraftKey.get() }) }
    }

    /** Per-install device id, set by MainActivity from [com.mohona.erp.feature.auth.data.DeviceIdentity]. */
    @Volatile var deviceId: String = LoginRules.newDeviceId()
    val login: LoginRepository? by lazy { client?.let { LoginRepository(it) { deviceId } } }
    val procurement: ProcurementRepository? by lazy { client?.let { ProcurementRepository(it) } }
    val field: FieldRepository? by lazy { client?.let { FieldRepository(it) } }
    val payroll: PayrollRepository? by lazy { client?.let { PayrollRepository(it) } }
    val qr: QrRepository? by lazy { client?.let { QrRepository(it) } }
    val print: PrintRepository? by lazy { client?.let { PrintRepository(it) } }
    val reports: ReportRepository? by lazy { client?.let { ReportRepository(it) } }
    val courier: CourierRepository? by lazy { client?.let { CourierRepository(it) } }
    val ops: OpsRepository? by lazy { client?.let { OpsRepository(it) } }
    val sales: SalesRepository? by lazy { client?.let { SalesRepository(it) } }
    val crm: CrmRepository? by lazy { client?.let { CrmRepository(it) } }
    val finance: FinanceRepository? by lazy { client?.let { FinanceRepository(it) } }
    val mfg: MfgRepository? by lazy { client?.let { MfgRepository(it) } }
    val warehouse: WarehouseRepository? by lazy { client?.let { WarehouseRepository(it) } }
    val stock: StockRepository? by lazy { client?.let { StockRepository(it) } }
    val products: ProductRepository? by lazy { client?.let { ProductRepository(it) } }
    val structure: StructureRepository? by lazy { client?.let { StructureRepository(it) } }
    val notify: NotifyRepository? by lazy { client?.let { NotifyRepository(it) } }
    val recycle: RecycleRepository? by lazy { client?.let { RecycleRepository(it) } }
    val kpi: KpiRepository? by lazy { client?.let { KpiRepository(it) } }
    val kpiCache: KpiCache by lazy { KpiCache() }

    /** F154-034: the server says whether this position may take screenshots (FLAG_SECURE when blocked). */
    @Volatile var blockScreenshots: Boolean = false
    val design: DesignRepository? by lazy { client?.let { DesignRepository(it) } }
    val shell: ShellRepository? by lazy { client?.let { ShellRepository(it) } }
    val iam: IamRepository? by lazy { client?.let { IamRepository(it) } }
    val approvals: ApprovalRepository? by lazy { client?.let { ApprovalRepository(it) } }
    val rules: RulesRepository? by lazy { client?.let { RulesRepository(it) } }
    val hierarchy: HierarchyRepository? by lazy { client?.let { HierarchyRepository(it) } }
    val forms: FormsRepository? by lazy { client?.let { FormsRepository(it) } }
    val modules: ModulesRepository? by lazy { client?.let { ModulesRepository(it) } }
    val settings: SettingsRepository? by lazy { client?.let { SettingsRepository(it) } }
    val governance: GovernanceRepository? by lazy { client?.let { GovernanceRepository(it) } }
    val permissions: PermissionRepository? by lazy { client?.let { PermissionRepository(it) } }
    val positions: PositionRepository? by lazy { client?.let { PositionRepository(it) { clearSessionData() } } }

    /** Called on sign-out and on company/position switch. */
    fun clearSessionData() {
        cache.clearAll()
        kpiCache.clear()
        currentPersonId = null
    }
}

package com.mohona.erp.ui.navigation

import android.net.Uri
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.shell.LocalMotionMs
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.core.shell.ShellTabs
import com.mohona.erp.data.AppMode
import com.mohona.erp.data.SessionViewModel
import com.mohona.erp.data.demo.DemoRepository
import com.mohona.erp.domain.RecordRef
import com.mohona.erp.domain.RecordType
import com.mohona.erp.domain.UserContext
import com.mohona.erp.ui.components.EmptyState
import com.mohona.erp.ui.screens.DiagnosticsScreen
import com.mohona.erp.ui.screens.ApprovalCenterScreen
import com.mohona.erp.ui.screens.ChairmanScreen
import com.mohona.erp.ui.screens.ChairmanStudioScreen
import com.mohona.erp.ui.screens.GlobalHomeScreen
import com.mohona.erp.ui.screens.AccessPreviewScreen
import com.mohona.erp.ui.screens.ConnectedActions
import com.mohona.erp.ui.screens.DashboardScreen
import com.mohona.erp.ui.screens.RecycleBinScreen
import com.mohona.erp.ui.screens.InboxScreen
import com.mohona.erp.ui.screens.StructureScreen
import com.mohona.erp.ui.screens.ProductsScreen
import com.mohona.erp.ui.screens.StockScreen
import com.mohona.erp.ui.screens.ProcurementScreen
import com.mohona.erp.ui.screens.WarehouseScreen
import com.mohona.erp.ui.screens.MfgScreen
import com.mohona.erp.ui.screens.FinanceScreen
import com.mohona.erp.ui.screens.DealerScreen
import com.mohona.erp.ui.screens.SalesScreen
import com.mohona.erp.ui.screens.MyDayScreen
import com.mohona.erp.ui.screens.ScanScreen
import com.mohona.erp.ui.screens.PrintScreen
import com.mohona.erp.ui.screens.ReportsScreen
import com.mohona.erp.ui.screens.MapScreen
import com.mohona.erp.ui.screens.OpsScreen
import com.mohona.erp.ui.screens.CourierScreen
import com.mohona.erp.ui.screens.DepartmentScreen
import com.mohona.erp.ui.screens.PrimeHomeScreen
import com.mohona.erp.feature.actions.DeptNav
import com.mohona.erp.ui.screens.CriticalBanner
import com.mohona.erp.ui.screens.DesignStudioScreen
import com.mohona.erp.ui.screens.LayoutStudioScreen
import com.mohona.erp.ui.screens.FormFillScreen
import com.mohona.erp.ui.screens.FormsListScreen
import com.mohona.erp.ui.screens.OrgTreeScreen
import com.mohona.erp.ui.screens.ProfileShellActions
import com.mohona.erp.ui.screens.SettingsScreen
import com.mohona.erp.ui.screens.LoginScreen
import com.mohona.erp.ui.screens.ModuleDashboardScreen
import com.mohona.erp.ui.screens.NotificationCenterScreen
import com.mohona.erp.ui.screens.ProfileScreen
import com.mohona.erp.ui.screens.QrPreviewScreen
import com.mohona.erp.ui.screens.RecordDashboardScreen
import com.mohona.erp.ui.screens.RecordListScreen
import com.mohona.erp.ui.screens.ReportCenterScreen
import com.mohona.erp.ui.screens.ReportPreviewScreen
import com.mohona.erp.ui.screens.ScannerScreen
import com.mohona.erp.ui.screens.SearchScreen
import com.mohona.erp.ui.screens.WingDashboardScreen

/**
 * Stable route identity for the whole app. A record is ALWAYS opened through [RECORD_PATTERN] (type + id), so one canonical dashboard serves
 * every entry point (lists, related links, search, notifications, QR, reports). Company context travels with the session, not the URL.
 */
object Routes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val SEARCH = "search"
    const val SCAN = "scan"
    const val REPORTS = "reports"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"
    const val APPROVALS = "approvals"
    const val CHAIRMAN = "chairman"
    const val DIAGNOSTICS = "diagnostics"
    const val FORMS = "forms"
    const val SETTINGS = "settings"
    const val ORG = "org"
    const val DESIGN = "design"
    const val LAYOUT = "layout"
    const val DASHBOARD = "dashboard"
    const val RECYCLE = "recycle"
    const val INBOX = "inbox"
    const val STRUCTURE = "structure"
    const val PRODUCTS = "products"
    const val STOCK = "stock"
    const val PROCUREMENT = "procurement"
    const val WAREHOUSE = "warehouse"
    const val MFG = "mfg"
    const val FINANCE = "finance"
    const val DEALERS = "dealers"
    const val SALES = "sales"
    const val MYDAY = "myday"
    const val QRSCAN = "qrscan"
    const val PRINT = "print"
    const val CUSTOM_REPORTS = "custom_reports"
    const val MAP = "map"
    const val OPS = "ops"
    const val COURIER = "courier"
    const val CHAIRMAN_PANEL = "chairman_panel"
    const val CHAIRMAN_STUDIO = "chairman_studio"
    const val DEPARTMENT = "department"
    const val FORM_PATTERN = "form/{formId}"
    const val ACCESS_PATTERN = "access/{assignmentId}"
    fun form(id: String) = "form/" + Uri.encode(id)
    fun access(id: String) = "access/" + Uri.encode(id)

    const val WING_PATTERN = "wing/{wingId}"
    const val MODULE_PATTERN = "module/{wingId}/{moduleId}"
    const val LIST_PATTERN = "list/{typeCode}"
    const val RECORD_PATTERN = "record/{typeCode}/{id}"
    const val REPORT_PATTERN = "report/{reportId}"
    const val QR_PATTERN = "qr/{token}"

    fun wing(id: String) = "wing/" + Uri.encode(id)
    fun module(wingId: String, moduleId: String) = "module/" + Uri.encode(wingId) + "/" + Uri.encode(moduleId)
    fun list(type: RecordType) = "list/" + type.code
    fun record(ref: RecordRef) = "record/" + ref.type.code + "/" + Uri.encode(ref.id)
    fun report(id: String) = "report/" + Uri.encode(id)
    fun qr(token: String) = "qr/" + Uri.encode(token)
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

/** Icons for the setting-driven tabs (S17: ui.nav.bottom_tabs via [ShellTabs]). */
private fun tabIcon(key: String): ImageVector = when (key) {
    "home" -> Icons.Filled.Home; "tasks" -> Icons.Filled.Checklist; "reports" -> Icons.Filled.Assessment
    "search" -> Icons.Filled.Search; "scan" -> Icons.Filled.QrCodeScanner; "forms" -> Icons.Filled.Description
    "dashboard" -> Icons.Filled.Assessment
    else -> Icons.Filled.Person
}

private fun NavController.goToTab(route: String) {
    navigate(route) {
        popUpTo(Routes.HOME) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MohonaApp() {
    val session: SessionViewModel = viewModel()
    val nav = rememberNavController()
    val backStackEntry by nav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val state = session.state
    val connected = state.mode == AppMode.CONNECTED && state.profile?.isPreview == false
    val tabs = ShellTabs.resolve(if (connected) state.ui.tabs else null, if (connected) state.perms else null, if (connected) state.ui.modules else emptySet())
        .map { Tab(it.route, it.labelBn, tabIcon(it.key)) }
    val showBar = tabs.any { it.route == currentRoute }
    var draftInfo by remember { mutableStateOf<String?>(null) }
    val ctx = session.userContext()
    // F154-034: block screenshots / screen sharing for positions the Chairman chose (decided by the server, re-read on every position change)
    val activity = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity
    LaunchedEffect(state.profile, connected) {
        val block = connected && AppContainer.blockScreenshots
        activity?.window?.let { w ->
            if (block) w.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
            else w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }
    // OI-29: offline drafts sync by themselves after login and when the network comes back (never submitted automatically)
    com.mohona.erp.feature.forms.data.DraftAutoSyncEffect(active = connected) {
        session.syncDrafts { r -> if (r.synced + r.conflicts + r.failed > 0) draftInfo = "খসড়া স্বয়ংক্রিয় সিঙ্ক: ${r.synced} · ইতিমধ্যে জমা: ${r.conflicts} · ব্যর্থ: ${r.failed}" }
    }

    val openRecord: (RecordRef) -> Unit = { nav.navigate(Routes.record(it)) }
    val showQr: (RecordRef) -> Unit = { ref -> DemoRepository.get(ref)?.qrToken?.let { nav.navigate(Routes.qr(it)) } }

    Scaffold(
        containerColor = Color.White,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = currentRoute == t.route,
                            onClick = { nav.goToTab(t.route) },
                            icon = { Icon(t.icon, contentDescription = t.label) },
                            label = { Text(t.label, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { padding ->
      val systemScale = android.provider.Settings.Global.getFloat(androidx.compose.ui.platform.LocalContext.current.contentResolver,
          android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
      val motionMs = com.mohona.erp.feature.design.data.MotionPolicy.durationMs(state.design?.motion ?: com.mohona.erp.feature.design.data.Motion(), systemScale)
      var banner by remember { mutableStateOf<List<com.mohona.erp.feature.notify.data.Notice>>(emptyList()) }
      LaunchedEffect(connected, currentRoute) {
          banner = if (connected) ((AppContainer.notify?.banner() as? com.mohona.erp.core.net.ApiResult.Ok)?.value ?: emptyList()) else emptyList()
      }
      CompositionLocalProvider(LocalPermissions provides (if (connected) state.perms else null), LocalMotionMs provides motionMs) {
       androidx.compose.foundation.layout.Column {
        CriticalBanner(banner) { nav.navigate(Routes.INBOX) }
        NavHost(navController = nav, startDestination = Routes.LOGIN, modifier = Modifier.padding(padding)) {
            composable(Routes.LOGIN) {
                val goHome: () -> Unit = { nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } } }
                LoginScreen(
                    session = state,
                    onSelectMode = { session.selectMode(it) },
                    onStartPreview = { primary, secondary ->
                        session.startPreview(primary, secondary)
                        nav.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } }
                    },
                    connected = ConnectedActions(
                        pinLogin = { phone, pin -> session.loginConnected(phone, pin, goHome) },
                        startOtp = { session.startOtp(it) },
                        verifyOtp = { session.verifyOtp(it) },
                        setPin = { pin, confirm -> session.setNewPin(pin, confirm, goHome) },
                        choosePosition = { session.choosePosition(it, goHome) },
                        goTo = { session.goTo(it) },
                        verifyMfa = { session.verifyMfa(it, goHome) }
                    )
                )
            }
            composable(Routes.HOME) {
                Guard(ctx, nav) { c ->
                    // Prime Distribution Architect 1: the connected app opens on the seven main icons; Preview keeps the sample home.
                    if (!c.isPreview) PrimeHomeScreen(
                        companyName = listOfNotNull(state.profile?.companyName, state.profile?.name).joinToString(" · "),
                        onOpenDepartment = { DeptNav.current = it; nav.navigate(Routes.DEPARTMENT) },
                        onNotifications = { nav.navigate(Routes.INBOX) },
                        onProfile = { nav.goToTab(Routes.PROFILE) }
                    ) else
                    GlobalHomeScreen(
                        ctx = c, authorizedCompanyIds = session.authorizedCompanyIds(), isPreview = c.isPreview,
                        unreadNotifications = DemoRepository.notifications.size,
                        onOpenWing = { nav.navigate(Routes.wing(it)) },
                        onSearch = { nav.goToTab(Routes.SEARCH) },
                        onNotifications = { nav.navigate(Routes.NOTIFICATIONS) },
                        onProfile = { nav.goToTab(Routes.PROFILE) },
                        onChairman = { nav.navigate(Routes.CHAIRMAN) },
                        onSelectCompany = { session.selectCompany(it) }
                    )
                }
            }
            composable(Routes.SEARCH) { Guard(ctx, nav) { c -> SearchScreen(c, { nav.goToTab(Routes.HOME) }, openRecord, showQr) } }
            composable(Routes.SCAN) { Guard(ctx, nav) { _ -> ScannerScreen { token -> nav.navigate(Routes.qr(token)) } } }
            composable(Routes.REPORTS) { Guard(ctx, nav) { c -> ReportCenterScreen(c, null) { nav.navigate(Routes.report(it)) } } }
            composable(Routes.PROFILE) {
                Guard(ctx, nav) { _ ->
                    val p = state.profile
                    val shell = ProfileShellActions(
                        onSettings = { nav.navigate(Routes.SETTINGS) }, onDesign = { nav.navigate(Routes.DESIGN) }, onLayout = { nav.navigate(Routes.LAYOUT) }, onRecycle = { nav.navigate(Routes.RECYCLE) }, onInbox = { nav.navigate(Routes.INBOX) }, onStructure = { nav.navigate(Routes.STRUCTURE) }, onProducts = { nav.navigate(Routes.PRODUCTS) }, onStock = { nav.navigate(Routes.STOCK) }, onProcurement = { nav.navigate(Routes.PROCUREMENT) }, onWarehouse = { nav.navigate(Routes.WAREHOUSE) }, onMfg = { nav.navigate(Routes.MFG) }, onFinance = { nav.navigate(Routes.FINANCE) }, onDealers = { nav.navigate(Routes.DEALERS) }, onSales = { nav.navigate(Routes.SALES) }, onMyDay = { nav.navigate(Routes.MYDAY) }, onScan = { nav.navigate(Routes.QRSCAN) }, onPrint = { nav.navigate(Routes.PRINT) },
                        onReports = { nav.navigate(Routes.CUSTOM_REPORTS) }, onMap = { nav.navigate(Routes.MAP) }, onOps = { nav.navigate(Routes.OPS) }, onCourier = { nav.navigate(Routes.COURIER) }, onChairmanPanel = { nav.navigate(Routes.CHAIRMAN_PANEL) }, onOrg = { nav.navigate(Routes.ORG) }, onForms = { nav.navigate(Routes.FORMS) },
                        onSyncDrafts = { session.syncDrafts { r -> draftInfo = "সিঙ্ক: ${r.synced} · ইতিমধ্যে জমা: ${r.conflicts} · ব্যর্থ: ${r.failed}" + (r.firstError?.let { " — $it" } ?: "") } },
                        onLogoutEverywhere = { session.logoutEverywhere(); nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } } },
                        draftInfo = draftInfo)
                    if (p != null) ProfileScreen(state, p, onDiagnostics = { nav.navigate(Routes.DIAGNOSTICS) }, shell = shell) {
                        session.logout()
                        nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } }
                    }
                }
            }
            composable(Routes.FORMS) { Guard(ctx, nav) { _ -> FormsListScreen({ nav.popBackStack() }) { nav.navigate(Routes.form(it.id)) } } }
            composable(Routes.FORM_PATTERN, arguments = listOf(navArgument("formId") { type = NavType.StringType })) { e ->
                Guard(ctx, nav) { c -> FormFillScreen(e.arguments?.getString("formId").orEmpty(), c.companyId) { nav.popBackStack() } }
            }
            composable(Routes.QRSCAN) { Guard(ctx, nav) { _ -> ScanScreen { nav.popBackStack() } } }
            composable(Routes.PRINT) { Guard(ctx, nav) { _ -> PrintScreen { nav.popBackStack() } } }
            composable(Routes.CUSTOM_REPORTS) { Guard(ctx, nav) { _ -> ReportsScreen { nav.popBackStack() } } }
            composable(Routes.MAP) { Guard(ctx, nav) { _ -> MapScreen { nav.popBackStack() } } }
            composable(Routes.DEPARTMENT) { Guard(ctx, nav) { _ -> DepartmentScreen(DeptNav.current, { nav.navigate(it) }) { nav.popBackStack() } } }
            composable(Routes.COURIER) { Guard(ctx, nav) { _ -> CourierScreen(false) { nav.popBackStack() } } }
            composable(Routes.CHAIRMAN_PANEL) { Guard(ctx, nav) { _ -> CourierScreen(true) { nav.popBackStack() } } }
            composable(Routes.OPS) { Guard(ctx, nav) { _ -> OpsScreen { nav.popBackStack() } } }
            composable(Routes.CHAIRMAN_STUDIO) { Guard(ctx, nav) { _ -> ChairmanStudioScreen { nav.popBackStack() } } }
            composable(Routes.MYDAY) { Guard(ctx, nav) { _ -> MyDayScreen { nav.popBackStack() } } }
            composable(Routes.SALES) { Guard(ctx, nav) { _ -> SalesScreen { nav.popBackStack() } } }
            composable(Routes.DEALERS) { Guard(ctx, nav) { _ -> DealerScreen { nav.popBackStack() } } }
            composable(Routes.FINANCE) { Guard(ctx, nav) { _ -> FinanceScreen { nav.popBackStack() } } }
            composable(Routes.MFG) { Guard(ctx, nav) { _ -> MfgScreen { nav.popBackStack() } } }
            composable(Routes.WAREHOUSE) { Guard(ctx, nav) { _ -> WarehouseScreen { nav.popBackStack() } } }
            composable(Routes.PROCUREMENT) { Guard(ctx, nav) { _ -> ProcurementScreen { nav.popBackStack() } } }
            composable(Routes.STOCK) { Guard(ctx, nav) { _ -> StockScreen { nav.popBackStack() } } }
            composable(Routes.PRODUCTS) { Guard(ctx, nav) { _ -> ProductsScreen { nav.popBackStack() } } }
            composable(Routes.STRUCTURE) { Guard(ctx, nav) { _ -> StructureScreen { nav.popBackStack() } } }
            composable(Routes.INBOX) { Guard(ctx, nav) { _ -> InboxScreen({ nav.popBackStack() }) { nav.navigate(Routes.APPROVALS) } } }
            composable(Routes.RECYCLE) { Guard(ctx, nav) { _ -> RecycleBinScreen { nav.popBackStack() } } }
            composable(Routes.DASHBOARD) {
                Guard(ctx, nav) { _ ->
                    DashboardScreen(state.design, if (state.design?.layouts?.containsKey("dashboard." + (state.profile?.roleCodes?.firstOrNull()?.lowercase() ?: "")) == true)
                        "dashboard." + state.profile?.roleCodes?.firstOrNull()?.lowercase() else "home", { nav.popBackStack() }) { nav.navigate(Routes.APPROVALS) }
                }
            }
            composable(Routes.LAYOUT) { Guard(ctx, nav) { _ -> LayoutStudioScreen { nav.popBackStack() } } }
            composable(Routes.DESIGN) { Guard(ctx, nav) { _ -> DesignStudioScreen(state.design?.icons ?: emptyList()) { nav.popBackStack() } } }
            composable(Routes.SETTINGS) { Guard(ctx, nav) { _ -> SettingsScreen { nav.popBackStack() } } }
            composable(Routes.ORG) { Guard(ctx, nav) { _ -> OrgTreeScreen({ nav.popBackStack() }) { nav.navigate(Routes.access(it)) } } }
            composable(Routes.ACCESS_PATTERN, arguments = listOf(navArgument("assignmentId") { type = NavType.StringType })) { e ->
                Guard(ctx, nav) { _ -> AccessPreviewScreen(e.arguments?.getString("assignmentId").orEmpty()) { nav.popBackStack() } }
            }
            composable(Routes.DIAGNOSTICS) { Guard(ctx, nav) { c -> DiagnosticsScreen(c.isPreview) { nav.popBackStack() } } }
            composable(Routes.NOTIFICATIONS) { Guard(ctx, nav) { c -> NotificationCenterScreen(c, { nav.popBackStack() }, openRecord) } }
            composable(Routes.APPROVALS) { Guard(ctx, nav) { c -> ApprovalCenterScreen(c, { nav.popBackStack() }, openRecord, showQr) } }
            composable(Routes.CHAIRMAN) {
                Guard(ctx, nav) { c ->
                    ChairmanScreen(c, session.authorizedCompanyIds(), { nav.popBackStack() }, { session.selectCompany(it) }) { nav.navigate(Routes.wing("mfg")) }
                }
            }
            composable(Routes.WING_PATTERN, arguments = listOf(navArgument("wingId") { type = NavType.StringType })) { e ->
                val id = e.arguments?.getString("wingId") ?: ""
                Guard(ctx, nav) { c ->
                    WingDashboardScreen(
                        wingId = id, ctx = c, onBack = { nav.popBackStack() },
                        onOpenModule = { w, m -> nav.navigate(Routes.module(w, m)) },
                        onOpenList = { nav.navigate(Routes.list(it)) },
                        onOpenRecord = openRecord,
                        onSearch = { nav.goToTab(Routes.SEARCH) },
                        onNotifications = { nav.navigate(Routes.NOTIFICATIONS) },
                        onApprovals = { nav.navigate(Routes.APPROVALS) },
                        onReports = { nav.goToTab(Routes.REPORTS) }
                    )
                }
            }
            composable(Routes.MODULE_PATTERN, arguments = listOf(navArgument("wingId") { type = NavType.StringType }, navArgument("moduleId") { type = NavType.StringType })) { e ->
                val w = e.arguments?.getString("wingId") ?: ""
                val m = e.arguments?.getString("moduleId") ?: ""
                Guard(ctx, nav) { c -> ModuleDashboardScreen(w, m, c, { nav.popBackStack() }, { nav.navigate(Routes.list(it)) }, openRecord) }
            }
            composable(Routes.LIST_PATTERN, arguments = listOf(navArgument("typeCode") { type = NavType.StringType })) { e ->
                val type = RecordType.fromCode(e.arguments?.getString("typeCode") ?: "")
                Guard(ctx, nav) { c ->
                    if (type == null) EmptyState("এই তালিকা পাওয়া যায়নি।")
                    else RecordListScreen(type, c, { nav.popBackStack() }, openRecord, showQr)
                }
            }
            composable(Routes.RECORD_PATTERN, arguments = listOf(navArgument("typeCode") { type = NavType.StringType }, navArgument("id") { type = NavType.StringType })) { e ->
                val type = RecordType.fromCode(e.arguments?.getString("typeCode") ?: "")
                val id = e.arguments?.getString("id") ?: ""
                Guard(ctx, nav) { c ->
                    if (type == null) EmptyState("এই রেকর্ড-ধরন পাওয়া যায়নি।")
                    else RecordDashboardScreen(RecordRef(type, id), c, { nav.popBackStack() }, openRecord, showQr)
                }
            }
            composable(Routes.REPORT_PATTERN, arguments = listOf(navArgument("reportId") { type = NavType.StringType })) { e ->
                val id = e.arguments?.getString("reportId") ?: ""
                Guard(ctx, nav) { c -> ReportPreviewScreen(id, c, { nav.popBackStack() }, openRecord) }
            }
            composable(Routes.QR_PATTERN, arguments = listOf(navArgument("token") { type = NavType.StringType })) { e ->
                val token = e.arguments?.getString("token") ?: ""
                Guard(ctx, nav) { c -> QrPreviewScreen(token, c, { nav.popBackStack() }, openRecord) }
            }
        }
       }
      }
    }
}

/** If the process was recreated without a session, send the user back to the login screen. */
@Composable
private fun Guard(ctx: UserContext?, nav: NavController, content: @Composable (UserContext) -> Unit) {
    if (ctx == null) {
        LaunchedEffect(Unit) { nav.navigate(Routes.LOGIN) { popUpTo(nav.graph.id) { inclusive = true } } }
    } else {
        content(ctx)
    }
}

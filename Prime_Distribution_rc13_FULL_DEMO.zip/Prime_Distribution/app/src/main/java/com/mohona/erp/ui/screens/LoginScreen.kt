package com.mohona.erp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mohona.erp.data.AppConfig
import com.mohona.erp.data.AppMode
import com.mohona.erp.data.Roles
import com.mohona.erp.data.SessionState
import com.mohona.erp.ui.components.MohonaLogo
import com.mohona.erp.ui.components.PreviewBanner
import com.mohona.erp.ui.theme.BackgroundGray
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.OrangeDark
import com.mohona.erp.ui.theme.OrangePrimary
import com.mohona.erp.ui.theme.OrangeSoft
import com.mohona.erp.ui.theme.TextMuted

@Composable
fun LoginScreen(
    session: SessionState,
    onSelectMode: (AppMode) -> Unit,
    onStartPreview: (primary: String, secondary: String?) -> Unit,
    connected: ConnectedActions
) {
    var primaryRole by remember { mutableStateOf("MD") }
    var secondaryRole by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .background(Brush.verticalGradient(listOf(OrangePrimary, OrangeDark))),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(108.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                MohonaLogo(size = 84.dp)
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .offset(y = (-26).dp)
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color.White)
                .padding(horizontal = 20.dp, vertical = 22.dp)
        ) {
            Text(text = "স্বাগতম", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(
                text = "আপনার কাজের জায়গায় প্রবেশ করুন",
                style = MaterialTheme.typography.bodyMedium,
                color = TextMuted
            )
            Spacer(Modifier.height(18.dp))

            // Mode selector (two clearly separated modes)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(BackgroundGray)
                    .padding(4.dp)
            ) {
                ModeTab(if (AppConfig.demoServer) "সাধারণ প্রিভিউ" else "প্রিভিউ মোড", session.mode == AppMode.PREVIEW, Modifier.weight(1f)) { onSelectMode(AppMode.PREVIEW) }
                ModeTab(if (AppConfig.demoServer) "পূর্ণ ডেমো" else "সংযুক্ত মোড", session.mode == AppMode.CONNECTED, Modifier.weight(1f)) { onSelectMode(AppMode.CONNECTED) }
            }
            Spacer(Modifier.height(16.dp))

            if (session.mode == AppMode.PREVIEW) {
                PreviewBanner("লগইন ছাড়াই ডিজাইন দেখুন। সব তথ্য নমুনা; কোনো বাস্তব ডেটা সংরক্ষণ বা পোস্ট হয় না। প্রিভিউ ভূমিকা কোনো ব্যাকএন্ড-অধিকার দেয় না।")
                Spacer(Modifier.height(14.dp))
                RoleDropdown(
                    label = "প্রিভিউ-ভূমিকা",
                    selected = primaryRole,
                    allowNone = false,
                    onSelect = { primaryRole = it ?: primaryRole }
                )
                Text(
                    text = Roles.find(primaryRole)?.descBn ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 6.dp)
                )
                Spacer(Modifier.height(10.dp))
                RoleDropdown(
                    label = "দ্বিতীয় ভূমিকা (ঐচ্ছিক; একাধিক ভূমিকার প্রিভিউ)",
                    selected = secondaryRole,
                    allowNone = true,
                    onSelect = { secondaryRole = it }
                )
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = { onStartPreview(primaryRole, secondaryRole) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary)
                ) {
                    Text("প্রিভিউ শুরু করুন", style = MaterialTheme.typography.titleSmall)
                }
            } else {
                if (AppConfig.demoServer) {
                    PreviewBanner("পূর্ণ ডেমো (সার্ভার ছাড়া): যেকোনো মোবাইল নম্বর (যেমন 01700000000) ও যেকোনো PIN দিন, তারপর যে পদের চোখে অ্যাপ দেখতে চান সেটি বেছে নিন — চেয়ারম্যান, এমডি, বিক্রয়, ডিলার, গুদাম, হিসাব, কারখানা, এইচআর। সব তথ্য একটি কাল্পনিক কোম্পানির নমুনা; কিছুই সংরক্ষিত হয় না।")
                    Spacer(Modifier.height(12.dp))
                } else if (!AppConfig.connectedConfigured) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(OrangeSoft)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = AppConfig.configProblem ?: "সংযুক্ত মোড কনফিগার করা নেই।",
                            style = MaterialTheme.typography.bodySmall,
                            color = OrangeDark
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                }
                ConnectedLoginPanel(session, connected)
                Text(
                    text = "মোবাইল নম্বর ও PIN দিয়ে লগইন; PIN শুধু সার্ভারে যাচাই হয়। প্রথমবার বা PIN ভুলে গেলে আমন্ত্রিত নম্বরে SMS-কোড। অনুমতি আসে বেছে নেওয়া পদের জন্য সার্ভার থেকে।",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun ModeTab(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(11.dp))
            .background(if (selected) Color.White else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) OrangeDark else TextMuted
        )
    }
}

@Composable
private fun RoleDropdown(label: String, selected: String?, allowNone: Boolean, onSelect: (String?) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Text(text = label, style = MaterialTheme.typography.labelLarge, color = TextMuted)
    Spacer(Modifier.height(6.dp))
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (selected == null) "— নেই —" else Roles.nameOf(selected),
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Start,
                maxLines = 1
            )
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (allowNone) {
                DropdownMenuItem(text = { Text("— নেই —") }, onClick = { onSelect(null); open = false })
            }
            Roles.all.forEach { r ->
                DropdownMenuItem(
                    text = { Text(r.nameBn) },
                    onClick = {
                        onSelect(r.code)
                        open = false
                    }
                )
            }
        }
    }
}

package com.mohona.erp.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.domain.UserContext
import com.mohona.erp.feature.auth.data.CompanyChoice
import com.mohona.erp.feature.auth.data.LoginRepository
import com.mohona.erp.feature.auth.data.LoginRules
import kotlinx.coroutines.launch

enum class AppMode { PREVIEW, CONNECTED }

/** Connected-mode login steps (S16). */
enum class ConnectedStep { PIN_LOGIN, OTP_PHONE, OTP_CODE, PIN_SETUP, POSITION, MFA }

data class SessionState(
    val mode: AppMode = if (AppConfig.demoServer) AppMode.CONNECTED else AppMode.PREVIEW,
    val profile: UserProfile? = null,
    val loading: Boolean = false,
    val error: String? = null,
    val info: String? = null,
    val step: ConnectedStep = ConnectedStep.PIN_LOGIN,
    val otpPhone: String? = null,
    val companies: List<CompanyChoice> = emptyList(),
    /** Position waiting for two-factor verification (OI-27), the TOTP factor to verify, and a new enrolment to show once. */
    val mfaFor: String? = null,
    val mfaFactorId: String? = null,
    val mfaEnrollment: com.mohona.erp.core.net.TotpEnrollment? = null,
    /** Permission hints + shell configuration of the selected position (S17). Null in Preview. */
    val perms: com.mohona.erp.feature.iam.data.MyPermissions? = null,
    val ui: com.mohona.erp.core.shell.UiConfig = com.mohona.erp.core.shell.UiConfig.DEFAULT,
    /** Active company design (theme + icon bindings) of the selected position (S18). */
    val design: com.mohona.erp.feature.design.data.ActiveDesign? = null
)

/**
 * Shared authentication & session layer.
 * - PREVIEW: a local demo profile; no network, nothing saved; the chosen roles only change what the demo shows.
 * - CONNECTED (S16): mobile number + PIN through the Edge Function (PIN checked only in the database); first login and
 *   "forgot PIN" go through an SMS OTP on an invited number. Then company/position selection; permissions come from the
 *   server for that position only. Tokens live in memory; sign-out ends the session on the server.
 */
const val DEMO_COMPANY_1 = "C1"
const val DEMO_COMPANY_2 = "C2"

class SessionViewModel : ViewModel() {
    var state by mutableStateOf(SessionState())
        private set

    /** Company currently in view (group-level roles may switch; everybody else is fixed to their own company). */
    var selectedCompanyId by mutableStateOf(DEMO_COMPANY_1)
        private set

    fun authorizedCompanyIds(): Set<String> {
        val p = state.profile
        if (p != null && !p.isPreview) return setOf(p.organizationId)
        val roles = p?.roleCodes ?: emptyList()
        return if ("CHAIRMAN" in roles) setOf(DEMO_COMPANY_1, DEMO_COMPANY_2) else setOf(DEMO_COMPANY_1)
    }

    fun selectCompany(id: String) {
        if (id in authorizedCompanyIds()) selectedCompanyId = id
    }

    /** Visual-simulation context. In Preview it carries no backend authority. */
    fun userContext(): UserContext? {
        val p = state.profile ?: return null
        val company = if (selectedCompanyId in authorizedCompanyIds()) selectedCompanyId else authorizedCompanyIds().first()
        return UserContext(p.name, p.employeeId, p.roleCodes, company, setOf(company), p.isPreview)
    }

    private val login: LoginRepository? get() = AppContainer.login

    fun selectMode(mode: AppMode) {
        state = state.copy(mode = mode, error = null, info = null)
    }

    fun startPreview(primaryRole: String, secondaryRole: String?) {
        selectedCompanyId = DEMO_COMPANY_1
        com.mohona.erp.data.demo.DemoRepository.resetSimulation()
        state = SessionState(mode = AppMode.PREVIEW, profile = PreviewProfiles.forRoles(primaryRole, secondaryRole))
    }

    fun goTo(step: ConnectedStep) {
        state = state.copy(step = step, error = null, info = null)
    }

    private inline fun withLogin(block: (LoginRepository) -> Unit) {
        val repo = login
        if (repo == null) state = state.copy(error = AppConfig.configProblem ?: "সংযুক্ত মোড কনফিগার করা নেই।") else block(repo)
    }

    /** Daily login: mobile number + PIN. */
    fun loginConnected(phone: String, pin: String, onSuccess: () -> Unit) = withLogin { repo ->
        if (LoginRules.canonicalPhone(phone) == null || pin.isEmpty()) {
            state = state.copy(error = "মোবাইল নম্বর ও PIN দিন।"); return@withLogin
        }
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            when (val r = repo.pinLogin(phone, pin, android.os.Build.MODEL ?: "Android")) {
                is ApiResult.Err -> state = state.copy(loading = false, error = r.error.messageBn)
                is ApiResult.Ok -> { state = state.copy(otpPhone = null); loadCompanies(onSuccess) }
            }
        }
    }

    /** First login / forgot PIN: only invited or linked numbers get a code (self sign-up is closed). */
    fun startOtp(phone: String) = withLogin { repo ->
        val canonical = LoginRules.canonicalPhone(phone)
        if (canonical == null) { state = state.copy(error = "মোবাইল নম্বর সঠিক নয়।"); return@withLogin }
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            val allowed = repo.otpStart(canonical)
            if (allowed is ApiResult.Ok && !allowed.value) {
                state = state.copy(loading = false, error = "এই নম্বরে লগইনের আমন্ত্রণ নেই; ব্যবস্থাপকের সাথে যোগাযোগ করুন।"); return@launch
            }
            if (allowed is ApiResult.Err) { state = state.copy(loading = false, error = allowed.error.messageBn); return@launch }
            when (val r = repo.requestOtp(canonical)) {
                is ApiResult.Err -> state = state.copy(loading = false, error = r.error.messageBn)
                is ApiResult.Ok -> state = state.copy(loading = false, step = ConnectedStep.OTP_CODE, otpPhone = canonical, info = "কোড পাঠানো হয়েছে।")
            }
        }
    }

    fun verifyOtp(code: String) = withLogin { repo ->
        val phone = state.otpPhone ?: run { goTo(ConnectedStep.OTP_PHONE); return@withLogin }
        viewModelScope.launch {
            state = state.copy(loading = true, error = null, info = null)
            when (val r = repo.verifyOtp(phone, code.trim())) {
                is ApiResult.Err -> { state = state.copy(loading = false, error = r.error.messageBn); return@launch }
                is ApiResult.Ok -> Unit
            }
            if (state.mfaFor != null) { prepareMfa(); return@launch }
            // first login claims the invitation; for an already-linked login there is no open invitation (that is fine)
            repo.claimInvitation()
            state = state.copy(loading = false, step = ConnectedStep.PIN_SETUP, info = "নতুন PIN ঠিক করুন।")
        }
    }

    /** Sets (or resets) the PIN behind the fresh OTP, registers this device, then logs in with the new PIN. */
    fun setNewPin(pin: String, confirm: String, onSuccess: () -> Unit) = withLogin { repo ->
        if (pin != confirm) { state = state.copy(error = "দুটি PIN মেলেনি।"); return@withLogin }
        LoginRules.pinProblemBn(LoginRules.pinProblem(pin))?.let { state = state.copy(error = it); return@withLogin }
        val phone = state.otpPhone ?: return@withLogin
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            val set = repo.setPin(pin)
            if (set is ApiResult.Err) { state = state.copy(loading = false, error = set.error.messageBn); return@launch }
            val dev = repo.registerDevice(android.os.Build.MODEL ?: "Android")
            if (dev is ApiResult.Err) { state = state.copy(loading = false, error = dev.error.messageBn); return@launch }
            repo.signOut(false)                       // leave the OTP session; daily work runs on the PIN session
            when (val r = repo.pinLogin(phone, pin, android.os.Build.MODEL ?: "Android")) {
                is ApiResult.Err -> state = state.copy(loading = false, step = ConnectedStep.PIN_LOGIN, error = r.error.messageBn)
                is ApiResult.Ok -> loadCompanies(onSuccess)
            }
        }
    }

    private suspend fun loadCompanies(onSuccess: () -> Unit) {
        val repo = login ?: return
        when (val r = repo.companies()) {
            is ApiResult.Err -> state = state.copy(loading = false, error = r.error.messageBn)
            is ApiResult.Ok -> {
                val auto = LoginRepository.autoPick(r.value)
                if (auto != null) enterPosition(auto.assignmentId, onSuccess)
                else state = state.copy(loading = false, step = ConnectedStep.POSITION, companies = r.value,
                    error = if (r.value.none { c -> c.positions.any { it.usable } }) "কোনো সক্রিয় পদ নেই।" else null)
            }
        }
    }

    fun choosePosition(assignmentId: String, onSuccess: () -> Unit) {
        val needsMfa = state.companies.flatMap { it.positions }.any { it.assignmentId == assignmentId && it.mfaRequired }
        if (needsMfa) {
            // PIN and OTP sessions are aal1: an MFA position needs a GoTrue session + TOTP (aal2)
            if (AppContainer.client?.sessionKind == "pin" || state.otpPhone == null) {
                state = state.copy(step = ConnectedStep.OTP_PHONE, mfaFor = assignmentId, error = null,
                    info = "এই পদের জন্য মোবাইল-কোড ও দুই-ধাপ যাচাই (Authenticator) লাগবে।")
            } else {
                state = state.copy(mfaFor = assignmentId)
                viewModelScope.launch { prepareMfa() }
            }
            return
        }
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            enterPosition(assignmentId, onSuccess)
        }
    }

    /** After the OTP: verify an existing TOTP factor, or enrol one first (secret shown once). */
    private suspend fun prepareMfa() {
        val c = AppContainer.client ?: return
        state = state.copy(loading = true, error = null)
        when (val f = c.mfaVerifiedTotp()) {
            is ApiResult.Err -> state = state.copy(loading = false, error = f.error.messageBn)
            is ApiResult.Ok -> if (f.value.isNotEmpty()) {
                state = state.copy(loading = false, step = ConnectedStep.MFA, mfaFactorId = f.value.first(), mfaEnrollment = null,
                    info = "Authenticator অ্যাপের ৬ অঙ্কের কোড দিন।")
            } else when (val e = c.mfaEnrollTotp("Prime Distribution " + (android.os.Build.MODEL ?: "Android"))) {
                is ApiResult.Err -> state = state.copy(loading = false, error = e.error.messageBn)
                is ApiResult.Ok -> state = state.copy(loading = false, step = ConnectedStep.MFA, mfaFactorId = e.value.factorId, mfaEnrollment = e.value,
                    info = "Authenticator অ্যাপে এই গোপন কী যোগ করে কোড দিন। কী-টি আর দেখানো হবে না।")
            }
        }
    }

    fun verifyMfa(code: String, onSuccess: () -> Unit) {
        val c = AppContainer.client ?: return
        val factor = state.mfaFactorId ?: return
        val target = state.mfaFor ?: return
        viewModelScope.launch {
            state = state.copy(loading = true, error = null)
            when (val r = c.mfaVerify(factor, code.trim())) {
                is ApiResult.Err -> state = state.copy(loading = false, error = r.error.messageBn)
                is ApiResult.Ok -> { state = state.copy(mfaEnrollment = null); enterPosition(target, onSuccess) }
            }
        }
    }

    /** Selects the position on the server, then loads its permissions (UI hints) — never a client-side role choice. */
    private suspend fun enterPosition(assignmentId: String, onSuccess: () -> Unit) {
        val positions = AppContainer.positions ?: return
        val ctx = when (val r = positions.select(assignmentId)) {
            is ApiResult.Err -> { state = state.copy(loading = false, error = r.error.messageBn); return }
            is ApiResult.Ok -> r.value
        }
        // Prime 08: a new position or company = everything re-checked. Nothing read under the previous position/company stays on screen.
        AppContainer.cache.clearAll(); AppContainer.kpiCache.clear()
        AppContainer.blockScreenshots = ((AppContainer.client?.rpcObject("v1_screen_policy") as? ApiResult.Ok)?.value?.optBoolean("block_screenshots") ?: false)
        val perms = (AppContainer.permissions?.mine() as? ApiResult.Ok)?.value
        val ui = (AppContainer.shell?.load() as? ApiResult.Ok)?.value ?: com.mohona.erp.core.shell.UiConfig.DEFAULT
        // published company theme (S18); a bad or missing one falls back to the built-in tokens, never to an unreadable UI
        val design = (AppContainer.design?.active() as? ApiResult.Ok)?.value
        com.mohona.erp.ui.theme.ThemeRuntime.apply(
            design?.tokens?.let { com.mohona.erp.ui.theme.tokens.TokenCodec.decode(it).tokens } ?: com.mohona.erp.ui.theme.tokens.MohonaTokens.DEFAULT)
        com.mohona.erp.ui.theme.DesignProps.apply(design?.props)
        selectedCompanyId = ctx.companyId
        AppContainer.currentPersonId = ctx.personId
        AppContainer.uiMaxDrafts = ui.maxDrafts
        state = SessionState(
            mode = AppMode.CONNECTED,
            perms = perms ?: com.mohona.erp.feature.iam.data.MyPermissions.NONE,
            ui = ui,
            design = design,
            profile = UserProfile(
                name = ctx.positionNameBn,
                roleCodes = listOf(ctx.positionCode),
                companyName = ctx.companyNameBn,
                companyCode = ctx.companyCode,
                isPreview = false,
                permissions = perms?.grants?.flatMap { (code, scopes) -> scopes.map { PermissionGrant(code, it.kind.name) } } ?: emptyList(),
                organizationId = ctx.companyId,
                employeeId = ctx.membershipId
            )
        )
        onSuccess()
    }

    /** Sign out on every device: ends all sessions and removes this device's offline drafts (OI-18). */
    fun logoutEverywhere() {
        val repo = login
        AppContainer.draftStore?.clearAll()
        selectedCompanyId = DEMO_COMPANY_1
        AppContainer.clearSessionData()
        com.mohona.erp.ui.theme.ThemeRuntime.reset(); com.mohona.erp.ui.theme.DesignProps.reset()
        state = SessionState(mode = state.mode)
        if (repo != null) viewModelScope.launch { repo.signOut(true) }
    }

    /** Pushes this person's offline drafts (never submits). */
    fun syncDrafts(onDone: (com.mohona.erp.feature.forms.data.SyncReport) -> Unit) {
        val store = AppContainer.draftStore ?: return
        val forms = AppContainer.forms ?: return
        val p = state.profile ?: return
        val personId = AppContainer.currentPersonId ?: return
        viewModelScope.launch {
            onDone(com.mohona.erp.feature.forms.data.DraftSyncer(store, forms)
                .syncAll(p.organizationId, personId, state.ui.draftTtlDays) { java.util.UUID.randomUUID().toString() })
        }
    }

    /** Clears the session immediately; the server-side sign-out (PIN session + selected position) follows. */
    fun logout() {
        val repo = login
        selectedCompanyId = DEMO_COMPANY_1
        if (com.mohona.erp.data.demo.DemoRepository.isLoaded) com.mohona.erp.data.demo.DemoRepository.resetSimulation()
        AppContainer.clearSessionData()
        com.mohona.erp.ui.theme.ThemeRuntime.reset(); com.mohona.erp.ui.theme.DesignProps.reset()
        state = SessionState(mode = state.mode)
        if (repo != null) viewModelScope.launch { repo.signOut(false) }
    }
}

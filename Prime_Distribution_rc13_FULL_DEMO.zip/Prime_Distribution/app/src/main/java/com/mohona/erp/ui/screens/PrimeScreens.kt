package com.mohona.erp.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.mohona.erp.core.di.AppContainer
import com.mohona.erp.core.net.ApiResult
import com.mohona.erp.core.shell.LocalPermissions
import com.mohona.erp.feature.actions.ActionCatalog
import com.mohona.erp.feature.actions.ActionDef
import com.mohona.erp.feature.actions.Department
import com.mohona.erp.feature.actions.FieldType
import com.mohona.erp.feature.actions.LookupField
import com.mohona.erp.feature.actions.LookupKinds
import com.mohona.erp.ui.components.AppCard
import com.mohona.erp.ui.components.ScreenHeader
import com.mohona.erp.ui.theme.BadRed
import com.mohona.erp.ui.theme.TextMuted
import kotlinx.coroutines.launch

/** Departments the current position may open. The Chairman icon needs loaded permissions AND the Chairman-only right. */
@Composable
fun visibleDepartments(): List<Department> {
    val perms = LocalPermissions.current
    return ActionCatalog.departments.filter { d ->
        when {
            d.chairmanOnly -> perms != null && perms.has(d.gatePermission ?: "")
            d.id == "dealer" -> perms != null && perms.has("dealer.portal.read")
            d.gatePermission == null -> true
            else -> perms == null || perms.has(d.gatePermission ?: "")
        }
    }
}

/**
 * Prime Distribution main screen: ONLY the seven main icons (MFS, Warehouse, DMS, CRM, Office/HR, Courier, Chairman).
 * Icons without permission are not shown; the seventh is for the Chairman alone.
 */
@Composable
fun PrimeHomeScreen(companyName: String, onOpenDepartment: (String) -> Unit, onNotifications: () -> Unit, onProfile: () -> Unit) {
    val depts = visibleDepartments()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Prime Distribution", style = MaterialTheme.typography.headlineSmall)
        if (companyName.isNotBlank()) Text(companyName, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
        if (com.mohona.erp.data.AppConfig.demoServer) com.mohona.erp.ui.components.PreviewBanner("পূর্ণ ডেমো: কাল্পনিক কোম্পানির নমুনা তথ্য; কোনো কাজ সংরক্ষিত হয় না। অন্য পদের চোখে দেখতে প্রোফাইল থেকে লগআউট করে আবার ঢুকুন।")
        depts.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                pair.forEach { d ->
                    AppCard(modifier = Modifier.weight(1f), onClick = { onOpenDepartment(d.id) }) {
                        Column(Modifier.padding(vertical = 22.dp, horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(d.icon, style = MaterialTheme.typography.displaySmall)
                            Text(d.titleBn, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
                if (pair.size == 1) Column(Modifier.weight(1f)) {}
            }
        }
        if (depts.isEmpty()) Text("আপনার পদে এখনো কোনো বিভাগের অনুমতি নেই — চেয়ারম্যানের সাথে যোগাযোগ করুন।", color = TextMuted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onNotifications) { Text("নোটিফিকেশন") }
            OutlinedButton(onClick = onProfile) { Text("প্রোফাইল") }
        }
    }
}

/**
 * One department: its ready screens first, then every server action of the department as a form (search by name).
 * Results are shown as plain lines; the server enforces every right and rule.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DepartmentScreen(departmentId: String, onOpenRoute: (String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val perms = LocalPermissions.current
    val dept = ActionCatalog.departments.firstOrNull { it.id == departmentId } ?: ActionCatalog.departments.first()
    val allowed = visibleDepartments().any { it.id == dept.id }
    val actions = remember(dept.id) {
        runCatching { context.assets.open("lookup_kinds.json").bufferedReader(Charsets.UTF_8).use { it.readText() } }.onSuccess { LookupKinds.load(it) }
        runCatching { context.assets.open("actions.json").bufferedReader(Charsets.UTF_8).use { it.readText() } }
            .map { ActionCatalog.parse(it) }.getOrDefault(emptyList()).filter { it.department == dept.id }
    }
    var query by remember { mutableStateOf("") }
    var current by remember { mutableStateOf<ActionDef?>(null) }
    var values by remember { mutableStateOf(mapOf<String, String>()) }
    var result by remember { mutableStateOf<List<String>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(dept.icon + " " + dept.titleBn, onBack)
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            val a = current
            if (!allowed) {
                Text("এই বিভাগ দেখার অনুমতি নেই।", color = BadRed)
            } else if (a == null) {
                dept.links.filter { l -> perms == null || (l.permission?.let { perms.has(it) } ?: true) }.forEach { l ->
                    Button(onClick = { onOpenRoute(l.route) }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text(l.titleBn) }
                }
                Text("সব কাজ (ফর্ম)", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("কাজ খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                actions.filter { query.isBlank() || it.titleBn.contains(query.trim(), ignoreCase = true) || it.rpc.contains(query.trim(), ignoreCase = true) }.forEach { d ->
                    OutlinedButton(onClick = { current = d; values = emptyMap(); result = emptyList(); error = null }, modifier = Modifier.fillMaxWidth()) {
                        Text(d.titleBn + if (d.write) "" else "  (দেখা)")
                    }
                }
                if (actions.isEmpty()) Text("কাজের তালিকা লোড হয়নি।", color = TextMuted)
            } else {
                Text(a.titleBn, style = MaterialTheme.typography.titleMedium)
                Text(a.rpc, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                a.fields.forEach { f ->
                    if (f.type == FieldType.BOOL) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(f.labelBn, modifier = Modifier.width(140.dp), style = MaterialTheme.typography.bodySmall)
                            listOf("true" to "হ্যাঁ", "false" to "না", "" to "—").forEach { (v, l) ->
                                FilterChip(selected = values[f.param].orEmpty() == v, onClick = { values = values + (f.param to v) }, label = { Text(l) })
                            }
                        }
                    } else if (f.type == FieldType.UUID && LookupKinds.kindFor(f.param) != null) {
                        LookupField(f.labelBn, LookupKinds.kindFor(f.param)!!, f.optional, values[f.param].orEmpty()) { v -> values = values + (f.param to v) }
                    } else {
                        OutlinedTextField(value = values[f.param].orEmpty(), onValueChange = { v -> values = values + (f.param to v) }, modifier = Modifier.fillMaxWidth(),
                            singleLine = f.type != FieldType.JSON,
                            label = { Text(f.labelBn + when (f.type) { FieldType.DATE -> " (বছর-মাস-দিন)"; FieldType.JSON -> " (JSON)"; FieldType.UUID -> " (আইডি)"; FieldType.TEXT_ARRAY -> " (কমা দিয়ে)"; else -> "" } +
                                if (f.optional) " · ঐচ্ছিক" else "") })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !busy, onClick = {
                        val params = ActionCatalog.buildParams(a, values)
                        val client = AppContainer.client
                        if (params.isFailure) {
                            error = params.exceptionOrNull()?.message ?: "তথ্য ঠিক নয়।"
                        } else if (client == null) {
                            error = "সংযুক্ত মোড নয়।"
                        } else {
                            busy = true; error = null
                            scope.launch {
                                when (val r = client.rpc(a.rpc, params.getOrThrow(), write = a.write)) {
                                    is ApiResult.Ok -> result = ActionCatalog.render(r.value)
                                    is ApiResult.Err -> { result = emptyList(); error = r.error.messageBn }
                                }
                                busy = false
                            }
                        }
                    }) { Text(if (a.write) "জমা দিন" else "দেখুন") }
                    OutlinedButton(onClick = { current = null; result = emptyList(); error = null }) { Text("তালিকায় ফিরুন") }
                }
                error?.let { Text(it, color = BadRed, style = MaterialTheme.typography.bodySmall) }
                result.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

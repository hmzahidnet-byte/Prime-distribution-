package com.mohona.erp.core

import com.mohona.erp.core.net.DemoTransport
import com.mohona.erp.core.net.HttpRequest
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The full demo answers the real app requests from the recorded fixtures (assets/demo/rpc_fixtures.json). */
class DemoTransportTest {
    private val t = DemoTransport { File("src/main/assets/demo/rpc_fixtures.json").takeIf { it.exists() }?.readText() }
    private fun rpc(name: String, body: JSONObject = JSONObject(), write: Boolean = false) =
        t.execute(HttpRequest("POST", DemoTransport.BASE_URL + "/rest/v1/rpc/" + name,
            if (write) mapOf("Idempotency-Key" to "k") else emptyMap(), body.toString()))

    @Test fun loginPositionsAndRoleSwitch() {
        val login = t.execute(HttpRequest("POST", DemoTransport.BASE_URL + "/functions/v1/auth-pin-login", emptyMap(), "{}"))
        assertEquals(200, login.code)
        assertTrue(JSONObject(login.body).has("expires_at"))
        val companies = JSONArray(rpc("v1_auth_my_companies").body)
        val positions = companies.getJSONObject(0).getJSONArray("positions")
        assertTrue(positions.length() >= 10)
        val sm = (0 until positions.length()).map { positions.getJSONObject(it) }.first { it.getString("position_code") == "SALES_MANAGER" }
        assertEquals(false, sm.getBoolean("mfa_required"))
        assertEquals(200, rpc("v1_iam_select_position", JSONObject().put("p_assignment_id", sm.getString("assignment_id")), write = true).code)
        assertEquals("SALES_MANAGER", t.role)
    }

    @Test fun kpiSubsetInRequestedOrder() {
        val r = rpc("v1_kpi_values", JSONObject().put("p_codes", JSONArray().put("dms.sales").put("approvals.pending")).put("p_period", "this_month"))
        assertEquals(200, r.code)
        val a = JSONArray(r.body)
        assertEquals(2, a.length())
        assertEquals("dms.sales", a.getJSONObject(0).getString("code"))
    }

    @Test fun writesAreAcknowledgedNeverStoredAndUnknownReadsSayNoData() {
        val w = rpc("v1_order_create", JSONObject(), write = true)
        assertEquals(200, w.code)
        assertEquals("demo_saved", JSONObject(w.body).getString("status"))
        val u = rpc("v1_does_not_exist")
        assertEquals(400, u.code)
        assertTrue(u.body.contains("E_DEMO_NO_DATA"))
    }
}

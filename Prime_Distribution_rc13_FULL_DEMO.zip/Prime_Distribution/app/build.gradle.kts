import java.util.Properties
import java.time.Instant

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Optional Staging credentials from local.properties or environment. Only the PUBLIC anon/publishable key belongs here.
val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
// Build identity: GIT_SHA comes from CI (GITHUB_SHA) or `git rev-parse`; never invented.
fun gitSha(): String = (System.getenv("GITHUB_SHA") ?: runCatching {
    ProcessBuilder("git", "rev-parse", "HEAD").directory(rootDir).redirectErrorStream(true).start()
        .inputStream.bufferedReader().readText().trim().takeIf { it.matches(Regex("[0-9a-f]{40}")) }
}.getOrNull() ?: "UNKNOWN").take(40)
fun cfg(name: String): String =
    (localProps.getProperty(name) ?: System.getenv(name) ?: "").trim().replace("\"", "").replace("\\", "")

android {
    namespace = "com.mohona.erp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.prime.distribution"
        minSdk = 26
        targetSdk = 34
        versionCode = 22
        versionName = "1.0.0-rc13"
        buildConfigField("String", "SUPABASE_URL", "\"${cfg("SUPABASE_URL")}\"")
        buildConfigField("String", "GIT_SHA", "\"${gitSha()}\"")
        buildConfigField("String", "BUILD_TIME_UTC", "\"${Instant.now()}\"")
        buildConfigField("String", "SUPABASE_ANON_KEY", "\"${cfg("SUPABASE_ANON_KEY")}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.navigation:navigation-compose:2.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // QR scanning through Google's code scanner (no camera permission, reads one frame, records nothing).
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    // In-app map without an API key (OpenStreetMap tiles; offline region packages, V162-12).
    implementation("org.osmdroid:osmdroid-android:6.1.17")
    // QR image on invoices / receipts (encoder only; scanning stays with the Google code scanner).
    implementation("com.google.zxing:core:3.5.3")

    debugImplementation("androidx.compose.ui:ui-tooling")

    // JVM unit tests (costing, demo-graph integrity, access/action policy, navigation routes). org.json is the real library because Android's is stubbed in unit tests.
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20231013")
}

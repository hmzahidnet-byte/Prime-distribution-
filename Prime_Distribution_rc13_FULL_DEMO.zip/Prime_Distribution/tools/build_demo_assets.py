#!/usr/bin/env python3
"""Builds app/src/main/assets/demo/rpc_fixtures.json from a Dev database that ran backend/supabase/seed/demo_seed.sql + demo_record.sql.
The app's DemoTransport answers every read with what the REAL server returned for that position (recorded, not hand-written).
Usage: PGHOST=... PGPORT=... PGUSER=... PGDATABASE=demo python3 tools/build_demo_assets.py"""
import json, os, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'app', 'src', 'main', 'assets', 'demo', 'rpc_fixtures.json')


def q(sql):
    r = subprocess.run(['psql', '-At', '-v', 'ON_ERROR_STOP=1', '-c', sql], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(r.stderr)
    return r.stdout.strip()


users = json.loads(q("select json_agg(json_build_object('role', role, 'assignment_id', assignment_id, 'name_bn', name_bn) order by role) from demo_seed.users"))
rows = json.loads(q("""select json_agg(json_build_object('r', role, 'n', rpc, 'm', match, 'b', body, 's', err_state, 'e', err_message) order by role, rpc, match::text)
                       from demo_seed.fixture"""))
# one login for every demo position: the company list carries all positions (no MFA in the demo)
company = None
positions = []
order = ['CHAIRMAN', 'MD', 'SALES_MANAGER', 'FIELD_SALES', 'FIELD_SALES_2', 'DEALER_PORTAL', 'STOREKEEPER', 'ACCOUNTANT', 'CASHIER', 'FIN_MANAGER',
         'PROD_SUPERVISOR', 'QC_OFFICER', 'PURCHASE_OFFICER', 'HR_OFFICER', 'PAYROLL_OFFICER', 'WING_HEAD']
by_role = {u['role']: u for u in users}
for row in rows:
    if row['n'] == 'v1_auth_my_companies' and row['m'] == {} and row['s'] is None and row['b']:
        for c in row['b']:
            if company is None:
                company = {k: v for k, v in c.items() if k != 'positions'}
            for p in c['positions']:
                if p['assignment_id'] == by_role[row['r']]['assignment_id']:
                    positions.append(dict(p, mfa_required=False, usable=True, name_bn=p['name_bn'] + ' — ' + by_role[row['r']]['name_bn'], _role=row['r']))
positions.sort(key=lambda p: order.index(p['_role']) if p['_role'] in order else 99)
for p in positions:
    p.pop('_role')
company['positions'] = positions

fx = {}
for row in rows:
    e = {'m': row['m']}
    if row['s'] is None:
        e['b'] = row['b']
    else:
        e['e'] = {'code': row['s'], 'message': row['e']}
    fx.setdefault(row['r'], {}).setdefault(row['n'], []).append(e)

doc = {'note': 'DEMO data recorded from the real server functions on a fictional company; nothing here is real.',
       'recorded_on': q('select current_date'),
       'roles': {u['assignment_id']: u['role'] for u in users},
       'companies': [company],
       'fixtures': fx}
os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(doc, f, ensure_ascii=False, separators=(',', ':'))
print('wrote', OUT, os.path.getsize(OUT), 'bytes,', len(positions), 'positions,', sum(len(v) for v in fx.values()), 'rpc entries')
